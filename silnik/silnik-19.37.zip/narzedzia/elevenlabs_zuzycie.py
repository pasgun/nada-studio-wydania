"""Zużycie kredytów ElevenLabs: ile zostało w okresie rozliczeniowym, ile poszło każdego dnia i na co
(lektor, rozpoznawanie mowy, czyszczenie dźwięku, dubbing), plus ostatnie nagrania lektora.

  python narzedzia/elevenlabs_zuzycie.py [--dni 14]

Tylko odczyt: nic nie kosztuje. Klucz bierze z .env (nie wypisuje go).
"""
import argparse
import sys
import time
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import blad, klucz, wynik  # noqa: E402

API = "https://api.elevenlabs.io"
NAZWY = {"tts": "lektor (tekst na mowę)", "stt": "rozpoznawanie mowy (napisy, transkrypcja)", "speech_to_text": "rozpoznawanie mowy (napisy, transkrypcja)",
         "voice_isolator": "czyszczenie dźwięku (Voice Isolator)", "audio_isolation": "czyszczenie dźwięku (Voice Isolator)",
         "dubbing": "dubbing", "sts": "zmiana głosu", "speech_to_speech": "zmiana głosu", "sound_effects": "efekty dźwiękowe",
         "music": "muzyka", "voice_design": "projektowanie głosu", "All": "razem"}


def zapytaj(sciezka, params=None):
    import requests
    r = requests.get(API + sciezka, headers={"xi-api-key": klucz("ELEVENLABS_API_KEY")}, params=params or {}, timeout=40)
    if r.status_code in (401, 403):
        return None, f"ElevenLabs odrzucił zapytanie ({r.status_code}): klucz nie ma uprawnienia do tej informacji"
    if not r.ok:
        return None, f"{r.status_code}: {r.text[:200]}"
    return r.json(), None


def dzien(ms):
    return datetime.fromtimestamp(ms / 1000).strftime("%Y-%m-%d")


def main(dni):
    sub, b = zapytaj("/v1/user/subscription")
    if not sub:
        blad(f"Nie udało się odczytać abonamentu ElevenLabs: {b}")
    uzyte, limit = sub.get("character_count") or 0, sub.get("character_limit") or 0
    odn = sub.get("next_character_count_reset_unix")
    dane = {"abonament": sub.get("tier"), "uzyte": uzyte, "limit": limit, "zostalo": max(0, limit - uzyte),
            "odnowienie": datetime.fromtimestamp(odn).strftime("%Y-%m-%d %H:%M") if odn else None}
    teraz = int(time.time() * 1000)
    start = teraz - dni * 86400 * 1000
    uwagi = []
    dzienne = None
    for rodzaj in ("product_type", "model", "none"):
        st, b = zapytaj("/v1/usage/character-stats", {"start_unix": start, "end_unix": teraz, "breakdown_type": rodzaj, "aggregation_interval": "day"})
        if st and st.get("time"):
            dzienne = {"podzial": rodzaj, "dni": []}
            for i, t in enumerate(st["time"]):
                pozycje = {NAZWY.get(k, k): round(v[i]) for k, v in (st.get("usage") or {}).items() if i < len(v) and v[i]}
                if pozycje:
                    dzienne["dni"].append({"dzien": dzien(t), "razem": sum(pozycje.values()) if len(pozycje) > 1 or "razem" not in pozycje else pozycje["razem"], "na_co": pozycje})
            sumy = {}
            for d in dzienne["dni"]:
                for k, v in d["na_co"].items():
                    sumy[k] = sumy.get(k, 0) + v
            dzienne["suma_okresu"] = dict(sorted(sumy.items(), key=lambda x: -x[1]))
            break
        if b:
            uwagi.append(f"statystyki ({rodzaj}): {b}")
    if dzienne:
        dane["dzienne"] = dzienne
    hist, b = zapytaj("/v1/history", {"page_size": 100})
    if hist:
        lista = []
        for h in hist.get("history", []):
            if (h.get("date_unix") or 0) * 1000 < start:
                continue
            zn = abs((h.get("character_count_change_to") or 0) - (h.get("character_count_change_from") or 0))
            lista.append({"kiedy": datetime.fromtimestamp(h.get("date_unix") or 0).strftime("%Y-%m-%d %H:%M"), "kredyty": zn,
                          "glos": h.get("voice_name"), "zrodlo": h.get("source"), "tekst": (h.get("text") or "")[:70]})
        dane["lektor_ostatnie"] = lista[:60]
        dane["lektor_razem"] = sum(x["kredyty"] for x in lista)
    elif b:
        uwagi.append(f"historia lektora: {b}")
    if uwagi:
        dane["uwagi"] = uwagi
    wynik(**dane)


if __name__ == "__main__":
    a = argparse.ArgumentParser(description="Zużycie kredytów ElevenLabs")
    a.add_argument("--dni", type=int, default=14)
    main(a.parse_args().dni)
