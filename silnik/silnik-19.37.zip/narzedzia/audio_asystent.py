"""Asystent audio (jak „AI Audio Assistant” w DaVinci Resolve, plus to, co robi się ręcznie w Audition):
rozpoznaje ścieżki (mowa, muzyka, efekty, tło), czyści i wyrównuje mowę, ścisza muzykę pod mową i robi
zmasterowany miks w wybranym standardzie (YouTube, podcast, TV, Netflix).

  python narzedzia/audio_asystent.py analizuj --xml sekwencja.xml --folder wyniki/<...>
      -> ścieżki A1..An: rodzaj (dialog / muzyka / efekty / tlo), pewność, głośność, a dla mowy diagnoza:
         szum tła, pogłos, buczenie 50/60 Hz, przestery, syczenie i propozycje ustawień („auto”)
  python narzedzia/audio_asystent.py miks --xml sekwencja.xml --folder wyniki/<...> --uklad uklad.json
      -> <folder>/miks_ai_<n>.wav (48 kHz, 24 bit, stereo) + szyny miks_ai_<n>_mowa|muzyka|efekty|tlo.wav
         + asystent_raport.txt (co zostało zrobione z każdą ścieżką). Oryginały panel tylko wycisza.

uklad.json:
  {"standard": "youtube|podcast|ebu|atsc|netflix" (albo "cel_lufs": -14),
   "duck_db": 10, "miejsce_dla_mowy": true, "klej": true,
   "mowa": {"odszumianie": "auto|wyl|lekko|srednio|mocno", "poglos": ..., "buczenie": ..., "przester": ...,
            "deesser": ..., "bramka": ..., "barwa": ..., "wyrownanie": ..., "kompresja": ..., "ai_izolacja": false},
   "sciezki": [{"nr": 1, "typ": "dialog|muzyka|efekty|tlo|pomin", "korekta_db": 0}, ...]}

Dźwięk: panel eksportuje z Premiere każdą ścieżkę osobno (--z-premiere), więc asystent pracuje dokładnie na tym, co słychać na
osi (wybór kanałów, Fill Left, głośności, efekty); z pliku XML bierze tylko położenie klipów. Bez tego czyta pliki źródłowe.

Wszystko liczy się na tym komputerze (ffmpeg, numpy; odszumianie siecią neuronową RNNoise z narzedzia/audio_modele).
Jedyny wyjątek: „ai_izolacja” wysyła mowę do ElevenLabs Voice Isolator (zużywa kredyty ElevenLabs).
Każdy krok zachowuje długość i położenie dźwięku w czasie (także opóźnienia filtrów są mierzone i cofane).
"""
import argparse
import re
import json
import shutil
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, postep, wynik  # noqa: E402
import ciecie  # noqa: E402
import audio_dsp as A  # noqa: E402

SR = A.SR
PODPOWIEDZI = {
    "muzyka": ("music", "muzyka", "song", "track", "beat", "epidemic", "artlist", "envato", "bgm", "podklad", "podkład", "instrumental"),
    "efekty": ("sfx", "whoosh", "swoosh", "hit", "impact", "riser", "efekt", "fx", "click", "klik", "boom", "transition", "przejscie"),
    "tlo": ("amb", "atmo", "room tone", "roomtone", "tlo", "tło", "otoczenie", "wind", "wiatr", "ambience", "background noise", "pokoj", "pokój"),
    "dialog": ("mic", "mikrofon", "voice", "lektor", "vo_", "wywiad", "rozmowa", "zoom", "rode", "lav", "dialog", "host", "gosc", "gość"),
}
# poziomy szyn przed masteringiem (LUFS); muzyka bez mowy 8 dB pod mową, pod mową jeszcze niżej (ducking)
POZIOM = {"dialog": -20.0, "muzyka": -27.0, "efekty": -26.0, "tlo": -40.0}
STANDARDY = {
    "youtube": {"nazwa": "YouTube, Instagram, TikTok", "lufs": -14.0, "tp": -1.0},
    "podcast": {"nazwa": "Podcast (Spotify, Apple)", "lufs": -16.0, "tp": -1.0},
    "ebu": {"nazwa": "Telewizja w Europie (EBU R128)", "lufs": -23.0, "tp": -1.0},
    "atsc": {"nazwa": "Telewizja w USA (ATSC A/85)", "lufs": -24.0, "tp": -2.0},
    "netflix": {"nazwa": "Netflix (głośność mowy)", "lufs": -27.0, "tp": -2.0, "mowa": True},
}
KROKI_MOWY = ("przester", "buczenie", "odszumianie", "poglos", "barwa", "deesser", "wyrownanie", "kompresja", "bramka")
NAZWY_POZIOMOW = {0: "wył.", 1: "lekko", 2: "średnio", 3: "mocno"}


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


def numery_sciezek(seq):
    """Ścieżki audio tak, jak są w Premiere: (numer, nazwy klipów). Ścieżka stereo to w pliku XML dwie ścieżki
    (po jednej na kanał), tu liczy się jako jedna."""
    audio = seq.find("media/audio")
    if audio is None:
        return []
    mapa = ciecie.mapa_sciezek_audio(seq)
    po = {}
    for i, tr in enumerate(audio.findall("track"), 1):
        kl = [c for c in tr.findall("clipitem") if (c.findtext("enabled") or "TRUE").upper() != "FALSE"]
        if kl and (tr.findtext("enabled") or "TRUE").upper() != "FALSE":
            nazwy = po.setdefault(mapa.get(i, i), [])
            for c in kl[:8]:
                n = c.findtext("name") or ""
                if n not in nazwy:
                    nazwy.append(n)
    return [(nr, " ".join(po[nr][:8])) for nr in sorted(po)]


# ---------- składanie ścieżki z fragmentów plików ----------
def klastry(segmenty):
    """Grupuje fragmenty po pliku (i kanale) w ciągłe obszary pliku, żeby każdy obszar czytać i obrabiać raz.
    -> lista {plik, kanal, od, do, segmenty:[(src, tl, d)]}"""
    po_pliku = {}
    for p, src, tl, d, kan in segmenty:
        if d <= 0.001 or not Path(p).exists():
            continue
        po_pliku.setdefault((p, kan), []).append((src, tl, d))
    wyn = []
    for (p, kan), lista in po_pliku.items():
        lista.sort()
        biez = None
        for src, tl, d in lista:
            if biez and src - biez["do"] < 20:
                biez["do"] = max(biez["do"], src + d)
                biez["segmenty"].append((src, tl, d))
            else:
                biez = {"plik": p, "kanal": kan, "od": src, "do": src + d, "segmenty": [(src, tl, d)]}
                wyn.append(biez)
    for k in wyn:
        k["od_pad"] = max(0.0, k["od"] - 1.0)
        k["dl_pad"] = (k["do"] + 1.0) - k["od_pad"]
    return wyn


def klastry_z_osi(segmenty, wav):
    """Jak klastry(), ale dźwięk pochodzi z pliku, który wyeksportował Premiere dla całej ścieżki (czas pliku = czas osi):
    z XML bierzemy tylko to, gdzie leżą klipy i z jakiego nagrania są (każde nagranie dostaje osobną diagnozę i obróbkę),
    a brzmienie (kanały, głośność, efekty) jest dokładnie takie jak na osi."""
    po = {}
    for p, src, tl, d, kan in segmenty:
        if d > 0.001:
            po.setdefault((p, kan), []).append((tl, tl, d))
    wyn = []
    for (p, kan), lista in po.items():
        lista.sort()
        biez = None
        for src, tl, d in lista:
            if biez and src - biez["do"] < 20:
                biez["do"] = max(biez["do"], src + d)
                biez["segmenty"].append((src, tl, d))
            else:
                biez = {"plik": wav, "kanal": None, "zrodlo": p, "od": src, "do": src + d, "segmenty": [(src, tl, d)]}
                wyn.append(biez)
    for k in wyn:
        k["od_pad"] = max(0.0, k["od"] - 1.0)
        k["dl_pad"] = (k["do"] + 1.0) - k["od_pad"]
    return wyn


def nazwa_k(k):
    """Nazwa nagrania do raportu: oryginalny plik klipu (także gdy dźwięk jest z eksportu Premiere)."""
    return Path(k.get("zrodlo") or k["plik"]).name


def wczytaj_z_osi(plik):
    """{numer ścieżki A: plik WAV wyeksportowany przez Premiere}."""
    if not plik or not sciezka(plik).exists():
        return {}
    d = json.loads(sciezka(plik).read_text(encoding="utf-8"))
    return {int(k): v for k, v in d.items() if v and Path(v).exists()}


def wczytaj_klaster(k, tmp, ch):
    raw = tmp.nowy(Path(k["plik"]).stem)
    A.z_pliku(k["plik"], raw, ch=ch, ss=k["od_pad"], t=k["dl_pad"], kanal=k["kanal"] if k["kanal"] and ciecie.kanaly(k["plik"]) > 1 else None)
    return raw


def zloz_sciezke(klastry_raw, dl, ch, cel):
    """Kładzie fragmenty z (obrobionych) klastrów na osi czasu; 2 ms wyciszenia na krawędziach cięć (bez trzasków)."""
    n = int(round(dl * SR))
    y = A.nowy_raw(cel, n, ch)
    fade = int(0.002 * SR)
    for k, raw in klastry_raw:
        x = A.czytaj(raw, ch)
        for src, tl, d in k["segmenty"]:
            i0 = int(round((src - k["od_pad"]) * SR))
            t0 = int(round(tl * SR))
            m = min(int(round(d * SR)), len(x) - i0, n - t0)
            if m <= 0 or i0 < 0:
                continue
            kaw = np.array(x[i0:i0 + m], dtype=np.float32)
            if m > 4 * fade:
                r = np.linspace(0, 1, fade, dtype=np.float32)
                if ch > 1:
                    r = r[:, None]
                kaw[:fade] *= r
                kaw[-fade:] *= r[::-1]
            y[t0:t0 + m] += kaw
    y.flush()
    del y
    return cel


def surowa_sciezka(seq, defs, nr, dl, tmp, ch, diagnozy=None, z_osi=None):
    """Ścieżka A<nr> złożona na osi czasu (surowe float32). diagnozy: lista, do której trafia diagnoza każdego
    nagrania (pliku) z tej ścieżki osobno: mikrofony i pokoje różnią się, więc nie mierzymy ich razem."""
    seg = ciecie.scal(ciecie.zlacz_kanaly(ciecie.segmenty_audio(seq, defs, sciezki={nr})))
    ks = klastry_z_osi(seg, z_osi[nr]) if z_osi and nr in z_osi else klastry(seg)
    if not ks:
        return None, []
    pary = [(k, wczytaj_klaster(k, tmp, ch)) for k in ks]
    if diagnozy is not None:
        for k, r in pary:
            d = A.diagnoza(A.czytaj(r, ch) if ch == 1 else A.mono_z(np.array(A.czytaj(r, ch))))
            d.pop("przestery_miejsca", None)
            d.pop("barwa", None)
            diagnozy.append({"plik": nazwa_k(k), "dlugosc_s": round(k["do"] - k["od"], 1), "diagnoza": d, "opis": opis_diagnozy(d)})
    cel = tmp.nowy(f"A{nr}")
    zloz_sciezke(pary, dl, ch, cel)
    for _, r in pary:
        A.usun(r)
    return cel, ks


# ---------- rozpoznanie rodzaju ścieżki ----------
def cechy(x, dl):
    """Cechy ścieżki do rozpoznania rodzaju: pokrycie (ile czasu coś gra), liczba odcinków, a z fragmentu do 60 s:
    zmienność barwy (mowa ciągle skacze między samogłoskami a „s”, „sz”), udział basu poniżej 150 Hz (muzyka, szum)
    i krótkie przerwy między słowami („dołki” głośności)."""
    env = A.ramki_db(x, hop=0.05, okno=0.05)
    akt = env > -45
    pokrycie = float(akt.sum()) / max(1, int(dl / 0.05))
    zmiany = np.diff(akt.astype(int))
    odcinki = int((zmiany == 1).sum() + (1 if len(akt) and akt[0] else 0))
    c = {"pokrycie": pokrycie, "odcinki": odcinki, "zmiennosc": 0.0, "bas": 0.0, "dolki": 0.0}
    if akt.sum() < 40:
        return c
    i0 = int(np.argmax(akt)) * int(A.SR * 0.05)
    fr = np.array(x[i0:i0 + A.SR * 60], dtype=np.float32)
    h = 960  # 20 ms
    n = len(fr) // h
    if n < 50:
        return c
    db = A.ramki_db(fr, hop=0.02, okno=0.02)[:n]
    p95 = np.percentile(db, 95)
    sel = db > p95 - 40
    S = np.abs(np.fft.rfft(fr[:n * h].reshape(n, h) * np.hanning(h).astype(np.float32), axis=1))
    f = np.fft.rfftfreq(h, 1 / A.SR)
    en = S.sum(axis=1) + 1e-9
    cen = (S * f).sum(axis=1) / en
    if sel.sum() > 20:
        c["zmiennosc"] = float(np.std(cen[sel]) / (np.mean(cen[sel]) + 1e-9))
        c["bas"] = float((S[sel][:, f < 150] ** 2).sum() / ((S[sel] ** 2).sum() + 1e-12))
        c["dolki"] = float(np.mean(db[sel] < p95 - 20))
    return c


def ma_obraz(seq, defs, nr):
    """Czy klipy ścieżki A<nr> pochodzą z plików wideo (kamera, nagranie ekranu) albo zagnieżdżonych sekwencji."""
    mapa = ciecie.mapa_sciezek_audio(seq)
    audio = seq.find("media/audio")
    for i, tr in enumerate(audio.findall("track") if audio is not None else [], 1):
        if mapa.get(i, i) != nr:
            continue
        for cl in tr.findall("clipitem"):
            if cl.find("sequence") is not None or cl.find("multiclip") is not None:
                return True
            fe = cl.find("file")
            if fe is not None:
                d = defs.get(("file", fe.get("id")), fe)
                if d.find("media/video") is not None:
                    return True
    return False


def zgadnij(nazwy, c, dl, lufs, wideo=False):
    """Rodzaj ścieżki: po nazwie pliku, po tym, czy to dźwięk z kamery, potem po cechach dźwięku."""
    n = nazwy.lower()
    # oczyszczona mowa (Enhance Speech z Premiere: „…-esv2-50p-bg-10p-music-10p.wav”, Voice Isolator, nasze _czysty.wav)
    # ma w nazwie „music” albo „bg” jako ustawienia, a to nadal mowa
    if re.search(r"esv\d|enhanc|_czysty|isolat|izolac", n):
        return "dialog", 0.85, "nazwa pliku (oczyszczona mowa)"
    for typ, slowa in PODPOWIEDZI.items():
        if any(s in n for s in slowa):
            return typ, 0.85, "nazwa pliku"
    pokrycie, odcinki = c["pokrycie"], c["odcinki"]
    if pokrycie < 0.2 and odcinki > 0 and pokrycie * dl / max(1, odcinki) < 4:
        return "efekty", 0.6, "krótkie, rzadkie dźwięki"
    mowa = c["zmiennosc"] >= 0.45 and c["bas"] < 0.35 and c["dolki"] >= 0.14
    if wideo:
        return "dialog", 0.8 if mowa else 0.65, "dźwięk z kamery" + (", rytm i barwa mowy" if mowa else "")
    if mowa:
        return "dialog", 0.8, "rytm i barwa mowy"
    if pokrycie > 0.3 and re.search(r"\.(mp3|m4a|aac|ogg|flac)\b", n):
        return "muzyka", 0.7, "plik muzyczny (mp3), gra długo"
    if pokrycie > 0.5 and c["dolki"] < 0.05 and (lufs is None or lufs < -34):
        return "tlo", 0.6, "równy, cichy szum"
    if pokrycie > 0.4:
        return "muzyka", 0.65, "gra równo i długo, barwa muzyki"
    return "dialog", 0.45, "niepewne"


def opis_diagnozy(d):
    """Krótko po polsku: co słychać w nagraniu mowy."""
    if not d or d.get("cisza"):
        return "prawie cisza"
    cz = []
    snr = d.get("snr_db") or 0
    cz.append("szum tła " + ("mały" if snr > 45 else "słyszalny" if snr > 32 else "mocny") + f" ({d['szum_db']:g} dB)")
    if d.get("poglos_s") and d["poglos_s"] >= 0.3:
        cz.append("pogłos ok. " + f"{d['poglos_s']:.1f}".replace(".", ",") + " s")
    if d.get("buczenie_hz"):
        cz.append(f"buczenie {d['buczenie_hz']:g} Hz")
    if d.get("przestery"):
        cz.append("przester w 1 miejscu" if d["przestery"] == 1 else f"przester w {d['przestery']} miejscach")
    if (d.get("rekomendacja") or {}).get("deesser", 0) >= 2:
        cz.append("syczące „s”")
    return ", ".join(cz)


def podpis_sciezki(seq, defs, nr):
    seg = ciecie.scal(ciecie.zlacz_kanaly(ciecie.segmenty_audio(seq, defs, sciezki={nr})))
    return tuple(sorted((p, kan, round(src, 2), round(tl, 2), round(d, 2)) for p, src, tl, d, kan in seg))


def zrodla_po_plikach(diag):
    """Jedna pozycja na plik (dłuższe nagranie bywa podzielone na kilka fragmentów osi): opis z najdłuższego fragmentu,
    propozycje ustawień = najmocniejsze potrzebne."""
    po = {}
    for z in diag:
        if z["diagnoza"].get("cisza"):
            continue
        p = po.setdefault(z["plik"], {"plik": z["plik"], "dlugosc_s": 0.0, "naj": z, "rek": {}})
        p["dlugosc_s"] += z["dlugosc_s"]
        if z["dlugosc_s"] > p["naj"]["dlugosc_s"]:
            p["naj"] = z
        for k, v in z["diagnoza"]["rekomendacja"].items():
            p["rek"][k] = max(p["rek"].get(k, 0), v)
    return [{"plik": p["plik"], "dlugosc_s": round(p["dlugosc_s"], 1), "opis": p["naj"]["opis"], "rekomendacja": p["rek"],
             "szum_db": p["naj"]["diagnoza"].get("szum_db"), "poglos_s": p["naj"]["diagnoza"].get("poglos_s")} for p in po.values()]


def analizuj(xml, folder, pomin=None, z_premiere=None):
    """pomin: numery ścieżek audio wyciszonych w Premiere (M): pokazane na liście jako „Pomiń”, bez słuchania."""
    folder = sciezka(folder)
    folder.mkdir(parents=True, exist_ok=True)
    tree, root, seq, defs, fps = ciecie.zaladuj(xml)
    dl = ciecie.liczba(seq, "duration") / fps
    lista = numery_sciezek(seq)
    if not lista:
        blad("W tej sekwencji nie ma klipów audio.")
    pomin = {int(x) for x in (pomin or [])}
    z_osi = wczytaj_z_osi(z_premiere)
    tmp = A.Folder()
    wyn, podpisy = [], {}
    try:
        for i, (nr, nazwy) in enumerate(lista, 1):
            if nr in pomin:
                wyn.append({"nr": nr, "kod": f"A{nr}", "nazwa": nazwy[:60], "typ": "pomin", "pewnosc": 1, "wyciszona": True,
                            "powod": "wyciszona w Premiere (M), pomijam"})
                continue
            pp = podpis_sciezki(seq, defs, nr)
            if pp and pp in podpisy:
                wyn.append({"nr": nr, "kod": f"A{nr}", "nazwa": nazwy[:60], "typ": "pomin", "pewnosc": 1, "duplikat": podpisy[pp],
                            "powod": f"ten sam dźwięk co {podpisy[pp]} (ten sam plik i kanał), liczony raz"})
                continue
            podpisy[pp] = f"A{nr}"
            postep(f"Słucham ścieżki A{nr} ({i}/{len(lista)})")
            diag = []
            try:
                raw, ks = surowa_sciezka(seq, defs, nr, dl, tmp, 1, diagnozy=diag, z_osi=z_osi)
            except A.BladAudio as e:
                wyn.append({"nr": nr, "kod": f"A{nr}", "nazwa": nazwy[:60], "typ": "pomin", "pewnosc": 0, "powod": "nie da się odczytać dźwięku: " + str(e)[:120]})
                continue
            if raw is None:
                wyn.append({"nr": nr, "kod": f"A{nr}", "nazwa": nazwy[:60], "typ": "pomin", "pewnosc": 0, "powod": "brak plików na dysku"})
                continue
            x = A.czytaj(raw)
            lufs = A.glosnosc(raw)
            c = cechy(x, dl)
            pokrycie = c["pokrycie"]
            typ, pewnosc, powod = zgadnij(nazwy, c, dl, lufs, ma_obraz(seq, defs, nr))
            s = {"nr": nr, "kod": f"A{nr}", "nazwa": nazwy[:60], "typ": typ, "pewnosc": round(pewnosc, 2), "powod": powod,
                 "pokrycie_proc": round(pokrycie * 100), "lufs": lufs, "plikow": len({k["plik"] for k in ks})}
            dobre = zrodla_po_plikach(diag)
            if dobre:
                # propozycja „auto” dla ścieżki = najmocniejsza potrzebna obróbka spośród jej nagrań (przy miksie każde nagranie dostaje swoją)
                rek = {}
                for z in dobre:
                    for k_, v in z["rekomendacja"].items():
                        rek[k_] = max(rek.get(k_, 0), v)
                s["zrodla"] = dobre
                s["rekomendacja"] = rek
                s["diagnoza_opis"] = dobre[0]["opis"] if len(dobre) == 1 else " · ".join(f"{z['plik']}: {z['opis']}" for z in dobre[:4])
            wyn.append(s)
            del x
            A.usun(raw)
    finally:
        tmp.sprzataj()
    (folder / "asystent_analiza.json").write_text(json.dumps({"sciezki": wyn, "dlugosc_s": dl}, ensure_ascii=False, indent=1), encoding="utf-8")
    wynik(sciezki=wyn, dlugosc_s=round(dl, 2), standardy={k: v["nazwa"] for k, v in STANDARDY.items()})


# ---------- obróbka mowy ----------
def poziomy_mowy(ust, rek):
    """Ustawienia z panelu (auto/wyl/lekko/srednio/mocno) -> poziom 0–3 dla każdego kroku tego nagrania."""
    out = {}
    for k in KROKI_MOWY:
        v = str((ust or {}).get(k, "auto")).lower()
        out[k] = int(rek.get(k, 0)) if v == "auto" else A.POZIOMY.get(v, 0)
    return out


def oczysc(raw, d, poz, ai, tmp, raport, ai_minuty):
    """Etap 1 mowy: przester, buczenie, dół pasma, szum, pogłos (albo izolacja AI ElevenLabs)."""
    if poz["przester"] and d.get("przestery_miejsca"):
        n = A.napraw_przestery(raw, d["przestery_miejsca"])
        if n:
            raport.append("przester naprawiony w 1 miejscu" if n == 1 else f"przester naprawiony w {n} miejscach")
    filtry = ["highpass=f=75:p=2"]
    fb = A.filtr_buczenia(d.get("buczenie_hz"), d.get("buczenie_harm") or [], poz["buczenie"] or 0)
    if fb:
        filtry.append(fb)
        raport.append(f"buczenie {d['buczenie_hz']:g} Hz usunięte")
    y = tmp.nowy("hp")
    A.filtruj(raw, y, ",".join(filtry), opis="filtr dołu i buczenia")
    A.podmien(y, raw)
    if ai:
        import dzwiek
        wej = tmp.nowy("ai_we").with_suffix(".mp3")
        A.ffmpeg([*A.surowe_we(1), "-i", raw, "-c:a", "libmp3lame", "-b:a", "192k", wej], "plik dla ElevenLabs")
        wyj = tmp.nowy("ai_wy").with_suffix(".audio")
        n = A.probki(raw, 1)
        dzwiek.izolacja_elevenlabs(wej, wyj)
        y = tmp.nowy("ai")
        A.z_pliku(wyj, y)
        A.dopasuj(y, n, 1)
        lag = A.opoznienie(A.czytaj(raw), A.czytaj(y))
        A.przesun(y, lag)
        A.podmien(y, raw)
        ai_minuty[0] += n / SR / 60
        raport.append("izolacja głosu AI (ElevenLabs): szum i pogłos usunięte")
        return
    if poz["odszumianie"]:
        f, cwd = A.filtr_odszumiania(poz["odszumianie"], d.get("szum_db", -60))
        y = tmp.nowy("dn")
        A.filtruj(raw, y, f, cwd=cwd, opis="odszumianie")
        A.podmien(y, raw)
        raport.append("odszumianie " + NAZWY_POZIOMOW[poz["odszumianie"]] + (" (sieć neuronowa RNNoise)" if "arnndn" in f else ""))
    if poz["poglos"]:
        p = poz["poglos"]
        A.wpe(raw, {1: 0.5, 2: 0.8, 3: 1.0}[p], p)
        rt = max(0.4, min(2.0, (d.get("poglos_s") or 0.4) * 1.4))
        beta, zak = {1: (0.7, 8), 2: (1.0, 14), 3: (1.3, 20)}[p]
        A.poglos_widmowy(raw, rt, beta, zak)
        raport.append("pogłos zmniejszony " + NAZWY_POZIOMOW[p])


def dopracuj(raw, barwa_wl, barwa_cel, poz, tmp, raport):
    """Etap 2 mowy (każde nagranie osobno): barwa (dopasowanie mikrofonów + korekcja) i de-esser."""
    filtry = []
    if poz["barwa"] and barwa_wl is not None:
        s = {1: 0.5, 2: 0.8, 3: 1.0}[poz["barwa"]]
        krzywa = np.zeros(len(A.TERCJE))
        if barwa_cel is not None:
            krzywa += A.eq_dopasowania(barwa_wl, barwa_cel, s)
        krzywa += A.eq_mowy(np.asarray(barwa_wl) + krzywa, poz["barwa"])
        krzywa = np.clip(krzywa, -8, 8)
        f = A.filtr_eq(krzywa)
        if f:
            filtry.append(f)
            raport.append("barwa wyrównana (" + ", ".join(opis_eq(krzywa)) + ")")
    fd = A.filtr_deessera(poz["deesser"])
    if fd:
        filtry.append(fd)
        raport.append("de-esser " + NAZWY_POZIOMOW[poz["deesser"]])
    if filtry:
        y = tmp.nowy("eq")
        A.filtruj(raw, y, ",".join(filtry), opis="barwa mowy")
        A.podmien(y, raw)


def dynamika(raw, poz, przebicia, tmp, raport):
    """Etap 3 mowy (cała ścieżka): wyrównanie fraz, kompresja, bramka; przebicia innych mikrofonów nie są podbijane."""
    if poz["wyrownanie"]:
        w = A.wyrownaj(raw, poz["wyrownanie"], POZIOM["dialog"], przebicia)
        if w:
            raport.append(f"wyrównanie fraz od {pl(w['min_db'])} do {pl(w['max_db'])} dB")
    fk = A.filtr_kompresji(poz["kompresja"], A.poziom_glosu(raw))
    if fk:
        y = tmp.nowy("komp")
        A.filtruj(raw, y, fk, opis="kompresja mowy", kompensuj=False)
        A.podmien(y, raw)
        raport.append("kompresja " + NAZWY_POZIOMOW[poz["kompresja"]])
    if poz["bramka"]:
        b = A.bramka(raw, poz["bramka"], przebicia)
        if b:
            raport.append(f"bramka: tło między słowami ciszej o {b['zasieg_db']} dB" +
                          (f", przebicia z innych mikrofonów przyciszone ({b['przebicia_proc']}% czasu)" if b.get("przebicia_proc") else ""))


def pl(v, znak=True):
    """Liczba po polsku (przecinek), z plusem dla dodatnich."""
    s = f"{v:+.1f}" if znak else f"{v:.1f}"
    s = s.replace(".0", "") if s.endswith(".0") else s
    return s.replace(".", ",")


def opis_eq(k):
    cz = []
    for nazwa, a, b in (("dół", 100, 250), ("dudnienie", 250, 500), ("środek", 800, 2000), ("czytelność", 2000, 5000), ("góra", 6300, 12500)):
        sel = (A.TERCJE >= a) & (A.TERCJE <= b)
        v = float(np.mean(k[sel]))
        if abs(v) >= 1:
            cz.append(f"{nazwa} {v:+.0f} dB")
    return cz or ["drobne poprawki"]


def szum_w_przerwach(raw):
    """Odstęp głosu od tła w dB (głośne sylaby minus cisza między słowami)."""
    e = A.ramki_db(A.czytaj(raw))
    e = e[e > -115]
    return float(np.percentile(e, 95) - np.percentile(e, 10)) if len(e) > 50 else None


def obrob_mowe(seq, defs, sciezki_mowy, dl, ust, tmp, raport_ogolny, ai_minuty, z_osi=None):
    """Mowa: czyszczenie i barwa dla każdego nagrania (plik + kanał) osobno, bo każdy mikrofon ma inny szum,
    pokój i barwę; potem wyrównanie, kompresja i bramka na całej ścieżce (z wiedzą o przebiciach innych mikrofonów)."""
    ai = bool((ust or {}).get("ai_izolacja"))
    zrodla = []  # [nr, klaster, raw, diagnoza, poziomy, raport, szum_przed]
    podpisy, sciezki = {}, []
    for s in sciezki_mowy:
        nr = int(s["nr"])
        seg = ciecie.scal(ciecie.zlacz_kanaly(ciecie.segmenty_audio(seq, defs, sciezki={nr})))
        podpis = tuple(sorted((p, kan, round(src, 2), round(tl, 2), round(d, 2)) for p, src, tl, d, kan in seg))
        if podpis in podpisy:
            raport_ogolny.append(f"A{nr} to ta sama mowa co A{podpisy[podpis]} (ten sam plik i kanał): policzona raz")
            continue
        podpisy[podpis] = nr
        sciezki.append(s)
        for k in (klastry_z_osi(seg, z_osi[nr]) if z_osi and nr in z_osi else klastry(seg)):
            postep(f"Mowa A{nr}: {nazwa_k(k)}")
            raw = wczytaj_klaster(k, tmp, 1)
            d = A.diagnoza(A.czytaj(raw))
            if d.get("cisza"):
                zrodla.append([nr, k, raw, d, None, [], None])
                continue
            poz = poziomy_mowy(ust, d["rekomendacja"])
            rap = []
            przed = szum_w_przerwach(raw)
            oczysc(raw, d, poz, ai, tmp, rap, ai_minuty)
            po = szum_w_przerwach(raw)
            if przed is not None and po is not None and po - przed >= 3:
                rap.insert(0, f"tło ciszej o {po - przed:.0f} dB względem głosu")
            zrodla.append([nr, k, raw, d, poz, rap, przed])
    # wspólna barwa: średnie widmo wszystkich oczyszczonych nagrań (ważone długością)
    barwy, wagi = {}, []
    for i, z in enumerate(zrodla):
        if z[4] is None:
            continue
        x = A.czytaj(z[2])
        barwy[i] = A.barwa_mowy(A.fragment_mowy(x, A.ramki_db(x)))
        del x  # plik będzie zaraz podmieniany: Windows nie pozwala, gdy jest otwarty
        wagi.append((barwy[i], z[1]["do"] - z[1]["od"]))
    cel = None
    if len(wagi) > 1:
        moc = sum(10 ** (b / 10) * w for b, w in wagi) / sum(w for _, w in wagi)
        cel = 10 * np.log10(moc + 1e-20)
    for i, z in enumerate(zrodla):
        if z[4] is None:
            continue
        postep(f"Mowa A{z[0]}: barwa ({nazwa_k(z[1])})")
        dopracuj(z[2], barwy[i], cel, z[4], tmp, z[5])
    # ścieżki mowy złożone z obrobionych nagrań
    gotowe = []
    for s in sciezki:
        nr = int(s["nr"])
        nasze = [z for z in zrodla if z[0] == nr]
        if not nasze:
            continue
        cel_raw = tmp.nowy(f"mowa_A{nr}")
        zloz_sciezke([(z[1], z[2]) for z in nasze], dl, 1, cel_raw)
        poz = {k: max((z[4] or {}).get(k, 0) for z in nasze) for k in ("wyrownanie", "kompresja", "bramka")}
        gotowe.append((s, cel_raw, poz, nasze))
    for z in zrodla:
        A.usun(z[2])
    maski = A.maski_przebic([g[1] for g in gotowe])
    wyniki = []
    for (s, raw, poz, nasze), maska in zip(gotowe, maski):
        nr = int(s["nr"])
        postep(f"Mowa A{nr}: wyrównanie, kompresja, bramka")
        rap_sc = []
        dynamika(raw, poz, maska, tmp, rap_sc)
        A.ustaw_glosnosc(raw, POZIOM["dialog"], 1, float(s.get("korekta_db", 0)))
        for z in nasze:
            rap = list(z[5])
            if z[4] is None:
                raport_ogolny.append(f"A{nr} mowa, {nazwa_k(z[1])}: prawie cisza, bez obróbki")
                continue
            raport_ogolny.append(f"A{nr} mowa, {nazwa_k(z[1])}: " + ("; ".join(rap) or "czyste nagranie"))
        raport_ogolny.append(f"A{nr} mowa, cała ścieżka: " + ("; ".join(rap_sc) or "bez zmian"))
        wyniki.append(raw)
    return wyniki


# ---------- miks ----------
def suma(lista, n, ch, cel, mono_na_stereo=False):
    y = A.nowy_raw(cel, n, ch)
    krok = SR * 30
    for raw in lista:
        x = A.czytaj(raw, 1 if mono_na_stereo else ch)
        for a in range(0, n, krok):
            b = min(n, a + krok, len(x))
            if b <= a:
                break
            blok = np.array(x[a:b], dtype=np.float32)
            y[a:b] += blok[:, None] if mono_na_stereo else blok
    y.flush()
    del y
    return cel


def mnoz(raw, ch, zysk_db):
    x = A.czytaj(raw, ch, "r+")
    k = np.float32(10 ** (zysk_db / 20))
    for a in range(0, len(x), SR * 30):
        x[a:a + SR * 30] *= k
    x.flush()


def glosnosc_mowy(raw_master, maska, hop=0.01):
    """Głośność całości liczona tylko tam, gdzie ktoś mówi (jak „dialog-gated” w specyfikacji Netflix)."""
    x = A.czytaj(raw_master, 2)
    h = int(SR * hop)
    sel = np.flatnonzero(maska > 0.5)
    if len(sel) < 100:
        return A.glosnosc(raw_master, 2)
    tmp = Path(str(raw_master) + ".mowa.f32")
    with open(tmp, "wb") as f:
        idx = np.flatnonzero(np.diff(np.r_[0, (maska > 0.5).astype(np.int8), 0]))
        for a, b in zip(idx[::2], idx[1::2]):
            np.array(x[a * h:b * h], dtype=np.float32).tofile(f)
    v = A.glosnosc(tmp, 2)
    A.usun(tmp)
    return v


def miks(xml, folder, uklad, z_premiere=None):
    t0 = time.time()
    folder = sciezka(folder)
    folder.mkdir(parents=True, exist_ok=True)
    u = json.loads(sciezka(uklad).read_text(encoding="utf-8")) if isinstance(uklad, (str, Path)) else uklad
    std = STANDARDY.get(u.get("standard")) or {"nazwa": f"{u.get('cel_lufs', -14):g} LUFS", "lufs": float(u.get("cel_lufs", -14)), "tp": -1.0}
    duck = max(0.0, float(u.get("duck_db", 10)))
    ust_mowy = u.get("mowa") or {}
    tree, root, seq, defs, fps = ciecie.zaladuj(xml)
    dl = ciecie.liczba(seq, "duration") / fps
    n = int(round(dl * SR))
    sc = [s for s in u.get("sciezki", []) if s.get("typ") in POZIOM]
    if not sc:
        blad("Żadna ścieżka nie została wybrana do miksu.")
    z_osi = wczytaj_z_osi(z_premiere)
    tmp = A.Folder()
    raport, ai_minuty = [], [0.0]
    brak = [int(s["nr"]) for s in sc if int(s["nr"]) not in z_osi]
    if z_osi and brak:
        raport.append("Dźwięk z plików (Premiere nie wyeksportował): " + ", ".join(f"A{n}" for n in brak) +
                      "; tam ustawienia kanałów i efekty z osi mogą nie być uwzględnione")
    elif not z_osi:
        raport.append("Uwaga: dźwięk czytany z plików, nie z Premiere: ustawienia kanałów, głośności i efekty z osi mogą nie być uwzględnione")
    try:
        szyny = {}
        mowa = [s for s in sc if s["typ"] == "dialog"]
        if mowa:
            sciezki = obrob_mowe(seq, defs, mowa, dl, ust_mowy, tmp, raport, ai_minuty, z_osi)
            if sciezki:
                szyny["dialog"] = suma(sciezki, n, 1, tmp.nowy("szyna_mowa"))
                for r in sciezki:
                    A.usun(r)
        maska = A.aktywnosc_mowy(szyny["dialog"]) if "dialog" in szyny else None
        for typ in ("muzyka", "efekty", "tlo"):
            lista = []
            for s in [x for x in sc if x["typ"] == typ]:
                nr = int(s["nr"])
                postep(f"{ {'muzyka': 'Muzyka', 'efekty': 'Efekty', 'tlo': 'Tło'}[typ] } A{nr}")
                raw, ks = surowa_sciezka(seq, defs, nr, dl, tmp, 2, z_osi=z_osi)
                if raw is None:
                    continue
                f = {"muzyka": "highpass=f=30", "efekty": "highpass=f=35,acompressor=threshold=-14dB:ratio=4:attack=1:release=120:makeup=1",
                     "tlo": "highpass=f=40"}[typ]
                y = tmp.nowy(f"{typ}_A{nr}")
                A.filtruj(raw, y, f, ch=2, opis=typ, kompensuj=False)
                A.usun(raw)
                # dźwięk wzięty z osi gra tak, jak go ustawiłeś: cichą muzykę i tło podgłaśniamy najwyżej o 3 dB
                # (głośniejsze ściszamy do poziomu pod mową); suwak „Głośniej / ciszej” dokłada swoje
                zysk = A.ustaw_glosnosc(y, POZIOM[typ], 2, float(s.get("korekta_db", 0)),
                                        max_wzmocnienie=3.0 if z_osi and typ in ("muzyka", "tlo") else None)
                if zysk is None:
                    continue
                lista.append(y)
                opis = f"A{nr} {'muzyka' if typ == 'muzyka' else 'efekty' if typ == 'efekty' else 'tło'}: głośność {zysk:+.0f} dB".replace("+0 dB", "bez zmian")
                if typ == "efekty":
                    opis += ", najgłośniejsze uderzenia przytrzymane"
                raport.append(opis)
            if not lista:
                continue
            szyna = suma(lista, n, 2, tmp.nowy(f"szyna_{typ}"))
            for r in lista:
                A.usun(r)
            if maska is not None and typ in ("muzyka", "tlo") and maska.any():
                dd = duck if typ == "muzyka" else min(duck, 4.0)
                if dd > 0:
                    rz = None
                    if typ == "muzyka" and u.get("miejsce_dla_mowy", True):
                        rz = tmp.nowy("rzezba")
                        A.filtruj(szyna, rz, "equalizer=f=2500:t=o:w=1.6:g=-4", ch=2, kompensuj=False)
                    A.wycisz_pod_mowa(szyna, maska, dd, ch=2, raw_rzezba=rz)
                    if rz:
                        A.usun(rz)
                    raport.append(("Muzyka ściszana" if typ == "muzyka" else "Tło ściszane") + f" pod mową o {dd:g} dB" +
                                  (", z miejscem na głos (pasmo mowy w muzyce ciszej, gdy ktoś mówi)" if typ == "muzyka" and u.get("miejsce_dla_mowy", True) else ""))
            szyny[typ] = szyna
        if not szyny:
            blad("Nie udało się odczytać dźwięku z wybranych ścieżek (brak plików na dysku?).")
        postep("Mastering")
        master = tmp.nowy("master")
        if "dialog" in szyny:
            suma([szyny["dialog"]], n, 2, master, mono_na_stereo=True)
        else:
            A.nowy_raw(master, n, 2).flush()
        m = A.czytaj(master, 2, "r+")
        for k in ("muzyka", "efekty", "tlo"):
            if k in szyny:
                x = A.czytaj(szyny[k], 2)
                for a in range(0, n, SR * 30):
                    m[a:a + SR * 30] += x[a:a + SR * 30]
                del x  # Windows nie pozwala usunąć pliku, który jest jeszcze otwarty
        m.flush()
        del m
        if u.get("klej", True):
            y = tmp.nowy("klej")
            A.filtruj(master, y, "acompressor=threshold=-18dB:ratio=1.6:attack=25:release=250:knee=6:makeup=1", ch=2, opis="kompresja całości", kompensuj=False)
            A.podmien(y, master)
        pomiar = (lambda r: glosnosc_mowy(r, maska)) if std.get("mowa") and maska is not None else (lambda r: A.glosnosc(r, 2))
        zm = pomiar(master) or std["lufs"]
        zysk = std["lufs"] - zm
        limit = 10 ** ((std["tp"] - 0.3) / 20)
        flt = f"aresample=192000,alimiter=limit={limit:.4f}:attack=2:release=60:level=false:asc=1,aresample=48000"
        przed_lim = tmp.nowy("przed_lim")
        wyj = tmp.nowy("wyj")
        for proba in range(2):
            shutil.copy(master, przed_lim)
            mnoz(przed_lim, 2, zysk)
            A.filtruj(przed_lim, wyj, flt, ch=2, opis="limiter")
            jest = pomiar(wyj)
            if jest is None or abs(jest - std["lufs"]) <= 0.4 or proba == 1:
                break
            zysk += std["lufs"] - jest
        nr = 1
        while (folder / f"miks_ai_{nr}.wav").exists():
            nr += 1
        cel = folder / f"miks_ai_{nr}.wav"
        A.do_wav(wyj, cel, 2)
        koncowe, tp = A.glosnosc(wyj, 2, tp=True)
        pliki_szyn = {}
        if u.get("szyny", True):
            for k, nazwa in (("dialog", "mowa"), ("muzyka", "muzyka"), ("efekty", "efekty"), ("tlo", "tlo")):
                if k in szyny:
                    ch = 1 if k == "dialog" else 2
                    mnoz(szyny[k], ch, zysk)
                    p = folder / f"miks_ai_{nr}_{nazwa}.wav"
                    A.do_wav(szyny[k], p, ch, ch_wy=2)
                    pliki_szyn[nazwa] = str(p)
        mowa_lufs = glosnosc_mowy(wyj, maska) if maska is not None else None
    except A.BladAudio as e:
        tmp.sprzataj()
        blad(str(e))
    finally:
        tmp.sprzataj()
    raport.append(f"Mastering: {std['nazwa']}, głośność {pl(koncowe, False) if koncowe is not None else '?'} LUFS" +
                  (f" (mowa {pl(mowa_lufs, False)} LUFS)" if mowa_lufs is not None and std.get("mowa") else "") +
                  f", szczyt {pl(tp, False) if tp is not None else '?'} dBTP (limit {pl(std['tp'], False)})" + (", kompresja całości" if u.get("klej", True) else ""))
    if ai_minuty[0]:
        raport.append(f"ElevenLabs Voice Isolator: {pl(ai_minuty[0], False)} min nagrań (kredyty ElevenLabs)")
    tekst = "\n".join(["Asystent audio: co zostało zrobione", ""] + [f"- {r}" for r in raport]) + "\n"
    (folder / "asystent_raport.txt").write_text(tekst, encoding="utf-8")
    wynik(plik=str(cel), lufs=koncowe, tp=tp, standard=std["nazwa"], cel_lufs=std["lufs"], szyny=pliki_szyn, raport=raport,
          czas_s=round(time.time() - t0), ai_minuty=round(ai_minuty[0], 1),
          dialog=len([s for s in sc if s["typ"] == "dialog"]), muzyka=len([s for s in sc if s["typ"] == "muzyka"]),
          efekty=len([s for s in sc if s["typ"] == "efekty"]), tlo=len([s for s in sc if s["typ"] == "tlo"]),
          sciezki=[int(s["nr"]) for s in sc])


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Asystent audio: czysta mowa, muzyka pod mową i zmasterowany miks")
    sub = p.add_subparsers(dest="tryb", required=True)
    a1 = sub.add_parser("analizuj"); a1.add_argument("--xml", required=True); a1.add_argument("--folder", required=True)
    a1.add_argument("--pomin", default="", help="numery ścieżek audio wyciszonych w Premiere, np. 5,6")
    a1.add_argument("--z-premiere", default=None, help="JSON {numer ścieżki: WAV wyeksportowany przez Premiere}: dźwięk dokładnie jak na osi")
    a2 = sub.add_parser("miks"); a2.add_argument("--xml", required=True); a2.add_argument("--folder", required=True); a2.add_argument("--uklad", required=True)
    a2.add_argument("--z-premiere", default=None)
    a = p.parse_args()
    if a.tryb == "analizuj":
        analizuj(a.xml, a.folder, [int(x) for x in a.pomin.replace("A", "").split(",") if x.strip().isdigit()], a.z_premiere)
    else:
        miks(a.xml, a.folder, a.uklad, a.z_premiere)
