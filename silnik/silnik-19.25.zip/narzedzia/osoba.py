"""Prowadzący do miniatur i grafik: przegląd zdjęć i wycinanie osoby z tła (bez Photoshopa).

  python narzedzia/osoba.py arkusz --folder materialy/<zadanie> [--wyjscie <folder zadania>/osoba]
      arkusz kontaktowy wszystkich zdjęć z numerami (JPG, PNG, WEBP, HEIC, RAW: NEF, CR2, CR3, ARW, RAF, DNG, ORF, RW2):
      obejrzyj go (Read) i wybierz zdjęcia z pasującą miną; wynik: arkusz_1.jpg, arkusz_2.jpg... i lista plików z numerami
  python narzedzia/osoba.py wytnij --plik materialy/<zadanie>/GPU_5930.NEF --wyjscie <folder zadania>/osoba/01.png [--model ...]
      osoba wycięta z tła jako PNG z przezroczystością, przycięty do sylwetki (do "osoba" w seria.json narzędzia grafika.py)
  python narzedzia/osoba.py wytnij --pliki '["a.NEF","b.jpg"]' --folder-wyjscia <folder zadania>/osoba   (kilka naraz)

Wycinanie robi lokalnie biblioteka rembg (za darmo, bez kredytów). Za pierwszym razem pobiera model (ok. 170 MB).
Wymaga: python -m pip install rembg onnxruntime rawpy (narzędzie doinstaluje je samo, gdy ich brak).
"""
import argparse
import importlib
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import blad, postep, wynik  # noqa: E402
from montaz import sciezka  # noqa: E402

RAW = {".nef", ".cr2", ".cr3", ".arw", ".raf", ".dng", ".orf", ".rw2", ".nrw", ".srw", ".pef"}
OBRAZY = {".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff", ".bmp", ".heic"} | RAW
PAKIETY = {"rembg": "rembg", "onnxruntime": "onnxruntime", "rawpy": "rawpy"}


def wymagaj(*nazwy):
    """Doinstalowuje brakujące biblioteki (raz), bo zadania w tle nie mogą same uruchamiać pip."""
    brak = []
    for n in nazwy:
        try:
            importlib.import_module(n)
        except ImportError:
            brak.append(PAKIETY.get(n, n))
    if not brak:
        return
    postep(f"Instaluję potrzebne biblioteki: {', '.join(brak)} (tylko za pierwszym razem)")
    r = subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", *brak], capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        blad(f"Nie udało się zainstalować {', '.join(brak)}: {r.stderr[-500:]}. Uruchom ręcznie: python -m pip install {' '.join(brak)}")
    importlib.invalidate_caches()


def wczytaj(plik, max_bok=2400, szybko=False):
    """Zdjęcie jako obraz RGB; RAW przez rawpy (szybko=True: wbudowany podgląd JPEG z aparatu, do arkusza)."""
    from PIL import Image, ImageOps
    p = sciezka(plik)
    if not p.exists():
        blad(f"Nie widzę pliku {p}")
    if p.suffix.lower() in RAW:
        wymagaj("rawpy")
        import io
        import rawpy
        with rawpy.imread(str(p)) as raw:
            img = None
            if szybko:
                try:
                    th = raw.extract_thumb()
                    if th.format == rawpy.ThumbFormat.JPEG:
                        img = ImageOps.exif_transpose(Image.open(io.BytesIO(th.data))).convert("RGB")
                except Exception:
                    img = None
            if img is None:
                rgb = raw.postprocess(use_camera_wb=True, no_auto_bright=False, output_bps=8, half_size=max_bok <= 2000)
                img = Image.fromarray(rgb)
    else:
        if p.suffix.lower() == ".heic":
            try:
                import pillow_heif
                pillow_heif.register_heif_opener()
            except ImportError:
                blad("Zdjęcia HEIC wymagają biblioteki pillow-heif: python -m pip install pillow-heif")
        img = ImageOps.exif_transpose(Image.open(p)).convert("RGB")
    img.thumbnail((max_bok, max_bok))
    return img


def lista_zdjec(folder):
    f = sciezka(folder)
    if not f.is_dir():
        blad(f"Nie ma folderu {f}")
    return sorted(x for x in f.rglob("*") if x.is_file() and x.suffix.lower() in OBRAZY and not x.name.startswith("."))


def arkusz(folder, wyjscie=None, na_arkusz=24):
    from PIL import Image, ImageDraw, ImageFont
    pliki = lista_zdjec(folder)
    if not pliki:
        blad(f"W {folder} nie ma zdjęć.")
    wyj = sciezka(wyjscie) if wyjscie else sciezka(folder) / "_arkusze"
    wyj.mkdir(parents=True, exist_ok=True)
    kol, mini = 6, 300
    try:
        font = ImageFont.truetype("arial.ttf", 22)
    except Exception:
        font = ImageFont.load_default()
    arkusze, numery = [], []
    for s in range(0, len(pliki), na_arkusz):
        cz = pliki[s:s + na_arkusz]
        rzedy = (len(cz) + kol - 1) // kol
        ark = Image.new("RGB", (kol * (mini + 8) + 8, rzedy * (mini + 8) + 8), (25, 25, 25))
        d = ImageDraw.Draw(ark)
        for i, p in enumerate(cz):
            nr = s + i + 1
            postep(f"Arkusz zdjęć: {nr}/{len(pliki)}", nr / len(pliki))
            try:
                im = wczytaj(p, 700, szybko=True)
            except SystemExit:
                raise
            except Exception:
                continue
            im.thumbnail((mini, mini))
            x, y = 8 + (i % kol) * (mini + 8), 8 + (i // kol) * (mini + 8)
            ark.paste(im, (x + (mini - im.width) // 2, y + (mini - im.height) // 2))
            d.rectangle([x, y, x + 46, y + 30], fill=(0, 0, 0))
            d.text((x + 6, y + 3), str(nr), fill=(255, 220, 0), font=font)
            numery.append({"nr": nr, "plik": str(p)})
        cel = wyj / f"arkusz_{len(arkusze) + 1}.jpg"
        ark.save(cel, quality=85)
        arkusze.append(str(cel))
    (wyj / "zdjecia.json").write_text(json.dumps(numery, ensure_ascii=False, indent=1), encoding="utf-8")
    wynik(arkusze=arkusze, zdjec=len(numery), lista=str(wyj / "zdjecia.json"),
          uwaga="Obejrzyj arkusze (Read) i wybierz numery zdjęć; potem osoba.py wytnij z plikami z listy.")


_SESJA = {}


def wytnij_jeden(plik, cel, model="isnet-general-use"):
    wymagaj("rembg", "onnxruntime")
    from rembg import new_session, remove
    img = wczytaj(plik, 2400)
    if model not in _SESJA:
        postep(f"Wczytuję model wycinania ({model}); za pierwszym razem pobiera się ok. 170 MB")
        try:
            _SESJA[model] = new_session(model)
        except Exception:
            model = "u2net_human_seg"
            _SESJA[model] = _SESJA.get(model) or new_session(model)
    out = remove(img, session=_SESJA[model], post_process_mask=True)
    box = out.getchannel("A").point(lambda v: 255 if v > 24 else 0).getbbox()
    if not box:
        blad(f"Nie znalazłem osoby na zdjęciu {Path(plik).name}")
    out = out.crop(box)
    cel = sciezka(cel)
    cel.parent.mkdir(parents=True, exist_ok=True)
    out.save(cel)
    return {"plik": str(cel), "zrodlo": str(plik), "szer": out.width, "wys": out.height, "model": model}


def wytnij(pliki, wyjscia, model):
    wyniki = []
    for i, (p, c) in enumerate(zip(pliki, wyjscia), 1):
        postep(f"Wycinam osobę {i}/{len(pliki)}: {Path(p).name}", (i - 1) / len(pliki))
        wyniki.append(wytnij_jeden(p, c, model))
    wynik(osoby=wyniki, uwaga='W seria.json przy grafice: "osoba": {"plik": "<png>", "strona": "prawo"} (lewo/prawo, opcjonalnie "wysokosc": 0.95).')


if __name__ == "__main__":
    a = argparse.ArgumentParser(description="Prowadzący: arkusz zdjęć i wycinanie osoby z tła")
    s = a.add_subparsers(dest="tryb", required=True)
    k = s.add_parser("arkusz"); k.add_argument("--folder", required=True); k.add_argument("--wyjscie")
    w = s.add_parser("wytnij"); w.add_argument("--plik"); w.add_argument("--wyjscie"); w.add_argument("--pliki"); w.add_argument("--folder-wyjscia")
    w.add_argument("--model", default="isnet-general-use", help="isnet-general-use (domyślny), u2net_human_seg (tylko ludzie), birefnet-portrait (najdokładniejszy, ok. 1 GB i dużo pamięci)")
    x = a.parse_args()
    if x.tryb == "arkusz":
        arkusz(x.folder, x.wyjscie)
    else:
        if x.pliki:
            lista = json.loads(x.pliki)
            fw = sciezka(x.folder_wyjscia or "osoba")
            wytnij(lista, [fw / f"{i:02d}_{Path(p).stem}.png" for i, p in enumerate(lista, 1)], x.model)
        elif x.plik and x.wyjscie:
            wytnij([x.plik], [x.wyjscie], x.model)
        else:
            blad("Podaj --plik i --wyjscie albo --pliki i --folder-wyjscia.")
