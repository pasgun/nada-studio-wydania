"""Grafiki w barwach marki: tło (stock / AI / Envato) + nagłówek + podtytuł + przycisk CTA + logo.

Jedna grafika:
  python narzedzia/grafika.py --tlo wyniki/X/tlo.jpg --wyjscie wyniki/X/grafika.png --format post-4x5 \
     --folder-klienta klienci/marka --naglowek "Czym jest *ETF*?" --podtytul "Koszyk setek firm w jednym zakupie" \
     --cta "Odbierz darmowe szkolenie" --kolory '{"primary":"#0B1F3A","accent":"#22C55E","text":"#FFFFFF","highlight":"#22C55E"}'

Seria (wiele grafik w kilku formatach naraz):
  python narzedzia/grafika.py seria --plan wyniki/X/seria.json

  seria.json:
  {
    "folder_klienta": "klienci/marka", "wyjscie": "wyniki/X/grafiki",
    "formaty": ["post-4x5", "story-9x16", "square"],
    "font": "Montserrat", "font_tekstu": "Inter",
    "kolory": {"primary": "#0B1F3A", "accent": "#22C55E", "text": "#FFFFFF", "highlight": "#22C55E"},
    "cta": "Odbierz darmowe szkolenie",                       (domyślne dla wszystkich)
    "grafiki": [
      {"nazwa": "czym-jest-etf", "tlo": "wyniki/X/tla/01.jpg", "naglowek": "Czym jest *ETF*?",
       "podtytul": "...", "cta": "...", "fokus_x": 0.5, "fokus_y": 0.4, "uklad": "auto"},   (fokus: punkt tła, który ma zostać w kadrze)
      {"nazwa": "miniatura", "tlo": "...", "naglowek": "...", "osoba": {"plik": "wyniki/X/osoba/01.png", "strona": "prawo",
       "wysokosc": 0.95, "odbij": false, "obrys": "#FFFFFF"}},   (prowadzący wycięty z tła przez narzedzia/osoba.py,
       osobna warstwa w PSD; przy "uklad": "auto" tekst staje po drugiej stronie)
      ...
    ]
  }
  Wynik: <wyjscie>/<nr>_<nazwa>_<format>.png, <wyjscie>/podglad_serii.jpg (wszystko na jednym arkuszu)
  oraz <wyjscie>/photoshop/seria.psd: jeden plik, rząd = grafika, kolumny = formaty, każda na osobnym artboardzie
  (01_nazwa_1080x1350, 01_nazwa_1080x1920...), warstwy (tło, przyciemnienie,
  nagłówek i podtytuł jako edytowalny tekst, przycisk, logo). Wymaga Node.js; "psd": false w planie wyłącza.
  Same pliki PSD jeszcze raz: python narzedzia/grafika.py psd --plan wyniki/X/seria.json

Słowa w *gwiazdkach* dostają kolor podświetlenia.
Formaty: post-4x5 (1080x1350), story-9x16 (1080x1920), square (1080x1080), poziom-16x9 (1920x1080),
link-1200x628 (reklama/link Facebook, LinkedIn), display-300x250 (baner Google), pinterest-2x3 (1000x1500),
yt-1280x720 (miniatura YouTube), x-1500x500 (nagłówek X), linkedin-1584x396 (baner LinkedIn).
Układ tekstu ("uklad" w serii albo przy grafice): auto, dol, gora, srodek, lewo, prawo.
Bez logo: "logo": false (albo "bez_logo": true) w serii albo przy grafice; bez tego bierze logo.png klienta.
"""
import argparse
import json
import re
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import blad, wynik  # noqa: E402
from montaz import hex_rgb, sciezka  # noqa: E402
import fonty  # noqa: E402

FORMATY = {
    "post-4x5": (1080, 1350), "story-9x16": (1080, 1920), "square": (1080, 1080), "poziom-16x9": (1920, 1080),
    "link-1200x628": (1200, 628), "display-300x250": (300, 250), "pinterest-2x3": (1000, 1500),
    "yt-1280x720": (1280, 720), "x-1500x500": (1500, 500), "linkedin-1584x396": (1584, 396),
}
SKROTY = {"post-4x5": "4x5", "story-9x16": "9x16", "square": "1x1", "poziom-16x9": "16x9", "link-1200x628": "1200x628",
          "display-300x250": "300x250", "pinterest-2x3": "2x3", "yt-1280x720": "yt", "x-1500x500": "x-naglowek",
          "linkedin-1584x396": "linkedin-baner"}


def dodaj_wlasne(formaty):
    """Własne rozmiary ze Studio: „wlasny-1200x900” (szerokość x wysokość w pikselach, 50–8000)."""
    for f in formaty or []:
        m = re.match(r"^wlasny-(\d{2,4})x(\d{2,4})$", str(f))
        if m and f not in FORMATY:
            w, h = int(m.group(1)), int(m.group(2))
            if 50 <= w <= 8000 and 50 <= h <= 8000:
                FORMATY[f] = (w, h)
                SKROTY[f] = f"{w}x{h}"
    return formaty


def cover(img, W, H, fx=0.5, fy=0.5):
    """Kadruje tło do formatu, trzymając punkt fokusu (fx, fy w zakresie 0–1) jak najbliżej środka."""
    s = max(W / img.width, H / img.height)
    img = img.resize((max(W, int(img.width * s + 1)), max(H, int(img.height * s + 1))))
    x = int(min(max(img.width * fx - W / 2, 0), img.width - W))
    y = int(min(max(img.height * fy - H / 2, 0), img.height - H))
    return img.crop((x, y, x + W, y + H))


def linie_z_wyroznieniem(tekst, font, max_w, d):
    """Dzieli tekst na linie; zwraca listę linii, każda to lista (słowo, wyróżnione)."""
    slowa = [(s.replace("*", ""), "*" in s) for s in tekst.split()]
    linie, biez = [], []
    for s in slowa:
        proba = " ".join(x for x, _ in biez + [s])
        if biez and d.textlength(proba, font=font) > max_w:
            linie.append(biez)
            biez = [s]
        else:
            biez.append(s)
    if biez:
        linie.append(biez)
    return linie


class Warstwy:
    """Grafika złożona z warstw (tło, przyciemnienie, teksty, przycisk, logo). Ta sama lista warstw
    daje gotowy PNG i plik Photoshopa (tekst zostaje edytowalny)."""

    def __init__(self, W, H):
        self.W, self.H, self.lista = W, H, []

    def nowa(self, nazwa, tekst=None, krycie=1.0):
        from PIL import Image
        img = Image.new("RGBA", (self.W, self.H), (0, 0, 0, 0))
        self.lista.append({"nazwa": nazwa, "img": img, "tekst": tekst, "krycie": krycie})
        return img

    def zlacz(self):
        from PIL import Image
        wyn = Image.new("RGBA", (self.W, self.H), (0, 0, 0, 255))
        for w in self.lista:
            img = w["img"]
            if w["krycie"] < 1:
                a = img.getchannel("A").point(lambda v: int(v * w["krycie"]))
                img = img.copy()
                img.putalpha(a)
            wyn.alpha_composite(img)
        return wyn

    def zapisz_do_psd(self, folder):
        """Każda warstwa przycięta do swojej zawartości + opis (pozycja, tekst) do złożenia PSD."""
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=True)
        opis = []
        for i, w in enumerate(self.lista):
            box = w["img"].getbbox()
            if not box:
                continue
            plik = folder / f"w{i:02d}.png"
            w["img"].crop(box).save(plik, compress_level=1)
            opis.append({"nazwa": w["nazwa"], "plik": str(plik), "x": box[0], "y": box[1], "krycie": w["krycie"], "tekst": w["tekst"]})
        return opis


def opis_tekstu(linie, font, plik_fontu, rozmiar, interlinia, x, y_gora, kolor, podsw=None, wyrownanie="left"):
    """Dane warstwy tekstowej dla Photoshopa: tekst z łamaniem linii, font, kolory fragmentów, punkt zaczepienia (linia bazowa)."""
    teksty, runs = [], []
    for li, linia in enumerate(linie):
        for k, (slowo, wyr) in enumerate(linia):
            fragment = slowo + (" " if k < len(linia) - 1 else ("\n" if li < len(linie) - 1 else ""))
            teksty.append(fragment)
            kol = podsw if (wyr and podsw) else kolor
            if runs and runs[-1]["kolor"] == list(kol[:3]):
                runs[-1]["dl"] += len(fragment)
            else:
                runs.append({"dl": len(fragment), "kolor": list(kol[:3])})
    return {"tekst": "".join(teksty), "font": fonty.nazwa_postscript(plik_fontu), "rozmiar": rozmiar, "interlinia": interlinia,
            "x": x, "y": y_gora + font.getmetrics()[0], "wyrownanie": wyrownanie, "runs": runs}


def dodaj_osobe(ws, osoba, W, H):
    """Prowadzący wycięty z tła (PNG z przezroczystością, np. z narzedzia/osoba.py) przy dolnej krawędzi, po lewej albo prawej.
    osoba: {"plik", "strona": "prawo"|"lewo", "wysokosc": 0.95 (część wysokości kadru), "przesun": 0 (część szerokości, + do środka),
            "odbij": false (lustro, żeby patrzył w stronę tekstu), "obrys": "#FFFFFF" (biała obwódka jak na miniaturach YT, opcjonalnie)}"""
    from PIL import Image, ImageFilter, ImageOps
    p = sciezka(osoba["plik"])
    if not p.exists():
        blad(f"Nie ma pliku prowadzącego {p} (wytnij go: python narzedzia/osoba.py wytnij ...)")
    im = Image.open(p).convert("RGBA")
    if osoba.get("odbij"):
        im = ImageOps.mirror(im)
    wys = int(H * float(osoba.get("wysokosc", 0.95)))
    s = wys / im.height
    if im.width * s > W * 0.6:  # bardzo szeroki kadr: nie więcej niż 60% szerokości
        s = W * 0.6 / im.width
    im = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)
    strona = osoba.get("strona", "prawo")
    przes = int(W * float(osoba.get("przesun", 0)))
    x = (W - im.width - int(W * 0.02) - przes) if strona == "prawo" else (int(W * 0.02) + przes)
    y = H - im.height
    if osoba.get("obrys"):
        r = max(2, int(H * 0.006))
        a = im.getchannel("A").filter(ImageFilter.MaxFilter(r * 2 + 1))
        ob = Image.new("RGBA", im.size, (*hex_rgb(osoba["obrys"], (255, 255, 255)), 255))
        ob.putalpha(a)
        ws.nowa("Prowadzący obrys").alpha_composite(ob, (x, y))
    ws.nowa("Prowadzący").alpha_composite(im, (x, y))


def renderuj(spec, W, H, wyjscie, warstwy_folder=None):
    """spec: tlo, naglowek, podtytul, cta, kolory, folder_klienta, font, font_tekstu, logo, fokus_x, fokus_y,
    uklad: auto | dol | gora | srodek | lewo | prawo (gdzie stoi blok tekstu).
    warstwy_folder: jeśli podany, zapisuje tam warstwy do pliku Photoshopa i zwraca ich opis."""
    from PIL import Image, ImageDraw, ImageFont

    kol = spec.get("kolory") or {}
    tekst_k = hex_rgb(kol.get("text"), (255, 255, 255))
    podsw = hex_rgb(kol.get("highlight") or kol.get("accent"), (34, 197, 94))
    akcent = hex_rgb(kol.get("accent") or kol.get("highlight"), (34, 197, 94))
    ciemny = hex_rgb(kol.get("primary") or kol.get("background"), (10, 14, 22))
    poziom = W / H >= 1.3
    story = H / W > 1.6   # Instagram/TikTok zasłaniają górę i dół kadru: trzymamy treść w bezpiecznej strefie
    uklad = spec.get("uklad") or "auto"
    osoba = spec.get("osoba") if isinstance(spec.get("osoba"), dict) and spec["osoba"].get("plik") else None
    if osoba and uklad == "auto":
        uklad = "lewo" if osoba.get("strona", "prawo") == "prawo" else "prawo"  # tekst po drugiej stronie niż prowadzący
    if uklad == "auto":
        uklad = "lewo" if poziom else "dol"
    if poziom and uklad in ("dol", "gora"):
        uklad = "lewo"
    if not poziom and uklad in ("lewo", "prawo"):
        uklad = "dol"
    ws = Warstwy(W, H)

    tlo = sciezka(spec["tlo"]) if spec.get("tlo") else None
    if tlo and tlo.exists():
        tlo_img = cover(Image.open(tlo).convert("RGB"), W, H, float(spec.get("fokus_x", 0.5)), float(spec.get("fokus_y", 0.5)))
    else:
        tlo_img = Image.new("RGB", (W, H), ciemny)
    ws.nowa("Tło").paste(tlo_img.convert("RGBA"))

    # przyciemnienie w kolorze marki tam, gdzie stoi tekst
    gd = ImageDraw.Draw(ws.nowa("Przyciemnienie"))
    if uklad in ("lewo", "prawo"):
        koniec = int(W * 0.72)
        for i in range(koniec):
            alfa = int(235 * (1 - i / koniec) ** 1.2)
            x = i if uklad == "lewo" else W - 1 - i
            gd.line([(x, 0), (x, H)], fill=(*ciemny, alfa))
    elif uklad == "srodek":
        gd.rectangle([0, 0, W, H], fill=(*ciemny, 150))
    else:
        start = int(H * 0.35)
        for i in range(H - start):
            alfa = int(235 * (i / (H - start)) ** 1.3)
            y = start + i if uklad == "dol" else H - 1 - start - i
            gd.line([(0, y), (W, y)], fill=(*ciemny, alfa))
    if osoba:
        dodaj_osobe(ws, osoba, W, H)
    d = ImageDraw.Draw(Image.new("RGBA", (W, H)))  # do mierzenia tekstu

    folder_f = sciezka(spec["folder_klienta"]) / "fonty" if spec.get("folder_klienta") else Path(".")
    f_gruby = fonty.znajdz(folder_f, spec.get("font"), gruby=True)
    if spec.get("font") and (not f_gruby or Path(f_gruby).parent != folder_f):  # nie ma w fontach klienta: wspólne / Google Fonts
        f_gruby = fonty.znajdz_wage(spec["font"], 800, folder_f if folder_f.exists() else None)[0] or f_gruby
    f_zwykly = fonty.znajdz(folder_f, spec.get("font_tekstu") or spec.get("font"), gruby=False) or f_gruby
    if (spec.get("font_tekstu") or spec.get("font")) and Path(f_zwykly).parent != folder_f:
        f_zwykly = fonty.znajdz_wage(spec.get("font_tekstu") or spec.get("font"), 400, folder_f if folder_f.exists() else None)[0] or f_zwykly
    if not f_gruby:
        blad("Brak fontu. Pobierz font marki: python narzedzia/fonty.py pobierz --nazwa NAZWA --folder klienci/marka/fonty")

    # wielkość liter liczona od krótszego boku; bardzo szerokie banery (X, LinkedIn) dostają większy tekst
    baza = (H * 1.4 if W / H >= 2.5 else H * 0.95) if poziom else min(W, H)
    m = max(8, int(baza * 0.075))
    max_w = (W * 0.55) if poziom else (W - 2 * m)
    if uklad == "srodek" and poziom:
        max_w = W * 0.7
    r_nag = int(baza * (0.085 if H <= W * 1.05 else 0.105 if story else 0.095))
    r_pod = max(9, int(baza * 0.042))
    f_pod = ImageFont.truetype(f_zwykly, r_pod)
    r_cta = max(9, int(baza * 0.04))
    f_cta = ImageFont.truetype(f_gruby, r_cta)

    cta = spec.get("cta", "")
    odstep = int(baza * 0.035)
    wys_cta = int(baza * 0.105) if cta else 0
    gora_bezp = int(H * 0.12) if story else m
    dol_bezp = int(H * 0.17) if story else m
    miejsce = H - gora_bezp - dol_bezp - (int(baza * 0.12) if uklad == "gora" else 0)
    # nagłówek: zmniejszamy, aż zmieści się w 4 liniach i w wysokości kadru
    while True:
        f_nag = ImageFont.truetype(f_gruby, max(9, r_nag))
        linie = linie_z_wyroznieniem(spec.get("naglowek", ""), f_nag, max_w, d)
        pod_linie = linie_z_wyroznieniem(spec.get("podtytul", ""), f_pod, max_w, d) if spec.get("podtytul") else []
        wys_nag = len(linie) * int(r_nag * 1.1)
        wys_pod = len(pod_linie) * int(r_pod * 1.35)
        blok = wys_nag + (odstep + wys_pod if pod_linie else 0) + (odstep + wys_cta if cta else 0)
        if (len(linie) <= 4 and blok <= miejsce) or r_nag < baza * 0.05:
            break
        r_nag = int(r_nag * 0.9)
    r_nag = max(9, r_nag)

    srodek_x = uklad == "srodek"
    if uklad == "dol":
        y = H - dol_bezp - blok
    elif uklad == "gora":
        y = gora_bezp + int(baza * 0.12)  # pod logo
    else:
        y = (H - blok) // 2 + (int(H * 0.04) if poziom else 0)
    x0 = (W - m - max_w) if uklad == "prawo" else m
    wyr = "center" if srodek_x else "left"

    def x_linii(szer):
        return (W - szer) / 2 if srodek_x else x0

    kotwica_x = W / 2 if srodek_x else x0
    dn = ImageDraw.Draw(ws.nowa("Nagłówek", opis_tekstu(linie, f_nag, f_gruby, r_nag, int(r_nag * 1.1), kotwica_x, y, tekst_k, podsw, wyr)))
    for linia in linie:
        szer = d.textlength(" ".join(s for s, _ in linia), font=f_nag)
        x = x_linii(szer)
        for slowo, wyr_ in linia:
            dn.text((x, y), slowo, font=f_nag, fill=podsw if wyr_ else tekst_k)
            x += d.textlength(slowo + " ", font=f_nag)
        y += int(r_nag * 1.1)
    if pod_linie:
        y += odstep
        dp = ImageDraw.Draw(ws.nowa("Podtytuł", opis_tekstu(pod_linie, f_pod, f_zwykly, r_pod, int(r_pod * 1.35), kotwica_x, y, tekst_k, None, wyr), 0.9))
        for linia in pod_linie:
            t = " ".join(s for s, _ in linia)
            dp.text((x_linii(d.textlength(t, font=f_pod)), y), t, font=f_pod, fill=tekst_k)
            y += int(r_pod * 1.35)
    if cta:
        y += odstep
        tw = d.textlength(cta, font=f_cta)
        bw, bh = tw + baza * 0.09, wys_cta
        bx = x_linii(bw)
        ImageDraw.Draw(ws.nowa("Przycisk")).rounded_rectangle([bx, y, bx + bw, y + bh], radius=bh / 2, fill=akcent)
        bb = d.textbbox((0, 0), cta, font=f_cta)
        jasny = sum(akcent) / 3 > 140
        k_cta = ciemny if jasny else (255, 255, 255)
        ty = y + (bh - (bb[3] - bb[1])) / 2 - bb[1]
        ImageDraw.Draw(ws.nowa("Tekst przycisku", opis_tekstu([[(w, False) for w in cta.split()]], f_cta, f_gruby, r_cta, r_cta, bx + bw / 2, ty,
                                                               k_cta, None, "center"))).text((bx + (bw - tw) / 2, ty), cta, font=f_cta, fill=k_cta)

    if spec.get("logo") is False or spec.get("bez_logo"):
        logo = None  # zadanie „bez logo klienta”
    else:
        logo = sciezka(spec["logo"]) if spec.get("logo") else (sciezka(spec["folder_klienta"]) / "logo.png" if spec.get("folder_klienta") else None)
    if logo and logo.exists():
        lg = Image.open(logo).convert("RGBA")
        lg.thumbnail((int(baza * 0.28), int(baza * 0.09)))
        lx = (W - lg.width) // 2 if srodek_x else (W - m - lg.width if uklad == "prawo" else m)
        ws.nowa("Logo").alpha_composite(lg, (int(lx), gora_bezp))

    img = ws.zlacz()
    wyjscie = Path(wyjscie)
    wyjscie.parent.mkdir(parents=True, exist_ok=True)
    img.convert("RGB").save(wyjscie, quality=94)
    opis = ws.zapisz_do_psd(warstwy_folder) if warstwy_folder else None
    return str(wyjscie), f_gruby, opis


def arkusz_podgladu(pliki_wg_grafiki, formaty, wyj):
    """Wszystkie grafiki na jednym obrazku: wiersz = grafika, kolumna = format."""
    from PIL import Image, ImageDraw

    wys = 300
    kolumny = [min(560, int(FORMATY[f][0] * wys / FORMATY[f][1])) for f in formaty]
    odst = 16
    W = sum(kolumny) + odst * (len(formaty) + 1)
    H = len(pliki_wg_grafiki) * (wys + odst) + odst
    ark = Image.new("RGB", (W, H), (30, 30, 30))
    d = ImageDraw.Draw(ark)
    for r, pliki in enumerate(pliki_wg_grafiki):
        x = odst
        for c, plik in enumerate(pliki):
            im = Image.open(plik).convert("RGB")
            im.thumbnail((kolumny[c], wys))
            ark.paste(im, (x, odst + r * (wys + odst)))
            d.text((x + 6, odst + r * (wys + odst) + 6), f"{r + 1:02d} {SKROTY[formaty[c]]}", fill=(255, 220, 0))
            x += kolumny[c] + odst
    ark.save(wyj, quality=85)


def zloz_psd(formaty, nazwy, opisy, pliki, wyj):
    """Jeden plik Photoshopa na całą serię: rząd = grafika, kolumny = jej formaty, każda na osobnym artboardzie
    (np. 01_czym-jest-etf_1080x1350 | 01_czym-jest-etf_1080x1920 | ...). Teksty zostają edytowalne."""
    import shutil
    import subprocess
    from PIL import Image

    node = shutil.which("node")
    skrypt = Path(__file__).resolve().parent / "psd" / "zloz_psd.js"
    if not node:
        return None, ("Brak Node.js, więc plik Photoshopa nie powstał. Zainstaluj: winget install OpenJS.NodeJS.LTS, "
                      "zamknij i otwórz terminal, potem: python narzedzia/grafika.py psd --plan <seria.json>")
    odst = 200
    szer_kol = [FORMATY[f][0] for f in formaty]
    wys_rzedu = max(FORMATY[f][1] for f in formaty)
    DW = sum(szer_kol) + odst * (len(formaty) + 1)
    DH = len(nazwy) * wys_rzedu + odst * (len(nazwy) + 1)
    kompozyt = Image.new("RGB", (DW, DH), (40, 40, 40))
    artboardy = []
    for r, nazwa in enumerate(nazwy):
        ay = odst + r * (wys_rzedu + odst)
        ax = odst
        for c, f in enumerate(formaty):
            W, H = FORMATY[f]
            kompozyt.paste(Image.open(pliki[r][c]).convert("RGB"), (ax, ay))
            warstwy = []
            for w in opisy[r][c]:
                t = dict(w["tekst"]) if w["tekst"] else None
                if t:
                    t["x"] += ax
                    t["y"] += ay
                warstwy.append({**w, "x": w["x"] + ax, "y": w["y"] + ay, "tekst": t})
            artboardy.append({"nazwa": f"{r + 1:02d}_{nazwa}_{W}x{H}", "x": ax, "y": ay, "w": W, "h": H, "warstwy": warstwy})
            ax += W + odst
    duzy = DW > 30000 or DH > 30000  # powyżej 30 000 px Photoshop wymaga formatu PSB (otwiera się tak samo)
    folder_psd = wyj / "photoshop"
    folder_psd.mkdir(exist_ok=True)
    cel = folder_psd / ("seria.psb" if duzy else "seria.psd")
    komp_plik = wyj / "_psd" / "kompozyt.png"
    komp_plik.parent.mkdir(parents=True, exist_ok=True)
    kompozyt.save(komp_plik, compress_level=1)
    zadanie = {"wyjscie": str(cel), "szerokosc": DW, "wysokosc": DH, "kompozyt": str(komp_plik), "artboardy": artboardy}
    zad_plik = wyj / "_psd" / "psd.json"
    zad_plik.write_text(json.dumps(zadanie, ensure_ascii=False), encoding="utf-8")
    r_ = subprocess.run([node, str(skrypt), str(zad_plik)], capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r_.returncode != 0:
        return None, f"Składanie PSD nie powiodło się: {(r_.stderr or r_.stdout)[-800:]}"
    shutil.rmtree(wyj / "_psd", ignore_errors=True)
    return str(cel), None


def seria(plan_plik, tylko_psd=False):
    plan = json.loads(sciezka(plan_plik).read_text(encoding="utf-8"))
    formaty = [f for f in dodaj_wlasne(plan.get("formaty", ["post-4x5"])) if f in FORMATY]
    if not formaty:
        blad(f"Brak poprawnych formatów. Dostępne: {', '.join(FORMATY)}")
    grafiki = plan.get("grafiki") or []
    if not grafiki:
        blad("Plan serii nie ma listy „grafiki”.")
    wyj = sciezka(plan.get("wyjscie", "wyniki/seria"))
    psd = plan.get("psd", True) or tylko_psd
    wspolne = {k: plan.get(k) for k in ("folder_klienta", "font", "font_tekstu", "kolory", "logo", "bez_logo", "cta", "uklad")}
    wszystkie, opisy, nazwy, font_uzyty = [], [], [], None
    for i, g in enumerate(grafiki, 1):
        spec = {**{k: v for k, v in wspolne.items() if v is not None}, **g}
        nazwa = g.get("nazwa") or f"grafika{i}"
        nazwy.append(nazwa)
        pliki, op = [], []
        for f in formaty:
            W, H = FORMATY[f]
            plik, font_uzyty, o = renderuj(spec, W, H, wyj / f"{i:02d}_{nazwa}_{SKROTY[f]}.png",
                                           (wyj / "_psd" / f"{i:02d}_{f}") if psd else None)
            pliki.append(plik)
            op.append(o)
        wszystkie.append(pliki)
        opisy.append(op)
    podglad = wyj / "podglad_serii.jpg"
    arkusz_podgladu(wszystkie, formaty, podglad)
    pliki_psd, uwaga = zloz_psd(formaty, nazwy, opisy, wszystkie, wyj) if psd else (None, None)
    dane = dict(folder=str(wyj), liczba_grafik=len(grafiki), formaty=formaty, plikow=sum(len(p) for p in wszystkie),
                podglad=str(podglad), font=font_uzyty, photoshop=pliki_psd,
                artboardow=len(grafiki) * len(formaty) if pliki_psd else 0)
    if uwaga:
        dane["uwaga_photoshop"] = uwaga
    wynik(**dane)


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] in ("seria", "psd"):
        p = argparse.ArgumentParser(description="Seria grafik")
        p.add_argument("tryb")
        p.add_argument("--plan", required=True)
        a = p.parse_args()
        seria(a.plan, tylko_psd=a.tryb == "psd")
    else:
        p = argparse.ArgumentParser(description="Grafika w barwach marki")
        p.add_argument("--tlo"); p.add_argument("--wyjscie", required=True); p.add_argument("--format", default="post-4x5")
        p.add_argument("--folder-klienta"); p.add_argument("--font"); p.add_argument("--font-tekstu"); p.add_argument("--logo")
        p.add_argument("--naglowek", required=True); p.add_argument("--podtytul", default=""); p.add_argument("--cta", default="")
        p.add_argument("--kolory", default=""); p.add_argument("--fokus-x", type=float, default=0.5); p.add_argument("--fokus-y", type=float, default=0.5)
        p.add_argument("--uklad", default="auto", choices=["auto", "dol", "gora", "srodek", "lewo", "prawo"])
        a = p.parse_args()
        if a.format not in FORMATY:
            blad(f"Nieznany format {a.format}. Dostępne: {', '.join(FORMATY)}")
        W, H = FORMATY[a.format]
        spec = {"tlo": a.tlo, "naglowek": a.naglowek, "podtytul": a.podtytul, "cta": a.cta,
                "kolory": json.loads(a.kolory) if a.kolory else {}, "folder_klienta": a.folder_klienta,
                "font": a.font, "font_tekstu": a.font_tekstu, "logo": a.logo, "fokus_x": a.fokus_x, "fokus_y": a.fokus_y,
                "uklad": a.uklad}
        plik, f, _ = renderuj(spec, W, H, sciezka(a.wyjscie))
        wynik(plik=plik, format=f"{W}x{H}", font=f)
