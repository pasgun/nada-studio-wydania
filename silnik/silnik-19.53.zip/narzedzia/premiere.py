"""Eksport osi czasu do Adobe Premiere Pro (format Final Cut Pro XML, który Premiere importuje).

Wywołuje go montaz.py, gdy plan ma "premiere": true. Można też ręcznie:
  python narzedzia/premiere.py --os wyniki/X/rolka_os_czasu.json

Co trafia do Premiere (folder premiere/ obok rolki):
- <nazwa>.xml   sekwencja: V1 ujęcia z tymi samymi cięciami co w rolce (do oryginalnych plików, także BRAW),
                V2 logo, A1 dźwięk z nagrań, A2 lektor, A3 muzyka, A4 efekty dźwiękowe
- <nazwa>_napisy.srt   napisy do importu jako napisy (captions)
- <nazwa>_dodatki.json   dla panelu: dynamiczne przejścia do położenia po imporcie, muzyka i efekty do sprawdzenia
- plansza.png, logo_nakladka.png   grafiki użyte w sekwencji
Przejścia: plik XML ma same cięcia i markery z nazwą przejścia (Premiere 2026 zawieszał się przy imporcie XML z przejściami).
Panel po imporcie kładzie w tych miejscach wbudowane przejścia Premiere: Cross Dissolve, Dip to Black, Dip to White,
Push, Cross Zoom, Iris Round. --przejscia-xml zapisuje przenikania i czerń w samym XML (stary sposób).
Ruchy kamery na zdjęciach są oznaczone markerami.
"""
import argparse
import json
import shutil
import subprocess
import sys
from pathlib import Path
from urllib.parse import quote
from xml.sax.saxutils import escape

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import blad, wynik  # noqa: E402

ROZSZ_OBRAZ = {".png", ".jpg", ".jpeg", ".webp"}
ORYGINALY = [".braw", ".r3d", ".ari", ".mxf", ".mov", ".mp4", ".mts", ".crm"]
NAZWY_PRZEJSC = {"zoom-in": "Zoom in", "zoom-out": "Zoom out", "whip-lewo": "Whip w lewo", "whip-prawo": "Whip w prawo",
                 "whip-gora": "Whip w górę", "whip-dol": "Whip w dół", "smuga-lewo": "Smuga w lewo", "smuga-prawo": "Smuga w prawo",
                 "fade": "Fade", "przenikanie": "Przenikanie", "czern": "Przez czerń", "flash": "Flash", "kolo": "Koło",
                 "rozmycie": "Rozmycie", "pixel": "Pixel", "zoom-przenikanie": "Zoom z przenikaniem"}
# przejścia, które Premiere wczytuje z pliku XML jako swoje (dają się potem zmieniać w Effect Controls)
XML_PRZEJSCIA = {"przenikanie": "Cross Dissolve", "fade": "Cross Dissolve", "zoom-przenikanie": "Cross Dissolve",
                 "rozmycie": "Cross Dissolve", "pixel": "Cross Dissolve", "czern": "Dip to Color Dissolve", "flash": "Dip to White"}
# dynamiczne: XML ich nie przenosi, więc panel kładzie po imporcie wbudowane przejścia Premiere w tych miejscach
# Premiere 2026 zawiesił się przy imporcie XML z przejściami (transitionitem), więc domyślnie plik XML ma same cięcia,
# a wszystkie przejścia kładzie panel po imporcie (wbudowane przejścia Premiere). --przejscia-xml włącza stary sposób.
PANEL_PRZEJSCIA = {"przenikanie": "Cross Dissolve", "fade": "Cross Dissolve", "zoom-przenikanie": "Cross Dissolve",
                   "rozmycie": "Cross Dissolve", "pixel": "Cross Dissolve", "czern": "Dip to Black", "flash": "Dip to White",
                   "zoom-in": "Cross Zoom", "zoom-out": "Cross Zoom", "whip-lewo": "Push", "whip-prawo": "Push",
                   "whip-gora": "Push", "whip-dol": "Push", "smuga-lewo": "Push", "smuga-prawo": "Push", "kolo": "Iris Round"}
DOMYSLNY_CZAS = {"przenikanie": 0.4, "fade": 0.4, "czern": 0.5, "flash": 0.3, "zoom-przenikanie": 0.35, "rozmycie": 0.3,
                 "pixel": 0.4, "zoom-in": 0.3, "zoom-out": 0.3, "kolo": 0.4}


def efekt_przejscia(nazwa):
    kat = "Dissolve"
    par = ""
    if nazwa == "Dip to Color Dissolve":
        par = ("<parameter><parameterid>dipcolor</parameterid><name>Color</name><value><alpha>255</alpha><red>0</red>"
               "<green>0</green><blue>0</blue></value></parameter>")
    return (f"<effect><name>{nazwa}</name><effectid>{nazwa}</effectid><effectcategory>{kat}</effectcategory>"
            "<effecttype>transition</effecttype><mediatype>video</mediatype><wipecode>0</wipecode><wipeaccuracy>100</wipeaccuracy>"
            f"<startratio>0</startratio><endratio>1</endratio><reverse>FALSE</reverse>{par}</effect>")


def url(p):
    """Ścieżka pliku w formacie, który Premiere rozumie na Windows i Macu."""
    s = Path(p).resolve().as_posix()
    if len(s) > 1 and s[1] == ":":
        s = s[0] + "%3a" + s[2:]
    return "file://localhost/" + quote(s.lstrip("/"), safe="/%")


def sonda(p):
    r = subprocess.run(["ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(p)],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    try:
        d = json.loads(r.stdout or "{}")
    except json.JSONDecodeError:
        d = {}
    v = next((s for s in d.get("streams", []) if s.get("codec_type") == "video"), None)
    a = next((s for s in d.get("streams", []) if s.get("codec_type") == "audio"), None)
    fps = None
    if v and v.get("avg_frame_rate") not in (None, "0/0"):
        n, m = v["avg_frame_rate"].split("/")
        fps = float(n) / float(m) if float(m) else None
    w, h = (v or {}).get("width"), (v or {}).get("height")
    for sd in (v or {}).get("side_data_list", []) or []:
        if abs(int(sd.get("rotation", 0))) == 90 and w and h:
            w, h = h, w
    try:
        dl = float(d.get("format", {}).get("duration", 0))
    except (TypeError, ValueError):
        dl = 0.0
    return {"fps": fps, "w": w, "h": h, "dlugosc": dl, "audio": a is not None,
            "kanaly": int(a.get("channels", 2)) if a else 0, "hz": int(a.get("sample_rate", 48000)) if a else 48000}


def _mapa_proksy():
    import porzadek
    return porzadek.system("proksy") / "mapa.json"


def oryginal(p):
    """Oryginał (np. BRAW) dla pliku proksy: z mapy zapisanej przy analizie (proksy z Premiere albo z folderu z proksy),
    a dla pliku z folderu _proksy: plik o tej samej nazwie piętro wyżej."""
    p = Path(p)
    try:
        import re
        n = lambda x: re.sub(r"[\\/]+", "/", str(x)).lower()
        m = {n(k): v for k, v in json.loads(_mapa_proksy().read_text(encoding="utf-8")).items()}.get(n(p))
        if m and Path(m).exists():
            return Path(m)
    except Exception:
        pass
    if p.parent.name.lower() != "_proksy":
        return None
    for roz in ORYGINALY:
        for kandydat in (p.parent.parent / (p.stem + roz), p.parent.parent / (p.stem + roz.upper())):
            if kandydat.exists():
                return kandydat
    return None


def rate_xml(fps):
    tb = round(fps)
    ntsc = "TRUE" if abs(fps - tb) > 0.01 else "FALSE"
    return f"<rate><timebase>{tb}</timebase><ntsc>{ntsc}</ntsc></rate>"


class Pliki:
    """Każdy plik opisany raz (pełny <file>), potem tylko odnośnik <file id=.../>."""

    def __init__(self, fps_sekw):
        self.ids, self.fps_sekw = {}, fps_sekw

    def xml(self, plik, info, wideo, audio):
        klucz = str(Path(plik).resolve())
        if klucz in self.ids:
            return f'<file id="{self.ids[klucz]}"/>'
        fid = f"file-{len(self.ids) + 1}"
        self.ids[klucz] = fid
        fps = info.get("fps") or self.fps_sekw
        media = ""
        if wideo:
            media += (f"<video><samplecharacteristics>{rate_xml(fps)}<width>{info.get('w') or 1920}</width>"
                      f"<height>{info.get('h') or 1080}</height><pixelaspectratio>square</pixelaspectratio>"
                      f"<fielddominance>none</fielddominance></samplecharacteristics></video>")
        if audio:
            media += (f"<audio><samplecharacteristics><depth>16</depth><samplerate>{info.get('hz', 48000)}</samplerate>"
                      f"</samplecharacteristics><channelcount>{info.get('kanaly') or 2}</channelcount></audio>")
        dur = max(1, round((info.get("dlugosc") or 0) * fps))
        return (f'<file id="{fid}"><name>{escape(Path(plik).name)}</name><pathurl>{url(plik)}</pathurl>{rate_xml(fps)}'
                f"<duration>{dur}</duration><media>{media}</media></file>")


def ruch_skala(W, H, w, h):
    if not (w and h):
        return None
    return round(max(W / w, H / h) * 100, 2)


def kadr_premiere(kadr, w_zrodla, w_celu):
    """Kadr z planu (skala w % pliku, którego używał montaż, np. proksy) przeliczony na plik w Premiere (np. oryginał RAW)."""
    if not isinstance(kadr, dict) or not kadr.get("skala"):
        return None
    sk = float(kadr["skala"])
    if w_zrodla and w_celu and w_zrodla != w_celu:
        sk = sk * w_zrodla / w_celu
    return {"skala": round(sk, 2), "x": round(float(kadr.get("x", 0.5)), 4), "y": round(float(kadr.get("y", 0.5)), 4)}


def efekt_kadr(kadr):
    """Motion: Scale i Position (Position w XML jako przesunięcie środka względem środka kadru, w ułamku szerokości/wysokości)."""
    return ("<filter><effect><name>Basic Motion</name><effectid>basic</effectid><effectcategory>motion</effectcategory>"
            "<effecttype>motion</effecttype><mediatype>video</mediatype>"
            "<parameter authoringApp=\"PremierePro\"><parameterid>scale</parameterid><name>Scale</name><valuemin>0</valuemin>"
            f"<valuemax>1000</valuemax><value>{kadr['skala']}</value></parameter>"
            "<parameter authoringApp=\"PremierePro\"><parameterid>center</parameterid><name>Center</name>"
            f"<value><horiz>{round(kadr['x'] - 0.5, 5)}</horiz><vert>{round(kadr['y'] - 0.5, 5)}</vert></value></parameter>"
            "</effect></filter>")


def efekt_skala(skala):
    if skala is None:
        return ""
    return ("<filter><effect><name>Basic Motion</name><effectid>basic</effectid><effectcategory>motion</effectcategory>"
            "<effecttype>motion</effecttype><mediatype>video</mediatype><parameter authoringApp=\"PremierePro\">"
            "<parameterid>scale</parameterid><name>Scale</name><valuemin>0</valuemin><valuemax>1000</valuemax>"
            f"<value>{skala}</value></parameter></effect></filter>")


def efekt_glosnosc(g):
    if abs(g - 1.0) < 0.01:
        return ""
    return ("<filter><effect><name>Audio Levels</name><effectid>audiolevels</effectid><effectcategory>audiolevels</effectcategory>"
            "<effecttype>audiolevels</effecttype><mediatype>audio</mediatype><parameter><parameterid>level</parameterid>"
            f"<name>Level</name><valuemin>0</valuemin><valuemax>3.98109</valuemax><value>{g:.3f}</value></parameter></effect></filter>")


def eksport(os_czasu, folder, przejscia_xml_wl=False):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    W, H, fps = os_czasu["W"], os_czasu["H"], int(os_czasu["fps"])
    F = lambda s: int(round(s * fps))  # noqa: E731
    pliki = Pliki(fps)
    uwagi, nr_klipu = [], [0]

    def nowy_id():
        nr_klipu[0] += 1
        return f"clipitem-{nr_klipu[0]}"

    # --- grafiki pomocnicze ---
    plansza = None
    if os_czasu.get("plansza_png") and Path(os_czasu["plansza_png"]).exists():
        plansza = folder / "plansza.png"
        shutil.copy(os_czasu["plansza_png"], plansza)
    logo_nakl = None
    if os_czasu.get("logo"):
        from PIL import Image
        lg = os_czasu["logo"]
        im = Image.open(lg["plik"]).convert("RGBA")
        szer = lg["szerokosc"]
        im = im.resize((szer, max(1, round(im.height * szer / im.width))))
        tlo = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        y = int(H * 0.06) if lg.get("pozycja", "gora") == "gora" else int(H * 0.86)
        tlo.alpha_composite(im, ((W - im.width) // 2, y))
        logo_nakl = folder / "logo_nakladka.png"
        tlo.save(logo_nakl)

    # --- V1: ujęcia ---
    # najpierw dane każdego ujęcia, potem przejścia (potrzebują zapasu klatek w sąsiednich ujęciach), na końcu XML
    ujecia, markery, przejscia_panel = [], [], []
    for i, e in enumerate(os_czasu["elementy"]):
        start_t, koniec_t = F(e["od"]), F(e["od"] + e["czas"])
        if koniec_t <= start_t:
            continue
        zrodlo = Path(e["plik"])
        if i == len(os_czasu["elementy"]) - 1 and plansza and zrodlo.name == "plansza.png":
            zrodlo = plansza
        obraz = zrodlo.suffix.lower() in ROZSZ_OBRAZ
        info = sonda(zrodlo)
        w_zrodla = info.get("w")
        cel = zrodlo
        org = None if obraz else oryginal(zrodlo)
        if org:
            info_org = sonda(org)
            if info_org.get("w") and info_org.get("h"):
                info = {**info, "w": info_org["w"], "h": info_org["h"]}
            else:
                uwagi.append(f"{org.name}: nie znam rozdzielczości oryginału; jeśli kadr jest zły, w Premiere „Scale to Frame Size”.")
            cel = org
        if obraz:
            from PIL import Image
            with Image.open(zrodlo) as im_:
                info.update({"w": im_.width, "h": im_.height, "fps": fps, "dlugosc": max(e["czas"], 1) * 10})
        f_fps = info.get("fps") or fps
        w_in = 0 if obraz else int(round(e["start"] * f_fps))
        w_out = w_in + int(round(e["czas"] * f_fps))
        dur = max(1, round(info.get("dlugosc", 0) * f_fps))
        ujecia.append({"i": i, "e": e, "start": start_t, "end": koniec_t, "in": w_in, "out": w_out, "fps": f_fps, "dur": dur,
                       "cel": cel, "info": info, "obraz": obraz, "przed": None, "po": None,
                       "kadr": kadr_premiere(e.get("kadr"), w_zrodla, info.get("w")) if not obraz else None})
        if e.get("ruch") and e["ruch"] != "brak" and obraz:
            markery.append(f"<marker><comment>Ruch kamery: {escape(e['ruch'])}</comment><name>Ruch: {escape(e['ruch'])}</name>"
                           f"<in>{start_t}</in><out>-1</out></marker>")

    przejscia_xml, w_xml = {}, 0
    for k in range(1, len(ujecia)):
        A, B = ujecia[k - 1], ujecia[k]
        rodz = B["e"].get("przejscie")
        if not rodz or rodz == "ciecie" or A["end"] != B["start"]:
            continue
        nazwa_pl = NAZWY_PRZEJSC.get(rodz, rodz)
        d_s = float(B["e"].get("przejscie_d") or DOMYSLNY_CZAS.get(rodz, 0.3))
        if przejscia_xml_wl and rodz in XML_PRZEJSCIA:
            d = max(2, int(round(d_s * fps)))
            dA = lambda x: int(round(x * A["fps"] / fps))  # noqa: E731
            dB = lambda x: int(round(x * B["fps"] / fps))  # noqa: E731
            zapas_A = 10 ** 9 if A["obraz"] else A["dur"] - A["out"]
            zapas_B = 10 ** 9 if B["obraz"] else B["in"]
            pol = d // 2
            # wyrównanie: środek na cięciu (jak w Premiere), a gdy brak zapasu, od cięcia albo do cięcia
            if zapas_A >= dA(d - pol) and zapas_B >= dB(pol):
                przed, po, wyr = pol, d - pol, "center"
            elif zapas_A >= dA(d):
                przed, po, wyr = 0, d, "start"
            elif zapas_B >= dB(d):
                przed, po, wyr = d, 0, "end"
            else:
                przed = None
            if przed is not None:
                A["po"], B["przed"] = dA(po), dB(przed)
                cut = B["start"]
                przejscia_xml[k] = (f"<transitionitem><start>{cut - przed}</start><end>{cut + po}</end><alignment>{wyr}</alignment>"
                                    f"{rate_xml(fps)}{efekt_przejscia(XML_PRZEJSCIA[rodz])}</transitionitem>")
                w_xml += 1
                continue
            uwagi.append(f"Przejście „{nazwa_pl}” w {B['start'] / fps:.1f} s: za krótkie ujęcia na przejście w Premiere, zostawiłem marker.")
        elif rodz in PANEL_PRZEJSCIA:
            przejscia_panel.append({"czas_s": round(B["start"] / fps, 4), "rodzaj": rodz, "premiere": PANEL_PRZEJSCIA[rodz],
                                    "dlugosc_s": round(d_s if d_s >= 0.2 else 0.3, 3)})
        markery.append(f"<marker><comment>Przejście z silnika: {escape(nazwa_pl)}</comment><name>{escape(nazwa_pl)}</name>"
                       f"<in>{B['start']}</in><out>-1</out></marker>")

    # pełny opis osi dla panelu (budowanie projektu .prproj): co ma leżeć na której ścieżce, od kiedy i jaki kawałek pliku
    opis_wideo, opis_audio, opis_ruch = [], [], []
    for u in ujecia:
        kd = u.get("kadr")
        opis_wideo.append({"tor": 1, "plik": str(u["cel"]), "od_s": round(u["start"] / fps, 4), "dlugosc_s": round((u["end"] - u["start"]) / fps, 4),
                           "w_pliku_s": 0 if u["obraz"] else round(u["in"] / u["fps"], 4), "obraz": u["obraz"],
                           "skala": kd["skala"] if kd else ruch_skala(W, H, u["info"].get("w"), u["info"].get("h")),
                           **({"pozycja": [kd["x"], kd["y"]], "kadr": True} if kd else {})})
        # ruch kamery jako klatki kluczowe: zdjęcia, a w nagraniach z kadrem przybliżenie / oddalenie na tym kadrze
        rch = u["e"].get("ruch")
        if rch and rch != "brak" and (u["obraz"] or (kd and rch in ("przybliz", "oddal"))):
            opis_ruch.append({"od_s": round(u["start"] / fps, 4), "dlugosc_s": round((u["end"] - u["start"]) / fps, 4), "ruch": rch,
                              **({"pozycja": [kd["x"], kd["y"]]} if kd else {})})
    v1 = []
    for k, u in enumerate(ujecia):
        st = -1 if u["przed"] is not None else u["start"]
        kn = -1 if u["po"] is not None else u["end"]
        w_in = u["in"] - (u["przed"] or 0)
        w_out = u["out"] + (u["po"] or 0)
        if k in przejscia_xml:
            v1.append(przejscia_xml[k])
        v1.append(f'<clipitem id="{nowy_id()}"><name>{escape(u["cel"].name)}</name><enabled>TRUE</enabled>'
                  f'<duration>{u["dur"]}</duration>{rate_xml(u["fps"])}'
                  f"<start>{st}</start><end>{kn}</end><in>{w_in}</in><out>{w_out}</out>"
                  f"{pliki.xml(u['cel'], u['info'], True, u['info'].get('audio', False) and not u['obraz'])}"
                  f"{efekt_kadr(u['kadr']) if u.get('kadr') else efekt_skala(ruch_skala(W, H, u['info'].get('w'), u['info'].get('h')))}</clipitem>")

    # --- V2: logo ---
    v2 = []
    if logo_nakl:
        dl_logo = F(os_czasu["logo"]["do"])
        info = {"w": W, "h": H, "fps": fps, "dlugosc": os_czasu["calosc"] * 10}
        opis_wideo.append({"tor": 2, "plik": str(logo_nakl), "od_s": 0, "dlugosc_s": round(dl_logo / fps, 4), "w_pliku_s": 0, "obraz": True, "skala": None})
        v2.append(f'<clipitem id="{nowy_id()}"><name>logo_nakladka.png</name><enabled>TRUE</enabled><duration>{F(os_czasu["calosc"] * 10)}</duration>'
                  f"{rate_xml(fps)}<start>0</start><end>{dl_logo}</end><in>0</in><out>{dl_logo}</out>{pliki.xml(logo_nakl, info, True, False)}</clipitem>")

    # --- V3+: nakładki (animacje, szablony, animowane logo) ---
    # nakładki, które na siebie nie zachodzą, dzielą ścieżkę; zachodzące idą wyżej. Oryginalna długość, dopasowane do kadru.
    tory_nakl = []
    for nk in sorted(os_czasu.get("nakladki") or [], key=lambda x: x["czas"]):
        pl = Path(nk["plik"])
        if not pl.exists():
            uwagi.append(f"Nakładka {pl.name}: nie ma pliku, pominięta w Premiere.")
            continue
        inf = sonda(pl)
        f_fps = inf.get("fps") or fps
        st = F(nk["czas"])
        kn = min(F(nk["czas"] + (inf.get("dlugosc") or 3)), F(os_czasu["calosc"]))
        if kn <= st:
            continue
        dl_src = max(1, int(round((kn - st) * f_fps / fps)))
        klip = (f'<clipitem id="{nowy_id()}"><name>{escape(pl.name)}</name><enabled>TRUE</enabled>'
                f"<duration>{max(1, round((inf.get('dlugosc') or 3) * f_fps))}</duration>{rate_xml(f_fps)}"
                f"<start>{st}</start><end>{kn}</end><in>0</in><out>{dl_src}</out>{pliki.xml(pl, inf, True, False)}"
                f"{efekt_skala(round(min(W / inf['w'], H / inf['h']) * 100, 2) if inf.get('w') and inf.get('h') and (inf['w'], inf['h']) != (W, H) else None)}</clipitem>")
        for nr_t, t in enumerate(tory_nakl):
            if t["koniec"] <= st:
                t["klipy"].append(klip); t["koniec"] = kn
                break
        else:
            nr_t = len(tory_nakl)
            tory_nakl.append({"klipy": [klip], "koniec": kn})
        opis_wideo.append({"tor": (3 if logo_nakl else 2) + nr_t, "plik": str(pl), "od_s": round(st / fps, 4), "dlugosc_s": round((kn - st) / fps, 4),
                           "w_pliku_s": 0, "obraz": False, "skala": round(min(W / inf["w"], H / inf["h"]) * 100, 2) if inf.get("w") and inf.get("h") and (inf["w"], inf["h"]) != (W, H) else None})

    # --- audio ---
    def klip_audio(plik, start_t, koniec_t, w_in_s, glosnosc=1.0, tor_a=1):
        opis_audio.append({"tor": tor_a, "plik": str(plik), "od_s": round(start_t / fps, 4), "dlugosc_s": round((koniec_t - start_t) / fps, 4),
                           "w_pliku_s": round(float(w_in_s), 4), "glosnosc": round(float(glosnosc), 4)})
        info = sonda(plik)
        f_fps = info.get("fps") if info.get("w") else None
        f_fps = f_fps or fps
        w_in = int(round(w_in_s * f_fps))
        dlug = int(round((koniec_t - start_t) / fps * f_fps))
        return (f'<clipitem id="{nowy_id()}"><name>{escape(Path(plik).name)}</name><enabled>TRUE</enabled>'
                f'<duration>{max(1, round(info.get("dlugosc", 0) * f_fps))}</duration>{rate_xml(f_fps)}'
                f"<start>{start_t}</start><end>{koniec_t}</end><in>{w_in}</in><out>{w_in + dlug}</out>"
                f"{pliki.xml(plik, info, bool(info.get('w')), True)}"
                f"<sourcetrack><mediatype>audio</mediatype><trackindex>1</trackindex></sourcetrack>{efekt_glosnosc(glosnosc)}</clipitem>")

    a1 = []
    for e, a in zip(os_czasu["elementy"], os_czasu.get("sceny_audio", [])):
        if not a.get("dzwiek"):
            continue
        st, kn = F(e["od"]), F(e["od"] + e["czas"])
        if a.get("dzwiek_z"):
            zr, w_in = Path(a["dzwiek_z"]["plik"]), a["dzwiek_z"]["start"]
        else:
            zr, w_in = Path(e["plik"]), e["start"]
            zr = oryginal(zr) or zr
        a1.append(klip_audio(zr, st, kn, w_in, a.get("glosnosc", 1.0)))
    # numery ścieżek audio takie, jakie wyjdą w XML (puste ścieżki są pomijane)
    nr_a = 1 + (1 if a1 else 0)
    a2 = [klip_audio(os_czasu["lektor"], 0, F(os_czasu["calosc"]), 0, 1.0, nr_a)] if os_czasu.get("lektor") else []
    nr_a += 1 if a2 else 0
    a3 = []
    if os_czasu.get("muzyka"):
        a3.append(klip_audio(os_czasu["muzyka"]["plik"], 0, F(os_czasu["calosc"]), os_czasu["muzyka"].get("start", 0),
                             os_czasu["muzyka"]["glosnosc"], nr_a))
    nr_a += 1 if a3 else 0
    a4 = []
    for ef in os_czasu.get("efekty", []):
        dl = sonda(ef["plik"]).get("dlugosc") or 0.5
        a4.append(klip_audio(ef["plik"], F(ef["czas"]), F(ef["czas"] + dl), 0, ef["glosnosc"], nr_a))

    def tor(klipy, audio=False):
        atr = ' premiereTrackType="Stereo"' if audio else ""
        return f"<track{atr}>{''.join(klipy)}<enabled>TRUE</enabled><locked>FALSE</locked></track>"

    tory_v = tor(v1) + (tor(v2) if v2 else "") + "".join(tor(t["klipy"]) for t in tory_nakl)
    tory_a = "".join(tor(k, True) for k in (a1, a2, a3, a4) if k) or tor([], True)
    nazwa = os_czasu.get("nazwa", "rolka")
    xml = (f'<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE xmeml>\n<xmeml version="4"><sequence id="sequence-1">'
           f"<name>{escape(nazwa)}</name><duration>{F(os_czasu['calosc'])}</duration>{rate_xml(fps)}"
           f"<timecode>{rate_xml(fps)}<string>00:00:00:00</string><frame>0</frame><displayformat>NDF</displayformat></timecode>"
           f"<media><video><format><samplecharacteristics>{rate_xml(fps)}<width>{W}</width><height>{H}</height>"
           f"<pixelaspectratio>square</pixelaspectratio><fielddominance>none</fielddominance></samplecharacteristics></format>"
           f"{tory_v}</video><audio><numOutputChannels>2</numOutputChannels><format><samplecharacteristics><depth>16</depth>"
           f"<samplerate>48000</samplerate></samplecharacteristics></format>{tory_a}</audio></media>"
           f"{''.join(markery)}</sequence></xmeml>\n")
    plik_xml = folder / f"{nazwa}.xml"
    plik_xml.write_text(xml, encoding="utf-8")
    # dla panelu: co ma być w sekwencji po imporcie (dynamiczne przejścia do położenia, muzyka i efekty do sprawdzenia)
    srt_cel = folder / Path(os_czasu["srt"]).name if os_czasu.get("srt") and Path(os_czasu["srt"]).exists() else None
    nap = os_czasu.get("napisy")
    if nap and not (nap.get("slowa") and Path(nap["slowa"]).exists()):
        nap = None
    dodatki = {"wersja": 4, "xml": str(plik_xml), "fps": fps, "nazwa": nazwa, "W": W, "H": H, "calosc_s": os_czasu["calosc"],
               "wideo": opis_wideo, "audio": opis_audio, "ruch": opis_ruch, "srt": str(srt_cel) if srt_cel else None,
               "przejscia": przejscia_panel,
               # napisy w stylu z narzędzia (słowa + styl z montażu): projekt Premiere kładzie je jako osobne klipy
               "napisy": nap,
               "muzyka": ({"plik": os_czasu["muzyka"]["plik"], "od_s": 0, "w_pliku_s": os_czasu["muzyka"].get("start", 0),
                           "dlugosc_s": os_czasu["calosc"], "glosnosc": os_czasu["muzyka"]["glosnosc"]} if os_czasu.get("muzyka") else None),
               "efekty": [{"plik": ef["plik"], "od_s": ef["czas"], "glosnosc": ef["glosnosc"]} for ef in os_czasu.get("efekty", [])]}
    (folder / f"{nazwa}_dodatki.json").write_text(json.dumps(dodatki, ensure_ascii=False, indent=1), encoding="utf-8")
    if os_czasu.get("srt") and Path(os_czasu["srt"]).exists():
        shutil.copy(os_czasu["srt"], folder / Path(os_czasu["srt"]).name)
    (folder / "CZYTAJ.txt").write_text(
        "Import do Premiere Pro:\n"
        f"1. Plik > Importuj (Ctrl+I) i wybierz {plik_xml.name}. Powstanie sekwencja „{nazwa}” z klipami w panelu Projekt.\n"
        "2. Jeśli klip jest offline (czerwony): prawy klik > Połącz multimedia i wskaż plik (np. oryginał BRAW).\n"
        "3. Napisy: Plik > Importuj plik .srt, potem przeciągnij go na oś czasu nad obrazem.\n"
        "4. Przejścia kładzie panel Nada Studio po imporcie („Wczytaj do Premiere”): Cross Dissolve, Dip to Black, Dip to White,\n"
        "   Push, Cross Zoom, Iris Round (zmieniasz je w Effect Controls). Przy ręcznym imporcie zostają markery z nazwą przejścia.\n"
        "   Efekty dźwiękowe (whoosh) leżą na osobnej ścieżce audio.\n"
        "5. Muzyka (A3) ma już ustawioną głośność pod lektorem; ściszenie pod mową dopracuj ręcznie albo przez Remix/Auto-Ducking.\n",
        encoding="utf-8")
    return {"xml": str(plik_xml), "folder": str(folder), "uwagi": uwagi, "przejscia_w_xml": w_xml,
            "przejscia_do_panelu": len(przejscia_panel), "efekty": len(a4)}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Eksport do Premiere Pro")
    p.add_argument("--os", required=True, help="plik *_os_czasu.json zapisany przez montaz.py")
    p.add_argument("--folder", help="gdzie zapisać (domyślnie premiere/ obok)")
    p.add_argument("--przejscia-xml", action="store_true",
                   help="przenikania i czerń jako przejścia w pliku XML (Premiere 2026 potrafi się na tym zawiesić)")
    p.add_argument("--nazwa", help="nazwa sekwencji i plików (domyślnie z osi montażu, np. po porządku: <klient>_<szer>x<wys>_rolka1)")
    p.add_argument("--efekty-auto", action="store_true",
                   help="dołóż efekty dźwiękowe (whoosh, błysk) przy dynamicznych przejściach, gdy montaż ich nie dodał")
    a = p.parse_args()
    plik = Path(a.os)
    if not plik.exists():
        blad(f"Nie ma pliku {plik}")
    oc = json.loads(plik.read_text(encoding="utf-8"))
    if a.efekty_auto and not oc.get("efekty"):
        import efekty as efekty_mod
        prz = [{"rodzaj": e.get("przejscie"), "czas": e["od"],
                "d": e.get("przejscie_d") or DOMYSLNY_CZAS.get(e.get("przejscie"), 0.25)}
               for e in oc["elementy"][1:] if e.get("przejscie") and e["przejscie"] != "ciecie"]
        oc["efekty"] = [{"plik": x["plik"], "czas": x["czas"], "glosnosc": x["glosnosc"]} for x in efekty_mod.auto_efekty(prz, oc["calosc"])]
    if a.nazwa:
        oc["nazwa"] = a.nazwa
    wynik(**eksport(oc, a.folder or plik.parent / "premiere", a.przejscia_xml))
