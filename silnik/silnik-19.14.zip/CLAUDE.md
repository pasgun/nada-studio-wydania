# Silnik rolek Nadamedia

Ten folder to silnik, który robi rolki i grafiki dla klientów. Zadania przychodzą ze strony „Studio Nadamedia” na claude.ai jako polecenie `/rolka {json}`, `/grafika {json}`, `/aftermovie {json}` albo polecenie narzędzia: `/napisy`, `/ciecie`, `/transkrypcja`, `/pion`, `/miniatury`, `/dzwiek`, `/tlumaczenie`, `/formaty`, `/brandbook`, `/multicam`, `/animacje`, `/jak-wzor`. Panel „Nada Studio” w Premiere i After Effects (`narzedzia/panel_premiere.py --instaluj`; panel czyta pliki prosto z `premiere/` w silniku) ma cięcie ciszy i wpadek, multicam podcastu, aftermovie, animacje, szablony rolek (edycja w AE przez Dynamic Link), poprawę dźwięku zaznaczonych klipów, napisy do sekwencji, asystenta audio i transkrypcję; błędy panelu zapisują się w `_system/panel/bledy.txt`; animacje, szablony i napisy wstawione z panelu są zapisane w `_system/panel/animacje_na_osi.json` (po kliknięciu na osi wracają do edycji w panelu); zadania z panelu przychodzą z `"zrodlo": "premiere"`: użytkownika nie ma wtedy przy komputerze, nie zadawaj pytań i raportuj etapy przez `narzedzia/postep.py`. Szczegółowe kroki są w skillach w `.claude/skills/`. Zadania z przycisku „Wykonaj” w Studio uruchamia `narzedzia/mcp_studio.py` (Claude Code albo Gemini w tle, przebieg w `_system/studio/<id>/`): użytkownik czyta Twoje odpowiedzi w zakładce Console w Studio (widać tam też zadania z panelu) i może odpisać; gdy potrzebujesz jego decyzji, zakończ odpowiedź pytaniem i znacznikiem `[CZEKAM]`, a po skończeniu znacznikiem `[GOTOWE]`.

Silnik jest częścią apki Nada Studio (Windows): apka instaluje programy (Python, ffmpeg, Node, Claude Code, Antigravity; ich foldery w `_system/sciezki.json`, narzędzia dopisują je same do PATH przez `narzedzia/sciezki.py`), ma wbudowane Studio (baza w `_system/baza/`, pliki w `_system/pliki/`) i aktualizuje pliki silnika z GitHuba. Pliki silnika (narzędzia, skille, panele, ten plik) podmienia aktualizacja: nie trzymaj w nich danych użytkownika.

Użytkownik to montażysta i operator, nie programista. Rozmawiaj po polsku, bez żargonu. Jeśli musisz użyć terminu technicznego, wyjaśnij go jednym zdaniem.

**Język.** Jeśli plik `_system/jezyk.txt` zawiera `en` (użytkownik wybrał w apce angielski), rozmawiaj z nim po angielsku: odpowiedzi, pytania, plany i raporty po angielsku, tak samo prosto i bez żargonu. Nazwy narzędzi, folderów i pól w plikach zostają bez zmian (są po polsku). Treść dla klienta (lektor, napisy, grafiki) zawsze w języku z zadania, nie w języku apki.

## Serwisy i jak je wybierać

Zadanie zawiera listę `serwisy`: tych wolno użyć. Nigdy nie używaj serwisu spoza listy. Jeśli lista jest pusta, zaproponuj serwisy i zapytaj.

| Serwis | Do czego | Jak | Koszt dla użytkownika |
| --- | --- | --- | --- |
| `gemini` | obrazy AI Nano Banana (klatki, tła; w grafikach `tryb_grafiki: "nano"` = cała grafika z tekstem) | `python narzedzia/gemini.py obraz [--obrazy logo.png] [--px 1200x628]`, `gemini.py grafika --plan nb.json` (pod spodem Antigravity: `narzedzia/obraz_agy.py`) | z limitów abonamentu Google AI Pro przez Antigravity, bez płatnego API; płatne API tylko, gdy użytkownik sam ustawi `"silnik": "api"` w `narzedzia/obrazy_ustawienia.json` (nie zmieniaj tego) |
| `magnific` | obrazy AI i krótkie wideo AI | narzędzia MCP serwera `magnific` (`images_generate`, `video_generate`, `images_upscale`), wynik pobierz `python narzedzia/pobierz.py` | kredyty z abonamentu Magnific |
| `magnific-stock` | prawdziwe ujęcia wideo i zdjęcia ze stocka | `python narzedzia/freepik.py szukaj --podglady ...`, obejrzyj miniatury, potem `freepik.py pobierz` | w abonamencie, limit 100 pobrań dziennie |
| `nagrania` | materiał nagrany przez użytkownika | folder z `zadanie.nagrania_folder`, analiza `python narzedzia/analiza.py folder --folder ...` | darmowe (transkrypcja: kredyty ElevenLabs albo lokalnie) |
| `envato` | prawdziwe ujęcia, zdjęcia, muzyka | pliki z folderu `envato/` (użytkownik pobiera je ręcznie) | w abonamencie |
| `higgsfield` | wideo AI najwyższej jakości (rolki) oraz obrazy AI Soul 2 (grafiki) | `python narzedzia/higgsfield.py wideo|obraz` | wideo DROGIE (ok. 0,35 USD za 5 s klipu); obrazy tanie (ułamek centa) |
| `materialy` | zdjęcia i pliki użytkownika do grafik | folder z `zadanie.materialy_folder` | darmowe |
| `epidemic` | muzyka i efekty dźwiękowe (pobiera sam, umie dociąć utwór do długości rolki) | narzędzia MCP serwera `epidemic-sound` (połączenie kluczem `EPIDEMIC_SOUND_MCP_API_KEY`; brak połączenia: `python narzedzia/mozg.py epidemic`) | w abonamencie Epidemic Sound |
| `artlist` | muzyka z katalogu Artlist (tylko wyszukiwanie: dajesz 3 propozycje z linkami, użytkownik pobiera wybraną do `muzyka/`) albo muzyka generowana AI (kredyty, tylko za zgodą) | narzędzia MCP serwera `artlist` | katalog w abonamencie; generowanie z kredytów |
| `elevenlabs` | lektor | `python narzedzia/lektor.py` | z puli znaków planu |

Domyślna rekomendacja: **stock na pierwszym miejscu**, generowanie tylko tam, gdzie stock nie wystarcza.
1. Każdą scenę najpierw spróbuj wypełnić ujęciem wideo ze stocka Magnific (`magnific-stock`): prawdziwe ujęcia, bez kredytów. Szukaj kilkoma angielskimi frazami, zanim uznasz, że czegoś nie ma.
2. Envato, gdy użytkownik ma pasujące pliki w `envato/`.
3. Obraz AI (Gemini albo Magnific) ożywiony ruchem kamery w montażu, tylko gdy w stocku nie ma sensownego ujęcia (np. bardzo konkretna metafora, produkt klienta).
4. Wideo AI (Magnific): domyślnie najwyżej 1 scena na rolkę, zwykle hak, i tylko gdy stock nie daje mocnego otwarcia. Więcej tylko na prośbę użytkownika.
5. Higgsfield tylko wtedy, gdy jest na liście, a użytkownik o niego prosi albo Magnific nie da rady.
Gdy skończy się dzienny limit 100 pobrań ze stocka, powiedz o tym i zaproponuj Envato albo obrazy AI.

**Własne stocki użytkownika** (dodane w apce, lista w `_system/stocki.json`, podgląd: `python narzedzia/stock_api.py lista`). Traktuj je jak serwisy stockowe: wolno ich użyć, gdy na liście `serwisy` jest ich `slug` albo `magnific-stock`/`envato` (czyli zadanie pozwala na stock), w kolejności po stocku Magnific.
- `api: "tak"` z obsługą wbudowaną (Pexels, Pixabay): `python narzedzia/stock_api.py szukaj --serwis <slug> --fraza "<angielska fraza>" [--pion]`, obejrzyj podglądy (Read na `podglad` po pobraniu `pobierz.py`, jeśli trzeba), potem `stock_api.py pobierz --serwis <slug> --url <url> --wyjscie <folder zadania>/sceny/<plik>`. Klucz jest w `.env` (nazwa w `klucz_env`), nie czytaj go.
- `api: "tak"` bez obsługi wbudowanej: nie pisz własnego kodu do tego API w trakcie zadania; napisz w raporcie, że serwis da się podłączyć (dokumentacja w `docs`).
- `api: "partner"` albo `"nie"`: działa jak Envato, czyli pliki pobrane ręcznie przez użytkownika leżą w folderze z pola `folder` (`stock_reczny/<slug>/`, lista: `stock_api.py pliki --serwis <slug>`). Nigdy nie próbuj pobierać z tych serwisów automatycznie. Gdy folder jest pusty, a stock by się przydał, powiedz to i podaj frazy do wyszukania na stronie serwisu.
- W raporcie podaj, z którego serwisu jest każde ujęcie (licencje różnych serwisów wymagają np. podania autora).

Jeśli serwer MCP `magnific` nie jest podłączony (brak jego narzędzi), powiedz użytkownikowi, żeby wpisał
`! claude mcp add --transport http magnific https://mcp.magnific.com`, a potem zrestartował Claude Code.

## Narzędzia (folder `narzedzia/`)

Każde narzędzie wypisuje wynik jako JSON (`"ok": true/false`). Przy `"ok": false` przeczytaj `"blad"`, napraw przyczynę i spróbuj ponownie. Nie zgaduj wyników.

- `python narzedzia/sprawdz.py [--test]` sprawdza Pythona, ffmpeg, klucze w `.env` i połączenie z serwisami
- `python narzedzia/lektor.py` robi lektora ElevenLabs: `lektor.mp3` oraz `slowa.json` z czasem każdego słowa
- `python narzedzia/gemini.py obraz|modele` generuje obrazy Gemini
- `python narzedzia/obraz_agy.py test|obraz` Nano Banana przez Antigravity CLI (narzędzie generate_image, abonament Google AI Pro, bez klucza API); `gemini.py` i `stock.py` używają go same (ustawienie w `narzedzia/obrazy_ustawienia.json`, domyślnie `agy`)
- `python narzedzia/higgsfield.py obraz|wideo|scena` generuje obraz i wideo Higgsfield
- `python narzedzia/freepik.py szukaj|pobierz|obraz` to stock Magnific (zdjęcia, wideo) i obrazy Mystic; klucz `MAGNIFIC_API_KEY`
- `python narzedzia/stock.py frazy|z-klipow|z-filmu|z-plikow|szukaj|pobierz|licznik` wyszukiwarka stocków (panel: Stock): polski opis albo ujęcia (z osi, pliki, gotowy film rozbity na ujęcia) zamienia przez Gemini na angielskie frazy, szuka w stocku Magnific (podgląd wideo po najechaniu, pobieranie do `stock/<data>/` i kosza „Nada – stock”), do Envato daje tylko linki do wyszukiwania na stronie; licznik dziennych pobrań w `_system/stock/pobrania.json`
- `python narzedzia/pobierz.py --url ... --wyjscie ...` pobiera wynik z adresu, np. z Magnific MCP
- `python narzedzia/montaz.py zloz --plan plan.json` składa rolkę; `klatki --plik rolka.mp4` wycina kadry do kontroli
- `python narzedzia/analiza.py folder|klip|referencje` robi z nagrań arkusze kadrów (Read), listę cięć i transkrypcję ze słowami
- `python narzedzia/dzwiek.py premiere --plik X --kopia <backup>` (panel Premiere: czysty plik obok oryginału, kopia oryginału do backupu); `python narzedzia/dzwiek.py popraw|folder` poprawia dźwięk mowy z nagrań (AI ElevenLabs Voice Isolator + obróbka studyjna), wynik `_analiza/<klip>_czysty.wav`
- `python narzedzia/grafika.py seria --plan seria.json` składa serię grafik (wiele sztuk × formaty), arkusz podglądu i jeden plik Photoshopa (`photoshop/seria.psd`: rząd = grafika, kolumny = formaty, każda na osobnym artboardzie, edytowalne teksty); `grafika.py psd --plan ...` robi same PSD jeszcze raz
- `python narzedzia/napisy.py segmenty --xml X --folder Y --styl JSON --W --H` (panel Premiere: każdy napis osobnym przezroczystym MOV + `napisy.json` + SRT; poprawki: `napisy.py popraw --folder Y --zmiany '[{"id":3,"tekst":"..."}]'` albo `--styl JSON --wszystkie`), `napisy.py sekwencja ...` (jeden MOV na całą sekwencję); `python narzedzia/napisy.py transkrybuj|wypal|podglad` napisy w stylu ze Studio: do gotowych filmów (generator napisów) i podgląd stylu; montaż rolek używa tego samego silnika
- `python narzedzia/mowa.py --plik X [--mowcy]` rozpoznawanie mowy (ElevenLabs z mówcami i zdarzeniami, Whisper z Subtitle Edit, faster-whisper); `--silniki` pokazuje dostępne
- `python narzedzia/transkrypcja.py --folder X` transkrypcja z kodami czasowymi (txt, srt, słowa)
- `python narzedzia/ciecie.py analizuj|zastosuj|tekst` cięcie ciszy i wpadek w sekwencji z Premiere/DaVinci (XML), nowa sekwencja z markerami; tnie wszystkie ścieżki w tych samych miejscach, zablokowane ścieżki zostawia bez cięć; wynik `zastosuj` ma też `ciecia` (zakresy w sekundach oryginału), `markery`, `grupy` i `zablokowane`: panel Premiere tnie nimi kopię sekwencji w samym Premiere (`nm_tnij_w_premiere` w `premiere/host/host.jsx`), więc efekty i ustawienia klipów zostają; plik XML jest zapasem i drogą dla DaVinci
- `python narzedzia/pion.py --plik|--folder` z poziomu na pion 9:16 ze śledzeniem twarzy albo mówcy
- `python narzedzia/miniatury.py klatki --plik film` najlepsze kadry na miniatury YouTube
- `python narzedzia/dzwiek.py hurtem --folder X --moc 80` poprawa dźwięku wszystkich plików z folderu (jak Adobe Podcast)
- `python narzedzia/tlumacz.py dubbing --folder X --jezyki en,de` wersje językowe przez dubbing ElevenLabs
- `python narzedzia/formaty.py --plik grafika.psd --formaty ...` jedna grafika na wiele rozmiarów + PSD z artboardami
- `python narzedzia/brandbook.py strona|pdf` dane marki ze strony www i brandbook PDF
- `python narzedzia/wspolne.py --klient "<klient.nazwa>" --klient-folder "<klient.folder>" --projekt "<zadanie.tytul>" --id "<zadanie.id>"` tworzy folder zadania `wyniki/<Klient>/<Tytuł>` (to samo zadanie wraca do swojego folderu)
- `python narzedzia/porzadek.py zadanie --folder <folder zadania>` porządek na koniec zadania: gotowe pliki na wierzch (np. „Rolka 1.mp4”), `Projekty/` (Premiere XML, PSD), `Materiały/` (reszta); poprawia ścieżki w timeline'ach; `porzadek.py stare` porządkuje stare foldery
- `python narzedzia/marka.py sprawdz --folder klienci/<folder>` mówi, czy notatkę marki `marka.md` trzeba napisać albo odświeżyć, i wypisuje pliki brandbooka
- `python narzedzia/efekty.py generuj|lista|plan` efekty dźwiękowe do przejść: wbudowana biblioteka `narzedzia/dzwieki/` i pliki użytkownika z `muzyka/efekty/`; montaż używa jej sam przy `"efekty_auto": true`
- `python narzedzia/bity.py --plik muzyka.mp3` wykrywa tempo, bity, takty i „drop” do cięcia w rytm
- `python narzedzia/premiere.py --os <rolka>_os_czasu.json` eksport osi czasu do Premiere (zwykle robi go sam montaż przy `"premiere": true`)
- `python narzedzia/fonty.py pobierz|pokaz|lista|instaluj|wariant` pobiera font marki z Google Fonts albo pokazuje fonty klienta; `lista [--szukaj X]` przegląda ok. 1500 rodzin (`narzedzia/fonty_lista.json`), `instaluj --polecane` albo `instaluj --rodzina X [--kursywa]` instaluje fonty w Windows (dla Premiere, AE i Photoshopa), `wariant --rodzina X --waga 900 [--kursywa]` pobiera jeden wariant. Warianty nazywaj jak w oryginale: Thin, ExtraLight, Light, Regular, Medium, SemiBold, Bold, ExtraBold, Black (+ Italic)
- `python narzedzia/multicam.py analizuj|zastosuj` multicam podcastu: kamera na osobę mówiącą do swojego mikrofonu (odporne na przebicia), czysty i wyrównany dźwięk bez przebić (`--dzwiek`); `--nieuzyte wylacz|usun` co zrobić z nieużytymi ujęciami kamer
- `python narzedzia/stock_api.py lista|szukaj|pobierz|pliki` własne stocki użytkownika z `_system/stocki.json` (sekcja „Serwisy”)
- `python narzedzia/davinci_most.py wyniki|tnij|napisy|wczytane|folder|klienci|style|mozgi|panel-folder|multicam|aftermovie|zlecenie` most do DaVinci Resolve (panel w DaVinci ma też animacje, szablony rolek, napisy w stylu rolek, aftermovie w tle, stock Magnific i multicam podcastu; rzeczy wstawiane z panelu leżą w `wyniki/<Klient>/Panel DaVinci/`; aftermovie z DaVinci przychodzi z `"program": "davinci"` i działa jak z panelu Premiere, a gotowa oś trafia do zakładki Wyniki panelu) (panel Nada Studio w wersji Studio: Workspace > Workflow Integrations, skrypty Lua w każdej wersji: Workspace > Scripts > Nada Studio): osie z wyników do wczytania, cięcie ciszy i wpadek oraz napisy SRT dla osi wyeksportowanej z DaVinci (FCP 7 XML); folder roboczy `wyniki/DaVinci/<oś> <data>`; pliki panelu są w `davinci/`
- `python narzedzia/aftermovie.py material --xml sekwencja.xml --folder X` klipy z osi czasu Premiere (ścieżki, zostawione fragmenty, muzyka z osi) + ich analiza
- `python narzedzia/animacje.py lista|marka|render|galeria` animacje z biblioteki (`narzedzia/animacje/animacje.js`, własne presety w `narzedzia/animacje/wlasne/`) jako MOV z przezroczystością, w kolorach i foncie marki; 197 presetów w kategoriach tekst, belki, rolki, cta, liczby, przejscia; panel renderuje je bez After Effects (kodek Animation, szybki podgląd w Premiere) z 15 s zapasu na końcu: gdy użytkownik wydłuży albo skróci klip animacji na osi, panel sam renderuje ją od nowa w tej długości (wyjście zostaje na końcu); „Animacje z mowy” w panelu: mózg tylko planuje (`narzedzia/animacje/z_mowy.md`, plan w `plan_animacji.json`), a panel renderuje i wstawia, więc wszystko jest edytowalne
- `python narzedzia/kolor.py kamery|wykryj|luty|dodaj-lut|usun-lut|instaluj-luty|plan` narzędzie Kolor (panel: Kolor): dane kamer (`narzedzia/kolor/kamery.json`: natywne ISO, profile, porady), klimaty (`klimaty.json`), biblioteka LUT-ów użytkownika z przypisaniem do kamery i profilu (`narzedzia/kolor/luty.json`), rozpoznanie kamery i profilu (metadane, XML Sony, SRT DJI, BRAW), pomiar ujęć po LUT-cie i plan wyrównania; panel nakłada to w Lumetri (skrypty Premiere wybierają LUT tylko po pozycji na liście: `narzedzia/kolor/luty_pozycje.json`)
- `python narzedzia/audio_asystent.py analizuj|miks` asystent audio jak AI Audio Assistant w DaVinci (obróbka w `narzedzia/audio_dsp.py`): rozpoznaje mowę, muzykę, efekty i tło; diagnoza każdego nagrania mowy (szum, pogłos, buczenie 50/60 Hz, przestery, syczenie); mowa: naprawa przesterów, usuwanie buczenia, odszumianie (RNNoise z `narzedzia/audio_modele/` + afftdn), usuwanie pogłosu (WPE + wygaszanie ogona), dopasowanie barwy mikrofonów i korekcja, de-esser, wyrównanie fraz, kompresja, bramka z wyciszaniem przebić innych mikrofonów; muzyka ściszana pod mową z miejscem na głos; mastering pod standard (YouTube -14, podcast -16, EBU -23, ATSC -24, Netflix -27 z pomiarem mowy) z limiterem true peak; wynik: miks + osobne szyny (mowa, muzyka, efekty, tło) i `asystent_raport.txt`; panel wstawia je zawsze do kopii sekwencji „… - miks AI” (`nm_miks_w_kopii`), oryginalnej sekwencji nie zmienia; opcjonalnie izolacja głosu ElevenLabs (kredyty, tylko gdy użytkownik zaznaczy); dźwięk bierze z WAV-ów wyeksportowanych przez Premiere (`--z-premiere`, każda ścieżka osobno, tak jak gra na osi), z XML tylko położenie klipów; numery ścieżek audio zawsze jak w Premiere (`ciecie.mapa_sciezek_audio`: ścieżka stereo to w XML dwie ścieżki)
- `python narzedzia/postep.py --etap X | --gotowe | --blad` etapy zadania dla paska postępu w panelu Premiere (bez panelu nic nie robi)
- `python narzedzia/szablony.py lista|render|galeria` 127 szablonów rolek w kategoriach (`narzedzia/szablony/szablony.js`): zdjęcia, teksty, liczby, cytaty, promocje, porady, opinie i inne; `render --szablon X --wartosci '<json>' --klient <folder> --wyjscie plik.mov [--podglad] [--ae opis.json]`; `--ae` zapisuje opis do zbudowania kompozycji w After Effects (`narzedzia/szablony/ae_buduj.jsx`)
- `python narzedzia/wzor.py analizuj --plik wzor.mp4 --folder X [--mowa auto]` rozbiór rolki-wzoru: ujęcia i cięcia, arkusze kadrów, tempo muzyki, cięcia w bit, mocne uderzenia dźwięku (skill `jak-wzor`)
- `python narzedzia/limity.py` pasek stanu Claude Code z limitami (5 h, tydzień, godziny odnowienia) i zapis zużycia na rodzaj zadania; `--pokaz` wypisuje stan
- `python narzedzia/mozg.py sprawdz|instaluj|polacz|epidemic|test|tryb|pelne` drugi „mózg”: Gemini przez Antigravity CLI (`agy`, logowanie kontem Google, limity abonamentu Google AI Pro, bez klucza API); Antigravity zezwala w tle tylko na polecenia zapisane znak w znak, więc Gemini uruchamia narzędzia przez pomocnika `python narzedzia/uruchom.py` (prośba w `polecenie_gemini.json`, zasady w `AGENTS.md`; wolno tylko narzędzia z `narzedzia/`, ffmpeg i ffprobe); `instaluj` daje zgodę na pomocnika, `test` sprawdza go w tle (wynik w `_system/studio/agy_test.txt`), `tryb accept-edits|piaskownica` wybiera tryb zadań w tle; wybór Claude/Gemini jest w Studio (zakładka Console) i na ekranie głównym panelu; zasady dla Gemini są w `AGENTS.md` i `GEMINI.md` (odsyłają tutaj)
- `python narzedzia/mozgi_inne.py katalog|lista|dodaj|usun|test` inne mózgi poza Claude i Gemini (Codex, GitHub Copilot CLI, Gemini CLI, Qwen Code, OpenCode albo własny program), dodawane w apce: lista w `_system/mozgi.json` z wynikiem testu (czy uruchamia narzędzia, ma internet, czyta i zapisuje pliki, widzi obrazy, trzyma się zasad); „Wykonaj” w Studio uruchamia je w tle z poleceniem w pliku (`polecenie_N.md` w `_system/studio/<id>/`)
- `python narzedzia/mcp_studio.py --instaluj` mały serwer dla aplikacji Claude na PC: Studio pokazuje z niego limity, stan kluczy (tylko tak/nie), otwiera plik `.env` w Notatniku, zapisuje style napisów ze Studio (`narzedzia/napisy_style_moje.json`) i uruchamia polecenia z przycisku „Wykonaj” (Claude Code w tle)

Parametry każdego narzędzia pokaże `--help`. Opis formatu `plan.json` jest na górze `montaz.py` (w tym `nakladki`: animacje i szablony MOV/WEBM z przezroczystością na osi rolki).

Własne rozmiary grafik ze Studio przychodzą jako `wlasny-<szer>x<wys>` (np. `wlasny-2000x500`); `grafika.py` i `formaty.py` rozumieją je same.

## Foldery

- `klienci/<folder>/` zawiera `logo.png`, `fonty/` (.ttf/.otf) i opcjonalnie `makiety/`, czyli ekrany aplikacji klienta do wstawiania w rolki
- `envato/` to pliki pobrane ręcznie z Envato Elements. Envato nie ma API do pobierania, więc nigdy nie próbuj pobierać z Envato automatycznie
- `muzyka/` to podkłady z licencją
- `nagrania/<sesja>/` to nagrania użytkownika; analiza ląduje w `_analiza/` obok i jest używana ponownie
- `klienci/<folder>/referencje/wideo/` to filmy-wzory, `klienci/<folder>/referencje/grafiki/` to grafiki-wzory. Starsze pliki wideo leżące bezpośrednio w `referencje/` traktuj jak wideo.
- `klienci/<folder>/styl_wideo.md` i `styl_grafiki.md` to notatki stylu napisane z referencji (starszy `styl.md` traktuj jak `styl_wideo.md`)
- `materialy/<zadanie>/` to zdjęcia i pliki użytkownika do grafik
- `klienci/<folder>/brandbook/` to brandbook (PDF), warianty logo, palety; `klienci/<folder>/marka.md` to notatka marki, którą piszesz z brandbooka i przykładów
- `napisy/<zlecenie>/` to gotowe filmy do generatora napisów; wyniki w `napisy/<zlecenie>/gotowe/`, robocze pliki w `_napisy/`
- `fonty/<Nazwa>/` to wspólne fonty pobierane automatycznie z Google Fonts dla napisów (nie trzeba ich ruszać)
- foldery tworzy i otwiera przyciskami w Studio narzędzie `narzedzia/foldery.py`; jeśli potrzebnego folderu nie ma, utwórz go sam (`python narzedzia/foldery.py --otworz <ścieżka>` tworzy też instrukcję CZYTAJ.txt)
- `klienci/<folder>/makiety/<kod języka>/` to makiety w danym języku (`pl`, `sv`...), te same nazwy plików w każdym języku; pliki leżące bezpośrednio w `makiety/` traktuj jak polskie
- `wyniki/<Klient>/<Tytuł zadania>/` to folder jednego zadania (nazwa klienta i tytuł jak w Studio). Tworzy go zawsze `python narzedzia/wspolne.py --klient "<klient.nazwa>" --klient-folder "<klient.folder>" --projekt "<zadanie.tytul>" --id "<zadanie.id>"` (w skillach stoi `--klient "<klient.skrot>"`: podawaj zamiast tego `klient.nazwa`, `klient.folder` i `--id`). Pracujesz w nim jak dotąd (podfoldery `r1/`, `sceny/`, `grafiki/`...), a **na sam koniec, przed raportem i przed `postep.py --gotowe`, uruchom `python narzedzia/porzadek.py zadanie --folder <folder>`**: gotowe pliki trafiają na wierzch z czytelnymi nazwami („Rolka 1.mp4”, „Aftermovie poziom.mp4”, grafiki), `Projekty/` dostaje timeline'y Premiere i pliki PSD, `Materiały/` całą resztę (ścieżki w XML i JSON poprawia sam). W raporcie i w `postep.py --gotowe --xml/--wideo` podawaj już ścieżki z wyniku porządku (`gotowe`, `timeline_premiere`). Poprawki: to samo `--id` daje ten sam folder; pracuj w nim, a porządek przeniesie poprzednie gotowe pliki do `Materiały/Poprzednie wersje/`. Rzeczy wstawiane z panelu na oś (animacje, napisy) leżą w `wyniki/<Klient>/Panel Premiere/` i ich nie przenosisz.
- `_system/` to pliki silnika (przebiegi zleceń, rejestr panelu, mapa proksy, licznik, stock, prośby Gemini, testy). Nie zapisuj tam wyników zadań i nie twórz w `wyniki/` folderów zaczynających się od `_`.
- `zlecenia/<klient>_<projekt>_<DDMMRR>/` to pliki do narzędzi ze Studio (transkrypcja, pion, dźwięk, formaty...); wyniki narzędzi trafiają do podfolderu `gotowe/`
- `klienci/<folder>/logo/` to wszystkie wersje logo (kolorowe, białe na ciemne tła, czarne, sygnet); `logo.png` w folderze klienta to wersja domyślna. Do każdego tła wybieraj wersję o dobrym kontraście (na zdjęciach i ciemnych tłach zwykle białą) i zapisz wybór w `marka.md`
- `klienci/<folder>/fonty/` to pliki fontów marki

## Zasady

1. **Plan przed wydawaniem.** Gdy zadanie ma `plan_przed_startem: true`, najpierw pokaż plan scen z serwisami i kosztem, i czekaj na zgodę. Bez zgody nie generuj niczego płatnego.
2. **Limity na rolkę:** 1 klip wideo AI (Magnific lub Higgsfield łącznie), 6 obrazów AI, 3 podejścia do lektora. Więcej tylko po zapytaniu. Najpierw generuj obraz, obejrzyj go (Read), a dopiero dobry animuj.
3. **Klucze.** Klucze API są tylko w `.env` (połączenia Gemini także w `.agents/mcp_config.json`). Nigdy ich nie wypisuj, nie kopiuj i nie próbuj czytać tych plików.
4. **Marka.** Kolory i zasady wizualne bierz z `marka.md` (sekcja „Marka i brandbook”), a gdy jej nie ma, z `paleta` i `kolory_uwagi` z zadania. Fonty, ton, CTA i zakazane słowa z danych klienta. Zakazów pilnuj w lektorze, napisach i grafikach.
5. **Prompty do generatorów** pisz po angielsku. Kadr pionowy 9:16, bez napisów i logotypów w obrazie, bez rozpoznawalnych osób publicznych. Napisy dodaje montaż.
6. **Kontrola.** Zanim powiesz, że rolka jest gotowa, wytnij kadry (`montaz.py klatki`) i obejrzyj je: czytelność napisów, nic ważnego nie zasłonięte, logo na miejscu.
7. **Raport.** Na końcu podaj ścieżkę do pliku, długość, z czego zrobione sceny i ile generacji zużyto w każdym serwisie. Przypomnij o wgraniu pliku w Studio. Gdy gotowe pliki nie są filmem z `montaz.py`, plikiem w `gotowe/` ani grafiką z `grafiki/`, zapisz w folderze zadania `gotowe.json`: `{"pliki": ["ścieżki gotowych plików względem folderu zadania"]}`. „Zobacz wyniki” w Studio pokazuje tylko gotowe rzeczy, a materiały robocze dopiero po kliknięciu.
8. **Zmiany w silniku.** Narzędzia (`narzedzia/`), skille i panel to kod użytkownika: poprawiaj w nich tylko drobny, oczywisty błąd, który blokuje zadanie, bez przerabiania działania i bez zmiany zgód. Każdą zmianę wypisz w odpowiedzi i w `raport.md` w sekcji „Zmiany w silniku” (plik, co było źle, co zmieniłeś). Większy błąd tylko opisz w raporcie.
9. Jeśli serwis zwróci błąd, którego nie da się naprawić w kodzie (brak środków, zły klucz), powiedz to wprost i zaproponuj inny serwis z listy `serwisy`.

## Grafiki w trybie Nano Banana (`zadanie.tryb_grafiki: "nano"`)

Użytkownik wybrał, że całą grafikę (tło, tekst, układ) robi Nano Banana (Gemini), taniej i szybciej, bez edytowalnego PSD. Gemini jest wtedy dozwolony, nawet jeśli nie ma go w `serwisy`. Kroki 1 i 2 skilla `grafika` robisz tak samo (folder, marka, `teksty.md`), potem zamiast kroków 3–5 tego skilla:
1. Plan (przy `plan_przed_startem: true` pokaż go i czekaj na „ok”): ile obrazów powstanie (grafiki × formaty); obrazy idą z limitów abonamentu Google AI Pro przez Antigravity (każdy obraz to kilkadziesiąt sekund, narzędzie robi 2 naraz). **Limit obrazów w abonamencie jest mały: po kilkunastu obrazach Antigravity odpowiada „429 RESOURCE_EXHAUSTED” i odnawia limit dopiero po kilku godzinach.** Gdy obrazów ma być więcej niż 12, powiedz to w planie i zaproponuj: najpierw format główny (pierwszy z listy) dla wszystkich grafik, pozostałe formaty po odnowieniu limitu (`--brakujace`), albo mniej formatów.
2. Zbuduj `<folder>/nb.json` według opisu na górze `narzedzia/gemini.py` (sekcja „Plan dla grafika”): `formaty` z zadania; `wspolne` po angielsku: kolory marki w HEX z `marka.md`, font nagłówków (nazwa i grubość), nastrój ze `styl_grafiki.md` (gdy `zadanie.styl.zrodlo` nie jest `marka`, zamiast tego według sekcji „Styl zadania” niżej); `logo` = wariant logo z dobrym kontrastem (z `marka.md`), `logo_miejsce` zgodnie ze stylem; dla każdej grafiki `prompt` po angielsku: co jest na obrazie, gdzie stoi tekst (`zadanie.uklad`), a teksty z `teksty.md` po polsku w cudzysłowie (nagłówek, podtytuł, CTA); zdjęcia użytkownika albo produktu w `obrazy` (model użyje ich jako materiału).
3. `python narzedzia/gemini.py grafika --plan <folder>/nb.json` (dogenerowanie tylko brakujących: dopisz `--brakujace`; tylko wybrane od nowa: `"od_nowa": true` albo lista formatów przy grafice). Styl ze Studio (`zadanie.styl`) narzędzie stosuje samo z `zadanie.json` w folderze zadania: przy `referencje`/`tylko_referencje` samo dokłada referencje klienta jako obrazy wejściowe i każe kopiować ich wygląd, więc przy `tylko_referencje` NIE wpisuj do `wspolne` kolorów, fontów ani nastroju marki (tylko układ i treść). Wynik ma listę `brakuje`: tych obrazów nie ma (np. skończył się limit); nigdy nie podstawiaj w ich miejsce innych plików, tylko napisz, kiedy je dogenerować. Lista `z_tlem`: model oddał zły kształt i obraz jest wpasowany z rozmytym tłem po bokach (nie przycięty); obejrzyj je i słabe zrób od nowa. Nie poprawiaj `gemini.py` ani `obraz_agy.py` w trakcie zadania (zasada 8): opisz problem w raporcie.
4. Obejrzyj `podglad_serii.jpg` (Read). Sprawdź pisownię każdego napisu litera po literze i polskie znaki. Złą grafikę wygeneruj jeszcze raz (popraw prompt, np. krótszy tekst), najwyżej 2 razy bez pytania; potem napisz, która ma błąd.
5. Raport jak w kroku 6 skilla, ale bez Photoshopa: napisz, że tekst jest częścią obrazu (do zmian trzeba wygenerować ponownie) i ile obrazów zużyto.

## Styl zadania (`zadanie.styl`) ma pierwszeństwo przed marką

Czasem użytkownik chce dla klienta coś zupełnie innego niż brandbook (np. celowo krzykliwe, tandetne, „brzydkie” grafiki). Zadanie ze Studio może mieć `"styl": {"zrodlo": "...", "opis": "...", "bez_logo": true/false}`. Ta sekcja ma pierwszeństwo przed „Marka i brandbook”, przed `marka.md` i przed skillami:
- `zrodlo: "marka"` (albo brak pola `styl`): jak zwykle, według `marka.md`.
- `zrodlo: "referencje"`: najpierw obejrzyj referencje klienta (Read: `referencje/grafiki/` przy grafikach, arkusze z `referencje/wideo/` przy wideo; 3–6 najbardziej typowych) i trzymaj się ich: układ, ilość tekstu, kolory, rodzaj fontów (podobny font znajdziesz przez `fonty.py lista --szukaj`), tła, ramki, nastrój. Z marki bierzesz tylko to, czego referencje nie rozstrzygają (np. logo, CTA). Gdy `styl_grafiki.md` albo `styl_wideo.md` są sprzeczne z tym, co widzisz w referencjach, wierz referencjom i popraw notatkę.
- `zrodlo: "tylko_referencje"`: kolorów, fontów i zasad wizualnych z `marka.md`, `styl_grafiki.md` i brandbooka NIE używasz wcale (także ich list „unikać”: jeśli referencje mają czerwone kółka, szeryfowe fonty albo białe tło, robisz tak samo). Wszystko wizualne bierzesz z referencji jak wyżej. Zostają tylko rzeczy merytoryczne: nazwa marki, CTA, zakazane słowa.
- `zrodlo: "opis"`: wygląd według `styl.opis`, bez marki i bez referencji (poza treścią: CTA, zakazane słowa).
- `styl.opis` (gdy jest) zawsze wygrywa ze wszystkim innym. „Brzydko”, „tandetnie”, „chamsko”, „jak z bazaru” to świadomy wybór użytkownika: nie poprawiaj tego w stronę eleganckiego designu.
- `bez_logo: true`: żadnego logo (w grafikach `"logo": false` w `seria.json`, w nano bez `logo`, w rolkach bez logo i bez logo na planszy).
- Grafiki w trybie `psd` (`grafika.py seria`) mają zawsze ten sam układ (tło, przyciemnienie, nagłówek, przycisk); dobierz `kolory`, `font`, `uklad` i tła tak, żeby było jak najbliżej referencji albo opisu, a w raporcie napisz wprost, że do wiernego wyglądu referencji lepszy jest tryb Nano Banana. W trybie `nano` dodaj 2–3 najbardziej typowe referencje do `obrazy` w `nb.json`, a w `wspolne` napisz po angielsku, że model ma skopiować styl referencji (układ, typografię, kolory, poziom „kiczu”), z nową treścią.
- W raporcie napisz jednym zdaniem, czym się kierowałeś (marka, referencje, opis).

## Marka i brandbook

Użytkownik nie przypisuje kolorów do ról. Robisz to Ty, raz na klienta, i zapisujesz w `klienci/<folder>/marka.md`.
1. Na początku każdego zadania: `python narzedzia/marka.py sprawdz --folder <klient.folder>`.
2. Stan `brak` albo `nieaktualna`: przeczytaj pliki z `brandbook/` (PDF czytaj narzędziem Read po kawałku, maks. 20 stron naraz, najpierw spis treści i strony o kolorach, typografii i logo), obejrzyj obrazy z `brandbook/` i `referencje/grafiki/`, przeczytaj `styl_wideo.md`, jeśli jest. Weź pod uwagę `paleta` i `kolory_uwagi` z zadania. Napisz `marka.md`:
   - na górze blok JSON z rolami kolorów, którego używasz w planach: `{"tlo_ciemne": "#..", "tlo_jasne": "#..", "tekst_na_ciemnym": "#..", "tekst_na_jasnym": "#..", "akcent": "#..", "przycisk": "#..", "tekst_przycisku": "#..", "podswietlenie_napisow": "#..", "tlo_plansza_koncowa": "#.."}`
   - kolory: nazwy z brandbooka, proporcje (ile koloru marki), dozwolone i zakazane połączenia
   - typografia: font nagłówków i tekstu, grubości, wielkie litery czy nie
   - logo: który plik na jasne, który na ciemne tło (ścieżki), minimalna wielkość, pole ochronne, czego nie robić
   - styl zdjęć i grafik, ton, rzeczy zakazane
   Krótko, w punktach. Powiedz użytkownikowi jednym zdaniem, że notatka marki powstała.
3. Stan `aktualna`: przeczytaj `marka.md` i trzymaj się jej. Stan `brak_zrodel`: użyj palety i uwag z karty klienta; jeśli i ich nie ma, dobierz kolory z logo.
4. Role z `marka.md` przekładaj na pola narzędzi: grafiki (`kolory`: `primary` = tło ciemne, `accent` = przycisk, `text` = tekst na ciemnym, `highlight` = akcent), plansza końcowa rolki, domyślne napisy (gdy zadanie nie ma stylu napisów: font nagłówków, `aktywne_tlo` = podświetlenie napisów). Logo: jeśli `brandbook/` ma lepszy wariant na dane tło niż `logo.png`, podaj go w planie (`logo`).

## Napisy

- `zadanie.napisy` to styl napisów ustawiony w Studio (opis pól na górze `narzedzia/napisy.py`). Wstaw go do `plan.json` jako `"napisy"` bez zmian. `false` = rolka bez napisów (`"napisy": false`). Brak pola = styl domyślny z marki (sekcja wyżej).
- Gdy styl ma `kluczowe_wl: true`, zaznacz słowa kluczowe: w pliku słów (`slowa.json` lektora albo `_slowa.json` nagrania; jedno słowo w linii) dopisz `"wazne": 1` do 1 najważniejszego słowa na fragment (liczby, nazwy, obietnica), `2` i `3` rzadko, dla drugiego i trzeciego rodzaju (np. słowa negatywne). Nie więcej niż co piąte słowo.
- Font napisów: silnik szuka go w `fonty/` klienta, potem pobiera właściwą grubość z Google Fonts do `fonty/<Nazwa>/`. Jeśli wynik podaje inny font niż w stylu (zapasowy), powiedz o tym.
- Gotowe style (64 w 8 grupach) są w `narzedzia/napisy_style.json`; Studio i panel pokazują je w galerii. Podgląd na płótnie: `narzedzia/napisy_podglad.js`.
- Podgląd stylu bez renderu rolki: `python narzedzia/napisy.py podglad --styl <styl.json> --wyjscie podglad.png [--plik film.mp4]`.

## Własne nagrania

1. `python narzedzia/analiza.py folder --folder <nagrania_folder>`. Przeczytaj wynik, obejrzyj arkusze kadrów (Read) i przeczytaj frazy mowy w plikach `_analiza/*.json`.
2. Gadająca głowa: buduj rolkę z wypowiedzi. Wybierz najmocniejsze zdanie na hak, potem treść, na końcu CTA. Tnij na granicach fraz (pola `od`/`do`), nigdy w środku słowa; zostaw 0,1 s zapasu. W scenie: `"start"`, `"czas"`, `"dzwiek": true`, `"slowa": <plik _slowa.json>`. Przebitki (B-roll, stock) kładź na fragmentach, gdzie mówiący nie musi być widoczny: scena z obrazem przebitki dostaje `"dzwiek": true`, `"dzwiek_z": {"plik": <klip z twarzą>, "start": <dalszy ciąg wypowiedzi>}` i to samo `"slowa"`, więc mowa i napisy lecą dalej bez przerwy. Zaczynaj i kończ rolkę na twarzy.
3. B-roll bez mowy: lektor z ElevenLabs, ujęcia dobierane do zdań lektora; najlepsze fragmenty wybieraj z arkuszy (ostre, stabilne, bez przypadkowych osób).
4. W planie przy scenach z oryginalnym dźwiękiem ustaw `"dopasuj_do_lektora": false`.
5. Nie oceniasz ostrości ani drgań z pewnością, bo widzisz pojedyncze klatki. Jeśli masz wątpliwość, napisz o tym w raporcie.

## Referencje i styl

- **Wideo:** jeśli klient ma pliki w `referencje/wideo/` (albo starsze bezpośrednio w `referencje/`), a nie ma `styl_wideo.md` (albo przybyły nowe pliki), zrób `python narzedzia/analiza.py referencje --folder <folder klienta>/referencje/wideo`, obejrzyj arkusze i napisz `styl_wideo.md`: długość, tempo (średnia długość ujęcia, słowa na sekundę), budowa (hak, treść, CTA), styl napisów, przejścia, muzyka, rodzaj ujęć, czego unikać. Krótko, w punktach.
- **Grafiki:** jeśli klient ma obrazy w `referencje/grafiki/`, a nie ma `styl_grafiki.md`, obejrzyj je (Read, po kolei) i napisz `styl_grafiki.md`: gdzie stoi tekst (układ: dol/gora/srodek/lewo/prawo), jak długie nagłówki, czy jest podtytuł i CTA, rodzaj zdjęć (ludzie, produkt, abstrakcja), jasne czy ciemne tła, ile koloru marki, czego unikać.
- Przy każdym zadaniu czytaj właściwą notatkę i trzymaj się jej. Nie analizuj referencji ponownie, jeśli notatka jest aktualna, chyba że w briefie jest „odśwież styl”.

## Wersje językowe

- Po zakończeniu rolki sprawdź podfoldery `makiety/` klienta. Jeśli są języki inne niż polski, zapytaj jednym zdaniem: „Robimy też wersję: SV?” (wymień kody z folderów). Nie pokazuj tłumaczenia do akceptacji, użytkownik nie zna tych języków.
- Po „tak” dla każdego języka: przetłumacz tekst lektora (naturalnie, marketingowo, z zachowaniem zakazów klienta), głos z pola `jezyki` w karcie klienta (jeśli brak, użyj głównego głosu modelem multilingual i napisz w raporcie, że może być słychać akcent), te same sceny, makiety podmienione na pliki o tych samych nazwach z `makiety/<kod>/`, plansza i CTA z pola `jezyki` albo przetłumaczone. Sceny z mową w nagraniu dostają przetłumaczone napisy (`napisy_wlasne` według fraz), oryginalny dźwięk zostaje.
- Plik: `rolka_<kod>.mp4` w tym samym folderze zadania; plan `plan_<kod>.json`. Nie generuj ponownie płatnych scen.

## Dźwięk nagrań

Gdy zadanie ma `popraw_dzwiek: true`, a sceny używają oryginalnej mowy: `python narzedzia/dzwiek.py folder --folder <nagrania_folder>` (domyślnie AI ElevenLabs; `--silnik ffmpeg` to darmowa lżejsza wersja, użyj jej, gdy brak kredytów). W planie każda scena z mową dostaje `"dzwiek_z": {"plik": "<..._czysty.wav>", "start": <ten sam start co mowa>}`. Plik ma tę samą długość co klip, więc czasy się zgadzają. W raporcie podaj minuty przepuszczone przez ElevenLabs.

## Muzyka i efekty

- Dobieraj muzykę do nastroju, tempa i grupy docelowej (styl z `styl_wideo.md`, jeśli jest). Pod mową: spokojniejsza, bez wokalu.
- `epidemic`: wyszukaj (nastrój, gatunek, BPM, bez wokalu), wybierz 1 utwór, jeśli się da, dotnij go narzędziem do długości rolki (edit to length), pobierz do `<folder zadania>/muzyka.mp3` i ustaw w `plan.json` w `muzyka`. W raporcie podaj tytuł i autora.
- `artlist`: wyszukaj i pokaż 3 propozycje (tytuł, nastrój, link). Poproś o pobranie wybranej do `muzyka/` i poczekaj. Generowanie muzyki AI w Artlist tylko po wyraźnej zgodzie (kosztuje kredyty).
- Brak obu: użyj pliku z `muzyka/`, jeśli pasuje, albo zrób rolkę bez muzyki i napisz o tym.
- Efekty (whoosh przy przejściach, klik przy makiecie): z `epidemic`, z plików w `muzyka/efekty/` albo z wbudowanej biblioteki `narzedzia/dzwieki/` (whoosh, swish, hit, flash, riser; darmowe, zrobione syntezą przez `narzedzia/efekty.py`); w planie `efekty_dzwiekowe` z czasem na osi rolki. Oszczędnie.
- **Dynamiczne przejścia zawsze z dźwiękiem.** Gdy w filmie są whip, smuga, zoom, koło, pixel, rozmycie albo flash, w planie ustaw `"efekty_auto": true`: montaż sam kładzie whoosh, swish albo błysk tak, żeby szczyt dźwięku wypadł w środku przejścia (pliki z `muzyka/efekty/` z „whoosh”, „swish”, „hit”, „flash” w nazwie mają pierwszeństwo). Wyłącz tylko, gdy zadanie ma `"efekty_dzwiekowe": false` (montaż czyta to też sam z `zadanie.json`). W raporcie napisz, ile efektów doszło i skąd.

## Ruch kamery i przejścia

- `"ruch"` w scenie: przybliz, oddal, pan-prawo, pan-lewo, pan-gora, pan-dol, brak. Obrazy zawsze z ruchem; wideo z ruchem tylko, gdy ujęcie jest statyczne.
- `"przejscie"` (do tej sceny): ciecie (domyślnie), zoom-in, zoom-out, whip-lewo/prawo/gora/dol, smuga-lewo/prawo, fade, przenikanie, czern, flash, kolo, rozmycie, pixel, zoom-przenikanie.
- `zadanie.przejscia`: „tylko-ciecia”: same cięcia; „oszczedne” (domyślnie): 1–3 przejścia na rolkę w miejscach zmiany tematu, reszta cięcia; „dynamiczne”: przejście przy większości zmian scen, ale nie przy każdej. Zawsze zgodnie ze `styl_wideo.md`, jeśli jest.
- Przy gadającej głowie nie rób przejść w środku zdania; whip i zoom kładź na granicy fraz. Do planszy końcowej zwykle `czern` albo `fade`.

## Eksport do Premiere

- Gdy `plan.json` ma `"premiere": true`, montaż zapisuje folder `premiere/` obok filmu: `<nazwa>.xml` (Final Cut Pro XML, Premiere go importuje), `<nazwa>_napisy.srt`, `plansza.png`, `logo_nakladka.png`, `CZYTAJ.txt`.
- Sekwencja ma te same cięcia co film: V1 ujęcia (wskazuje oryginały RAW zamiast proksy), V2 logo, dźwięk nagrań, lektor, muzyka i efekty dźwiękowe na osobnych ścieżkach audio (puste ścieżki są pomijane). XML ma same cięcia i markery z nazwą przejścia (Premiere 2026 zawieszał się przy imporcie XML z przejściami); wszystkie przejścia kładzie panel po imporcie jako wbudowane przejścia Premiere (Cross Dissolve, Dip to Black, Dip to White, Push, Cross Zoom, Iris Round, według `premiere/<nazwa>_dodatki.json`) i przy okazji sprawdza, czy muzyka i efekty są na osi (jak nie, dokłada je sam). Ruchy kamery na zdjęciach są markerami.
- Napisy wypalone w filmie są też w pliku SRT obok, do importu jako napisy.
- Pole `uwagi` w wyniku eksportu przekaż użytkownikowi.

## Pliki RAW (BRAW, R3D)

ffmpeg ich nie odczyta. Analiza i montaż pracują na proksy, eksport do Premiere wskazuje oryginały (mapa proksy → oryginał w `_system/proksy/mapa.json`). Proksy: podpięte w Premiere (panel zapisuje je w `proksy.json` w folderze zadania), podfolder `_proksy/` obok nagrań albo foldery z proksy ustawione w panelu (`narzedzia/proksy_foldery.json`, zwykle `D:\PROXY PREMIER`; nazwa proksy zaczyna się od nazwy oryginału, np. `A039_C001_Proxy.mp4`). Gdy klip w `material_premiere.json` ma pole `proksy`, w planie montażu podaj jako plik sceny właśnie je. Użytkownik może też zrobić proksy w DaVinci Resolve: Deliver > Individual clips > MP4 H.264 > nazwa pliku jak źródło.

