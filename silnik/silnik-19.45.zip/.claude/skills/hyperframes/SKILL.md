---
name: hyperframes
description: Podręcznik HyperFrames (animacje i grafiki ruchome z HTML i GSAP). Używaj tylko, gdy skill silnika (animacje, rolka, jak-wzor) albo `CLAUDE.md` każe zbudować animację w HyperFrames przez `python narzedzia/ruch.py`.
---

> **W silniku Nada Studio** ten skill jest dodatkiem od innego autora (HeyGen, HyperFrames, Apache-2.0). Skille silnika (`rolka`, `grafika`, `animacje`, `jak-wzor`, `brandbook`, `napisy`) i `CLAUDE.md` mają pierwszeństwo: przy sprzeczności wygrywają one. Pracujesz bez użytkownika przy komputerze: niczego nie pytasz i nie czekasz na podgląd, decyzje bierzesz z zadania. Nigdy nie zakładasz kont, nie logujesz się, nie płacisz, nie instalujesz programów, nie czytasz i nie zapisujesz kluczy API, nie wysyłasz plików klienta do chmury.
> HyperFrames uruchamiasz tylko przez `python narzedzia/ruch.py` (wersja przypięta w silniku, telemetria wyłączona): zamiast `npx hyperframes <polecenie>` pisz `python narzedzia/ruch.py hf <polecenie>`. Nowy projekt: `python narzedzia/ruch.py nowy --folder <folder zadania>/ruch/<nazwa>` (zamiast `init`), render z kolorami i fontami marki: `python narzedzia/ruch.py render --projekt <folder> --wyjscie <plik.mov> --podglad`. GSAP z `lib/gsap.min.js`, kolory i fonty z `lib/marka.css` (zmienne `--glowny`, `--akcent`, `--tekst`, `--font`), zamiast CDN i Google Fonts. Zakazane: `cloud`, `publish`, `auth`, `billing`, `feedback`, `usage`, `lambda`, `cloudrun`, `upgrade`, `preview`, `open`, `media-use`, `reverse-any-video`, HeyGen (awatary, lektor, muzyka). Muzyka, lektor i efekty: narzędzia silnika (`CLAUDE.md`, „Muzyka i efekty”). Zasady wyglądu: sekcja „Gust” w `CLAUDE.md` i `narzedzia/ruch/BIBLIOTEKA.md`.

# HyperFrames

HyperFrames renders HTML to video by seeking a paused timeline frame by frame, so every render is identical; the person edits the same files in the Studio preview. Run the CLI as `python narzedzia/ruch.

`index.html` is the root composition: it declares the video's variables and mounts one scene per sub-composition from `compositions/`. Media and fonts live in `assets/`. A new project: `python narzedzia/ruch.py nowy --folder <dir>`. A website as the subject: `python narzedzia/ruch.py hf capture <url> --json`.

Build what was asked: no voiceover or captions and no new aspect ratio unless the request or the source calls for them; a film over ~15 s that tells something gets music and sound on its visible actions unless the person asked for silence (`references/sound.md`). A new video is 1920×1080 at 30 fps. A question, a hold or a loose idea gets an answer or a proposal, not an edit. Before hand-writing a named effect, transition, caption style, chart or card, search the registry (`/hyperframes-registry`). Media (footage, photos, music, voice, sound effects) come from the engine's own tools, never from HeyGen. Show real things from their source (the product's screens, the brand's logo, a real place's imagery); draw only what has none.

## Contract

`python narzedzia/ruch.py hf check --json` reports most violations with a `Fix:` line.

1. Every timed element has `class="clip"`, `data-start` and `data-duration` in seconds, and shows over `[start, start + duration)`: land an end state just before its end. `data-track-index` is only a Studio lane; paint order is `z-index`.
2. The video's length is the root's `data-duration`: overrun is cut, an early end holds the last frame.
3. Each composition builds one paused timeline and registers it after its tweens: `window.__timelines["<data-composition-id>"] = tl`.
4. No `Date.now()`, unseeded `Math.random()`, network fetches, timers or `repeat: -1`. Everything visible is a function of timeline time.
5. Never tween `display`, `visibility` or `autoAlpha` on a `.clip`; animate a child.
6. No CSS `transform` on an element GSAP transforms; animate transforms, not `left`/`top`/`width`/`height`.
7. Never `play()`, `pause()` or seek media. A `<video>` keeps its sound with `data-has-audio="true"`, else it is `muted`; music, voice, replacement sound and J/L cuts are a separate `<audio>`.
8. Every `<audio>` has an `id` or it is left out of the mix. No `crossorigin` on media. Time the `<video>`, never its wrapper.
9. Only the bundled fonts (`references/format.md`) resolve by name; any other family needs `@font-face` to a file in `assets/fonts/`.
10. Asset paths: `assets/...` (no leading `/`), in sub-compositions too.
11. Grades, grain, blur and vignettes on footage go through `python narzedzia/ruch.py hf media-treatment` (`/media-use`), never CSS filters.
12. A scene file puts its styles, markup and scripts inside `<template>` and styles its root as `#root`. Intended overflow or overlap: `data-layout-allow-overflow`, `data-layout-allow-overlap`.

## Keep it editable

Studio edits the tags you write.

- One scene per sub-composition, short readable ids; the root holds only scene hosts, media and audio.
- Timed elements are written in the HTML, not made by script, each with a stable `id`.
- Copy, brand colours and swappable media are variables (`data-var-text`, `data-var-src`, `var(--id)`).
- One kind per track: `data-track-kind="graphics"` on scene and overlay hosts, `captions` on the one host that holds every caption group.
- Content stays inside the 90% action-safe box, captions and key text inside 80% title-safe; Studio draws the guides, never add them.

## Work loop

- An existing project: `python narzedzia/ruch.py hf timeline --json` shows what plays when; before any change, `python narzedzia/ruch.py hf history --since mine --who <you>` shows what the person changed since your last turn: build on it (`/hyperframes-cli`).
- A new film over ~15 s that tells something: its type's file (below), then `references/story.md`: three storylines that are three different films, in words only; pick the one that best fits the job brief yourself. Then `SPEC.md` (`references/spec.md`): every adjective as a number, the defaults banned by name, the shots by frame.
- After your last edit: `python narzedzia/ruch.py hf check --json`; fix every error, weigh every warning. A film: `python narzedzia/ruch.py hf snapshot --review` and `references/review.md`, ending in `REVIEW.md`. A small edit: snapshot what you changed (`--at`, `--range`, `--composition`) and look before you reply.
- Render locally with `python narzedzia/ruch.py render` after your check and review pass; never wait for a preview (nobody is at the computer).


## What to read

| The request | Read |
| --- | --- |
| Launch, promo, feature | `references/types/launch.md` |
| Explainer, tutorial | `references/types/explainer.md` |
| Music video | `references/types/music.md` |
| Chart, numbers | `references/types/data.md` |
| Vertical or social clip | `references/types/vertical.md` |
| 3D, simulation, generative | `references/types/3d.md` |
| Character, mascot, story short | `references/types/character.md` |
| A real place or map; a website, PR or script; kinetic type | `references/film.md` |
| Captions; cards over a talking head | `references/captions.md`; `references/overlays.md` |
| Motion: eases, titles, cuts, punch-ins, speed, holds | `references/motion.md` |
| Scenes, attributes, media, lint; GSAP, Lottie, 3D, canvas | `references/format.md`; `references/runtimes.md` |

Decks: `/slideshow`. Remotion source: `/remotion-to-hyperframes`. Figma: `/figma`. The CLI version is pinned by the engine (narzedzia/ruch/package.json); never upgrade it.
