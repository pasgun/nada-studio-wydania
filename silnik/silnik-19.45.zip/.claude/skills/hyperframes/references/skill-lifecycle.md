# Wersja HyperFrames

Silnik Nada Studio przypina wersję HyperFrames w `narzedzia/ruch/package.json`. Nie aktualizuj jej i nie instaluj skilli; nie uruchamiaj `upgrade`.
