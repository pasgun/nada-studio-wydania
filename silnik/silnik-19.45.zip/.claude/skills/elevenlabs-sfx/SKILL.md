---
name: elevenlabs-sfx
description: Jak opisywać efekty dźwiękowe dla ElevenLabs. Używaj tylko, gdy w Epidemic Sound nie ma pasującego efektu, a skill silnika każe zrobić efekt w ElevenLabs.
---

> **W silniku Nada Studio** ten skill jest dodatkiem od innego autora (ElevenLabs, MIT). Skille silnika (`rolka`, `grafika`, `animacje`, `jak-wzor`, `brandbook`, `napisy`) i `CLAUDE.md` mają pierwszeństwo: przy sprzeczności wygrywają one. Pracujesz bez użytkownika przy komputerze: niczego nie pytasz i nie czekasz na podgląd, decyzje bierzesz z zadania. Nigdy nie zakładasz kont, nie logujesz się, nie płacisz, nie instalujesz programów, nie czytasz i nie zapisujesz kluczy API, nie wysyłasz plików klienta do chmury.
> Efekt dźwiękowy z ElevenLabs robisz tylko narzędziem silnika: `python narzedzia/efekty.py elevenlabs --opis "<po angielsku>" --czas <s> --wyjscie <plik.mp3>` (klucz bierze sam z `.env`). Kodu z przykładów niżej nie uruchamiasz. Najpierw zawsze efekty z Epidemic Sound (`CLAUDE.md`, „Muzyka i efekty”); ElevenLabs tylko, gdy w Epidemic nie ma pasującego, i z kredytów użytkownika (pilnuj limitów z zadania).

# ElevenLabs Sound Effects

Generate sound effects from text descriptions — supports looping, custom duration, and prompt adherence control.

> Klucz `ELEVENLABS_API_KEY` daje silnik. Nigdy go nie wypisuj, nie kopiuj i nie zapisuj. Gdy go brak, przerwij i napisz o tym; nigdy nie uruchamiaj `onboard`, logowania ani instalatorów.

## Quick Start

### Python

```python
from elevenlabs import ElevenLabs

client = ElevenLabs()

audio = client.text_to_sound_effects.convert(
    text="Thunder rumbling in the distance with light rain",
    model_id="eleven_text_to_sound_v3",
)

with open("thunder.mp3", "wb") as f:
    for chunk in audio:
        f.write(chunk)
```

### JavaScript

```javascript
import { ElevenLabsClient } from "@elevenlabs/elevenlabs-js";
import { createWriteStream } from "fs";

const client = new ElevenLabsClient();
const audio = await client.textToSoundEffects.convert({
  text: "Thunder rumbling in the distance with light rain",
  modelId: "eleven_text_to_sound_v3",
});
audio.pipe(createWriteStream("thunder.mp3"));
```

### CLI

```bash
elevenlabs text-to-sound-effects convert \
  --text "Thunder rumbling in the distance with light rain" \
  --model-id eleven_text_to_sound_v3 \
  --output thunder.mp3
```

## Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `text` | string (required) | — | Description of the desired sound effect |
| `model_id` | string | `eleven_text_to_sound_v2` | Model to use. Set `eleven_text_to_sound_v3` (SFX v3) explicitly: it follows multi-part prompts more closely, handles music and vocals better, and sounds more natural |
| `duration_seconds` | number \| null | null (auto) | Duration 0.5–30s; auto-calculated if null |
| `prompt_influence` | number \| null | 0.3 | How closely to follow the prompt (0–1) |
| `loop` | boolean | false | Generate a seamlessly looping sound |

## Examples with Parameters

```python
# Looping ambient sound, 10 seconds
audio = client.text_to_sound_effects.convert(
    text="Gentle forest ambiance with birds chirping",
    model_id="eleven_text_to_sound_v3",
    duration_seconds=10.0,
    prompt_influence=0.5,
    loop=True,
)

# Short UI sound, high prompt adherence
audio = client.text_to_sound_effects.convert(
    text="Soft notification chime",
    model_id="eleven_text_to_sound_v3",
    duration_seconds=1.0,
    prompt_influence=0.8,
)
```

## Output Formats

Pass `--output-format` (CLI) or `output_format` as an SDK parameter:

| Format | Description |
|--------|-------------|
| `mp3_44100_128` | MP3 44.1kHz 128kbps (default) |
| `pcm_44100` | Raw uncompressed CD quality |
| `opus_48000_128` | Opus 48kHz 128kbps — efficient compressed |
| `ulaw_8000` | μ-law 8kHz — telephony |

Full list: `mp3_22050_32`, `mp3_24000_48`, `mp3_44100_32`, `mp3_44100_64`, `mp3_44100_96`, `mp3_44100_128`, `mp3_44100_192`, `pcm_8000`, `pcm_16000`, `pcm_22050`, `pcm_24000`, `pcm_32000`, `pcm_44100`, `pcm_48000`, `wav_8000`, `wav_16000`, `wav_22050`, `wav_24000`, `wav_32000`, `wav_44100`, `wav_48000`, `ulaw_8000`, `alaw_8000`, `opus_48000_32`, `opus_48000_64`, `opus_48000_96`, `opus_48000_128`, `opus_48000_192`.

## Prompt Tips

- Be specific: "Heavy rain on a tin roof" > "Rain"
- Combine elements: "Footsteps on gravel with distant traffic"
- Specify style: "Cinematic braam, horror" or "8-bit retro jump sound"
- Mention mood/context: "Eerie wind howling through an abandoned building"

## Error Handling

```python
try:
    audio = client.text_to_sound_effects.convert(text="Explosion")
except Exception as e:
    print(f"API error: {e}")
```

Common errors:
- **401**: Invalid API key
- **422**: Invalid parameters (check duration range, prompt_influence range)
- **429**: Rate limit exceeded

## References

- [Installation Guide](references/installation.md)
