---
name: hyperframes-cli
description: Polecenia HyperFrames (lint, check, snapshot, beats, render lokalny) przez `python narzedzia/ruch.py hf ...`. Używaj tylko razem ze skillem `hyperframes`.
---

> **W silniku Nada Studio** ten skill jest dodatkiem od innego autora (HeyGen, HyperFrames, Apache-2.0). Skille silnika (`rolka`, `grafika`, `animacje`, `jak-wzor`, `brandbook`, `napisy`) i `CLAUDE.md` mają pierwszeństwo: przy sprzeczności wygrywają one. Pracujesz bez użytkownika przy komputerze: niczego nie pytasz i nie czekasz na podgląd, decyzje bierzesz z zadania. Nigdy nie zakładasz kont, nie logujesz się, nie płacisz, nie instalujesz programów, nie czytasz i nie zapisujesz kluczy API, nie wysyłasz plików klienta do chmury.
> HyperFrames uruchamiasz tylko przez `python narzedzia/ruch.py` (wersja przypięta w silniku, telemetria wyłączona): zamiast `npx hyperframes <polecenie>` pisz `python narzedzia/ruch.py hf <polecenie>`. Nowy projekt: `python narzedzia/ruch.py nowy --folder <folder zadania>/ruch/<nazwa>` (zamiast `init`), render z kolorami i fontami marki: `python narzedzia/ruch.py render --projekt <folder> --wyjscie <plik.mov> --podglad`. GSAP z `lib/gsap.min.js`, kolory i fonty z `lib/marka.css` (zmienne `--glowny`, `--akcent`, `--tekst`, `--font`), zamiast CDN i Google Fonts. Zakazane: `cloud`, `publish`, `auth`, `billing`, `feedback`, `usage`, `lambda`, `cloudrun`, `upgrade`, `preview`, `open`, `media-use`, `reverse-any-video`, HeyGen (awatary, lektor, muzyka). Muzyka, lektor i efekty: narzędzia silnika (`CLAUDE.md`, „Muzyka i efekty”). Zasady wyglądu: sekcja „Gust” w `CLAUDE.md` i `narzedzia/ruch/BIBLIOTEKA.md`.

# HyperFrames CLI

Run `python narzedzia/ruch.py hf <command>` unless the project gives a wrapper; then use the wrapper. It needs Node.js 22+ and FFmpeg. Every command has `--help`; most take `--json`, and a failure prints `✗ …`, a `Fix:` line and exits non-zero.

Ignore `_meta.updateNotice`: the engine pins the version.

## Commands by job

| Job | Commands |
| --- | --- |
| Start | `init <dir> --skip-skills` (blank; `--example <name>` only when asked), `capture <url>` |
| Read a project | `info`, `compositions`, `timeline --json`, `docs <topic>` |
| Check it | `lint` while writing; `check --json` as the gate (lint, runtime, layout, contrast) |
| Look at it | `snapshot` (`--at <t,…>`, `--range START,END`, `--composition <id>`, `--zoom`, `--angle`, `--against <video>`), `keyframes`, `compare`, `audio` |
| Edit the timeline | `timeline` with `move`, `trim`, `split`, `set`, `duplicate`, `delete`, `apply`, `undo`, `ids` |
| Reuse | `catalog`, `add` (`/hyperframes-registry`) |
| Media and sound | `media-treatment`, `grade-compare`, `remove-background`, `tts`, `transcribe`, `beats`, `normalize-audio` (`/media-use`) |
| Show and ship | `render` (locally, through `python narzedzia/ruch.py render`) |
| Upkeep | `doctor`, `clean` |

`captions` is not a command: run `transcribe`, then read ../hyperframes/references/captions.md.

`validate`, `inspect` and `layout` are deprecated aliases of `check`; `events` is skills' own telemetry. Don't run them.

## The loop

1. Write, then `python narzedzia/ruch.py hf lint` after the first pass and after structural changes.
2. `python narzedzia/ruch.py hf check --json` and fix every error. While a lint error remains the layout and contrast audits don't run; "0 samples" means nothing was checked. Contrast failures carry a `suggestedColor`. A finding at a single sample (an entrance in flight) is info; a 3 s+ video with no visible change fails `sweep_static`.
3. `python narzedzia/ruch.py hf snapshot` and read the PNGs (under `.hyperframes/artifacts/snapshots/`): that is how you see the video. With sub-compositions, snapshot a midpoint of every scene; tiny unstyled content or a missing hero is a mount defect (`../hyperframes/references/format.md`).
4. No preview server: nobody is at the computer. Look at snapshots and the `--podglad` sheet instead.

"This element" or the current selection: `python narzedzia/ruch.py hf preview --context --json --context-fields selection`; `no-selection` means ask them to click it.

## Edit the timeline

These are the edits Studio itself makes, so the result stays in Studio's shape.

- `timeline --json` lists clips with absolute `absStart`/`absEnd`, owning `file` and the `#id` ref the edit commands take (`timeline ids` stamps missing ids).
- `timeline move|trim|split|set|duplicate|delete <ref> … --plan --json` previews one edit; run it again without `--plan`. `--start`, `--end`, `--duration` set one edge or the length.
- An edit is refused when the clip would overlap a neighbour (`--overwrite`, or move the neighbour first) or end past its composition: raise the root's `data-duration` first. No command changes `data-duration`.
- Several edits at once: a JSON file such as `[{"verb": "move", "ref": "#outro", "time": "9"}]`, then `timeline apply plan.json --json`. Each run prints a `receipt`; save it and `timeline undo receipt.json` reverts it.

<!-- history (trial): remove this block together with the command -->

## Project history

Every write is kept and can be undone. At the start of a turn, `python narzedzia/ruch.py hf history begin --who <you> --label "<plan>"`, then `history --since mine --who <you>` to see what the person changed; build on their edits. A check failed or they say it got worse: `history undo --who <you>`, never hand-edit back. End the turn with `history end`.

<!-- /history (trial) -->

## Render where

| Need | Command |
| --- | --- |
| Local | `render --quality looks -o out.mp4` (`draft`, `delivery`) |
| Reproducible container | `render --docker --strict -o out.mp4` |
| Batch from variables | `render --batch rows.json -o "renders/{name}.mp4"` |

A 30 s film renders in a minute or two: run it in the foreground. Detach only a render longer than your tool's timeout (`HYPERFRAMES_RENDER_DETACHED=1`, its own group, output to a log) and wait with `until grep -qE 'Render (complete|failed)' render.log; do sleep 5; done`, never `pgrep -f`, which matches its own loop and waits until the tool times out.

Never run `cloud render`, `publish`, `auth`, `billing`, `feedback`, `usage`, `lambda`, `cloudrun`, `upgrade`.

## When a command fails

| Symptom | Fix |
| --- | --- |
| Chrome missing or won't start | `python narzedzia/ruch.py hf browser ensure`; `doctor --json` always exits 0, gate on `.ok` |
| A heavy page isn't ready in time | Raise `--timeout` on `check` or `snapshot` |
| Unusual codec looks blank | Keep `--proxy` on (the default) |
| Render slow on Linux | The summary's second line says `screenshot` + `software gpu`: the slow path |
| `capture` fails or writes `BLOCKED.md` | Take nothing from its partial files; retry into a new `-o` folder |
| Disk tight | `clean --dry-run`, then `clean`; never delete `.hyperframes` (it holds history) |

## References

Read the row before running its command.

| Commands | Read |
| --- | --- |
| `init`, `capture`, `skills` | `references/init-and-scaffold.md` |
| `lint`, `check`, motion sidecars, `snapshot` | `references/lint-validate-inspect.md` |
| `compare`, `grade-compare`, `render --batch` | `references/compare-and-batch.md` |
| `beats` | `references/beats.md` |
| `preview`, `play`, `render`, `publish`, Studio context | `references/preview-render.md` |
| `doctor`, `browser` | `references/doctor-browser.md` |
| `info`, `upgrade`, `compositions`, `timeline`, `docs`, `usage`, telemetry | `references/upgrade-info-misc.md` |
| `--strict` flags, run ids, `clean`, shader lint, JSON paths | `references/conventions.md` |
| `keyframes` | `../hyperframes/references/motion.md` (Seeing motion) |
