---
name: jak-wzor
description: Robi rolkę podobną do podanego wzoru (gotowej rolki) z materiałów użytkownika: to samo tempo cięć, rodzaj ujęć, przejścia, napisy kinetyczne, muzyka i efekty dźwiękowe. Za darmo (silnik + Epidemic w abonamencie). Uruchamiane poleceniem /jak-wzor z danymi w JSON ze Studio.
disable-model-invocation: true
---

Zlecenie:

$ARGUMENTS

Cel: rolka o tym samym „charakterze” co wzór (tempo, budowa, typ ujęć, przejścia, styl napisów, energia muzyki), ale z materiałów użytkownika i o jego temacie. Nie kopiujesz cudzych treści 1:1: nie używasz muzyki ani ujęć ze wzoru, nie przepisujesz jego tekstów (tylko ich formę), bez logo i znaków wzoru.

## 1. Przygotowanie
- Folder: `zlecenie.folder` (w nim plik wzoru i podfolder `nagrania/` z materiałem; gdy nagrań brak, zatrzymaj się i poproś). Wyniki w `<folder>/gotowe/`.
- Marka i styl klienta: jak w `CLAUDE.md` („Marka i brandbook”, `styl_wideo.md`).

## 2. Rozbiór wzoru
`python narzedzia/wzor.py analizuj --plik <wzór> --folder <folder>/_wzor` (z `--mowa auto`, gdy we wzorze ktoś mówi albo jest lektor).
Obejrzyj wszystkie arkusze (Read). Zapisz `<folder>/przepis.md`:
- format, długość, liczba ujęć, średnia długość ujęcia, czy cięcia trafiają w bit (`ciecia_w_bit_proc`),
- budowa: hak (pierwsze 1–2 s), rozwinięcie, kulminacja, zakończenie / CTA,
- lista ujęć wzoru: nr, długość, rodzaj (plan ogólny, zbliżenie, detal, twarz, ruch kamery, produkt), przejście do kolejnego (cięcie, whip, zoom, flash, rozmycie, glitch, przenikanie),
- napisy i grafiki: jakie (kinetyczne słowo po słowie, duży tytuł, liczniki, strzałki, belki), gdzie na kadrze, kolory, wielkość; opisz dokładnie wygląd i ruch (krój, grubość, wielkość w % kadru, kolor, jak wchodzi i schodzi, ile trwa) na gęstych klatkach (`ffmpeg -ss <s> -t 1.5 -i <wzór> -vf fps=8,scale=480:-1,tile=4x3 ...`),
- muzyka: tempo (BPM) i „drop” z `wzor.json`, energia początku i końca (z `energia_taktow`), czy jest wokal (z transkrypcji, gdy `--mowa auto` znalazła słowa poza lektorem); gatunku nie zgadujesz z obrazu (nie słyszysz muzyki): zapisz 2–3 gatunki pasujące do tempa, energii i tematu z dopiskiem „propozycja”,
- efekty dźwiękowe: momenty z `uderzenia_s` (zwykle whoosh przy przejściach, hit przy wejściu tytułu, riser przed dropem),
- kolorystyka i nastrój (ciepłe / zimne, kontrast, czarno-białe).

## 3. Materiał
`python narzedzia/analiza.py folder --folder <folder>/nagrania --mowa nie` (z `auto`, gdy zlecenie chce wypowiedzi). Obejrzyj arkusze i dla każdego ujęcia wzoru wybierz najbliższe ujęcie z materiału (ten sam rodzaj planu i ruchu). Brakuje pasującego: najbliższe zastępstwo albo stock z `zlecenie.serwisy`, jeśli jest na liście.

## 4. Muzyka i efekty
- Muzyka z `epidemic` (zlecenie.muzyka) według sekcji „Muzyka i efekty” w `CLAUDE.md` (brief, 3 kandydatów, `bity.py` dla każdego): tempo ±6 BPM od wzoru, podobny kształt energii (cicho i głośno w tych samych miejscach), bez wokalu, jeśli wzór ma napisy do czytania. Wybrany zapisz do `<folder>/muzyka.mp3` i ustaw `start` tak, żeby „drop” wypadł tam, gdzie we wzorze. Bez Epidemic: plik z `muzyka/` tylko, gdy pasuje według `bity.py`.
- Efekty dźwiękowe z Epidemic Sound (wyszukaj „whoosh”, „hit”, „riser”, „click”) albo z `muzyka/efekty/`, w miejscach jak we wzorze, ściszone (0.5–0.7).

## 5. Napisy kinetyczne i grafiki
Teksty piszesz na temat zlecenia (`zlecenie.brief`), w formie wzoru (tyle słów na raz, tak samo krótko). Każdy element odtwarzasz w „Ruchu” (sekcja „Animacje i grafiki ruchome” w `CLAUDE.md`): `python narzedzia/ruch.py nowy --folder <folder>/ruch/<nn>`, `index.html` z ruchem i typografią jak we wzorze (w kolorach i fontach marki), `python narzedzia/ruch.py render --projekt <folder>/ruch/<nn> --wyjscie <folder>/gotowe/anim/<nn>.mov --format <pion|poziom> --wartosci '{"czas": <s>}' --podglad --tlo <klatka ujęcia>`. Porównaj podgląd z gęstymi klatkami wzoru i popraw. Gotowe bloki HyperFrames (`ruch.py hf catalog --query ...`) mogą przyspieszyć pracę.

## 6. Montaż
`plan.json` (opis na górze `narzedzia/montaz.py`): sceny z długościami jak we wzorze (przeskalowane do `zlecenie.dlugosc`, jeśli inna; cięcia na bitach nowej muzyki, gdy wzór tnie w bit), przejścia jak we wzorze, `nakladki` z animacjami (czas na osi rolki), `efekty_dzwiekowe`, `muzyka`, logo i plansza końcowa wg marki, `"napisy": false` (napisy są w nakładkach), `"premiere": true`.
`python narzedzia/montaz.py zloz --plan <folder>/plan.json`

## 7. Kontrola
`python narzedzia/montaz.py klatki --plik <rolka> --ile 10`; porównaj z arkuszem wzoru: tempo, kadry, czytelność napisów, nic ważnego nie zasłonięte. Do 2 poprawek bez pytania.

## 8. Raport
Plik, długość, ile ujęć (wzór vs nowa), utwór i efekty (tytuł, autor), co zmieniłeś względem wzoru i dlaczego. Koszt: 0 zł poza abonamentami (ElevenLabs tylko przy rozpoznawaniu mowy).
Higgsfield Katana (gotowe „edity” ze wzoru) jest płatna (kredyty Higgsfield) i działa przez łącznik Higgsfield w Claude: użyj jej tylko, gdy `zlecenie.katana` jest `true`, i powiedz wcześniej, ile kredytów zużyje.
