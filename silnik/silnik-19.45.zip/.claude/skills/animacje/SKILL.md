---
name: animacje
description: Robi animacje i grafiki ruchome (napisy kinetyczne, belki z nazwiskiem, liczby, wykresy, CTA, karty, plansze, szablony na film, przejścia) nowe z opisu w HyperFrames („Ruch”) albo z biblioteki, w kolorach i fontach marki klienta, jako pliki MOV z przezroczystością do Premiere. Uruchamiane poleceniem /animacje z danymi w JSON ze Studio albo z panelu w Premiere.
disable-model-invocation: true
---

Zadanie:

$ARGUMENTS

Animacje robisz w **„Ruchu”** (HyperFrames: HTML + GSAP) przez `python narzedzia/ruch.py` (opis na górze pliku). Zasady techniczne i wyglądu: `narzedzia/ruch/BIBLIOTEKA.md`, sekcje „Animacje i grafiki ruchome” i „Gust” w `CLAUDE.md`; podręcznik HyperFrames: skille `hyperframes`, `hyperframes-cli`, `hyperframes-registry` (gotowe bloki), `motion-effects`, `animated-chart`. Biblioteka: `python narzedzia/ruch.py lista` (biblioteka + „Moje”). Stara biblioteka presetów (`narzedzia/animacje.py`) tylko w trybie `stare`.

## Zasady wspólne

- Folder wyników: z panelu jest w `folder`; ze Studio pliki zapisuj do `<zlecenie.folder>/gotowe/` (utwórz go). Projekty HyperFrames trzymaj w `<folder>/ruch/<nazwa>/`.
- Marka: kolory i fonty wstawia sam `ruch.py` (z `klienci/<x>/marka.md`, `animacje.json`, karty). Z panelu `marka_z_panelu`, ze Studio `zlecenie.marka` (wybrane przez użytkownika) mają pierwszeństwo: przekaż je w `--wartosci` (`kolor_glowny`, `kolor_akcent`, `kolor_tekstu`, `font`, `waga`). Przeczytaj „gust marki” w `marka.md`, jeśli jest.
- Wyróżnienia w tekście: `*słowo*` (kolor akcentu), `|` = nowa linia. Teksty po polsku, krótkie (do 6–7 słów na raz). Teksty pisz według skilla `copywriting` (bez „tekstów jak z AI”).
- Format: `format` z zadania (`pion`, `poziom`, `kwadrat`, `4x5` albo np. `1920x1080`); z panelu rozmiar sekwencji. Długość: `czas` z zadania (z panelu: długość klipu na osi).
- Z panelu: użytkownika nie ma przy komputerze, nie zadawaj pytań. Etapy: `python narzedzia/postep.py --etap <klucz> --tekst "..."` (klucze: `przygotowanie`, `projekt`, `render`, `kontrola`), na koniec `--gotowe`, przy błędzie `--blad "..."`.

## Tryb `opis` (domyślny: nowa animacja z opisu użytkownika)

1. Przeczytaj opis (`opis`), „gust marki” i 1–2 podobne pozycje z biblioteki (`narzedzia/ruch/biblioteka/<id>/index.html`) jako wzór techniki. Gdy pasuje gotowy blok HyperFrames: `python narzedzia/ruch.py hf catalog --query "<po angielsku>" --json` i `hf add <nazwa>` w folderze projektu, potem przerób go pod markę.
2. `python narzedzia/ruch.py nowy --folder <folder>/ruch/<id>` i napisz `index.html` oraz `meta.json` (id: małe litery i myślniki; `nazwa` po polsku; `kat`; `czas`; `pelny: true` dla planszy na cały ekran albo przejścia; `pola` tak, żeby użytkownik zmienił tekst, liczby i zdjęcie bez kodu).
   - `zlecenie.rodzaj: "szablon"` (z sekcji Szablony w panelu): pełny kadr 9:16 (`pelny: true`) z polem `film` albo `obraz` na materiał użytkownika (duże okno na klip) i tekstami; bez materiału ma wyglądać dobrze z kolorem marki.
3. `python narzedzia/ruch.py render --projekt <folder>/ruch/<id> --wyjscie <folder>/<id>.mov --podglad [--tlo <klatka z filmu>] --format <format> --wartosci '{"czas": <s>}'` i obejrzyj `<id>_podglad.jpg`. Popraw i powtórz (do 3 razy), aż jest premium: tekst duży i czytelny, nic nie wychodzi poza kadr, nic w bezpiecznej strefie, wejście szybkie z miękkim hamowaniem, bez odbijania.
4. `python narzedzia/ruch.py zapisz --projekt <folder>/ruch/<id> --id <id> --nazwa "<nazwa>" --kat <kat> --opis "<1 zdanie>"`: animacja trafia do „Moje” w panelu (i do kolejnych zadań).

## Tryb `biblioteka` (lista gotowych pozycji z „Ruchu”)

Dla każdej pozycji z `animacje` (`id`, `wartosci`): `python narzedzia/ruch.py render --szablon <id> --klient <klient.folder> --format <format> --wartosci '<json>' --wyjscie <folder>/<nn>_<id>.mov --podglad [--tlo <klatka>]`. Obejrzyj podglądy i popraw wartości (tekst, pozycja, rozmiar).

## Tryb `film` (animacje do filmu według opisu)

Opis mówi, co i kiedy pokazać (np. „0:12 belka Anna Nowak, CEO; 0:40 licznik +250% zasięgów”). Gdy podano `xml` sekwencji i `dopasuj_do_mowy: true`, najpierw `python narzedzia/ciecie.py analizuj --xml <xml> --folder <folder>/mowa` i z `zdania.txt` ustal dokładne momenty. Każdą grafikę zrób jak w trybie `opis` (spójny wygląd całego filmu: ta sama typografia i ten sam ruch) albo z biblioteki; podgląd zawsze z `--tlo <klatka z filmu w tym miejscu>`. Zapisz `<folder>/wstawki.json`: `[{"plik": "<pełna ścieżka .mov>", "czas_s": 12.0, "opis": "belka Anna Nowak"}]` (czas na osi sekwencji). Panel położy je na wolnej ścieżce nad filmem.

## Tryb `stare` (tylko na wyraźną prośbę: stara biblioteka presetów)

`python narzedzia/animacje.py lista|render --preset <id> --klient ... --format ... --parametry '<json>' --wyjscie <plik.mov> --podglad` (opis na górze `narzedzia/animacje.py`).

## Raport

Lista plików (ścieżka, nazwa, czas trwania), co zapisałeś w „Moje”, decyzje podjęte samodzielnie. Z panelu na koniec: `python narzedzia/postep.py --gotowe --wideo <plik.mov> [--wideo ...] --tekst "<1 zdanie>"`.
