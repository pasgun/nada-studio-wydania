# Skille innych autorów w silniku

Wgrane narzędziem `narzedzia_budowania/skille_zewnetrzne.py` z poprawkami bezpieczeństwa (bez telemetrii, chmury, logowania, płatności, instalatorów i zapisu kluczy; HyperFrames tylko przez `python narzedzia/ruch.py`). Skille silnika mają pierwszeństwo. Licencje w plikach LICENSE w folderach.

| Skill | Źródło | Wersja (commit, data) |
| --- | --- | --- |
| `hyperframes` | heygen-com/hyperframes `skills/hyperframes` | cb8e02e 2026-11-06 |
| `hyperframes-cli` | heygen-com/hyperframes `skills/hyperframes-cli` | cb8e02e 2026-11-06 |
| `hyperframes-registry` | heygen-com/hyperframes `skills/hyperframes-registry` | cb8e02e 2026-11-06 |
| `motion-effects` | charlie947/motion-graphics-skills `skills/motion-effects` | 229022e 2026-10-11 |
| `animated-chart` | charlie947/motion-graphics-skills `skills/animated-chart` | 229022e 2026-10-11 |
| `reel-export` | charlie947/motion-graphics-skills `skills/reel-export` | 229022e 2026-10-11 |
| `elevenlabs-sfx` | elevenlabs/skills `sound-effects` | 9763c39 2026-11-04 |
| `elevenlabs-muzyka` | elevenlabs/skills `music` | 9763c39 2026-11-04 |
| `ad-creative` | coreyhaines31/marketingskills `skills/ad-creative` | 88c79f6 2026-10-30 |
| `copywriting` | coreyhaines31/marketingskills `skills/copywriting` | 88c79f6 2026-10-30 |
| `social` | coreyhaines31/marketingskills `skills/social` | 88c79f6 2026-10-30 |
| `marketing-psychology` | coreyhaines31/marketingskills `skills/marketing-psychology` | 88c79f6 2026-10-30 |
