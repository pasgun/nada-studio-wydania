---
name: hyperframes-registry
description: Katalog ok. 450 gotowych bloków HyperFrames (przejścia, napisy kinetyczne, wykresy, karty UI). Używaj tylko w projekcie HyperFrames, gdy skill silnika każe sięgnąć po gotowy blok.
---

> **W silniku Nada Studio** ten skill jest dodatkiem od innego autora (HeyGen, HyperFrames, Apache-2.0). Skille silnika (`rolka`, `grafika`, `animacje`, `jak-wzor`, `brandbook`, `napisy`) i `CLAUDE.md` mają pierwszeństwo: przy sprzeczności wygrywają one. Pracujesz bez użytkownika przy komputerze: niczego nie pytasz i nie czekasz na podgląd, decyzje bierzesz z zadania. Nigdy nie zakładasz kont, nie logujesz się, nie płacisz, nie instalujesz programów, nie czytasz i nie zapisujesz kluczy API, nie wysyłasz plików klienta do chmury.
> HyperFrames uruchamiasz tylko przez `python narzedzia/ruch.py` (wersja przypięta w silniku, telemetria wyłączona): zamiast `npx hyperframes <polecenie>` pisz `python narzedzia/ruch.py hf <polecenie>`. Nowy projekt: `python narzedzia/ruch.py nowy --folder <folder zadania>/ruch/<nazwa>` (zamiast `init`), render z kolorami i fontami marki: `python narzedzia/ruch.py render --projekt <folder> --wyjscie <plik.mov> --podglad`. GSAP z `lib/gsap.min.js`, kolory i fonty z `lib/marka.css` (zmienne `--glowny`, `--akcent`, `--tekst`, `--font`), zamiast CDN i Google Fonts. Zakazane: `cloud`, `publish`, `auth`, `billing`, `feedback`, `usage`, `lambda`, `cloudrun`, `upgrade`, `preview`, `open`, `media-use`, `reverse-any-video`, HeyGen (awatary, lektor, muzyka). Muzyka, lektor i efekty: narzędzia silnika (`CLAUDE.md`, „Muzyka i efekty”). Zasady wyglądu: sekcja „Gust” w `CLAUDE.md` i `narzedzia/ruch/BIBLIOTEKA.md`.

# HyperFrames registry

Starting from an item is faster and usually better than writing the effect yourself, and an installed item is ordinary source in your project: change it, cut it down, restyle it.

## Find and install

There is no `hyperframes registry` command; searching is `catalog`, installing is `add`.

```bash
python narzedzia/ruch.py hf catalog --query "<what the beat should do, in English>" --json
python narzedzia/ruch.py hf add <name> --json        # prints the written files and the mount snippet
```

- Query in English even when the video is not: the catalog is indexed in English, and another script returns `No searchable words in query`, which is not a gap.
- Search is local and sends nothing. The default `words` tier only finds items that reuse your words; `--on-device` ranks by meaning after a one-time ~33 MB download. Don't use `--on-device` (no extra downloads). The `--json` envelope names the tier that answered.
- Narrow with `--type block|component` and `--tag <tag>`. `add <tag>` installs every block with that tag; dependencies install first. `add` needs the network even for an item installed before; search works offline from the cached manifest.

Tiers, `dropped` and `unindexed`, stale indexes, offline behaviour: `references/search.md`.

## What's in it

| Blocks: a scene with its own timeline | Examples |
| --- | --- |
| Transitions | `beat-freeze-cut`, `chromatic-radial-split`, `cinematic-zoom` |
| Overlays and lower thirds | `camcorder-hud`, `editorial-flash-overlay`, `lt-clean-bar` |
| Title cards and kinetic type | `canopy-part-title`, `code-slice-hero` |
| Social, chat and UI cards | `ai-chat-reveal`, `chatgpt-exchange` |
| Code, charts, data and maps | `code-diff`, `bar-chart-race`, `data-chart` |
| 3D, shader and backgrounds | `app-showcase`, `aurora`, `blob` |

| Components: a snippet merged into your scene | Examples |
| --- | --- |
| Motion primitives and text effects | `agent-cursor`, `blur-in`, `bottom-up-letters` |
| Caption styles | `caption-clip-wipe`, `caption-editorial-emphasis` |
| Camera moves | `camera-shake`, `camera-scan-gate` |
| Product demo and UI props | `before-after-wipe`, `browser-device-stage` |
| Textures, particles and effects | `ascii-render-pass`, `grain-overlay` |

## Wiring

- **Block**: installs to `compositions/<name>.html`. Mount it with `data-composition-src`, `data-composition-id` matching the block's own id, `data-start` and the `data-duration` you need; the snippet `add` prints is the starting point. `references/wiring-blocks.md`.
- **Component**: installs to `compositions/components/<name>.html`. Copy its markup, `<style>` and script into your scene, and follow its comment block if it hooks into your timeline. `references/wiring-components.md`.
- Take the largest unit that fits, then edit it. Keep an installed item's ids prefixed as they are, so two items can't collide.
- An item keeps its own variables; set them for one mount with `data-variable-values` on its host (`add --vars '{"title":"…"}'` writes that), and point its colour and font variables at your brand's.
- Beat-synced blocks take hit times from `python narzedzia/ruch.py hf beats --json`: the beat times minus the mount's `data-start`.
- Install paths come from `hyperframes.json` (`references/install-locations.md`).

## Contributing

Authoring a new block or component for an upstream PR: `references/contributing.md`, starter templates in `references/templates.md`, quality bar in `references/component-quality-bar.md`.
