"""Porządek w wynikach: foldery klientów, foldery zadań z nazwą jak w Studio, gotowe pliki na wierzchu.

Układ:
  wyniki/<Klient>/<Tytuł zadania>/       gotowe rzeczy na wierzchu (np. „Rolka 1.mp4”, grafiki PNG)
      Projekty/                          pliki do dalszej pracy: Premiere (XML + SRT), Photoshop (PSD), After Effects
      Materiały/                         wszystko inne, co było użyte (sceny, lektor, muzyka, plany, raport)
  wyniki/<Klient>/Panel Premiere/...     rzeczy wstawiane z panelu na oś (animacje, napisy, szablony): nie są przenoszone
  _system/                               pliki silnika (Console, licznik, panel, proksy, stock, Gemini, testy), poza wynikami

  python narzedzia/porzadek.py folder --klient "Instytut Edukacji Finansowej" --tytul "3 rolki ETF" [--id ABCD] [--klient-folder instytut-edukacji-finansowej]
  python narzedzia/porzadek.py zadanie --folder "wyniki/Instytut Edukacji Finansowej/3 rolki ETF"     (na koniec zadania)
  python narzedzia/porzadek.py system                     przenosi wyniki/_studio, _panel, _proksy... do _system/
  python narzedzia/porzadek.py stare [--wykonaj]          stare foldery wyniki/<klient>_<projekt>_<data> do nowego układu (bez --wykonaj tylko pokazuje plan)

Przy przenoszeniu narzędzie poprawia ścieżki w plikach XML (timeline do Premiere), JSON, MD i SRT w folderze zadania,
więc timeline wczytany po porządkach wskazuje właściwe pliki. Pliki sterujące (postęp, przebieg mózgu) zostają
na miejscu, ale są ukryte. Niczego nie kasuje.
"""
import argparse
import json
import os
import re
import shutil
import sys
import time
from pathlib import Path
from urllib.parse import quote

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, wynik  # noqa: E402

WYNIKI = KATALOG_SILNIKA / "wyniki"
SYSTEM = KATALOG_SILNIKA / "_system"
SYSTEMOWE = ["studio", "panel", "proksy", "licznik", "stock", "gemini", "test"]
PROJEKTY, MATERIALY = "Projekty", "Materiały"
WIDEO = {".mp4", ".mov", ".webm", ".m4v", ".mkv"}
OBRAZY = {".png", ".jpg", ".jpeg", ".webp"}
PLIKI_PROJEKTOW = {".psd", ".psb", ".aep", ".prproj", ".mogrt", ".drp"}
# pliki, które czyta panel albo Studio w trakcie i po zadaniu: zostają na miejscu, tylko ukryte
STERUJACE = {"postep.json", "proces_panelu.json", "claude_log.jsonl", "zadanie_panel.json", "sekwencja.xml", "proksy.json", "polecenie_gemini.json"}
TEKSTOWE = {".xml", ".json", ".jsonl", ".md", ".srt", ".txt", ".csv"}
ZAKAZANE = '<>:"/\\|?*'


# ---------- nazwy ----------
def czysta_nazwa(t, dl=70):
    t = "".join("-" if c in ZAKAZANE or ord(c) < 32 else c for c in str(t or "")).strip().strip(".")
    t = re.sub(r"\s+", " ", t)
    return t[:dl].rstrip(" .") or "bez nazwy"


def ladna_z_folderu(slug):
    """„instytut-edukacji-finansowej” -> „Instytut Edukacji Finansowej”, „tm” -> „TM”."""
    slowa = [s for s in re.split(r"[-_\s]+", str(slug or "")) if s]
    return " ".join(s.upper() if len(s) <= 3 and len(slowa) == 1 else s[:1].upper() + s[1:] for s in slowa) or "Bez klienta"


def nazwa_klienta(klient="", klient_folder=""):
    """Nazwa folderu klienta: z klienci/<folder>/klient.json, z podanej nazwy albo ładnie z nazwy folderu klienta."""
    from wspolne import slug_zwarty
    kl = KATALOG_SILNIKA / "klienci"
    kf = str(klient_folder or "").replace("\\", "/").split("/")[-1]
    if kf and klient and not re.fullmatch(r"[a-z0-9\-_]+", klient):
        try:  # zapamiętaj ładną nazwę, żeby panel (który zna tylko folder) używał tej samej
            p = kl / kf / "klient.json"
            if (kl / kf).is_dir():
                d = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
                if d.get("nazwa") != klient:
                    d["nazwa"] = klient
                    p.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
        except Exception:
            pass
    kandydaci = []
    if kf:
        kandydaci.append(kl / kf)
    if klient and kl.exists():
        s = slug_zwarty(klient)
        kandydaci += [k for k in kl.iterdir() if k.is_dir() and slug_zwarty(k.name) == s]
    for k in kandydaci:
        try:
            n = json.loads((k / "klient.json").read_text(encoding="utf-8")).get("nazwa")
            if n:
                return czysta_nazwa(n, 60)
        except Exception:
            pass
    if klient and not re.fullmatch(r"[a-z0-9\-_]+", klient):
        return czysta_nazwa(klient, 60)
    if kandydaci:
        return czysta_nazwa(ladna_z_folderu(kandydaci[0].name), 60)
    return czysta_nazwa(ladna_z_folderu(klient) if klient else "Bez klienta", 60)


def _info(folder):
    try:
        return json.loads((Path(folder) / MATERIALY / "_info.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


def folder_zadania(klient="", tytul="", zadanie_id="", klient_folder="", utworz=True, podfolder=None):
    """wyniki/<Klient>/<Tytuł>. To samo zadanie (ten sam numer) wraca do swojego folderu; inne o tej samej nazwie dostaje „(2)”."""
    k = WYNIKI / nazwa_klienta(klient, klient_folder)
    if podfolder:
        k = k / podfolder
    baza = czysta_nazwa(tytul or "Zadanie " + time.strftime("%d.%m.%Y"))
    zid = str(zadanie_id or "").strip()
    if zid and k.exists():
        for d in k.iterdir():
            if d.is_dir() and _info(d).get("zadanie_id") == zid:
                return d
    p, n = k / baza, 2
    while p.exists() and any(p.iterdir()):
        p = k / f"{baza} ({n})"
        n += 1
    if utworz:
        (p / MATERIALY).mkdir(parents=True, exist_ok=True)
        inf = _info(p) or {"utworzono": time.strftime("%Y-%m-%d %H:%M"), "tytul": tytul, "klient": k.parent.name if podfolder else k.name}
        if zid:
            inf["zadanie_id"] = zid
        (p / MATERIALY / "_info.json").write_text(json.dumps(inf, ensure_ascii=False, indent=1), encoding="utf-8")
    return p


# ---------- pliki silnika ----------
def system(nazwa):
    """_system/<nazwa>; przy pierwszym użyciu przenosi tam stary wyniki/_<nazwa>."""
    nowy, stary = SYSTEM / nazwa, WYNIKI / f"_{nazwa}"
    if stary.exists():
        nowy.mkdir(parents=True, exist_ok=True)
        for x in list(stary.iterdir()):
            cel = nowy / x.name
            if not cel.exists():
                try:
                    x.rename(cel)  # tylko zwykłe przeniesienie; plik w użyciu zostaje i przejdzie następnym razem
                except Exception:
                    pass
        try:
            stary.rmdir()
        except OSError:
            pass
    nowy.mkdir(parents=True, exist_ok=True)
    return nowy


def ukryj(p):
    if sys.platform.startswith("win"):
        try:
            import ctypes
            ctypes.windll.kernel32.SetFileAttributesW(str(p), 0x02)
        except Exception:
            pass


# ---------- poprawianie ścieżek ----------
def _formy(p):
    """Zapisy jednej ścieżki spotykane w plikach: C:\\a\\b, C:/a/b, C:\\\\a\\\\b (JSON), file://localhost/C%3a/a/b (XML Premiere)."""
    p = Path(p).resolve()
    win, posix = str(p).replace("/", "\\"), p.as_posix()
    f = {win, posix, win.replace("\\", "\\\\")}
    s = posix
    if len(s) > 1 and s[1] == ":":
        s = s[0] + "%3a" + s[2:]
    f.add("file://localhost/" + quote(s.lstrip("/"), safe="/%"))
    f.add("file://localhost/" + quote(s.lstrip("/"), safe="/%").replace("%3a", "%3A"))
    return f


def popraw_sciezki(folder, zmiany):
    """zmiany = [(stara, nowa)]; podmienia w plikach tekstowych folderu zadania (także w ukrytych sterujących)."""
    pary = []
    for st, nw in zmiany:
        fs_, fn = sorted(_formy(st)), sorted(_formy(nw))
        # te same rodzaje zapisu po kolei (windows, posix, json, url)
        for a in fs_:
            for b in fn:
                if (("\\\\" in a) == ("\\\\" in b)) and (a.startswith("file:") == b.startswith("file:")) and (("\\" in a) == ("\\" in b)) and (("%3A" in a) == ("%3A" in b)):
                    pary.append((a, b))
                    break
    if not pary:
        return 0
    # jedno przejście dla wszystkich zmian naraz (bez łańcuchów: A->B i potem B->C), najdłuższe ścieżki najpierw,
    # wielkość liter bez znaczenia (Windows); tylko całe składniki ścieżki (r1 nie może zmienić r10)
    mapa = {}
    for a, b in sorted(pary, key=lambda x: -len(x[0])):
        mapa.setdefault(a.lower(), b)
    wzor = re.compile("(" + "|".join(re.escape(a) for a in sorted(mapa, key=len, reverse=True)) + r")(?=[\\/\"'<\s,)\]}]|%5C|%2F|$)", re.I)
    zmienione = 0
    for p in Path(folder).rglob("*"):
        if not p.is_file() or p.suffix.lower() not in TEKSTOWE or p.stat().st_size > 30_000_000:
            continue
        try:
            t = p.read_text(encoding="utf-8")
        except Exception:
            continue
        n = wzor.sub(lambda m: mapa[m.group(1).lower()], t)
        if n != t:
            czasy = p.stat()
            p.write_text(n, encoding="utf-8")
            # data zmiany zostaje stara: poprawione ścieżki to nie nowa praca (Console nie pokaże starych zadań jako świeżych)
            os.utime(p, (czasy.st_atime, czasy.st_mtime))
            zmienione += 1
    return zmienione


# ---------- porządek w folderze zadania ----------
def _nowszy(x, od):
    """Czy plik (albo coś w folderze) powstał po ostatnim porządku: poprawki zrobione wewnątrz Materiały/."""
    try:
        if x.is_file():
            return x.stat().st_mtime > od
        return any(k.is_file() and k.stat().st_mtime > od for k in x.rglob("*"))
    except OSError:
        return False


def _gotowe(folder, od=None):
    """Ścieżki względne gotowych plików (te same reguły co „Zobacz wyniki” w Studio).
    od = czas ostatniego porządku: wtedy liczą się też nowe pliki zrobione w Materiały/ (poprawki)."""
    folder = Path(folder)
    man = folder / "gotowe.json"
    if man.exists():
        try:
            d = json.loads(man.read_text(encoding="utf-8-sig"))
            lista = d.get("pliki", d) if isinstance(d, dict) else d
            return [Path(str(x)).as_posix() for x in lista or [] if (folder / str(x)).is_file()]
        except Exception:
            pass
    wyn = []
    for x in sorted(folder.rglob("*")):
        rel = x.relative_to(folder)
        w_mat = rel.parts[0] == MATERIALY and od and len(rel.parts) > 1 and rel.parts[1] != "Poprzednie wersje"
        if w_mat and not _nowszy(x, od):
            continue
        if not x.is_file() or (rel.parts[0] in (PROJEKTY, MATERIALY) and not w_mat) or len(rel.parts) > 6 or any(c.startswith("_") for c in rel.parts[:-1]):
            continue
        e, czesci = x.suffix.lower(), [c.lower() for c in rel.parts[:-1]]
        if e in WIDEO and x.with_name(x.stem + "_os_czasu.json").exists():
            wyn.append(rel.as_posix())
        elif "gotowe" in czesci and (e in WIDEO or e in OBRAZY or e in {".srt", ".pdf", ".wav", ".mp3"}):
            wyn.append(rel.as_posix())
        elif czesci and czesci[-1] == "grafiki" and e in OBRAZY:
            wyn.append(rel.as_posix())
    return wyn


# dopiski rozmiaru w nazwie rolki: rolka_kwadrat.mp4, rolka_1080x1350.mp4, rolka - poziom.mp4
_FORMATY = {"pion": "", "1080x1920": "", "kwadrat": "kwadrat", "1080x1080": "kwadrat", "poziom": "poziom", "1920x1080": "poziom",
            "4x5": "4x5"}


def _czesci_rolki(stem):
    """„rolka_kwadrat_sv” -> ("kwadrat", "SV"); None, gdy to nie jest plik rolki."""
    t = [x for x in re.split(r"[_\s-]+", stem.lower()) if x]
    if not t or t[0] != "rolka":
        return None
    fmt = jez = ""
    for x in t[1:]:
        if x in _FORMATY:
            fmt = _FORMATY[x]
        elif re.fullmatch(r"\d{3,4}x\d{3,4}", x):
            fmt = x
        elif re.fullmatch(r"[a-z]{2}", x):
            jez = x.upper()
        else:
            return None  # inna nazwa, np. rolka_robocza: zostaje jak jest
    return fmt, jez


def _ladna_nazwa(rel, wszystkie):
    """„r2/rolka.mp4” -> „Rolka 2.mp4”, „r1/rolka_sv.mp4” -> „Rolka 1 SV.mp4”, „r1/rolka_kwadrat.mp4” -> „Rolka 1 - kwadrat.mp4”,
    „aftermovie_pion.mp4” -> „Aftermovie pion.mp4”."""
    p = Path(rel)
    m = re.fullmatch(r"r(\d+)", p.parent.name, re.I)
    cz = _czesci_rolki(p.stem)
    if cz is not None:
        fmt, jez = cz
        dop = (f" {jez}" if jez else "") + (f" - {fmt}" if fmt else "")
        if m:
            return f"Rolka {m.group(1)}{dop}{p.suffix.lower()}"
        # jedna rolka (w kilku rozmiarach albo językach): „Rolka.mp4”, „Rolka - kwadrat.mp4”
        rolki = {Path(w).parent.as_posix() for w in wszystkie if _czesci_rolki(Path(w).stem) is not None and not re.fullmatch(r"r\d+", Path(w).parent.name, re.I)}
        if len(rolki) == 1:
            return f"Rolka{dop}{p.suffix.lower()}"
    m2 = re.fullmatch(r"aftermovie_(pion|poziom)", p.stem, re.I)
    if m2:
        return f"Aftermovie {m2.group(1).lower()}{p.suffix.lower()}"
    return p.name


def _wolna(cel):
    if not cel.exists():
        return cel
    n = 2
    while True:
        k = cel.with_name(f"{cel.stem} ({n}){cel.suffix}")
        if not k.exists():
            return k
        n += 1


def uporzadkuj(folder):
    folder = Path(folder).resolve()
    if not folder.is_dir():
        blad(f"Nie ma folderu {folder}")
    mat, proj = folder / MATERIALY, folder / PROJEKTY
    mat.mkdir(exist_ok=True)
    zmiany, ruchy = [], []

    def przenies(zr, cel):
        cel.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(zr), str(cel))
        zmiany.append((zr, cel))
        ruchy.append({"z": zr.relative_to(folder).as_posix(), "do": cel.relative_to(folder).as_posix()})

    # 0. poprzednie gotowe (poprawki): stare wersje na wierzchu idą do Materiały/Poprzednie wersje
    od = _info(folder).get("uporzadkowano")
    gotowe = _gotowe(folder, od)
    nowe_nazwy = {_ladna_nazwa(g, gotowe) for g in gotowe}
    stamp = time.strftime("%Y-%m-%d %H%M")
    if gotowe:
        for x in list(folder.iterdir()):
            if x.is_file() and x.name in nowe_nazwy and x.relative_to(folder).as_posix() not in gotowe:
                przenies(x, mat / "Poprzednie wersje" / stamp / x.name)
    # 1. gotowe na wierzch
    for g in gotowe:
        zr = folder / g
        if len(Path(g).parts) == 1 and zr.name == _ladna_nazwa(g, gotowe):
            continue
        cel = folder / _ladna_nazwa(g, gotowe)
        try:
            ten_sam = cel.exists() and os.path.samefile(zr, cel)
        except OSError:
            ten_sam = False
        if ten_sam:
            # Windows i Mac nie rozróżniają wielkości liter: „rolka.mp4” i „Rolka.mp4” to ten sam plik, więc tylko zmiana nazwy (przez nazwę tymczasową)
            tmp = zr.with_name(zr.name + ".zmiana_nazwy")
            zr.rename(tmp)
            tmp.rename(cel)
            zmiany.append((zr, cel))
            ruchy.append({"z": zr.relative_to(folder).as_posix(), "do": cel.relative_to(folder).as_posix()})
            continue
        przenies(zr, _wolna(cel))
    # 2. projekty: foldery premiere/ (timeline + SRT + grafiki do niego), photoshop/, pliki PSD/AEP
    for x in sorted(folder.rglob("*"), key=lambda p: len(p.parts)):
        if not x.exists():
            continue
        rel = x.relative_to(folder)
        if rel.parts[0] == PROJEKTY or (rel.parts[0] == MATERIALY and not (od and len(rel.parts) > 1 and rel.parts[1] != "Poprzednie wersje" and _nowszy(x, od))):
            continue
        if x.is_dir() and x.name.lower() in ("premiere", "photoshop", "after-effects", "after effects"):
            rodzic = rel.parent.as_posix() if rel.parent.as_posix() != MATERIALY else "."
            m = re.fullmatch(r"r(\d+)", rel.parent.name, re.I) if rodzic != "." else None
            opis = {"premiere": "Premiere", "photoshop": "Photoshop"}.get(x.name.lower(), "After Effects")
            nazwa = f"Rolka {m.group(1)} - {opis}" if m else (opis if rodzic == "." else f"{rel.parent.name} - {opis}")
            if od and (proj / nazwa).exists():  # poprawki: poprzedni projekt do Poprzednie wersje
                przenies(proj / nazwa, _wolna(mat / "Poprzednie wersje" / stamp / nazwa))
            przenies(x, _wolna(proj / nazwa))
        elif x.is_file() and x.suffix.lower() in PLIKI_PROJEKTOW:
            przenies(x, _wolna(proj / x.name))
    # 3. reszta z wierzchu do Materiały (bez gotowych i plików sterujących)
    zostaje = {_ladna_nazwa(g, gotowe) for g in gotowe} | {PROJEKTY, MATERIALY} | set(_info(folder).get("na_wierzchu", []))
    for x in list(folder.iterdir()):
        robocze = x.is_file() and re.search(r"_podglad\.(jpe?g|png)$", x.name, re.I)  # arkusze kontrolne grafik
        if (x.name in zostaje and not robocze) or x.name in STERUJACE or x.name.startswith("."):
            continue
        if x.is_file() and x.parent == folder and x.name in {Path(c["do"]).name for c in ruchy if "/" not in c["do"]}:
            continue
        przenies(x, _wolna(mat / x.name))
    # 4. ścieżki w plikach i ukrycie plików sterujących
    poprawione = popraw_sciezki(folder, zmiany) if zmiany else 0
    for n in STERUJACE:
        if (folder / n).exists():
            ukryj(folder / n)
    if proj.exists() and not any(proj.iterdir()):
        proj.rmdir()
    na_wierzchu = sorted(x.name for x in folder.iterdir() if x.name not in STERUJACE and not x.name.startswith("."))
    xml = [str(p) for p in proj.rglob("*.xml")] if proj.exists() else []
    try:
        inf = _info(folder)
        inf["uporzadkowano"] = time.time()
        inf["na_wierzchu"] = [n for n in na_wierzchu if n not in (PROJEKTY, MATERIALY)]
        (mat / "_info.json").write_text(json.dumps(inf, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception:
        pass
    return {"folder": str(folder), "na_wierzchu": na_wierzchu, "przeniesione": len(ruchy), "poprawione_pliki": poprawione,
            "timeline_premiere": xml, "gotowe": [str(folder / _ladna_nazwa(g, gotowe)) for g in gotowe]}


# ---------- stare foldery ----------
def plan_starych():
    """Stare foldery wyniki/<klient>_<projekt>_<DDMMRR> (i _2, _v2): dokąd trafią w nowym układzie."""
    from wspolne import slug_zwarty
    kl = KATALOG_SILNIKA / "klienci"
    klienci = {slug_zwarty(k.name): k.name for k in kl.iterdir() if k.is_dir()} if kl.exists() else {}
    plan = []
    for d in sorted(WYNIKI.iterdir()) if WYNIKI.exists() else []:
        if not d.is_dir() or d.name.startswith("_") or (d / MATERIALY).exists():
            continue
        m = re.fullmatch(r"([a-z0-9]+)_([a-z0-9]+)_(\d{6})(?:_(v?\d+))?", d.name)
        m2 = re.fullmatch(r"(\d{4}-\d{2}-\d{2})_([A-Z0-9]{4})_(.+?)(_v\d+)?", d.name)
        if not m and not m2:  # after-effects zostaje: Premiere ma do tych projektów żywe połączenie (Dynamic Link)
            continue
        zad = {}
        for z in ("zadanie.json", "zadanie_panel.json"):
            try:
                zad = json.loads((d / z).read_text(encoding="utf-8-sig"))
                break
            except Exception:
                pass
        zz = zad.get("zadanie", zad) if isinstance(zad, dict) else {}
        kk = zad.get("klient") if isinstance(zad.get("klient"), dict) else {}
        if d.name == "after-effects":
            plan.append({"z": d.name, "do": f"{nazwa_klienta('', '')}/Panel Premiere/After Effects", "uwaga": "projekty After Effects z panelu"})
            continue
        if m:
            kslug, pslug, data, wer = m.groups()
        else:
            data, kslug, pslug, wer = m2.group(1), "", m2.group(3), m2.group(4)
        kfold = (kk.get("folder") or "").split("/")[-1] or klienci.get(kslug, "")
        klient = kk.get("nazwa") or ""
        tytul = zz.get("tytul") or zz.get("title") or pslug.replace("-", " ")
        panel = bool(zad.get("zrodlo") == "premiere" or (d / "proces_panelu.json").exists() or (d / "zadanie_panel.json").exists())
        if re.search(r"animacje|napisy|ciecie|transkrypcja|multicam|miks", pslug) and not zz.get("tytul"):
            panel = True
        if m:
            dd = f"{data[0:2]}.{data[2:4]}.20{data[4:6]}"
        else:
            dd = f"{data[8:10]}.{data[5:7]}.{data[0:4]}"
        nazwa = czysta_nazwa(f"{tytul} {dd}" if not zz.get("tytul") else tytul) + (f" {wer.replace('_', '')}" if wer else "")
        kn = nazwa_klienta(klient, kfold) if (klient or kfold) else ladna_z_folderu(kslug) if kslug else "Bez klienta"
        plan.append({"z": d.name, "do": f"{kn}/{'Panel Premiere/' if panel else ''}{nazwa}", "panel": panel})
    return plan


def _przenies_ukryte(stary, nowy):
    """Zadanie z panelu usunięte z listy w Console zostaje ukryte także po przeniesieniu folderu (numer zależy od ścieżki)."""
    plik = SYSTEM / "studio" / "ukryte.json"
    try:
        u = json.loads(plik.read_text(encoding="utf-8"))
    except Exception:
        return
    def nr(p):
        return "panel~" + Path(p).resolve().relative_to(WYNIKI.resolve()).as_posix().replace("/", "~~")
    try:
        st, nw = nr(stary), nr(nowy)
    except ValueError:
        return
    if st in u and nw not in u:
        u.append(nw)
        plik.write_text(json.dumps(sorted(u), ensure_ascii=False, indent=1), encoding="utf-8")


def przenies_stare(plan):
    wyn = []
    for p in plan:
        zr, cel = WYNIKI / p["z"], WYNIKI / p["do"]
        cel = _wolna(cel)
        cel.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(zr), str(cel))
        popraw_sciezki(cel, [(zr, cel)])
        _przenies_ukryte(zr, cel)
        if not p.get("panel") and p["z"] != "after-effects":
            try:
                uporzadkuj(cel)
            except SystemExit:
                pass
        wyn.append({"z": p["z"], "do": str(cel.relative_to(WYNIKI))})
    return wyn


def main():
    ap = argparse.ArgumentParser(description="Porządek w wynikach")
    sub = ap.add_subparsers(dest="cmd", required=True)
    f = sub.add_parser("folder"); f.add_argument("--klient", default=""); f.add_argument("--tytul", required=True)
    f.add_argument("--id", default=""); f.add_argument("--klient-folder", default=""); f.add_argument("--panel", action="store_true")
    z = sub.add_parser("zadanie"); z.add_argument("--folder", required=True)
    sub.add_parser("system")
    s = sub.add_parser("stare"); s.add_argument("--wykonaj", action="store_true")
    a = ap.parse_args()
    if a.cmd == "folder":
        p = folder_zadania(a.klient, a.tytul, a.id, a.klient_folder, podfolder="Panel Premiere" if a.panel else None)
        wynik(folder=p.relative_to(KATALOG_SILNIKA).as_posix(), sciezka=str(p))
    elif a.cmd == "zadanie":
        fol = Path(a.folder)
        if not fol.is_absolute():
            fol = KATALOG_SILNIKA / fol
        wynik(**uporzadkuj(fol))
    elif a.cmd == "system":
        wynik(foldery=[str(system(n)) for n in SYSTEMOWE])
    else:
        plan = plan_starych()
        if not a.wykonaj:
            wynik(plan=plan, ile=len(plan), dalej="Żeby przenieść: python narzedzia/porzadek.py stare --wykonaj")
        else:
            wynik(przeniesione=przenies_stare(plan))


if __name__ == "__main__":
    main()
