# Animacje z mowy (zadanie z panelu Premiere)

Panel wysłał sekwencję, w której ktoś mówi. Twoje zadanie: posłuchać (przez transkrypcję), co i kiedy pada, i zaplanować animacje, napisy, szablony i przejścia, które podkreślą najważniejsze momenty. **Ty tylko planujesz.** Renderuje i wstawia panel (tak samo jak ręcznie), więc użytkownik może potem każdą rzecz kliknąć na osi i poprawić.

Użytkownika nie ma przy komputerze: nie zadawaj pytań, decyzje zapisz w `uzasadnienie` i w raporcie. Etapy przez `postep.py` (klucze: `przygotowanie`, `mowa`, `plan`, `kontrola`), na koniec `postep.py --gotowe --tekst "<1 zdanie>"`, przy błędzie `--blad "..."`.

## Dane

- `zadanie.json` w folderze zadania (ten sam JSON co w poleceniu): `ustawienia` (patrz niżej), `xml` (sekwencja), `fps`, `format`, `marka_z_panelu`, `klient`.
- `katalog.json` w folderze zadania: dostępne presety animacji (`animacje`: id, nazwa, kategoria, pola, domyślny czas) i szablony bez zdjęć (`szablony`: id, nazwa, kategoria, pola tekstowe). Wybieraj **tylko** z tej listy.
- `ciecia.json` w folderze zadania: klipy na osi (`start`, `end`, `tor`), z nich wynikają miejsca cięć.

## Kroki

1. `przygotowanie`: przeczytaj `zadanie.json`, `katalog.json`, `ciecia.json`. Jeśli jest klient, przeczytaj `marka.md` (ton, zakazane słowa, CTA).
2. `mowa`: `python narzedzia/ciecie.py analizuj --xml <xml> --folder <folder>/mowa --silnik <zadanie.mowa.silnik>` (i `--jezyk <zadanie.mowa.jezyk>`, gdy jest podany; to te same ustawienia co w Cięciu w panelu). Przeczytaj `<folder>/mowa/zdania.txt` (zdania z czasem na osi) i plik słów, jeśli jest.
3. `plan`: wybierz momenty i zapisz `<folder>/plan_animacji.json` (format niżej). Zasady:
   - **Liczba**: najwyżej `ustawienia.na_minute` pozycji na minutę mowy i najwyżej `ustawienia.maks` w sumie (0 = bez limitu sumy); przejścia i szablony liczą się osobno (`ustawienia.przejscia.maks`, `ustawienia.szablony_maks`). Przy natężeniu „mało” wybieraj tylko najmocniejsze momenty.
   - **Rodzaje**: tylko te z `ustawienia.rodzaje` (`tekst` = słowa kluczowe i hasła, `belki` = belka z imieniem i rolą, `liczby` = liczniki i statystyki, `cta` = wezwania, `rolki` = strzałki, nalepki, emoji, `przejscia`, `szablony`).
   - **Kiedy**: animacja startuje 0,1–0,3 s przed słowem, które podkreśla (`czas_s` na osi sekwencji). Między pozycjami co najmniej `ustawienia.odstep_s` sekund (przejścia się nie liczą). Nie zasłaniaj dwóch rzeczy naraz. Belka z imieniem: przy pierwszym pojawieniu się mówcy (imiona w `ustawienia.mowcy`, inaczej pomiń belki z nazwiskiem).
   - **Długość** (`dlugosc_s`): `ustawienia.dlugosc` (`krotko` 1,5–2,5 s, `standard` 2,5–4 s, `dluzej` 4–6 s, `auto` = tyle, ile trwa myśl), nigdy dłużej niż do następnej pozycji.
   - **Teksty**: krótkie (do 6–7 słów), w języku `ustawienia.jezyk` (`jak_mowa` = jak mówi), wyróżnienie najważniejszego słowa `*gwiazdkami*`, bez zakazanych słów marki. Liczby przepisuj dokładnie tak, jak padły. Emoji tylko gdy `ustawienia.emoji`.
   - **Styl**: `ustawienia.styl` (`auto`, `minimal` = proste napisy i belki, `dynamiczny` = mocne wejścia, liczby, nalepki, `kinowy` = eleganckie, spokojne, mało elementów, `social` = jak TikTok/Reels: dużo energii, emoji, strzałki). Dobieraj presety po polu `gust` z `python narzedzia/animacje.py lista`: `minimal`, `kinowy` i `auto` = tylko gust „spokojne”, najwyżej 1 rzecz na 10 s, bez emoji (`auto` inaczej tylko wtedy, gdy „gust marki” w `marka.md` mówi, że marka jest zabawna albo energiczna); `dynamiczny` = „spokojne” plus „social” (liczniki, wykresy, mocniejsze wejścia); `social` = wolno też emoji, strzałki i naklejki (`--wszystkie`), z ustawieniem `sprezystosc` 0.8–1. Zawsze sekcja „Gust: kadr, ruch, napisy i umiar” w `CLAUDE.md` (duży tekst, bezpieczna strefa, jedna rzecz naraz).
   - **Pozycja**: tylko z `ustawienia.pozycje` (pole `pozycja` w parametrach: `dol`, `gora`, `srodek`, `lewy-dol`, `prawy-dol`, `lewy-gora`, `prawy-gora`); belki zwykle `lewy-dol`.
   - **Przejścia** (`ustawienia.przejscia.tryb`): `brak`; `tematy` = tylko na cięciach, gdzie zmienia się temat rozmowy; `ciecia` = co któreś cięcie (`co_ile`). Przejście kładziesz na cięciu (`czas_s` = czas cięcia z `ciecia.json`); `dlugosc_s` z presetu.
   - **Fragment**: gdy `ustawienia.zakres` ma `od_s`/`do_s`, planuj tylko w tym fragmencie.
   - `ustawienia.uwagi` od użytkownika mają pierwszeństwo przed tymi zasadami.
4. `kontrola`: sprawdź plan: czasy rosną, nic nie wychodzi poza sekwencję, odstępy i limity zgodne z ustawieniami, każdy `preset`/`szablon` jest w `katalog.json`, pola zgadzają się z polami presetu. Popraw i zapisz.

## Format `plan_animacji.json`

```json
{"pozycje": [
  {"rodzaj": "animacja", "preset": "<id z katalog.animacje>", "czas_s": 12.4, "dlugosc_s": 3.0,
   "parametry": {"tekst": "Wzrost *o 250%*", "pozycja": "dol"}, "slowa": "co dokładnie padło", "uzasadnienie": "krótko po polsku"},
  {"rodzaj": "przejscie", "preset": "<id przejścia>", "czas_s": 30.12, "parametry": {}, "uzasadnienie": "zmiana tematu"},
  {"rodzaj": "szablon", "szablon": "<id z katalog.szablony>", "czas_s": 45.0, "dlugosc_s": 4.0, "pola": {"<pole>": "tekst"}, "uzasadnienie": "..."}
], "podsumowanie": "1–2 zdania: co i dlaczego"}
```

`parametry` to pola presetu z `katalog.json` (np. `tekst`, `tekst2`, `liczba`, `po`, `lista`, `emoji`) i opcjonalnie `pozycja`. Kolorów i fontu nie podawaj: panel bierze je z marki.
