/* Biblioteka animacji Studio Nadamedia.
 *
 * Jedno źródło dla: panelu w Premiere (podgląd i render do MOV z przezroczystością), Studio (galeria z podglądem)
 * i silnika (node render.js, gdy Claude robi animacje sam).
 *
 * Każdy preset rysuje jedną klatkę: NMAnim.rysuj(ctx, idPresetu, t, parametry, W, H)
 *   t – czas w sekundach od początku animacji, W×H – rozmiar klatki.
 * Tło zostaje przezroczyste: rysowane są tylko elementy animacji.
 *
 * Parametry wspólne (wszystkie opcjonalne, domyślne w DOMYSLNE):
 *   tekst, tekst2, lista (linie albo „a; b; c”, w wykresach „etykieta:wartość”), liczba, od, przed, po,
 *   x, y, x2, y2 (0–1, punkt na kadrze dla strzałek, kółek, pinezek), emoji,
 *   kolor_glowny, kolor_akcent, kolor_tekstu, kolor_tla, font, waga, rozmiar (mnożnik), wielkie (WIELKIE LITERY),
 *   cien, pozycja (srodek, gora, dol, lewy-dol, lewy-gora, prawy-dol, prawy-gora), tempo (mnożnik szybkości wejścia),
 *   czas (s), wyjscie (s), wyjscie_styl (zanik, w-gore, w-dol, zoom, brak), logo (obraz, jeśli jest),
 *   sprezystosc (0 = ruch bez przestrzelenia, 0.35 domyślnie = lekkie „dosiadanie”, 1 = mocne odbicie w stylu social).
 * W tekście *gwiazdki* wyróżniają słowa kolorem akcentu.
 *
 * Własne presety (np. napisane przez Claude z opisu) dodaje się przez NMAnim.dodaj({...}) w plikach wlasne/*.js;
 * wzór na dole tego pliku (sekcja „Jak napisać preset”).
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.NMAnim = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  // ---------- matematyka i ruch ----------
  const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
  const lerp = (a, b, t) => a + (b - a) * t;
  // sprężystość ruchu (0 = bez przestrzelenia, 1 = pełne „boing” jak dawniej); ustawiana z parametru `sprezystosc` przy każdym rysowaniu.
  // Domyślnie 0.35: ruch hamuje miękko i tylko lekko „dosiada”, jak w dzisiejszym motion designie.
  let SPREZYNA = 0.35;
  const E = {
    lin: (t) => t,
    inCubic: (t) => t * t * t,
    outCubic: (t) => 1 - Math.pow(1 - t, 3),
    inOutCubic: (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
    outQuint: (t) => 1 - Math.pow(1 - t, 5),
    outExpo: (t) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t)),
    inExpo: (t) => (t <= 0 ? 0 : Math.pow(2, 10 * t - 10)),
    outBack: (t) => { const c1 = 1.70158 * SPREZYNA, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
    outBackMocno: (t) => { const c1 = 3 * SPREZYNA, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
    inBack: (t) => { const c1 = 1.70158; return (c1 + 1) * t * t * t - c1 * t * t; },
    outElastic: (t) => (t <= 0 ? 0 : t >= 1 ? 1 : Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * (2 * Math.PI) / 3) + 1),
    outBounce: (t) => {
      const n = 7.5625, d = 2.75;
      if (t < 1 / d) return n * t * t;
      if (t < 2 / d) return n * (t -= 1.5 / d) * t + 0.75;
      if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + 0.9375;
      return n * (t -= 2.625 / d) * t + 0.984375;
    },
  };
  const okno = (t, od, dl) => (dl <= 0 ? (t >= od ? 1 : 0) : clamp((t - od) / dl));
  const los = (n) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };

  // ---------- kolory ----------
  function rgb(hex) {
    let h = String(hex || "#000").replace("#", "").trim();
    if (h.length === 3) h = h.split("").map((c) => c + c).join("");
    const n = parseInt(h.slice(0, 6), 16) || 0;
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  const rgba = (hex, a) => { const [r, g, b] = rgb(hex); return `rgba(${r},${g},${b},${a})`; };
  const jasnosc = (hex) => { const [r, g, b] = rgb(hex); return (0.299 * r + 0.587 * g + 0.114 * b) / 255; };
  const kontrast = (hex) => (jasnosc(hex) > 0.6 ? "#111111" : "#FFFFFF");
  function ciemniej(hex, k) { const [r, g, b] = rgb(hex); const f = (v) => Math.round(v * (1 - k)); return `rgb(${f(r)},${f(g)},${f(b)})`; }

  // ---------- płótno pomocnicze (warstwy) ----------
  let fabryka = null;
  function nowyCanvas(w, h) {
    if (fabryka) return fabryka(w, h);
    if (typeof OffscreenCanvas !== "undefined") return new OffscreenCanvas(w, h);
    const c = document.createElement("canvas"); c.width = w; c.height = h; return c;
  }
  const bufory = {};
  function warstwa(s, nr, rysujFn) {
    const k = `${nr}_${s.W}x${s.H}`;
    let c = bufory[k];
    if (!c) c = bufory[k] = nowyCanvas(s.W, s.H);
    const x = c.getContext("2d");
    x.setTransform(1, 0, 0, 1, 0, 0);
    x.globalAlpha = 1;
    x.globalCompositeOperation = "source-over";
    x.clearRect(0, 0, s.W, s.H);
    rysujFn(x);
    return c;
  }

  // ---------- kształty ----------
  function zaokr(ctx, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2));
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }
  function gwiazda(ctx, cx, cy, ramiona, r1, r2, obrot = 0) {
    ctx.beginPath();
    for (let i = 0; i < ramiona * 2; i++) {
      const r = i % 2 ? r2 : r1, a = obrot + (i * Math.PI) / ramiona - Math.PI / 2;
      i ? ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r) : ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
    }
    ctx.closePath();
  }
  function serce(ctx, cx, cy, r) {
    ctx.beginPath();
    ctx.moveTo(cx, cy + r * 0.9);
    ctx.bezierCurveTo(cx - r * 1.6, cy - r * 0.1, cx - r * 0.7, cy - r * 1.2, cx, cy - r * 0.45);
    ctx.bezierCurveTo(cx + r * 0.7, cy - r * 1.2, cx + r * 1.6, cy - r * 0.1, cx, cy + r * 0.9);
    ctx.closePath();
  }
  function kursor(ctx, x, y, sk, kolor = "#FFFFFF") {
    ctx.save(); ctx.translate(x, y); ctx.scale(sk, sk);
    ctx.beginPath();
    ctx.moveTo(0, 0); ctx.lineTo(0, 34); ctx.lineTo(9, 26); ctx.lineTo(15, 40); ctx.lineTo(21, 37); ctx.lineTo(15, 24); ctx.lineTo(26, 24);
    ctx.closePath();
    ctx.fillStyle = kolor; ctx.strokeStyle = "#111"; ctx.lineWidth = 2.5; ctx.lineJoin = "round";
    ctx.fill(); ctx.stroke(); ctx.restore();
  }
  function ptaszek(ctx, x, y, r, e, kolor, gr) {
    // znak „✓” rysowany od lewej do prawej, e = 0..1
    const p = [[x - r * 0.55, y], [x - r * 0.15, y + r * 0.42], [x + r * 0.6, y - r * 0.45]];
    const d1 = Math.hypot(p[1][0] - p[0][0], p[1][1] - p[0][1]), d2 = Math.hypot(p[2][0] - p[1][0], p[2][1] - p[1][1]);
    const L = (d1 + d2) * e;
    ctx.beginPath(); ctx.moveTo(...p[0]);
    if (L <= d1) ctx.lineTo(lerp(p[0][0], p[1][0], L / d1), lerp(p[0][1], p[1][1], L / d1));
    else { ctx.lineTo(...p[1]); const k = (L - d1) / d2; ctx.lineTo(lerp(p[1][0], p[2][0], k), lerp(p[1][1], p[2][1], k)); }
    ctx.strokeStyle = kolor; ctx.lineWidth = gr; ctx.lineCap = "round"; ctx.lineJoin = "round"; ctx.stroke();
  }
  // linia po punktach rysowana do ułamka e (do strzałek i tras)
  function sciezkaCzesc(ctx, pkt, e) {
    const dl = []; let suma = 0;
    for (let i = 1; i < pkt.length; i++) { const d = Math.hypot(pkt[i][0] - pkt[i - 1][0], pkt[i][1] - pkt[i - 1][1]); dl.push(d); suma += d; }
    let zostalo = suma * clamp(e); ctx.beginPath(); ctx.moveTo(...pkt[0]);
    let koniec = pkt[0], kier = 0;
    for (let i = 1; i < pkt.length; i++) {
      if (zostalo <= 0) break;
      const d = dl[i - 1], k = Math.min(1, zostalo / d);
      koniec = [lerp(pkt[i - 1][0], pkt[i][0], k), lerp(pkt[i - 1][1], pkt[i][1], k)];
      kier = Math.atan2(pkt[i][1] - pkt[i - 1][1], pkt[i][0] - pkt[i - 1][0]);
      ctx.lineTo(...koniec); zostalo -= d;
    }
    return { koniec, kier, suma };
  }
  function krzywa(a, b, c, n = 40) { // kwadratowa Béziera jako punkty
    const w = [];
    for (let i = 0; i <= n; i++) { const t = i / n; w.push([(1 - t) * (1 - t) * a[0] + 2 * (1 - t) * t * b[0] + t * t * c[0], (1 - t) * (1 - t) * a[1] + 2 * (1 - t) * t * b[1] + t * t * c[1]]); }
    return w;
  }

  // ---------- tekst ----------
  // po fontach z literami fonty z emoji (bez nich @napi-rs/canvas rysuje emoji w tekście jako puste kwadraty)
  const FONT_ZAPAS = '"Segoe UI", "Helvetica Neue", Arial, "Liberation Sans", "DejaVu Sans", "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif';
  const font = (s, px, waga) => `${s.p.kursywa ? "italic " : ""}${waga || s.p.waga} ${Math.max(1, Math.round(px))}px "${s.p.font}", ${FONT_ZAPAS}`;
  const tekstP = (s, t) => { t = String(t == null ? "" : t); return s.p.wielkie ? t.toLocaleUpperCase("pl") : t; };
  function slowaZ(t) {
    const w = []; let wyr = false;
    String(t).split(/\s+/).filter(Boolean).forEach((x) => {
      let start = false, kon = false;
      if (x.startsWith("*")) { start = true; x = x.slice(1); }
      if (x.endsWith("*") || x.match(/\*[.,!?:;…]+$/)) { kon = true; x = x.replace(/\*([.,!?:;…]*)$/, "$1"); }
      if (start) wyr = true;
      if (x) w.push({ t: x, wyr });
      if (kon) wyr = false;
    });
    return w;
  }
  /* Układ akapitu: słowa z pozycją (x lewej krawędzi, y środka linii), linie, rozmiar bloku. */
  function uloz(s, tekst, px, o = {}) {
    const ctx = s.ctx, waga = o.waga || s.p.waga;
    ctx.font = font(s, px, waga);
    const maxW = o.maxW || s.W * 0.84 * (s.p.szerokosc || 1), lh = (o.lh || 1.12) * px * (s.p.interlinia || 1), align = o.align || s.poz.align;
    const sp = ctx.measureText(" ").width;
    const linie = []; let lin = { slowa: [], w: 0 };
    // Enter w polu tekstu = nowa linia: wtedy linie są dokładnie takie, jak wpisane (bez samoczynnego łamania)
    const akapity = String(tekstP(s, tekst)).split(/\r?\n/), reczne = akapity.filter((x) => x.trim()).length > 1;
    akapity.forEach((ak, ai) => {
      if (ai > 0 && lin.slowa.length && !o.jednaLinia) { linie.push(lin); lin = { slowa: [], w: 0 }; }
      slowaZ(ak).forEach((sl) => {
        sl.w = ctx.measureText(sl.t).width;
        const nw = lin.slowa.length ? lin.w + sp + sl.w : sl.w;
        if (lin.slowa.length && nw > maxW && !o.jednaLinia && !reczne) { linie.push(lin); lin = { slowa: [], w: 0 }; lin.slowa.push(sl); lin.w = sl.w; }
        else { lin.slowa.push(sl); lin.w = nw; }
      });
    });
    if (lin.slowa.length) linie.push(lin);
    const x = o.x != null ? o.x : s.poz.x, y = o.y != null ? o.y : s.poz.y;
    const h = linie.length * lh, y0 = (o.gora ? y : y - h / 2) + lh / 2;
    const slowa = []; let i = 0;
    linie.forEach((l, li) => {
      let xx = align === "left" ? x : align === "right" ? x - l.w : x - l.w / 2;
      l.x0 = xx; l.y = y0 + li * lh;
      l.slowa.forEach((sl) => { sl.x = xx; sl.y = l.y; sl.i = i++; sl.li = li; slowa.push(sl); xx += sl.w + sp; });
    });
    const szer = Math.max(0, ...linie.map((l) => l.w));
    const lewa = align === "left" ? x : align === "right" ? x - szer : x - szer / 2;
    return { slowa, linie, px, lh, h, w: szer, x: lewa, y: y0 - lh / 2, waga, font: font(s, px, waga), sp };
  }
  /* Znaki z pozycją (do animacji litera po literze). */
  function znaki(s, ul) {
    const ctx = s.ctx; ctx.font = ul.font;
    const z = []; let i = 0;
    ul.slowa.forEach((sl) => {
      let pref = "";
      for (const c of Array.from(sl.t)) {
        const x = sl.x + ctx.measureText(pref).width, w = ctx.measureText(c).width;
        z.push({ c, x, y: sl.y, w, slowo: sl, i: i++ }); pref += c;
      }
    });
    return z;
  }
  /* Rozmiar fontu, przy którym tekst mieści się w jednej linii o szerokości maxW. */
  function dopasuj(s, tekst, px, maxW, waga) {
    s.ctx.font = font(s, px, waga);
    const w = s.ctx.measureText(tekstP(s, tekst)).width;
    return w > maxW ? px * maxW / w : px;
  }
  function cien(s, ctx = s.ctx, mocno = 1) {
    if (!s.p.cien) return;
    mocno *= s.p.cien_moc == null ? 1 : +s.p.cien_moc;
    // cień tylko dla czytelności na jasnym obrazie: krótki i blisko liter (nie „pływający” tekst)
    ctx.shadowColor = rgba(s.p.kolor_cienia || "#000000", Math.min(1, 0.3 * mocno)); ctx.shadowBlur = 10 * s.u * mocno; ctx.shadowOffsetY = 2 * s.u * mocno;
  }
  const bezCienia = (ctx) => { ctx.shadowColor = "transparent"; ctx.shadowBlur = 0; ctx.shadowOffsetY = 0; ctx.shadowOffsetX = 0; };
  function piszSlowo(s, sl, kolor, ctx = s.ctx, dx = 0, dy = 0) {
    ctx.fillStyle = sl.wyr ? s.k.a : (kolor || s.k.t);
    ctx.fillText(sl.t, sl.x + dx, sl.y + dy);
  }
  function lista(t) {
    return String(t || "").split(/\n|;|\|/).map((x) => x.trim()).filter(Boolean);
  }
  function pary(t) {
    return lista(t).map((x) => { const m = x.match(/^(.*?)[:=]\s*(-?[\d.,]+)\s*$/); return m ? { e: m[1].trim(), v: parseFloat(m[2].replace(",", ".")) } : { e: x, v: 0 }; });
  }
  function liczbaTekst(v, miejsca = 0) {
    const t = Number(v).toFixed(miejsca);
    const [c, u] = t.split(".");
    return c.replace(/\B(?=(\d{3})+(?!\d))/g, " ") + (u ? "," + u : "");
  }
  function miejscaPo(v) { const t = String(v); return t.includes(".") ? Math.min(2, t.split(".")[1].length) : 0; }

  // ---------- pozycje ----------
  const POZYCJE = {
    // bezpieczne strefy telefonu (pion): góra 14% pasek aplikacji, dół 25% opis i nazwa konta, prawe 12% serduszko i komentarze
    srodek: [0.5, 0.5, "center"], gora: [0.5, 0.2, "center"], dol: [0.5, 0.7, "center"],
    "lewy-dol": [0.07, 0.72, "left"], "lewy-gora": [0.07, 0.18, "left"], "lewy-srodek": [0.07, 0.5, "left"],
    "prawy-dol": [0.86, 0.72, "right"], "prawy-gora": [0.86, 0.18, "right"],
  };

  // ---------- presety ----------
  const PRESETY = [];
  const KATEGORIE = [
    { id: "tekst", nazwa: "Napisy i tytuły" },
    { id: "belki", nazwa: "Belki z nazwiskiem" },
    { id: "rolki", nazwa: "Grafiki do rolek" },
    { id: "liczby", nazwa: "Liczby i wykresy" },
    { id: "cta", nazwa: "Wezwania do działania" },
    { id: "ksztalty", nazwa: "Kształty, ramki i strzałki" },
    { id: "przejscia", nazwa: "Przejścia i akcenty" },
    { id: "wlasne", nazwa: "Własne" },
  ];
  function dodaj(p) {
    const i = PRESETY.findIndex((x) => x.id === p.id);
    if (i >= 0) PRESETY.splice(i, 1, p); else PRESETY.push(p);
    return p;
  }
  const DOMYSLNE = {
    tekst: "Twój tekst *tutaj*", tekst2: "", lista: "", liczba: 100, od: 0, przed: "", po: "", emoji: "🔥",
    x: 0.5, y: 0.5, x2: 0.78, y2: 0.3,
    // bez marki: spokojna grafitowa baza i jeden ciepły akcent (wcześniej pomarańcz z żółtym)
    kolor_glowny: "#16181D", kolor_akcent: "#FF7A45", kolor_tekstu: "#FFFFFF", kolor_tla: "#141414", sprezystosc: 0.35,
    font: "Montserrat", waga: 800, rozmiar: 1, wielkie: false, cien: true, pozycja: null, tempo: 1,
    czas: null, wyjscie: 0.4, wyjscie_styl: "zanik", logo: null,
    // wspólne dla wszystkich presetów (panel: „Ruch i układ” i „Tekst”)
    kursywa: false, interlinia: 1, odstep: 0, szerokosc: 1, obrys: 0, kolor_obrysu: "#000000", cien_moc: 1, kolor_cienia: "#000000",
    przesun_x: 0, przesun_y: 0, obrot: 0, krycie: 1, opoznienie: 0, wejscie_styl: "",
  };

  // Teksty — wejście słowami / literami
  dodaj({ id: "pop-slowa", nazwa: "Słowa wyskakują", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "To *zmieni* wszystko" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      ul.slowa.forEach((w) => {
        const e = okno(s.t, w.i * 0.11 / s.p.tempo, 0.38 / s.p.tempo); if (e <= 0) return;
        const sc = E.outBackMocno(e);
        ctx.save(); ctx.translate(w.x + w.w / 2, w.y); ctx.scale(sc, sc); ctx.globalAlpha *= clamp(e * 3);
        cien(s); piszSlowo(s, w, null, ctx, -w.x - w.w / 2, -w.y); ctx.restore();
      });
    } });
  dodaj({ id: "maszyna", nazwa: "Maszyna do pisania", kat: "tekst", czas: 3.5, pola: ["tekst"], przyklad: { tekst: "Pisane na *żywo*…" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 90 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul);
      const ile = Math.floor(okno(s.t, 0.1, z.length * 0.055 / s.p.tempo) * z.length);
      ctx.font = ul.font; cien(s);
      z.slice(0, ile).forEach((c) => { ctx.fillStyle = c.slowo.wyr ? s.k.a : s.k.t; ctx.fillText(c.c, c.x, c.y); });
      const ost = z[Math.max(0, ile - 1)];
      if (ost && Math.floor(s.t * 2.2) % 2 === 0 || ile < z.length) {
        const x = ile ? ost.x + ost.w + 4 * s.u : z[0].x, y = ile ? ost.y : z[0].y;
        bezCienia(ctx); ctx.fillStyle = s.k.a; ctx.fillRect(x, y - ul.px * 0.42, 7 * s.u, ul.px * 0.84);
      }
    } });
  dodaj({ id: "maska-linie", nazwa: "Linie wysuwają się spod maski", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Nowy rozdział *zaczyna się* dziś" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 96 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      ul.linie.forEach((l, li) => {
        const e = E.outQuint(okno(s.t, li * 0.12 / s.p.tempo, 0.7 / s.p.tempo));
        ctx.save(); ctx.beginPath(); ctx.rect(0, l.y - ul.lh * 0.6, s.W, ul.lh * 1.2); ctx.clip();
        const dy = (1 - e) * ul.lh * 1.1;
        l.slowa.forEach((w) => piszSlowo(s, w, null, ctx, 0, dy)); ctx.restore();
      });
    } });
  dodaj({ id: "maska-slowa", nazwa: "Słowa wjeżdżają z dołu", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Krok po *kroku* do celu" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 96 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      ul.slowa.forEach((w) => {
        const e = E.outCubic(okno(s.t, w.i * 0.09 / s.p.tempo, 0.5 / s.p.tempo));
        ctx.save(); ctx.beginPath(); ctx.rect(w.x - 20 * s.u, w.y - ul.lh * 0.6, w.w + 40 * s.u, ul.lh * 1.2); ctx.clip();
        piszSlowo(s, w, null, ctx, 0, (1 - e) * ul.lh); ctx.restore();
      });
    } });
  dodaj({ id: "rozmycie", nazwa: "Wyostrzenie z rozmycia", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Skup się na *tym*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      ul.slowa.forEach((w) => {
        const e = E.outCubic(okno(s.t, w.i * 0.1 / s.p.tempo, 0.7 / s.p.tempo)); if (e <= 0) return;
        ctx.save(); ctx.globalAlpha *= e;
        const b = (1 - e) * 22 * s.u; if (b > 0.3) ctx.filter = `blur(${b.toFixed(1)}px)`;
        const sc = lerp(1.25, 1, e); ctx.translate(w.x + w.w / 2, w.y); ctx.scale(sc, sc);
        piszSlowo(s, w, null, ctx, -w.x - w.w / 2, -w.y); ctx.restore();
      });
    } });
  dodaj({ id: "sprezyna-litery", nazwa: "Litery podskakują", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Super *okazja*!" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 104 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul); ctx.font = ul.font; cien(s);
      z.forEach((c) => {
        const e = okno(s.t, c.i * 0.028 / s.p.tempo, 0.5 / s.p.tempo); if (e <= 0) return;
        ctx.save(); ctx.globalAlpha *= clamp(e * 2.5);
        ctx.fillStyle = c.slowo.wyr ? s.k.a : s.k.t; ctx.fillText(c.c, c.x, c.y + (1 - E.outBackMocno(e)) * ul.px * 0.9); ctx.restore();
      });
    } });
  dodaj({ id: "fala", nazwa: "Fala liter", kat: "tekst", czas: 4, pola: ["tekst"], przyklad: { tekst: "Lato w *pełni*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul); ctx.font = ul.font; cien(s);
      z.forEach((c) => {
        const e = okno(s.t, c.i * 0.03 / s.p.tempo, 0.35); if (e <= 0) return;
        ctx.globalAlpha = e * s.alfa; ctx.fillStyle = c.slowo.wyr ? s.k.a : s.k.t;
        ctx.fillText(c.c, c.x, c.y + Math.sin(s.t * 5 - c.i * 0.55) * 12 * s.u * s.p.rozmiar);
      });
      ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "glitch", nazwa: "Glitch", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "SYSTEM *ERROR*", wielkie: true },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 104 * s.u * s.p.rozmiar), ctx = s.ctx;
      const krok = Math.floor(s.t * 14), zaklocenie = s.t < 0.6 / s.p.tempo || (s.t % 1.6) < 0.14;
      const c = warstwa(s, "glitch", (x) => { x.font = ul.font; x.textBaseline = "middle"; ul.slowa.forEach((w) => piszSlowo(s, w, null, x)); });
      const o = zaklocenie ? (los(krok) - 0.5) * 26 * s.u : 0;
      if (zaklocenie) {
        const kan = warstwa(s, "glitch2", (x) => { x.drawImage(c, 0, 0); x.globalCompositeOperation = "source-in"; x.fillStyle = "#00E5FF"; x.fillRect(0, 0, s.W, s.H); });
        ctx.save(); ctx.globalAlpha *= 0.8; ctx.drawImage(kan, o, 0); ctx.restore();
        const kan2 = warstwa(s, "glitch3", (x) => { x.drawImage(c, 0, 0); x.globalCompositeOperation = "source-in"; x.fillStyle = "#FF2E88"; x.fillRect(0, 0, s.W, s.H); });
        ctx.save(); ctx.globalAlpha *= 0.8; ctx.drawImage(kan2, -o, 0); ctx.restore();
        const y0 = ul.y, h = ul.h;
        for (let i = 0; i < 6; i++) {
          const yy = y0 + los(krok * 7 + i) * h, hh = (0.05 + los(krok + i * 3) * 0.12) * h, dx = (los(krok * 3 + i) - 0.5) * 60 * s.u;
          ctx.drawImage(c, 0, yy, s.W, hh, dx, yy, s.W, hh);
        }
        ctx.save(); ctx.globalAlpha *= 0.5; ctx.drawImage(c, 0, 0); ctx.restore();
      } else ctx.drawImage(c, 0, 0);
    } });
  dodaj({ id: "zakreslacz", nazwa: "Zakreślacz", kat: "tekst", czas: 3.5, pola: ["tekst"], przyklad: { tekst: "To jest *najważniejsze*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 96 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      const wej = E.outCubic(okno(s.t, 0, 0.45 / s.p.tempo));
      let cel = ul.slowa.filter((w) => w.wyr); if (!cel.length) cel = ul.linie[ul.linie.length - 1].slowa;
      const e = E.inOutCubic(okno(s.t, 0.45 / s.p.tempo, 0.55 / s.p.tempo));
      const grupy = {}; cel.forEach((w) => (grupy[w.li] = grupy[w.li] || []).push(w));
      Object.values(grupy).forEach((g) => {
        const x0 = g[0].x - 14 * s.u, x1 = g[g.length - 1].x + g[g.length - 1].w + 14 * s.u;
        ctx.save(); ctx.fillStyle = s.k.a; ctx.translate(0, g[0].y); ctx.transform(1, 0, -0.12, 1, 0, 0);
        zaokr(ctx, x0, -ul.px * 0.42, (x1 - x0) * e, ul.px * 0.86, 8 * s.u); ctx.fill(); ctx.restore();
      });
      ctx.globalAlpha = s.alfa * wej;
      ul.slowa.forEach((w) => {
        const pod = cel.includes(w);
        ctx.fillStyle = pod && e > 0.5 ? kontrast(s.k.a) : s.k.t;
        ctx.fillText(w.t, w.x, w.y + (1 - wej) * 30 * s.u);
      });
      ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "odkrycie-blokiem", nazwa: "Odkrycie blokiem", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Premiera *już jutro*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 96 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      ul.linie.forEach((l, li) => {
        const d = li * 0.12 / s.p.tempo, a = E.inOutCubic(okno(s.t, d, 0.4 / s.p.tempo)), b = E.inOutCubic(okno(s.t, d + 0.4 / s.p.tempo, 0.4 / s.p.tempo));
        const pad = 12 * s.u, x0 = l.x0 - pad, w = l.w + pad * 2, y = l.y - ul.lh * 0.5;
        if (b > 0) l.slowa.forEach((w2) => piszSlowo(s, w2));
        ctx.fillStyle = li % 2 ? s.k.a : s.k.g;
        const lewo = x0 + w * b, prawo = x0 + w * a;
        if (prawo > lewo) ctx.fillRect(lewo, y, prawo - lewo, ul.lh);
      });
    } });
  dodaj({ id: "podkreslenie", nazwa: "Podkreślenie", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Zapamiętaj *to*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 96 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      const e = E.outCubic(okno(s.t, 0, 0.5 / s.p.tempo)), l = E.inOutCubic(okno(s.t, 0.35 / s.p.tempo, 0.6 / s.p.tempo));
      ctx.globalAlpha = s.alfa * e; cien(s); ul.slowa.forEach((w) => piszSlowo(s, w, null, ctx, 0, (1 - e) * 24 * s.u)); bezCienia(ctx);
      ctx.globalAlpha = s.alfa;
      const ost = ul.linie[ul.linie.length - 1], y = ost.y + ul.px * 0.62;
      ctx.strokeStyle = s.k.a; ctx.lineWidth = 10 * s.u * s.p.rozmiar; ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(ul.x, y); ctx.lineTo(ul.x + ul.w * l, y); ctx.stroke();
    } });
  dodaj({ id: "stos-slow", nazwa: "Stos słów", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Mniej gadania *więcej* robienia", wielkie: true },
    rysuj(s) {
      const ctx = s.ctx, sl = slowaZ(tekstP(s, s.p.tekst)); if (!sl.length) return;
      const px0 = 150 * s.u * s.p.rozmiar, maxW = s.W * 0.8;
      const rozm = sl.map((w) => dopasuj(s, w.t, px0, maxW));
      const lh = rozm.map((r) => r * 0.98), h = lh.reduce((a, b) => a + b, 0);
      let y = s.poz.y - h / 2;
      sl.forEach((w, i) => {
        const e = okno(s.t, i * 0.16 / s.p.tempo, 0.3 / s.p.tempo); y += lh[i] / 2;
        if (e > 0) {
          ctx.save(); ctx.font = font(s, rozm[i], 900); const sz = ctx.measureText(w.t).width;
          const x = s.poz.align === "left" ? s.poz.x : s.poz.align === "right" ? s.poz.x - sz : s.poz.x - sz / 2;
          const sc = lerp(1.7, 1, E.outExpo(e)); ctx.translate(x + sz / 2, y); ctx.scale(sc, sc); ctx.globalAlpha *= clamp(e * 2);
          cien(s); ctx.fillStyle = w.wyr ? s.k.a : i % 2 ? s.k.t : s.k.t; ctx.fillText(w.t, -sz / 2, 0); ctx.restore();
        }
        y += lh[i] / 2;
      });
    } });
  dodaj({ id: "neon", nazwa: "Neon", kat: "tekst", czas: 3.5, pola: ["tekst"], przyklad: { tekst: "Open *late*", kolor_akcent: "#FF3CAC" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      const t = s.t * s.p.tempo, migot = t < 0.9 ? (los(Math.floor(t * 22)) > 0.45 ? 1 : 0.15) : 1;
      ctx.globalAlpha = s.alfa * migot; ctx.lineWidth = 3 * s.u; ctx.lineJoin = "round";
      ctx.shadowColor = s.k.a; ctx.shadowBlur = 34 * s.u * (0.8 + 0.2 * Math.sin(s.t * 6));
      ul.slowa.forEach((w) => { ctx.strokeStyle = s.k.a; ctx.strokeText(w.t, w.x, w.y); });
      ctx.shadowBlur = 12 * s.u; ul.slowa.forEach((w) => { ctx.fillStyle = "#FFFFFF"; ctx.fillText(w.t, w.x, w.y); });
      bezCienia(ctx); ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "blysk", nazwa: "Błysk przez tekst", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Edycja *premium*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx;
      const e = E.outCubic(okno(s.t, 0, 0.5 / s.p.tempo)), b = okno(s.t, 0.5 / s.p.tempo, 0.8 / s.p.tempo);
      const c = warstwa(s, "blysk", (x) => {
        x.font = ul.font; x.textBaseline = "middle"; ul.slowa.forEach((w) => piszSlowo(s, w, null, x));
        if (b > 0 && b < 1) {
          x.globalCompositeOperation = "source-atop";
          const sx = lerp(ul.x - ul.w * 0.4, ul.x + ul.w * 1.4, b), g = x.createLinearGradient(sx - 120 * s.u, 0, sx + 120 * s.u, 0);
          g.addColorStop(0, "rgba(255,255,255,0)"); g.addColorStop(0.5, "rgba(255,255,255,0.95)"); g.addColorStop(1, "rgba(255,255,255,0)");
          x.fillStyle = g; x.fillRect(0, 0, s.W, s.H);
        }
      });
      ctx.save(); ctx.globalAlpha *= e; ctx.translate(0, (1 - e) * 30 * s.u); cien(s); ctx.drawImage(c, 0, 0); ctx.restore();
    } });
  dodaj({ id: "rozstrzelenie", nazwa: "Litery zbiegają się", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "KOLEKCJA 2026", wielkie: true, waga: 600 },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 92 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul); ctx.font = ul.font;
      const e = E.outQuint(okno(s.t, 0, 1.2 / s.p.tempo)), cx = ul.x + ul.w / 2;
      ctx.globalAlpha = s.alfa * clamp(e * 1.5); cien(s);
      z.forEach((c) => { ctx.fillStyle = c.slowo.wyr ? s.k.a : s.k.t; ctx.fillText(c.c, cx + (c.x - cx) * (1 + (1 - e) * 0.7), c.y); });
      ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "uderzenie", nazwa: "Uderzenie z ekranu", kat: "tekst", czas: 2.5, pola: ["tekst"], przyklad: { tekst: "BOOM!", wielkie: true },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 130 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      const d = 0.35 / s.p.tempo, e = okno(s.t, 0, d), cx = ul.x + ul.w / 2, cy = ul.y + ul.h / 2;
      const drg = s.t > d && s.t < d + 0.25 ? (los(Math.floor(s.t * 60)) - 0.5) * 16 * s.u * (1 - (s.t - d) / 0.25) : 0;
      const rysujRaz = (sc, a) => { ctx.save(); ctx.globalAlpha *= a; ctx.translate(cx + drg, cy + drg * 0.6); ctx.scale(sc, sc); ctx.translate(-cx, -cy); ul.slowa.forEach((w) => piszSlowo(s, w)); ctx.restore(); };
      if (e < 1) { for (let i = 3; i >= 1; i--) rysujRaz(lerp(3, 1, E.inExpo(clamp(e - i * 0.06))), 0.15); }
      cien(s); rysujRaz(lerp(3, 1, E.inExpo(e)), clamp(e * 2.5)); bezCienia(ctx);
    } });
  dodaj({ id: "slowo-po-slowie", nazwa: "Słowo po słowie (rolki)", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Jedno słowo na *raz* robi robotę", wielkie: true },
    rysuj(s) {
      const ctx = s.ctx, sl = slowaZ(tekstP(s, s.p.tekst)); if (!sl.length) return;
      const dl = Math.max(0.2, (s.T - s.p.wyjscie) / sl.length), i = Math.min(sl.length - 1, Math.floor(s.t / dl)), w = sl[i];
      const e = okno(s.t - i * dl, 0, 0.16), px = dopasuj(s, w.t, 150 * s.u * s.p.rozmiar, s.W * 0.86, 900);
      ctx.font = font(s, px, 900); const sz = ctx.measureText(w.t).width;
      const x = s.poz.align === "left" ? s.poz.x : s.poz.align === "right" ? s.poz.x - sz : s.poz.x - sz / 2;
      ctx.save(); ctx.translate(x + sz / 2, s.poz.y); const sc = lerp(0.6, 1, E.outBackMocno(e)); ctx.scale(sc, sc);
      cien(s); ctx.fillStyle = w.wyr ? s.k.a : s.k.t; ctx.fillText(w.t, -sz / 2, 0); ctx.restore();
    } });
  dodaj({ id: "slowa-w-ramkach", nazwa: "Słowa kluczowe w ramkach", kat: "tekst", czas: 3.5, pola: ["tekst"], przyklad: { tekst: "Zarabiaj *więcej* pracując *mniej*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 92 * s.u * s.p.rozmiar, { lh: 1.3 }), ctx = s.ctx; ctx.font = ul.font;
      ul.slowa.forEach((w) => {
        const e = okno(s.t, w.i * 0.13 / s.p.tempo, 0.4 / s.p.tempo); if (e <= 0) return;
        ctx.save(); ctx.globalAlpha *= clamp(e * 2);
        if (w.wyr) {
          const sc = E.outBackMocno(e), pad = 14 * s.u;
          ctx.translate(w.x + w.w / 2, w.y); ctx.rotate((1 - sc) * 0.2 - 0.03); ctx.scale(sc, sc);
          ctx.fillStyle = s.k.a; zaokr(ctx, -w.w / 2 - pad, -ul.px * 0.55, w.w + pad * 2, ul.px * 1.1, 12 * s.u); ctx.fill();
          ctx.fillStyle = kontrast(s.k.a); ctx.fillText(w.t, -w.w / 2, 0);
        } else { cien(s); ctx.fillStyle = s.k.t; ctx.fillText(w.t, w.x, w.y + (1 - E.outCubic(e)) * 30 * s.u); }
        ctx.restore();
      });
    } });
  dodaj({ id: "obrot-liter", nazwa: "Litery obracają się", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Zobacz *nowość*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul); ctx.font = ul.font; cien(s);
      z.forEach((c) => {
        const e = okno(s.t, c.i * 0.035 / s.p.tempo, 0.55 / s.p.tempo); if (e <= 0) return;
        ctx.save(); ctx.translate(c.x + c.w / 2, c.y); ctx.scale(1, Math.max(0.001, E.outBack(e))); ctx.globalAlpha *= clamp(e * 2);
        ctx.fillStyle = c.slowo.wyr ? s.k.a : s.k.t; ctx.fillText(c.c, -c.w / 2, 0); ctx.restore();
      });
    } });
  dodaj({ id: "rozciecie", nazwa: "Rozcięcie", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Nowa *era*", wielkie: true },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 120 * s.u * s.p.rozmiar), ctx = s.ctx;
      const c = warstwa(s, "rozciecie", (x) => { x.font = ul.font; x.textBaseline = "middle"; ul.slowa.forEach((w) => piszSlowo(s, w, null, x)); });
      const e = E.outQuint(okno(s.t, 0, 0.8 / s.p.tempo)), sr = ul.y + ul.h / 2, d = (1 - e) * s.W * 0.6;
      ctx.drawImage(c, 0, 0, s.W, sr, -d, 0, s.W, sr);
      ctx.drawImage(c, 0, sr, s.W, s.H - sr, d, sr, s.W, s.H - sr);
      const l = okno(s.t, 0, 0.5 / s.p.tempo) * (1 - okno(s.t, 0.6 / s.p.tempo, 0.4));
      if (l > 0) { ctx.fillStyle = s.k.a; ctx.fillRect(ul.x - 30 * s.u, sr - 2 * s.u, (ul.w + 60 * s.u) * l, 4 * s.u); }
    } });
  dodaj({ id: "losowe-litery", nazwa: "Litery w losowej kolejności", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Coś się *szykuje*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul); ctx.font = ul.font; cien(s);
      z.forEach((c) => {
        const e = okno(s.t, los(c.i + 1) * 0.7 / s.p.tempo, 0.25); if (e <= 0) return;
        ctx.globalAlpha = s.alfa * e; ctx.fillStyle = c.slowo.wyr ? s.k.a : s.k.t; ctx.fillText(c.c, c.x, c.y);
      });
      ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "dekoder", nazwa: "Dekoder (losowe znaki)", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "DOSTĘP *PRZYZNANY*", wielkie: true, font: "Space Mono" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 88 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul); ctx.font = ul.font; cien(s);
      const ZN = "ABCDEFGHIJKLMNOPRSTUWXYZ0123456789#%&@$";
      z.forEach((c) => {
        const gotowe = 0.15 + c.i * 0.045 / s.p.tempo; if (s.t < c.i * 0.015) return;
        const zn = s.t >= gotowe || c.c === " " ? c.c : ZN[Math.floor(los(c.i * 13 + Math.floor(s.t * 25)) * ZN.length)];
        ctx.fillStyle = s.t >= gotowe ? (c.slowo.wyr ? s.k.a : s.k.t) : rgba(s.k.a, 0.8); ctx.fillText(zn, c.x, c.y);
      });
    } });
  dodaj({ id: "dlugi-cien", nazwa: "Długi cień", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "RETRO", wielkie: true },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 130 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      const e = E.outBack(okno(s.t, 0, 0.5 / s.p.tempo)), cien2 = E.outCubic(okno(s.t, 0.2 / s.p.tempo, 0.6 / s.p.tempo));
      const cx = ul.x + ul.w / 2, cy = ul.y + ul.h / 2; ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); ctx.translate(-cx, -cy);
      const n = Math.round(22 * cien2);
      for (let i = n; i >= 1; i--) { ctx.fillStyle = ciemniej(s.k.g, 0.15 + i / 60); ul.slowa.forEach((w) => ctx.fillText(w.t, w.x + i * 1.6 * s.u, w.y + i * 1.6 * s.u)); }
      ul.slowa.forEach((w) => piszSlowo(s, w)); ctx.restore();
    } });
  dodaj({ id: "kontur-wypelnienie", nazwa: "Kontur i wypełnienie", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "OUTLINE *FILL*", wielkie: true, waga: 900 },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 120 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      const a = okno(s.t, 0, 0.4 / s.p.tempo), b = E.inOutCubic(okno(s.t, 0.4 / s.p.tempo, 0.7 / s.p.tempo));
      ctx.globalAlpha = s.alfa * a; ctx.lineWidth = 3 * s.u; ctx.lineJoin = "round";
      ul.slowa.forEach((w) => { ctx.strokeStyle = w.wyr ? s.k.a : s.k.t; ctx.strokeText(w.t, w.x, w.y); });
      ctx.globalAlpha = s.alfa;
      ctx.save(); ctx.beginPath(); ctx.rect(ul.x - 10, 0, (ul.w + 20) * b, s.H); ctx.clip(); ul.slowa.forEach((w) => piszSlowo(s, w)); ctx.restore();
    } });
  dodaj({ id: "tytul-kinowy", nazwa: "Tytuł kinowy", kat: "tekst", czas: 4, pola: ["tekst", "tekst2"], przyklad: { tekst: "WARSZAWA", tekst2: "21.10.2026", wielkie: true, waga: 300 },
    rysuj(s) {
      const ctx = s.ctx, px = 110 * s.u * s.p.rozmiar, e = E.outQuint(okno(s.t, 0, 1.6 / s.p.tempo));
      const t = tekstP(s, s.p.tekst), od = lerp(0.6, 0.18, e) * px;
      ctx.font = font(s, px, s.p.waga);
      const zn = Array.from(t), szer = zn.reduce((a, c) => a + ctx.measureText(c).width, 0) + od * (zn.length - 1);
      let x = s.poz.x - (s.poz.align === "left" ? 0 : s.poz.align === "right" ? szer : szer / 2);
      ctx.globalAlpha = s.alfa * clamp(e * 1.4); cien(s); ctx.fillStyle = s.k.t;
      zn.forEach((c) => { ctx.fillText(c, x, s.poz.y); x += ctx.measureText(c).width + od; }); bezCienia(ctx);
      const l = E.inOutCubic(okno(s.t, 0.3 / s.p.tempo, 1 / s.p.tempo)), lw = szer * 0.7 * l, sx = s.poz.x - (s.poz.align === "left" ? -szer * 0.15 : s.poz.align === "right" ? szer * 0.85 : 0);
      ctx.globalAlpha = s.alfa; ctx.fillStyle = s.k.a;
      ctx.fillRect(sx - lw / 2, s.poz.y - px * 0.85, lw, 2.5 * s.u); ctx.fillRect(sx - lw / 2, s.poz.y + px * 0.8, lw, 2.5 * s.u);
      if (s.p.tekst2) {
        const e2 = okno(s.t, 0.9 / s.p.tempo, 0.6); ctx.globalAlpha = s.alfa * e2; ctx.font = font(s, px * 0.3, 500); const w2 = ctx.measureText(s.p.tekst2).width;
        ctx.fillStyle = s.k.t; ctx.fillText(s.p.tekst2, sx - w2 / 2, s.poz.y + px * 1.15 + (1 - e2) * 10 * s.u); ctx.globalAlpha = s.alfa;
      }
    } });
  dodaj({ id: "tytul-z-podtytulem", nazwa: "Tytuł z podtytułem", kat: "tekst", czas: 3.5, pola: ["tekst", "tekst2"], przyklad: { tekst: "Jak zacząć *inwestować*", tekst2: "Poradnik w 3 krokach" },
    rysuj(s) {
      const ctx = s.ctx, ul = uloz(s, s.p.tekst, 92 * s.u * s.p.rozmiar, { y: s.poz.y - 30 * s.u * s.p.rozmiar }); ctx.font = ul.font;
      const l = E.outCubic(okno(s.t, 0, 0.4 / s.p.tempo));
      const bx = (s.poz.align === "left" ? ul.x - 26 * s.u : ul.x - 26 * s.u);
      ctx.fillStyle = s.k.a; ctx.fillRect(bx, ul.y, 9 * s.u, (ul.h + 60 * s.u * s.p.rozmiar) * l);
      ul.linie.forEach((li, i) => {
        const e = E.outQuint(okno(s.t, 0.15 / s.p.tempo + i * 0.1, 0.6 / s.p.tempo));
        ctx.save(); ctx.beginPath(); ctx.rect(0, li.y - ul.lh * 0.6, s.W, ul.lh * 1.2); ctx.clip(); cien(s);
        li.slowa.forEach((w) => piszSlowo(s, w, null, ctx, 0, (1 - e) * ul.lh)); ctx.restore();
      });
      if (s.p.tekst2) {
        const e = E.outCubic(okno(s.t, 0.6 / s.p.tempo, 0.5)); ctx.globalAlpha = s.alfa * e;
        const u2 = uloz(s, s.p.tekst2, 44 * s.u * s.p.rozmiar, { y: ul.y + ul.h + 34 * s.u * s.p.rozmiar, waga: 500 });
        ctx.font = u2.font; u2.slowa.forEach((w) => { ctx.fillStyle = rgba(s.k.t, 0.85); ctx.fillText(w.t, w.x + (1 - e) * -20 * s.u, w.y); });
        ctx.globalAlpha = s.alfa;
      }
    } });
  dodaj({ id: "napis-na-plakietce", nazwa: "Napis na plakietce", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Czy wiesz, że *80%* ludzi…" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 72 * s.u * s.p.rozmiar, { maxW: s.W * 0.78, lh: 1.25 }), ctx = s.ctx; ctx.font = ul.font;
      ul.linie.forEach((l, i) => {
        const e = E.outBack(okno(s.t, i * 0.1 / s.p.tempo, 0.45 / s.p.tempo)); if (e <= 0) return;
        const pad = 22 * s.u, cx = l.x0 + l.w / 2;
        ctx.save(); ctx.translate(cx, l.y); ctx.scale(e, e); ctx.translate(-cx, -l.y);
        ctx.fillStyle = s.k.tl === "#141414" ? "#FFFFFF" : s.k.tl; zaokr(ctx, l.x0 - pad, l.y - ul.lh * 0.5, l.w + pad * 2, ul.lh, 14 * s.u); ctx.fill();
        const kt = kontrast(s.k.tl === "#141414" ? "#FFFFFF" : s.k.tl);
        l.slowa.forEach((w) => { ctx.fillStyle = w.wyr ? s.k.g : kt; ctx.fillText(w.t, w.x, w.y); }); ctx.restore();
      });
    } });

  // Belki z nazwiskiem
  function belkaTeksty(s, x, y, px) {
    const ctx = s.ctx;
    ctx.font = font(s, px, s.p.waga); const w1 = ctx.measureText(tekstP(s, s.p.tekst)).width;
    ctx.font = font(s, px * 0.52, 500); const w2 = s.p.tekst2 ? ctx.measureText(s.p.tekst2).width : 0;
    return { w1, w2, w: Math.max(w1, w2) };
  }
  const prawa = (s) => s.poz.align === "right";
  dodaj({ id: "belka-prosta", nazwa: "Belka prosta", kat: "belki", czas: 4, pola: ["tekst", "tekst2"], dom: { pozycja: "lewy-dol" }, przyklad: { tekst: "Anna Kowalska", tekst2: "Prezes, Emerald Media" },
    rysuj(s) {
      const ctx = s.ctx, px = 58 * s.u * s.p.rozmiar, m = belkaTeksty(s, 0, 0, px), pad = 28 * s.u, h = px * (s.p.tekst2 ? 2.1 : 1.5);
      const W = m.w + pad * 2, x0 = prawa(s) ? s.poz.x - W : s.poz.x, y0 = s.poz.y - h / 2;
      const a = E.outQuint(okno(s.t, 0, 0.6 / s.p.tempo));
      ctx.fillStyle = rgba(s.k.tl, 0.92); ctx.fillRect(prawa(s) ? x0 + W * (1 - a) : x0, y0, W * a, h);
      ctx.fillStyle = s.k.g; ctx.fillRect(prawa(s) ? x0 + W - 8 * s.u : x0, y0, 8 * s.u, h * a);
      ctx.save(); ctx.beginPath(); ctx.rect(x0, y0, W, h); ctx.clip();
      const e1 = E.outCubic(okno(s.t, 0.25 / s.p.tempo, 0.5)), e2 = E.outCubic(okno(s.t, 0.4 / s.p.tempo, 0.5));
      const ty = s.p.tekst2 ? y0 + h * 0.36 : y0 + h / 2;
      ctx.font = font(s, px, s.p.waga); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), prawa(s) ? x0 + W - pad - m.w1 : x0 + pad, ty + (1 - e1) * h);
      if (s.p.tekst2) { ctx.font = font(s, px * 0.52, 500); ctx.fillStyle = rgba(s.k.t, 0.8); ctx.fillText(s.p.tekst2, prawa(s) ? x0 + W - pad - m.w2 : x0 + pad, y0 + h * 0.72 + (1 - e2) * h); }
      ctx.restore();
    } });
  dodaj({ id: "belka-akcent", nazwa: "Belka z akcentem", kat: "belki", czas: 4, pola: ["tekst", "tekst2"], dom: { pozycja: "lewy-dol" }, przyklad: { tekst: "Marek Nowak", tekst2: "Head of Marketing" },
    rysuj(s) {
      const ctx = s.ctx, px = 56 * s.u * s.p.rozmiar, m = belkaTeksty(s, 0, 0, px), pad = 26 * s.u, h1 = px * 1.5, h2 = px * 0.95;
      const x0 = prawa(s) ? s.poz.x - m.w - pad * 2 : s.poz.x, y0 = s.poz.y - (h1 + h2) / 2;
      const a = E.outBackMocno(okno(s.t, 0, 0.35 / s.p.tempo)), b = E.outQuint(okno(s.t, 0.2 / s.p.tempo, 0.6 / s.p.tempo)), c = E.outQuint(okno(s.t, 0.35 / s.p.tempo, 0.6 / s.p.tempo));
      ctx.save(); ctx.translate(x0, y0); ctx.scale(a, a); ctx.fillStyle = s.k.a; ctx.fillRect(-h1 * 0.25, -h1 * 0.18, h1 * 0.5, h1 * 0.5); ctx.restore();
      const W1 = (m.w1 + pad * 2) * b; ctx.fillStyle = s.k.g; ctx.fillRect(x0, y0, W1, h1);
      ctx.save(); ctx.beginPath(); ctx.rect(x0, y0, W1, h1); ctx.clip(); ctx.font = font(s, px, s.p.waga); ctx.fillStyle = kontrast(s.k.g);
      ctx.fillText(tekstP(s, s.p.tekst), x0 + pad, y0 + h1 / 2); ctx.restore();
      if (s.p.tekst2) {
        const W2 = (m.w2 + pad * 2) * c; ctx.fillStyle = "#FFFFFF"; ctx.fillRect(x0, y0 + h1, W2, h2);
        ctx.save(); ctx.beginPath(); ctx.rect(x0, y0 + h1, W2, h2); ctx.clip(); ctx.font = font(s, px * 0.52, 600); ctx.fillStyle = "#111";
        ctx.fillText(s.p.tekst2, x0 + pad, y0 + h1 + h2 / 2); ctx.restore();
      }
    } });
  dodaj({ id: "belka-linia", nazwa: "Belka z linią", kat: "belki", czas: 4, pola: ["tekst", "tekst2"], dom: { pozycja: "lewy-dol" }, przyklad: { tekst: "Kasia Wiśniewska", tekst2: "fotografka" },
    rysuj(s) {
      const ctx = s.ctx, px = 60 * s.u * s.p.rozmiar, m = belkaTeksty(s, 0, 0, px), x0 = prawa(s) ? s.poz.x - m.w : s.poz.x, y = s.poz.y;
      const l = E.inOutCubic(okno(s.t, 0, 0.5 / s.p.tempo)), e1 = E.outQuint(okno(s.t, 0.3 / s.p.tempo, 0.6)), e2 = E.outQuint(okno(s.t, 0.4 / s.p.tempo, 0.6));
      ctx.fillStyle = s.k.a; ctx.fillRect(prawa(s) ? x0 + m.w * (1 - l) : x0, y - 2.5 * s.u, m.w * l, 5 * s.u);
      ctx.save(); ctx.beginPath(); ctx.rect(x0 - 20, y - px * 1.4, m.w + 40, px * 1.37); ctx.clip(); cien(s);
      ctx.font = font(s, px, s.p.waga); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), prawa(s) ? x0 + m.w - m.w1 : x0, y - px * 0.62 + (1 - e1) * px * 1.3); ctx.restore();
      if (s.p.tekst2) {
        ctx.save(); ctx.beginPath(); ctx.rect(x0 - 20, y + 3 * s.u, m.w + 40, px); ctx.clip(); cien(s);
        ctx.font = font(s, px * 0.52, 500); ctx.fillStyle = rgba(s.k.t, 0.9); ctx.fillText(s.p.tekst2, prawa(s) ? x0 + m.w - m.w2 : x0, y + px * 0.48 - (1 - e2) * px); ctx.restore();
      }
    } });
  dodaj({ id: "belka-pigulka", nazwa: "Belka pigułka z inicjałami", kat: "belki", czas: 4, pola: ["tekst", "tekst2"], dom: { pozycja: "lewy-dol" }, przyklad: { tekst: "Jan Zieliński", tekst2: "@janzielinski" },
    rysuj(s) {
      const ctx = s.ctx, px = 48 * s.u * s.p.rozmiar, m = belkaTeksty(s, 0, 0, px), h = px * 2.3, r = h / 2;
      const W = h + m.w + 40 * s.u, x0 = prawa(s) ? s.poz.x - W : s.poz.x, y0 = s.poz.y - r;
      const a = E.outBackMocno(okno(s.t, 0, 0.4 / s.p.tempo)), b = E.outQuint(okno(s.t, 0.25 / s.p.tempo, 0.6 / s.p.tempo));
      ctx.save(); cien(s); ctx.fillStyle = "#FFFFFF"; zaokr(ctx, x0, y0, h + (W - h) * b, h, r); ctx.fill(); ctx.restore();
      ctx.save(); ctx.translate(x0 + r, y0 + r); ctx.scale(a, a); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, r * 0.82, 0, Math.PI * 2); ctx.fill();
      const ini = String(s.p.tekst || "").split(/\s+/).map((x) => x[0] || "").join("").slice(0, 2).toUpperCase();
      ctx.font = font(s, r * 0.8, 800); const wi = ctx.measureText(ini).width; ctx.fillStyle = kontrast(s.k.g); ctx.fillText(ini, -wi / 2, 0); ctx.restore();
      ctx.save(); ctx.beginPath(); zaokr(ctx, x0, y0, h + (W - h) * b, h, r); ctx.clip();
      const tx = x0 + h + 8 * s.u, e = okno(s.t, 0.45 / s.p.tempo, 0.4); ctx.globalAlpha *= e;
      ctx.font = font(s, px, s.p.waga); ctx.fillStyle = "#111"; ctx.fillText(tekstP(s, s.p.tekst), tx, s.p.tekst2 ? y0 + h * 0.38 : y0 + r);
      if (s.p.tekst2) { ctx.font = font(s, px * 0.6, 500); ctx.fillStyle = s.k.g; ctx.fillText(s.p.tekst2, tx, y0 + h * 0.68); }
      ctx.restore();
    } });
  dodaj({ id: "belka-dwukolor", nazwa: "Belka dwukolorowa", kat: "belki", czas: 4, pola: ["tekst", "tekst2"], dom: { pozycja: "lewy-dol", wielkie: true }, przyklad: { tekst: "Tomasz Lis", tekst2: "Ekspert ds. finansów" },
    rysuj(s) {
      const ctx = s.ctx, px = 54 * s.u * s.p.rozmiar, m = belkaTeksty(s, 0, 0, px), pad = 22 * s.u, h1 = px * 1.45, h2 = px;
      [[s.p.tekst, s.k.g, px, s.p.waga, m.w1, 0, h1], [s.p.tekst2, s.k.a, px * 0.52, 700, m.w2, h1 + 6 * s.u, h2]].forEach(([t, kol, r, wg, w, dy, h], i) => {
        if (!t) return;
        const e = E.outQuint(okno(s.t, i * 0.15 / s.p.tempo, 0.6 / s.p.tempo)), W = w + pad * 2;
        const x0 = (prawa(s) ? s.poz.x - W : s.poz.x) + (prawa(s) ? 1 : -1) * (1 - e) * (W + 60 * s.u) * 0, y0 = s.poz.y - (h1 + h2) / 2 + dy;
        ctx.save(); ctx.beginPath(); ctx.rect(x0, y0, W, h); ctx.clip();
        const dx = (1 - e) * -W * (prawa(s) ? -1 : 1);
        ctx.fillStyle = kol; ctx.fillRect(x0 + dx, y0, W, h);
        ctx.font = font(s, r, wg); ctx.fillStyle = kontrast(kol); ctx.fillText(i ? t : tekstP(s, t), x0 + pad + dx * 1.15, y0 + h / 2); ctx.restore();
      });
    } });
  dodaj({ id: "belka-minimal", nazwa: "Belka minimalistyczna", kat: "belki", czas: 4, pola: ["tekst", "tekst2"], dom: { pozycja: "lewy-dol" }, przyklad: { tekst: "Ola Mazur", tekst2: "architektka wnętrz" },
    rysuj(s) {
      const ctx = s.ctx, px = 58 * s.u * s.p.rozmiar, m = belkaTeksty(s, 0, 0, px), h = px * (s.p.tekst2 ? 1.9 : 1.2);
      const xl = prawa(s) ? s.poz.x : s.poz.x, y0 = s.poz.y - h / 2, l = E.outQuint(okno(s.t, 0, 0.45 / s.p.tempo));
      ctx.fillStyle = s.k.a; ctx.fillRect(xl - 3 * s.u, y0 + h * (1 - l) / 2, 6 * s.u, h * l);
      const odst = 24 * s.u, kier = prawa(s) ? -1 : 1;
      ctx.save(); ctx.beginPath(); prawa(s) ? ctx.rect(0, y0 - 10, xl - odst / 2, h + 20) : ctx.rect(xl + odst / 2, y0 - 10, s.W, h + 20); ctx.clip(); cien(s);
      const e1 = E.outQuint(okno(s.t, 0.2 / s.p.tempo, 0.6)), e2 = E.outQuint(okno(s.t, 0.32 / s.p.tempo, 0.6));
      ctx.font = font(s, px, s.p.waga); ctx.fillStyle = s.k.t;
      ctx.fillText(tekstP(s, s.p.tekst), prawa(s) ? xl - odst - m.w1 + (1 - e1) * m.w1 : xl + odst - (1 - e1) * (m.w1 + odst), s.p.tekst2 ? y0 + px * 0.55 : y0 + h / 2);
      if (s.p.tekst2) { ctx.font = font(s, px * 0.5, 400); ctx.fillStyle = rgba(s.k.t, 0.85); ctx.fillText(s.p.tekst2, prawa(s) ? xl - odst - m.w2 + (1 - e2) * m.w2 : xl + odst - (1 - e2) * (m.w2 + odst), y0 + px * 1.42); }
      ctx.restore(); void kier;
    } });
  dodaj({ id: "belka-social", nazwa: "Nick w social mediach", kat: "belki", czas: 3.5, pola: ["tekst"], dom: { pozycja: "dol" }, przyklad: { tekst: "@nadamedia" },
    rysuj(s) {
      const ctx = s.ctx, px = 56 * s.u * s.p.rozmiar; ctx.font = font(s, px, s.p.waga);
      const w = ctx.measureText(s.p.tekst).width, h = px * 1.8, W = w + h + 40 * s.u;
      const x0 = s.poz.align === "left" ? s.poz.x : s.poz.align === "right" ? s.poz.x - W : s.poz.x - W / 2, y0 = s.poz.y - h / 2;
      const e = E.outBackMocno(okno(s.t, 0, 0.45 / s.p.tempo)); ctx.save(); ctx.translate(x0 + W / 2, y0 + h / 2); ctx.scale(e, e); ctx.translate(-x0 - W / 2, -y0 - h / 2);
      cien(s); ctx.fillStyle = "#FFFFFF"; zaokr(ctx, x0, y0, W, h, h / 2); ctx.fill(); bezCienia(ctx);
      const g = ctx.createLinearGradient(x0, y0, x0 + h, y0 + h); g.addColorStop(0, s.k.g); g.addColorStop(1, s.k.a);
      ctx.fillStyle = g; zaokr(ctx, x0 + h * 0.14, y0 + h * 0.14, h * 0.72, h * 0.72, h * 0.22); ctx.fill();
      ctx.strokeStyle = "#FFF"; ctx.lineWidth = h * 0.06; ctx.beginPath(); ctx.arc(x0 + h / 2, y0 + h / 2, h * 0.16, 0, Math.PI * 2); ctx.stroke();
      zaokr(ctx, x0 + h * 0.27, y0 + h * 0.27, h * 0.46, h * 0.46, h * 0.13); ctx.stroke();
      ctx.font = font(s, px, s.p.waga); ctx.fillStyle = "#111"; ctx.fillText(s.p.tekst, x0 + h + 10 * s.u, y0 + h / 2); ctx.restore();
    } });

  // Grafiki do rolek
  const punkt = (s, a = "x", b = "y") => [clamp(+s.p[a]) * s.W, clamp(+s.p[b]) * s.H];
  dodaj({ id: "strzalka", nazwa: "Strzałka rysowana ręcznie", kat: "rolki", czas: 3, pola: ["tekst", "xy"], przyklad: { tekst: "Patrz tutaj!", x: 0.6, y: 0.55 },
    rysuj(s) {
      const ctx = s.ctx, [tx, ty] = punkt(s), u = s.u * s.p.rozmiar;
      const sx = tx + (tx > s.W / 2 ? -1 : 1) * 300 * u, sy = ty + (ty > s.H * 0.4 ? -1 : 1) * 260 * u;
      const e = E.inOutCubic(okno(s.t, 0.15 / s.p.tempo, 0.6 / s.p.tempo)), et = E.outBack(okno(s.t, 0, 0.35 / s.p.tempo));
      const pkt = krzywa([sx, sy + (ty > sy ? 40 : -40) * u], [sx + (tx - sx) * 0.1, ty + (sy - ty) * 0.15], [tx - (tx - sx) * 0.08, ty - (ty - sy) * 0.08]);
      ctx.strokeStyle = s.k.a; ctx.lineWidth = 11 * u; ctx.lineCap = "round"; ctx.lineJoin = "round"; cien(s);
      const { koniec, kier } = sciezkaCzesc(ctx, pkt, e); ctx.stroke();
      if (e > 0.85) {
        const g = E.outBack(okno(e, 0.85, 0.15)) * 40 * u;
        ctx.beginPath(); ctx.moveTo(koniec[0] - Math.cos(kier - 0.5) * g, koniec[1] - Math.sin(kier - 0.5) * g); ctx.lineTo(...koniec);
        ctx.lineTo(koniec[0] - Math.cos(kier + 0.5) * g, koniec[1] - Math.sin(kier + 0.5) * g); ctx.stroke();
      }
      if (s.p.tekst) {
        ctx.font = font(s, 58 * u, s.p.waga); const w = ctx.measureText(tekstP(s, s.p.tekst)).width;
        const lx = clamp(sx - w / 2, 30 * s.u, s.W - w - 30 * s.u), ly = sy + (ty > sy ? -30 : 50) * u;
        ctx.save(); ctx.translate(lx + w / 2, ly); ctx.rotate(-0.04); ctx.scale(et, et); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), -w / 2, 0); ctx.restore();
      }
    } });
  dodaj({ id: "kolko", nazwa: "Zakreślone kółko", kat: "rolki", czas: 3, pola: ["xy"], przyklad: { x: 0.5, y: 0.5 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), r = 170 * s.u * s.p.rozmiar, e = E.inOutCubic(okno(s.t, 0, 0.7 / s.p.tempo));
      const pkt = []; for (let i = 0; i <= 80; i++) { const a = -2.2 + (i / 80) * Math.PI * 2.15, rr = r * (1 + 0.06 * Math.sin(i * 0.21)); pkt.push([cx + Math.cos(a) * rr * 1.25, cy + Math.sin(a) * rr * 0.85]); }
      ctx.strokeStyle = s.k.a; ctx.lineWidth = 10 * s.u * s.p.rozmiar; ctx.lineCap = "round"; cien(s); sciezkaCzesc(ctx, pkt, e); ctx.stroke();
    } });
  dodaj({ id: "emoji", nazwa: "Emoji wyskakuje", kat: "rolki", czas: 2.5, pola: ["emoji", "xy"], przyklad: { emoji: "🔥", x: 0.75, y: 0.3 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), px = 170 * s.u * s.p.rozmiar, e = E.outElastic(okno(s.t, 0, 0.8 / s.p.tempo));
      ctx.save(); ctx.translate(cx, cy + Math.sin(s.t * 3) * 8 * s.u); ctx.rotate(Math.sin(s.t * 4) * 0.12 * (1 - okno(s.t, 1, 2) * 0.5)); ctx.scale(e, e);
      ctx.font = `${Math.round(px)}px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif`; const w = ctx.measureText(s.p.emoji).width;
      ctx.fillText(s.p.emoji, -w / 2, 0); ctx.restore();
    } });
  dodaj({ id: "obserwuj", nazwa: "Przycisk Obserwuj z kliknięciem", kat: "cta", czas: 3, pola: ["tekst", "tekst2"], dom: { pozycja: "dol" }, przyklad: { tekst: "Obserwuj", tekst2: "Obserwujesz ✓" },
    rysuj(s) {
      const ctx = s.ctx, px = 60 * s.u * s.p.rozmiar, klik = 1.3 / s.p.tempo, po = s.t > klik;
      ctx.font = font(s, px, 800); const t = po && s.p.tekst2 ? s.p.tekst2 : s.p.tekst, w = ctx.measureText(t).width;
      const W = Math.max(w, ctx.measureText(s.p.tekst).width) + 90 * s.u, h = px * 1.9, cx = s.poz.x, cy = s.poz.y;
      const e = E.outBackMocno(okno(s.t, 0, 0.4 / s.p.tempo)), nac = s.t > klik - 0.08 && s.t < klik + 0.12 ? 0.92 : 1;
      ctx.save(); ctx.translate(cx, cy); ctx.scale(e * nac, e * nac); cien(s);
      ctx.fillStyle = po ? "#3A3A3A" : s.k.g; zaokr(ctx, -W / 2, -h / 2, W, h, h * 0.3); ctx.fill(); bezCienia(ctx);
      ctx.fillStyle = po ? "#FFFFFF" : kontrast(s.k.g); ctx.fillText(t, -w / 2, 0); ctx.restore();
      if (s.t > klik) { const r = okno(s.t, klik, 0.5); ctx.strokeStyle = rgba("#FFFFFF", 1 - r); ctx.lineWidth = 4 * s.u; ctx.beginPath(); ctx.arc(cx + W * 0.25, cy + h * 0.2, 20 * s.u + r * 60 * s.u, 0, Math.PI * 2); ctx.stroke(); }
      const m = E.inOutCubic(okno(s.t, 0.4 / s.p.tempo, klik - 0.45 / s.p.tempo));
      kursor(ctx, lerp(cx + W, cx + W * 0.25, m), lerp(cy + h * 2.2, cy + h * 0.2, m), 1.6 * s.u * s.p.rozmiar * (s.t > klik - 0.08 && s.t < klik + 0.12 ? 0.85 : 1));
    } });
  dodaj({ id: "pasek-postepu", nazwa: "Pasek postępu filmu", kat: "rolki", czas: 15, pola: [], dom: { wyjscie: 0.01, wyjscie_styl: "brak" }, przyklad: { czas: 6 },
    rysuj(s) {
      const ctx = s.ctx, m = 30 * s.u, h = 12 * s.u * s.p.rozmiar, y = 40 * s.u, e = okno(s.t, 0, 0.3);
      ctx.globalAlpha = s.alfa * e; ctx.fillStyle = rgba("#FFFFFF", 0.3); zaokr(ctx, m, y, s.W - m * 2, h, h / 2); ctx.fill();
      ctx.fillStyle = s.k.g; zaokr(ctx, m, y, Math.max(h, (s.W - m * 2) * clamp(s.t / s.T)), h, h / 2); ctx.fill(); ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "lista-check", nazwa: "Lista z odhaczaniem", kat: "rolki", czas: 5, pola: ["lista"], dom: { pozycja: "lewy-srodek" }, przyklad: { lista: "Plan treści\nNagranie\nMontaż\n*Publikacja*" },
    rysuj(s) {
      const ctx = s.ctx, el = lista(s.p.lista), px = 62 * s.u * s.p.rozmiar, lh = px * 1.7, x = s.poz.align === "center" ? s.W * 0.18 : s.poz.x;
      const y0 = s.poz.y - (el.length - 1) * lh / 2, krok = Math.max(0.35, Math.min(0.8, (s.T - s.p.wyjscie - 0.6) / Math.max(1, el.length))) / s.p.tempo;
      el.forEach((t, i) => {
        const y = y0 + i * lh, e = E.outBack(okno(s.t, i * krok, 0.35)), c = E.outCubic(okno(s.t, i * krok + 0.25, 0.35));
        if (e <= 0) return; const b = px * 1.05;
        ctx.save(); ctx.translate(x + b / 2, y); ctx.scale(e, e); cien(s);
        ctx.fillStyle = c > 0 ? s.k.g : "rgba(255,255,255,0.15)"; ctx.strokeStyle = s.k.t; ctx.lineWidth = 4 * s.u;
        zaokr(ctx, -b / 2, -b / 2, b, b, 12 * s.u); ctx.fill(); if (c <= 0) ctx.stroke(); bezCienia(ctx);
        if (c > 0) ptaszek(ctx, 0, 0, b * 0.42, c, kontrast(s.k.g), 7 * s.u); ctx.restore();
        const sl = slowaZ(tekstP(s, t)); ctx.save(); ctx.globalAlpha *= clamp(e); ctx.font = font(s, px, s.p.waga); cien(s);
        let xx = x + b + 26 * s.u + (1 - e) * 30 * s.u; sl.forEach((w) => { ctx.fillStyle = w.wyr ? s.k.a : s.k.t; ctx.fillText(w.t, xx, y); xx += ctx.measureText(w.t + " ").width; }); ctx.restore();
      });
    } });
  dodaj({ id: "cena", nazwa: "Cena na gwiazdce", kat: "cta", czas: 3, pola: ["tekst", "tekst2", "xy"], przyklad: { tekst: "99 zł", tekst2: "tylko dziś", x: 0.72, y: 0.3 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), r = 190 * s.u * s.p.rozmiar, e = E.outBackMocno(okno(s.t, 0, 0.5 / s.p.tempo));
      ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); ctx.rotate(-0.12 + Math.sin(s.t * 2) * 0.03); cien(s);
      gwiazda(ctx, 0, 0, 16, r, r * 0.86, s.t * 0.3); ctx.fillStyle = s.k.a; ctx.fill(); bezCienia(ctx);
      const kt = kontrast(s.k.a), px = dopasuj(s, s.p.tekst, r * 0.62, r * 1.45, 900);
      ctx.font = font(s, px, 900); let w = ctx.measureText(s.p.tekst).width; ctx.fillStyle = kt; ctx.fillText(s.p.tekst, -w / 2, s.p.tekst2 ? r * 0.12 : 0);
      if (s.p.tekst2) { ctx.font = font(s, r * 0.2, 700); w = ctx.measureText(s.p.tekst2).width; ctx.fillText(s.p.tekst2, -w / 2, -r * 0.42); }
      ctx.restore();
    } });
  dodaj({ id: "odliczanie", nazwa: "Odliczanie 3-2-1", kat: "liczby", czas: 3.2, pola: ["liczba"], dom: { wyjscie: 0.2 }, przyklad: { liczba: 3 },
    rysuj(s) {
      const ctx = s.ctx, n = Math.max(1, Math.min(10, Math.round(+s.p.liczba || 3))), dl = (s.T - s.p.wyjscie) / n;
      const i = Math.min(n - 1, Math.floor(s.t / dl)), lt = s.t - i * dl, e = E.outBackMocno(okno(lt, 0, 0.3)), r = 200 * s.u * s.p.rozmiar;
      const cx = s.poz.x, cy = s.poz.y;
      ctx.strokeStyle = rgba(s.k.t, 0.25); ctx.lineWidth = 14 * s.u; ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = s.k.a; ctx.lineCap = "round"; ctx.beginPath(); ctx.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (1 - clamp(lt / dl))); ctx.stroke();
      const t = String(n - i); ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); ctx.globalAlpha *= 1 - okno(lt, dl - 0.15, 0.15) * 0.6;
      ctx.font = font(s, r * 1.1, 900); const w = ctx.measureText(t).width; cien(s); ctx.fillStyle = s.k.t; ctx.fillText(t, -w / 2, r * 0.04); ctx.restore();
    } });
  dodaj({ id: "licznik", nazwa: "Licznik liczby", kat: "liczby", czas: 3, pola: ["liczba", "od", "przed", "po", "tekst2"], przyklad: { liczba: 250, przed: "+", po: "%", tekst2: "więcej zasięgów" },
    rysuj(s) {
      const ctx = s.ctx, e = E.outExpo(okno(s.t, 0.1, 1.6 / s.p.tempo)), v = lerp(+s.p.od || 0, +s.p.liczba || 0, e);
      const t = `${s.p.przed || ""}${liczbaTekst(v, miejscaPo(s.p.liczba))}${s.p.po || ""}`, px = dopasuj(s, t, 190 * s.u * s.p.rozmiar, s.W * 0.86, 900);
      const wej = E.outBack(okno(s.t, 0, 0.4)); ctx.font = font(s, px, 900); const w = ctx.measureText(t).width;
      const x = s.poz.align === "left" ? s.poz.x : s.poz.align === "right" ? s.poz.x - w : s.poz.x - w / 2;
      ctx.save(); ctx.translate(x + w / 2, s.poz.y); ctx.scale(wej, wej); cien(s); ctx.fillStyle = s.k.a; ctx.fillText(t, -w / 2, 0); ctx.restore();
      if (s.p.tekst2) {
        const e2 = E.outCubic(okno(s.t, 0.5 / s.p.tempo, 0.5)); ctx.globalAlpha = s.alfa * e2;
        const u2 = uloz(s, s.p.tekst2, 52 * s.u * s.p.rozmiar, { y: s.poz.y + px * 0.75, gora: true, waga: 600 }); ctx.font = u2.font; cien(s);
        u2.slowa.forEach((w2) => piszSlowo(s, w2, null, ctx, 0, (1 - e2) * 20 * s.u)); ctx.globalAlpha = s.alfa;
      }
    } });
  dodaj({ id: "wykres-slupki", nazwa: "Wykres słupkowy", kat: "liczby", czas: 4, pola: ["lista", "po", "tekst"], przyklad: { lista: "2023: 40\n2024: 65\n*2025*: 120", po: " tys.", tekst: "Sprzedaż" },
    rysuj(s) {
      const ctx = s.ctx, d = pary(s.p.lista); if (!d.length) return;
      const W = s.W * 0.78 * s.p.rozmiar, H = s.H * (s.H > s.W ? 0.32 : 0.45) * s.p.rozmiar, x0 = s.poz.x - W / 2, y0 = s.poz.y + H / 2;
      const max = Math.max(...d.map((x) => x.v), 1), bw = W / d.length * 0.62, gap = W / d.length;
      const os = E.outCubic(okno(s.t, 0, 0.4)); ctx.fillStyle = rgba(s.k.t, 0.6); ctx.fillRect(x0, y0, W * os, 3 * s.u);
      if (s.p.tekst) { ctx.font = font(s, 50 * s.u * s.p.rozmiar, s.p.waga); ctx.fillStyle = s.k.t; ctx.globalAlpha = s.alfa * os; ctx.fillText(tekstP(s, s.p.tekst), x0, y0 - H - 60 * s.u); ctx.globalAlpha = s.alfa; }
      d.forEach((p, i) => {
        const e = E.outQuint(okno(s.t, 0.25 + i * 0.15 / s.p.tempo, 0.9 / s.p.tempo)), h = (p.v / max) * H * e, x = x0 + gap * i + (gap - bw) / 2;
        const wyr = /^\*.*\*$/.test(p.e), et = p.e.replace(/\*/g, "");
        cien(s, ctx, 0.6); ctx.fillStyle = wyr ? s.k.a : s.k.g; zaokr(ctx, x, y0 - h, bw, h, Math.min(14 * s.u, h / 2)); ctx.fill(); bezCienia(ctx);
        ctx.font = font(s, 36 * s.u * s.p.rozmiar, 600); ctx.fillStyle = s.k.t; let w = ctx.measureText(et).width; ctx.fillText(et, x + bw / 2 - w / 2, y0 + 36 * s.u);
        if (e > 0.05) { const vt = liczbaTekst(p.v * e, miejscaPo(p.v)) + (s.p.po || ""); ctx.font = font(s, 40 * s.u * s.p.rozmiar, 800); w = ctx.measureText(vt).width; ctx.fillText(vt, x + bw / 2 - w / 2, y0 - h - 30 * s.u); }
      });
    } });
  dodaj({ id: "wykres-kolo", nazwa: "Wykres kołowy (procent)", kat: "liczby", czas: 3.5, pola: ["liczba", "tekst2"], przyklad: { liczba: 73, tekst2: "klientów wraca" },
    rysuj(s) {
      const ctx = s.ctx, r = 190 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y, wej = E.outBack(okno(s.t, 0, 0.45)), e = E.outCubic(okno(s.t, 0.2, 1.4 / s.p.tempo));
      const v = clamp((+s.p.liczba || 0) / 100);
      ctx.save(); ctx.translate(cx, cy); ctx.scale(wej, wej);
      ctx.lineWidth = 42 * s.u * s.p.rozmiar; ctx.strokeStyle = rgba(s.k.t, 0.18); ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = s.k.g; ctx.lineCap = "round"; ctx.beginPath(); ctx.arc(0, 0, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * v * e + 0.0001); ctx.stroke();
      const t = Math.round(v * 100 * e) + "%"; ctx.font = font(s, r * 0.62, 900); const w = ctx.measureText(t).width; cien(s); ctx.fillStyle = s.k.t; ctx.fillText(t, -w / 2, 0); ctx.restore();
      if (s.p.tekst2) { const e2 = okno(s.t, 0.6, 0.5); ctx.globalAlpha = s.alfa * e2; const u2 = uloz(s, s.p.tekst2, 50 * s.u * s.p.rozmiar, { y: cy + r + 60 * s.u, gora: true, align: "center", x: cx, waga: 600 }); ctx.font = u2.font; cien(s); u2.slowa.forEach((w2) => piszSlowo(s, w2)); ctx.globalAlpha = s.alfa; }
    } });
  dodaj({ id: "vs", nazwa: "Porównanie VS", kat: "rolki", czas: 3.5, pola: ["tekst", "tekst2"], przyklad: { tekst: "iPhone", tekst2: "Android", wielkie: true },
    rysuj(s) {
      const ctx = s.ctx, px = 76 * s.u * s.p.rozmiar, cy = s.poz.y, e1 = E.outQuint(okno(s.t, 0, 0.6 / s.p.tempo)), e2 = E.outBackMocno(okno(s.t, 0.35 / s.p.tempo, 0.45));
      ctx.font = font(s, px, 900); cien(s);
      const a = tekstP(s, s.p.tekst), b = tekstP(s, s.p.tekst2), wa = ctx.measureText(a).width, wb = ctx.measureText(b).width;
      ctx.fillStyle = s.k.t; ctx.fillText(a, s.W * 0.27 - wa / 2 - (1 - e1) * s.W * 0.5, cy); ctx.fillText(b, s.W * 0.73 - wb / 2 + (1 - e1) * s.W * 0.5, cy); bezCienia(ctx);
      const l = E.inOutCubic(okno(s.t, 0.1, 0.6)); ctx.strokeStyle = rgba(s.k.t, 0.7); ctx.lineWidth = 4 * s.u;
      ctx.beginPath(); ctx.moveTo(s.W / 2 + 60 * s.u, cy - 300 * s.u * l); ctx.lineTo(s.W / 2 - 60 * s.u, cy + 300 * s.u * l); ctx.stroke();
      const r = 82 * s.u * s.p.rozmiar; ctx.save(); ctx.translate(s.W / 2, cy); ctx.scale(e2, e2); ctx.rotate((1 - e2) * 0.6);
      cien(s); ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill(); bezCienia(ctx);
      ctx.font = font(s, r * 0.85, 900); const w = ctx.measureText("VS").width; ctx.fillStyle = kontrast(s.k.a); ctx.fillText("VS", -w / 2, 0); ctx.restore();
    } });
  dodaj({ id: "cytat", nazwa: "Cytat", kat: "rolki", czas: 4.5, pola: ["tekst", "tekst2"], przyklad: { tekst: "Najlepszy czas na start był wczoraj. Drugi najlepszy jest *dziś*.", tekst2: "— przysłowie" },
    rysuj(s) {
      const ctx = s.ctx, ul = uloz(s, s.p.tekst, 66 * s.u * s.p.rozmiar, { maxW: s.W * 0.76, lh: 1.25, waga: 600 }); ctx.font = ul.font;
      const q = E.outBackMocno(okno(s.t, 0, 0.4)); ctx.save(); ctx.translate(ul.x + 30 * s.u, ul.y - 70 * s.u); ctx.scale(q, q);
      ctx.font = font(s, 240 * s.u * s.p.rozmiar, 900); ctx.fillStyle = s.k.a; ctx.fillText("“", -50 * s.u, 60 * s.u); ctx.restore();
      ctx.font = ul.font; cien(s);
      ul.slowa.forEach((w) => { const e = okno(s.t, 0.3 + w.i * 0.06 / s.p.tempo, 0.3); if (e <= 0) return; ctx.globalAlpha = s.alfa * e; piszSlowo(s, w, null, ctx, 0, (1 - e) * 14 * s.u); });
      ctx.globalAlpha = s.alfa;
      if (s.p.tekst2) { const e = E.outCubic(okno(s.t, 0.5 + ul.slowa.length * 0.06, 0.5)); ctx.globalAlpha = s.alfa * e; ctx.font = font(s, 42 * s.u * s.p.rozmiar, 500); ctx.fillStyle = rgba(s.k.t, 0.85); ctx.fillText(s.p.tekst2, ul.x + (1 - e) * 30 * s.u, ul.y + ul.h + 50 * s.u); ctx.globalAlpha = s.alfa; }
    } });
  dodaj({ id: "dymek", nazwa: "Dymek rozmowy", kat: "rolki", czas: 3.5, pola: ["tekst", "xy"], przyklad: { tekst: "Serio?! 😮", x: 0.55, y: 0.35 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), ul0 = uloz(s, s.p.tekst, 56 * s.u * s.p.rozmiar, { maxW: s.W * 0.6, x: cx, y: cy, align: "center", lh: 1.2 });
      const pad = 34 * s.u, W = ul0.w + pad * 2, H = ul0.h + pad * 1.4, x0 = cx - W / 2, y0 = cy - H / 2;
      const e = E.outBackMocno(okno(s.t, 0, 0.45 / s.p.tempo)), ox = x0 + W * 0.22, oy = y0 + H + 40 * s.u;
      ctx.save(); ctx.translate(ox, oy); ctx.scale(e, e); ctx.translate(-ox, -oy); cien(s);
      ctx.fillStyle = "#FFFFFF"; zaokr(ctx, x0, y0, W, H, 40 * s.u); ctx.fill();
      ctx.beginPath(); ctx.moveTo(x0 + W * 0.18, y0 + H - 2); ctx.lineTo(ox, oy); ctx.lineTo(x0 + W * 0.36, y0 + H - 2); ctx.closePath(); ctx.fill(); bezCienia(ctx);
      ctx.font = ul0.font; ul0.slowa.forEach((w) => { ctx.fillStyle = w.wyr ? s.k.g : "#111"; ctx.fillText(w.t, w.x, w.y); }); ctx.restore();
    } });
  dodaj({ id: "pinezka", nazwa: "Pinezka z miejscem", kat: "rolki", czas: 3.5, pola: ["tekst", "tekst2", "xy"], przyklad: { tekst: "Kraków", tekst2: "Rynek Główny", x: 0.4, y: 0.45 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), r = 46 * s.u * s.p.rozmiar, e = okno(s.t, 0, 0.7 / s.p.tempo), y = lerp(cy - s.H * 0.4, cy, E.outBounce(e));
      if (e > 0) {
        ctx.fillStyle = "rgba(0,0,0,0.3)"; ctx.beginPath(); ctx.ellipse(cx, cy + 4 * s.u, r * 0.7 * clamp(e * 1.5), r * 0.22 * clamp(e * 1.5), 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.moveTo(cx, y); ctx.bezierCurveTo(cx - r * 0.3, y - r * 0.7, cx - r, y - r * 1.1, cx - r, y - r * 1.75);
        ctx.arc(cx, y - r * 1.75, r, Math.PI, 0); ctx.bezierCurveTo(cx + r, y - r * 1.1, cx + r * 0.3, y - r * 0.7, cx, y); ctx.fill();
        ctx.fillStyle = "#FFF"; ctx.beginPath(); ctx.arc(cx, y - r * 1.75, r * 0.4, 0, Math.PI * 2); ctx.fill();
      }
      const p = E.outQuint(okno(s.t, 0.7 / s.p.tempo, 0.6)); if (p <= 0 || !s.p.tekst) return;
      const px = 50 * s.u * s.p.rozmiar; ctx.font = font(s, px, s.p.waga); const w1 = ctx.measureText(tekstP(s, s.p.tekst)).width;
      ctx.font = font(s, px * 0.6, 500); const w2 = s.p.tekst2 ? ctx.measureText(s.p.tekst2).width : 0;
      const W = Math.max(w1, w2) + 50 * s.u, H = px * (s.p.tekst2 ? 2.2 : 1.6), x0 = cx + r * 1.5, y0 = cy - r * 1.75 - H / 2;
      ctx.save(); ctx.beginPath(); ctx.rect(x0, y0 - 10, W + 20, H + 20); ctx.clip(); cien(s);
      ctx.fillStyle = "#FFFFFF"; zaokr(ctx, x0 - W * (1 - p), y0, W, H, 16 * s.u); ctx.fill(); bezCienia(ctx);
      ctx.font = font(s, px, s.p.waga); ctx.fillStyle = "#111"; ctx.fillText(tekstP(s, s.p.tekst), x0 + 25 * s.u - W * (1 - p), s.p.tekst2 ? y0 + H * 0.36 : y0 + H / 2);
      if (s.p.tekst2) { ctx.font = font(s, px * 0.6, 500); ctx.fillStyle = s.k.g; ctx.fillText(s.p.tekst2, x0 + 25 * s.u - W * (1 - p), y0 + H * 0.7); }
      ctx.restore();
    } });
  dodaj({ id: "przesun-w-gore", nazwa: "Przesuń w górę", kat: "cta", czas: 3, pola: ["tekst"], dom: { pozycja: "dol" }, przyklad: { tekst: "Przesuń po więcej" },
    rysuj(s) {
      const ctx = s.ctx, e = E.outCubic(okno(s.t, 0, 0.4)), cx = s.poz.x, y = s.poz.y + 30 * s.u;
      ctx.globalAlpha = s.alfa * e; ctx.strokeStyle = s.k.t; ctx.lineWidth = 9 * s.u * s.p.rozmiar; ctx.lineCap = "round"; ctx.lineJoin = "round"; cien(s);
      for (let i = 0; i < 3; i++) {
        const f = ((s.t * 1.3 + i / 3) % 1), yy = y - f * 90 * s.u, a = Math.sin(f * Math.PI);
        ctx.globalAlpha = s.alfa * e * a; ctx.beginPath(); ctx.moveTo(cx - 34 * s.u, yy); ctx.lineTo(cx, yy - 30 * s.u); ctx.lineTo(cx + 34 * s.u, yy); ctx.stroke();
      }
      ctx.globalAlpha = s.alfa * e; ctx.font = font(s, 50 * s.u * s.p.rozmiar, 700); const w = ctx.measureText(tekstP(s, s.p.tekst)).width;
      ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), cx - w / 2, y + 70 * s.u); ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "logo-odkrycie", nazwa: "Odkrycie logo", kat: "cta", czas: 3, pola: ["logo", "tekst"], przyklad: { tekst: "nadamedia" },
    rysuj(s) {
      const ctx = s.ctx, cx = s.poz.x, cy = s.poz.y, R = 260 * s.u * s.p.rozmiar, e = E.outQuint(okno(s.t, 0.1, 0.9 / s.p.tempo)), ring = okno(s.t, 0, 1.1 / s.p.tempo);
      ctx.strokeStyle = rgba(s.k.a, 1 - ring); ctx.lineWidth = 8 * s.u; ctx.beginPath(); ctx.arc(cx, cy, R * 0.3 + ring * R * 1.1, 0, Math.PI * 2); ctx.stroke();
      ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, Math.max(0.1, R * 1.4 * e), 0, Math.PI * 2); ctx.clip();
      const img = s.p.logo;
      if (img && (img.width || img.naturalWidth)) {
        const iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height, k = Math.min(R * 1.6 / iw, R * 1.0 / ih) * lerp(1.25, 1, e);
        ctx.drawImage(img, cx - iw * k / 2, cy - ih * k / 2, iw * k, ih * k);
      } else { const px = dopasuj(s, s.p.tekst, 120 * s.u * s.p.rozmiar, R * 1.8, 900); ctx.font = font(s, px, 900); const w = ctx.measureText(tekstP(s, s.p.tekst)).width; ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), cx - w / 2, cy); }
      ctx.restore();
    } });
  dodaj({ id: "reflektor", nazwa: "Reflektor (przyciemnienie wokół)", kat: "rolki", czas: 3, pola: ["xy"], przyklad: { x: 0.5, y: 0.42 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), e = E.outCubic(okno(s.t, 0, 0.5 / s.p.tempo)), r = lerp(Math.max(s.W, s.H), 220 * s.u * s.p.rozmiar, e);
      const c = warstwa(s, "reflektor", (x) => {
        x.fillStyle = `rgba(0,0,0,${0.62 * e})`; x.fillRect(0, 0, s.W, s.H); x.globalCompositeOperation = "destination-out";
        const g = x.createRadialGradient(cx, cy, r * 0.75, cx, cy, r); g.addColorStop(0, "rgba(0,0,0,1)"); g.addColorStop(1, "rgba(0,0,0,0)");
        x.fillStyle = g; x.beginPath(); x.arc(cx, cy, r, 0, Math.PI * 2); x.fill();
      });
      ctx.drawImage(c, 0, 0);
    } });
  dodaj({ id: "nagrywanie", nazwa: "Kadr kamery REC", kat: "rolki", czas: 5, pola: [], przyklad: {},
    rysuj(s) {
      const ctx = s.ctx, m = 50 * s.u, d = 90 * s.u, e = E.outCubic(okno(s.t, 0, 0.4)), g = 6 * s.u;
      ctx.strokeStyle = "#FFFFFF"; ctx.lineWidth = g; ctx.globalAlpha = s.alfa * e; const mm = m + (1 - e) * 40 * s.u;
      [[mm, mm, 1, 1], [s.W - mm, mm, -1, 1], [mm, s.H - mm, 1, -1], [s.W - mm, s.H - mm, -1, -1]].forEach(([x, y, a, b]) => {
        ctx.beginPath(); ctx.moveTo(x, y + d * b); ctx.lineTo(x, y); ctx.lineTo(x + d * a, y); ctx.stroke();
      });
      if (Math.floor(s.t * 1.6) % 2 === 0) { ctx.fillStyle = "#FF2D2D"; ctx.beginPath(); ctx.arc(mm + 50 * s.u, mm + 70 * s.u, 14 * s.u, 0, Math.PI * 2); ctx.fill(); }
      ctx.font = `700 ${Math.round(40 * s.u)}px Consolas, "Courier New", monospace`; ctx.fillStyle = "#FFF"; ctx.fillText("REC", mm + 80 * s.u, mm + 72 * s.u);
      const sek = Math.floor(s.t), kl = Math.floor((s.t % 1) * 25), tc = `00:00:${String(sek).padStart(2, "0")}:${String(kl).padStart(2, "0")}`;
      const w = ctx.measureText(tc).width; ctx.fillText(tc, s.W - mm - 40 * s.u - w, mm + 72 * s.u);
      ctx.strokeRect(s.W - mm - 140 * s.u, s.H - mm - 90 * s.u, 80 * s.u, 36 * s.u); ctx.fillRect(s.W - mm - 134 * s.u, s.H - mm - 84 * s.u, 50 * s.u, 24 * s.u); ctx.fillRect(s.W - mm - 60 * s.u, s.H - mm - 80 * s.u, 6 * s.u, 16 * s.u);
      ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "naklejka", nazwa: "Naklejka", kat: "rolki", czas: 3, pola: ["tekst", "xy"], przyklad: { tekst: "MUST HAVE", x: 0.7, y: 0.25, wielkie: true },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), px = 62 * s.u * s.p.rozmiar; ctx.font = font(s, px, 900);
      const t = tekstP(s, s.p.tekst), w = ctx.measureText(t).width, W = w + 60 * s.u, H = px * 1.7, e = E.outBackMocno(okno(s.t, 0, 0.45 / s.p.tempo));
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(-0.1 + Math.sin(s.t * 3.2) * 0.04); ctx.scale(e, e); cien(s, ctx, 1.2);
      ctx.fillStyle = "#FFFFFF"; zaokr(ctx, -W / 2 - 10 * s.u, -H / 2 - 10 * s.u, W + 20 * s.u, H + 20 * s.u, 26 * s.u); ctx.fill(); bezCienia(ctx);
      ctx.fillStyle = s.k.g; zaokr(ctx, -W / 2, -H / 2, W, H, 18 * s.u); ctx.fill();
      ctx.fillStyle = kontrast(s.k.g); ctx.fillText(t, -w / 2, 0); ctx.restore();
    } });
  dodaj({ id: "etykieta", nazwa: "Etykieta NOWOŚĆ", kat: "cta", czas: 3, pola: ["tekst"], dom: { pozycja: "lewy-gora", wielkie: true }, przyklad: { tekst: "Nowość" },
    rysuj(s) {
      const ctx = s.ctx, px = 50 * s.u * s.p.rozmiar; ctx.font = font(s, px, 900); const t = tekstP(s, s.p.tekst), w = ctx.measureText(t).width;
      const H = px * 1.6, W = w + 70 * s.u, e = E.outQuint(okno(s.t, 0, 0.6 / s.p.tempo)), x0 = prawa(s) ? s.poz.x - W : s.poz.x, y0 = s.poz.y - H / 2;
      const dx = (1 - e) * (prawa(s) ? 1 : -1) * (W + x0 + 50);
      ctx.save(); ctx.translate(dx, 0); cien(s); ctx.fillStyle = s.k.a; ctx.beginPath();
      ctx.moveTo(x0, y0); ctx.lineTo(x0 + W, y0); ctx.lineTo(x0 + W - 24 * s.u, y0 + H / 2); ctx.lineTo(x0 + W, y0 + H); ctx.lineTo(x0, y0 + H); ctx.closePath(); ctx.fill(); bezCienia(ctx);
      ctx.fillStyle = kontrast(s.k.a); ctx.fillText(t, x0 + 24 * s.u, y0 + H / 2); ctx.restore();
    } });
  dodaj({ id: "klikniecie", nazwa: "Kursor i kliknięcie", kat: "rolki", czas: 2.5, pola: ["xy"], przyklad: { x: 0.55, y: 0.5 },
    rysuj(s) {
      const ctx = s.ctx, [tx, ty] = punkt(s), klik = 0.9 / s.p.tempo, m = E.inOutCubic(okno(s.t, 0, klik));
      if (s.t > klik) for (let i = 0; i < 2; i++) { const r = okno(s.t, klik + i * 0.12, 0.6); if (r <= 0 || r >= 1) continue; ctx.strokeStyle = rgba(s.k.a, 1 - r); ctx.lineWidth = 6 * s.u; ctx.beginPath(); ctx.arc(tx, ty, 10 * s.u + r * 90 * s.u, 0, Math.PI * 2); ctx.stroke(); }
      const sk = 2 * s.u * s.p.rozmiar * (s.t > klik && s.t < klik + 0.15 ? 0.85 : 1);
      kursor(ctx, lerp(tx + 260 * s.u, tx, m), lerp(ty + 300 * s.u, ty, m), sk);
    } });
  dodaj({ id: "powiadomienie", nazwa: "Powiadomienie na telefonie", kat: "rolki", czas: 4, pola: ["tekst", "tekst2"], dom: { pozycja: "gora" }, przyklad: { tekst: "Nowe zamówienie! 🎉", tekst2: "Ktoś właśnie kupił Twój kurs" },
    rysuj(s) {
      const ctx = s.ctx, W = Math.min(s.W * 0.88, 900 * s.u), H = 170 * s.u * s.p.rozmiar, x0 = s.W / 2 - W / 2;
      const e = E.outBack(okno(s.t, 0, 0.55 / s.p.tempo)), y0 = lerp(-H - 20, s.poz.y - H / 2, e);
      cien(s, ctx, 1.4); ctx.fillStyle = "rgba(245,245,247,0.97)"; zaokr(ctx, x0, y0, W, H, 34 * s.u); ctx.fill(); bezCienia(ctx);
      const ik = H * 0.42; ctx.fillStyle = s.k.g; zaokr(ctx, x0 + 26 * s.u, y0 + H / 2 - ik / 2, ik, ik, ik * 0.24); ctx.fill();
      const lit = (s.p.tekst || "N").replace(/[^A-Za-zĄĆĘŁŃÓŚŹŻąćęłńóśźż]/g, "")[0] || "N";
      ctx.font = font(s, ik * 0.55, 800); let w = ctx.measureText(lit.toUpperCase()).width; ctx.fillStyle = kontrast(s.k.g); ctx.fillText(lit.toUpperCase(), x0 + 26 * s.u + ik / 2 - w / 2, y0 + H / 2);
      const tx = x0 + 26 * s.u + ik + 24 * s.u;
      ctx.font = font(s, 40 * s.u * s.p.rozmiar, 700); ctx.fillStyle = "#111"; ctx.fillText(s.p.tekst, tx, y0 + H * 0.36);
      ctx.font = font(s, 34 * s.u * s.p.rozmiar, 400); ctx.fillStyle = "#444"; ctx.fillText(s.p.tekst2 || "", tx, y0 + H * 0.66);
      ctx.font = font(s, 28 * s.u, 400); ctx.fillStyle = "#888"; w = ctx.measureText("teraz").width; ctx.fillText("teraz", x0 + W - 30 * s.u - w, y0 + H * 0.36);
    } });
  dodaj({ id: "komentarz", nazwa: "Odpowiedź na komentarz", kat: "rolki", czas: 4, pola: ["tekst", "tekst2"], dom: { pozycja: "gora" }, przyklad: { tekst: "Jak to zrobiłeś?? 🤯", tekst2: "ania.k" },
    rysuj(s) {
      const ctx = s.ctx, px = 52 * s.u * s.p.rozmiar, ul = uloz(s, s.p.tekst, px, { maxW: s.W * 0.62, align: "left", x: 0, y: 0, waga: 600 });
      const naglowek = "Odpowiedz użytkownikowi " + (s.p.tekst2 || "widz"); ctx.font = font(s, 30 * s.u, 600);
      const W = Math.max(ul.w, ctx.measureText(naglowek).width, 300 * s.u) + 160 * s.u, H = ul.h + 110 * s.u, x0 = s.W / 2 - W / 2, y0 = s.poz.y - H / 2;
      const e = E.outBackMocno(okno(s.t, 0, 0.45 / s.p.tempo)); ctx.save(); ctx.translate(x0 + 40 * s.u, y0 + H); ctx.scale(e, e); ctx.translate(-x0 - 40 * s.u, -y0 - H);
      cien(s); ctx.fillStyle = "#FFFFFF"; zaokr(ctx, x0, y0, W, H, 30 * s.u); ctx.fill(); bezCienia(ctx);
      const r = 36 * s.u; ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(x0 + 30 * s.u + r, y0 + 30 * s.u + r, r, 0, Math.PI * 2); ctx.fill();
      ctx.font = font(s, 30 * s.u, 600); ctx.fillStyle = "#666"; ctx.fillText(naglowek, x0 + 120 * s.u, y0 + 46 * s.u);
      ctx.font = ul.font; ul.slowa.forEach((w) => { ctx.fillStyle = w.wyr ? s.k.g : "#111"; ctx.fillText(w.t, x0 + 120 * s.u + w.x, y0 + 72 * s.u + px * 0.6 + w.y - ul.y - ul.lh / 2 + ul.lh / 2); });
      ctx.restore();
    } });
  dodaj({ id: "wyszukiwarka", nazwa: "Wpisywanie w wyszukiwarkę", kat: "rolki", czas: 3.5, pola: ["tekst"], przyklad: { tekst: "jak zacząć montować filmy" },
    rysuj(s) {
      const ctx = s.ctx, px = 46 * s.u * s.p.rozmiar, W = s.W * 0.84, H = px * 2.2, x0 = s.poz.x - W / 2, y0 = s.poz.y - H / 2;
      const e = E.outBack(okno(s.t, 0, 0.4)), n = Array.from(s.p.tekst || ""), ile = Math.floor(okno(s.t, 0.45, n.length * 0.06 / s.p.tempo) * n.length);
      const enter = 0.5 + n.length * 0.06 / s.p.tempo + 0.25, nac = s.t > enter && s.t < enter + 0.15 ? 0.96 : 1;
      ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(e * nac, e * nac); ctx.translate(-s.poz.x, -s.poz.y);
      cien(s); ctx.fillStyle = "#FFFFFF"; zaokr(ctx, x0, y0, W, H, H / 2); ctx.fill(); bezCienia(ctx);
      ctx.strokeStyle = "#777"; ctx.lineWidth = 5 * s.u; ctx.beginPath(); ctx.arc(x0 + H * 0.5, s.poz.y - 4 * s.u, px * 0.36, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(x0 + H * 0.5 + px * 0.26, s.poz.y + px * 0.22); ctx.lineTo(x0 + H * 0.5 + px * 0.5, s.poz.y + px * 0.46); ctx.stroke();
      ctx.font = font(s, px, 500); ctx.fillStyle = "#111"; const t = n.slice(0, ile).join(""); ctx.fillText(t, x0 + H * 0.95, s.poz.y);
      if (Math.floor(s.t * 2.4) % 2 === 0 || ile < n.length) { const w = ctx.measureText(t).width; ctx.fillStyle = s.k.g; ctx.fillRect(x0 + H * 0.95 + w + 4 * s.u, s.poz.y - px * 0.5, 4 * s.u, px); }
      ctx.restore();
    } });
  dodaj({ id: "gwiazdki", nazwa: "Ocena w gwiazdkach", kat: "liczby", czas: 3, pola: ["liczba", "tekst"], przyklad: { liczba: 5, tekst: "4,9 / 5 z 1200 opinii" },
    rysuj(s) {
      const ctx = s.ctx, r = 56 * s.u * s.p.rozmiar, n = clamp(+s.p.liczba || 5, 0, 5), x0 = s.poz.x - r * 2.4 * 2, y = s.poz.y;
      for (let i = 0; i < 5; i++) {
        const e = E.outBackMocno(okno(s.t, i * 0.12 / s.p.tempo, 0.4)); if (e <= 0) continue; const x = x0 + i * r * 2.4;
        ctx.save(); ctx.translate(x, y); ctx.scale(e, e); ctx.rotate((1 - e) * 1.2); cien(s);
        gwiazda(ctx, 0, 0, 5, r, r * 0.45); ctx.fillStyle = rgba(s.k.t, 0.25); ctx.fill(); bezCienia(ctx);
        const wyp = clamp(n - i); if (wyp > 0) { ctx.save(); ctx.beginPath(); ctx.rect(-r, -r, 2 * r * wyp, 2 * r); ctx.clip(); gwiazda(ctx, 0, 0, 5, r, r * 0.45); ctx.fillStyle = s.k.a; ctx.fill(); ctx.restore(); }
        ctx.restore();
      }
      if (s.p.tekst) { const e = okno(s.t, 0.7, 0.4); ctx.globalAlpha = s.alfa * e; const u2 = uloz(s, s.p.tekst, 46 * s.u * s.p.rozmiar, { x: s.poz.x, align: "center", y: y + r * 1.9, gora: true, waga: 600 }); ctx.font = u2.font; cien(s); u2.slowa.forEach((w) => piszSlowo(s, w)); ctx.globalAlpha = s.alfa; }
    } });
  dodaj({ id: "os-czasu", nazwa: "Oś czasu", kat: "rolki", czas: 5, pola: ["lista"], przyklad: { lista: "2019: Start\n2021: 1. biuro\n2023: 50 osób\n*2026*: Europa" },
    rysuj(s) {
      const ctx = s.ctx, d = lista(s.p.lista).map((x) => { const i = x.indexOf(":"); return i > 0 ? [x.slice(0, i).trim(), x.slice(i + 1).trim()] : [x, ""]; }); if (!d.length) return;
      const W = s.W * 0.84, x0 = s.W / 2 - W / 2, y = s.poz.y, krok = (s.T - s.p.wyjscie - 0.8) / d.length / s.p.tempo;
      const l = E.inOutCubic(okno(s.t, 0, Math.max(0.5, krok * d.length))); ctx.fillStyle = rgba(s.k.t, 0.7); ctx.fillRect(x0, y - 2 * s.u, W * l, 4 * s.u);
      d.forEach(([rok, opis], i) => {
        const x = x0 + W * (d.length === 1 ? 0.5 : i / (d.length - 1)) * 0.92 + W * 0.04, e = E.outBackMocno(okno(s.t, 0.2 + i * krok, 0.4)); if (e <= 0) return;
        const wyr = /^\*.*\*$/.test(rok), r2 = rok.replace(/\*/g, "");
        ctx.save(); ctx.translate(x, y); ctx.scale(e, e); ctx.fillStyle = wyr ? s.k.a : s.k.g; ctx.beginPath(); ctx.arc(0, 0, 18 * s.u, 0, Math.PI * 2); ctx.fill(); ctx.restore();
        ctx.globalAlpha = s.alfa * clamp(e); const gora = i % 2 === 0;
        ctx.font = font(s, 46 * s.u * s.p.rozmiar, 900); let w = ctx.measureText(r2).width; ctx.fillStyle = wyr ? s.k.a : s.k.t; cien(s);
        ctx.fillText(r2, clamp(x - w / 2, 10, s.W - w - 10), y + (gora ? -70 : 70) * s.u);
        ctx.font = font(s, 30 * s.u * s.p.rozmiar, 500); w = ctx.measureText(opis).width; ctx.fillStyle = s.k.t; ctx.fillText(opis, clamp(x - w / 2, 10, s.W - w - 10), y + (gora ? -122 : 118) * s.u); bezCienia(ctx);
        ctx.globalAlpha = s.alfa;
      });
    } });
  dodaj({ id: "przed-po", nazwa: "Przed / Po", kat: "rolki", czas: 3.5, pola: ["tekst", "tekst2"], przyklad: { tekst: "PRZED", tekst2: "PO" },
    rysuj(s) {
      const ctx = s.ctx, l = E.inOutCubic(okno(s.t, 0, 0.7 / s.p.tempo)), e = E.outBackMocno(okno(s.t, 0.35 / s.p.tempo, 0.45));
      ctx.fillStyle = "#FFFFFF"; ctx.fillRect(s.W / 2 - 3 * s.u, 0, 6 * s.u, s.H * l); const px = 54 * s.u * s.p.rozmiar, y = s.H * 0.1;
      [[s.p.tekst || "PRZED", s.W * 0.25, "#222"], [s.p.tekst2 || "PO", s.W * 0.75, s.k.g]].forEach(([t, x, kol]) => {
        ctx.save(); ctx.translate(x, y); ctx.scale(e, e); ctx.font = font(s, px, 900); const w = ctx.measureText(t).width;
        cien(s); ctx.fillStyle = kol; zaokr(ctx, -w / 2 - 26 * s.u, -px * 0.8, w + 52 * s.u, px * 1.6, 14 * s.u); ctx.fill(); bezCienia(ctx);
        ctx.fillStyle = kontrast(kol); ctx.fillText(t, -w / 2, 0); ctx.restore();
      });
    } });
  dodaj({ id: "hashtagi", nazwa: "Hashtagi wypływają", kat: "rolki", czas: 4, pola: ["lista"], przyklad: { lista: "#montaż; #rolki; #tiktok; #reels; #wideo" },
    rysuj(s) {
      const ctx = s.ctx, el = lista(s.p.lista), px = 50 * s.u * s.p.rozmiar;
      el.forEach((t, i) => {
        const e = E.outCubic(okno(s.t, i * 0.22 / s.p.tempo, 0.7)); if (e <= 0) return;
        ctx.font = font(s, px, 700); const w = ctx.measureText(t).width, x = s.W * (0.12 + los(i + 3) * 0.6), y = s.poz.y + (i - el.length / 2) * px * 1.5 + (1 - e) * 120 * s.u;
        ctx.save(); ctx.globalAlpha *= e; cien(s); ctx.fillStyle = rgba(s.k.tl, 0.85); zaokr(ctx, x - 18 * s.u, y - px * 0.75, w + 36 * s.u, px * 1.5, px * 0.75); ctx.fill(); bezCienia(ctx);
        ctx.fillStyle = i % 2 ? s.k.a : s.k.t; ctx.fillText(t, x, y); ctx.restore();
      });
    } });
  dodaj({ id: "serduszka", nazwa: "Serduszka lecą w górę", kat: "rolki", czas: 4, pola: ["xy"], dom: { wyjscie: 0.8 }, przyklad: { x: 0.82, y: 0.85 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s);
      for (let i = 0; i < 18; i++) {
        const st = i * 0.17, z = (s.t - st) / 2.2; if (z <= 0 || z >= 1) continue;
        const r = (22 + los(i) * 26) * s.u * s.p.rozmiar, x = cx + Math.sin(z * 6 + i) * 50 * s.u + (los(i + 9) - 0.5) * 80 * s.u, y = cy - z * s.H * 0.55;
        ctx.save(); ctx.globalAlpha *= Math.sin(z * Math.PI); serce(ctx, x, y, r); ctx.fillStyle = [s.k.g, s.k.a, "#FF3B5C"][i % 3]; ctx.fill(); ctx.restore();
      }
    } });
  dodaj({ id: "konfetti", nazwa: "Konfetti", kat: "przejscia", czas: 3, pola: ["xy"], dom: { wyjscie: 0.6 }, przyklad: { x: 0.5, y: 0.5 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), kol = [s.k.g, s.k.a, "#FFFFFF", "#4ADE80", "#60A5FA", "#F472B6"];
      for (let i = 0; i < 90; i++) {
        const a = los(i) * Math.PI * 2, v = (500 + los(i + 1) * 900) * s.u, t = s.t;
        const x = cx + Math.cos(a) * v * (1 - Math.exp(-t * 2.2)) * 0.55, y = cy + Math.sin(a) * v * (1 - Math.exp(-t * 2.2)) * 0.55 + 260 * s.u * t * t;
        const w = (10 + los(i + 2) * 14) * s.u * s.p.rozmiar;
        ctx.save(); ctx.translate(x, y); ctx.rotate(t * (4 + los(i + 3) * 8)); ctx.scale(1, Math.cos(t * 9 + i)); ctx.fillStyle = kol[i % kol.length]; ctx.fillRect(-w / 2, -w / 4, w, w / 2); ctx.restore();
      }
    } });
  dodaj({ id: "krok", nazwa: "Krok z numerem", kat: "rolki", czas: 3.5, pola: ["liczba", "tekst", "tekst2"], dom: { pozycja: "lewy-srodek" }, przyklad: { liczba: 1, tekst: "Zaplanuj treść", tekst2: "zanim włączysz kamerę" },
    rysuj(s) {
      const ctx = s.ctx, r = 70 * s.u * s.p.rozmiar, x = s.poz.align === "center" ? s.W * 0.15 : s.poz.x + r, y = s.poz.y;
      const e = E.outBackMocno(okno(s.t, 0, 0.4)); ctx.save(); ctx.translate(x, y); ctx.scale(e, e); ctx.rotate((1 - e) * -0.8); cien(s);
      ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill(); bezCienia(ctx);
      const n = String(Math.round(+s.p.liczba || 1)); ctx.font = font(s, r * 1.05, 900); const w = ctx.measureText(n).width; ctx.fillStyle = kontrast(s.k.g); ctx.fillText(n, -w / 2, 2 * s.u); ctx.restore();
      const tx = x + r + 30 * s.u, e1 = E.outQuint(okno(s.t, 0.2, 0.6)), e2 = E.outQuint(okno(s.t, 0.35, 0.6));
      ctx.save(); ctx.beginPath(); ctx.rect(tx, y - r * 1.5, s.W, r * 3); ctx.clip(); cien(s);
      ctx.font = font(s, 64 * s.u * s.p.rozmiar, s.p.waga); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), tx - (1 - e1) * 500 * s.u, s.p.tekst2 ? y - r * 0.28 : y);
      if (s.p.tekst2) { ctx.font = font(s, 40 * s.u * s.p.rozmiar, 500); ctx.fillStyle = rgba(s.k.t, 0.85); ctx.fillText(s.p.tekst2, tx - (1 - e2) * 500 * s.u, y + r * 0.45); }
      ctx.restore();
    } });
  dodaj({ id: "pytanie", nazwa: "Pytanie do widza", kat: "cta", czas: 3.5, pola: ["tekst"], przyklad: { tekst: "A Ty jak *myślisz*?" },
    rysuj(s) {
      const ctx = s.ctx, r = 80 * s.u * s.p.rozmiar, e = E.outBackMocno(okno(s.t, 0, 0.45)), cy = s.poz.y - 80 * s.u * s.p.rozmiar;
      ctx.save(); ctx.translate(s.poz.x, cy - r * 0.6); ctx.scale(e, e); ctx.rotate(Math.sin(s.t * 3) * 0.08); cien(s);
      ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill(); bezCienia(ctx);
      ctx.font = font(s, r * 1.3, 900); const w = ctx.measureText("?").width; ctx.fillStyle = kontrast(s.k.a); ctx.fillText("?", -w / 2, 4 * s.u); ctx.restore();
      const ul = uloz(s, s.p.tekst, 70 * s.u * s.p.rozmiar, { y: cy + r * 0.9, gora: true, align: "center", x: s.poz.x }); ctx.font = ul.font; cien(s);
      ul.slowa.forEach((w2) => { const e2 = okno(s.t, 0.3 + w2.i * 0.08, 0.3); if (e2 <= 0) return; ctx.globalAlpha = s.alfa * e2; piszSlowo(s, w2, null, ctx, 0, (1 - e2) * 20 * s.u); });
      ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "statystyka", nazwa: "Duża statystyka", kat: "liczby", czas: 3.5, pola: ["tekst", "tekst2"], przyklad: { tekst: "3 mln", tekst2: "wyświetleń w miesiąc" },
    rysuj(s) {
      const ctx = s.ctx, px = dopasuj(s, s.p.tekst, 200 * s.u * s.p.rozmiar, s.W * 0.86, 900), e = E.outQuint(okno(s.t, 0, 0.6 / s.p.tempo));
      ctx.font = font(s, px, 900); const t = tekstP(s, s.p.tekst), w = ctx.measureText(t).width;
      const x = s.poz.align === "left" ? s.poz.x : s.poz.align === "right" ? s.poz.x - w : s.poz.x - w / 2, y = s.poz.y - 30 * s.u;
      ctx.save(); ctx.beginPath(); ctx.rect(0, y - px * 0.62, s.W, px * 1.2); ctx.clip(); cien(s); ctx.fillStyle = s.k.t; ctx.fillText(t, x, y + (1 - e) * px * 1.1); ctx.restore();
      const l = E.inOutCubic(okno(s.t, 0.3 / s.p.tempo, 0.5)); ctx.fillStyle = s.k.a; ctx.fillRect(x, y + px * 0.6, w * l, 12 * s.u * s.p.rozmiar);
      if (s.p.tekst2) { const e2 = E.outCubic(okno(s.t, 0.55 / s.p.tempo, 0.5)); ctx.globalAlpha = s.alfa * e2; ctx.font = font(s, 52 * s.u * s.p.rozmiar, 600); cien(s); ctx.fillStyle = s.k.t; const w2 = ctx.measureText(s.p.tekst2).width; ctx.fillText(s.p.tekst2, s.poz.align === "center" ? s.poz.x - w2 / 2 : x, y + px * 0.6 + 70 * s.u); ctx.globalAlpha = s.alfa; }
    } });
  dodaj({ id: "trasa", nazwa: "Trasa A → B", kat: "rolki", czas: 3.5, pola: ["tekst", "tekst2", "xy", "xy2"], przyklad: { tekst: "Warszawa", tekst2: "Lizbona", x: 0.25, y: 0.62, x2: 0.75, y2: 0.36 },
    rysuj(s) {
      const ctx = s.ctx, a = punkt(s), b = punkt(s, "x2", "y2"), mid = [(a[0] + b[0]) / 2, Math.min(a[1], b[1]) - Math.abs(b[0] - a[0]) * 0.3];
      const e = E.inOutCubic(okno(s.t, 0.3, 1.4 / s.p.tempo)), pkt = krzywa(a, mid, b, 60);
      ctx.setLineDash([16 * s.u, 14 * s.u]); ctx.strokeStyle = s.k.t; ctx.lineWidth = 6 * s.u; ctx.lineCap = "round"; cien(s);
      const { koniec } = sciezkaCzesc(ctx, pkt, e); ctx.stroke(); ctx.setLineDash([]);
      [[a, s.p.tekst, 0], [b, s.p.tekst2, 1.6 / s.p.tempo]].forEach(([p, t, d]) => {
        const k = E.outBackMocno(okno(s.t, d, 0.4)); if (k <= 0) return;
        ctx.save(); ctx.translate(...p); ctx.scale(k, k); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, 20 * s.u, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = "#FFF"; ctx.lineWidth = 5 * s.u; ctx.stroke(); if (t) { ctx.font = font(s, 46 * s.u * s.p.rozmiar, s.p.waga); const w = ctx.measureText(t).width; ctx.fillStyle = s.k.t; ctx.fillText(t, -w / 2, 64 * s.u); } ctx.restore();
      });
      if (e > 0 && e < 1) { ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(...koniec, 14 * s.u, 0, Math.PI * 2); ctx.fill(); }
    } });
  dodaj({ id: "lajk", nazwa: "Lajk z wybuchem", kat: "cta", czas: 2.5, pola: ["xy"], przyklad: { x: 0.5, y: 0.5 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), r = 90 * s.u * s.p.rozmiar, e = E.outElastic(okno(s.t, 0.1, 0.9 / s.p.tempo)), w = okno(s.t, 0.15, 0.5);
      if (w > 0 && w < 1) for (let i = 0; i < 12; i++) { const a = (i / 12) * Math.PI * 2, d1 = r * (1.1 + w * 0.9), d2 = r * (1.3 + w * 1.2); ctx.strokeStyle = rgba(i % 2 ? s.k.a : s.k.g, 1 - w); ctx.lineWidth = 7 * s.u; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * d1, cy + Math.sin(a) * d1); ctx.lineTo(cx + Math.cos(a) * d2, cy + Math.sin(a) * d2); ctx.stroke(); }
      ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); cien(s); serce(ctx, 0, r * 0.1, r); ctx.fillStyle = "#FF3B5C"; ctx.fill(); ctx.restore();
    } });

  // Przejścia i akcenty (pełny kadr, z własnym zakończeniem)
  dodaj({ id: "przejscie-panele", nazwa: "Przejście: panele kolorów", kat: "przejscia", czas: 1.2, pola: [], pelne: true, przyklad: {},
    rysuj(s) {
      const ctx = s.ctx, T = s.T;
      [[s.k.g, 0], [s.k.a, 0.08], [s.k.tl, 0.16]].forEach(([kol, d]) => {
        const a = E.inOutCubic(okno(s.t, d * T, T * 0.42)), b = E.inOutCubic(okno(s.t, T * 0.5 + d * T * 0.5, T * 0.42));
        const x0 = s.W * b, x1 = s.W * a; if (x1 > x0) { ctx.fillStyle = kol; ctx.fillRect(x0, 0, x1 - x0, s.H); }
      });
    } });
  dodaj({ id: "przejscie-kolo", nazwa: "Przejście: koło", kat: "przejscia", czas: 1.2, pola: ["xy"], pelne: true, przyklad: {},
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), R = Math.hypot(Math.max(cx, s.W - cx), Math.max(cy, s.H - cy)) * 1.02;
      const a = E.inOutCubic(okno(s.t, 0, s.T * 0.48)), b = E.inOutCubic(okno(s.t, s.T * 0.52, s.T * 0.48));
      const c = warstwa(s, "kolo", (x) => {
        x.fillStyle = s.k.g; x.beginPath(); x.arc(cx, cy, Math.max(0.1, R * a), 0, Math.PI * 2); x.fill();
        if (b > 0) { x.globalCompositeOperation = "destination-out"; x.beginPath(); x.arc(cx, cy, Math.max(0.1, R * b), 0, Math.PI * 2); x.fill(); }
      });
      ctx.drawImage(c, 0, 0);
    } });
  dodaj({ id: "przejscie-paski", nazwa: "Przejście: ukośne paski", kat: "przejscia", czas: 1.2, pola: [], pelne: true, przyklad: {},
    rysuj(s) {
      const ctx = s.ctx, n = 7, D = Math.hypot(s.W, s.H), sz = D / n;
      ctx.save(); ctx.translate(s.W / 2, s.H / 2); ctx.rotate(-0.5);
      for (let i = 0; i < n; i++) {
        const a = E.inOutCubic(okno(s.t, i * 0.035 * s.T, s.T * 0.4)), b = E.inOutCubic(okno(s.t, s.T * 0.5 + i * 0.035 * s.T, s.T * 0.4));
        const y = -D / 2 + i * sz, x0 = -D / 2 + D * b, x1 = -D / 2 + D * a;
        if (x1 > x0) { ctx.fillStyle = i % 2 ? s.k.a : s.k.g; ctx.fillRect(x0, y, x1 - x0, sz + 1); }
      }
      ctx.restore();
    } });
  dodaj({ id: "blysk-ekranu", nazwa: "Błysk ekranu", kat: "przejscia", czas: 0.6, pola: [], pelne: true, przyklad: { czas: 0.8 },
    rysuj(s) { const ctx = s.ctx, x = s.t / s.T, a = x < 0.25 ? x / 0.25 : 1 - (x - 0.25) / 0.75; ctx.fillStyle = `rgba(255,255,255,${clamp(a)})`; ctx.fillRect(0, 0, s.W, s.H); } });
  dodaj({ id: "kregi", nazwa: "Rozchodzące się kręgi", kat: "przejscia", czas: 2, pola: ["xy"], przyklad: {},
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), R = Math.max(s.W, s.H) * 0.7;
      for (let i = 0; i < 4; i++) { const e = E.outCubic(okno(s.t, i * 0.15, 1.1)); if (e <= 0 || e >= 1) continue; ctx.strokeStyle = rgba(i % 2 ? s.k.a : s.k.g, 1 - e); ctx.lineWidth = (30 - i * 5) * s.u; ctx.beginPath(); ctx.arc(cx, cy, R * e, 0, Math.PI * 2); ctx.stroke(); }
    } });
  dodaj({ id: "wybuch-linii", nazwa: "Wybuch linii (akcent)", kat: "przejscia", czas: 1.5, pola: ["xy"], przyklad: { x: 0.5, y: 0.45 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), r = 140 * s.u * s.p.rozmiar, e = okno(s.t, 0, 0.6 / s.p.tempo);
      ctx.lineCap = "round"; ctx.lineWidth = 10 * s.u * s.p.rozmiar;
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * Math.PI * 2 + 0.2, d1 = r * (1 + E.outCubic(e) * 0.9), d2 = r * (1 + E.outCubic(clamp(e * 1.6)) * 1.5);
        if (d2 <= d1) continue; ctx.strokeStyle = i % 2 ? s.k.a : s.k.g; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * d1, cy + Math.sin(a) * d1); ctx.lineTo(cx + Math.cos(a) * d2, cy + Math.sin(a) * d2); ctx.stroke();
      }
    } });
  dodaj({ id: "linie-predkosci", nazwa: "Linie prędkości", kat: "przejscia", czas: 1.5, pola: [], przyklad: {},
    rysuj(s) {
      const ctx = s.ctx;
      for (let i = 0; i < 26; i++) {
        const y = los(i) * s.H, v = 1.5 + los(i + 4) * 2.5, L = (150 + los(i + 1) * 500) * s.u, x = ((s.t * v + los(i + 7)) % 1.4) * (s.W + L * 2) - L;
        ctx.fillStyle = rgba(i % 3 ? "#FFFFFF" : s.k.a, 0.3 + los(i + 2) * 0.5); ctx.fillRect(x, y, L, (3 + los(i + 3) * 6) * s.u);
      }
    } });
  dodaj({ id: "ksztalty-tlo", nazwa: "Pływające kształty (tło)", kat: "przejscia", czas: 6, pola: [], przyklad: {},
    rysuj(s) {
      const ctx = s.ctx;
      for (let i = 0; i < 14; i++) {
        const x = (los(i) * s.W + Math.sin(s.t * 0.6 + i) * 60 * s.u), y = ((los(i + 20) * s.H - s.t * (20 + los(i + 3) * 40) * s.u) % s.H + s.H) % s.H, r = (14 + los(i + 5) * 40) * s.u;
        ctx.save(); ctx.translate(x, y); ctx.rotate(s.t * (los(i + 8) - 0.5)); ctx.globalAlpha *= 0.35 + los(i + 6) * 0.4; ctx.strokeStyle = ctx.fillStyle = i % 2 ? s.k.a : s.k.g; ctx.lineWidth = 5 * s.u;
        const typ = i % 4;
        if (typ === 0) { ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill(); }
        else if (typ === 1) { ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.stroke(); }
        else if (typ === 2) { ctx.fillRect(-r / 6, -r, r / 3, r * 2); ctx.fillRect(-r, -r / 6, r * 2, r / 3); }
        else { ctx.beginPath(); ctx.moveTo(0, -r); ctx.lineTo(r * 0.87, r * 0.5); ctx.lineTo(-r * 0.87, r * 0.5); ctx.closePath(); ctx.stroke(); }
        ctx.restore();
      }
    } });
  dodaj({ id: "ramka", nazwa: "Ramka rysowana dookoła", kat: "przejscia", czas: 3, pola: [], przyklad: {},
    rysuj(s) {
      const ctx = s.ctx, m = 40 * s.u, e = E.inOutCubic(okno(s.t, 0, 1.2 / s.p.tempo));
      const pkt = [[m, m], [s.W - m, m], [s.W - m, s.H - m], [m, s.H - m], [m, m]];
      ctx.strokeStyle = s.k.g; ctx.lineWidth = 12 * s.u * s.p.rozmiar; ctx.lineJoin = "round"; sciezkaCzesc(ctx, pkt, e); ctx.stroke();
    } });


  // =====================================================================
  // ---------- wersja 17: dużo nowych presetów w każdej kategorii ----------
  // =====================================================================
  const PI = Math.PI;
  /* Tekst wchodzący słowami, literami albo liniami. ruch(ctx, e, el, s, ul) ustawia przekształcenie
     (punkt 0,0 = środek elementu) i zwraca krycie (0–1); po nim rysowany jest sam element. */
  function tekstRuch(id, nazwa, o) {
    dodaj({ id, nazwa, kat: "tekst", czas: o.czas || 3, pola: o.pola || ["tekst"], dom: o.dom, przyklad: { tekst: o.przyklad },
      rysuj(s) {
        const ul = uloz(s, s.p.tekst, (o.px || 100) * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
        const jedn = o.jedn || "slowa", el = jedn === "znaki" ? znaki(s, ul) : jedn === "linie" ? ul.linie.map((l, i) => ({ l, i, x: l.x0, y: l.y, w: l.w })) : ul.slowa;
        const n = el.length, krok = (o.krok || (jedn === "znaki" ? 0.03 : 0.1)) / s.p.tempo, dl = (o.dl || 0.5) / s.p.tempo;
        el.forEach((x, i) => {
          const kol = o.kolejnosc ? o.kolejnosc(i, n) : i;
          const e = okno(s.t, kol * krok, dl);
          if (e <= 0 && !o.zawsze) return;
          ctx.save(); ctx.translate(x.x + x.w / 2, x.y);
          const a = o.ruch(ctx, e, x, s, ul, i, n);
          ctx.globalAlpha = s.alfa * (a == null ? 1 : clamp(a));
          if (o.cien !== false) cien(s);
          if (jedn === "znaki") { ctx.fillStyle = o.kolor ? o.kolor(s, x, i, n) : (x.slowo.wyr ? s.k.a : s.k.t); ctx.fillText(x.c, -x.w / 2, 0); }
          else if (jedn === "linie") x.l.slowa.forEach((w) => piszSlowo(s, w, null, ctx, -x.x - x.w / 2, -x.y));
          else { if (o.kolor) { ctx.fillStyle = o.kolor(s, x, i, n); ctx.fillText(x.t, -x.w / 2, 0); } else piszSlowo(s, x, null, ctx, -x.x - x.w / 2, -x.y); }
          ctx.restore();
        });
        if (o.po) o.po(s, ul);
      } });
  }
  tekstRuch("slowa-z-lewej", "Słowa wjeżdżają z lewej", { przyklad: "Szybko, *prosto*, skutecznie", ruch: (c, e, x, s) => { const k = E.outQuint(e); c.translate(-(1 - k) * 160 * s.u, 0); return e * 2; } });
  tekstRuch("slowa-z-prawej", "Słowa wjeżdżają z prawej", { przyklad: "Nowy *sezon* startuje", ruch: (c, e, x, s) => { const k = E.outQuint(e); c.translate((1 - k) * 160 * s.u, 0); return e * 2; } });
  tekstRuch("slowa-z-gory", "Słowa spadają z góry", { przyklad: "Wszystko w *jednym* miejscu", ruch: (c, e, x, s) => { const k = E.outBounce(e); c.translate(0, -(1 - k) * 220 * s.u); return e * 3; }, dl: 0.7 });
  tekstRuch("slowa-obrot", "Słowa z obrotem", { przyklad: "Kręci się *wokół* ciebie", ruch: (c, e, x, s) => { const k = E.outBack(e); c.rotate((1 - k) * -0.9); c.scale(k, k); return e * 2.5; } });
  tekstRuch("slowa-flip", "Słowa obracają się jak karty", { przyklad: "Odwróć *swoją* perspektywę", ruch: (c, e) => { const k = E.outBack(e); c.scale(1, Math.max(0.02, Math.abs(Math.cos((1 - k) * PI / 2)))); return e * 3; }, dl: 0.55 });
  tekstRuch("slowa-rozciagniecie", "Słowa rozciągają się", { przyklad: "Więcej *miejsca* na pomysły", ruch: (c, e) => { const k = E.outElastic(e); c.scale(Math.max(0.01, k), 1); return e * 4; }, dl: 0.9 });
  tekstRuch("slowa-zoom-duzy", "Słowa lecą na ekran", { przyklad: "Prosto w *twarz*", ruch: (c, e) => { const k = E.outCubic(e); const sk = lerp(3.2, 1, k); c.scale(sk, sk); return e * 1.6; }, dl: 0.45 });
  tekstRuch("slowa-skos", "Słowa ze skosem", { przyklad: "Pełna *prędkość* naprzód", ruch: (c, e, x, s) => { const k = E.outQuint(e); c.translate((1 - k) * 260 * s.u, 0); c.transform(1, 0, -(1 - k) * 0.8, 1, 0, 0); return e * 2; } });
  tekstRuch("slowa-naprzemian", "Słowa na zmianę z góry i z dołu", { przyklad: "Góra dół *rytm* gra", ruch: (c, e, x, s, ul, i) => { const k = E.outQuint(e); c.translate(0, (1 - k) * (i % 2 ? 1 : -1) * 120 * s.u); return e * 2; } });
  tekstRuch("slowa-od-srodka", "Słowa wybuchają od środka", { przyklad: "Wszystko *zaczyna się* tutaj", krok: 0, dl: 0.7, ruch: (c, e, x, s) => { const k = E.outBack(e); c.translate((s.poz.x - x.x - x.w / 2) * (1 - k), (s.poz.y - x.y) * (1 - k)); c.scale(k, k); return e * 2; } });
  tekstRuch("slowa-pulsuja", "Słowa pulsują w rytmie", { przyklad: "Czujesz *ten* rytm?", czas: 3.5, zawsze: true, ruch: (c, e, x, s, ul, i) => { const k = E.outBack(e); const b = 1 + 0.06 * Math.max(0, Math.sin((s.t * 2.2 - i * 0.18) * PI * 2)); c.scale(k * b, k * b); return e * 3; } });
  tekstRuch("slowa-drzenie", "Drżące słowa", { przyklad: "To *niesamowite*!", czas: 3, ruch: (c, e, x, s, ul, i) => { const k = E.outBackMocno(e); const d = 5 * s.u * (1 - okno(s.t, 1.2, 1)); c.translate((los(i * 7 + Math.floor(s.t * 24)) - 0.5) * d, (los(i * 13 + Math.floor(s.t * 24)) - 0.5) * d); c.scale(k, k); return e * 3; } });
  tekstRuch("slowa-kolejno-akcent", "Słowa rozświetlają się po kolei", { przyklad: "Każde słowo ma znaczenie", czas: 3.5, zawsze: true, kolor: (s, x, i, n) => { const f = okno(s.t, 0.4 + i * 0.28 / s.p.tempo, 0.12); return f > 0 && f < 1 ? s.k.a : f >= 1 ? s.k.t : rgba(s.k.t, 0.35); }, ruch: () => 1 });
  tekstRuch("litery-spadaja", "Litery spadają", { jedn: "znaki", przyklad: "Spadają *gwiazdy*", ruch: (c, e, x, s, ul, i) => { const k = E.outBounce(e); c.translate(0, -(1 - k) * 260 * s.u); return e * 4; }, dl: 0.75 });
  tekstRuch("litery-obrot", "Litery wirują", { jedn: "znaki", przyklad: "Wir *energii*", ruch: (c, e) => { const k = E.outBack(e); c.rotate((1 - k) * PI * 2); c.scale(k, k); return e * 3; }, dl: 0.6 });
  tekstRuch("litery-rozsypane", "Litery zlatują się z rozsypki", { jedn: "znaki", krok: 0.012, dl: 0.9, przyklad: "Układamy *całość*", ruch: (c, e, x, s, ul, i) => { const k = E.outQuint(e); c.translate((los(i * 3.1) - 0.5) * 900 * s.u * (1 - k), (los(i * 5.7) - 0.5) * 1100 * s.u * (1 - k)); c.rotate((los(i * 9.3) - 0.5) * 3 * (1 - k)); return e * 2; } });
  tekstRuch("litery-rozmycie-bok", "Litery wpływają z rozmyciem", { jedn: "znaki", przyklad: "Płynnie i *lekko*", ruch: (c, e, x, s) => { const k = E.outCubic(e); c.translate((1 - k) * 60 * s.u, 0); if (k < 0.98) c.filter = `blur(${((1 - k) * 14 * s.u).toFixed(1)}px)`; return e * 1.5; } });
  tekstRuch("litery-guma", "Gumowe litery", { jedn: "znaki", przyklad: "Boing *boing*!", ruch: (c, e) => { const k = E.outElastic(e); c.scale(1 + (1 - k) * 0.8, Math.max(0.01, k)); return e * 4; }, dl: 0.8 });
  tekstRuch("litery-od-konca", "Litery od końca", { jedn: "znaki", przyklad: "Na *wspak* do celu", kolejnosc: (i, n) => n - 1 - i, ruch: (c, e, x, s) => { const k = E.outBack(e); c.translate(0, (1 - k) * 80 * s.u); return e * 3; } });
  tekstRuch("litery-srodek", "Litery od środka na boki", { jedn: "znaki", przyklad: "SYMETRIA", kolejnosc: (i, n) => Math.abs(i - (n - 1) / 2), krok: 0.05, ruch: (c, e) => { const k = E.outBackMocno(e); c.scale(k, k); return e * 3; } });
  tekstRuch("litery-teczowe", "Tęczowe litery", { jedn: "znaki", czas: 3.5, przyklad: "Kolorowo *wszędzie*", zawsze: true, kolor: (s, x, i) => { const kol = [s.k.g, s.k.a, s.k.t]; return kol[(i + Math.floor(s.t * 6)) % 3]; }, ruch: (c, e) => { const k = E.outBack(e); c.scale(k, k); return e * 3; } });
  tekstRuch("litery-fala-ciagla", "Litery falują cały czas", { jedn: "znaki", czas: 4, przyklad: "Na *fali*", zawsze: true, ruch: (c, e, x, s, ul, i) => { c.translate(0, Math.sin(s.t * 5 - i * 0.45) * 18 * s.u * s.p.rozmiar); return E.outCubic(e) * 2; } });
  tekstRuch("linie-z-boku", "Linie wysuwają się na zmianę z boków", { jedn: "linie", przyklad: "Pierwsza linia z lewej druga z *prawej* strony", dl: 0.6, krok: 0.18, ruch: (c, e, x, s, ul, i) => { const k = E.outQuint(e); c.translate((1 - k) * (i % 2 ? 1 : -1) * s.W * 0.7, 0); return 1; } });
  tekstRuch("linie-zoom", "Linie przybliżają się po kolei", { jedn: "linie", przyklad: "Krok po kroku *bliżej* celu", krok: 0.22, ruch: (c, e) => { const k = E.outBack(e); c.scale(k, k); return e * 2; } });
  tekstRuch("linie-schodki", "Linie po schodkach", { jedn: "linie", przyklad: "Raz dwa trzy *cztery* pięć", krok: 0.2, ruch: (c, e, x, s, ul, i) => { const k = E.outCubic(e); c.translate(0, (1 - k) * 90 * s.u); c.translate((i - (ul.linie.length - 1) / 2) * 40 * s.u * k, 0); return e * 2; } });
  // tekst z dekoracją
  function tekstZDekoracja(id, nazwa, przyklad, deko, o = {}) {
    dodaj({ id, nazwa, kat: "tekst", czas: o.czas || 3.2, pola: ["tekst"], przyklad: { tekst: przyklad },
      rysuj(s) {
        const ul = uloz(s, s.p.tekst, (o.px || 96) * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
        const e = E.outCubic(okno(s.t, 0, 0.6 / s.p.tempo));
        deko(s, ul, ctx, "pod");
        ctx.globalAlpha = s.alfa * clamp(e * 2);
        ul.slowa.forEach((w) => { ctx.save(); cien(s); piszSlowo(s, w, null, ctx, 0, (1 - e) * 30 * s.u); ctx.restore(); });
        ctx.globalAlpha = s.alfa;
        deko(s, ul, ctx, "nad");
      } });
  }
  tekstZDekoracja("tekst-ramka-rysowana", "Ramka rysuje się wokół tekstu", "Ważna *informacja*", (s, ul, ctx, w) => {
    if (w !== "nad") return; const m = 28 * s.u, e = E.inOutCubic(okno(s.t, 0.3 / s.p.tempo, 0.9 / s.p.tempo));
    const x = ul.x - m, y = ul.y - m * 0.6, W = ul.w + m * 2, H = ul.h + m * 1.2;
    ctx.strokeStyle = s.k.a; ctx.lineWidth = 7 * s.u * s.p.rozmiar; ctx.lineJoin = "round";
    sciezkaCzesc(ctx, [[x, y], [x + W, y], [x + W, y + H], [x, y + H], [x, y]], e); ctx.stroke();
  });
  tekstZDekoracja("tekst-w-kolku", "Słowo w zakreślonym kółku", "To *działa* naprawdę", (s, ul, ctx, w) => {
    if (w !== "nad") return; const wyr = ul.slowa.filter((x) => x.wyr); const cel = wyr.length ? wyr : [ul.slowa[ul.slowa.length - 1]]; if (!cel[0]) return;
    const x0 = Math.min(...cel.map((x) => x.x)), x1 = Math.max(...cel.map((x) => x.x + x.w)), cy = cel[0].y, rx = (x1 - x0) / 2 + 30 * s.u, ry = ul.px * 0.75;
    const e = E.inOutCubic(okno(s.t, 0.5 / s.p.tempo, 0.8 / s.p.tempo)); ctx.strokeStyle = s.k.a; ctx.lineWidth = 6 * s.u * s.p.rozmiar; ctx.lineCap = "round";
    ctx.beginPath(); for (let i = 0; i <= 60 * e; i++) { const a = -PI * 0.6 + (i / 60) * PI * 2.15, r = 1 + 0.05 * Math.sin(i * 0.3); const px = (x0 + x1) / 2 + Math.cos(a) * rx * r, py = cy + Math.sin(a) * ry * r; i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } ctx.stroke();
  });
  tekstZDekoracja("tekst-podkreslenie-fala", "Podkreślenie falą", "Nowy *poziom* jakości", (s, ul, ctx, w) => {
    if (w !== "nad") return; const l = ul.linie[ul.linie.length - 1], y = l.y + ul.px * 0.68, e = E.inOutCubic(okno(s.t, 0.35 / s.p.tempo, 0.8 / s.p.tempo));
    ctx.strokeStyle = s.k.a; ctx.lineWidth = 7 * s.u * s.p.rozmiar; ctx.lineCap = "round"; ctx.beginPath();
    for (let x = 0; x <= l.w * e; x += 4 * s.u) { const py = y + Math.sin(x / (22 * s.u)) * 7 * s.u; x ? ctx.lineTo(l.x0 + x, py) : ctx.moveTo(l.x0 + x, py); } ctx.stroke();
  });
  tekstZDekoracja("tekst-przekreslenie", "Przekreślenie i poprawka", "Trudne *łatwe*", (s, ul, ctx, w) => {
    if (w !== "nad") return; const zw = ul.slowa.filter((x) => !x.wyr); if (!zw.length) return;
    const e = E.inOutCubic(okno(s.t, 0.5 / s.p.tempo, 0.35 / s.p.tempo)); ctx.strokeStyle = s.k.g; ctx.lineWidth = 9 * s.u * s.p.rozmiar; ctx.lineCap = "round";
    zw.forEach((x) => { ctx.beginPath(); ctx.moveTo(x.x - 6 * s.u, x.y + 4 * s.u); ctx.lineTo(x.x - 6 * s.u + (x.w + 12 * s.u) * e, x.y - 4 * s.u); ctx.stroke(); });
  });
  tekstZDekoracja("tekst-nawiasy", "Tekst w nawiasach", "Najważniejsze *teraz*", (s, ul, ctx, w) => {
    if (w !== "nad") return; const e = E.outBackMocno(okno(s.t, 0.1 / s.p.tempo, 0.5 / s.p.tempo)), m = 36 * s.u, h = ul.h + m, gr = 8 * s.u * s.p.rozmiar, r = 26 * s.u;
    ctx.strokeStyle = s.k.a; ctx.lineWidth = gr; const cx = ul.x + ul.w / 2, d = (ul.w / 2 + m) * e;
    [[-1, cx - d], [1, cx + d]].forEach(([k, x]) => { ctx.beginPath(); ctx.moveTo(x - k * r, ul.y - m / 2); ctx.lineTo(x, ul.y - m / 2); ctx.lineTo(x, ul.y - m / 2 + h); ctx.lineTo(x - k * r, ul.y - m / 2 + h); ctx.stroke(); });
  });
  tekstZDekoracja("tekst-plama", "Tekst na plamie koloru", "Coś *wyjątkowego*", (s, ul, ctx, w) => {
    if (w !== "pod") return; const e = E.outBackMocno(okno(s.t, 0, 0.55 / s.p.tempo)), cx = ul.x + ul.w / 2, cy = ul.y + ul.h / 2;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); ctx.rotate(-0.04); ctx.fillStyle = s.k.g; ctx.beginPath();
    const rx = ul.w / 2 + 60 * s.u, ry = ul.h / 2 + 50 * s.u; for (let i = 0; i <= 24; i++) { const a = i / 24 * PI * 2, r = 1 + 0.08 * Math.sin(a * 3 + s.t * 2); const px = Math.cos(a) * rx * r, py = Math.sin(a) * ry * r; i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }
    ctx.closePath(); ctx.fill(); ctx.restore();
  });
  tekstZDekoracja("tekst-swiatlo", "Przelatujący błysk po tekście", "Błyszczy *jak nowe*", (s, ul, ctx, w) => {
    if (w !== "nad") return; const e = okno(s.t, 0.6 / s.p.tempo, 0.7 / s.p.tempo); if (e <= 0 || e >= 1) return;
    const x = ul.x - 100 * s.u + (ul.w + 200 * s.u) * E.inOutCubic(e);
    ctx.save(); ctx.globalCompositeOperation = "source-atop"; const g = ctx.createLinearGradient(x - 60 * s.u, 0, x + 60 * s.u, 0);
    g.addColorStop(0, "rgba(255,255,255,0)"); g.addColorStop(0.5, "rgba(255,255,255,0.9)"); g.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = g; ctx.fillRect(ul.x - 100 * s.u, ul.y - 50 * s.u, ul.w + 200 * s.u, ul.h + 100 * s.u); ctx.restore();
  });
  tekstZDekoracja("tekst-kropki", "Tekst z kropkami akcentu", "Proste. Szybkie. *Twoje.*", (s, ul, ctx, w) => {
    if (w !== "nad") return; ul.slowa.forEach((x, i) => { const e = E.outBackMocno(okno(s.t, (0.3 + i * 0.12) / s.p.tempo, 0.35)); if (e <= 0) return;
      ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(x.x + x.w / 2, x.y - ul.px * 0.72, 7 * s.u * s.p.rozmiar * e, 0, PI * 2); ctx.fill(); });
  });
  tekstZDekoracja("tekst-cudzyslow", "Krótki cytat w cudzysłowie", "Najlepsza *decyzja* w tym roku", (s, ul, ctx, w) => {
    if (w !== "nad") return; const e = E.outBackMocno(okno(s.t, 0, 0.5 / s.p.tempo)); ctx.save(); ctx.translate(ul.x - 10 * s.u, ul.y - 30 * s.u); ctx.scale(e, e);
    ctx.font = font(s, 220 * s.u * s.p.rozmiar, 900); ctx.fillStyle = s.k.a; ctx.fillText("„", -70 * s.u, -10 * s.u); ctx.restore();
  }, { px: 84 });
  dodaj({ id: "tekst-licznik-slow", nazwa: "Słowa jak na liczydle", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "WYNIK *GWARANTOWANY*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul), AL = "ABCDEFGHIJKLMNOPRSTUWZ0123456789"; ctx.font = ul.font; cien(s);
      z.forEach((c) => {
        const e = okno(s.t, c.i * 0.04 / s.p.tempo, 0.7 / s.p.tempo); if (e <= 0) return;
        ctx.save(); ctx.beginPath(); ctx.rect(c.x - 4 * s.u, c.y - ul.px * 0.6, c.w + 8 * s.u, ul.px * 1.2); ctx.clip();
        const ile = 5, przes = (1 - E.outCubic(e)) * ile;
        for (let k = 0; k <= ile; k++) { const yy = c.y + (k - przes) * ul.px * 1.1; const ch = k === 0 ? c.c : AL[Math.floor(los(c.i * 11 + k) * AL.length)];
          if (Math.abs(yy - c.y) < ul.px * 1.2) { ctx.fillStyle = c.slowo.wyr ? s.k.a : s.k.t; ctx.fillText(ch, c.x, yy); } }
        ctx.restore();
      });
    } });
  dodaj({ id: "tekst-rozsuniecie", nazwa: "Tekst rozsuwa się na dwie połowy", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "OTWIERAMY *NOWE*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 110 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      const e = E.outQuint(okno(s.t, 0.1, 0.8 / s.p.tempo)), d = (1 - e) * ul.px * 0.9;
      [[-1, ul.y - 40 * s.u, ul.y + ul.h / 2], [1, ul.y + ul.h / 2, ul.y + ul.h + 40 * s.u]].forEach(([k, y0, y1]) => {
        ctx.save(); ctx.beginPath(); ctx.rect(0, y0, s.W, y1 - y0); ctx.clip(); ctx.translate(0, k * d); ctx.globalAlpha = s.alfa * clamp(e * 2);
        ul.slowa.forEach((w) => piszSlowo(s, w)); ctx.restore();
      });
      ctx.fillStyle = s.k.a; const lw = ul.w * E.outQuint(okno(s.t, 0, 0.5 / s.p.tempo)) * (1 - E.inCubic(okno(s.t, 0.5, 0.5)));
      ctx.fillRect(ul.x + (ul.w - lw) / 2, ul.y + ul.h / 2 - 3 * s.u, lw, 6 * s.u);
    } });

  // ---------- belki z nazwiskiem (v17) ----------
  /* Wspólny układ belki: prostokąt (x0, y0, W, h) przy pozycji, teksty po lewej (albo po prawej przy pozycji z prawej). */
  function belkaUklad(s, px, padX, wysK) {
    const m = belkaTeksty(s, 0, 0, px), pad = (padX || 28) * s.u, h = px * (wysK || (s.p.tekst2 ? 2.1 : 1.5));
    const W = m.w + pad * 2, x0 = prawa(s) ? s.poz.x - W : s.poz.x - (s.poz.align === "center" ? W / 2 : 0), y0 = s.poz.y - h / 2;
    return { m, pad, h, W, x0, y0, px };
  }
  function belkaTekst(s, b, e1, e2, o = {}) {
    const ctx = s.ctx, p = prawa(s), ty = s.p.tekst2 ? b.y0 + b.h * 0.37 : b.y0 + b.h / 2;
    const x1 = p ? b.x0 + b.W - b.pad - b.m.w1 : b.x0 + b.pad + (o.dx || 0), x2 = p ? b.x0 + b.W - b.pad - b.m.w2 : b.x0 + b.pad + (o.dx || 0);
    ctx.save(); if (o.klip !== false) { ctx.beginPath(); ctx.rect(b.x0 - 4 * s.u, b.y0, b.W + 8 * s.u + (o.dx || 0), b.h); ctx.clip(); }
    ctx.font = font(s, b.px, s.p.waga); ctx.fillStyle = o.k1 || s.k.t; ctx.globalAlpha = s.alfa * clamp(e1 * 2); ctx.fillText(tekstP(s, s.p.tekst), x1, ty + (1 - e1) * b.h * (o.ruch == null ? 0.6 : o.ruch));
    if (s.p.tekst2) { ctx.font = font(s, b.px * 0.52, 500); ctx.fillStyle = o.k2 || rgba(s.k.t, 0.82); ctx.globalAlpha = s.alfa * clamp(e2 * 2); ctx.fillText(s.p.tekst2, x2, b.y0 + b.h * 0.73 + (1 - e2) * b.h * (o.ruch == null ? 0.6 : o.ruch)); }
    ctx.restore(); ctx.globalAlpha = s.alfa;
  }
  function belkaN(id, nazwa, przyklad, fn, o = {}) {
    dodaj({ id, nazwa, kat: "belki", czas: o.czas || 4, pola: o.pola || ["tekst", "tekst2"], dom: Object.assign({ pozycja: "lewy-dol" }, o.dom || {}), przyklad, rysuj: fn });
  }
  const T = (s, od, dl) => okno(s.t, od / s.p.tempo, dl / s.p.tempo);
  belkaN("belka-skos", "Belka ukośna", { tekst: "Kasia Wiśniewska", tekst2: "Fotografka ślubna" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 56 * s.u * s.p.rozmiar, 40), a = E.outQuint(T(s, 0, 0.6)), sk = b.h * 0.35;
    ctx.save(); cien(s); ctx.fillStyle = s.k.g; ctx.beginPath(); const w = (b.W + sk) * a;
    ctx.moveTo(b.x0 + sk, b.y0); ctx.lineTo(b.x0 + sk + w, b.y0); ctx.lineTo(b.x0 + w, b.y0 + b.h); ctx.lineTo(b.x0, b.y0 + b.h); ctx.closePath(); ctx.fill(); ctx.restore();
    belkaTekst(s, b, E.outCubic(T(s, 0.25, 0.5)), E.outCubic(T(s, 0.4, 0.5)), { dx: sk * 0.5, k1: kontrast(s.k.g), k2: rgba(kontrast(s.k.g), 0.8) });
  });
  belkaN("belka-dwa-paski", "Dwa paski z przeciwnych stron", { tekst: "Piotr Zieliński", tekst2: "Trener personalny" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 56 * s.u * s.p.rozmiar), a = E.outQuint(T(s, 0, 0.55)), c = E.outQuint(T(s, 0.12, 0.55)), h1 = b.h * 0.58;
    ctx.fillStyle = s.k.g; ctx.fillRect(b.x0 - (1 - a) * s.W * 0.5, b.y0, b.W, h1);
    ctx.fillStyle = s.k.tl; ctx.fillRect(b.x0 + (1 - c) * s.W * 0.5, b.y0 + h1, b.W * 0.85, b.h - h1);
    const p = prawa(s); ctx.save(); ctx.globalAlpha = s.alfa * clamp(a * 2); ctx.font = font(s, b.px, s.p.waga); ctx.fillStyle = kontrast(s.k.g); ctx.fillText(tekstP(s, s.p.tekst), p ? b.x0 + b.W - b.pad - b.m.w1 : b.x0 + b.pad, b.y0 + h1 / 2);
    if (s.p.tekst2) { ctx.globalAlpha = s.alfa * clamp(c * 2); ctx.font = font(s, b.px * 0.48, 600); ctx.fillStyle = s.k.t; ctx.fillText(s.p.tekst2, p ? b.x0 + b.W * 0.85 - b.pad - b.m.w2 * 0.92 : b.x0 + b.pad, b.y0 + h1 + (b.h - h1) / 2); } ctx.restore();
  }, { });
  belkaN("belka-live", "Belka z kropką na żywo", { tekst: "NA ŻYWO", tekst2: "Gala Biznesu 2026" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 50 * s.u * s.p.rozmiar, 30, s.p.tekst2 ? 1.6 : 1.4), a = E.outBackMocno(T(s, 0, 0.45)), r = b.px * 0.22;
    const W1 = b.m.w1 + b.pad * 2 + r * 3; ctx.save(); ctx.translate(b.x0, b.y0 + b.h / 2); ctx.scale(a, a); cien(s);
    ctx.fillStyle = "#E11D48"; zaokr(ctx, 0, -b.px * 0.7, W1, b.px * 1.4, b.px * 0.7); ctx.fill(); bezCienia(ctx);
    ctx.fillStyle = "#FFFFFF"; ctx.globalAlpha = s.alfa * (0.55 + 0.45 * Math.round((Math.sin(s.t * 6) + 1) / 2)); ctx.beginPath(); ctx.arc(b.pad + r, 0, r, 0, PI * 2); ctx.fill(); ctx.globalAlpha = s.alfa;
    ctx.font = font(s, b.px, 800); ctx.fillText(tekstP(s, s.p.tekst), b.pad + r * 3, 0);
    if (s.p.tekst2) { const e2 = E.outCubic(T(s, 0.3, 0.5)); ctx.globalAlpha = s.alfa * e2; ctx.font = font(s, b.px * 0.8, 600); ctx.fillStyle = s.k.t; ctx.fillText(s.p.tekst2, W1 + 24 * s.u - (1 - e2) * 30 * s.u, 0); }
    ctx.restore();
  }, { pola: ["tekst", "tekst2"] });
  belkaN("belka-pionowa-linia", "Pionowa linia i tekst", { tekst: "Ola Lewandowska", tekst2: "Architektka wnętrz" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 60 * s.u * s.p.rozmiar, 34), a = E.outQuint(T(s, 0, 0.5)), p = prawa(s);
    ctx.fillStyle = s.k.a; const lx = p ? b.x0 + b.W : b.x0; ctx.fillRect(lx - 4 * s.u, b.y0 + b.h / 2 - b.h / 2 * a, 8 * s.u, b.h * a);
    belkaTekst(s, b, E.outCubic(T(s, 0.25, 0.6)), E.outCubic(T(s, 0.4, 0.6)), { ruch: 0 , klip: false });
    ctx.save(); ctx.globalAlpha = 1; ctx.restore();
  });
  belkaN("belka-szklo", "Belka jak matowe szkło", { tekst: "Tomasz Kamiński", tekst2: "Założyciel, Studio Kadr" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 54 * s.u * s.p.rozmiar, 34), a = E.outBack(T(s, 0, 0.55));
    ctx.save(); ctx.translate(b.x0 + b.W / 2, b.y0 + b.h / 2); ctx.scale(lerp(0.9, 1, a), lerp(0.9, 1, a)); ctx.globalAlpha = s.alfa * clamp(a * 1.5);
    ctx.fillStyle = "rgba(255,255,255,0.16)"; zaokr(ctx, -b.W / 2, -b.h / 2, b.W, b.h, 22 * s.u); ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.45)"; ctx.lineWidth = 2 * s.u; ctx.stroke(); ctx.restore();
    belkaTekst(s, b, E.outCubic(T(s, 0.2, 0.5)), E.outCubic(T(s, 0.35, 0.5)), { ruch: 0.3 });
  });
  belkaN("belka-podkreslenie", "Nazwisko z podkreśleniem", { tekst: "Michał Wójcik", tekst2: "Szef kuchni" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 62 * s.u * s.p.rozmiar, 0), a = E.inOutCubic(T(s, 0.15, 0.6)), p = prawa(s);
    belkaTekst(s, b, E.outCubic(T(s, 0, 0.5)), E.outCubic(T(s, 0.35, 0.5)), { ruch: 0.4 });
    ctx.fillStyle = s.k.a; const y = b.y0 + b.h * (s.p.tekst2 ? 0.56 : 0.82), w = b.m.w1 * a; ctx.fillRect(p ? b.x0 + b.W - w : b.x0, y, w, 6 * s.u * s.p.rozmiar);
  });
  belkaN("belka-ramka", "Belka w ramce", { tekst: "Agnieszka Dąbrowska", tekst2: "Psycholog" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 54 * s.u * s.p.rozmiar, 30), e = E.inOutCubic(T(s, 0, 0.8));
    ctx.strokeStyle = s.k.g; ctx.lineWidth = 5 * s.u; sciezkaCzesc(ctx, [[b.x0, b.y0], [b.x0 + b.W, b.y0], [b.x0 + b.W, b.y0 + b.h], [b.x0, b.y0 + b.h], [b.x0, b.y0]], e); ctx.stroke();
    belkaTekst(s, b, E.outCubic(T(s, 0.3, 0.5)), E.outCubic(T(s, 0.45, 0.5)));
  });
  belkaN("belka-od-srodka", "Belka rozsuwa się od środka", { tekst: "Jakub Mazur", tekst2: "Reżyser" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 56 * s.u * s.p.rozmiar), a = E.outQuint(T(s, 0, 0.6));
    ctx.save(); cien(s); ctx.fillStyle = s.k.tl; ctx.fillRect(b.x0 + b.W / 2 * (1 - a), b.y0, b.W * a, b.h); ctx.restore();
    ctx.fillStyle = s.k.g; ctx.fillRect(b.x0 + b.W / 2 * (1 - a), b.y0 + b.h - 6 * s.u, b.W * a, 6 * s.u);
    belkaTekst(s, b, E.outCubic(T(s, 0.3, 0.5)), E.outCubic(T(s, 0.42, 0.5)), { ruch: 0 });
  });
  belkaN("belka-social-handle", "Imię i nazwa konta", { tekst: "Zuza Gotuje", tekst2: "@zuzagotuje" }, (s) => {
    const ctx = s.ctx, px = 52 * s.u * s.p.rozmiar, b = belkaUklad(s, px, 28, 1.5), r = b.h * 0.42, a = E.outBackMocno(T(s, 0, 0.45)), e = E.outQuint(T(s, 0.15, 0.6));
    const W = b.W + r * 2 + 20 * s.u, x0 = prawa(s) ? s.poz.x - W : s.poz.x;
    ctx.save(); cien(s); ctx.fillStyle = s.k.tl; zaokr(ctx, x0, b.y0, (W) * e, b.h, b.h / 2); ctx.fill(); ctx.restore();
    ctx.save(); ctx.translate(x0 + b.h / 2, b.y0 + b.h / 2); ctx.scale(a, a); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill();
    ctx.font = font(s, r * 1.05, 800); ctx.fillStyle = kontrast(s.k.g); const ini = String(s.p.tekst || "?").trim().split(/\s+/).map((x) => x[0]).join("").slice(0, 2).toUpperCase(); const iw = ctx.measureText(ini).width; ctx.fillText(ini, -iw / 2, 0); ctx.restore();
    const bb = Object.assign({}, b, { x0: x0 + r * 2 + 8 * s.u, W: b.W }); belkaTekst(s, bb, E.outCubic(T(s, 0.3, 0.5)), E.outCubic(T(s, 0.42, 0.5)), { k2: s.k.a });
  });
  belkaN("belka-news", "Pasek informacyjny", { tekst: "PILNE", tekst2: "Rusza nabór do programu dla młodych twórców" }, (s) => {
    const ctx = s.ctx, px = 44 * s.u * s.p.rozmiar, h = px * 1.8, y0 = s.poz.y - h / 2, a = E.outQuint(T(s, 0, 0.5)), c = E.outQuint(T(s, 0.2, 0.6));
    ctx.font = font(s, px, 900); const w1 = ctx.measureText(tekstP(s, s.p.tekst)).width + 50 * s.u;
    ctx.fillStyle = rgba(s.k.tl, 0.95); ctx.fillRect(0, y0, s.W * c, h);
    ctx.fillStyle = "#DC2626"; ctx.fillRect(0, y0, w1 * a, h);
    ctx.save(); ctx.beginPath(); ctx.rect(0, y0, s.W, h); ctx.clip(); ctx.fillStyle = "#FFFFFF"; ctx.fillText(tekstP(s, s.p.tekst), 25 * s.u - (1 - a) * w1, y0 + h / 2);
    ctx.font = font(s, px * 0.85, 600); ctx.fillStyle = s.k.t; const tw = ctx.measureText(s.p.tekst2 || "").width, dost = s.W - w1 - 40 * s.u;
    const przes = tw > dost ? -Math.max(0, s.t - 1.2) * 120 * s.u : 0; ctx.beginPath(); ctx.rect(w1, y0, s.W - w1, h); ctx.clip();
    ctx.globalAlpha = s.alfa * clamp(c * 2); ctx.fillText(s.p.tekst2 || "", w1 + 24 * s.u + przes + (1 - c) * 60 * s.u, y0 + h / 2); ctx.restore();
  }, { dom: { pozycja: "dol" }, czas: 5 });
  belkaN("belka-podcast", "Belka podcastu z mikrofonem", { tekst: "Rozmowy o pieniądzach", tekst2: "odc. 24 · gość: Ewa Nowicka" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 50 * s.u * s.p.rozmiar, 30, 2.2), a = E.outBackMocno(T(s, 0, 0.45)), e = E.outQuint(T(s, 0.1, 0.6)), r = b.h * 0.44;
    const x0 = prawa(s) ? s.poz.x - b.W - b.h : s.poz.x;
    ctx.save(); cien(s); ctx.fillStyle = s.k.tl; zaokr(ctx, x0, b.y0, (b.W + b.h) * e, b.h, 18 * s.u); ctx.fill(); ctx.restore();
    ctx.save(); ctx.translate(x0 + b.h / 2, b.y0 + b.h / 2); ctx.scale(a, a); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill();
    ctx.fillStyle = kontrast(s.k.g); zaokr(ctx, -r * 0.2, -r * 0.55, r * 0.4, r * 0.7, r * 0.2); ctx.fill(); ctx.strokeStyle = kontrast(s.k.g); ctx.lineWidth = r * 0.09;
    ctx.beginPath(); ctx.arc(0, -r * 0.1, r * 0.33, 0, PI); ctx.stroke(); ctx.beginPath(); ctx.moveTo(0, r * 0.23); ctx.lineTo(0, r * 0.5); ctx.stroke(); ctx.restore();
    // fala dźwięku
    ctx.fillStyle = s.k.a; for (let i = 0; i < 5; i++) { const hh = (0.3 + 0.7 * Math.abs(Math.sin(s.t * 7 + i * 1.3))) * b.h * 0.25 * e; ctx.fillRect(x0 + b.h + b.W - 70 * s.u + i * 11 * s.u, b.y0 + b.h * 0.3 - hh / 2, 6 * s.u, hh); }
    belkaTekst(s, Object.assign({}, b, { x0: x0 + b.h - 10 * s.u }), E.outCubic(T(s, 0.3, 0.5)), E.outCubic(T(s, 0.45, 0.5)));
  });
  belkaN("belka-lokalizacja", "Lokalizacja z pinezką", { tekst: "Zakopane", tekst2: "Tatry, Polska" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 60 * s.u * s.p.rozmiar, 0), a = E.outBounce(T(s, 0, 0.7)), r = b.px * 0.42, px0 = prawa(s) ? b.x0 + b.W + r * 1.6 : b.x0;
    ctx.save(); ctx.translate(px0, b.y0 + b.h / 2 - (1 - a) * 200 * s.u); cien(s); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, -r * 0.4, r, PI * 0.85, PI * 2.15); ctx.lineTo(0, r * 1.3); ctx.closePath(); ctx.fill();
    bezCienia(ctx); ctx.fillStyle = kontrast(s.k.g); ctx.beginPath(); ctx.arc(0, -r * 0.4, r * 0.4, 0, PI * 2); ctx.fill(); ctx.restore();
    belkaTekst(s, Object.assign({}, b, { x0: b.x0 + (prawa(s) ? 0 : r * 1.6) }), E.outCubic(T(s, 0.35, 0.5)), E.outCubic(T(s, 0.5, 0.5)));
  });
  belkaN("belka-etykieta-nad", "Etykieta nad nazwiskiem", { tekst: "Marta Kowalczyk", tekst2: "GOŚĆ ODCINKA" }, (s) => {
    const ctx = s.ctx, px = 62 * s.u * s.p.rozmiar, p = prawa(s); ctx.font = font(s, px, s.p.waga); const w1 = ctx.measureText(tekstP(s, s.p.tekst)).width;
    ctx.font = font(s, px * 0.42, 800); const w2 = ctx.measureText(s.p.tekst2 || "").width + 30 * s.u, h2 = px * 0.75;
    const x = p ? s.poz.x - w1 : s.poz.x, y = s.poz.y, a = E.outBackMocno(T(s, 0, 0.4)), e = E.outQuint(T(s, 0.2, 0.6));
    ctx.save(); ctx.translate(p ? s.poz.x - w2 : x, y - px * 1.05); ctx.scale(a, a); ctx.fillStyle = s.k.a; zaokr(ctx, 0, -h2 / 2, w2, h2, 6 * s.u); ctx.fill();
    ctx.fillStyle = kontrast(s.k.a); ctx.fillText(s.p.tekst2 || "", 15 * s.u, 0); ctx.restore();
    ctx.save(); ctx.beginPath(); ctx.rect(x - 10 * s.u, y - px * 0.7, w1 + 20 * s.u, px * 1.4); ctx.clip(); cien(s); ctx.font = font(s, px, s.p.waga); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), x, y + (1 - e) * px * 1.3); ctx.restore();
  });
  belkaN("belka-numer", "Belka z numerem", { tekst: "Jak zacząć oszczędzać", tekst2: "01" }, (s) => {
    const ctx = s.ctx, px = 54 * s.u * s.p.rozmiar, h = px * 1.7, p = prawa(s); ctx.font = font(s, px, s.p.waga); const w = ctx.measureText(tekstP(s, s.p.tekst)).width + 60 * s.u;
    const kw = h, x0 = p ? s.poz.x - w - kw : s.poz.x, y0 = s.poz.y - h / 2, a = E.outBackMocno(T(s, 0, 0.45)), e = E.outQuint(T(s, 0.2, 0.6));
    ctx.save(); cien(s); ctx.fillStyle = s.k.tl; ctx.fillRect(x0 + kw, y0, w * e, h); ctx.restore();
    ctx.save(); ctx.translate(x0 + kw / 2, y0 + h / 2); ctx.scale(a, a); ctx.fillStyle = s.k.g; ctx.fillRect(-kw / 2, -h / 2, kw, h);
    ctx.font = font(s, px * 1.1, 900); ctx.fillStyle = kontrast(s.k.g); const nw = ctx.measureText(s.p.tekst2 || "").width; ctx.fillText(s.p.tekst2 || "", -nw / 2, 0); ctx.restore();
    ctx.save(); ctx.beginPath(); ctx.rect(x0 + kw, y0, w, h); ctx.clip(); ctx.font = font(s, px, s.p.waga); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), x0 + kw + 30 * s.u - (1 - e) * w, y0 + h / 2); ctx.restore();
  });
  belkaN("belka-gradient", "Belka z przenikaniem koloru", { tekst: "Natalia Wrona", tekst2: "Wokalistka" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 58 * s.u * s.p.rozmiar, 34), a = E.outQuint(T(s, 0, 0.7)), p = prawa(s);
    const g = ctx.createLinearGradient(p ? b.x0 + b.W : b.x0, 0, p ? b.x0 - b.W * 0.4 : b.x0 + b.W * 1.4, 0); g.addColorStop(0, rgba(s.k.g, 0.95)); g.addColorStop(1, rgba(s.k.g, 0));
    ctx.fillStyle = g; ctx.fillRect(p ? b.x0 + b.W - (b.W * 1.4) * a : b.x0, b.y0, b.W * 1.4 * a, b.h);
    belkaTekst(s, b, E.outCubic(T(s, 0.2, 0.5)), E.outCubic(T(s, 0.35, 0.5)), { k1: kontrast(s.k.g), k2: rgba(kontrast(s.k.g), 0.8) });
  });
  belkaN("belka-kafelki", "Nazwisko i stanowisko na kafelkach", { tekst: "Adam Krawczyk", tekst2: "CEO" }, (s) => {
    const ctx = s.ctx, px = 54 * s.u * s.p.rozmiar, p = prawa(s), h = px * 1.6; ctx.font = font(s, px, s.p.waga); const w1 = ctx.measureText(tekstP(s, s.p.tekst)).width + 50 * s.u;
    ctx.font = font(s, px * 0.62, 800); const w2 = s.p.tekst2 ? ctx.measureText(s.p.tekst2).width + 40 * s.u : 0;
    const x0 = p ? s.poz.x - w1 - w2 - 10 * s.u : s.poz.x, y0 = s.poz.y - h / 2, a = E.outBackMocno(T(s, 0, 0.45)), c = E.outBackMocno(T(s, 0.15, 0.45));
    const kaf = (x, w, kol, tk, t, f, e) => { ctx.save(); ctx.translate(x + w / 2, y0 + h / 2); ctx.scale(1, e); cien(s); ctx.fillStyle = kol; zaokr(ctx, -w / 2, -h / 2, w, h, 10 * s.u); ctx.fill(); bezCienia(ctx); ctx.font = f; ctx.fillStyle = tk; const tw = ctx.measureText(t).width; ctx.fillText(t, -tw / 2, 0); ctx.restore(); };
    kaf(x0, w1, s.k.tl, s.k.t, tekstP(s, s.p.tekst), font(s, px, s.p.waga), a);
    if (s.p.tekst2) kaf(x0 + w1 + 10 * s.u, w2, s.k.a, kontrast(s.k.a), s.p.tekst2, font(s, px * 0.62, 800), c);
  });
  belkaN("belka-maszyna", "Belka pisana na klawiaturze", { tekst: "Karol Szymański", tekst2: "programista" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 52 * s.u * s.p.rozmiar, 30), e = E.outQuint(T(s, 0, 0.45)), p = prawa(s);
    ctx.fillStyle = rgba(s.k.tl, 0.9); ctx.fillRect(b.x0, b.y0, b.W * e, b.h);
    const t1 = tekstP(s, s.p.tekst), t2 = s.p.tekst2 || "", n1 = Math.floor(clamp((s.t - 0.4 / s.p.tempo) / (t1.length * 0.05 / s.p.tempo)) * t1.length), n2 = Math.floor(clamp((s.t - 0.5 / s.p.tempo - t1.length * 0.05 / s.p.tempo) / (Math.max(1, t2.length) * 0.04 / s.p.tempo)) * t2.length);
    const ty = s.p.tekst2 ? b.y0 + b.h * 0.37 : b.y0 + b.h / 2;
    ctx.font = font(s, b.px, s.p.waga); ctx.fillStyle = s.k.t; ctx.fillText(t1.slice(0, n1), b.x0 + b.pad, ty);
    ctx.font = font(s, b.px * 0.52, 500); ctx.fillStyle = s.k.a; ctx.fillText(t2.slice(0, n2), b.x0 + b.pad, b.y0 + b.h * 0.73);
    if (Math.floor(s.t * 2.5) % 2 === 0) { ctx.font = font(s, n2 > 0 || n1 >= t1.length ? b.px * 0.52 : b.px, 500); const tt = n2 > 0 || n1 >= t1.length ? t2.slice(0, n2) : t1.slice(0, n1); const xw = ctx.measureText(tt).width; ctx.fillStyle = s.k.a; ctx.fillRect(b.x0 + b.pad + xw + 4 * s.u, (n2 > 0 || n1 >= t1.length ? b.y0 + b.h * 0.73 : ty) - b.px * 0.3, 4 * s.u, b.px * 0.6); }
    void p;
  });
  belkaN("belka-minimal-kreska", "Mała kreska i tekst", { tekst: "Joanna Pawlak", tekst2: "Projektantka mody" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 50 * s.u * s.p.rozmiar, 0), a = E.inOutCubic(T(s, 0, 0.5)), p = prawa(s);
    ctx.fillStyle = s.k.a; const kw = 60 * s.u * a; ctx.fillRect(p ? b.x0 + b.W - kw : b.x0, b.y0 - 14 * s.u, kw, 5 * s.u);
    belkaTekst(s, b, E.outCubic(T(s, 0.25, 0.6)), E.outCubic(T(s, 0.4, 0.6)), { ruch: 0.5 });
  });

  // ---------- grafiki do rolek (v17) ----------
  function ikonaN(id, nazwa, fn, o = {}) {
    dodaj({ id, nazwa, kat: "rolki", czas: o.czas || 3, pola: o.pola || ["tekst"], dom: Object.assign({ pozycja: "srodek" }, o.dom || {}), przyklad: o.przyklad || {}, rysuj: fn });
  }
  function podpis(s, y, e, px, pole) {
    const tx = s.p[pole || "tekst"]; if (!tx) return; const ctx = s.ctx, u = uloz(s, tx, (px || 64) * s.u * s.p.rozmiar, { y, gora: true, align: "center", x: s.poz.x });
    ctx.save(); ctx.font = u.font; ctx.globalAlpha = s.alfa * clamp(e * 2); cien(s); u.slowa.forEach((w) => piszSlowo(s, w, null, ctx, 0, (1 - e) * 30 * s.u)); ctx.restore();
  }
  const R0 = (s, k) => (k || 120) * s.u * s.p.rozmiar;
  ikonaN("kciuk", "Kciuk w górę", (s) => {
    const ctx = s.ctx, r = R0(s, 130), a = E.outBackMocno(T(s, 0, 0.5)), ob = Math.sin(clamp(s.t * 3) * PI) * 0.25;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.rotate(-ob); cien(s); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); bezCienia(ctx);
    ctx.fillStyle = kontrast(s.k.g); zaokr(ctx, -r * 0.55, -r * 0.05, r * 0.25, r * 0.6, r * 0.06); ctx.fill(); zaokr(ctx, -r * 0.25, -r * 0.1, r * 0.75, r * 0.65, r * 0.15); ctx.fill();
    ctx.beginPath(); ctx.moveTo(-r * 0.22, -r * 0.05); ctx.lineTo(r * 0.02, -r * 0.6); ctx.quadraticCurveTo(r * 0.2, -r * 0.62, r * 0.17, -r * 0.35); ctx.lineTo(r * 0.12, -r * 0.08); ctx.closePath(); ctx.fill(); ctx.restore();
    podpis(s, s.poz.y + r * 1.3, E.outCubic(T(s, 0.35, 0.5)));
  }, { przyklad: { tekst: "Dobra robota!" } });
  ikonaN("wykrzyknik", "Wykrzyknik uwaga", (s) => {
    const ctx = s.ctx, r = R0(s, 130), a = E.outBackMocno(T(s, 0, 0.45)), dr = Math.sin(s.t * 30) * 0.05 * (1 - clamp(s.t - 0.4));
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.rotate(dr); cien(s); ctx.fillStyle = "#FACC15"; ctx.beginPath(); ctx.moveTo(0, -r); ctx.lineTo(r * 1.05, r * 0.75); ctx.lineTo(-r * 1.05, r * 0.75); ctx.closePath(); ctx.lineJoin = "round"; ctx.lineWidth = r * 0.18; ctx.strokeStyle = "#FACC15"; ctx.stroke(); ctx.fill(); bezCienia(ctx);
    ctx.fillStyle = "#111"; zaokr(ctx, -r * 0.09, -r * 0.45, r * 0.18, r * 0.75, r * 0.08); ctx.fill(); ctx.beginPath(); ctx.arc(0, r * 0.5, r * 0.11, 0, PI * 2); ctx.fill(); ctx.restore();
    podpis(s, s.poz.y + r * 1.25, E.outCubic(T(s, 0.3, 0.5)));
  }, { przyklad: { tekst: "Uważaj na *to*" } });
  ikonaN("zarowka", "Żarówka pomysł", (s) => {
    const ctx = s.ctx, r = R0(s, 110), a = E.outBackMocno(T(s, 0, 0.5)), sw = okno(s.t, 0.45 / s.p.tempo, 0.2);
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a);
    if (sw > 0) { ctx.strokeStyle = rgba(s.k.a, sw); ctx.lineWidth = r * 0.08; ctx.lineCap = "round"; for (let i = 0; i < 8; i++) { const an = -PI / 2 + (i - 3.5) * 0.42; ctx.beginPath(); ctx.moveTo(Math.cos(an) * r * 1.25, Math.sin(an) * r * 1.25 - r * 0.2); ctx.lineTo(Math.cos(an) * r * (1.25 + 0.35 * sw), Math.sin(an) * r * (1.25 + 0.35 * sw) - r * 0.2); ctx.stroke(); } }
    cien(s); ctx.fillStyle = sw > 0 ? s.k.a : "#9CA3AF"; ctx.beginPath(); ctx.arc(0, -r * 0.2, r * 0.8, PI * 0.8, PI * 2.2); ctx.lineTo(r * 0.35, r * 0.75); ctx.lineTo(-r * 0.35, r * 0.75); ctx.closePath(); ctx.fill(); bezCienia(ctx);
    ctx.fillStyle = "#6B7280"; zaokr(ctx, -r * 0.38, r * 0.78, r * 0.76, r * 0.18, r * 0.06); ctx.fill(); zaokr(ctx, -r * 0.3, r * 1.0, r * 0.6, r * 0.16, r * 0.06); ctx.fill(); ctx.restore();
    podpis(s, s.poz.y + r * 1.6, E.outCubic(T(s, 0.6, 0.5)));
  }, { przyklad: { tekst: "Mam *pomysł*" } });
  ikonaN("dzwonek", "Dzwonek powiadomień", (s) => {
    const ctx = s.ctx, r = R0(s, 110), a = E.outBackMocno(T(s, 0, 0.45)), dz = Math.sin(s.t * 18) * 0.35 * Math.max(0, 1 - Math.abs(s.t - 0.9) * 2);
    ctx.save(); ctx.translate(s.poz.x, s.poz.y - r * 0.6); ctx.scale(a, a); ctx.rotate(dz); cien(s); ctx.fillStyle = s.k.a; ctx.beginPath();
    ctx.moveTo(-r * 0.75, r * 1.2); ctx.quadraticCurveTo(-r * 0.6, r * 0.9, -r * 0.6, r * 0.4); ctx.quadraticCurveTo(-r * 0.6, -r * 0.25, 0, -r * 0.25); ctx.quadraticCurveTo(r * 0.6, -r * 0.25, r * 0.6, r * 0.4); ctx.quadraticCurveTo(r * 0.6, r * 0.9, r * 0.75, r * 1.2); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.arc(0, r * 1.32, r * 0.17, 0, PI * 2); ctx.fill(); ctx.beginPath(); ctx.arc(0, -r * 0.32, r * 0.1, 0, PI * 2); ctx.fill(); bezCienia(ctx); ctx.restore();
    const b = E.outBackMocno(T(s, 0.7, 0.4)); if (b > 0) { ctx.save(); ctx.translate(s.poz.x + r * 0.55, s.poz.y - r * 0.85); ctx.scale(b, b); ctx.fillStyle = "#EF4444"; ctx.beginPath(); ctx.arc(0, 0, r * 0.3, 0, PI * 2); ctx.fill(); ctx.font = font(s, r * 0.36, 800); ctx.fillStyle = "#fff"; const w = ctx.measureText("1").width; ctx.fillText("1", -w / 2, 0); ctx.restore(); }
    podpis(s, s.poz.y + r * 1.25, E.outCubic(T(s, 0.5, 0.5)));
  }, { przyklad: { tekst: "Włącz *powiadomienia*" } });
  ikonaN("koszyk", "Koszyk zakupowy", (s) => {
    const ctx = s.ctx, r = R0(s, 110), e = E.outQuint(T(s, 0, 0.7)), x = lerp(-s.W * 0.2, s.poz.x, e);
    ctx.save(); ctx.translate(x, s.poz.y); ctx.rotate((1 - e) * -0.15); cien(s); ctx.strokeStyle = s.k.g; ctx.lineWidth = r * 0.13; ctx.lineJoin = "round"; ctx.lineCap = "round";
    ctx.beginPath(); ctx.moveTo(-r * 1.1, -r * 0.7); ctx.lineTo(-r * 0.8, -r * 0.7); ctx.lineTo(-r * 0.5, r * 0.4); ctx.lineTo(r * 0.8, r * 0.4); ctx.lineTo(r * 1.0, -r * 0.4); ctx.lineTo(-r * 0.7, -r * 0.4); ctx.stroke();
    ctx.fillStyle = s.k.g; [-0.35, 0.65].forEach((k) => { ctx.beginPath(); ctx.arc(r * k, r * 0.68, r * 0.14, 0, PI * 2); ctx.fill(); });
    const b = E.outBounce(T(s, 0.55, 0.6)); if (b > 0) { ctx.fillStyle = s.k.a; zaokr(ctx, -r * 0.3, -r * 0.4 - (1 - b) * r * 1.5 - r * 0.45, r * 0.6, r * 0.55, r * 0.08); ctx.fill(); }
    ctx.restore(); podpis(s, s.poz.y + r * 1.15, E.outCubic(T(s, 0.7, 0.5)));
  }, { przyklad: { tekst: "Dodane do *koszyka*" } });
  ikonaN("odznaka-procent", "Gwiazda promocji -50%", (s) => {
    const ctx = s.ctx, r = R0(s, 160), a = E.outBackMocno(T(s, 0, 0.5));
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.rotate(s.t * 0.4 - 0.2); cien(s); ctx.fillStyle = s.k.g; gwiazda(ctx, 0, 0, 16, r, r * 0.84); ctx.fill(); bezCienia(ctx); ctx.rotate(-(s.t * 0.4 - 0.2) - 0.12);
    const t = tekstP(s, s.p.tekst), px = dopasuj(s, t, r * 0.7, r * 1.5, 900); ctx.font = font(s, px, 900); ctx.fillStyle = kontrast(s.k.g); const w = ctx.measureText(t).width; ctx.fillText(t, -w / 2, -px * 0.1);
    if (s.p.tekst2) { ctx.font = font(s, px * 0.35, 700); const w2 = ctx.measureText(s.p.tekst2).width; ctx.fillText(s.p.tekst2, -w2 / 2, px * 0.55); } ctx.restore();
  }, { pola: ["tekst", "tekst2"], przyklad: { tekst: "-50%", tekst2: "tylko dziś" } });
  ikonaN("stara-nowa-cena", "Stara cena przekreślona, nowa wskakuje", (s) => {
    const ctx = s.ctx, px = 110 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y;
    const a = E.outCubic(T(s, 0, 0.4)); ctx.font = font(s, px * 0.6, 700); const t1 = s.p.tekst || "", w1 = ctx.measureText(t1).width;
    ctx.globalAlpha = s.alfa * a; ctx.fillStyle = rgba(s.k.t, 0.7); ctx.fillText(t1, cx - w1 / 2, cy - px * 0.6); ctx.globalAlpha = s.alfa;
    const k = E.inOutCubic(T(s, 0.45, 0.35)); ctx.strokeStyle = "#EF4444"; ctx.lineWidth = 8 * s.u; ctx.beginPath(); ctx.moveTo(cx - w1 / 2 - 10 * s.u, cy - px * 0.55); ctx.lineTo(cx - w1 / 2 - 10 * s.u + (w1 + 20 * s.u) * k, cy - px * 0.65); ctx.stroke();
    const b = E.outBackMocno(T(s, 0.85, 0.45)); if (b > 0) { ctx.save(); ctx.translate(cx, cy + px * 0.35); ctx.scale(b, b); cien(s); ctx.font = font(s, px, 900); const t2 = s.p.tekst2 || ""; const w2 = ctx.measureText(t2).width; ctx.fillStyle = s.k.a; ctx.fillText(t2, -w2 / 2, 0); ctx.restore(); }
  }, { pola: ["tekst", "tekst2"], przyklad: { tekst: "299 zł", tekst2: "149 zł" } });
  ikonaN("mit-fakt", "Mit czy fakt", (s) => {
    const ctx = s.ctx, px = 80 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y, a = E.outBackMocno(T(s, 0, 0.4)), zm = s.t > 1.3 / s.p.tempo;
    const t = zm ? "FAKT" : "MIT", kol = zm ? "#22C55E" : "#EF4444", fl = Math.abs(Math.cos(clamp((s.t - 1.15 / s.p.tempo) / 0.3) * PI));
    ctx.save(); ctx.translate(cx, cy - px * 0.9); ctx.scale(a, a * (s.t > 1.15 / s.p.tempo && s.t < 1.45 / s.p.tempo ? Math.max(0.05, fl) : 1)); cien(s); ctx.font = font(s, px, 900); const w = ctx.measureText(t).width + 70 * s.u;
    ctx.fillStyle = kol; zaokr(ctx, -w / 2, -px * 0.7, w, px * 1.4, 16 * s.u); ctx.fill(); bezCienia(ctx); ctx.fillStyle = "#fff"; ctx.fillText(t, -w / 2 + 35 * s.u, 0); ctx.restore();
    podpis(s, cy + px * 0.3, E.outCubic(T(s, 0.3, 0.5)), 60);
  }, { przyklad: { tekst: "Kawa odwadnia organizm" }, czas: 3.5 });
  ikonaN("podium", "Podium TOP 3", (s) => {
    const ctx = s.ctx, el = lista(s.p.lista), w = 190 * s.u * s.p.rozmiar, wys = [260, 200, 150].map((x) => x * s.u * s.p.rozmiar), kol = [s.k.a, s.k.g, ciemniej(s.k.g, 0.3)];
    const ord = [1, 0, 2], baza = s.poz.y + 200 * s.u;
    ord.forEach((m, j) => {
      const e = E.outBackMocno(T(s, 0.15 + (2 - m) * 0.25, 0.5)); if (e <= 0) return; const x = s.poz.x + (j - 1) * (w + 10 * s.u) - w / 2, h = wys[m] * e;
      ctx.save(); cien(s); ctx.fillStyle = kol[m]; ctx.fillRect(x, baza - h, w, h); bezCienia(ctx); ctx.font = font(s, w * 0.42, 900); ctx.fillStyle = kontrast(kol[m]); const nt = String(m + 1), nw = ctx.measureText(nt).width; ctx.fillText(nt, x + w / 2 - nw / 2, baza - h + w * 0.32);
      if (el[m]) { const px = dopasuj(s, el[m], 44 * s.u * s.p.rozmiar, w * 1.05, 700); ctx.font = font(s, px, 700); ctx.fillStyle = s.k.t; const tw = ctx.measureText(el[m]).width; ctx.fillText(el[m], x + w / 2 - tw / 2, baza - h - px * 0.9); }
      ctx.restore();
    });
  }, { pola: ["lista"], przyklad: { lista: "Kraków\nGdańsk\nWrocław" }, czas: 3.5 });
  ikonaN("naklejka-nowosc", "Obrotowa naklejka NOWOŚĆ", (s) => {
    const ctx = s.ctx, r = R0(s, 140), a = E.outBackMocno(T(s, 0, 0.5)), t = tekstP(s, s.p.tekst || "NOWOŚĆ") + " • ", m = r + 30 * s.u;
    ctx.save(); ctx.translate(clamp(s.poz.x, m, s.W - m), clamp(s.poz.y, m, s.H - m)); ctx.scale(a, a); cien(s); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); bezCienia(ctx);
    ctx.rotate(s.t * 0.9); ctx.font = font(s, r * 0.2, 800); ctx.fillStyle = kontrast(s.k.g); const pow = (t + t).split(""), kat = (PI * 2) / pow.length;
    pow.forEach((c, i) => { ctx.save(); ctx.rotate(i * kat); ctx.translate(0, -r * 0.78); ctx.fillText(c, -ctx.measureText(c).width / 2, 0); ctx.restore(); });
    ctx.rotate(-s.t * 0.9); ctx.fillStyle = s.k.a; gwiazda(ctx, 0, 0, 5, r * 0.4, r * 0.18, -PI / 2); ctx.fill(); ctx.restore();
  }, { przyklad: { tekst: "NOWOŚĆ" }, dom: { pozycja: "prawy-gora" } });
  ikonaN("equalizer", "Słupki dźwięku", (s) => {
    const ctx = s.ctx, n = 11, w = 26 * s.u * s.p.rozmiar, H = 220 * s.u * s.p.rozmiar, a = E.outCubic(T(s, 0, 0.4));
    for (let i = 0; i < n; i++) { const h = H * a * (0.25 + 0.75 * Math.abs(Math.sin(s.t * (3 + los(i) * 4) + i))); const x = s.poz.x + (i - (n - 1) / 2) * w * 1.6 - w / 2;
      ctx.fillStyle = i % 3 === 1 ? s.k.a : s.k.g; zaokr(ctx, x, s.poz.y - h / 2, w, h, w / 2); ctx.fill(); }
    podpis(s, s.poz.y + H * 0.7, E.outCubic(T(s, 0.3, 0.5)));
  }, { przyklad: { tekst: "Podgłośnij!" }, czas: 4 });
  ikonaN("dymek-pisze", "Ktoś pisze…", (s) => {
    const ctx = s.ctx, r = 60 * s.u * s.p.rozmiar, a = E.outBackMocno(T(s, 0, 0.4)), w = r * 3.4, h = r * 1.6;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); cien(s); ctx.fillStyle = "#E5E7EB"; zaokr(ctx, -w / 2, -h / 2, w, h, h / 2); ctx.fill(); ctx.beginPath(); ctx.arc(-w / 2 + r * 0.25, h / 2 - r * 0.1, r * 0.3, 0, PI * 2); ctx.fill(); bezCienia(ctx);
    for (let i = 0; i < 3; i++) { const sk = 0.6 + 0.4 * Math.max(0, Math.sin(s.t * 7 - i * 0.9)); ctx.fillStyle = "#6B7280"; ctx.beginPath(); ctx.arc((i - 1) * r * 0.85, 0, r * 0.24 * sk, 0, PI * 2); ctx.fill(); }
    ctx.restore(); podpis(s, s.poz.y + h, E.outCubic(T(s, 0.3, 0.5)), 54);
  }, { przyklad: { tekst: "Odpowiedź za chwilę" } });
  ikonaN("wiadomosc", "Wiadomość SMS", (s) => {
    const ctx = s.ctx, px = 46 * s.u * s.p.rozmiar, a = E.outBackMocno(T(s, 0, 0.45)), u = uloz(s, s.p.tekst, px, { maxW: s.W * 0.6, align: "left", x: 0, y: 0, gora: true, waga: 500 });
    const w = u.w + 56 * s.u, h = u.h + 40 * s.u, x0 = s.poz.x - w / 2, y0 = s.poz.y - h / 2;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y + h / 2); ctx.scale(a, a); ctx.translate(-s.poz.x, -s.poz.y - h / 2); cien(s); ctx.fillStyle = s.k.g; zaokr(ctx, x0, y0, w, h, 30 * s.u); ctx.fill();
    ctx.beginPath(); ctx.moveTo(x0 + w - 30 * s.u, y0 + h - 4 * s.u); ctx.quadraticCurveTo(x0 + w + 10 * s.u, y0 + h + 6 * s.u, x0 + w + 16 * s.u, y0 + h); ctx.quadraticCurveTo(x0 + w, y0 + h - 10 * s.u, x0 + w - 4 * s.u, y0 + h - 30 * s.u); ctx.fill(); bezCienia(ctx);
    ctx.font = u.font; u.slowa.forEach((sl) => { ctx.fillStyle = sl.wyr ? s.k.a : kontrast(s.k.g); ctx.fillText(sl.t, x0 + 28 * s.u + sl.x, y0 + 20 * s.u + sl.y); });
    ctx.restore();
    const b = E.outCubic(T(s, 0.6, 0.3)); if (b > 0) { ctx.globalAlpha = s.alfa * b; ctx.font = font(s, px * 0.5, 600); ctx.fillStyle = rgba(s.k.t, 0.8); const tt = "Dostarczono"; ctx.fillText(tt, x0 + w - ctx.measureText(tt).width, y0 + h + px * 0.8); ctx.globalAlpha = s.alfa; }
  }, { przyklad: { tekst: "Hej, widziałeś już *nowy* odcinek?" } });
  ikonaN("reakcje", "Reakcje wylatują w górę", (s) => {
    const ctx = s.ctx, em = Array.from(s.p.emoji || "😍🔥👏😂❤️"), n = 18;
    for (let i = 0; i < n; i++) { const st = los(i * 3.3) * (s.T - 1.4), e = okno(s.t, st, 1.4); if (e <= 0 || e >= 1) continue;
      const x = s.poz.x + (los(i * 7.1) - 0.5) * s.W * 0.5 + Math.sin(e * 6 + i) * 30 * s.u, y = s.H * 0.85 - e * s.H * 0.55, sk = (0.6 + los(i) * 0.6) * s.p.rozmiar;
      ctx.globalAlpha = s.alfa * (1 - E.inCubic(e)); ctx.font = `${Math.round(70 * s.u * sk)}px "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif`; ctx.fillText(em[i % em.length], x, y); }
    ctx.globalAlpha = s.alfa;
  }, { pola: ["emoji"], przyklad: { emoji: "😍🔥👏😂❤️" }, czas: 4 });
  ikonaN("kadr-celownik", "Zaznaczenie kadru narożnikami", (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), w = 360 * s.u * s.p.rozmiar, h = 300 * s.u * s.p.rozmiar, e = E.outBackMocno(T(s, 0, 0.5)), k = 60 * s.u, sk = lerp(1.8, 1, e);
    ctx.save(); ctx.translate(cx, cy); ctx.scale(sk, sk); ctx.globalAlpha = s.alfa * clamp(e * 2); ctx.strokeStyle = s.k.a; ctx.lineWidth = 8 * s.u; ctx.lineCap = "round";
    [[-1, -1], [1, -1], [1, 1], [-1, 1]].forEach(([a, b]) => { ctx.beginPath(); ctx.moveTo(a * w / 2, b * h / 2 - b * k); ctx.lineTo(a * w / 2, b * h / 2); ctx.lineTo(a * w / 2 - a * k, b * h / 2); ctx.stroke(); });
    ctx.restore(); if (s.p.tekst) { const e2 = E.outCubic(T(s, 0.4, 0.4)); ctx.save(); ctx.globalAlpha = s.alfa * e2; ctx.font = font(s, 44 * s.u * s.p.rozmiar, 800); const tw = ctx.measureText(s.p.tekst).width + 30 * s.u;
      ctx.fillStyle = s.k.a; ctx.fillRect(cx - w / 2, cy - h / 2 - 70 * s.u, tw, 56 * s.u); ctx.fillStyle = kontrast(s.k.a); ctx.fillText(s.p.tekst, cx - w / 2 + 15 * s.u, cy - h / 2 - 42 * s.u); ctx.restore(); }
  }, { pola: ["tekst", "xy"], przyklad: { tekst: "TU PATRZ", x: 0.5, y: 0.45 } });
  ikonaN("klawisze", "Skrót klawiszowy", (s) => {
    const ctx = s.ctx, kl = String(s.p.tekst || "Ctrl+S").split("+").map((x) => x.trim()).filter(Boolean), px = 56 * s.u * s.p.rozmiar, h = px * 1.9; ctx.font = font(s, px, 700);
    const sz = kl.map((k) => Math.max(h, ctx.measureText(k).width + px)), plus = px * 1.1, cal = sz.reduce((a, b) => a + b, 0) + plus * (kl.length - 1); let x = s.poz.x - cal / 2;
    kl.forEach((k, i) => { const e = E.outBackMocno(T(s, i * 0.2, 0.4)), wc = okno(s.t, (0.9 + i * 0.05) / s.p.tempo, 0.15), wd = wc > 0 && wc < 1 ? 6 * s.u : 0;
      ctx.save(); ctx.translate(x + sz[i] / 2, s.poz.y + wd); ctx.scale(e, e); ctx.fillStyle = "#D1D5DB"; zaokr(ctx, -sz[i] / 2, -h / 2 + 10 * s.u - wd, sz[i], h, 16 * s.u); ctx.fill();
      ctx.fillStyle = "#F9FAFB"; zaokr(ctx, -sz[i] / 2, -h / 2, sz[i], h - 10 * s.u, 16 * s.u); ctx.fill(); ctx.fillStyle = "#111827"; const tw = ctx.measureText(k).width; ctx.fillText(k, -tw / 2, -5 * s.u); ctx.restore();
      x += sz[i]; if (i < kl.length - 1) { ctx.globalAlpha = s.alfa * E.outCubic(T(s, i * 0.2 + 0.1, 0.3)); ctx.fillStyle = s.k.t; ctx.fillText("+", x + plus / 2 - ctx.measureText("+").width / 2, s.poz.y); ctx.globalAlpha = s.alfa; x += plus; } });
  }, { przyklad: { tekst: "Ctrl + Shift + S" } });
  ikonaN("zrobione", "Zrobione: ptaszek w kole", (s) => {
    const ctx = s.ctx, r = R0(s, 120), a = E.outBackMocno(T(s, 0, 0.45)), k = E.inOutCubic(T(s, 0.3, 0.5));
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); cien(s); ctx.fillStyle = "#22C55E"; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); bezCienia(ctx); ctx.restore();
    ptaszek(ctx, s.poz.x, s.poz.y, r * 0.55, k, "#FFFFFF", r * 0.16);
    podpis(s, s.poz.y + r * 1.3, E.outCubic(T(s, 0.6, 0.5)));
  }, { przyklad: { tekst: "Gotowe!" } });
  ikonaN("krzyzyk", "Nie: krzyżyk w kole", (s) => {
    const ctx = s.ctx, r = R0(s, 120), a = E.outBackMocno(T(s, 0, 0.45)), k1 = E.inOutCubic(T(s, 0.3, 0.25)), k2 = E.inOutCubic(T(s, 0.5, 0.25)), d = r * 0.42;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.rotate(Math.sin(clamp((s.t - 0.75) * 3) * PI * 3) * 0.08); cien(s); ctx.fillStyle = "#EF4444"; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); bezCienia(ctx);
    ctx.strokeStyle = "#fff"; ctx.lineWidth = r * 0.17; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(-d, -d); ctx.lineTo(-d + 2 * d * k1, -d + 2 * d * k1); ctx.stroke(); if (k2 > 0) { ctx.beginPath(); ctx.moveTo(d, -d); ctx.lineTo(d - 2 * d * k2, -d + 2 * d * k2); ctx.stroke(); } ctx.restore();
    podpis(s, s.poz.y + r * 1.3, E.outCubic(T(s, 0.6, 0.5)));
  }, { przyklad: { tekst: "Tego *nie* rób" } });
  ikonaN("kalendarz", "Kartka z kalendarza", (s) => {
    const ctx = s.ctx, w = 260 * s.u * s.p.rozmiar, h = w * 1.05, a = E.outBackMocno(T(s, 0, 0.5)), [d, ...mies] = String(s.p.tekst || "24 grudnia").split(/\s+/);
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.rotate((1 - a) * 0.3); cien(s); ctx.fillStyle = "#FFFFFF"; zaokr(ctx, -w / 2, -h / 2, w, h, 24 * s.u); ctx.fill(); bezCienia(ctx);
    ctx.save(); ctx.beginPath(); zaokr(ctx, -w / 2, -h / 2, w, h, 24 * s.u); ctx.clip(); ctx.fillStyle = s.k.g; ctx.fillRect(-w / 2, -h / 2, w, h * 0.3); ctx.restore();
    ctx.font = font(s, h * 0.13, 800); ctx.fillStyle = kontrast(s.k.g); const m = mies.join(" ").toLocaleUpperCase("pl"), mw = ctx.measureText(m).width; ctx.fillText(m, -mw / 2, -h * 0.35);
    ctx.font = font(s, h * 0.46, 900); ctx.fillStyle = "#111827"; const dw = ctx.measureText(d).width; ctx.fillText(d, -dw / 2, h * 0.15); ctx.restore();
    podpis(s, s.poz.y + h * 0.75, E.outCubic(T(s, 0.4, 0.5)), 56, "tekst2");
  }, { pola: ["tekst", "tekst2"], przyklad: { tekst: "24 grudnia", tekst2: "Wielka premiera" } });
  ikonaN("bateria", "Bateria się ładuje", (s) => {
    const ctx = s.ctx, w = 330 * s.u * s.p.rozmiar, h = w * 0.5, a = E.outBackMocno(T(s, 0, 0.4)), p = clamp((s.t - 0.4) / Math.max(0.5, s.T - 1.2)), poz = Math.min(4, Math.floor(p * 5));
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.strokeStyle = s.k.t; ctx.lineWidth = 10 * s.u; zaokr(ctx, -w / 2, -h / 2, w, h, 20 * s.u); ctx.stroke(); ctx.fillStyle = s.k.t; zaokr(ctx, w / 2 + 6 * s.u, -h * 0.18, 18 * s.u, h * 0.36, 6 * s.u); ctx.fill();
    const kw = (w - 40 * s.u) / 5; for (let i = 0; i <= poz; i++) { ctx.fillStyle = poz < 2 ? "#EF4444" : poz < 4 ? "#FACC15" : "#22C55E"; zaokr(ctx, -w / 2 + 14 * s.u + i * (kw + 3 * s.u), -h / 2 + 14 * s.u, kw - 3 * s.u, h - 28 * s.u, 6 * s.u); ctx.fill(); }
    ctx.restore(); podpis(s, s.poz.y + h * 0.9, E.outCubic(T(s, 0.3, 0.5)));
  }, { przyklad: { tekst: "Ładowanie *energii*…" }, czas: 4 });

  // ---------- liczby i wykresy (v17) ----------
  function liczbaN(id, nazwa, przyklad, fn, o = {}) { dodaj({ id, nazwa, kat: "liczby", czas: o.czas || 3.5, pola: o.pola || ["liczba", "od", "przed", "po", "tekst2"], dom: o.dom, przyklad, rysuj: fn }); }
  const wartosc = (s, e) => lerp(+s.p.od || 0, +s.p.liczba || 0, e);
  const liczbaT = (s, v) => `${s.p.przed || ""}${liczbaTekst(v, miejscaPo(s.p.liczba))}${s.p.po || ""}`;
  liczbaN("licznik-kolo", "Licznik w kole postępu", { liczba: 87, po: "%", tekst2: "zadowolonych klientów" }, (s) => {
    const ctx = s.ctx, r = 190 * s.u * s.p.rozmiar, e = E.outCubic(T(s, 0.1, 1.6)), a = E.outBack(T(s, 0, 0.4)), max = +s.p.max || 100;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.lineWidth = r * 0.16; ctx.lineCap = "round"; ctx.strokeStyle = rgba(s.k.t, 0.18); ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.stroke();
    ctx.strokeStyle = s.k.a; ctx.beginPath(); ctx.arc(0, 0, r, -PI / 2, -PI / 2 + PI * 2 * clamp(wartosc(s, e) / max)); ctx.stroke();
    const t = liczbaT(s, wartosc(s, e)); ctx.font = font(s, dopasuj(s, t, r * 0.72, r * 1.5, 900), 900); ctx.fillStyle = s.k.t; const w = ctx.measureText(t).width; ctx.fillText(t, -w / 2, 0); ctx.restore();
    podpis(s, s.poz.y + r * 1.35, E.outCubic(T(s, 0.6, 0.5)), 52, "tekst2");
  }, { pola: ["liczba", "od", "przed", "po", "tekst2"] });
  liczbaN("licznik-pasek", "Licznik z paskiem", { liczba: 72, po: "%", tekst2: "Ukończono kurs" }, (s) => {
    const ctx = s.ctx, W = s.W * 0.7 * s.p.rozmiar, h = 34 * s.u * s.p.rozmiar, e = E.outCubic(T(s, 0.2, 1.5)), a = E.outCubic(T(s, 0, 0.4)), x0 = s.poz.x - W / 2, max = +s.p.max || 100;
    ctx.globalAlpha = s.alfa * a; ctx.fillStyle = rgba(s.k.t, 0.2); zaokr(ctx, x0, s.poz.y, W, h, h / 2); ctx.fill();
    ctx.fillStyle = s.k.a; zaokr(ctx, x0, s.poz.y, Math.max(h, W * clamp(wartosc(s, e) / max)), h, h / 2); ctx.fill();
    const t = liczbaT(s, wartosc(s, e)); ctx.font = font(s, 110 * s.u * s.p.rozmiar, 900); ctx.fillStyle = s.k.t; cien(s); ctx.fillText(t, x0, s.poz.y - 80 * s.u * s.p.rozmiar);
    if (s.p.tekst2) { ctx.font = font(s, 46 * s.u * s.p.rozmiar, 600); ctx.fillText(s.p.tekst2, x0, s.poz.y + h + 50 * s.u); } ctx.globalAlpha = s.alfa;
  });
  liczbaN("licznik-pieniadze", "Rosnąca kwota", { liczba: 125000, po: " zł", tekst2: "przychodu w pierwszym roku" }, (s) => {
    const ctx = s.ctx, e = E.outQuint(T(s, 0.1, 1.8)), skok = 1 + 0.12 * Math.sin(clamp((s.t - 1.9 / s.p.tempo) * 4) * PI), t = liczbaT(s, Math.round(wartosc(s, e)));
    const px = dopasuj(s, t, 170 * s.u * s.p.rozmiar, s.W * 0.88, 900); ctx.font = font(s, px, 900); const w = ctx.measureText(t).width;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(skok, skok); cien(s, ctx, 1.5); ctx.fillStyle = "#22C55E"; ctx.fillText(t, -w / 2, 0); ctx.restore();
    for (let i = 0; i < 10; i++) { const st = 0.3 + los(i) * 1.6, k = okno(s.t, st, 1.2); if (k <= 0 || k >= 1) continue; ctx.globalAlpha = s.alfa * (1 - k); ctx.font = font(s, 60 * s.u, 900); ctx.fillStyle = s.k.a; ctx.fillText("$", s.poz.x + (los(i * 5) - 0.5) * s.W * 0.7, s.poz.y - k * 300 * s.u); }
    ctx.globalAlpha = s.alfa; podpis(s, s.poz.y + px * 0.8, E.outCubic(T(s, 0.5, 0.5)), 50, "tekst2");
  });
  liczbaN("strzalka-wzrost", "Strzałka wzrostu z procentem", { liczba: 340, przed: "+", po: "%", tekst2: "wzrost sprzedaży" }, (s) => {
    const ctx = s.ctx, W = 420 * s.u * s.p.rozmiar, H = 300 * s.u * s.p.rozmiar, e = E.inOutCubic(T(s, 0, 1)), x0 = s.poz.x - W / 2, y0 = s.poz.y + H / 2;
    const pkt = [[x0, y0], [x0 + W * 0.3, y0 - H * 0.35], [x0 + W * 0.5, y0 - H * 0.2], [x0 + W, y0 - H]]; ctx.strokeStyle = "#22C55E"; ctx.lineWidth = 18 * s.u * s.p.rozmiar; ctx.lineJoin = "round"; ctx.lineCap = "round"; cien(s);
    sciezkaCzesc(ctx, pkt, e); ctx.stroke(); if (e > 0.95) { ctx.fillStyle = "#22C55E"; ctx.save(); ctx.translate(x0 + W, y0 - H); ctx.rotate(Math.atan2(-H * 0.8, W * 0.5)); ctx.beginPath(); ctx.moveTo(30 * s.u, 0); ctx.lineTo(-25 * s.u, -30 * s.u); ctx.lineTo(-25 * s.u, 30 * s.u); ctx.closePath(); ctx.fill(); ctx.restore(); }
    bezCienia(ctx); const k = E.outCubic(T(s, 0.6, 1)), t = liczbaT(s, wartosc(s, k)); ctx.font = font(s, 120 * s.u * s.p.rozmiar, 900); ctx.fillStyle = s.k.t; cien(s); ctx.globalAlpha = s.alfa * clamp(k * 3); ctx.fillText(t, x0, y0 - H - 40 * s.u);
    ctx.globalAlpha = s.alfa; podpis(s, y0 + 50 * s.u, E.outCubic(T(s, 0.8, 0.5)), 50, "tekst2");
  });
  liczbaN("wykres-liniowy", "Wykres liniowy rysuje się", { lista: "Sty: 20\nLut: 35\nMar: 30\nKwi: 55\nMaj: 80", tekst: "Obserwujący (tys.)" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista), W = s.W * 0.78 * s.p.rozmiar, H = 420 * s.u * s.p.rozmiar, x0 = s.poz.x - W / 2, y0 = s.poz.y + H / 2, max = Math.max(1, ...d.map((x) => x.v));
    const e = E.inOutCubic(T(s, 0.3, 1.5)), a = E.outCubic(T(s, 0, 0.4)); ctx.globalAlpha = s.alfa * a; ctx.strokeStyle = rgba(s.k.t, 0.25); ctx.lineWidth = 2 * s.u;
    for (let i = 0; i <= 4; i++) { ctx.beginPath(); ctx.moveTo(x0, y0 - H * i / 4); ctx.lineTo(x0 + W, y0 - H * i / 4); ctx.stroke(); }
    const pkt = d.map((x, i) => [x0 + W * i / Math.max(1, d.length - 1), y0 - H * x.v / max]);
    ctx.strokeStyle = s.k.a; ctx.lineWidth = 9 * s.u; ctx.lineJoin = "round"; sciezkaCzesc(ctx, pkt, e); ctx.stroke();
    ctx.font = font(s, 34 * s.u * s.p.rozmiar, 600); d.forEach((x, i) => { const v = okno(e, i / Math.max(1, d.length - 1) - 0.02, 0.05); ctx.fillStyle = s.k.t; ctx.fillText(x.e, pkt[i][0] - ctx.measureText(x.e).width / 2, y0 + 40 * s.u);
      if (v > 0) { ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(pkt[i][0], pkt[i][1], 13 * s.u * E.outBack(v), 0, PI * 2); ctx.fill(); } });
    if (s.p.tekst) { ctx.font = font(s, 50 * s.u * s.p.rozmiar, 800); ctx.fillStyle = s.k.t; ctx.fillText(s.p.tekst, x0, y0 - H - 60 * s.u); } ctx.globalAlpha = s.alfa;
  }, { pola: ["lista", "tekst"], czas: 4 });
  liczbaN("wykres-poziomy", "Wykres słupkowy poziomy", { lista: "Instagram: 62\nTikTok: 81\nYouTube: 45\nFacebook: 30", po: "%" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista), W = s.W * 0.6 * s.p.rozmiar, h = 52 * s.u * s.p.rozmiar, lh = h * 1.9, max = Math.max(1, ...d.map((x) => x.v)), x0 = s.poz.x - W * 0.5, y0 = s.poz.y - (d.length - 1) * lh / 2;
    d.forEach((x, i) => { const e = E.outCubic(T(s, 0.2 + i * 0.15, 1)), y = y0 + i * lh; ctx.font = font(s, h * 0.7, 700); ctx.fillStyle = s.k.t; ctx.globalAlpha = s.alfa * clamp(e * 3); ctx.fillText(x.e, x0, y - h * 0.75);
      ctx.fillStyle = rgba(s.k.t, 0.15); zaokr(ctx, x0, y - h * 0.35, W, h * 0.7, h * 0.35); ctx.fill(); ctx.fillStyle = i % 2 ? s.k.g : s.k.a; zaokr(ctx, x0, y - h * 0.35, Math.max(h * 0.7, W * x.v / max * e), h * 0.7, h * 0.35); ctx.fill();
      const t = liczbaTekst(x.v * e) + (s.p.po || ""); ctx.fillStyle = s.k.t; ctx.fillText(t, x0 + W + 20 * s.u, y); });
    ctx.globalAlpha = s.alfa;
  }, { pola: ["lista", "po"], czas: 4 });
  liczbaN("ranking", "Ranking TOP 5", { lista: "Kraków\nWarszawa\nGdańsk\nPoznań\nWrocław", tekst: "Najlepsze miasta" }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista).slice(0, 8), px = 56 * s.u * s.p.rozmiar, lh = px * 1.75, x0 = s.W * 0.14, y0 = s.poz.y - (el.length - 1) * lh / 2;
    if (s.p.tekst) { const e = E.outCubic(T(s, 0, 0.4)); ctx.globalAlpha = s.alfa * e; ctx.font = font(s, px * 1.1, 900); ctx.fillStyle = s.k.a; ctx.fillText(tekstP(s, s.p.tekst), x0, y0 - lh * 1.2); }
    el.forEach((t, i) => { const j = el.length - 1 - i, e = E.outQuint(T(s, 0.25 + j * 0.18, 0.5)); if (e <= 0) return; const y = y0 + i * lh;
      ctx.globalAlpha = s.alfa * clamp(e * 2); ctx.save(); ctx.translate((1 - e) * -200 * s.u, 0); cien(s); ctx.fillStyle = i === 0 ? s.k.a : s.k.g; zaokr(ctx, x0, y - px * 0.65, px * 1.3, px * 1.3, 12 * s.u); ctx.fill(); bezCienia(ctx);
      ctx.font = font(s, px * 0.8, 900); ctx.fillStyle = kontrast(i === 0 ? s.k.a : s.k.g); const n = String(i + 1); ctx.fillText(n, x0 + px * 0.65 - ctx.measureText(n).width / 2, y);
      ctx.font = font(s, px, s.p.waga); ctx.fillStyle = s.k.t; cien(s); ctx.fillText(t, x0 + px * 1.6, y); ctx.restore(); });
    ctx.globalAlpha = s.alfa;
  }, { pola: ["lista", "tekst"], czas: 4.5, dom: { pozycja: "lewy-srodek" } });
  liczbaN("stoper", "Stoper odmierza czas", { liczba: 30, po: " s", tekst2: "tyle zajmuje przygotowanie" }, (s) => {
    const ctx = s.ctx, r = 170 * s.u * s.p.rozmiar, a = E.outBack(T(s, 0, 0.4)), e = clamp((s.t - 0.3) / Math.max(0.5, s.T - 1.2)), v = Math.round(lerp(+s.p.od || 0, +s.p.liczba || 0, e));
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); cien(s); ctx.fillStyle = "#FFFFFF"; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); ctx.fillRect(-r * 0.15, -r * 1.25, r * 0.3, r * 0.2); bezCienia(ctx);
    ctx.strokeStyle = s.k.g; ctx.lineWidth = r * 0.08; ctx.beginPath(); ctx.arc(0, 0, r * 0.88, -PI / 2, -PI / 2 + PI * 2 * e); ctx.stroke();
    ctx.strokeStyle = "#111827"; ctx.lineWidth = r * 0.05; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(-PI / 2 + e * PI * 2 * 3) * r * 0.65, Math.sin(-PI / 2 + e * PI * 2 * 3) * r * 0.65); ctx.stroke();
    const t = `${s.p.przed || ""}${v}${s.p.po || ""}`; ctx.font = font(s, r * 0.42, 900); ctx.fillStyle = "#111827"; ctx.fillText(t, -ctx.measureText(t).width / 2, r * 0.45); ctx.restore();
    podpis(s, s.poz.y + r * 1.35, E.outCubic(T(s, 0.4, 0.5)), 50, "tekst2");
  }, { czas: 4 });
  liczbaN("ludziki", "9 na 10 osób", { liczba: 9, tekst2: "na 10 osób poleca nas znajomym" }, (s) => {
    const ctx = s.ctx, n = 10, w = 78 * s.u * s.p.rozmiar, ile = Math.round(+s.p.liczba || 0), x0 = s.poz.x - (n * w) / 2;
    for (let i = 0; i < n; i++) { const e = E.outBackMocno(T(s, i * 0.07, 0.4)); if (e <= 0) continue; const x = x0 + i * w + w / 2, y = s.poz.y, k = i < ile && s.t > (0.8 + i * 0.08) / s.p.tempo;
      ctx.save(); ctx.translate(x, y); ctx.scale(e, e); ctx.fillStyle = k ? s.k.a : rgba(s.k.t, 0.3); ctx.beginPath(); ctx.arc(0, -w * 0.45, w * 0.2, 0, PI * 2); ctx.fill(); zaokr(ctx, -w * 0.28, -w * 0.2, w * 0.56, w * 0.7, w * 0.22); ctx.fill(); ctx.restore(); }
    const t = `${ile}/10`; ctx.font = font(s, 140 * s.u * s.p.rozmiar, 900); ctx.fillStyle = s.k.a; cien(s); const a = E.outBack(T(s, 1.3, 0.4)); if (a > 0) { ctx.save(); ctx.translate(s.poz.x, s.poz.y - 200 * s.u * s.p.rozmiar); ctx.scale(a, a); ctx.fillText(t, -ctx.measureText(t).width / 2, 0); ctx.restore(); }
    podpis(s, s.poz.y + 90 * s.u * s.p.rozmiar, E.outCubic(T(s, 1.4, 0.5)), 48, "tekst2");
  }, { pola: ["liczba", "tekst2"], czas: 4 });
  liczbaN("mnoznik", "Mnożnik x3", { liczba: 3, przed: "x", tekst2: "szybsza praca" }, (s) => {
    const ctx = s.ctx, px = 280 * s.u * s.p.rozmiar, n = Math.max(1, Math.round(+s.p.liczba || 1)), krok = 0.35 / s.p.tempo, i = Math.min(n, 1 + Math.floor(s.t / krok)), lok = (s.t % krok) / krok;
    const sk = s.t < n * krok ? lerp(1.5, 1, E.outBack(lok)) : 1, t = `${s.p.przed || ""}${i}${s.p.po || ""}`; ctx.font = font(s, px, 900); const w = ctx.measureText(t).width;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(sk, sk); ctx.rotate(-0.06); cien(s, ctx, 2); ctx.fillStyle = s.k.a; ctx.fillText(t, -w / 2, 0); ctx.restore();
    podpis(s, s.poz.y + px * 0.6, E.outCubic(okno(s.t, n * krok, 0.4)), 60, "tekst2");
  }, { pola: ["liczba", "przed", "po", "tekst2"] });
  liczbaN("procent-donut", "Wykres kołowy z podziałem", { lista: "Wideo: 55\nZdjęcia: 30\nTekst: 15", tekst: "Co działa najlepiej" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista), r = 200 * s.u * s.p.rozmiar, suma = d.reduce((a, x) => a + x.v, 0) || 1, e = E.inOutCubic(T(s, 0.2, 1.3)), kol = [s.k.a, s.k.g, ciemniej(s.k.g, 0.35), "#9CA3AF", "#E5E7EB"];
    let k0 = -PI / 2; const cx = s.poz.x, cy = s.poz.y - 60 * s.u; ctx.lineWidth = r * 0.42;
    d.forEach((x, i) => { const k1 = k0 + (x.v / suma) * PI * 2; const kk = Math.min(k1, -PI / 2 + PI * 2 * e); if (kk > k0) { ctx.strokeStyle = kol[i % kol.length]; ctx.beginPath(); ctx.arc(cx, cy, r, k0, kk); ctx.stroke(); } k0 = k1; });
    ctx.font = font(s, 40 * s.u * s.p.rozmiar, 700); d.forEach((x, i) => { const a = E.outCubic(T(s, 1 + i * 0.15, 0.4)); ctx.globalAlpha = s.alfa * a; const y = cy + r * 1.45 + i * 60 * s.u * s.p.rozmiar; ctx.fillStyle = kol[i % kol.length]; ctx.fillRect(cx - r, y - 15 * s.u, 30 * s.u, 30 * s.u);
      ctx.fillStyle = s.k.t; ctx.fillText(`${x.e} ${Math.round(x.v / suma * 100)}%`, cx - r + 50 * s.u, y); });
    ctx.globalAlpha = s.alfa; if (s.p.tekst) { ctx.font = font(s, 56 * s.u * s.p.rozmiar, 800); ctx.fillStyle = s.k.t; const w = ctx.measureText(s.p.tekst).width; ctx.fillText(s.p.tekst, cx - w / 2, cy - r * 1.5); }
  }, { pola: ["lista", "tekst"], czas: 4 });
  liczbaN("porownanie-slupki", "Porównanie: my i konkurencja", { lista: "Konkurencja: 40\n*My*: 95", po: "%" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista).slice(0, 2), H = 460 * s.u * s.p.rozmiar, w = 180 * s.u * s.p.rozmiar, max = Math.max(1, ...d.map((x) => x.v)), baza = s.poz.y + H / 2;
    d.forEach((x, i) => { const e = E.outBackMocno(T(s, 0.2 + i * 0.35, 0.8)), cx = s.poz.x + (i ? 1 : -1) * w * 0.85, h = H * x.v / max * Math.max(0, e), wyr = /\*/.test(x.e) || i === 1, nz = x.e.replace(/\*/g, "");
      ctx.fillStyle = wyr ? s.k.a : rgba(s.k.t, 0.35); zaokr(ctx, cx - w / 2, baza - h, w, h, 14 * s.u); ctx.fill(); ctx.font = font(s, 48 * s.u * s.p.rozmiar, 900); ctx.fillStyle = s.k.t; const t = liczbaTekst(x.v * clamp(e)) + (s.p.po || "");
      ctx.fillText(t, cx - ctx.measureText(t).width / 2, baza - h - 40 * s.u); ctx.font = font(s, 40 * s.u * s.p.rozmiar, 700); ctx.fillText(nz, cx - ctx.measureText(nz).width / 2, baza + 45 * s.u); });
  }, { pola: ["lista", "po"], czas: 3.5 });
  liczbaN("dni-do", "Ile dni zostało", { liczba: 7, tekst2: "dni do premiery" }, (s) => {
    const ctx = s.ctx, n = Math.round(+s.p.liczba || 0), start = n + 5, e = E.outQuint(T(s, 0.1, 1.4)), v = Math.round(lerp(start, n, e)), w = 170 * s.u * s.p.rozmiar, h = w * 1.3;
    String(v).padStart(2, "0").split("").forEach((c, i, arr) => { const x = s.poz.x + (i - (arr.length - 1) / 2) * (w + 18 * s.u); ctx.save(); ctx.translate(x, s.poz.y); cien(s); ctx.fillStyle = s.k.tl; zaokr(ctx, -w / 2, -h / 2, w, h, 18 * s.u); ctx.fill(); bezCienia(ctx);
      ctx.fillStyle = rgba("#000", 0.35); ctx.fillRect(-w / 2, -2 * s.u, w, 4 * s.u); ctx.font = font(s, h * 0.7, 900); ctx.fillStyle = s.k.a; ctx.fillText(c, -ctx.measureText(c).width / 2, 0); ctx.restore(); });
    podpis(s, s.poz.y + h * 0.75, E.outCubic(T(s, 0.6, 0.5)), 56, "tekst2");
  }, { pola: ["liczba", "tekst2"] });
  liczbaN("ocena", "Ocena 4,9 z gwiazdkami", { liczba: 4.9, tekst2: "na podstawie 1 200 opinii" }, (s) => {
    const ctx = s.ctx, r = 46 * s.u * s.p.rozmiar, v = +s.p.liczba || 5, e = E.outCubic(T(s, 0.1, 1.2)), wart = lerp(0, v, e);
    ctx.font = font(s, 170 * s.u * s.p.rozmiar, 900); const t = liczbaTekst(wart, 1); ctx.fillStyle = s.k.t; cien(s); ctx.fillText(t, s.poz.x - ctx.measureText(t).width / 2, s.poz.y - 80 * s.u * s.p.rozmiar); bezCienia(ctx);
    for (let i = 0; i < 5; i++) { const a = E.outBackMocno(T(s, 0.3 + i * 0.12, 0.4)); if (a <= 0) continue; const x = s.poz.x + (i - 2) * r * 2.4, y = s.poz.y + 60 * s.u * s.p.rozmiar;
      ctx.save(); ctx.translate(x, y); ctx.scale(a, a); ctx.fillStyle = rgba(s.k.t, 0.25); gwiazda(ctx, 0, 0, 5, r, r * 0.45, -PI / 2); ctx.fill(); ctx.save(); ctx.beginPath(); ctx.rect(-r, -r, r * 2 * clamp(wart - i), r * 2); ctx.clip(); ctx.fillStyle = "#FACC15"; gwiazda(ctx, 0, 0, 5, r, r * 0.45, -PI / 2); ctx.fill(); ctx.restore(); ctx.restore(); }
    podpis(s, s.poz.y + 150 * s.u * s.p.rozmiar, E.outCubic(T(s, 0.8, 0.5)), 44, "tekst2");
  }, { pola: ["liczba", "tekst2"] });
  liczbaN("tabela-przed-po", "Tabela przed i po", { lista: "Czas montażu: 8 h → 2 h\nKoszt: 2000 zł → 600 zł\nRolki w tygodniu: 1 → 5", tekst: "Przed → Po" }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista).map((x) => x.split(/→|->/).map((y) => y.trim())), px = 44 * s.u * s.p.rozmiar, lh = px * 2.4, W = s.W * 0.84, x0 = s.poz.x - W / 2, y0 = s.poz.y - (el.length - 1) * lh / 2;
    el.forEach((r, i) => { const e = E.outQuint(T(s, 0.2 + i * 0.25, 0.6)); if (e <= 0) return; const y = y0 + i * lh; const m = r[0].match(/^(.*?):\s*(.*)$/), et = m ? m[1] : "", przed = m ? m[2] : r[0], po = r[1] || "";
      ctx.globalAlpha = s.alfa * clamp(e * 2); ctx.fillStyle = rgba(s.k.tl, 0.85); zaokr(ctx, x0, y - lh * 0.42, W * e, lh * 0.84, 14 * s.u); ctx.fill();
      ctx.font = font(s, px * 0.7, 600); ctx.fillStyle = rgba(s.k.t, 0.7); ctx.fillText(et, x0 + 24 * s.u, y - px * 0.5);
      ctx.font = font(s, px, 800); ctx.fillStyle = rgba(s.k.t, 0.75); ctx.fillText(przed, x0 + 24 * s.u, y + px * 0.4); const pw = ctx.measureText(przed).width;
      ctx.fillStyle = s.k.a; ctx.fillText("→", x0 + 50 * s.u + pw, y + px * 0.4); ctx.fillText(po, x0 + 70 * s.u + pw + ctx.measureText("→").width, y + px * 0.4); });
    ctx.globalAlpha = s.alfa;
  }, { pola: ["lista", "tekst"], czas: 4.5 });

  // ---------- wezwania do działania (v17) ----------
  function ctaN(id, nazwa, przyklad, fn, o = {}) { dodaj({ id, nazwa, kat: "cta", czas: o.czas || 3, pola: o.pola || ["tekst", "tekst2"], dom: Object.assign({ pozycja: "dol" }, o.dom || {}), przyklad, rysuj: fn }); }
  function przycisk(s, t, cx, cy, px, kol, e, o = {}) {
    const ctx = s.ctx; ctx.font = font(s, px, 800); const w = ctx.measureText(t).width + px * 1.6 + (o.ikona ? px * 1.2 : 0), h = px * 1.9;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); cien(s); ctx.fillStyle = kol; zaokr(ctx, -w / 2, -h / 2, w, h, o.r == null ? h / 2 : o.r); ctx.fill(); bezCienia(ctx);
    ctx.fillStyle = o.kt || kontrast(kol); ctx.fillText(t, -w / 2 + px * 0.8 + (o.ikona ? px * 1.2 : 0), 0); if (o.ikona) o.ikona(ctx, -w / 2 + px * 1.1, 0, px * 0.5, o.kt || kontrast(kol)); ctx.restore();
    return { w, h };
  }
  const ikZakladka = (c, x, y, r, k) => { c.fillStyle = k; c.beginPath(); c.moveTo(x - r * 0.6, y - r); c.lineTo(x + r * 0.6, y - r); c.lineTo(x + r * 0.6, y + r); c.lineTo(x, y + r * 0.45); c.lineTo(x - r * 0.6, y + r); c.closePath(); c.fill(); };
  const ikStrzalka = (c, x, y, r, k) => { c.strokeStyle = k; c.lineWidth = r * 0.35; c.lineCap = "round"; c.lineJoin = "round"; c.beginPath(); c.moveTo(x - r * 0.8, y + r * 0.6); c.quadraticCurveTo(x - r * 0.6, y - r * 0.5, x + r * 0.7, y - r * 0.4); c.stroke(); c.beginPath(); c.moveTo(x + r * 0.2, y - r * 0.9); c.lineTo(x + r * 0.8, y - r * 0.4); c.lineTo(x + r * 0.2, y + r * 0.1); c.stroke(); };
  const ikDymek = (c, x, y, r, k) => { c.fillStyle = k; c.beginPath(); c.ellipse(x, y - r * 0.1, r, r * 0.8, 0, 0, PI * 2); c.fill(); c.beginPath(); c.moveTo(x - r * 0.6, y + r * 0.4); c.lineTo(x - r * 0.9, y + r); c.lineTo(x - r * 0.1, y + r * 0.6); c.fill(); };
  const ikTelefon = (c, x, y, r, k) => { c.strokeStyle = k; c.lineWidth = r * 0.45; c.lineCap = "round"; c.beginPath(); c.arc(x, y, r * 0.8, PI * 0.6, PI * 1.4); c.stroke(); };
  const ikKoszyk = (c, x, y, r, k) => { c.strokeStyle = k; c.lineWidth = r * 0.25; c.lineJoin = "round"; c.beginPath(); c.moveTo(x - r, y - r * 0.6); c.lineTo(x - r * 0.6, y + r * 0.4); c.lineTo(x + r * 0.8, y + r * 0.4); c.lineTo(x + r, y - r * 0.3); c.closePath(); c.stroke(); c.fillStyle = k; c.beginPath(); c.arc(x - r * 0.4, y + r * 0.85, r * 0.2, 0, PI * 2); c.arc(x + r * 0.6, y + r * 0.85, r * 0.2, 0, PI * 2); c.fill(); };
  const ikPobierz = (c, x, y, r, k) => { c.strokeStyle = k; c.lineWidth = r * 0.3; c.lineCap = "round"; c.lineJoin = "round"; c.beginPath(); c.moveTo(x, y - r); c.lineTo(x, y + r * 0.4); c.moveTo(x - r * 0.55, y - r * 0.1); c.lineTo(x, y + r * 0.45); c.lineTo(x + r * 0.55, y - r * 0.1); c.moveTo(x - r, y + r); c.lineTo(x + r, y + r); c.stroke(); };
  const ikDM = (c, x, y, r, k) => { c.fillStyle = k; c.beginPath(); c.moveTo(x - r, y - r * 0.2); c.lineTo(x + r, y - r); c.lineTo(x + r * 0.3, y + r); c.lineTo(x, y + r * 0.1); c.closePath(); c.fill(); };
  ctaN("cta-zapisz-post", "Zapisz post na później", { tekst: "Zapisz na później", tekst2: "przyda się!" }, (s) => {
    const e = E.outBackMocno(T(s, 0, 0.45)), klik = s.t > 1.2 / s.p.tempo, nac = Math.abs(s.t - 1.2 / s.p.tempo) < 0.1 ? 0.9 : 1, px = 54 * s.u * s.p.rozmiar;
    przycisk(s, klik ? (s.p.tekst2 || "Zapisane ✓") : s.p.tekst, s.poz.x, s.poz.y, px, klik ? s.k.a : "#FFFFFF", e * nac, { ikona: ikZakladka, kt: klik ? kontrast(s.k.a) : "#111" });
    const m = E.inOutCubic(T(s, 0.4, 0.75)); if (s.t < 1.5 / s.p.tempo) kursor(s.ctx, lerp(s.poz.x + 260 * s.u, s.poz.x - 60 * s.u, m), lerp(s.poz.y + 260 * s.u, s.poz.y + 20 * s.u, m), 1.5 * s.u * s.p.rozmiar);
  });
  ctaN("cta-udostepnij", "Udostępnij znajomemu", { tekst: "Wyślij znajomemu", tekst2: "który musi to zobaczyć" }, (s) => {
    const e = E.outBackMocno(T(s, 0, 0.45)), px = 54 * s.u * s.p.rozmiar, k = Math.sin(s.t * 5) * 6 * s.u;
    przycisk(s, s.p.tekst, s.poz.x + k * 0, s.poz.y, px, s.k.g, e, { ikona: ikStrzalka });
    podpis(Object.assign({}, s, { p: Object.assign({}, s.p, { tekst: s.p.tekst2 }) }), s.poz.y + px * 1.5, E.outCubic(T(s, 0.4, 0.5)), 44);
  });
  ctaN("cta-komentarz", "Napisz w komentarzu", { tekst: "Napisz „TAK” w komentarzu", tekst2: "wyślę Ci poradnik" }, (s) => {
    const e = E.outBackMocno(T(s, 0, 0.45)), px = 52 * s.u * s.p.rozmiar, b = Math.sin(s.t * 4) * 0.04 + 1;
    przycisk(s, s.p.tekst, s.poz.x, s.poz.y, px, s.k.g, e * b, { ikona: ikDymek });
    podpis(Object.assign({}, s, { p: Object.assign({}, s.p, { tekst: s.p.tekst2 }) }), s.poz.y + px * 1.5, E.outCubic(T(s, 0.4, 0.5)), 44);
  });
  ctaN("cta-link-w-bio", "Link w bio ze strzałką", { tekst: "Link w bio", tekst2: "" }, (s) => {
    const ctx = s.ctx, e = E.outBackMocno(T(s, 0, 0.45)), px = 64 * s.u * s.p.rozmiar; przycisk(s, s.p.tekst, s.poz.x, s.poz.y, px, s.k.a, e);
    for (let i = 0; i < 3; i++) { const f = ((s.t * 1.4 + i / 3) % 1), y = s.poz.y - px * 1.4 - f * 160 * s.u; ctx.globalAlpha = s.alfa * e * Math.sin(f * PI); ctx.strokeStyle = s.k.t; ctx.lineWidth = 10 * s.u; ctx.lineCap = "round"; ctx.lineJoin = "round";
      ctx.beginPath(); ctx.moveTo(s.poz.x - 40 * s.u, y + 30 * s.u); ctx.lineTo(s.poz.x, y - 10 * s.u); ctx.lineTo(s.poz.x + 40 * s.u, y + 30 * s.u); ctx.stroke(); }
    ctx.globalAlpha = s.alfa;
  }, { pola: ["tekst"], czas: 3.5 });
  ctaN("cta-przesun", "Przesuń w górę", { tekst: "Przesuń w górę", tekst2: "" }, (s) => {
    const ctx = s.ctx, a = E.outCubic(T(s, 0, 0.4)), f = (s.t * 0.9) % 1, r = 46 * s.u * s.p.rozmiar, y = s.poz.y + 80 * s.u - E.inOutCubic(f) * 220 * s.u;
    ctx.globalAlpha = s.alfa * a * Math.sin(f * PI); ctx.fillStyle = "rgba(255,255,255,0.9)"; ctx.beginPath(); ctx.arc(s.poz.x, y, r, 0, PI * 2); ctx.fill();
    ctx.fillStyle = rgba("#FFFFFF", 0.25); zaokr(ctx, s.poz.x - r * 0.3, y, r * 0.6, E.inOutCubic(f) * 220 * s.u, r * 0.3); ctx.fill(); ctx.globalAlpha = s.alfa * a;
    ctx.font = font(s, 52 * s.u * s.p.rozmiar, 800); ctx.fillStyle = s.k.t; cien(s); const t = tekstP(s, s.p.tekst); ctx.fillText(t, s.poz.x - ctx.measureText(t).width / 2, s.poz.y + 200 * s.u); ctx.globalAlpha = s.alfa;
  }, { pola: ["tekst"], czas: 3.5 });
  ctaN("cta-kliknij-link", "Kliknij przycisk z kursorem", { tekst: "Sprawdź ofertę", tekst2: "" }, (s) => {
    const ctx = s.ctx, e = E.outBackMocno(T(s, 0, 0.45)), klik = 1.2 / s.p.tempo, nac = Math.abs(s.t - klik) < 0.1 ? 0.9 : 1, px = 58 * s.u * s.p.rozmiar;
    przycisk(s, s.p.tekst, s.poz.x, s.poz.y, px, s.k.g, e * nac, { r: 16 * s.u, ikona: ikStrzalka });
    if (s.t > klik) { const r = okno(s.t, klik, 0.5); ctx.strokeStyle = rgba("#FFFFFF", 1 - r); ctx.lineWidth = 5 * s.u; ctx.beginPath(); ctx.arc(s.poz.x + 60 * s.u, s.poz.y + 20 * s.u, 20 * s.u + r * 80 * s.u, 0, PI * 2); ctx.stroke(); }
    const m = E.inOutCubic(T(s, 0.4, klik * s.p.tempo - 0.45)); kursor(ctx, lerp(s.poz.x + 300 * s.u, s.poz.x + 60 * s.u, m), lerp(s.poz.y + 300 * s.u, s.poz.y + 20 * s.u, m), 1.6 * s.u * s.p.rozmiar * nac);
  }, { pola: ["tekst"] });
  ctaN("cta-zadzwon", "Zadzwoń teraz", { tekst: "Zadzwoń: 600 100 200", tekst2: "" }, (s) => {
    const e = E.outBackMocno(T(s, 0, 0.45)), px = 54 * s.u * s.p.rozmiar, dz = Math.sin(s.t * 26) * 0.08 * (Math.floor(s.t * 1.3) % 2);
    s.ctx.save(); s.ctx.translate(s.poz.x, s.poz.y); s.ctx.rotate(dz); s.ctx.translate(-s.poz.x, -s.poz.y); przycisk(s, s.p.tekst, s.poz.x, s.poz.y, px, "#22C55E", e, { ikona: ikTelefon, kt: "#FFFFFF" }); s.ctx.restore();
  }, { pola: ["tekst"] });
  ctaN("cta-dm", "Napisz do mnie", { tekst: "Napisz DM „START”", tekst2: "odpiszę dziś" }, (s) => {
    const e = E.outBackMocno(T(s, 0, 0.45)), px = 54 * s.u * s.p.rozmiar; przycisk(s, s.p.tekst, s.poz.x, s.poz.y, px, s.k.a, e, { ikona: ikDM });
    podpis(Object.assign({}, s, { p: Object.assign({}, s.p, { tekst: s.p.tekst2 }) }), s.poz.y + px * 1.5, E.outCubic(T(s, 0.4, 0.5)), 44);
  });
  ctaN("cta-kod-rabatowy", "Kod rabatowy do skopiowania", { tekst: "NADA20", tekst2: "-20% na pierwsze zamówienie" }, (s) => {
    const ctx = s.ctx, px = 70 * s.u * s.p.rozmiar, a = E.outBackMocno(T(s, 0, 0.45)); ctx.font = font(s, px, 900); const w = ctx.measureText(s.p.tekst).width + px * 2, h = px * 2;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); cien(s); ctx.fillStyle = "#FFFFFF"; zaokr(ctx, -w / 2, -h / 2, w, h, 16 * s.u); ctx.fill(); bezCienia(ctx);
    ctx.setLineDash([14 * s.u, 10 * s.u]); ctx.strokeStyle = s.k.g; ctx.lineWidth = 5 * s.u; zaokr(ctx, -w / 2 + 12 * s.u, -h / 2 + 12 * s.u, w - 24 * s.u, h - 24 * s.u, 10 * s.u); ctx.stroke(); ctx.setLineDash([]);
    const kop = s.t > 1.4 / s.p.tempo; ctx.fillStyle = "#111827"; ctx.fillText(s.p.tekst, -ctx.measureText(s.p.tekst).width / 2, 0);
    if (kop) { const k = E.outBackMocno(okno(s.t, 1.4 / s.p.tempo, 0.3)); ctx.save(); ctx.translate(0, -h * 0.85); ctx.scale(k, k); ctx.font = font(s, px * 0.4, 700); const tt = "Skopiowano ✓", tw = ctx.measureText(tt).width + 30 * s.u; ctx.fillStyle = "#111827"; zaokr(ctx, -tw / 2, -px * 0.35, tw, px * 0.7, px * 0.35); ctx.fill(); ctx.fillStyle = "#fff"; ctx.fillText(tt, -tw / 2 + 15 * s.u, 0); ctx.restore(); }
    ctx.restore(); podpis(Object.assign({}, s, { p: Object.assign({}, s.p, { tekst: s.p.tekst2 }) }), s.poz.y + h * 0.8, E.outCubic(T(s, 0.4, 0.5)), 44);
  }, { czas: 3.5 });
  ctaN("cta-newsletter", "Zapisz się: pole e-mail", { tekst: "twoj@email.pl", tekst2: "Zapisz się" }, (s) => {
    const ctx = s.ctx, px = 44 * s.u * s.p.rozmiar, W = s.W * 0.78, h = px * 2.2, x0 = s.poz.x - W / 2, a = E.outCubic(T(s, 0, 0.5)), t = s.p.tekst || "", n = Math.floor(clamp((s.t - 0.4 / s.p.tempo) / (t.length * 0.05 / s.p.tempo)) * t.length);
    ctx.globalAlpha = s.alfa * a; cien(s); ctx.fillStyle = "#FFFFFF"; zaokr(ctx, x0, s.poz.y - h / 2, W, h, h / 2); ctx.fill(); bezCienia(ctx);
    ctx.font = font(s, px, 500); ctx.fillStyle = "#374151"; ctx.fillText(t.slice(0, n), x0 + px, s.poz.y); ctx.font = font(s, px, 800); const bw = ctx.measureText(s.p.tekst2 || "").width + px * 1.6;
    const klik = s.t > (0.6 + t.length * 0.05) / s.p.tempo + 0.3; ctx.fillStyle = klik ? "#22C55E" : s.k.g; zaokr(ctx, x0 + W - bw - 8 * s.u, s.poz.y - h / 2 + 8 * s.u, bw, h - 16 * s.u, (h - 16 * s.u) / 2); ctx.fill();
    ctx.fillStyle = kontrast(klik ? "#22C55E" : s.k.g); ctx.fillText(klik ? "✓" : s.p.tekst2 || "", x0 + W - bw - 8 * s.u + px * 0.8, s.poz.y); ctx.globalAlpha = s.alfa;
  }, { czas: 4 });
  ctaN("cta-wiecej", "Sprawdź więcej ze strzałkami", { tekst: "Zobacz więcej", tekst2: "" }, (s) => {
    const ctx = s.ctx, a = E.outCubic(T(s, 0, 0.4)), px = 58 * s.u * s.p.rozmiar; ctx.font = font(s, px, 800); const t = tekstP(s, s.p.tekst), w = ctx.measureText(t).width;
    ctx.globalAlpha = s.alfa * a; cien(s); ctx.fillStyle = s.k.t; ctx.fillText(t, s.poz.x - w / 2 - px, s.poz.y); bezCienia(ctx);
    for (let i = 0; i < 3; i++) { const f = 0.35 + 0.65 * Math.max(0, Math.sin(s.t * 6 - i * 0.8)); ctx.globalAlpha = s.alfa * a * f; ctx.strokeStyle = s.k.a; ctx.lineWidth = 9 * s.u; ctx.lineCap = "round"; ctx.lineJoin = "round"; const x = s.poz.x + w / 2 - px * 0.6 + i * px * 0.6;
      ctx.beginPath(); ctx.moveTo(x, s.poz.y - px * 0.35); ctx.lineTo(x + px * 0.3, s.poz.y); ctx.lineTo(x, s.poz.y + px * 0.35); ctx.stroke(); }
    ctx.globalAlpha = s.alfa;
  }, { pola: ["tekst"] });
  ctaN("cta-pobierz", "Pobierz aplikację", { tekst: "Pobierz za darmo", tekst2: "" }, (s) => {
    const e = E.outBackMocno(T(s, 0, 0.45)), px = 56 * s.u * s.p.rozmiar, b = 1 + Math.sin(s.t * 5) * 0.03; przycisk(s, s.p.tekst, s.poz.x, s.poz.y, px, "#111827", e * b, { ikona: ikPobierz, kt: "#FFFFFF", r: 18 * s.u });
  }, { pola: ["tekst"] });
  ctaN("cta-kup-teraz", "Kup teraz z koszykiem", { tekst: "Kup teraz", tekst2: "dostawa jutro" }, (s) => {
    const e = E.outBackMocno(T(s, 0, 0.45)), px = 60 * s.u * s.p.rozmiar, ob = Math.sin(s.t * 3) * 0.03; s.ctx.save(); s.ctx.translate(s.poz.x, s.poz.y); s.ctx.rotate(ob); s.ctx.translate(-s.poz.x, -s.poz.y);
    przycisk(s, s.p.tekst, s.poz.x, s.poz.y, px, s.k.a, e, { ikona: ikKoszyk }); s.ctx.restore();
    podpis(Object.assign({}, s, { p: Object.assign({}, s.p, { tekst: s.p.tekst2 }) }), s.poz.y + px * 1.5, E.outCubic(T(s, 0.4, 0.5)), 42);
  });
  ctaN("cta-polub-obserwuj", "Polub i obserwuj", { tekst: "Polub", tekst2: "Obserwuj" }, (s) => {
    const ctx = s.ctx, px = 50 * s.u * s.p.rozmiar, a = E.outBackMocno(T(s, 0, 0.4)), b = E.outBackMocno(T(s, 0.25, 0.4)), k1 = s.t > 1.1 / s.p.tempo, k2 = s.t > 1.7 / s.p.tempo;
    const ikS = (c, x, y, r, k) => { c.fillStyle = k1 ? "#fff" : "#EF4444"; serce(c, x, y + r * 0.1, r * 0.95); c.fill(); };
    przycisk(s, s.p.tekst || "", s.poz.x - 170 * s.u * s.p.rozmiar, s.poz.y, px, k1 ? "#EF4444" : "#FFFFFF", a * (Math.abs(s.t - 1.1 / s.p.tempo) < 0.1 ? 0.9 : 1), { kt: k1 ? "#fff" : "#111", ikona: ikS });
    const ikP = (c, x, y, r, k) => { if (k2) ptaszek(c, x, y, r * 1.1, 1, "#fff", r * 0.3); else { c.strokeStyle = k; c.lineWidth = r * 0.3; c.beginPath(); c.moveTo(x - r * 0.7, y); c.lineTo(x + r * 0.7, y); c.moveTo(x, y - r * 0.7); c.lineTo(x, y + r * 0.7); c.stroke(); } };
    przycisk(s, k2 ? "Obserwujesz" : s.p.tekst2 || "", s.poz.x + 170 * s.u * s.p.rozmiar, s.poz.y, px, k2 ? "#3A3A3A" : s.k.g, b, { kt: k2 ? "#fff" : undefined, ikona: ikP });
    void ctx;
  }, { czas: 3 });
  ctaN("cta-oferta-czas", "Oferta kończy się za…", { tekst: "Oferta kończy się za", liczba: 59 }, (s) => {
    const ctx = s.ctx, px = 48 * s.u * s.p.rozmiar, a = E.outCubic(T(s, 0, 0.4)), sek = Math.max(0, Math.ceil((+s.p.liczba || 59) - s.t)), t = `00:${String(Math.floor(sek / 60)).padStart(2, "0")}:${String(sek % 60).padStart(2, "0")}`;
    ctx.globalAlpha = s.alfa * a; ctx.font = font(s, px, 700); ctx.fillStyle = s.k.t; cien(s); const t1 = tekstP(s, s.p.tekst); ctx.fillText(t1, s.poz.x - ctx.measureText(t1).width / 2, s.poz.y - px * 1.3);
    ctx.font = font(s, px * 2.2, 900); const w = ctx.measureText(t).width + px * 1.4, h = px * 3; ctx.fillStyle = "#DC2626"; zaokr(ctx, s.poz.x - w / 2, s.poz.y - h * 0.15, w, h, 18 * s.u); ctx.fill(); bezCienia(ctx);
    ctx.fillStyle = "#fff"; ctx.fillText(t, s.poz.x - ctx.measureText(t).width / 2, s.poz.y + h * 0.35); ctx.globalAlpha = s.alfa;
  }, { pola: ["tekst", "liczba"], czas: 4 });

  // ---------- przejścia (v17, cały kadr) ----------
  function przejscieN(id, nazwa, fn, o = {}) { dodaj({ id, nazwa, kat: "przejscia", czas: o.czas || 1.2, pola: o.pola || [], pelne: true, przyklad: {}, rysuj: fn }); }
  /* Faza wejścia (zakrywa) i wyjścia (odkrywa): a, b w 0–1. */
  const fazy = (s) => [E.inOutCubic(okno(s.t, 0, s.T * 0.5)), E.inOutCubic(okno(s.t, s.T * 0.5, s.T * 0.5))];
  przejscieN("przejscie-wipe-skos", "Przejście: ukośna zasłona", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), D = s.W + s.H; ctx.fillStyle = s.k.g; ctx.beginPath();
    const x1 = -s.H + D * a, x0 = -s.H + D * b; ctx.moveTo(x0, 0); ctx.lineTo(x1 + s.H, 0); ctx.lineTo(x1, s.H); ctx.lineTo(x0 - s.H, s.H); ctx.closePath(); ctx.fill();
  });
  przejscieN("przejscie-kurtyna", "Przejście: kurtyna", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), w = s.W / 2 * (a - b); ctx.fillStyle = s.k.g; ctx.fillRect(0, 0, w, s.H); ctx.fillStyle = ciemniej(s.k.g, 0.12); ctx.fillRect(s.W - w, 0, w, s.H);
  });
  przejscieN("przejscie-romb", "Przejście: romb", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), R = (s.W + s.H) * 0.75, c = warstwa(s, "romb", (x) => {
      const r = (q) => { x.beginPath(); x.moveTo(s.W / 2, s.H / 2 - q); x.lineTo(s.W / 2 + q, s.H / 2); x.lineTo(s.W / 2, s.H / 2 + q); x.lineTo(s.W / 2 - q, s.H / 2); x.closePath(); x.fill(); };
      x.fillStyle = s.k.a; r(R * a); if (b > 0) { x.globalCompositeOperation = "destination-out"; r(R * b); } }); ctx.drawImage(c, 0, 0);
  });
  przejscieN("przejscie-gwiazda", "Przejście: gwiazda", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), R = (s.W + s.H) * 1.1, c = warstwa(s, "gw", (x) => {
      x.fillStyle = s.k.g; gwiazda(x, s.W / 2, s.H / 2, 5, Math.max(0.1, R * a), Math.max(0.05, R * a * 0.5), -PI / 2 + a); x.fill();
      if (b > 0) { x.globalCompositeOperation = "destination-out"; gwiazda(x, s.W / 2, s.H / 2, 5, Math.max(0.1, R * b), Math.max(0.05, R * b * 0.5), -PI / 2 - b); x.fill(); } }); ctx.drawImage(c, 0, 0);
  });
  przejscieN("przejscie-kaskada", "Przejście: kaskada pasków", (s) => {
    const ctx = s.ctx, n = 8, h = s.H / n;
    for (let i = 0; i < n; i++) { const a = E.inOutCubic(okno(s.t, i * 0.04, s.T * 0.45 - i * 0.02)), b = E.inOutCubic(okno(s.t, s.T * 0.5 + i * 0.04, s.T * 0.45 - i * 0.02));
      ctx.fillStyle = i % 2 ? s.k.g : s.k.a; ctx.fillRect(s.W * b, i * h - 1, s.W * (a - b), h + 2); }
  });
  przejscieN("przejscie-plamy", "Przejście: kolorowe plamy", (s) => {
    const ctx = s.ctx, n = 14, [a, b] = fazy(s), kol = [s.k.g, s.k.a, ciemniej(s.k.g, 0.2)];
    for (let i = 0; i < n; i++) { const st = los(i * 2.1) * 0.35, r = Math.max(0, (a - st) / (1 - st)) * (s.W + s.H) * 0.45 * (0.7 + los(i) * 0.6) * (1 - b); if (r <= 0) continue;
      ctx.fillStyle = kol[i % 3]; ctx.beginPath(); ctx.arc(los(i * 3.7) * s.W, los(i * 5.3) * s.H, r, 0, PI * 2); ctx.fill(); }
  });
  przejscieN("przejscie-szachownica", "Przejście: szachownica", (s) => {
    const ctx = s.ctx, k = 6, w = s.W / k, h = Math.ceil(s.H / w);
    for (let i = 0; i < k; i++) for (let j = 0; j < h; j++) { const op = ((i + j) % 2) * 0.12 + los(i * 9 + j) * 0.08, a = E.outCubic(okno(s.t, op, s.T * 0.3)), b = E.inCubic(okno(s.t, s.T * 0.55 + op, s.T * 0.25)), q = Math.max(0, a - b);
      if (q <= 0) continue; ctx.fillStyle = (i + j) % 2 ? s.k.g : s.k.a; const sz = w * q; ctx.fillRect(i * w + (w - sz) / 2, j * w + (w - sz) / 2, sz + 1, sz + 1); }
  });
  przejscieN("przejscie-zaluzje", "Przejście: żaluzje", (s) => {
    const ctx = s.ctx, n = 10, w = s.W / n, [a, b] = fazy(s); ctx.fillStyle = s.k.g;
    for (let i = 0; i < n; i++) { const q = b > 0 ? 1 - b : a; ctx.fillRect(b > 0 ? i * w + w * b : i * w, 0, w * q + 1, s.H); }
  });
  przejscieN("przejscie-trzy-kolory", "Przejście: trzy kolory", (s) => {
    const ctx = s.ctx, kol = [s.k.a, s.k.g, s.k.tl];
    kol.forEach((k, i) => { const a = E.inOutCubic(okno(s.t, i * 0.08, s.T * 0.42)), b = E.inOutCubic(okno(s.t, s.T * 0.5 + i * 0.08, s.T * 0.42)); ctx.fillStyle = k; ctx.fillRect(0, s.H * (1 - a), s.W, s.H * (a - b)); });
  });
  przejscieN("przejscie-fala", "Przejście: fala", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), fala = (p, dir) => { ctx.beginPath(); const y = s.H * (1 - p) - 80 * s.u; ctx.moveTo(0, s.H); for (let x = 0; x <= s.W; x += 10) ctx.lineTo(x, y + Math.sin(x / s.W * PI * 3 + s.t * 8 * dir) * 60 * s.u); ctx.lineTo(s.W, s.H); ctx.closePath(); };
    ctx.save(); ctx.fillStyle = s.k.g; fala(a * 1.15, 1); ctx.fill(); ctx.restore();
    if (b > 0) { ctx.save(); ctx.globalCompositeOperation = "destination-out"; fala(b * 1.15, -1); ctx.fill(); ctx.restore(); }
  });
  przejscieN("przejscie-glitch", "Przejście: zakłócenia", (s) => {
    const ctx = s.ctx, f = Math.floor(s.t * 30), siła = Math.sin(clamp(s.t / s.T) * PI);
    for (let i = 0; i < 16; i++) { if (los(f * 17 + i) > siła) continue; const y = los(f * 7 + i) * s.H, h = (0.02 + los(f + i * 3) * 0.12) * s.H; ctx.fillStyle = [s.k.g, s.k.a, "#FFFFFF", "#000000"][i % 4]; ctx.globalAlpha = 0.85; ctx.fillRect((los(i + f) - 0.5) * 80 * s.u, y, s.W, h); }
    ctx.globalAlpha = 1; if (siła > 0.85) { ctx.fillStyle = s.k.g; ctx.fillRect(0, 0, s.W, s.H); }
  }, { czas: 0.8 });
  przejscieN("przejscie-trojkaty", "Przejście: trójkąty", (s) => {
    const ctx = s.ctx, k = 5, w = s.W / k, rz = Math.ceil(s.H / w) + 1;
    for (let j = 0; j < rz; j++) for (let i = 0; i <= k; i++) { const op = (j / rz) * 0.3, a = E.outBack(okno(s.t, op, s.T * 0.28)), b = E.inCubic(okno(s.t, s.T * 0.5 + op, s.T * 0.25)), q = Math.max(0, a - b);
      if (q <= 0) continue; const cx = i * w + (j % 2 ? w / 2 : 0), cy = j * w; ctx.fillStyle = (i + j) % 2 ? s.k.g : s.k.a; ctx.save(); ctx.translate(cx, cy); ctx.scale(q, q); ctx.rotate(j % 2 ? PI : 0);
      ctx.beginPath(); ctx.moveTo(0, -w * 0.9); ctx.lineTo(w * 0.9, w * 0.6); ctx.lineTo(-w * 0.9, w * 0.6); ctx.closePath(); ctx.fill(); ctx.restore(); }
  });
  przejscieN("przejscie-zoom-ramka", "Przejście: wjazd w ramkę", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), q = Math.max(0, a - b), m = s.W * 0.5 * q;
    const c = warstwa(s, "ramka", (x) => { x.fillStyle = s.k.g; x.fillRect(0, 0, s.W, s.H); if (q < 1) { x.globalCompositeOperation = "destination-out"; x.fillRect(m, m * s.H / s.W, s.W - 2 * m, s.H - 2 * m * s.H / s.W); } });
    if (q > 0) ctx.drawImage(c, 0, 0);
  });
  przejscieN("przejscie-blysk-kolor", "Przejście: błysk koloru", (s) => {
    const ctx = s.ctx, q = Math.sin(clamp(s.t / s.T) * PI); ctx.globalAlpha = q; ctx.fillStyle = s.k.a; ctx.fillRect(0, 0, s.W, s.H); ctx.globalAlpha = 1;
  }, { czas: 0.6 });

  // =====================================================================
  // ---------- wersja 18: kolejne presety we wszystkich kategoriach ----------
  // =====================================================================
  const U = (s, k) => k * s.u * s.p.rozmiar;
  const xWyr = (s, w, x) => { x = x == null ? s.poz.x : x; return s.poz.align === "left" ? x : s.poz.align === "right" ? x - w : x - w / 2; };
  /* Jedna linia tekstu z *wyróżnieniami* od punktu x (lewa krawędź). Zwraca szerokość. */
  function linia(s, t, x, y, px, waga, kol, kolWyr, ctx = s.ctx) {
    ctx.font = font(s, px, waga); const sl = slowaZ(tekstP(s, t)), sp = ctx.measureText(" ").width; let xx = x;
    sl.forEach((w) => { ctx.fillStyle = w.wyr ? (kolWyr || s.k.a) : (kol || s.k.t); ctx.fillText(w.t, xx, y); xx += ctx.measureText(w.t).width + sp; });
    return Math.max(0, xx - sp - x);
  }
  function szerLinii(s, t, px, waga) {
    const ctx = s.ctx; ctx.font = font(s, px, waga); const sl = slowaZ(tekstP(s, t)), sp = ctx.measureText(" ").width;
    return sl.reduce((a, w) => a + ctx.measureText(w.t).width, 0) + sp * Math.max(0, sl.length - 1);
  }
  const bezGw = (t) => String(t || "").replace(/\*/g, "");
  const inicjaly = (t) => String(t || "?").trim().split(/\s+/).map((x) => Array.from(x)[0] || "").join("").slice(0, 2).toLocaleUpperCase("pl");
  const emojiFont = (px) => `${Math.round(px)}px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif`;
  function karta(s, x, y, w, h, r, kol, ctx = s.ctx, moc = 1) { ctx.save(); cien(s, ctx, moc); ctx.fillStyle = kol; zaokr(ctx, x, y, w, h, r); ctx.fill(); ctx.restore(); }
  const jasna = (s) => (jasnosc(s.k.tl) > 0.6 ? s.k.tl : "#FFFFFF");
  const ciemnyNa = (kol) => (jasnosc(kol) > 0.6 ? "#111111" : "#FFFFFF");
  function warstwaTekstu(s, nr, ul, kol) {
    return warstwa(s, nr, (x) => { x.font = ul.font; x.textBaseline = "middle"; ul.slowa.forEach((w) => piszSlowo(s, w, kol, x)); });
  }
  /* Odręczna linia: punkty z drganiem (stałym w czasie). */
  function odrecznie(pkt, drg, z) { return pkt.map((p, i) => [p[0] + (los(i * 3.1 + z) - 0.5) * drg, p[1] + (los(i * 7.3 + z) - 0.5) * drg]); }
  function obwodProst(x, y, w, h, n) {
    const p = [], L = 2 * (w + h);
    for (let i = 0; i <= n; i++) { let d = (i / n) * L; if (d < w) p.push([x + d, y]); else if ((d -= w) < h) p.push([x + w, y + d]); else if ((d -= h) < w) p.push([x + w - d, y + h]); else { d -= w; p.push([x, y + h - d]); } }
    return p;
  }
  function krzyzyk(ctx, x, y, r, e, kolor, gr) {
    ctx.strokeStyle = kolor; ctx.lineWidth = gr; ctx.lineCap = "round"; const a = clamp(e * 2), b = clamp(e * 2 - 1);
    ctx.beginPath(); ctx.moveTo(x - r, y - r); ctx.lineTo(x - r + 2 * r * a, y - r + 2 * r * a); if (b > 0) { ctx.moveTo(x + r, y - r); ctx.lineTo(x + r - 2 * r * b, y - r + 2 * r * b); } ctx.stroke();
  }
  /* Łuk od kąta a0 do a1; pełne koło rysowane od 0 do 2π (@napi-rs/canvas gubi łuk 2π zaczęty od innego kąta). */
  function luk(ctx, x, y, r, a0, a1) { if (a1 - a0 >= PI * 2 - 1e-4) ctx.arc(x, y, r, 0, PI * 2); else ctx.arc(x, y, r, a0, a1); }
  function tekstN(id, nazwa, przyklad, fn, o = {}) { dodaj({ id, nazwa, kat: "tekst", czas: o.czas || 3.2, pola: o.pola || ["tekst"], dom: o.dom, przyklad, rysuj: fn }); }
  const ostatnie = (ul) => ul.linie[ul.linie.length - 1];
  const celWyr = (ul) => { const w = ul.slowa.filter((x) => x.wyr); return w.length ? w : ostatnie(ul).slowa; };
  const grupujLinie = (sl) => { const g = {}; sl.forEach((w) => (g[w.li] = g[w.li] || []).push(w)); return Object.values(g); };

  // ---------- teksty (v18) ----------
  tekstN("tekst-marker-reczny", "Zakreślacz odręczny", { tekst: "Najważniejsza *rzecz w filmie*" }, (s) => {
    const ul = uloz(s, s.p.tekst, 96 * s.u * s.p.rozmiar, { lh: 1.25 }), ctx = s.ctx; if (!ul.slowa.length) return;
    const wej = E.outCubic(T(s, 0, 0.4)), grupy = grupujLinie(celWyr(ul)), zasieg = new Map();
    grupy.forEach((g, gi) => {
      const e = E.inOutCubic(T(s, 0.4 + gi * 0.35, 0.45)), x0 = g[0].x - 16 * s.u, x1 = g[g.length - 1].x + g[g.length - 1].w + 16 * s.u, y = g[0].y + ul.px * 0.04, L = (x1 - x0) * e;
      g.forEach((w) => zasieg.set(w, x0 + L >= w.x + w.w * 0.5));
      if (e <= 0) return;
      ctx.save(); ctx.strokeStyle = s.k.a; ctx.lineCap = "round"; ctx.lineJoin = "round";
      [[-ul.px * 0.02, 0.9, 0.78], [ul.px * 0.1, 0.45, 0.62]].forEach(([dy, a, k]) => {
        ctx.globalAlpha = s.alfa * a; ctx.lineWidth = ul.px * k; ctx.beginPath();
        for (let i = 0; i <= 20; i++) { const xx = x0 + L * i / 20, yy = y + dy + Math.sin(i * 1.3 + gi) * 2.5 * s.u; i ? ctx.lineTo(xx, yy) : ctx.moveTo(xx, yy); }
        ctx.stroke();
      });
      ctx.restore();
    });
    ctx.font = ul.font; ctx.globalAlpha = s.alfa * wej;
    ul.slowa.forEach((w) => { ctx.fillStyle = zasieg.get(w) ? kontrast(s.k.a) : s.k.t; ctx.fillText(w.t, w.x, w.y + (1 - wej) * 24 * s.u); });
    ctx.globalAlpha = s.alfa;
  });
  tekstN("tekst-podkreslenie-kolor", "Podkreślenie przelewa kolor na tekst", { tekst: "Kolor płynie *za linią*" }, (s) => {
    const ul = uloz(s, s.p.tekst, 96 * s.u * s.p.rozmiar, { lh: 1.3 }), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font;
    const wej = E.outCubic(T(s, 0, 0.45)), n = ul.linie.length;
    ctx.save(); ctx.globalAlpha = s.alfa * wej; cien(s); ul.slowa.forEach((w) => { ctx.fillStyle = s.k.t; ctx.fillText(w.t, w.x, w.y + (1 - wej) * 20 * s.u); }); ctx.restore();
    ul.linie.forEach((l, i) => {
      const e = E.inOutCubic(T(s, 0.35 + i * 0.3, 0.6)); if (e <= 0) return; const xg = l.x0 + l.w * e;
      ctx.fillStyle = s.k.a; zaokr(ctx, l.x0, l.y + ul.px * 0.56, Math.max(1, l.w * e), 9 * s.u * s.p.rozmiar, 4 * s.u); ctx.fill();
      ctx.save(); ctx.beginPath(); ctx.rect(l.x0 - 10 * s.u, l.y - ul.lh * 0.6, xg - l.x0 + 10 * s.u, ul.lh * 1.2); ctx.clip();
      l.slowa.forEach((w) => { ctx.fillStyle = w.wyr ? s.k.g : s.k.a; ctx.fillText(w.t, w.x, w.y); }); ctx.restore();
    });
    void n;
  });
  tekstN("tekst-podkreslenie-podwojne", "Podwójne podkreślenie odręczne", { tekst: "Tego *nie przegap*" }, (s) => {
    const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar, { lh: 1.35 }), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font; cien(s);
    ul.slowa.forEach((w) => { const e = E.outBack(T(s, w.i * 0.08, 0.4)); if (e <= 0) return; ctx.save(); ctx.globalAlpha *= clamp(e * 2); ctx.translate(w.x + w.w / 2, w.y); ctx.scale(e, e); piszSlowo(s, w, null, ctx, -w.x - w.w / 2, -w.y); ctx.restore(); });
    bezCienia(ctx);
    grupujLinie(celWyr(ul)).forEach((g, gi) => {
      const x0 = g[0].x - 8 * s.u, x1 = g[g.length - 1].x + g[g.length - 1].w + 8 * s.u, y = g[0].y + ul.px * 0.6, d = 0.55 + gi * 0.3;
      ctx.strokeStyle = s.k.a; ctx.lineCap = "round"; ctx.lineWidth = 8 * s.u * s.p.rozmiar;
      [[0, 0, 1], [ul.px * 0.2, 0.25, 0.8]].forEach(([dy, op, dl], k) => {
        const e = E.inOutCubic(T(s, d + op, 0.4)); if (e <= 0) return;
        const pkt = []; for (let i = 0; i <= 16; i++) { const f = i / 16; pkt.push([x0 + (x1 - x0) * (k ? 0.08 + f * dl : f), y + dy + Math.sin(f * PI * 1.5 + k) * 4 * s.u - (k ? 0 : f * 6 * s.u)]); }
        sciezkaCzesc(ctx, pkt, e); ctx.stroke();
      });
    });
  });
  tekstN("tekst-wypelnienie-fala", "Tekst napełnia się kolorem", { tekst: "PEŁNA *MOC*", wielkie: true, waga: 900 }, (s) => {
    const ul = uloz(s, s.p.tekst, 140 * s.u * s.p.rozmiar), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font;
    const a = E.outCubic(T(s, 0, 0.35)), e = E.inOutCubic(T(s, 0.25, 1.3)), top = ul.y - ul.px * 0.2, bot = ul.y + ul.h + ul.px * 0.1, poz = lerp(bot, top - ul.px * 0.15, e);
    ctx.save(); ctx.globalAlpha = s.alfa * a; ctx.lineWidth = 3 * s.u; ctx.lineJoin = "round"; ctx.strokeStyle = rgba(s.k.t, 0.85); ul.slowa.forEach((w) => ctx.strokeText(w.t, w.x, w.y)); ctx.restore();
    const c = warstwa(s, "wypelnienie", (x) => {
      x.font = ul.font; x.textBaseline = "middle"; ul.slowa.forEach((w) => { x.fillStyle = w.wyr ? s.k.a : s.k.t; x.fillText(w.t, w.x, w.y); });
      x.globalCompositeOperation = "destination-in"; x.beginPath(); x.moveTo(0, s.H);
      for (let xx = 0; xx <= s.W; xx += 12) x.lineTo(xx, poz + Math.sin(xx / (70 * s.u) + s.t * 6) * 10 * s.u * (1 - e * 0.7));
      x.lineTo(s.W, s.H); x.closePath(); x.fill();
    });
    ctx.drawImage(c, 0, 0);
  });
  /* Słowa z listy zmieniają się w miejscu: wspólny licznik. */
  function zmienne(s) {
    const el = lista(s.p.lista); const n = Math.max(1, el.length), dl = Math.max(0.5, (s.T - s.p.wyjscie - 0.3) / n);
    const i = Math.min(n - 1, Math.floor(s.t / dl)), lt = s.t - i * dl; return { el: el.length ? el : [""], n, dl, i, lt };
  }
  tekstN("tekst-kostka-slow", "Zmieniające się słowo (kostka)", { tekst: "Montaż, który jest", lista: "szybki; prosty; *twój*" }, (s) => {
    const ctx = s.ctx, px = 100 * s.u * s.p.rozmiar, z = zmienne(s), y1 = s.poz.y - px * 0.62, y2 = s.poz.y + px * 0.62, a = E.outCubic(T(s, 0, 0.4));
    if (s.p.tekst) { const w = szerLinii(s, s.p.tekst, px * 0.8, s.p.waga); ctx.save(); ctx.globalAlpha = s.alfa * a; cien(s); linia(s, s.p.tekst, xWyr(s, w), y1 + (1 - a) * 20 * s.u, px * 0.8, s.p.waga); ctx.restore(); }
    const rys = (t, k, kier) => { // k: 1 = widoczne, 0 = obrócone
      const tt = bezGw(t), w = szerLinii(s, tt, px * 1.2, 900); if (k <= 0.001) return;
      ctx.save(); ctx.translate(0, y2 + kier * (1 - k) * px * 0.6); ctx.scale(1, k); ctx.globalAlpha = s.alfa * clamp(k * 1.5);
      cien(s); ctx.font = font(s, px * 1.2, 900); ctx.fillStyle = /\*/.test(t) ? s.k.g : s.k.a; ctx.fillText(tekstP(s, tt), xWyr(s, w), 0);
      ctx.restore();
    };
    const pr = 0.32 / s.p.tempo, e = E.inOutCubic(okno(z.lt, 0, pr));
    if (z.i === 0) rys(z.el[0], E.outBack(T(s, 0.15, 0.45)), 1);
    else { rys(z.el[z.i - 1], 1 - e, -1); rys(z.el[z.i], e, 1); }
  }, { pola: ["tekst", "lista"], czas: 4 });
  tekstN("tekst-slowo-w-ramce", "Słowo w ramce zmienia się", { tekst: "Dla", lista: "twórców; firm; *ciebie*" }, (s) => {
    const ctx = s.ctx, px = 92 * s.u * s.p.rozmiar, z = zmienne(s), pad = px * 0.32, a = E.outCubic(T(s, 0, 0.4));
    const t0 = s.p.tekst ? tekstP(s, bezGw(s.p.tekst)) + " " : "", wp = t0 ? szerLinii(s, t0, px, s.p.waga) + px * 0.28 : 0;
    const sz = (t) => szerLinii(s, bezGw(t), px, 900) + pad * 2, pr = 0.38 / s.p.tempo, e = z.i ? E.inOutCubic(okno(z.lt, 0, pr)) : 1;
    const bw = z.i ? lerp(sz(z.el[z.i - 1]), sz(z.el[z.i]), e) : sz(z.el[0]) * E.outBack(T(s, 0.15, 0.5));
    const x0 = xWyr(s, wp + bw), y = s.poz.y, h = px * 1.45;
    ctx.save(); ctx.globalAlpha = s.alfa * a; cien(s); if (t0) linia(s, t0, x0, y, px, s.p.waga); ctx.restore();
    if (bw <= 1) return; const bx = x0 + wp;
    karta(s, bx, y - h / 2, bw, h, 16 * s.u, s.k.g);
    ctx.save(); ctx.beginPath(); ctx.rect(bx, y - h / 2, bw, h); ctx.clip(); ctx.font = font(s, px, 900); ctx.fillStyle = kontrast(s.k.g);
    const pisz = (t, dy) => { const tt = tekstP(s, bezGw(t)); ctx.fillStyle = /\*/.test(t) ? s.k.a : kontrast(s.k.g); ctx.fillText(tt, bx + pad, y + dy); };
    if (z.i) { pisz(z.el[z.i - 1], -e * h); pisz(z.el[z.i], (1 - e) * h); } else pisz(z.el[0], 0);
    ctx.restore();
  }, { pola: ["tekst", "lista"], czas: 4 });
  tekstN("tekst-maszyna-kasowanie", "Pisanie i kasowanie haseł", { tekst: "Robimy", lista: "rolki; reklamy; *teledyski*" }, (s) => {
    const ctx = s.ctx, px = 90 * s.u * s.p.rozmiar, el = lista(s.p.lista).map(bezGw), tp = s.p.tempo; if (!el.length) el.push("");
    let t = s.t - 0.2, akt = "", i = 0;
    for (i = 0; i < el.length; i++) {
      const zn = Array.from(el[i]), tw = zn.length * 0.06 / tp, st = 0.75, ks = i < el.length - 1 ? zn.length * 0.03 / tp : 0;
      if (t < tw) { akt = zn.slice(0, Math.floor(clamp(t / tw) * zn.length)).join(""); break; }
      if (t < tw + st || i === el.length - 1) { akt = el[i]; break; }
      if (t < tw + st + ks) { akt = zn.slice(0, Math.ceil((1 - (t - tw - st) / ks) * zn.length)).join(""); break; }
      t -= tw + st + ks + 0.12 / tp;
    }
    i = Math.min(i, el.length - 1);
    const wyr = /\*/.test(lista(s.p.lista)[i] || ""), t0 = s.p.tekst ? tekstP(s, s.p.tekst) + " " : "";
    ctx.font = font(s, px, s.p.waga); const w0 = ctx.measureText(t0).width, wMax = Math.max(...el.map((x) => ctx.measureText(tekstP(s, x)).width)), x0 = xWyr(s, w0 + wMax);
    cien(s); ctx.fillStyle = s.k.t; ctx.fillText(t0, x0, s.poz.y); ctx.fillStyle = wyr ? s.k.g : s.k.a; const ta = tekstP(s, akt); ctx.fillText(ta, x0 + w0, s.poz.y); bezCienia(ctx);
    if (Math.floor(s.t * 2.4) % 2 === 0 || akt.length < el[i].length) { const xw = ctx.measureText(ta).width; ctx.fillStyle = s.k.a; ctx.fillRect(x0 + w0 + xw + 6 * s.u, s.poz.y - px * 0.45, 6 * s.u, px * 0.9); }
  }, { pola: ["tekst", "lista"], czas: 5 });
  tekstN("tekst-terminal", "Okno terminala z poleceniami", { lista: "npm run montaz\nrenderuję rolkę…\n*gotowe w 12 s*", font: "JetBrains Mono", waga: 600 }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista), px = 44 * s.u * s.p.rozmiar, lh = px * 1.6, W = Math.min(s.W * 0.86, 1500 * s.u), h = lh * (el.length + 0.6) + px * 1.5;
    const x0 = s.poz.x - W / 2, y0 = s.poz.y - h / 2, a = E.outBack(T(s, 0, 0.45));
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(lerp(0.85, 1, a), lerp(0.85, 1, a)); ctx.translate(-s.poz.x, -s.poz.y); ctx.globalAlpha = s.alfa * clamp(a * 2);
    karta(s, x0, y0, W, h, 18 * s.u, rgba(s.k.tl, 0.94)); ctx.fillStyle = rgba(s.k.t, 0.08); zaokr(ctx, x0, y0, W, px * 1.2, 18 * s.u); ctx.fill();
    ["#FF5F57", "#FEBC2E", "#28C840"].forEach((k, i) => { ctx.fillStyle = k; ctx.beginPath(); ctx.arc(x0 + 36 * s.u + i * 32 * s.u, y0 + px * 0.6, 9 * s.u, 0, PI * 2); ctx.fill(); });
    let t = s.t - 0.45 / s.p.tempo, yy = y0 + px * 1.2 + lh * 0.8, kx = x0 + 40 * s.u, ky = yy; ctx.font = font(s, px, s.p.waga);
    for (let i = 0; i < el.length && t > 0; i++) {
      const tx = bezGw(el[i]), zn = Array.from(tx), dl = zn.length * 0.035 / s.p.tempo, n = Math.floor(clamp(t / dl) * zn.length), wyr = /\*/.test(el[i]);
      ctx.fillStyle = s.k.a; ctx.fillText(i === 0 ? "$" : ">", x0 + 40 * s.u, yy); ctx.fillStyle = wyr ? s.k.a : s.k.t;
      const vis = zn.slice(0, n).join(""); ctx.fillText(vis, x0 + 40 * s.u + px * 1.1, yy); kx = x0 + 40 * s.u + px * 1.1 + ctx.measureText(vis).width; ky = yy;
      t -= dl + 0.35 / s.p.tempo; yy += lh;
    }
    if (Math.floor(s.t * 2.5) % 2 === 0) { ctx.fillStyle = s.k.t; ctx.fillRect(kx + 6 * s.u, ky - px * 0.45, px * 0.55, px * 0.9); }
    ctx.restore();
  }, { pola: ["lista"], czas: 5 });
  tekstN("tekst-stos-kontur", "Nagłówek: linie pełne i konturowe", { tekst: "TWÓJ\nNOWY\n*KANAŁ*", wielkie: true, waga: 900 }, (s) => {
    const ul = uloz(s, s.p.tekst, 150 * s.u * s.p.rozmiar, { lh: 0.98, waga: 900 }), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font;
    ul.linie.forEach((l, i) => {
      const e = E.outQuint(T(s, i * 0.12, 0.65)), dx = (1 - e) * (i % 2 ? 1 : -1) * s.W * 0.6, kontur = i % 2 === 1;
      ctx.save(); ctx.globalAlpha = s.alfa * clamp(e * 2); ctx.translate(dx, 0);
      l.slowa.forEach((w) => {
        if (kontur && !w.wyr) { ctx.lineWidth = 4 * s.u * s.p.rozmiar; ctx.lineJoin = "round"; ctx.strokeStyle = s.k.t; ctx.strokeText(w.t, w.x, w.y); }
        else { cien(s); piszSlowo(s, w); bezCienia(ctx); }
      });
      ctx.restore();
    });
  });
  tekstN("tekst-echo-kontur", "Echo konturów", { tekst: "*ECHO*", wielkie: true, waga: 900 }, (s) => {
    const ul = uloz(s, s.p.tekst, 150 * s.u * s.p.rozmiar), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font;
    const cx = ul.x + ul.w / 2, cy = ul.y + ul.h / 2, e = E.outCubic(T(s, 0, 0.9)), puls = Math.sin(s.t * 3) * 0.5 + 0.5;
    for (let k = 5; k >= 1; k--) {
      const sk = 1 + k * (0.09 + 0.25 * (1 - e)) * (0.7 + 0.3 * puls), op = (1 - k / 6) * 0.55 * clamp(e * 3);
      ctx.save(); ctx.translate(cx, cy); ctx.scale(sk, sk); ctx.translate(-cx, -cy); ctx.globalAlpha = s.alfa * op; ctx.lineWidth = 2.5 * s.u / sk; ctx.strokeStyle = k % 2 ? s.k.a : s.k.g;
      ul.slowa.forEach((w) => ctx.strokeText(w.t, w.x, w.y)); ctx.restore();
    }
    const a = E.outBack(T(s, 0.1, 0.5)); ctx.save(); ctx.translate(cx, cy); ctx.scale(a, a); ctx.translate(-cx, -cy); cien(s); ul.slowa.forEach((w) => piszSlowo(s, w)); ctx.restore();
  });
  tekstN("tekst-paski-pionowe", "Tekst składa się z pionowych pasków", { tekst: "Składamy *całość*" }, (s) => {
    const ul = uloz(s, s.p.tekst, 104 * s.u * s.p.rozmiar), ctx = s.ctx; if (!ul.slowa.length) return;
    const c = warstwaTekstu(s, "paski-pion", ul), n = 14, x0 = ul.x - 10 * s.u, sw = (ul.w + 20 * s.u) / n, y0 = ul.y - ul.lh * 0.3, h = ul.h + ul.lh * 0.6;
    ctx.save(); cien(s);
    for (let i = 0; i < n; i++) {
      const e = E.outQuint(T(s, (i % 2 ? n - i : i) * 0.025, 0.7)); if (e <= 0) continue; const dy = (1 - e) * (i % 2 ? 1 : -1) * h * 1.1, x = x0 + i * sw;
      ctx.save(); ctx.beginPath(); ctx.rect(x, y0, sw + 0.5, h); ctx.clip(); ctx.globalAlpha = s.alfa * clamp(e * 1.5); ctx.drawImage(c, x, y0 - dy, sw + 0.5, h, x, y0, sw + 0.5, h); ctx.restore();
    }
    ctx.restore();
  });
  tekstN("tekst-kafelki", "Tekst odsłania się kafelkami", { tekst: "Odkryj *nowość*" }, (s) => {
    const ul = uloz(s, s.p.tekst, 104 * s.u * s.p.rozmiar), ctx = s.ctx; if (!ul.slowa.length) return;
    const c = warstwaTekstu(s, "kafelki", ul), k = ul.px * 0.36, x0 = ul.x - 10 * s.u, y0 = ul.y - ul.lh * 0.15, nx = Math.ceil((ul.w + 20 * s.u) / k), ny = Math.ceil((ul.h + ul.lh * 0.3) / k);
    for (let j = 0; j < ny; j++) for (let i = 0; i < nx; i++) {
      const st = (i / nx) * 0.45 + los(i * 31 + j * 17) * 0.35, e = T(s, st, 0.22); if (e <= 0) continue; const x = x0 + i * k, y = y0 + j * k;
      ctx.drawImage(c, x, y, k + 0.5, k + 0.5, x, y, k + 0.5, k + 0.5);
      if (e < 1) { const q = k * (1 - E.inCubic(e)); ctx.fillStyle = (i + j) % 2 ? s.k.a : s.k.g; ctx.fillRect(x + (k - q) / 2, y + (k - q) / 2, q, q); }
    }
  });
  tekstN("tekst-kolo-odkrycie", "Odkrycie kołem z obręczą", { tekst: "Wielkie *otwarcie*" }, (s) => {
    const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font;
    const cx = ul.x + ul.w / 2, cy = ul.y + ul.h / 2, R = Math.hypot(ul.w / 2, ul.h / 2) + 40 * s.u, e = E.inOutCubic(T(s, 0.05, 0.75)), r = Math.max(0.1, R * e);
    ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, r, 0, PI * 2); ctx.clip(); cien(s); ul.slowa.forEach((w) => piszSlowo(s, w)); ctx.restore();
    const o = T(s, 0.05, 1.1); if (o > 0 && o < 1) { ctx.strokeStyle = rgba(s.k.a, 1 - E.inCubic(o)); ctx.lineWidth = 10 * s.u * (1 - o * 0.6); ctx.beginPath(); ctx.arc(cx, cy, Math.max(0.1, R * E.outCubic(o) * 1.08), 0, PI * 2); ctx.stroke(); }
  });
  tekstN("tekst-ukosne-ciecie", "Ukośne odsłonięcie z belką", { tekst: "Szybko i *konkretnie*" }, (s) => {
    const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font;
    const sk = ul.h * 0.5 + 40 * s.u, x0 = ul.x - sk - 40 * s.u, x1 = ul.x + ul.w + sk + 40 * s.u, e = E.inOutCubic(T(s, 0, 0.8)), xg = lerp(x0, x1, e), y0 = ul.y - 40 * s.u, y1 = ul.y + ul.h + 40 * s.u, bw = 34 * s.u * (1 - E.inCubic(T(s, 0.6, 0.4)));
    ctx.save(); ctx.beginPath(); ctx.moveTo(0, y0); ctx.lineTo(xg + sk, y0); ctx.lineTo(xg - sk, y1); ctx.lineTo(0, y1); ctx.closePath(); ctx.clip(); cien(s); ul.slowa.forEach((w) => piszSlowo(s, w)); ctx.restore();
    if (bw > 0.5) { ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.moveTo(xg + sk, y0); ctx.lineTo(xg + sk + bw, y0); ctx.lineTo(xg - sk + bw, y1); ctx.lineTo(xg - sk, y1); ctx.closePath(); ctx.fill(); }
  });
  function pasTekstu(s, t, cy, kat, kol, kt, pred, e, ctx = s.ctx) {
    const px = 64 * s.u * s.p.rozmiar, h = px * 1.7, D = Math.hypot(s.W, s.H) * 1.2; ctx.font = font(s, px, 900);
    const fr = tekstP(s, bezGw(t)) + "  •  ", fw = Math.max(10, ctx.measureText(fr).width), off = ((s.t * pred * 160 * s.u) % fw + fw) % fw;
    ctx.save(); ctx.translate(s.W / 2, cy); ctx.rotate(kat); ctx.beginPath(); ctx.rect(-D / 2, -h / 2, D * e, h); ctx.clip(); cien(s); ctx.fillStyle = kol; ctx.fillRect(-D / 2, -h / 2, D, h); bezCienia(ctx);
    ctx.fillStyle = kt; for (let x = -D / 2 - fw + off; x < D / 2; x += fw) ctx.fillText(fr, x, 0);
    return { h, D };
  }
  tekstN("tekst-tasma", "Taśma ostrzegawcza z napisem", { tekst: "UWAGA NOWOŚĆ", wielkie: true }, (s) => {
    const ctx = s.ctx, e = E.outQuint(T(s, 0, 0.6)), { h, D } = pasTekstu(s, s.p.tekst, s.poz.y, -0.12, s.k.a, kontrast(s.k.a), -1, e);
    const pas = h * 0.16, kt = kontrast(s.k.a);
    [-h / 2, h / 2 - pas].forEach((y) => { ctx.save(); ctx.beginPath(); ctx.rect(-D / 2, y, D, pas); ctx.clip(); ctx.fillStyle = kt; const off = (s.t * 60 * s.u) % (pas * 2);
      for (let x = -D / 2 - pas * 2 + off; x < D / 2; x += pas * 2) { ctx.beginPath(); ctx.moveTo(x, y + pas); ctx.lineTo(x + pas, y); ctx.lineTo(x + pas * 1.8, y); ctx.lineTo(x + pas * 0.8, y + pas); ctx.closePath(); ctx.fill(); } ctx.restore(); });
    ctx.restore();
  }, { czas: 4 });
  tekstN("tekst-dwa-pasy", "Dwa przewijane pasy na krzyż", { tekst: "NOWA KOLEKCJA", tekst2: "TYLKO ONLINE", wielkie: true }, (s) => {
    pasTekstu(s, s.p.tekst2 || s.p.tekst, s.poz.y, 0.14, s.k.g, kontrast(s.k.g), 1, E.outQuint(T(s, 0.1, 0.6))); s.ctx.restore();
    pasTekstu(s, s.p.tekst, s.poz.y, -0.14, s.k.a, kontrast(s.k.a), -1, E.outQuint(T(s, 0, 0.6))); s.ctx.restore();
  }, { pola: ["tekst", "tekst2"], czas: 4 });
  tekstN("tekst-skupienie", "Skupienie na słowie kluczowym", { tekst: "Liczy się tylko *jakość*" }, (s) => {
    const ul = uloz(s, s.p.tekst, 96 * s.u * s.p.rozmiar), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font;
    const f = E.inOutCubic(T(s, 0.8, 0.5)), cel = celWyr(ul);
    ul.slowa.forEach((w) => {
      const e = E.outCubic(T(s, w.i * 0.07, 0.45)); if (e <= 0) return; const jest = cel.includes(w), sk = jest ? 1 + 0.08 * E.outBack(f) : 1 - 0.04 * f;
      ctx.save(); ctx.translate(w.x + w.w / 2, w.y + (1 - e) * 26 * s.u); ctx.scale(sk, sk); ctx.globalAlpha = s.alfa * e * (jest ? 1 : 1 - 0.62 * f);
      if (jest && f > 0) { ctx.shadowColor = rgba(s.k.a, 0.75 * f); ctx.shadowBlur = 30 * s.u * f; } else cien(s);
      ctx.fillStyle = jest ? lerpKolor(s.k.t, s.k.a, f) : s.k.t; ctx.fillText(w.t, -w.w / 2, 0); ctx.restore();
    });
  });
  function lerpKolor(a, b, t) { const x = rgb(a), y = rgb(b); return `rgb(${x.map((v, i) => Math.round(lerp(v, y[i], clamp(t)))).join(",")})`; }
  tekstN("tekst-naklejki-slowa", "Słowa jak naklejki", { tekst: "Szczere *opinie* bez filtra" }, (s) => {
    const ul = uloz(s, s.p.tekst, 80 * s.u * s.p.rozmiar, { lh: 1.6 }), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font;
    ul.slowa.forEach((w) => {
      const e = T(s, w.i * 0.13, 0.32); if (e <= 0) return; const sk = lerp(1.7, 1, E.outBack(e)), rot = (los(w.i * 5 + 1) - 0.5) * 0.16, pad = 18 * s.u, h = ul.px * 1.25, kol = w.wyr ? s.k.a : "#FFFFFF";
      ctx.save(); ctx.translate(w.x + w.w / 2, w.y); ctx.rotate(rot); ctx.scale(sk, sk); ctx.globalAlpha = s.alfa * clamp(e * 3);
      karta(s, -w.w / 2 - pad - 7 * s.u, -h / 2 - 7 * s.u, w.w + pad * 2 + 14 * s.u, h + 14 * s.u, 18 * s.u, "#FFFFFF");
      ctx.fillStyle = kol; zaokr(ctx, -w.w / 2 - pad, -h / 2, w.w + pad * 2, h, 13 * s.u); ctx.fill();
      ctx.fillStyle = w.wyr ? kontrast(s.k.a) : "#111111"; ctx.fillText(w.t, -w.w / 2, 0); ctx.restore();
    });
  });
  tekstN("tekst-karaoke", "Karaoke: płynne wypełnianie", { tekst: "Śpiewaj razem *z nami* do końca" }, (s) => {
    const ul = uloz(s, s.p.tekst, 92 * s.u * s.p.rozmiar, { lh: 1.25 }), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font;
    const a = E.outCubic(T(s, 0, 0.35)), suma = ul.linie.reduce((x, l) => x + l.w, 0), p = suma * clamp((s.t - 0.35) / Math.max(0.5, s.T - s.p.wyjscie - 0.75));
    ctx.save(); ctx.globalAlpha = s.alfa * a; cien(s); ul.slowa.forEach((w) => { ctx.fillStyle = rgba(s.k.t, 0.95); ctx.fillText(w.t, w.x, w.y); }); ctx.restore();
    let zost = p; ul.linie.forEach((l) => { const d = Math.min(l.w, zost); zost -= l.w; if (d <= 0) return;
      ctx.save(); ctx.beginPath(); ctx.rect(l.x0 - 2, l.y - ul.lh * 0.6, d + 2, ul.lh * 1.2); ctx.clip(); l.slowa.forEach((w) => { ctx.fillStyle = w.wyr ? s.k.g : s.k.a; ctx.fillText(w.t, w.x, w.y); }); ctx.restore();
      if (d < l.w) { ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(l.x0 + d, l.y - ul.px * 0.72, 9 * s.u, 0, PI * 2); ctx.fill(); } });
  }, { czas: 4 });
  tekstN("tekst-twardy-cien", "Neobrutalizm: tekst w ramce z twardym cieniem", { tekst: "Prosto.\nGłośno.\n*Wyraźnie.*" }, (s) => {
    const ul = uloz(s, s.p.tekst, 84 * s.u * s.p.rozmiar, { lh: 1.7, waga: 900 }), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font;
    ul.linie.forEach((l, i) => {
      const e = E.outBackMocno(T(s, i * 0.15, 0.45)); if (e <= 0) return; const c = E.outCubic(T(s, i * 0.15 + 0.2, 0.3)), pad = 26 * s.u, h = ul.px * 1.35, o = 14 * s.u * c, gr = 6 * s.u;
      const wyr = l.slowa.some((w) => w.wyr), kol = wyr ? s.k.a : "#FFFFFF";
      ctx.save(); ctx.translate(l.x0 + l.w / 2, l.y - (1 - e) * 80 * s.u); ctx.rotate((i % 2 ? 1 : -1) * 0.025); ctx.globalAlpha = s.alfa * clamp(e * 2);
      const x = -l.w / 2 - pad, y = -h / 2, w = l.w + pad * 2;
      ctx.fillStyle = "#111111"; ctx.fillRect(x + o, y + o, w, h); ctx.fillStyle = kol; ctx.fillRect(x - o * 0.3, y - o * 0.3, w, h);
      ctx.strokeStyle = "#111111"; ctx.lineWidth = gr; ctx.strokeRect(x - o * 0.3, y - o * 0.3, w, h);
      l.slowa.forEach((w2) => { ctx.fillStyle = w2.wyr ? kontrast(s.k.a) : "#111111"; ctx.fillText(w2.t, w2.x - l.x0 - l.w / 2 - o * 0.3, -o * 0.3); }); ctx.restore();
    });
  });
  function rozstrzel(s, t, x, y, px, waga, od, kol, e = 1) {
    const ctx = s.ctx; ctx.font = font(s, px, waga); const zn = Array.from(t); let xx = x;
    zn.forEach((c, i) => { const a = clamp(e * zn.length - i); if (a > 0) { ctx.globalAlpha = s.alfa * a; ctx.fillStyle = kol; ctx.fillText(c, xx, y); } xx += ctx.measureText(c).width + od; });
    ctx.globalAlpha = s.alfa; return xx - od - x;
  }
  const szerRozstrz = (s, t, px, waga, od) => { s.ctx.font = font(s, px, waga); const zn = Array.from(t); return zn.reduce((a, c) => a + s.ctx.measureText(c).width, 0) + od * Math.max(0, zn.length - 1); };
  tekstN("tekst-nadtytul", "Nagłówek z nadtytułem", { tekst: "Jak nagrać *czysty dźwięk*", tekst2: "Poradnik" }, (s) => {
    const ctx = s.ctx, px = 96 * s.u * s.p.rozmiar, ul = uloz(s, s.p.tekst, px, { y: s.poz.y + px * 0.25 }); if (!ul.slowa.length) return;
    const t2 = String(s.p.tekst2 || "").toLocaleUpperCase("pl"), p2 = px * 0.34, od = p2 * 0.35, w2 = szerRozstrz(s, t2, p2, 800, od), lw = 56 * s.u * s.p.rozmiar;
    const blok = t2 ? lw + 20 * s.u + w2 : 0, bx = s.poz.align === "left" ? ul.x : s.poz.align === "right" ? ul.x + ul.w - blok : ul.x + ul.w / 2 - blok / 2, by = ul.y - p2 * 1.4;
    if (t2) { const l = E.inOutCubic(T(s, 0, 0.45)); ctx.fillStyle = s.k.a; ctx.fillRect(bx, by - 2 * s.u, lw * l, 4 * s.u); rozstrzel(s, t2, bx + lw + 20 * s.u, by, p2, 800, od, s.k.a, T(s, 0.2, 0.5)); }
    ctx.font = ul.font; ul.linie.forEach((l, i) => { const e = E.outQuint(T(s, 0.3 + i * 0.1, 0.65)); ctx.save(); ctx.beginPath(); ctx.rect(0, l.y - ul.lh * 0.6, s.W, ul.lh * 1.2); ctx.clip(); cien(s); l.slowa.forEach((w) => piszSlowo(s, w, null, ctx, 0, (1 - e) * ul.lh)); ctx.restore(); });
    const r = E.inOutCubic(T(s, 0.6, 0.6)); ctx.fillStyle = rgba(s.k.t, 0.5); const rw = ul.w * r; ctx.fillRect(s.poz.align === "right" ? ul.x + ul.w - rw : s.poz.align === "left" ? ul.x : ul.x + (ul.w - rw) / 2, ul.y + ul.h + 26 * s.u, rw, 2 * s.u);
  }, { pola: ["tekst", "tekst2"] });
  tekstN("tekst-rozdzial", "Numer rozdziału i tytuł", { tekst: "Światło\n*naturalne*", tekst2: "02" }, (s) => {
    const ctx = s.ctx, px = 80 * s.u * s.p.rozmiar, nr = String(s.p.tekst2 || "01"), pn = px * 3.1; ctx.font = font(s, pn, 900); const wn = ctx.measureText(nr).width;
    const ul0 = uloz(s, s.p.tekst, px, { align: "left", x: 0, y: 0 }); const calosc = wn + 50 * s.u + ul0.w, x0 = xWyr(s, calosc), cy = s.poz.y;
    const a = E.outQuint(T(s, 0, 0.7)); ctx.save(); ctx.beginPath(); ctx.rect(x0 - 20 * s.u, cy - pn * 0.6, wn + 40 * s.u, pn * 1.2); ctx.clip();
    ctx.lineWidth = 4 * s.u * s.p.rozmiar; ctx.strokeStyle = s.k.a; ctx.lineJoin = "round"; ctx.font = font(s, pn, 900); ctx.strokeText(nr, x0, cy + (1 - a) * pn); ctx.restore();
    const l = E.inOutCubic(T(s, 0.25, 0.5)), lx = x0 + wn + 25 * s.u; ctx.fillStyle = s.k.a; ctx.fillRect(lx - 3 * s.u, cy - pn * 0.36 * l, 6 * s.u, pn * 0.72 * l);
    const ul = uloz(s, s.p.tekst, px, { align: "left", x: lx + 28 * s.u, y: cy }); ctx.font = ul.font;
    ul.linie.forEach((li, i) => { const e = E.outQuint(T(s, 0.4 + i * 0.12, 0.6)); ctx.save(); ctx.beginPath(); ctx.rect(lx + 10 * s.u, li.y - ul.lh * 0.6, s.W, ul.lh * 1.2); ctx.clip(); cien(s); li.slowa.forEach((w) => piszSlowo(s, w, null, ctx, -(1 - e) * (li.w + 40 * s.u), 0)); ctx.restore(); });
  }, { pola: ["tekst", "tekst2"] });
  tekstN("tekst-smuga-wjazd", "Wjazd ze smugą ruchu", { tekst: "Pełen *gaz*!" }, (s) => {
    const ul = uloz(s, s.p.tekst, 110 * s.u * s.p.rozmiar), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font;
    ul.linie.forEach((l, i) => {
      const e = T(s, i * 0.1, 0.5), k = E.outBack(e), v = (1 - E.outCubic(e)), dx = (1 - k) * -s.W * 0.8;
      for (let j = 6; j >= 0; j--) {
        const tr = j * v * 70 * s.u; if (j && tr < 2) continue;
        ctx.save(); ctx.globalAlpha = s.alfa * (j ? 0.16 * (1 - j / 7) : clamp(e * 3)); if (!j) cien(s); l.slowa.forEach((w) => piszSlowo(s, w, null, ctx, dx - tr, 0)); ctx.restore();
      }
    });
  });
  tekstN("tekst-wahadlo", "Słowa kołyszą się na wahadle", { tekst: "Kołysz się *z nami*" }, (s) => {
    const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar, { lh: 1.3 }), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font;
    ul.slowa.forEach((w) => {
      const t = s.t - w.i * 0.12 / s.p.tempo; if (t <= 0) return; const kat = 1.3 * Math.exp(-t * 3.2) * Math.cos(t * 9 * s.p.tempo), py = w.y - ul.px * 0.55;
      ctx.save(); ctx.translate(w.x + w.w / 2, py); ctx.rotate(kat); ctx.globalAlpha = s.alfa * clamp(t * 6); cien(s); piszSlowo(s, w, null, ctx, -w.x - w.w / 2, -py); ctx.restore();
    });
  });
  tekstN("tekst-domino", "Litery przewracają się jak domino", { tekst: "Efekt *domina*" }, (s) => {
    const ul = uloz(s, s.p.tekst, 110 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul); ctx.font = ul.font; cien(s);
    z.forEach((c) => { const e = T(s, c.i * 0.05, 0.45); if (e <= 0) return; const k = E.outBounce(e), py = c.y + ul.px * 0.36;
      ctx.save(); ctx.translate(c.x + c.w, py); ctx.rotate((1 - k) * PI / 2); ctx.globalAlpha = s.alfa * clamp(e * 4); ctx.fillStyle = c.slowo.wyr ? s.k.a : s.k.t; ctx.fillText(c.c, -c.w, -ul.px * 0.36); ctx.restore(); });
  });
  tekstN("tekst-tablica-odlotow", "Tablica odlotów (klapki)", { tekst: "ODLOT 12:40 *RZYM*", wielkie: true }, (s) => {
    const ctx = s.ctx, px = 76 * s.u * s.p.rozmiar, tw = px * 0.78, th = px * 1.15, gap = 6 * s.u, sl = slowaZ(tekstP(s, s.p.tekst)).map((w) => ({ t: w.t, wyr: w.wyr }));
    const maks = Math.max(4, Math.floor(s.W * 0.88 / (tw + gap))), linie = [[]]; sl.forEach((w) => { const l = linie[linie.length - 1], dl = l.reduce((a, x) => a + Array.from(x.t).length + 1, 0); if (l.length && dl + Array.from(w.t).length > maks) linie.push([w]); else l.push(w); });
    const ZN = "ABCDEFGHIJKLMNOPRSTUWZ0123456789"; let k = 0; ctx.font = font(s, px * 0.82, 800);
    linie.forEach((l, li) => {
      const zn = []; l.forEach((w, wi) => { Array.from(w.t).forEach((c) => zn.push({ c, wyr: w.wyr })); if (wi < l.length - 1) zn.push({ c: " ", wyr: false }); });
      const W = zn.length * (tw + gap) - gap, x0 = xWyr(s, W), y = s.poz.y + (li - (linie.length - 1) / 2) * (th + gap * 3);
      zn.forEach((z, i) => {
        const x = x0 + i * (tw + gap), we = E.outBack(T(s, k * 0.02, 0.3)); k++; if (we <= 0) return;
        ctx.save(); ctx.translate(x + tw / 2, y); ctx.scale(1, we); karta(s, -tw / 2, -th / 2, tw, th, 8 * s.u, rgba(s.k.tl, 0.95), ctx, 0.6);
        const gotowe = 0.35 + k * 0.045 / s.p.tempo, krok = Math.floor(s.t * 18), zc = z.c === " " || s.t >= gotowe ? z.c : ZN[Math.floor(los(k * 13 + krok) * ZN.length)], f = (s.t * 18) % 1;
        ctx.fillStyle = z.wyr && s.t >= gotowe ? s.k.a : s.k.t; const cw = ctx.measureText(zc).width;
        if (s.t < gotowe && z.c !== " ") { ctx.save(); ctx.scale(1, Math.abs(Math.cos(f * PI))); ctx.fillText(zc, -cw / 2, 0); ctx.restore(); } else ctx.fillText(zc, -cw / 2, 0);
        ctx.fillStyle = rgba("#000000", 0.55); ctx.fillRect(-tw / 2, -1.5 * s.u, tw, 3 * s.u); ctx.restore();
      });
    });
  }, { czas: 4 });
  tekstN("tekst-ramka-skacze", "Ramka skacze po słowach", { tekst: "Czytaj razem ze mną *słowo* po słowie" }, (s) => {
    const ul = uloz(s, s.p.tekst, 84 * s.u * s.p.rozmiar, { lh: 1.4 }), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font;
    const n = ul.slowa.length, dl = Math.max(0.15, (s.T - s.p.wyjscie - 0.4) / n), tt = Math.max(0, s.t - 0.3), i = Math.min(n - 1, Math.floor(tt / dl)), p = E.outBack(clamp((tt - i * dl) / Math.min(0.22, dl)));
    const a = ul.slowa[Math.max(0, i - 1)], b = ul.slowa[i], pad = 14 * s.u, h = ul.px * 1.2, wej = E.outCubic(T(s, 0, 0.35));
    const bx = i ? lerp(a.x, b.x, p) : b.x, by = i ? lerp(a.y, b.y, p) : b.y, bw = i ? lerp(a.w, b.w, p) : b.w;
    if (s.t > 0.2) karta(s, bx - pad, by - h / 2, bw + pad * 2, h, 12 * s.u, b.wyr ? s.k.g : s.k.a);
    ctx.globalAlpha = s.alfa * wej; ul.slowa.forEach((w) => { const ak = w === b && s.t > 0.2 && p > 0.5; ctx.fillStyle = ak ? kontrast(b.wyr ? s.k.g : s.k.a) : w.wyr ? s.k.a : s.k.t; ctx.fillText(w.t, w.x, w.y); }); ctx.globalAlpha = s.alfa;
  }, { czas: 4 });
  tekstN("tekst-equalizer", "Litery skaczą jak equalizer", { tekst: "GŁOŚNIEJ!", wielkie: true }, (s) => {
    const ul = uloz(s, s.p.tekst, 130 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul); ctx.font = ul.font; cien(s);
    const tl = clamp(1 - (s.t - 0.6) / 1.4) * 0.9 + 0.1;
    z.forEach((c) => { const e = E.outCubic(T(s, c.i * 0.03, 0.3)); if (e <= 0) return; const v = Math.abs(Math.sin(s.t * 9 + c.i * 1.7) * Math.sin(s.t * 4.3 + c.i)), sk = 1 + v * 0.75 * tl, py = c.y + ul.px * 0.36;
      ctx.save(); ctx.translate(c.x + c.w / 2, py); ctx.scale(1, sk * e); ctx.globalAlpha = s.alfa * e; ctx.fillStyle = c.slowo.wyr || v * tl > 0.5 ? s.k.a : s.k.t; ctx.fillText(c.c, -c.w / 2, -ul.px * 0.36); ctx.restore(); });
  }, { czas: 3.5 });
  tekstN("tekst-rozpad", "Tekst rozpada się na litery na końcu", { tekst: "I już *znika*…" }, (s) => {
    const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul); ctx.font = ul.font; cien(s);
    const kon = Math.max(0.8, s.T - 1.1);
    z.forEach((c) => {
      const e = E.outCubic(T(s, c.i * 0.025, 0.4)); if (e <= 0) return; const r = Math.max(0, s.t - kon - los(c.i * 3) * 0.25);
      const dx = (los(c.i * 7) - 0.5) * 900 * s.u * r, dy = (-200 * r + 1100 * r * r) * s.u * (0.5 + los(c.i * 5)), rot = (los(c.i * 11) - 0.5) * 8 * r;
      ctx.save(); ctx.translate(c.x + c.w / 2 + dx, c.y + dy + (1 - e) * 30 * s.u); ctx.rotate(rot); ctx.globalAlpha = s.alfa * e * clamp(1 - r * 1.4); ctx.fillStyle = c.slowo.wyr ? s.k.a : s.k.t; ctx.fillText(c.c, -c.w / 2, 0); ctx.restore();
    });
  }, { czas: 3.5, dom: { wyjscie: 0.15 } });
  tekstN("tekst-pytanie-odpowiedz", "Pytanie i mocna odpowiedź", { tekst: "Ile to kosztuje?", tekst2: "*ZERO* złotych" }, (s) => {
    const ctx = s.ctx, px = 70 * s.u * s.p.rozmiar, d = 1.1 / s.p.tempo, e1 = E.outCubic(T(s, 0, 0.45)), e2 = T(s, 1.1, 0.3), dim = E.inOutCubic(T(s, 1.1, 0.3));
    const u1 = uloz(s, s.p.tekst, px, { y: s.poz.y - px * 1.1 }); ctx.font = u1.font; ctx.save(); ctx.globalAlpha = s.alfa * e1 * (1 - 0.45 * dim); cien(s); u1.slowa.forEach((w) => piszSlowo(s, w, null, ctx, 0, (1 - e1) * 24 * s.u)); ctx.restore();
    if (e2 <= 0 || !s.p.tekst2) return; const u2 = uloz(s, s.p.tekst2, px * 1.75, { y: s.poz.y + px * 0.9, waga: 900 }), sk = lerp(2.2, 1, E.outExpo(e2)), drg = s.t > d + 0.3 && s.t < d + 0.55 ? (los(Math.floor(s.t * 60)) - 0.5) * 14 * s.u : 0;
    const cx = u2.x + u2.w / 2, cy = u2.y + u2.h / 2; ctx.save(); ctx.translate(cx + drg, cy); ctx.scale(sk, sk); ctx.translate(-cx, -cy); ctx.globalAlpha = s.alfa * clamp(e2 * 2.5); ctx.font = u2.font; cien(s, ctx, 1.4);
    u2.slowa.forEach((w) => { ctx.fillStyle = w.wyr ? s.k.a : s.k.t; ctx.fillText(w.t, w.x, w.y); }); ctx.restore();
  }, { pola: ["tekst", "tekst2"], czas: 3.5 });
  tekstN("tekst-hasla-po-kolei", "Hasła jedno po drugim", { lista: "Nagrywasz.\nWysyłasz.\n*My robimy resztę.*", wielkie: true }, (s) => {
    const ctx = s.ctx, z = zmienne(s), t = z.el[z.i], px = 110 * s.u * s.p.rozmiar, ul = uloz(s, t, px, { lh: 1.05, waga: 900 }); if (!ul.slowa.length) return; ctx.font = ul.font;
    const we = E.outQuint(okno(z.lt, 0, 0.45 / s.p.tempo)), wy = z.i < z.n - 1 ? E.inCubic(okno(z.lt, z.dl - 0.22, 0.22)) : 0, blok = z.i % 2 === 1;
    ul.linie.forEach((l, li) => {
      const e = E.outQuint(okno(z.lt, li * 0.07, 0.45 / s.p.tempo)), pad = 20 * s.u;
      ctx.save(); ctx.beginPath(); ctx.rect(0, l.y - ul.lh * 0.62, s.W, ul.lh * 1.24); ctx.clip(); ctx.translate(0, (1 - e) * ul.lh - wy * ul.lh);
      if (blok) { ctx.fillStyle = s.k.g; ctx.fillRect(l.x0 - pad, l.y - ul.lh * 0.5, l.w + pad * 2, ul.lh); l.slowa.forEach((w) => { ctx.fillStyle = w.wyr ? s.k.a : kontrast(s.k.g); ctx.fillText(w.t, w.x, w.y); }); }
      else { cien(s); l.slowa.forEach((w) => piszSlowo(s, w)); }
      ctx.restore();
    });
    void we;
  }, { pola: ["lista"], czas: 4.5 });
  tekstN("tekst-gradient-plynie", "Tekst z płynącym gradientem", { tekst: "KOLOR W *RUCHU*", wielkie: true, waga: 900 }, (s) => {
    const ul = uloz(s, s.p.tekst, 130 * s.u * s.p.rozmiar), ctx = s.ctx; if (!ul.slowa.length) return;
    const c = warstwa(s, "gradient-plynie", (x) => {
      x.font = ul.font; x.textBaseline = "middle"; ul.slowa.forEach((w) => { x.fillStyle = "#FFFFFF"; x.fillText(w.t, w.x, w.y); });
      x.globalCompositeOperation = "source-in"; const g = x.createLinearGradient(ul.x, 0, ul.x + ul.w, 0), kol = [s.k.g, s.k.a, s.k.t, s.k.a];
      for (let i = 0; i <= 16; i++) { const f = ((i / 16) * 1.4 - s.t * 0.45) * kol.length, j = ((Math.floor(f) % 4) + 4) % 4; g.addColorStop(i / 16, lerpKolor(kol[j], kol[(j + 1) % 4], f - Math.floor(f))); }
      x.fillStyle = g; x.fillRect(0, 0, s.W, s.H);
    });
    const e = E.outBack(T(s, 0, 0.5)), cx = ul.x + ul.w / 2, cy = ul.y + ul.h / 2; ctx.save(); ctx.translate(cx, cy); ctx.scale(lerp(0.7, 1, e), lerp(0.7, 1, e)); ctx.translate(-cx, -cy); ctx.globalAlpha = s.alfa * clamp(e * 2); cien(s); ctx.drawImage(c, 0, 0); ctx.restore();
  }, { czas: 4 });
  tekstN("tekst-lupa", "Lupa przesuwa się po tekście", { tekst: "Zobacz *szczegóły*" }, (s) => {
    const ul = uloz(s, s.p.tekst, 96 * s.u * s.p.rozmiar), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font;
    const a = E.outCubic(T(s, 0, 0.4)); ctx.save(); ctx.globalAlpha = s.alfa * a; cien(s); ul.slowa.forEach((w) => piszSlowo(s, w)); ctx.restore();
    const e = T(s, 0.35, 0.4); if (e <= 0) return; const r = Math.max(ul.lh * 0.85, 110 * s.u * s.p.rozmiar), f = clamp((s.t - 0.5) / Math.max(1, s.T - s.p.wyjscie - 0.9));
    const lx = lerp(ul.x + r * 0.3, ul.x + ul.w - r * 0.3, 0.5 - 0.5 * Math.cos(f * PI)), ly = ul.y + ul.h / 2 + Math.sin(f * PI * 2) * ul.h * 0.18, sk = E.outBack(e);
    ctx.save(); ctx.translate(lx, ly); ctx.scale(sk, sk); ctx.translate(-lx, -ly);
    ctx.save(); ctx.beginPath(); ctx.arc(lx, ly, r, 0, PI * 2); ctx.clip(); ctx.fillStyle = rgba(s.k.tl, 0.9); ctx.fill();
    ctx.translate(lx, ly); ctx.scale(1.7, 1.7); ctx.translate(-lx, -ly); ul.slowa.forEach((w) => piszSlowo(s, w)); ctx.restore();
    ctx.strokeStyle = s.k.a; ctx.lineWidth = 12 * s.u; ctx.beginPath(); ctx.arc(lx, ly, r, 0, PI * 2); ctx.stroke();
    ctx.lineCap = "round"; ctx.lineWidth = 26 * s.u; ctx.beginPath(); ctx.moveTo(lx + r * 0.74, ly + r * 0.74); ctx.lineTo(lx + r * 1.35, ly + r * 1.35); ctx.stroke(); ctx.restore();
  }, { czas: 4 });
  tekstN("tekst-tabliczka-obrot", "Tabliczka obraca się na drugą stronę", { tekst: "Przed zmianą", tekst2: "*Po zmianie*" }, (s) => {
    const ctx = s.ctx, px = 80 * s.u * s.p.rozmiar, w1 = szerLinii(s, s.p.tekst, px, s.p.waga), w2 = szerLinii(s, s.p.tekst2 || "", px, s.p.waga), W = Math.max(w1, w2) + 90 * s.u, h = px * 1.9;
    const cx = xWyr(s, W) + W / 2, cy = s.poz.y, a = E.outBack(T(s, 0, 0.45)), f = E.inOutCubic(T(s, 1.3, 0.6)), kat = f * PI, cs = Math.cos(kat), tyl = cs < 0;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(a * Math.max(0.02, Math.abs(cs)), a); const kol = tyl ? s.k.a : s.k.g;
    karta(s, -W / 2, -h / 2, W, h, h * 0.22, kol); const t = tyl ? (s.p.tekst2 || "") : s.p.tekst, tw = tyl ? w2 : w1;
    linia(s, t, -tw / 2, 0, px, s.p.waga, kontrast(kol), tyl ? kontrast(kol) : s.k.a);
    ctx.fillStyle = rgba("#000000", Math.sin(kat) * 0.35); zaokr(ctx, -W / 2, -h / 2, W, h, h * 0.22); ctx.fill(); ctx.restore();
  }, { pola: ["tekst", "tekst2"], czas: 3.5 });
  tekstN("tekst-ciecie-ukosne", "Cięcie ukośne przez tekst", { tekst: "PRZECIĘTE *CENY*", wielkie: true, waga: 900 }, (s) => {
    const ul = uloz(s, s.p.tekst, 120 * s.u * s.p.rozmiar), ctx = s.ctx; if (!ul.slowa.length) return;
    const c = warstwaTekstu(s, "ciecie-ukos", ul), a = E.outCubic(T(s, 0, 0.35)), cut = T(s, 0.45, 0.25), roz = E.outCubic(T(s, 0.55, 0.3)) * (1 - E.inOutCubic(T(s, 1.1, 0.5)));
    const cx = ul.x + ul.w / 2, cy = ul.y + ul.h / 2, k = -0.35, L = s.W + s.H, d = 22 * s.u * roz;
    const pol = (g) => { ctx.beginPath(); const dx = Math.cos(k) * L, dy = Math.sin(k) * L, nx = -Math.sin(k) * L * g, ny = Math.cos(k) * L * g; ctx.moveTo(cx - dx, cy - dy); ctx.lineTo(cx + dx, cy + dy); ctx.lineTo(cx + dx + nx, cy + dy + ny); ctx.lineTo(cx - dx + nx, cy - dy + ny); ctx.closePath(); };
    ctx.save(); ctx.globalAlpha = s.alfa * a; cien(s);
    [[-1, -1], [1, 1]].forEach(([g, z]) => { ctx.save(); pol(g); ctx.clip(); ctx.drawImage(c, z * (-Math.sin(k) * d + Math.cos(k) * d * 1.5), z * (Math.cos(k) * d + Math.sin(k) * d * 1.5)); ctx.restore(); });
    ctx.restore();
    if (cut > 0 && cut < 1) { const p = E.outCubic(cut), dx = Math.cos(k), dy = Math.sin(k), Lx = ul.w * 0.75; ctx.strokeStyle = "#FFFFFF"; ctx.lineWidth = 6 * s.u; ctx.lineCap = "round"; ctx.globalAlpha = s.alfa * (1 - cut * 0.5);
      ctx.beginPath(); ctx.moveTo(cx - dx * Lx, cy - dy * Lx); ctx.lineTo(cx - dx * Lx + dx * Lx * 2 * p, cy - dy * Lx + dy * Lx * 2 * p); ctx.stroke(); ctx.globalAlpha = s.alfa; }
  });
  tekstN("tekst-kafle-liter", "Litery na kafelkach jak w grze", { tekst: "GRA *SŁÓW*", wielkie: true }, (s) => {
    const ctx = s.ctx, px = 92 * s.u * s.p.rozmiar, k = px * 1.15, gap = px * 0.12, sl = slowaZ(tekstP(s, s.p.tekst)), maxW = s.W * 0.9, linie = [[]];
    sl.forEach((w) => { const l = linie[linie.length - 1], dl = l.reduce((a, x) => a + Array.from(x.t).length * (k + gap) + k * 0.4, 0); if (l.length && dl + Array.from(w.t).length * (k + gap) > maxW) linie.push([w]); else l.push(w); });
    let n = 0; ctx.font = font(s, px * 0.78, 900);
    linie.forEach((l, li) => {
      const W = l.reduce((a, x) => a + Array.from(x.t).length * (k + gap), 0) - gap + (l.length - 1) * k * 0.4; let x = xWyr(s, W); const y = s.poz.y + (li - (linie.length - 1) / 2) * (k + gap * 2.5);
      l.forEach((w) => { Array.from(w.t).forEach((c) => {
        const e = T(s, n * 0.06, 0.55); n++; if (e > 0) { const yy = y - (1 - E.outBounce(e)) * 300 * s.u, rot = (los(n * 3) - 0.5) * 0.12 * (1 - e), kol = w.wyr ? s.k.a : "#FFF4DC";
          ctx.save(); ctx.translate(x + k / 2, yy); ctx.rotate(rot); ctx.globalAlpha = s.alfa * clamp(e * 4); karta(s, -k / 2, -k / 2, k, k, k * 0.14, ciemniej(kol, 0.25)); ctx.fillStyle = kol; zaokr(ctx, -k / 2, -k / 2, k, k * 0.92, k * 0.14); ctx.fill();
          ctx.font = font(s, px * 0.78, 900); ctx.fillStyle = w.wyr ? kontrast(s.k.a) : "#2B2118"; const cw = ctx.measureText(c).width; ctx.fillText(c, -cw / 2, -k * 0.04);
          ctx.font = font(s, px * 0.22, 700); ctx.fillText(String(1 + Math.floor(los(c.charCodeAt(0)) * 9)), k * 0.24, k * 0.27); ctx.restore(); }
        x += k + gap; }); x += k * 0.4 - gap * 0; });
    });
  }, { czas: 3.5 });
  tekstN("tekst-pasy-pelne", "Linie na pasach przez cały kadr", { tekst: "Wiadomość\ndnia: *rusza*\nnabór" }, (s) => {
    const ul = uloz(s, s.p.tekst, 84 * s.u * s.p.rozmiar, { lh: 1.5 }), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font;
    ul.linie.forEach((l, i) => {
      const e = E.outQuint(T(s, i * 0.12, 0.6)), z = i % 2 ? 1 : -1, kol = i % 2 ? s.k.tl : s.k.g, h = ul.lh * 0.92, y = l.y - h / 2;
      ctx.save(); ctx.translate(z * (1 - e) * s.W, 0); cien(s, ctx, 0.7); ctx.fillStyle = kol; ctx.fillRect(-20, y, s.W + 40, h); bezCienia(ctx);
      const te = E.outCubic(T(s, i * 0.12 + 0.25, 0.4)); ctx.globalAlpha = s.alfa * te; l.slowa.forEach((w) => { ctx.fillStyle = w.wyr ? s.k.a : kontrast(kol); ctx.fillText(w.t, w.x + z * (1 - te) * 60 * s.u, w.y); }); ctx.restore();
    });
  });
  tekstN("tekst-pionowy-bok", "Napis pionowy przy krawędzi", { tekst: "KOLEKCJA *2026*", wielkie: true }, (s) => {
    const ctx = s.ctx, p = prawa(s), px = dopasuj(s, bezGw(s.p.tekst), 90 * s.u * s.p.rozmiar, s.H * 0.8, s.p.waga), w = szerLinii(s, s.p.tekst, px, s.p.waga), x = p ? s.W - px * 0.9 - 30 * s.u : px * 0.9 + 30 * s.u, cy = s.H / 2;
    ctx.save(); ctx.translate(x, cy); ctx.rotate(p ? PI / 2 : -PI / 2);
    const l = E.inOutCubic(T(s, 0, 0.6)); ctx.fillStyle = s.k.a; ctx.fillRect(-w / 2 - 40 * s.u, px * 0.72, (w + 80 * s.u) * l, 5 * s.u);
    const e = E.outQuint(T(s, 0.2, 0.8)); ctx.beginPath(); ctx.rect(-w / 2 - 20 * s.u, -px * 0.7, w + 40 * s.u, px * 1.4); ctx.clip(); cien(s); linia(s, s.p.tekst, -w / 2 - (1 - e) * (w + 60 * s.u), 0, px, s.p.waga); ctx.restore();
  }, { dom: { pozycja: "lewy-srodek" }, czas: 3.5 });
  tekstN("tekst-na-okregu", "Napis na obracającym się okręgu", { tekst: "OBSERWUJ PO WIĘCEJ", wielkie: true }, (s) => {
    const ctx = s.ctx, R = 190 * s.u * s.p.rozmiar, px = R * 0.24, cx = s.poz.x, cy = s.poz.y, a = E.outBack(T(s, 0, 0.55)); ctx.font = font(s, px, 800);
    const baza = tekstP(s, bezGw(s.p.tekst)) + " • ", obw = PI * 2 * R, wb = Math.max(1, ctx.measureText(baza).width), ile = Math.max(1, Math.round(obw / wb));
    ctx.font = font(s, clamp(px * obw / (ile * wb), px * 0.5, px * 1.25), 800); const t = Array(ile).fill(baza).join("");
    const zn = Array.from(t), szer = zn.map((c) => ctx.measureText(c).width), suma = szer.reduce((x, y) => x + y, 0), kr = (PI * 2) / suma;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(a, a); ctx.rotate(s.t * 0.6 - 0.9 * (1 - a)); cien(s); let k = -PI / 2;
    zn.forEach((c, i) => { const e = T(s, i * 0.012, 0.2); const kk = k + szer[i] * kr / 2; k += szer[i] * kr; if (e <= 0) return; ctx.save(); ctx.rotate(kk + PI / 2); ctx.globalAlpha = s.alfa * e; ctx.fillStyle = s.k.t; ctx.fillText(c, -szer[i] / 2, -R); ctx.restore(); });
    ctx.restore(); if (s.p.tekst2) { const b = E.outBackMocno(T(s, 0.3, 0.5)); ctx.save(); ctx.translate(cx, cy); ctx.scale(b, b); ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(0, 0, R * 0.7, 0, PI * 2); ctx.fill();
      const p2 = dopasuj(s, s.p.tekst2, R * 0.6, R * 1.0, 900); ctx.font = font(s, p2, 900); ctx.fillStyle = kontrast(s.k.a); const w = ctx.measureText(s.p.tekst2).width; ctx.fillText(s.p.tekst2, -w / 2, R * 0.03); ctx.restore(); }
    else { const b = E.outBackMocno(T(s, 0.3, 0.5)); ctx.save(); ctx.translate(cx, cy); ctx.scale(b, b); ctx.rotate(-s.t * 0.4); ctx.fillStyle = s.k.a; gwiazda(ctx, 0, 0, 5, R * 0.5, R * 0.22); ctx.fill(); ctx.restore(); }
  }, { pola: ["tekst", "tekst2"], czas: 5 });
  tekstN("tekst-mem", "Napis jak w memie (góra i dół)", { tekst: "Kiedy klient mówi", tekst2: "*ostatnia* poprawka", wielkie: true, waga: 900 }, (s) => {
    const ctx = s.ctx, px = 96 * s.u * s.p.rozmiar, m = s.H * 0.07;
    [[s.p.tekst, 0, true], [s.p.tekst2, 0.35, false]].forEach(([t, d, gora]) => {
      if (!t) return; const o = { gora: true, align: "center", x: s.W / 2, maxW: s.W * 0.9, lh: 1.05, waga: 900 };
      const h = uloz(s, t, px, Object.assign({ y: 0 }, o)).h, ul = uloz(s, t, px, Object.assign({ y: gora ? m : s.H - m - h }, o)), e = E.outBackMocno(T(s, d, 0.4)); if (e <= 0) return;
      const cy = ul.y + ul.h / 2; ctx.font = ul.font; ctx.save(); ctx.translate(s.W / 2, cy); ctx.scale(e, e); ctx.translate(-s.W / 2, -cy);
      ctx.lineJoin = "round"; ctx.miterLimit = 2; ctx.lineWidth = px * 0.16; ctx.strokeStyle = "#000000"; ul.slowa.forEach((w) => ctx.strokeText(w.t, w.x, w.y)); ul.slowa.forEach((w) => piszSlowo(s, w)); ctx.restore();
    });
  }, { pola: ["tekst", "tekst2"], czas: 3.5 });

  // ---------- belki z nazwiskiem (v18) ----------
  /* Dwie linie tekstu belki od punktu x (lewa krawędź): nazwisko i opis. */
  function dwieLinie(s, x, y, px, e1, e2, o = {}) {
    const ctx = s.ctx, t2 = s.p.tekst2, y1 = t2 ? y - px * 0.36 : y, y2 = y + px * 0.5;
    ctx.save(); ctx.globalAlpha = s.alfa * clamp(e1 * 2); ctx.font = font(s, px, o.waga1 || s.p.waga); ctx.fillStyle = o.k1 || s.k.t; ctx.fillText(tekstP(s, s.p.tekst), x + (1 - e1) * (o.dx == null ? -30 : o.dx) * s.u, y1);
    if (t2) { ctx.globalAlpha = s.alfa * clamp(e2 * 2); ctx.font = font(s, px * (o.sk2 || 0.52), o.waga2 || 500); ctx.fillStyle = o.k2 || rgba(s.k.t, 0.82); ctx.fillText(t2, x + (1 - e2) * (o.dx == null ? -30 : o.dx) * s.u, y2); }
    ctx.restore();
  }
  function szerDwoch(s, px, sk2, waga2) { const ctx = s.ctx; ctx.font = font(s, px, s.p.waga); const w1 = ctx.measureText(tekstP(s, s.p.tekst)).width; ctx.font = font(s, px * (sk2 || 0.52), waga2 || 500); const w2 = s.p.tekst2 ? ctx.measureText(s.p.tekst2).width : 0; return { w1, w2, w: Math.max(w1, w2) }; }
  function awatar(s, cx, cy, r, kol, sk = 1) {
    const ctx = s.ctx, img = s.p.logo; ctx.save(); ctx.translate(cx, cy); ctx.scale(sk, sk); ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fillStyle = kol; ctx.fill();
    if (img && (img.width || img.naturalWidth)) { ctx.clip(); const iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height, k = Math.max(2 * r / iw, 2 * r / ih); ctx.drawImage(img, -iw * k / 2, -ih * k / 2, iw * k, ih * k); }
    else { const ini = inicjaly(s.p.tekst); ctx.font = font(s, r * 0.9, 800); ctx.fillStyle = kontrast(kol); const w = ctx.measureText(ini).width; ctx.fillText(ini, -w / 2, r * 0.03); }
    ctx.restore();
  }
  belkaN("belka-mowca-fala", "Belka mówcy z falą dźwięku", { tekst: "Ewa Nowicka", tekst2: "Gość podcastu" }, (s) => {
    const ctx = s.ctx, px = 50 * s.u * s.p.rozmiar, m = szerDwoch(s, px), h = px * 2.3, kw = h * 1.1, W = m.w + kw + 50 * s.u, p = prawa(s), x0 = xWyr(s, W), y0 = s.poz.y - h / 2;
    const a = E.outBackMocno(T(s, 0, 0.45)), e = E.outQuint(T(s, 0.15, 0.6)), r = h * 0.3, cx = p ? x0 + W - kw / 2 : x0 + kw / 2, cy = y0 + h / 2;
    karta(s, p ? x0 + W * (1 - e) : x0, y0, W * e, h, h / 2, rgba(s.k.tl, 0.92));
    const g = E.outCubic(T(s, 0.35, 0.5)); ctx.strokeStyle = s.k.a; ctx.lineCap = "round"; ctx.lineWidth = 4 * s.u;
    for (let i = 0; i < 30; i++) { const k = (i / 30) * PI * 2, d = r * 1.12, L = (0.08 + 0.3 * Math.abs(Math.sin(s.t * 7 + i * 1.9) * Math.sin(s.t * 3.1 + i * 0.7))) * r * g; ctx.beginPath(); ctx.moveTo(cx + Math.cos(k) * d, cy + Math.sin(k) * d); ctx.lineTo(cx + Math.cos(k) * (d + L), cy + Math.sin(k) * (d + L)); ctx.stroke(); }
    awatar(s, cx, cy, r, s.k.g, a);
    ctx.save(); ctx.beginPath(); ctx.rect(x0, y0, W, h); ctx.clip(); const tx = p ? x0 + 34 * s.u : x0 + kw; dwieLinie(s, tx, cy, px, E.outCubic(T(s, 0.3, 0.5)), E.outCubic(T(s, 0.42, 0.5)), { k2: s.k.a }); ctx.restore();
  });
  belkaN("belka-kanal-zweryfikowany", "Nazwa kanału z odznaką weryfikacji", { tekst: "Nada Studio", tekst2: "248 tys. subskrybentów" }, (s) => {
    const ctx = s.ctx, px = 54 * s.u * s.p.rozmiar, m = szerDwoch(s, px, 0.5), h = px * 2.2, r = h * 0.36, W = h + m.w + px * 1.3 + 40 * s.u, x0 = xWyr(s, W), y0 = s.poz.y - h / 2;
    const e = E.outQuint(T(s, 0, 0.55)), a = E.outBackMocno(T(s, 0.1, 0.45)), cy = y0 + h / 2;
    karta(s, x0, y0, W * e, h, 20 * s.u, rgba(s.k.tl, 0.92)); awatar(s, x0 + h / 2, cy, r, s.k.g, a);
    ctx.save(); ctx.beginPath(); ctx.rect(x0, y0, W * e, h); ctx.clip(); dwieLinie(s, x0 + h, cy, px, E.outCubic(T(s, 0.25, 0.5)), E.outCubic(T(s, 0.4, 0.5)), { sk2: 0.5 }); ctx.restore();
    const b = E.outBackMocno(T(s, 0.6, 0.45)); if (b <= 0) return; ctx.font = font(s, px, s.p.waga); const bxp = x0 + h + ctx.measureText(tekstP(s, s.p.tekst)).width + px * 0.6, byp = s.p.tekst2 ? cy - px * 0.36 : cy, br = px * 0.4;
    ctx.save(); ctx.translate(bxp, byp); ctx.scale(b, b); ctx.rotate((1 - b) * -1.5); ctx.fillStyle = s.k.a; gwiazda(ctx, 0, 0, 10, br, br * 0.84); ctx.fill(); ptaszek(ctx, 0, 0, br * 0.62, E.outCubic(T(s, 0.8, 0.3)), kontrast(s.k.a), br * 0.22); ctx.restore();
  });
  belkaN("belka-korporacyjna", "Belka korporacyjna z logo", { tekst: "Magdalena Wróbel", tekst2: "Dyrektor finansowa · Nadamedia" }, (s) => {
    const ctx = s.ctx, px = 48 * s.u * s.p.rozmiar, m = szerDwoch(s, px, 0.55, 600), h = px * 2.3, lw = h, W = lw + m.w + 70 * s.u, x0 = xWyr(s, W), y0 = s.poz.y - h / 2, kj = jasna(s), kt = ciemnyNa(kj);
    const e = E.outQuint(T(s, 0, 0.6)), a = E.outBack(T(s, 0.2, 0.45)), l = E.inOutCubic(T(s, 0.35, 0.6));
    karta(s, x0, y0, W * e, h, 6 * s.u, kj);
    ctx.save(); ctx.translate(x0 + lw / 2, y0 + h / 2); ctx.scale(a, a); const img = s.p.logo, q = lw * 0.62;
    if (img && (img.width || img.naturalWidth)) { const iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height, k = Math.min(q / iw, q / ih); ctx.drawImage(img, -iw * k / 2, -ih * k / 2, iw * k, ih * k); }
    else { ctx.fillStyle = s.k.g; zaokr(ctx, -q / 2, -q / 2, q, q, 8 * s.u); ctx.fill(); ctx.font = font(s, q * 0.45, 800); ctx.fillStyle = kontrast(s.k.g); const ini = inicjaly(s.p.tekst), iw = ctx.measureText(ini).width; ctx.fillText(ini, -iw / 2, 0); }
    ctx.restore();
    ctx.fillStyle = rgba(kt, 0.18); ctx.fillRect(x0 + lw, y0 + h * 0.2, 2 * s.u, h * 0.6 * a);
    ctx.save(); ctx.beginPath(); ctx.rect(x0, y0, W * e, h); ctx.clip(); dwieLinie(s, x0 + lw + 30 * s.u, y0 + h / 2, px, E.outCubic(T(s, 0.3, 0.5)), E.outCubic(T(s, 0.42, 0.5)), { k1: kt, k2: s.k.g, sk2: 0.55, waga2: 600 }); ctx.restore();
    ctx.fillStyle = s.k.g; ctx.fillRect(x0, y0 + h, W * l, 6 * s.u);
  }, { pola: ["tekst", "tekst2", "logo"] });
  belkaN("belka-sport", "Belka sportowa z numerem", { tekst: "Kamil Nowak", tekst2: "KS Kamionka · napastnik", liczba: 9, wielkie: true }, (s) => {
    const ctx = s.ctx, px = 56 * s.u * s.p.rozmiar, h1 = px * 1.6, h2 = px * 0.95, sk = 0.22, nr = String(Math.round(+s.p.liczba || 0)), nw = h1 + h2;
    ctx.font = font(s, px, 900); const w1 = ctx.measureText(tekstP(s, s.p.tekst)).width + 60 * s.u; ctx.font = font(s, px * 0.5, 700); const w2 = s.p.tekst2 ? ctx.measureText(String(s.p.tekst2).toLocaleUpperCase("pl")).width + 50 * s.u : 0;
    const W = nw + Math.max(w1, w2), x0 = xWyr(s, W), y0 = s.poz.y - (h1 + h2) / 2;
    ctx.save(); ctx.translate(x0 + W / 2, s.poz.y); ctx.transform(1, 0, -sk, 1, 0, 0); ctx.translate(-x0 - W / 2, -s.poz.y);
    for (let i = 0; i < 3; i++) { const p = T(s, i * 0.05, 0.5); if (p <= 0 || p >= 1) continue; ctx.fillStyle = [s.k.a, s.k.g, "#FFFFFF"][i]; const sx = lerp(x0 - 200 * s.u, x0 + W + 100 * s.u, E.inOutCubic(p)); ctx.fillRect(sx, y0, 26 * s.u, h1 + h2); }
    const a = E.outQuint(T(s, 0.2, 0.55)), b = E.outQuint(T(s, 0.32, 0.55)), c = E.outBackMocno(T(s, 0.25, 0.45));
    ctx.fillStyle = s.k.g; ctx.fillRect(x0 + nw, y0, w1 * a, h1); ctx.fillStyle = rgba(s.k.tl, 0.95); if (w2) ctx.fillRect(x0 + nw, y0 + h1, w2 * b, h2);
    ctx.save(); ctx.translate(x0 + nw / 2, y0 + (h1 + h2) / 2); ctx.scale(c, c); ctx.fillStyle = s.k.a; ctx.fillRect(-nw / 2, -(h1 + h2) / 2, nw, h1 + h2); ctx.font = font(s, (h1 + h2) * 0.62, 900); ctx.fillStyle = kontrast(s.k.a); const tw = ctx.measureText(nr).width; ctx.fillText(nr, -tw / 2, 0); ctx.restore();
    ctx.save(); ctx.beginPath(); ctx.rect(x0 + nw, y0, Math.max(w1, w2), h1 + h2); ctx.clip();
    ctx.font = font(s, px, 900); ctx.fillStyle = kontrast(s.k.g); ctx.fillText(tekstP(s, s.p.tekst), x0 + nw + 30 * s.u - (1 - a) * w1, y0 + h1 / 2);
    if (w2) { ctx.font = font(s, px * 0.5, 700); ctx.fillStyle = s.k.t; ctx.fillText(String(s.p.tekst2).toLocaleUpperCase("pl"), x0 + nw + 25 * s.u - (1 - b) * w2, y0 + h1 + h2 / 2); }
    ctx.restore(); ctx.restore();
  }, { pola: ["tekst", "tekst2", "liczba"] });
  belkaN("belka-tv-wywiad", "Belka telewizyjna (wywiad)", { tekst: "Prof. Jan Wiśniewski", tekst2: "Ekonomista, Uniwersytet Ekonomiczny" }, (s) => {
    const ctx = s.ctx, px = 50 * s.u * s.p.rozmiar, m = szerDwoch(s, px, 0.6, 600), h1 = px * 1.55, h2 = px * 1.05, pad = 28 * s.u, W = m.w + pad * 2 + 30 * s.u, x0 = xWyr(s, W), y0 = s.poz.y - (h1 + h2) / 2;
    const a = E.outQuint(T(s, 0, 0.55)), b = E.outBack(T(s, 0.3, 0.5)), kj = "#FFFFFF";
    ctx.fillStyle = s.k.a; ctx.fillRect(x0 - 14 * s.u, y0, 14 * s.u, (h1 + (s.p.tekst2 ? h2 : 0)) * a);
    karta(s, x0, y0, (m.w1 + pad * 2 + 30 * s.u) * a, h1, 0, kj, ctx, 0.6);
    ctx.save(); ctx.beginPath(); ctx.rect(x0, y0, W, h1); ctx.clip(); ctx.font = font(s, px, s.p.waga); ctx.fillStyle = "#111111"; ctx.fillText(tekstP(s, s.p.tekst), x0 + pad - (1 - a) * 80 * s.u, y0 + h1 / 2); ctx.restore();
    if (s.p.tekst2 && b > 0) { const w2 = m.w2 + pad * 2; ctx.save(); ctx.translate(0, y0 + h1); ctx.scale(1, Math.max(0.01, b)); ctx.fillStyle = s.k.g; ctx.fillRect(x0, 0, w2, h2); ctx.font = font(s, px * 0.6, 600); ctx.fillStyle = kontrast(s.k.g); ctx.fillText(s.p.tekst2, x0 + pad, h2 / 2); ctx.restore(); }
  });
  belkaN("belka-jedna-linia", "Imię i rola w jednej linii", { tekst: "Ola Mazur", tekst2: "fotografka ślubna" }, (s) => {
    const ctx = s.ctx, px = 54 * s.u * s.p.rozmiar; ctx.font = font(s, px, s.p.waga); const w1 = ctx.measureText(tekstP(s, s.p.tekst)).width; ctx.font = font(s, px * 0.78, 400); const w2 = s.p.tekst2 ? ctx.measureText(s.p.tekst2).width : 0;
    const gap = px * 0.7, W = w1 + gap + w2, x0 = xWyr(s, W), cx = x0 + w1 + gap / 2, y = s.poz.y, a = E.outBackMocno(T(s, 0, 0.4)), e1 = E.outQuint(T(s, 0.25, 0.6)), e2 = E.outQuint(T(s, 0.35, 0.6));
    ctx.save(); ctx.translate(cx, y); ctx.scale(a, a); ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(0, 0, px * 0.16, 0, PI * 2); ctx.fill(); ctx.restore();
    ctx.save(); ctx.beginPath(); ctx.rect(0, y - px, cx - px * 0.25, px * 2); ctx.clip(); cien(s); ctx.font = font(s, px, s.p.waga); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), x0 + (1 - e1) * (w1 + gap), y); ctx.restore();
    if (w2) { ctx.save(); ctx.beginPath(); ctx.rect(cx + px * 0.25, y - px, s.W, px * 2); ctx.clip(); cien(s); ctx.font = font(s, px * 0.78, 400); ctx.fillStyle = rgba(s.k.t, 0.9); ctx.fillText(s.p.tekst2, cx + gap / 2 - (1 - e2) * (w2 + gap), y); ctx.restore(); }
  });
  belkaN("belka-narozniki", "Belka w narożnikach", { tekst: "Dawid Lis", tekst2: "Operator drona" }, (s) => {
    const ctx = s.ctx, px = 56 * s.u * s.p.rozmiar, m = szerDwoch(s, px), pad = 34 * s.u, h = px * (s.p.tekst2 ? 2.3 : 1.6), W = m.w + pad * 2, x0 = xWyr(s, W), y0 = s.poz.y - h / 2;
    const e = E.outQuint(T(s, 0, 0.6)), d = 34 * s.u * s.p.rozmiar, cx = x0 + W / 2, cy = y0 + h / 2, ox = W / 2 * e, oy = h / 2 * e;
    ctx.fillStyle = rgba(s.k.tl, 0.55 * e); ctx.fillRect(cx - ox, cy - oy, ox * 2, oy * 2);
    ctx.strokeStyle = s.k.a; ctx.lineWidth = 6 * s.u; ctx.lineCap = "square";
    [[-1, -1], [1, -1], [1, 1], [-1, 1]].forEach(([a, b]) => { const x = cx + a * Math.max(ox, d * 0.6), y = cy + b * Math.max(oy, d * 0.6); ctx.beginPath(); ctx.moveTo(x - a * d, y); ctx.lineTo(x, y); ctx.lineTo(x, y - b * d); ctx.stroke(); });
    dwieLinie(s, x0 + pad, cy, px, E.outCubic(T(s, 0.35, 0.5)), E.outCubic(T(s, 0.5, 0.5)), { dx: 0 });
  });
  belkaN("belka-identyfikator", "Identyfikator na smyczy", { tekst: "Kasia Lis", tekst2: "Organizatorka", przed: "Ekipa" }, (s) => {
    const ctx = s.ctx, px = 50 * s.u * s.p.rozmiar, m = szerDwoch(s, px, 0.55), W = Math.max(m.w + 70 * s.u, 300 * s.u * s.p.rozmiar), hb = px * 1.3, h = hb + px * (s.p.tekst2 ? 2.6 : 1.9);
    const t = s.t - 0.05, kat = 0.55 * Math.exp(-t * 2.6) * Math.cos(t * 7) * (t > 0 ? 1 : 0), cx = xWyr(s, W) + W / 2, top = s.poz.y - h / 2, py = top - 50 * s.u, d = E.outBack(T(s, 0, 0.5));
    ctx.save(); ctx.translate(cx, py - (1 - d) * 400 * s.u); ctx.rotate(kat);
    ctx.strokeStyle = s.k.g; ctx.lineWidth = 12 * s.u; ctx.beginPath(); ctx.moveTo(-W * 0.18, -s.H); ctx.lineTo(0, 0); ctx.lineTo(W * 0.18, -s.H); ctx.stroke();
    ctx.fillStyle = "#9CA3AF"; zaokr(ctx, -22 * s.u, -8 * s.u, 44 * s.u, 64 * s.u, 8 * s.u); ctx.fill();
    ctx.translate(0, 50 * s.u); karta(s, -W / 2, 0, W, h, 20 * s.u, "#FFFFFF");
    ctx.save(); zaokr(ctx, -W / 2, 0, W, h, 20 * s.u); ctx.clip(); ctx.fillStyle = s.k.g; ctx.fillRect(-W / 2, 0, W, hb); ctx.restore();
    ctx.fillStyle = "rgba(0,0,0,0.25)"; zaokr(ctx, -40 * s.u, 10 * s.u, 80 * s.u, 12 * s.u, 6 * s.u); ctx.fill();
    const lb = String(s.p.przed || "GOŚĆ").toLocaleUpperCase("pl"); ctx.font = font(s, hb * 0.38, 800); ctx.fillStyle = kontrast(s.k.g); ctx.fillText(lb, -ctx.measureText(lb).width / 2, hb * 0.66);
    ctx.font = font(s, px, s.p.waga); ctx.fillStyle = "#111111"; const n = tekstP(s, s.p.tekst); ctx.fillText(n, -ctx.measureText(n).width / 2, hb + px * 0.95);
    if (s.p.tekst2) { ctx.font = font(s, px * 0.55, 500); ctx.fillStyle = s.k.g; ctx.fillText(s.p.tekst2, -ctx.measureText(s.p.tekst2).width / 2, hb + px * 1.95); }
    ctx.restore();
  }, { pola: ["tekst", "tekst2", "przed"], dom: { pozycja: "prawy-gora" } });
  belkaN("belka-dwie-osoby", "Dwie osoby w rozmowie", { lista: "Anna Kowalska – prowadząca; Piotr Nowak – gość" }, (s) => {
    const ctx = s.ctx, os = lista(s.p.lista).slice(0, 2).map((x) => { const i = x.search(/\s[–—-]\s|,\s/); return i > 0 ? [x.slice(0, i).trim(), x.slice(i).replace(/^\s*[–—,-]\s*/, "").trim()] : [x, ""]; }), px = 46 * s.u * s.p.rozmiar, h = px * 2.2, y0 = s.poz.y - h / 2;
    os.forEach(([n, r], i) => {
      const p = i === 1, e = E.outQuint(T(s, i * 0.2, 0.6)), ee = E.outCubic(T(s, i * 0.2 + 0.25, 0.5)); ctx.font = font(s, px, s.p.waga); const w1 = ctx.measureText(tekstP(s, n)).width; ctx.font = font(s, px * 0.55, 600); const w2 = ctx.measureText(r).width;
      const W = Math.max(w1, w2) + 60 * s.u, m = s.W * 0.05, x0 = p ? s.W - m - W : m, kol = p ? s.k.a : s.k.g;
      ctx.save(); ctx.beginPath(); ctx.rect(p ? x0 : x0 - 20, y0 - 20, W + 20, h + 40); ctx.clip(); ctx.translate((p ? 1 : -1) * (1 - e) * (W + 40 * s.u), 0);
      karta(s, x0, y0, W, h, 14 * s.u, rgba(s.k.tl, 0.92)); ctx.fillStyle = kol; ctx.fillRect(p ? x0 + W - 10 * s.u : x0, y0, 10 * s.u, h);
      ctx.globalAlpha = s.alfa * ee; const tx = p ? x0 + W - 30 * s.u : x0 + 30 * s.u;
      ctx.font = font(s, px, s.p.waga); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, n), p ? tx - w1 : tx, r ? y0 + h * 0.37 : y0 + h / 2);
      if (r) { ctx.font = font(s, px * 0.55, 600); ctx.fillStyle = kol; ctx.fillText(r, p ? tx - w2 : tx, y0 + h * 0.72); } ctx.restore();
    });
  }, { pola: ["lista"], dom: { pozycja: "dol" } });
  belkaN("belka-pelny-pasek", "Pełny pasek na dole kadru", { tekst: "Marta Zając", tekst2: "Trenerka biegania · Nowy Sącz" }, (s) => {
    const ctx = s.ctx, px = 50 * s.u * s.p.rozmiar; ctx.font = font(s, px, s.p.waga); const w1 = ctx.measureText(tekstP(s, s.p.tekst)).width; ctx.font = font(s, px * 0.6, 500); const w2 = s.p.tekst2 ? ctx.measureText(s.p.tekst2).width : 0;
    const m = 50 * s.u, obok = w1 + w2 + 120 * s.u < s.W - m * 2, h = px * (obok || !w2 ? 1.9 : 2.6), y0 = s.poz.y - h / 2, e = E.outQuint(T(s, 0, 0.6)), l = E.inOutCubic(T(s, 0.2, 1.2));
    ctx.fillStyle = rgba(s.k.tl, 0.9); ctx.fillRect(0, y0 + h * (1 - e), s.W, h * e); ctx.fillStyle = rgba(s.k.t, 0.15); ctx.fillRect(0, y0, s.W, 4 * s.u * e); ctx.fillStyle = s.k.g; ctx.fillRect(0, y0, s.W * l, 4 * s.u * e);
    ctx.save(); ctx.beginPath(); ctx.rect(0, y0, s.W, h); ctx.clip(); const a = E.outCubic(T(s, 0.3, 0.5)), b = E.outCubic(T(s, 0.45, 0.5));
    ctx.font = font(s, px, s.p.waga); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), m, (obok || !w2 ? y0 + h / 2 : y0 + h * 0.36) + (1 - a) * h);
    if (w2) { ctx.font = font(s, px * 0.6, 500); ctx.fillStyle = s.k.a; ctx.fillText(s.p.tekst2, obok ? s.W - m - w2 : m, (obok ? y0 + h / 2 : y0 + h * 0.72) + (1 - b) * h); }
    ctx.restore();
  }, { dom: { pozycja: "dol" } });
  function papier(ctx, x, y, w, h, z, s) { const n = Math.max(6, Math.round(h / (9 * s.u))); ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + w, y);
    for (let i = 1; i <= n; i++) ctx.lineTo(x + w + (los(i + z) - 0.5) * 14 * s.u, y + h * i / n); ctx.lineTo(x, y + h); for (let i = n - 1; i >= 0; i--) ctx.lineTo(x + (los(i * 3 + z + 5) - 0.5) * 14 * s.u, y + h * i / n); ctx.closePath(); }
  belkaN("belka-wycinek", "Belka jak wycinek z gazety", { tekst: "Józef Kmita", tekst2: "rzeźbiarz ludowy, 78 lat" }, (s) => {
    const ctx = s.ctx, px = 52 * s.u * s.p.rozmiar, m = szerDwoch(s, px, 0.6, 600), x0 = xWyr(s, m.w1 + 60 * s.u), y = s.poz.y - (s.p.tekst2 ? px * 0.5 : 0);
    [[tekstP(s, s.p.tekst), px, s.p.waga, m.w1, -0.035, 0, "#F5F0E6", 3], [s.p.tekst2, px * 0.6, 600, m.w2, 0.02, px * 1.25, "#111111", 9]].forEach(([t, r, wg, w, rot, dy, kol, z], i) => {
      if (!t) return; const e = T(s, i * 0.2, 0.35), sk = lerp(1.5, 1, E.outBack(e)); if (e <= 0) return; const W = w + 50 * s.u, h = r * 1.7;
      ctx.save(); ctx.translate(x0 + W / 2 + i * 30 * s.u, y + dy); ctx.rotate(rot); ctx.scale(sk, sk); ctx.globalAlpha = s.alfa * clamp(e * 3); cien(s, ctx, 0.8); ctx.fillStyle = kol; papier(ctx, -W / 2, -h / 2, W, h, z, s); ctx.fill(); bezCienia(ctx);
      ctx.font = font(s, r, wg); ctx.fillStyle = i ? "#F5F0E6" : "#111111"; ctx.fillText(t, -w / 2, 0); ctx.restore();
    });
  });
  belkaN("belka-zakreslacz", "Nazwisko na pociągnięciu markera", { tekst: "Bartek Górski", tekst2: "Twórca rolek" }, (s) => {
    const ctx = s.ctx, px = 60 * s.u * s.p.rozmiar, m = szerDwoch(s, px), x0 = xWyr(s, m.w1 + 40 * s.u), y = s.poz.y - (s.p.tekst2 ? px * 0.4 : 0), e = E.inOutCubic(T(s, 0, 0.55));
    ctx.save(); ctx.strokeStyle = s.k.a; ctx.lineCap = "round"; ctx.lineWidth = px * 1.05; ctx.globalAlpha = s.alfa * 0.95; ctx.beginPath();
    const L = (m.w1 + 40 * s.u - px * 0.6) * e; for (let i = 0; i <= 16; i++) { const xx = x0 + px * 0.3 + L * i / 16, yy = y + Math.sin(i * 1.4) * 2.5 * s.u - i * 0.4 * s.u; i ? ctx.lineTo(xx, yy) : ctx.moveTo(xx, yy); } if (e > 0) ctx.stroke(); ctx.restore();
    const a = E.outCubic(T(s, 0.3, 0.4)); ctx.save(); ctx.globalAlpha = s.alfa * a; ctx.font = font(s, px, s.p.waga); ctx.fillStyle = kontrast(s.k.a); ctx.fillText(tekstP(s, s.p.tekst), x0 + 20 * s.u, y); ctx.restore();
    if (s.p.tekst2) { const b = E.outCubic(T(s, 0.5, 0.5)); ctx.save(); ctx.globalAlpha = s.alfa * b; cien(s); ctx.font = font(s, px * 0.55, 600); ctx.fillStyle = s.k.t; ctx.fillText(s.p.tekst2, x0 + 20 * s.u + (1 - b) * -30 * s.u, y + px * 1.05); ctx.restore(); }
  });
  belkaN("belka-ekspert", "Belka eksperta z odznaką", { tekst: "dr Alicja Krawiec", tekst2: "dietetyczka kliniczna", przed: "Ekspert" }, (s) => {
    const ctx = s.ctx, px = 50 * s.u * s.p.rozmiar, m = szerDwoch(s, px), h = px * 2.4, r = h * 0.42, W = m.w + r * 2 + 80 * s.u, x0 = xWyr(s, W), y0 = s.poz.y - h / 2, cy = y0 + h / 2;
    const e = E.outQuint(T(s, 0.1, 0.6)), a = E.outBackMocno(T(s, 0, 0.5)), cx = x0 + r + 10 * s.u;
    karta(s, cx, y0 + h * 0.08, (W - r - 10 * s.u) * e, h * 0.84, h * 0.42, rgba(s.k.tl, 0.92));
    ctx.save(); ctx.translate(cx, cy); ctx.scale(a, a); ctx.rotate((1 - a) * -2 + s.t * 0.15); cien(s); ctx.fillStyle = s.k.a; gwiazda(ctx, 0, 0, 14, r, r * 0.86); ctx.fill(); bezCienia(ctx);
    ctx.rotate(-(1 - a) * -2 - s.t * 0.15); ctx.strokeStyle = kontrast(s.k.a); ctx.lineWidth = r * 0.06; ctx.beginPath(); ctx.arc(0, 0, r * 0.68, 0, PI * 2); ctx.stroke(); ptaszek(ctx, 0, 0, r * 0.42, E.outCubic(T(s, 0.4, 0.4)), kontrast(s.k.a), r * 0.14); ctx.restore();
    const lb = String(s.p.przed || "").toLocaleUpperCase("pl"), tx = cx + r + 26 * s.u;
    if (lb) { const b = E.outBackMocno(T(s, 0.45, 0.4)); ctx.save(); ctx.translate(tx, y0 + h * 0.08); ctx.scale(b, b); ctx.font = font(s, px * 0.36, 800); const lw = ctx.measureText(lb).width + 24 * s.u; ctx.fillStyle = s.k.g; zaokr(ctx, 0, -px * 0.3, lw, px * 0.6, px * 0.3); ctx.fill(); ctx.fillStyle = kontrast(s.k.g); ctx.fillText(lb, 12 * s.u, 0); ctx.restore(); }
    ctx.save(); ctx.beginPath(); ctx.rect(cx + r, y0, W, h); ctx.clip(); dwieLinie(s, tx, cy + px * 0.08, px, E.outCubic(T(s, 0.3, 0.5)), E.outCubic(T(s, 0.42, 0.5)), { k2: s.k.a }); ctx.restore();
  }, { pola: ["tekst", "tekst2", "przed"] });
  belkaN("belka-strzalka", "Belka w kształcie strzałki", { tekst: "Szymon Bąk", tekst2: "Mechanik, warsztat Bąk" }, (s) => {
    const ctx = s.ctx, px = 52 * s.u * s.p.rozmiar, m = szerDwoch(s, px, 0.55), h1 = px * 1.6, h2 = px * 1.05, gr = h1 * 0.45, x0 = xWyr(s, m.w + 140 * s.u), y0 = s.poz.y - (h1 + h2 + 8 * s.u) / 2;
    const strz = (x, y, w, h, kol, e) => { const g = h * 0.45; w = w * e; if (w <= 1) return; ctx.save(); cien(s, ctx, 0.7); ctx.fillStyle = kol; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + w, y); ctx.lineTo(x + w + g, y + h / 2); ctx.lineTo(x + w, y + h); ctx.lineTo(x, y + h); ctx.lineTo(x + g, y + h / 2); ctx.closePath(); ctx.fill(); ctx.restore(); };
    const a = E.outQuint(T(s, 0, 0.55)), b = E.outQuint(T(s, 0.18, 0.55));
    strz(x0, y0, m.w1 + 70 * s.u, h1, s.k.g, a); if (s.p.tekst2) strz(x0 + gr * 0.6, y0 + h1 + 8 * s.u, m.w2 + 70 * s.u, h2, s.k.a, b);
    ctx.save(); ctx.globalAlpha = s.alfa * clamp(a * 2 - 0.6); ctx.font = font(s, px, s.p.waga); ctx.fillStyle = kontrast(s.k.g); ctx.fillText(tekstP(s, s.p.tekst), x0 + gr + 12 * s.u, y0 + h1 / 2);
    if (s.p.tekst2) { ctx.globalAlpha = s.alfa * clamp(b * 2 - 0.6); ctx.font = font(s, px * 0.55, 600); ctx.fillStyle = kontrast(s.k.a); ctx.fillText(s.p.tekst2, x0 + gr * 1.6 + 12 * s.u, y0 + h1 + 8 * s.u + h2 / 2); } ctx.restore();
  });
  belkaN("belka-profil-story", "Profil z kółkiem relacji", { tekst: "Zuza w podróży", tekst2: "@zuzawpodrozy" }, (s) => {
    const ctx = s.ctx, px = 50 * s.u * s.p.rozmiar, m = szerDwoch(s, px, 0.6), r = px * 1.05, W = r * 2.6 + m.w + 20 * s.u, x0 = xWyr(s, W), cx = x0 + r * 1.25, cy = s.poz.y, a = E.outBackMocno(T(s, 0, 0.5)), o = E.inOutCubic(T(s, 0.2, 0.8));
    ctx.save(); ctx.translate(cx, cy); ctx.scale(a, a); ctx.rotate(s.t * 1.2); const g = ctx.createLinearGradient(-r, -r, r, r); g.addColorStop(0, s.k.g); g.addColorStop(0.5, s.k.a); g.addColorStop(1, s.k.g);
    ctx.strokeStyle = g; ctx.lineWidth = r * 0.14; ctx.lineCap = "round"; ctx.beginPath(); luk(ctx, 0, 0, r * 1.18, -PI / 2, -PI / 2 + PI * 2 * Math.max(0.001, o)); ctx.stroke(); ctx.restore();
    awatar(s, cx, cy, r, s.k.g, a);
    ctx.save(); cien(s); dwieLinie(s, cx + r * 1.5, cy, px, E.outCubic(T(s, 0.3, 0.5)), E.outCubic(T(s, 0.42, 0.5)), { sk2: 0.6, k2: s.k.a }); ctx.restore();
  });
  belkaN("belka-tiktok", "Podpis jak w TikToku", { tekst: "@nadamedia", tekst2: "Kulisy montażu reklamy *#montaż*", lista: "dźwięk oryginalny – nadamedia" }, (s) => {
    const ctx = s.ctx, px = 50 * s.u * s.p.rozmiar, x0 = s.poz.align === "right" ? s.poz.x - s.W * 0.7 : s.poz.align === "center" ? s.W * 0.15 : s.poz.x, y = s.poz.y - px * 1.2, a = E.outCubic(T(s, 0, 0.4)), b = E.outCubic(T(s, 0.15, 0.4)), c = E.outCubic(T(s, 0.3, 0.4));
    ctx.save(); cien(s, ctx, 1.3); ctx.globalAlpha = s.alfa * a; ctx.font = font(s, px, 800); ctx.fillStyle = s.k.t; ctx.fillText(s.p.tekst, x0, y + (1 - a) * 20 * s.u);
    if (s.p.tekst2) { ctx.globalAlpha = s.alfa * b; linia(s, s.p.tekst2, x0, y + px * 1.2 + (1 - b) * 20 * s.u, px * 0.66, 500); }
    const muz = lista(s.p.lista)[0] || ""; if (muz) { ctx.globalAlpha = s.alfa * c; const yy = y + px * 2.3, nx = x0 + px * 0.3; ctx.fillStyle = s.k.t; ctx.beginPath(); ctx.ellipse(nx - px * 0.12, yy + px * 0.16, px * 0.14, px * 0.1, -0.4, 0, PI * 2); ctx.fill(); ctx.fillRect(nx, yy - px * 0.3, px * 0.06, px * 0.46); ctx.fillRect(nx, yy - px * 0.3, px * 0.22, px * 0.08);
      const mw = s.W * 0.5; ctx.save(); ctx.beginPath(); ctx.rect(x0 + px * 0.7, yy - px * 0.5, mw, px); ctx.clip(); ctx.font = font(s, px * 0.56, 500); const fr = muz + "   ·   ", fw = ctx.measureText(fr).width, off = (s.t * 70 * s.u) % fw; for (let xx = x0 + px * 0.7 - off; xx < x0 + px * 0.7 + mw; xx += fw) ctx.fillText(fr, xx, yy); ctx.restore(); }
    ctx.restore();
    const d = E.outBack(T(s, 0.4, 0.5)); if (d > 0) { const dr = px * 0.9, dx = x0 + s.W * 0.5 + px * 1.8, dy = y + px * 2.2; ctx.save(); ctx.translate(dx, dy); ctx.scale(d, d); ctx.rotate(s.t * 2.5); ctx.fillStyle = "#222222"; ctx.beginPath(); ctx.arc(0, 0, dr, 0, PI * 2); ctx.fill(); ctx.strokeStyle = "#444444"; ctx.lineWidth = 2 * s.u; ctx.beginPath(); ctx.arc(0, 0, dr * 0.72, 0, PI * 2); ctx.stroke(); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, dr * 0.42, 0, PI * 2); ctx.fill(); ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(dr * 0.12, -dr * 0.1, dr * 0.12, 0, PI * 2); ctx.fill(); ctx.restore(); }
  }, { pola: ["tekst", "tekst2", "lista"], czas: 5 });
  belkaN("belka-elegancka", "Belka elegancka (ślub, event)", { tekst: "Anna & Michał", tekst2: "12 września 2026", waga: 500 }, (s) => {
    const ctx = s.ctx, px = 72 * s.u * s.p.rozmiar, cx = s.poz.align === "center" ? s.poz.x : xWyr(s, 0) + (prawa(s) ? -s.W * 0.25 : s.W * 0.25), y = s.poz.y - (s.p.tekst2 ? px * 0.35 : 0);
    ctx.font = font(s, px, s.p.waga); const t = tekstP(s, s.p.tekst), w = ctx.measureText(t).width, a = E.outCubic(T(s, 0.2, 0.9)), l = E.inOutCubic(T(s, 0, 1)), L = Math.min(s.W * 0.18, 220 * s.u) * l, g = 40 * s.u;
    ctx.save(); ctx.globalAlpha = s.alfa * a; cien(s); ctx.fillStyle = s.k.t; ctx.fillText(t, cx - w / 2, y + (1 - a) * 14 * s.u); ctx.restore();
    ctx.fillStyle = s.k.a; [-1, 1].forEach((k) => { const x1 = cx + k * (w / 2 + g); ctx.fillRect(k < 0 ? x1 - L : x1, y - 1 * s.u, L, 2 * s.u); const dx = x1 + k * L; ctx.save(); ctx.translate(dx, y); ctx.rotate(PI / 4); const q = 9 * s.u * l; ctx.fillRect(-q / 2, -q / 2, q, q); ctx.restore(); });
    if (s.p.tekst2) { const t2 = String(s.p.tekst2).toLocaleUpperCase("pl"), p2 = px * 0.3, od = p2 * 0.45, w2 = szerRozstrz(s, t2, p2, 500, od); ctx.save(); cien(s); rozstrzel(s, t2, cx - w2 / 2, y + px * 0.95, p2, 500, od, rgba(s.k.t, 0.9), E.outCubic(T(s, 0.6, 0.9))); ctx.restore(); }
  }, { dom: { pozycja: "dol" } });
  const ikPinezka = (ctx, x, y, r, k, tlo) => { ctx.fillStyle = k; ctx.beginPath(); ctx.arc(x, y - r * 0.25, r * 0.62, PI * 0.82, PI * 2.18); ctx.lineTo(x, y + r * 0.85); ctx.closePath(); ctx.fill(); ctx.fillStyle = tlo || "#000000"; ctx.beginPath(); ctx.arc(x, y - r * 0.25, r * 0.24, 0, PI * 2); ctx.fill(); };
  const ikKalendarz = (ctx, x, y, r, k) => { ctx.strokeStyle = k; ctx.fillStyle = k; ctx.lineWidth = r * 0.16; zaokr(ctx, x - r * 0.7, y - r * 0.55, r * 1.4, r * 1.3, r * 0.2); ctx.stroke(); ctx.fillRect(x - r * 0.7, y - r * 0.55, r * 1.4, r * 0.35); ctx.fillRect(x - r * 0.42, y - r * 0.8, r * 0.14, r * 0.35); ctx.fillRect(x + r * 0.28, y - r * 0.8, r * 0.14, r * 0.35); };
  belkaN("belka-miejsce-data", "Miejsce i data wydarzenia", { tekst: "Hala Sportowa, Nowy Sącz", tekst2: "sobota 14.11 · godz. 18:00" }, (s) => {
    const ctx = s.ctx, px = 46 * s.u * s.p.rozmiar; ctx.font = font(s, px, s.p.waga); const w1 = ctx.measureText(tekstP(s, s.p.tekst)).width; ctx.font = font(s, px * 0.85, 600); const w2 = s.p.tekst2 ? ctx.measureText(s.p.tekst2).width : 0;
    const r = px * 0.75, lh = px * 1.9, n = s.p.tekst2 ? 2 : 1, W = Math.max(w1, w2) + r * 2 + 90 * s.u, h = lh * n + 30 * s.u, x0 = xWyr(s, W), y0 = s.poz.y - h / 2, e = E.outQuint(T(s, 0, 0.55));
    karta(s, x0, y0, W * e, h, 22 * s.u, rgba(s.k.tl, 0.9));
    [[tekstP(s, s.p.tekst), px, s.p.waga, ikPinezka], [s.p.tekst2, px * 0.85, 600, ikKalendarz]].slice(0, n).forEach(([t, r2, wg, ik], i) => {
      const yy = y0 + 15 * s.u + lh * (i + 0.5), a = E.outBackMocno(T(s, 0.2 + i * 0.15, 0.4)), b = E.outCubic(T(s, 0.3 + i * 0.15, 0.45)), ix = x0 + 30 * s.u + r;
      ctx.save(); ctx.translate(ix, yy); ctx.scale(a, a); ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); ik(ctx, 0, 0, r * 0.62, kontrast(s.k.a), s.k.a); ctx.restore();
      ctx.save(); ctx.beginPath(); ctx.rect(ix + r, yy - lh / 2, W, lh); ctx.clip(); ctx.globalAlpha = s.alfa * b; ctx.font = font(s, r2, wg); ctx.fillStyle = i ? rgba(s.k.t, 0.85) : s.k.t; ctx.fillText(t, ix + r + 22 * s.u - (1 - b) * 40 * s.u, yy); ctx.restore();
    });
  });
  belkaN("belka-zza-bloku", "Belka wysuwa się zza bloku", { tekst: "Igor Malinowski", tekst2: "Producent muzyczny" }, (s) => {
    const ctx = s.ctx, px = 54 * s.u * s.p.rozmiar, m = szerDwoch(s, px), p = prawa(s), h = px * (s.p.tekst2 ? 2.3 : 1.6), bw = 16 * s.u * s.p.rozmiar, W = m.w + 60 * s.u, x0 = xWyr(s, W + bw), y0 = s.poz.y - h / 2;
    const a = E.outBack(T(s, 0, 0.4)), e = E.outQuint(T(s, 0.3, 0.6)), bx = p ? x0 + W : x0;
    ctx.save(); ctx.beginPath(); p ? ctx.rect(0, y0 - 10, bx, h + 20) : ctx.rect(bx + bw, y0 - 10, s.W, h + 20); ctx.clip();
    const dx = (p ? 1 : -1) * (1 - e) * (W + 20 * s.u), rx = p ? x0 : x0 + bw; ctx.translate(dx, 0); karta(s, rx, y0, W, h, 0, rgba(s.k.tl, 0.92));
    dwieLinie(s, rx + 30 * s.u, y0 + h / 2, px, E.outCubic(T(s, 0.5, 0.5)), E.outCubic(T(s, 0.6, 0.5)), { dx: 0 }); ctx.restore();
    ctx.save(); ctx.translate(bx + bw / 2, y0 + h / 2); ctx.scale(1, a); ctx.fillStyle = s.k.a; ctx.fillRect(-bw / 2, -h / 2 - 10 * s.u, bw, h + 20 * s.u); ctx.restore();
  });
  belkaN("belka-neobrutal", "Belka neobrutalistyczna", { tekst: "Kuba Zieliński", tekst2: "grafik i ilustrator" }, (s) => {
    const ctx = s.ctx, px = 52 * s.u * s.p.rozmiar; ctx.font = font(s, px, 900); const w1 = ctx.measureText(tekstP(s, s.p.tekst)).width; ctx.font = font(s, px * 0.55, 700); const w2 = s.p.tekst2 ? ctx.measureText(s.p.tekst2).width : 0;
    const gr = 5 * s.u, W1 = w1 + 56 * s.u, h1 = px * 1.7, W2 = w2 + 40 * s.u, h2 = px * 1.05, x0 = xWyr(s, W1), y0 = s.poz.y - (h1 + h2 * 0.6) / 2;
    const box = (x, y, w, h, kol, e, o, rot) => { if (e <= 0) return; ctx.save(); ctx.translate(x + w / 2, y + h / 2 - (1 - e) * 60 * s.u); ctx.rotate(rot); ctx.globalAlpha = s.alfa * clamp(e * 2); ctx.fillStyle = "#111111"; ctx.fillRect(-w / 2 + o, -h / 2 + o, w, h); ctx.fillStyle = kol; ctx.fillRect(-w / 2, -h / 2, w, h); ctx.strokeStyle = "#111111"; ctx.lineWidth = gr; ctx.strokeRect(-w / 2, -h / 2, w, h); };
    const a = E.outBackMocno(T(s, 0, 0.45)), b = E.outBackMocno(T(s, 0.25, 0.45)), o = 12 * s.u * E.outCubic(T(s, 0.2, 0.3));
    box(x0, y0, W1, h1, "#FFFFFF", a, o, -0.015); if (a > 0) { ctx.font = font(s, px, 900); ctx.fillStyle = "#111111"; ctx.fillText(tekstP(s, s.p.tekst), -w1 / 2, 0); ctx.restore(); }
    if (w2) { box(x0 + W1 * 0.35, y0 + h1 - h2 * 0.12, W2, h2, s.k.a, b, o * 0.7, 0.03); if (b > 0) { ctx.font = font(s, px * 0.55, 700); ctx.fillStyle = kontrast(s.k.a); ctx.fillText(s.p.tekst2, -w2 / 2, 0); ctx.restore(); } }
  });
  belkaN("belka-hud", "Belka technologiczna (HUD)", { tekst: "Agent 47", tekst2: "Specjalista ds. bezpieczeństwa", przed: "ID-047", font: "JetBrains Mono", waga: 700 }, (s) => {
    const ctx = s.ctx, px = 48 * s.u * s.p.rozmiar, m = szerDwoch(s, px, 0.55), pad = 30 * s.u, h = px * 2.7, W = Math.max(m.w + pad * 2, 420 * s.u), x0 = xWyr(s, W), y0 = s.poz.y - h / 2, e = E.outQuint(T(s, 0, 0.6)), d = 26 * s.u;
    ctx.fillStyle = rgba(s.k.tl, 0.7 * e); ctx.fillRect(x0, y0, W * e, h); ctx.fillStyle = rgba(s.k.a, 0.07); for (let yy = y0; yy < y0 + h; yy += 6 * s.u) ctx.fillRect(x0, yy, W * e, 2 * s.u);
    ctx.strokeStyle = s.k.a; ctx.lineWidth = 3 * s.u; [[x0, y0, 1, 1], [x0 + W * e, y0, -1, 1], [x0, y0 + h, 1, -1], [x0 + W * e, y0 + h, -1, -1]].forEach(([x, y, a, b]) => { ctx.beginPath(); ctx.moveTo(x, y + b * d); ctx.lineTo(x, y); ctx.lineTo(x + a * d, y); ctx.stroke(); });
    const sc = T(s, 0.3, 0.8); if (sc > 0 && sc < 1) { ctx.fillStyle = rgba(s.k.a, 0.5 * (1 - sc)); ctx.fillRect(x0 + W * sc - 30 * s.u, y0, 30 * s.u, h); }
    const lb = String(s.p.przed || ""), tt = tekstP(s, s.p.tekst), n1 = Math.floor(clamp((s.t - 0.35) / (Array.from(tt).length * 0.04 / s.p.tempo)) * Array.from(tt).length);
    ctx.font = font(s, px * 0.4, 700); ctx.fillStyle = s.k.a; if (lb) { if (Math.floor(s.t * 3) % 2) ctx.fillRect(x0 + pad, y0 + px * 0.4, px * 0.2, px * 0.3); ctx.fillText(lb, x0 + pad + px * 0.35, y0 + px * 0.55); }
    ctx.font = font(s, px, s.p.waga); ctx.fillStyle = s.k.t; ctx.fillText(Array.from(tt).slice(0, n1).join(""), x0 + pad, y0 + h * 0.5);
    if (s.p.tekst2) { const b = E.outCubic(T(s, 0.9, 0.4)); ctx.globalAlpha = s.alfa * b; ctx.font = font(s, px * 0.55, 500); ctx.fillStyle = rgba(s.k.t, 0.8); ctx.fillText(s.p.tekst2, x0 + pad, y0 + h * 0.78); ctx.globalAlpha = s.alfa; }
  }, { pola: ["tekst", "tekst2", "przed"] });

  // ---------- grafiki do rolek (v18) ----------
  function rolkiN(id, nazwa, przyklad, fn, o = {}) { dodaj({ id, nazwa, kat: "rolki", czas: o.czas || 4, pola: o.pola || ["tekst"], dom: o.dom, przyklad, rysuj: fn }); }
  const szerKarty = (s, k) => Math.min(s.W * 0.88, (k || 900) * s.u * s.p.rozmiar);
  /* Wejście karty: skala z odbiciem wokół środka (cx, cy). */
  function wejscieKarty(s, cx, cy, e) { const ctx = s.ctx; ctx.translate(cx, cy); const k = lerp(0.6, 1, e); ctx.scale(k, k); ctx.translate(-cx, -cy); ctx.globalAlpha = s.alfa * clamp(e * 2.5); }
  function emoji(ctx, t, x, y, px) { ctx.font = emojiFont(px); const w = ctx.measureText(t).width; ctx.fillText(t, x - w / 2, y); }
  const zielony = "#22C55E", czerwony = "#EF4444";
  function krotko(v) { v = Math.round(v); return v >= 1e6 ? liczbaTekst(v / 1e6, 1).replace(/,0$/, "") + " mln" : v >= 1e4 ? liczbaTekst(v / 1e3, 1).replace(/,0$/, "") + " tys." : liczbaTekst(v); }
  const ikSerce = (c, x, y, r, k, pelne) => { serce(c, x, y + r * 0.1, r * 0.75); if (pelne) { c.fillStyle = k; c.fill(); } else { c.strokeStyle = k; c.lineWidth = r * 0.16; c.stroke(); } };
  const ikDzielenie = (c, x, y, r, k) => { c.fillStyle = k; c.beginPath(); c.moveTo(x + r * 0.9, y - r * 0.1); c.lineTo(x + r * 0.05, y - r * 0.85); c.lineTo(x + r * 0.05, y - r * 0.45); c.quadraticCurveTo(x - r * 0.9, y - r * 0.3, x - r * 0.9, y + r * 0.8); c.quadraticCurveTo(x - r * 0.4, y + r * 0.15, x + r * 0.05, y + r * 0.2); c.lineTo(x + r * 0.05, y + r * 0.62); c.closePath(); c.fill(); };

  rolkiN("rolki-czat-na-zywo", "Czat na żywo", { lista: "Ania: ale klimat! 😍\nTomek: skąd ta kurtka?\nKasia: *pozdrawiam z Krakowa*\nMarek: 🔥🔥🔥\nOla: kiedy kolejny live?\nPiotr: dzięki za porady!" }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista).map((x) => { const i = x.indexOf(":"); return i > 0 ? [x.slice(0, i).trim(), x.slice(i + 1).trim()] : ["", x]; }), px = 40 * s.u * s.p.rozmiar, lh = px * 2.1, maxW = Math.min(s.W * 0.7, 820 * s.u);
    const krok = Math.max(0.35, (s.T - s.p.wyjscie - 0.6) / Math.max(1, el.length)) / 1, ile = Math.min(el.length, Math.floor(s.t / krok) + 1), xL = s.poz.align === "right" ? s.poz.x - maxW : s.poz.align === "center" ? s.poz.x - maxW / 2 : s.poz.x, dol = s.poz.y + lh * 1.5;
    const kol = [s.k.a, s.k.g, "#7DD3FC", "#C4B5FD", "#86EFAC"];
    for (let i = ile - 1; i >= 0; i--) {
      const wiek = ile - 1 - i, e = E.outCubic(okno(s.t - i * krok, 0, 0.3)), y = dol - (wiek + (1 - e) * -1 + (1 - e)) * lh - (1 - e) * 0, op = clamp(1 - (wiek - 3) * 0.5) * clamp(e * 2);
      if (op <= 0) continue; const [n, t] = el[i]; ctx.save(); ctx.globalAlpha = s.alfa * op; ctx.translate(0, (1 - e) * lh * 0.6);
      ctx.font = font(s, px, 800); const nw = n ? ctx.measureText(n).width + px * 0.4 : 0; ctx.font = font(s, px, 500); const tw = Math.min(maxW - nw - px * 1.2, szerLinii(s, t, px, 500)), W = nw + tw + px * 1.2;
      ctx.fillStyle = rgba(s.k.tl, 0.6); zaokr(ctx, xL, y - px * 0.85, W, px * 1.7, px * 0.85); ctx.fill();
      ctx.font = font(s, px, 800); ctx.fillStyle = kol[(n.length + i) % kol.length]; ctx.fillText(n, xL + px * 0.6, y);
      ctx.save(); ctx.beginPath(); ctx.rect(xL, y - px, W - px * 0.5, px * 2); ctx.clip(); linia(s, t, xL + px * 0.6 + nw, y, px, 500, "#FFFFFF"); ctx.restore(); ctx.restore();
    }
  }, { pola: ["lista"], czas: 5, dom: { pozycja: "lewy-dol" } });
  rolkiN("rolki-rozmowa-czat", "Rozmowa na czacie (dymki)", { lista: "Hej, robicie rolki dla firm?\n> Jasne! Jaka branża?\nPiekarnia rodzinna 🥐\n> *Idealnie*, pokażę przykłady" }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista).map((x) => ({ moje: /^>/.test(x), t: x.replace(/^>\s*/, "") })), px = 44 * s.u * s.p.rozmiar, cw = szerKarty(s, 860), x0 = s.poz.x - cw / 2, maxB = cw * 0.72;
    const krok = Math.max(0.6, (s.T - s.p.wyjscie - 0.5) / Math.max(1, el.length)); let y = 0; const uk = el.map((m) => { const u = uloz(s, m.t, px, { maxW: maxB - px * 1.4, align: "left", x: 0, y: 0, gora: true, lh: 1.25, waga: 500 }); const o = { m, u, y, h: u.h + px * 1.1 }; y += o.h + px * 0.45; return o; });
    const widoczne = uk.filter((o, i) => s.t >= i * krok), wys = widoczne.length ? widoczne[widoczne.length - 1].y + widoczne[widoczne.length - 1].h : 0, przes = Math.max(0, wys - s.H * 0.5);
    const top = s.poz.y - Math.min(wys, s.H * 0.5) / 2 - przes;
    uk.forEach((o, i) => {
      const lt = s.t - i * krok; if (lt < 0) return; const pisze = !o.m.moje && lt < 0.45 / s.p.tempo, e = E.outBack(okno(lt, pisze ? 0.45 / s.p.tempo : 0, 0.35)), bw = (pisze ? px * 3 : o.u.w + px * 1.4), bh = pisze ? px * 1.8 : o.h;
      const kol = o.m.moje ? s.k.g : "#FFFFFF", bx = o.m.moje ? x0 + cw - bw : x0, by = top + o.y;
      ctx.save(); ctx.translate(o.m.moje ? bx + bw : bx, by + bh); ctx.scale(pisze ? E.outBack(okno(lt, 0, 0.25)) : e, pisze ? E.outBack(okno(lt, 0, 0.25)) : e); ctx.translate(-(o.m.moje ? bx + bw : bx), -(by + bh));
      karta(s, bx, by, bw, bh, px * 0.75, kol, ctx, 0.6);
      if (pisze) { for (let k = 0; k < 3; k++) { ctx.fillStyle = rgba("#111111", 0.35 + 0.5 * Math.max(0, Math.sin(s.t * 9 - k))); ctx.beginPath(); ctx.arc(bx + px * (0.8 + k * 0.7), by + bh / 2, px * 0.18, 0, PI * 2); ctx.fill(); } }
      else { ctx.font = o.u.font; o.u.slowa.forEach((w) => { ctx.fillStyle = w.wyr ? (o.m.moje ? s.k.a : s.k.g) : kontrast(kol); ctx.fillText(w.t, bx + px * 0.7 + w.x, by + px * 0.55 + w.y); }); }
      ctx.restore();
    });
  }, { pola: ["lista"], czas: 6 });
  rolkiN("rolki-pasek-reakcji", "Pasek reakcji z wyborem", { lista: "👍; ❤️; 😂; 😮; 😢; 😡", emoji: "😂", tekst: "Haha!" }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista), n = el.length || 1, r = 62 * s.u * s.p.rozmiar, gap = r * 0.45, W = n * r * 2 + (n + 1) * gap, h = r * 2 + gap * 2, x0 = s.poz.x - W / 2, y0 = s.poz.y - h / 2;
    const a = E.outBack(T(s, 0, 0.4)), wyb = Math.max(0, el.indexOf(s.p.emoji)), f = E.outBack(T(s, 1.1, 0.4));
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.translate(-s.poz.x, -s.poz.y); karta(s, x0, y0, W, h, h / 2, "#FFFFFF"); ctx.restore();
    el.forEach((em, i) => {
      const e = E.outBackMocno(T(s, 0.15 + i * 0.06, 0.4)); if (e <= 0) return; const ten = i === wyb, sk = e * (ten ? 1 + 0.55 * f : 1 - 0.12 * f), cx = x0 + gap + r + i * (r * 2 + gap), cy = s.poz.y - (ten ? f * r * 0.7 : 0) + Math.sin(s.t * 6 + i) * 3 * s.u;
      ctx.save(); ctx.translate(cx, cy); ctx.scale(sk, sk); ctx.textBaseline = "middle"; emoji(ctx, em, 0, r * 0.08, r * 1.5); ctx.restore();
    });
    if (f > 0) { const cx = x0 + gap + r + wyb * (r * 2 + gap); ctx.save(); ctx.globalAlpha = s.alfa * clamp(f); ctx.font = font(s, r * 0.5, 800); const lb = tekstP(s, bezGw(s.p.tekst || "")); if (lb) { const w = ctx.measureText(lb).width + r * 0.6; karta(s, cx - w / 2, y0 - r * 2.2, w, r * 0.9, r * 0.45, rgba(s.k.tl, 0.9)); ctx.fillStyle = s.k.t; ctx.fillText(lb, cx - w / 2 + r * 0.3, y0 - r * 1.75); } ctx.restore(); }
  }, { pola: ["lista", "emoji", "tekst"], czas: 3 });
  rolkiN("rolki-statystyki-posta", "Polubienia, komentarze i udostępnienia", { lista: "Polubienia: 12400\nKomentarze: 856\nUdostępnienia: 1203" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista).slice(0, 4), r = 52 * s.u * s.p.rozmiar, lh = r * 3.3, x = s.poz.align === "left" ? s.poz.x + r : s.poz.align === "center" ? s.poz.x : s.poz.x - r, y0 = clamp(s.poz.y - (d.length - 1) * lh / 2, r * 2, s.H - (d.length - 1) * lh - r * 2.5);
    const ik = [(c, k) => ikSerce(c, 0, 0, r, k, true), (c, k) => ikDymek(c, 0, 0, r * 0.75, k), (c, k) => ikDzielenie(c, 0, 0, r * 0.85, k), (c, k) => ikZakladka(c, 0, 0, r * 0.75, k)];
    d.forEach((p, i) => {
      const e = E.outBackMocno(T(s, i * 0.15, 0.45)); if (e <= 0) return; const y = y0 + i * lh, klik = i === 0 ? T(s, 0.9, 0.35) : 0, kol = i === 0 && klik > 0 ? "#FF3B5C" : "#FFFFFF";
      ctx.save(); ctx.translate(x, y); ctx.scale(e * (1 + Math.sin(clamp(klik) * PI) * 0.35), e * (1 + Math.sin(clamp(klik) * PI) * 0.35)); cien(s, ctx, 1.3); ik[i % 4](ctx, kol); ctx.restore();
      const v = krotko(p.v * E.outCubic(T(s, 0.2 + i * 0.15, 1.4))); ctx.save(); ctx.globalAlpha = s.alfa * clamp(e); cien(s, ctx, 1.3); ctx.font = font(s, r * 0.62, 800); ctx.fillStyle = "#FFFFFF"; ctx.fillText(v, x - ctx.measureText(v).width / 2, y + r * 1.45); ctx.restore();
    });
  }, { pola: ["lista"], dom: { pozycja: "prawy-dol" } });
  rolkiN("rolki-ankieta", "Ankieta z wynikami", { tekst: "Montujesz na *telefonie*?", lista: "Tak: 64\nNie, na komputerze: 36" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista).slice(0, 4), cw = szerKarty(s, 820), px = 52 * s.u * s.p.rozmiar, pad = px * 0.7, u = uloz(s, s.p.tekst, px, { maxW: cw - pad * 2, align: "center", x: s.poz.x, y: 0, gora: true, lh: 1.2 });
    const oh = px * 1.6, h = pad * 2 + u.h + px * 0.6 + d.length * (oh + px * 0.35), x0 = s.poz.x - cw / 2, y0 = s.poz.y - h / 2, a = E.outBack(T(s, 0, 0.45)), wyn = E.outCubic(T(s, 1.0, 0.9)), suma = d.reduce((x, p) => x + p.v, 0) || 1;
    ctx.save(); wejscieKarty(s, s.poz.x, s.poz.y, a); karta(s, x0, y0, cw, h, 30 * s.u, "#FFFFFF");
    ctx.font = u.font; u.slowa.forEach((w) => { ctx.fillStyle = w.wyr ? s.k.g : "#111111"; ctx.fillText(w.t, w.x, y0 + pad + w.y); });
    d.forEach((p, i) => {
      const y = y0 + pad + u.h + px * 0.6 + i * (oh + px * 0.35), pr = p.v / suma, wyr = i === d.reduce((b, q, j) => (q.v > d[b].v ? j : b), 0);
      ctx.fillStyle = "#EFEFEF"; zaokr(ctx, x0 + pad, y, cw - pad * 2, oh, oh / 2); ctx.fill();
      if (wyn > 0) { const g = ctx.createLinearGradient(x0 + pad, 0, x0 + cw - pad, 0); g.addColorStop(0, wyr ? s.k.g : "#BDBDBD"); g.addColorStop(1, wyr ? s.k.a : "#D6D6D6"); ctx.fillStyle = g; zaokr(ctx, x0 + pad, y, Math.max(oh, (cw - pad * 2) * pr * wyn), oh, oh / 2); ctx.fill(); }
      ctx.font = font(s, px * 0.62, 700); ctx.fillStyle = "#111111"; ctx.fillText(bezGw(p.e), x0 + pad + oh * 0.45, y + oh / 2);
      if (wyn > 0) { const t = Math.round(pr * 100 * wyn) + "%"; ctx.font = font(s, px * 0.62, 900); ctx.fillText(t, x0 + cw - pad - oh * 0.4 - ctx.measureText(t).width, y + oh / 2); }
    });
    ctx.restore();
  }, { pola: ["tekst", "lista"] });
  rolkiN("rolki-quiz", "Quiz: która odpowiedź jest dobra", { tekst: "Ile klatek ma 1 sekunda w kinie?", lista: "18\n*24*\n30\n60" }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista).slice(0, 5), cw = szerKarty(s, 820), px = 50 * s.u * s.p.rozmiar, pad = px * 0.6, u = uloz(s, s.p.tekst, px, { maxW: cw - pad * 2, align: "center", x: s.poz.x, y: 0, gora: true, lh: 1.2 });
    const hh = u.h + pad * 2, oh = px * 1.8, h = hh + pad + el.length * (oh + px * 0.3), x0 = s.poz.x - cw / 2, y0 = s.poz.y - h / 2, a = E.outBack(T(s, 0, 0.45)), odp = T(s, 1.8, 0.35);
    ctx.save(); wejscieKarty(s, s.poz.x, s.poz.y, a); karta(s, x0, y0, cw, h, 28 * s.u, "#FFFFFF");
    ctx.save(); zaokr(ctx, x0, y0, cw, h, 28 * s.u); ctx.clip(); ctx.fillStyle = s.k.g; ctx.fillRect(x0, y0, cw, hh); ctx.restore();
    ctx.font = u.font; u.slowa.forEach((w) => { ctx.fillStyle = kontrast(s.k.g); ctx.fillText(w.t, w.x, y0 + pad + w.y); });
    el.forEach((t, i) => {
      const e = E.outCubic(T(s, 0.3 + i * 0.12, 0.4)); if (e <= 0) return; const dobra = /\*/.test(t), y = y0 + hh + pad * 0.7 + i * (oh + px * 0.3), lit = "ABCDE"[i];
      ctx.save(); ctx.globalAlpha *= e * (odp > 0 && !dobra ? 1 - 0.55 * odp : 1); ctx.translate((1 - e) * 40 * s.u, 0);
      ctx.fillStyle = odp > 0 && dobra ? zielony : "#F1F1F1"; zaokr(ctx, x0 + pad, y, cw - pad * 2, oh, 16 * s.u); ctx.fill();
      ctx.fillStyle = odp > 0 && dobra ? "#FFFFFF" : s.k.g; ctx.beginPath(); ctx.arc(x0 + pad + oh * 0.55, y + oh / 2, oh * 0.32, 0, PI * 2); ctx.fill();
      ctx.font = font(s, oh * 0.36, 900); ctx.fillStyle = odp > 0 && dobra ? zielony : kontrast(s.k.g); ctx.fillText(lit, x0 + pad + oh * 0.55 - ctx.measureText(lit).width / 2, y + oh / 2);
      ctx.font = font(s, px * 0.85, 700); ctx.fillStyle = odp > 0 && dobra ? "#FFFFFF" : "#111111"; ctx.fillText(bezGw(t), x0 + pad + oh * 1.1, y + oh / 2);
      if (odp > 0 && dobra) ptaszek(ctx, x0 + cw - pad - oh * 0.55, y + oh / 2, oh * 0.3, E.outCubic(odp), "#FFFFFF", 6 * s.u);
      ctx.restore();
    });
    ctx.restore();
  }, { pola: ["tekst", "lista"], czas: 4.5 });
  rolkiN("rolki-suwak-emoji", "Suwak z emoji", { tekst: "Jak bardzo lubisz *poniedziałki*?", emoji: "😍", liczba: 82 }, (s) => {
    const ctx = s.ctx, cw = szerKarty(s, 760), px = 50 * s.u * s.p.rozmiar, pad = px * 0.8, u = uloz(s, s.p.tekst, px, { maxW: cw - pad * 2, align: "center", x: s.poz.x, y: 0, gora: true, lh: 1.2 });
    const h = pad * 2 + u.h + px * 2, x0 = s.poz.x - cw / 2, y0 = s.poz.y - h / 2, a = E.outBack(T(s, 0, 0.45)), v = clamp((+s.p.liczba || 0) / 100) * E.inOutCubic(T(s, 0.6, 1.3)), ty = y0 + pad + u.h + px, tx0 = x0 + pad + px * 0.3, tw = cw - pad * 2 - px * 0.6;
    ctx.save(); wejscieKarty(s, s.poz.x, s.poz.y, a); karta(s, x0, y0, cw, h, 30 * s.u, "#FFFFFF");
    ctx.font = u.font; u.slowa.forEach((w) => { ctx.fillStyle = w.wyr ? s.k.g : "#111111"; ctx.fillText(w.t, w.x, y0 + pad + w.y); });
    ctx.fillStyle = "#E5E5E5"; zaokr(ctx, tx0, ty - 7 * s.u, tw, 14 * s.u, 7 * s.u); ctx.fill();
    const g = ctx.createLinearGradient(tx0, 0, tx0 + tw, 0); g.addColorStop(0, s.k.a); g.addColorStop(1, s.k.g); ctx.fillStyle = g; zaokr(ctx, tx0, ty - 7 * s.u, Math.max(14 * s.u, tw * v), 14 * s.u, 7 * s.u); ctx.fill();
    const kx = tx0 + tw * v, sk = 1 + v * 0.5 + Math.sin(s.t * 14) * 0.04 * (v > 0 && v < clamp((+s.p.liczba || 0) / 100) ? 1 : 0); ctx.save(); ctx.translate(kx, ty); ctx.scale(sk, sk); ctx.rotate(Math.sin(s.t * 5) * 0.12); emoji(ctx, s.p.emoji, 0, 0, px * 1.3); ctx.restore();
    ctx.restore();
  }, { pola: ["tekst", "emoji", "liczba"] });
  rolkiN("rolki-karta-cytatu", "Karta z cytatem i autorem", { tekst: "Nie musisz być wielki, żeby zacząć. Ale musisz *zacząć*, żeby być wielki.", tekst2: "Zig Ziglar" }, (s) => {
    const ctx = s.ctx, cw = szerKarty(s, 880), px = 56 * s.u * s.p.rozmiar, pad = px * 1.1, u = uloz(s, s.p.tekst, px, { maxW: cw - pad * 2, align: "left", x: 0, y: 0, gora: true, lh: 1.3, waga: 700 });
    const h = pad * 2.6 + u.h + (s.p.tekst2 ? px * 2.2 : 0), x0 = s.poz.x - cw / 2, y0 = s.poz.y - h / 2, a = E.outBack(T(s, 0, 0.5)), kc = rgba(s.k.tl, 0.95);
    ctx.save(); wejscieKarty(s, s.poz.x, s.poz.y, a); karta(s, x0, y0, cw, h, 34 * s.u, kc); ctx.fillStyle = s.k.a; ctx.fillRect(x0, y0 + h * 0.18, 10 * s.u, h * 0.64 * a);
    ctx.font = font(s, px * 3.2, 900); ctx.fillStyle = rgba(s.k.a, 0.9); ctx.fillText("“", x0 + pad * 0.7, y0 + pad * 0.85 + px * 0.6);
    ctx.font = u.font; u.slowa.forEach((w) => { const e = T(s, 0.35 + w.i * 0.05, 0.3); if (e <= 0) return; ctx.globalAlpha = s.alfa * e; ctx.fillStyle = w.wyr ? s.k.a : s.k.t; ctx.fillText(w.t, x0 + pad + w.x, y0 + pad * 1.6 + w.y + (1 - e) * 10 * s.u); });
    ctx.globalAlpha = s.alfa;
    if (s.p.tekst2) { const e = E.outCubic(T(s, 0.6 + u.slowa.length * 0.05, 0.5)), yy = y0 + pad * 1.6 + u.h + px * 1.2, r = px * 0.6; ctx.globalAlpha = s.alfa * e; ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(x0 + pad + r, yy, r, 0, PI * 2); ctx.fill();
      ctx.font = font(s, r * 0.85, 800); ctx.fillStyle = kontrast(s.k.g); const ini = inicjaly(s.p.tekst2); ctx.fillText(ini, x0 + pad + r - ctx.measureText(ini).width / 2, yy); ctx.font = font(s, px * 0.62, 700); ctx.fillStyle = s.k.t; ctx.fillText(s.p.tekst2, x0 + pad + r * 2.5, yy); }
    ctx.restore();
  }, { pola: ["tekst", "tekst2"], czas: 5 });
  rolkiN("rolki-post-tekstowy", "Post jak z serwisu społecznościowego", { tekst: "Właśnie skończyliśmy montaż 50. rolki w tym miesiącu. *Dziękujemy* za zaufanie! 🙌", tekst2: "Nada Studio · @nadastudio", liczba: 2480 }, (s) => {
    const ctx = s.ctx, cw = szerKarty(s, 900), px = 46 * s.u * s.p.rozmiar, pad = px * 0.9, u = uloz(s, s.p.tekst, px, { maxW: cw - pad * 2, align: "left", x: 0, y: 0, gora: true, lh: 1.3, waga: 500 }), r = px * 1.05;
    const [nazwa, uchwyt] = String(s.p.tekst2 || "").split("·").map((x) => x.trim()), h = pad * 2 + r * 2 + px * 0.7 + u.h + px * 2.2, x0 = s.poz.x - cw / 2, y0 = s.poz.y - h / 2, a = E.outBack(T(s, 0, 0.5));
    ctx.save(); wejscieKarty(s, s.poz.x, s.poz.y, a); karta(s, x0, y0, cw, h, 28 * s.u, "#FFFFFF");
    const g = ctx.createLinearGradient(x0 + pad, y0 + pad, x0 + pad + r * 2, y0 + pad + r * 2); g.addColorStop(0, s.k.g); g.addColorStop(1, s.k.a); ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x0 + pad + r, y0 + pad + r, r, 0, PI * 2); ctx.fill();
    ctx.font = font(s, r * 0.8, 800); ctx.fillStyle = "#FFFFFF"; const ini = inicjaly(nazwa); ctx.fillText(ini, x0 + pad + r - ctx.measureText(ini).width / 2, y0 + pad + r);
    ctx.font = font(s, px * 0.85, 800); ctx.fillStyle = "#111111"; ctx.fillText(nazwa || "", x0 + pad + r * 2.4, y0 + pad + r * (uchwyt ? 0.65 : 1));
    const nw = ctx.measureText(nazwa || "").width; ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(x0 + pad + r * 2.4 + nw + px * 0.5, y0 + pad + r * (uchwyt ? 0.65 : 1), px * 0.3, 0, PI * 2); ctx.fill(); ptaszek(ctx, x0 + pad + r * 2.4 + nw + px * 0.5, y0 + pad + r * (uchwyt ? 0.65 : 1), px * 0.17, 1, "#FFFFFF", 3 * s.u);
    if (uchwyt) { ctx.font = font(s, px * 0.7, 500); ctx.fillStyle = "#6B7280"; ctx.fillText(uchwyt, x0 + pad + r * 2.4, y0 + pad + r * 1.45); }
    const ty = y0 + pad + r * 2 + px * 0.7; ctx.font = u.font; u.slowa.forEach((w) => { const e = T(s, 0.35 + w.i * 0.04, 0.25); if (e <= 0) return; ctx.globalAlpha = s.alfa * e; ctx.fillStyle = w.wyr ? s.k.g : "#111111"; ctx.fillText(w.t, x0 + pad + w.x, ty + w.y); });
    ctx.globalAlpha = s.alfa; const fy = ty + u.h + px * 1.2, kl = T(s, 1.4, 0.3); ctx.fillStyle = "#E5E7EB"; ctx.fillRect(x0 + pad, fy - px * 0.9, cw - pad * 2, 2 * s.u);
    ctx.save(); ctx.translate(x0 + pad + px * 0.6, fy); const sk = 1 + Math.sin(clamp(kl) * PI) * 0.4; ctx.scale(sk, sk); ikSerce(ctx, 0, 0, px * 0.6, kl > 0 ? "#FF3B5C" : "#6B7280", kl > 0); ctx.restore();
    ctx.font = font(s, px * 0.66, 700); ctx.fillStyle = "#374151"; ctx.fillText(liczbaTekst(Math.round((+s.p.liczba || 0) * (0.85 + 0.15 * E.outCubic(T(s, 1.4, 1))))), x0 + pad + px * 1.4, fy);
    ikDymek(ctx, x0 + pad + px * 6, fy, px * 0.45, "#6B7280"); ikDzielenie(ctx, x0 + pad + px * 8.2, fy, px * 0.5, "#6B7280");
    ctx.restore();
  }, { pola: ["tekst", "tekst2", "liczba"], czas: 5 });
  rolkiN("rolki-lista-zadan", "Lista zadań z paskiem postępu", { tekst: "Plan na dziś", lista: "Nagrać intro\nZmontować rolkę\nDodać napisy\nOpublikować" }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista), cw = szerKarty(s, 820), px = 48 * s.u * s.p.rozmiar, pad = px * 0.8, lh = px * 1.75, h = pad * 2 + px * 2.6 + el.length * lh, x0 = s.poz.x - cw / 2, y0 = s.poz.y - h / 2, a = E.outBack(T(s, 0, 0.45));
    const krok = Math.max(0.35, (s.T - s.p.wyjscie - 1) / Math.max(1, el.length)), zrob = el.map((x, i) => E.outCubic(okno(s.t, 0.7 + i * krok, 0.35))), ile = zrob.filter((x) => x >= 1).length, post = zrob.reduce((x, y) => x + y, 0) / Math.max(1, el.length);
    ctx.save(); wejscieKarty(s, s.poz.x, s.poz.y, a); karta(s, x0, y0, cw, h, 28 * s.u, rgba(s.k.tl, 0.95));
    ctx.font = font(s, px * 1.05, 900); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), x0 + pad, y0 + pad + px * 0.5);
    const lc = `${ile}/${el.length}`; ctx.font = font(s, px * 0.75, 800); ctx.fillStyle = s.k.a; ctx.fillText(lc, x0 + cw - pad - ctx.measureText(lc).width, y0 + pad + px * 0.5);
    ctx.fillStyle = rgba(s.k.t, 0.15); zaokr(ctx, x0 + pad, y0 + pad + px * 1.3, cw - pad * 2, 12 * s.u, 6 * s.u); ctx.fill(); ctx.fillStyle = s.k.a; zaokr(ctx, x0 + pad, y0 + pad + px * 1.3, Math.max(12 * s.u, (cw - pad * 2) * post), 12 * s.u, 6 * s.u); ctx.fill();
    el.forEach((t, i) => {
      const y = y0 + pad + px * 2.6 + (i + 0.5) * lh, z = zrob[i], b = px * 0.85, tt = tekstP(s, bezGw(t));
      ctx.strokeStyle = z > 0 ? s.k.a : rgba(s.k.t, 0.5); ctx.lineWidth = 4 * s.u; ctx.fillStyle = s.k.a; zaokr(ctx, x0 + pad, y - b / 2, b, b, 10 * s.u); if (z > 0) ctx.fill(); else ctx.stroke(); if (z > 0) ptaszek(ctx, x0 + pad + b / 2, y, b * 0.36, z, kontrast(s.k.a), 5 * s.u);
      ctx.font = font(s, px * 0.8, 600); ctx.fillStyle = z >= 1 ? rgba(s.k.t, 0.5) : s.k.t; ctx.fillText(tt, x0 + pad + b + px * 0.5, y); if (z > 0) { const w = ctx.measureText(tt).width * z; ctx.fillStyle = rgba(s.k.t, 0.7); ctx.fillRect(x0 + pad + b + px * 0.5, y - 2 * s.u, w, 4 * s.u); }
    });
    ctx.restore();
  }, { pola: ["tekst", "lista"], czas: 5 });
  rolkiN("rolki-kroki-postep", "Kroki połączone linią postępu", { lista: "Brief\nNagranie\nMontaż\n*Publikacja*" }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista), n = Math.max(1, el.length), pion = s.H > s.W, r = 62 * s.u * s.p.rozmiar, px = 62 * s.u * s.p.rozmiar, D = (pion ? s.H * 0.46 : s.W * 0.72) * Math.min(1.3, s.p.rozmiar);
    const krok = Math.max(0.4, (s.T - s.p.wyjscie - 0.8) / n), post = clamp((s.t - 0.4) / (krok * (n - 1) + 0.01)), pk = (i) => { const f = n === 1 ? 0.5 : i / (n - 1); return pion ? [s.poz.x - s.W * 0.18, s.poz.y - D / 2 + D * f] : [s.poz.x - D / 2 + D * f, s.poz.y]; };
    const a = pk(0), b = pk(n - 1), l = E.outCubic(T(s, 0, 0.4)); ctx.strokeStyle = rgba(s.k.t, 0.25); ctx.lineWidth = 10 * s.u; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(...a); ctx.lineTo(lerp(a[0], b[0], l), lerp(a[1], b[1], l)); ctx.stroke();
    ctx.strokeStyle = s.k.a; ctx.beginPath(); ctx.moveTo(...a); ctx.lineTo(lerp(a[0], b[0], post), lerp(a[1], b[1], post)); if (post > 0) ctx.stroke();
    el.forEach((t, i) => {
      const [x, y] = pk(i), f = n === 1 ? 0 : i / (n - 1), done = post >= f - 0.001 && s.t > 0.4, e = E.outBackMocno(T(s, 0.1 + i * 0.1, 0.4)), akt = done && (i === n - 1 || post < (i + 1) / (n - 1) - 0.001); if (e <= 0) return;
      ctx.save(); ctx.translate(x, y); ctx.scale(e * (akt ? 1.15 : 1), e * (akt ? 1.15 : 1)); cien(s); ctx.fillStyle = done ? s.k.a : "#3A3A3A"; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); bezCienia(ctx);
      if (done && !akt) ptaszek(ctx, 0, 0, r * 0.45, 1, kontrast(s.k.a), 6 * s.u); else { ctx.font = font(s, r * 0.9, 900); ctx.fillStyle = done ? kontrast(s.k.a) : "#FFFFFF"; const nr = String(i + 1); ctx.fillText(nr, -ctx.measureText(nr).width / 2, r * 0.04); }
      ctx.restore(); ctx.save(); ctx.globalAlpha = s.alfa * clamp(e); cien(s); const tt = tekstP(s, bezGw(t)); ctx.font = font(s, px * (akt ? 1.05 : 0.9), akt ? 900 : 600); ctx.fillStyle = akt ? s.k.a : s.k.t; const w = ctx.measureText(tt).width;
      if (pion) ctx.fillText(tt, x + r * 1.6, y); else ctx.fillText(tt, x - w / 2, y + r * 2); ctx.restore();
    });
  }, { pola: ["lista"], czas: 5 });
  function plusMinus(s, el, x, y, szer, px, tytul, plus, od) {
    const ctx = s.ctx, kol = plus ? zielony : czerwony, lh = px * 1.6, a = E.outCubic(T(s, od, 0.4)); ctx.save(); ctx.globalAlpha = s.alfa * a; ctx.font = font(s, px * 1.1, 900); ctx.fillStyle = kol; ctx.fillText(tytul, x, y); ctx.fillRect(x, y + px * 0.75, szer * E.inOutCubic(T(s, od, 0.6)), 4 * s.u); ctx.restore();
    el.forEach((t, i) => { const e = E.outBack(T(s, od + 0.3 + i * 0.25, 0.4)); if (e <= 0) return; const yy = y + px * 1.9 + i * lh, r = px * 0.42; ctx.save(); ctx.translate(x + r, yy); ctx.scale(e, e); ctx.fillStyle = kol; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill();
      if (plus) ptaszek(ctx, 0, 0, r * 0.5, 1, "#FFFFFF", 4 * s.u); else krzyzyk(ctx, 0, 0, r * 0.38, 1, "#FFFFFF", 4 * s.u); ctx.restore();
      ctx.save(); ctx.globalAlpha = s.alfa * clamp(e); cien(s); linia(s, t, x + r * 2.6, yy, px * 0.85, 600); ctx.restore(); });
  }
  rolkiN("rolki-plusy-minusy", "Plusy i minusy", { lista: "+ szybki montaż\n+ niska cena\n+ *napisy w zestawie*\n- dłuższy czas renderu\n- brak wersji 4K", tekst: "Plusy", tekst2: "Minusy" }, (s) => {
    const el = lista(s.p.lista), pl = el.filter((x) => !/^[-–]/.test(x)).map((x) => x.replace(/^\+\s*/, "")), mi = el.filter((x) => /^[-–]/.test(x)).map((x) => x.replace(/^[-–]\s*/, "")), px = 50 * s.u * s.p.rozmiar, pion = s.H > s.W;
    const t1 = tekstP(s, s.p.tekst || "Plusy"), t2 = tekstP(s, s.p.tekst2 || "Minusy");
    if (pion) { const h1 = px * 2 + pl.length * px * 1.6, h2 = px * 2 + mi.length * px * 1.6, x = s.W * 0.1, y0 = s.poz.y - (h1 + h2 + px) / 2; plusMinus(s, pl, x, y0, s.W * 0.8, px, t1, true, 0); plusMinus(s, mi, x, y0 + h1 + px, s.W * 0.8, px, t2, false, 0.3 + pl.length * 0.25); }
    else { const h = px * 2 + Math.max(pl.length, mi.length) * px * 1.6, y0 = s.poz.y - h / 2; plusMinus(s, pl, s.W * 0.1, y0, s.W * 0.36, px, t1, true, 0); plusMinus(s, mi, s.W * 0.54, y0, s.W * 0.36, px, t2, false, 0.3 + pl.length * 0.25); }
  }, { pola: ["lista", "tekst", "tekst2"], czas: 5 });
  rolkiN("rolki-zrob-nie-rob", "Zrób tak, nie tak", { tekst: "Nagrywaj przy oknie", tekst2: "Nie nagrywaj pod lampą", przed: "Tak", po: "Nie" }, (s) => {
    const ctx = s.ctx, px = 52 * s.u * s.p.rozmiar, pion = s.H > s.W, cw = pion ? szerKarty(s, 860) : s.W * 0.4, gap = px * 0.8;
    const karty = [[s.p.tekst, s.p.przed || "Tak", zielony, true], [s.p.tekst2, s.p.po || "Nie", czerwony, false]].map(([t, lb, kol, ok]) => ({ t, lb, kol, ok, u: uloz(s, t, px, { maxW: cw - px * 3.4, align: "left", x: 0, y: 0, gora: true, lh: 1.2 }) }));
    const hs = karty.map((k) => Math.max(px * 2.4, k.u.h + px * 1.6)), Wc = pion ? cw : cw * 2 + gap, Hc = pion ? hs[0] + hs[1] + gap : Math.max(...hs);
    karty.forEach((k, i) => {
      const e = E.outQuint(T(s, i * 0.35, 0.6)), h = pion ? hs[i] : Hc, x = pion ? s.poz.x - cw / 2 : s.poz.x - Wc / 2 + i * (cw + gap), y = pion ? s.poz.y - Hc / 2 + (i ? hs[0] + gap : 0) : s.poz.y - Hc / 2, dx = (i ? 1 : -1) * (1 - e) * s.W * 0.7;
      ctx.save(); ctx.translate(dx, 0); karta(s, x, y, cw, h, 24 * s.u, "#FFFFFF"); ctx.fillStyle = k.kol; ctx.save(); zaokr(ctx, x, y, cw, h, 24 * s.u); ctx.clip(); ctx.fillRect(x, y, 14 * s.u, h); ctx.restore();
      const r = px * 0.8, cx = x + px * 1.4, cy = y + h / 2, b = E.outBackMocno(T(s, i * 0.35 + 0.35, 0.4)); ctx.save(); ctx.translate(cx, cy); ctx.scale(b, b); ctx.fillStyle = k.kol; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill();
      if (k.ok) ptaszek(ctx, 0, 0, r * 0.5, E.outCubic(T(s, i * 0.35 + 0.5, 0.3)), "#FFFFFF", r * 0.18); else krzyzyk(ctx, 0, 0, r * 0.4, E.outCubic(T(s, i * 0.35 + 0.5, 0.3)), "#FFFFFF", r * 0.18); ctx.restore();
      const tx = x + px * 2.7, lb = String(k.lb).toLocaleUpperCase("pl"); ctx.font = font(s, px * 0.45, 900); ctx.fillStyle = k.kol; ctx.fillText(lb, tx, y + h / 2 - k.u.h / 2 - px * 0.15);
      ctx.font = k.u.font; k.u.slowa.forEach((w) => { ctx.fillStyle = w.wyr ? s.k.g : "#111111"; ctx.fillText(w.t, tx + w.x, y + h / 2 - k.u.h / 2 + px * 0.35 + w.y); }); ctx.restore();
    });
  }, { pola: ["tekst", "tekst2", "przed", "po"] });
  rolkiN("rolki-ramka-telefonu", "Ramka telefonu na nagranie", {}, (s) => {
    const ctx = s.ctx, hh = Math.min(s.H * 0.78, s.W * 0.78 * 2.05) * s.p.rozmiar, ww = hh / 2.05, e = E.outBack(T(s, 0, 0.6)), x0 = s.poz.x - ww / 2, y0 = s.poz.y - hh / 2 + (1 - e) * s.H * 0.6, r = ww * 0.16, gr = ww * 0.045;
    const c = warstwa(s, "telefon", (x) => {
      x.fillStyle = "#1C1C1E"; zaokr(x, x0, y0, ww, hh, r); x.fill(); x.fillStyle = "#3A3A3C"; x.fillRect(x0 - gr * 0.25, y0 + hh * 0.18, gr * 0.3, hh * 0.08); x.fillRect(x0 - gr * 0.25, y0 + hh * 0.3, gr * 0.3, hh * 0.12); x.fillRect(x0 + ww - gr * 0.05, y0 + hh * 0.25, gr * 0.3, hh * 0.15);
      x.strokeStyle = "#48484A"; x.lineWidth = gr * 0.15; zaokr(x, x0 + gr * 0.08, y0 + gr * 0.08, ww - gr * 0.16, hh - gr * 0.16, r * 0.97); x.stroke();
      x.globalCompositeOperation = "destination-out"; zaokr(x, x0 + gr, y0 + gr, ww - gr * 2, hh - gr * 2, r * 0.75); x.fill();
      x.globalCompositeOperation = "source-over"; x.fillStyle = "#000000"; zaokr(x, s.poz.x - ww * 0.15, y0 + gr * 1.6, ww * 0.3, ww * 0.085, ww * 0.045); x.fill();
      x.fillStyle = rgba("#FFFFFF", 0.85); x.font = `600 ${Math.round(ww * 0.042)}px "${s.p.font}", ${FONT_ZAPAS}`; x.textBaseline = "middle"; x.fillText("9:41", x0 + gr * 2.2, y0 + gr * 2.05);
      x.fillRect(x0 + ww - gr * 3.6, y0 + gr * 1.85, ww * 0.06, ww * 0.028); x.fillStyle = rgba("#FFFFFF", 0.8); zaokr(x, s.poz.x - ww * 0.17, y0 + hh - gr * 2, ww * 0.34, ww * 0.012, ww * 0.006); x.fill();
    });
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.rotate((1 - e) * 0.15); ctx.translate(-s.poz.x, -s.poz.y); cien(s, ctx, 1.5); ctx.drawImage(c, 0, 0); ctx.restore();
  }, { pola: [], czas: 4 });
  rolkiN("rolki-okno-przegladarki", "Okno przeglądarki z adresem", { tekst: "nadamedia.pl/oferta" }, (s) => {
    const ctx = s.ctx, ww = Math.min(s.W * 0.9, s.H * 1.2) * s.p.rozmiar, hh = Math.min(ww * 0.68, s.H * 0.7), x0 = s.poz.x - ww / 2, y0 = s.poz.y - hh / 2, e = E.outBack(T(s, 0, 0.5)), bh = Math.max(56 * s.u, ww * 0.085), r = 18 * s.u;
    const url = String(s.p.tekst || ""), n = Math.floor(clamp((s.t - 0.6) / (Array.from(url).length * 0.05 / s.p.tempo)) * Array.from(url).length), kl = T(s, 0.7 + Array.from(url).length * 0.05 / s.p.tempo + 0.2, 0.35);
    const c = warstwa(s, "przegladarka", (x) => {
      x.fillStyle = "#2B2B2F"; zaokr(x, x0, y0, ww, hh, r); x.fill(); x.globalCompositeOperation = "destination-out"; x.fillRect(x0 + 6 * s.u, y0 + bh, ww - 12 * s.u, hh - bh - 6 * s.u); x.globalCompositeOperation = "source-over";
      ["#FF5F57", "#FEBC2E", "#28C840"].forEach((k, i) => { x.fillStyle = k; x.beginPath(); x.arc(x0 + bh * 0.45 + i * bh * 0.38, y0 + bh / 2, bh * 0.12, 0, PI * 2); x.fill(); });
      const ux = x0 + bh * 1.7, uw = ww - bh * 2.2, uh = bh * 0.62; x.fillStyle = "#1A1A1D"; zaokr(x, ux, y0 + (bh - uh) / 2, uw, uh, uh / 2); x.fill();
      x.strokeStyle = s.k.a; x.lineWidth = 2 * s.u; if (s.t > 0.5 && kl <= 0) { zaokr(x, ux, y0 + (bh - uh) / 2, uw, uh, uh / 2); x.stroke(); }
      x.fillStyle = "#9CA3AF"; const lx = ux + uh * 0.5, ly = y0 + bh / 2, q = uh * 0.2; x.fillRect(lx - q, ly - q * 0.2, q * 2, q * 1.5); x.strokeStyle = "#9CA3AF"; x.lineWidth = q * 0.4; x.beginPath(); x.arc(lx, ly - q * 0.2, q * 0.7, PI, 0); x.stroke();
      x.font = `500 ${Math.round(uh * 0.48)}px "${s.p.font}", ${FONT_ZAPAS}`; x.textBaseline = "middle"; x.fillStyle = "#E5E7EB"; const vis = Array.from(url).slice(0, n).join(""); x.fillText(vis, lx + uh * 0.5, ly);
      if (kl <= 0 && Math.floor(s.t * 2.5) % 2 === 0) x.fillRect(lx + uh * 0.5 + x.measureText(vis).width + 3 * s.u, ly - uh * 0.25, 3 * s.u, uh * 0.5);
      if (kl > 0 && kl < 1) { x.fillStyle = s.k.a; x.fillRect(x0 + 6 * s.u, y0 + bh - 4 * s.u, (ww - 12 * s.u) * E.outCubic(kl), 4 * s.u); }
    });
    ctx.save(); wejscieKarty(s, s.poz.x, s.poz.y, e); cien(s, ctx, 1.4); ctx.drawImage(c, 0, 0); ctx.restore();
  }, { czas: 4 });
  rolkiN("rolki-ladowanie", "Ładowanie zakończone ptaszkiem", { tekst: "Wysyłanie pliku" }, (s) => {
    const ctx = s.ctx, r = 110 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y - r * 0.3, a = E.outBack(T(s, 0, 0.4)), kon = Math.max(1.2, s.T - s.p.wyjscie - 1.1), f = E.outBack(okno(s.t, kon, 0.45)), p = clamp((s.t - 0.2) / (kon - 0.2));
    ctx.save(); ctx.translate(cx, cy); ctx.scale(a, a); ctx.lineCap = "round"; ctx.lineWidth = r * 0.14;
    if (f <= 0) { ctx.strokeStyle = rgba(s.k.t, 0.15); ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.stroke(); const k = s.t * 7, L = 0.6 + 0.9 * Math.abs(Math.sin(s.t * 2.2)); ctx.strokeStyle = s.k.a; ctx.beginPath(); ctx.arc(0, 0, r, k, k + L * 2); ctx.stroke(); }
    else { ctx.scale(f, f); ctx.fillStyle = zielony; ctx.beginPath(); ctx.arc(0, 0, r * 1.08, 0, PI * 2); ctx.fill(); ptaszek(ctx, 0, 0, r * 0.5, E.outCubic(okno(s.t, kon + 0.1, 0.35)), "#FFFFFF", r * 0.16); }
    ctx.restore();
    const t = tekstP(s, f > 0 ? "Gotowe!" : (s.p.tekst || "") + ".".repeat(1 + Math.floor(s.t * 3) % 3)), pr = f > 0 ? "" : Math.round(p * 100) + "%"; ctx.save(); ctx.globalAlpha = s.alfa * a; cien(s); ctx.font = font(s, 56 * s.u * s.p.rozmiar, 700); ctx.fillStyle = s.k.t;
    const w = ctx.measureText(f > 0 ? t : (s.p.tekst || "") + "...").width; ctx.fillText(t, cx - w / 2, cy + r * 1.75); if (pr) { ctx.font = font(s, 44 * s.u * s.p.rozmiar, 800); ctx.fillStyle = s.k.a; ctx.fillText(pr, cx - ctx.measureText(pr).width / 2, cy + 3 * s.u); } ctx.restore();
  }, { czas: 4 });
  rolkiN("rolki-paski-relacji", "Paski postępu jak w relacjach", { tekst: "nadamedia", liczba: 4, czas: 8 }, (s) => {
    const ctx = s.ctx, n = Math.max(1, Math.min(12, Math.round(+s.p.liczba || 4))), m = 24 * s.u, gap = 8 * s.u, h = 7 * s.u * s.p.rozmiar, w = (s.W - m * 2 - gap * (n - 1)) / n, y = 30 * s.u, p = clamp(s.t / s.T) * n, a = okno(s.t, 0, 0.3);
    ctx.globalAlpha = s.alfa * a;
    for (let i = 0; i < n; i++) { const x = m + i * (w + gap); ctx.fillStyle = rgba("#FFFFFF", 0.35); zaokr(ctx, x, y, w, h, h / 2); ctx.fill(); const q = clamp(p - i); if (q > 0) { ctx.fillStyle = "#FFFFFF"; zaokr(ctx, x, y, Math.max(h, w * q), h, h / 2); ctx.fill(); } }
    if (s.p.tekst) { const r = 30 * s.u * s.p.rozmiar; cien(s); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(m + r, y + h + 26 * s.u + r, r, 0, PI * 2); ctx.fill(); ctx.strokeStyle = "#FFFFFF"; ctx.lineWidth = 3 * s.u; ctx.stroke();
      ctx.font = font(s, r * 0.95, 700); ctx.fillStyle = "#FFFFFF"; ctx.fillText(s.p.tekst, m + r * 2.5, y + h + 26 * s.u + r); const tw = ctx.measureText(s.p.tekst).width; ctx.font = font(s, r * 0.85, 500); ctx.fillStyle = rgba("#FFFFFF", 0.7); ctx.fillText(Math.max(1, Math.floor(p) + 1) + " godz.", m + r * 2.5 + tw + r * 0.6, y + h + 26 * s.u + r); }
    ctx.globalAlpha = s.alfa;
  }, { pola: ["tekst", "liczba"], czas: 15, dom: { wyjscie: 0.01, wyjscie_styl: "brak" } });
  rolkiN("rolki-emoji-wybuch", "Wybuch emoji", { lista: "🎉; 🔥; 😍; ⭐; 💥", x: 0.5, y: 0.5 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), el = lista(s.p.lista).length ? lista(s.p.lista) : [s.p.emoji], n = 26;
    for (let i = 0; i < n; i++) {
      const st = los(i * 1.3) * 0.25, t = Math.max(0, s.t - st); if (t <= 0) continue; const k = los(i * 2.7) * PI * 2, v = (500 + los(i * 4.1) * 700) * s.u * s.p.rozmiar, px = (50 + los(i * 6.3) * 60) * s.u * s.p.rozmiar;
      const x = cx + Math.cos(k) * v * (1 - Math.exp(-t * 3)) * 0.5, y = cy + Math.sin(k) * v * (1 - Math.exp(-t * 3)) * 0.5 + 300 * s.u * t * t, a = clamp(t * 8) * clamp(1.6 - t * 0.7);
      if (a <= 0) continue; ctx.save(); ctx.globalAlpha = s.alfa * a; ctx.translate(x, y); ctx.rotate((los(i * 8) - 0.5) * 4 * t); const sc = E.outBack(clamp(t * 4)); ctx.scale(sc, sc); emoji(ctx, el[i % el.length], 0, 0, px); ctx.restore();
    }
    const b = E.outBackMocno(T(s, 0, 0.35)) * (1 - okno(s.t, 0.4, 0.4)); if (b > 0) { ctx.save(); ctx.translate(cx, cy); ctx.scale(b, b); emoji(ctx, el[0], 0, 0, 160 * s.u * s.p.rozmiar); ctx.restore(); }
  }, { pola: ["lista", "xy"], czas: 3, dom: { wyjscie: 0.5 } });
  rolkiN("rolki-opinia-klienta", "Opinia klienta z gwiazdkami", { tekst: "Rolki zrobione w 2 dni, a zasięgi *wzrosły trzykrotnie*. Polecam!", tekst2: "Magda, właścicielka kawiarni", liczba: 5 }, (s) => {
    const ctx = s.ctx, cw = szerKarty(s, 860), px = 48 * s.u * s.p.rozmiar, pad = px * 0.9, u = uloz(s, s.p.tekst, px, { maxW: cw - pad * 2, align: "left", x: 0, y: 0, gora: true, lh: 1.3, waga: 600 }), r = px * 0.5;
    const h = pad * 2 + r * 2.4 + px * 0.5 + u.h + px * 1.9, x0 = s.poz.x - cw / 2, y0 = s.poz.y - h / 2, a = E.outBack(T(s, 0, 0.5)), ile = clamp(+s.p.liczba || 5, 0, 5);
    ctx.save(); wejscieKarty(s, s.poz.x, s.poz.y, a); karta(s, x0, y0, cw, h, 30 * s.u, "#FFFFFF");
    for (let i = 0; i < 5; i++) { const e = E.outBackMocno(T(s, 0.3 + i * 0.1, 0.35)), x = x0 + pad + r + i * r * 2.5, y = y0 + pad + r; ctx.save(); ctx.translate(x, y); ctx.scale(Math.max(0.01, e), Math.max(0.01, e)); ctx.fillStyle = "#E5E7EB"; gwiazda(ctx, 0, 0, 5, r * 1.1, r * 0.5); ctx.fill();
      ctx.beginPath(); ctx.rect(-r * 1.2, -r * 1.2, r * 2.4 * clamp(ile - i), r * 2.4); ctx.clip(); ctx.fillStyle = "#FBBF24"; gwiazda(ctx, 0, 0, 5, r * 1.1, r * 0.5); ctx.fill(); ctx.restore(); }
    const ty = y0 + pad + r * 2.4 + px * 0.5; ctx.font = u.font; u.slowa.forEach((w) => { const e = T(s, 0.6 + w.i * 0.04, 0.25); if (e <= 0) return; ctx.globalAlpha = s.alfa * e; ctx.fillStyle = w.wyr ? s.k.g : "#111111"; ctx.fillText(w.t, x0 + pad + w.x, ty + w.y); });
    ctx.globalAlpha = s.alfa; if (s.p.tekst2) { const e = E.outCubic(T(s, 1.2, 0.5)), yy = ty + u.h + px * 0.9; ctx.globalAlpha = s.alfa * e; ctx.font = font(s, px * 0.7, 700); ctx.fillStyle = "#374151"; ctx.fillText("— " + s.p.tekst2, x0 + pad, yy);
      const w = ctx.measureText("— " + s.p.tekst2).width; ctx.fillStyle = zielony; ctx.beginPath(); ctx.arc(x0 + pad + w + px * 0.6, yy, px * 0.32, 0, PI * 2); ctx.fill(); ptaszek(ctx, x0 + pad + w + px * 0.6, yy, px * 0.18, 1, "#FFFFFF", 3 * s.u); }
    ctx.restore();
  }, { pola: ["tekst", "tekst2", "liczba"], czas: 5 });
  rolkiN("rolki-cechy-produktu", "Opis cech produktu (linie do punktów)", { lista: "Wodoodporny\n*12 h* baterii\nWaga 180 g\nUSB-C", x: 0.5, y: 0.5 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), el = lista(s.p.lista).slice(0, 6), px = 44 * s.u * s.p.rozmiar, R = 150 * s.u * s.p.rozmiar;
    el.forEach((t, i) => {
      const lewa = i % 2 === 0, rz = Math.floor(i / 2), nrz = Math.ceil(el.length / 2), dy = (rz - (nrz - 1) / 2) * px * 3.4, k = (lewa ? PI : 0) + (lewa ? -1 : 1) * Math.atan2(dy, R * 2) * 0.8;
      const bw = szerLinii(s, t, px, 700) + px * 0.8, mg = 30 * s.u, px0 = cx + Math.cos(k) * R * 0.8, py0 = cy + Math.sin(k) * R * 0.8 + dy * 0.25, lx = lewa ? clamp(cx - R * 2, mg + bw, px0 - px) : clamp(cx + R * 2, px0 + px, s.W - mg - bw), ly = cy + dy;
      const e1 = E.outBack(T(s, i * 0.18, 0.35)), e2 = E.inOutCubic(T(s, i * 0.18 + 0.15, 0.45)), e3 = E.outCubic(T(s, i * 0.18 + 0.45, 0.4)); if (e1 <= 0) return;
      const pul = 1 + 0.25 * Math.max(0, Math.sin(s.t * 4 - i)); ctx.fillStyle = rgba(s.k.a, 0.35); ctx.beginPath(); ctx.arc(px0, py0, 18 * s.u * e1 * pul, 0, PI * 2); ctx.fill(); ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(px0, py0, 9 * s.u * e1, 0, PI * 2); ctx.fill();
      const kx = lerp(px0, lx, 0.35), pk = [[px0, py0], [kx, ly], [lx, ly]]; ctx.strokeStyle = s.k.t; ctx.lineWidth = 3 * s.u; cien(s); sciezkaCzesc(ctx, pk, e2); ctx.stroke(); bezCienia(ctx);
      if (e3 > 0) { ctx.save(); ctx.globalAlpha = s.alfa * e3; const pad = px * 0.4, bx = lewa ? lx - bw : lx; karta(s, bx, ly - px * 0.75, bw, px * 1.5, px * 0.3, rgba(s.k.tl, 0.9)); linia(s, t, bx + pad, ly, px, 700); ctx.restore(); }
    });
  }, { pola: ["lista", "xy"], czas: 4 });
  rolkiN("rolki-pogoda", "Widżet pogody", { tekst: "Zakopane", tekst2: "Słonecznie, lekki wiatr", liczba: 24, po: "°C" }, (s) => {
    const ctx = s.ctx, cw = szerKarty(s, 640), h = cw * 0.62, x0 = s.poz.x - cw / 2, y0 = s.poz.y - h / 2, a = E.outBack(T(s, 0, 0.5)), r = h * 0.2, sx = x0 + cw - h * 0.38, sy = y0 + h * 0.36;
    ctx.save(); wejscieKarty(s, s.poz.x, s.poz.y, a); const g = ctx.createLinearGradient(x0, y0, x0 + cw, y0 + h); g.addColorStop(0, s.k.g); g.addColorStop(1, ciemniej(s.k.g, 0.35)); ctx.save(); cien(s, ctx, 1.2); ctx.fillStyle = g; zaokr(ctx, x0, y0, cw, h, 40 * s.u); ctx.fill(); ctx.restore();
    const sl = E.outBack(T(s, 0.3, 0.5)); ctx.save(); ctx.translate(sx, sy); ctx.scale(sl, sl); ctx.rotate(s.t * 0.6); ctx.fillStyle = "#FDE047"; for (let i = 0; i < 10; i++) { ctx.rotate(PI / 5); ctx.fillRect(-r * 0.08, -r * 1.55, r * 0.16, r * 0.4); } ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); ctx.restore();
    const ch = E.outCubic(T(s, 0.5, 0.6)); ctx.save(); ctx.globalAlpha *= ch; ctx.translate(sx + r * 0.6 + (1 - ch) * 60 * s.u + Math.sin(s.t * 1.5) * 6 * s.u, sy + r * 0.75); ctx.fillStyle = "#FFFFFF"; ctx.beginPath(); ctx.arc(-r * 0.55, 0, r * 0.45, 0, PI * 2); ctx.arc(0, -r * 0.25, r * 0.6, 0, PI * 2); ctx.arc(r * 0.6, 0, r * 0.42, 0, PI * 2); ctx.fill(); ctx.fillRect(-r * 0.55, 0, r * 1.15, r * 0.45); ctx.restore();
    const kt = kontrast(s.k.g), v = Math.round(wartosc(s, E.outCubic(T(s, 0.3, 1.2)))) + (s.p.po || "°"); ctx.fillStyle = kt; ctx.font = font(s, h * 0.34, 900); ctx.fillText(v, x0 + h * 0.15, y0 + h * 0.42);
    ctx.font = font(s, h * 0.12, 800); ctx.fillText(tekstP(s, s.p.tekst), x0 + h * 0.16, y0 + h * 0.7); if (s.p.tekst2) { ctx.font = font(s, h * 0.085, 500); ctx.fillStyle = rgba(kt, 0.85); ctx.fillText(s.p.tekst2, x0 + h * 0.16, y0 + h * 0.83); }
    ctx.restore();
  }, { pola: ["tekst", "tekst2", "liczba", "po"] });
  rolkiN("rolki-zegar", "Zegar: upływ czasu", { tekst: "*3 godziny* później…", liczba: 3 }, (s) => {
    const ctx = s.ctx, r = 180 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y - r * 0.25, a = E.outBack(T(s, 0, 0.45)), p = E.inOutCubic(T(s, 0.3, Math.max(0.8, s.T - s.p.wyjscie - 1.3))), godz = (+s.p.liczba || 1) * p;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(a, a); karta(s, -r, -r, r * 2, r * 2, r, "#FFFFFF"); ctx.strokeStyle = s.k.g; ctx.lineWidth = r * 0.07; ctx.beginPath(); ctx.arc(0, 0, r * 0.93, 0, PI * 2); ctx.stroke();
    for (let i = 0; i < 12; i++) { const k = i * PI / 6; ctx.fillStyle = "#111111"; ctx.save(); ctx.rotate(k); ctx.fillRect(-r * 0.02, -r * 0.84, r * 0.04, i % 3 ? r * 0.08 : r * 0.15); ctx.restore(); }
    const kh = (10 / 12 + godz / 12) * PI * 2, km = (godz % 1) * PI * 2 + 0; ctx.lineCap = "round"; ctx.strokeStyle = "#111111"; ctx.lineWidth = r * 0.07; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.sin(kh) * r * 0.48, -Math.cos(kh) * r * 0.48); ctx.stroke();
    ctx.strokeStyle = s.k.a; ctx.lineWidth = r * 0.045; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.sin(km) * r * 0.72, -Math.cos(km) * r * 0.72); ctx.stroke(); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, r * 0.07, 0, PI * 2); ctx.fill(); ctx.restore();
    podpis(s, cy + r * 1.35, E.outCubic(T(s, 0.5, 0.5)), 64);
  }, { pola: ["tekst", "liczba"], czas: 4 });
  rolkiN("rolki-kalendarz-miesiac", "Kalendarz miesiąca z zaznaczonym dniem", { tekst: "Listopad 2026", liczba: 21, od: 6 }, (s) => {
    const ctx = s.ctx, cw = szerKarty(s, 820), k = cw / 7.6, pad = k * 0.3, off = Math.round(+s.p.od || 0) % 7, dni = 30, rz = Math.ceil((off + dni) / 7), h = pad * 2 + k * 1.6 + k * 0.7 + rz * k, x0 = s.poz.x - cw / 2, y0 = s.poz.y - h / 2, a = E.outBack(T(s, 0, 0.45)), cel = Math.round(+s.p.liczba || 1);
    ctx.save(); wejscieKarty(s, s.poz.x, s.poz.y, a); karta(s, x0, y0, cw, h, 30 * s.u, "#FFFFFF"); ctx.save(); zaokr(ctx, x0, y0, cw, h, 30 * s.u); ctx.clip(); ctx.fillStyle = s.k.g; ctx.fillRect(x0, y0, cw, k * 1.4); ctx.restore();
    ctx.font = font(s, k * 0.55, 900); ctx.fillStyle = kontrast(s.k.g); const tt = tekstP(s, s.p.tekst); ctx.fillText(tt, s.poz.x - ctx.measureText(tt).width / 2, y0 + k * 0.7);
    const gx = x0 + (cw - k * 7) / 2; ctx.font = font(s, k * 0.3, 800); ["Pn", "Wt", "Śr", "Cz", "Pt", "So", "Nd"].forEach((d, i) => { ctx.fillStyle = i > 4 ? s.k.g : "#6B7280"; ctx.fillText(d, gx + i * k + k / 2 - ctx.measureText(d).width / 2, y0 + k * 1.4 + k * 0.45); });
    for (let d = 1; d <= dni; d++) { const p = off + d - 1, cxd = gx + (p % 7) * k + k / 2, cyd = y0 + k * 2.2 + Math.floor(p / 7) * k + k / 2, e = T(s, 0.2 + p * 0.015, 0.25); if (e <= 0) continue; ctx.globalAlpha = s.alfa * e; ctx.font = font(s, k * 0.4, d === cel ? 900 : 600); ctx.fillStyle = d === cel ? s.k.g : "#111111"; const t = String(d); ctx.fillText(t, cxd - ctx.measureText(t).width / 2, cyd);
      if (d === cel) { const z = E.inOutCubic(T(s, 1.0, 0.6)); ctx.strokeStyle = s.k.a; ctx.lineWidth = 6 * s.u; ctx.lineCap = "round"; const pk = []; for (let i = 0; i <= 40; i++) { const kk = -2 + i / 40 * PI * 2.2; pk.push([cxd + Math.cos(kk) * k * 0.48 * (1 + 0.05 * Math.sin(i)), cyd + Math.sin(kk) * k * 0.42]); } if (z > 0) { sciezkaCzesc(ctx, pk, z); ctx.stroke(); } } }
    ctx.restore();
  }, { pola: ["tekst", "liczba", "od"], czas: 4 });
  rolkiN("rolki-czat-ai", "Okno czatu z AI", { tekst: "Napisz hasło reklamowe dla piekarni", tekst2: "Chleb, który pachnie *jak u babci* 🥖" }, (s) => {
    const ctx = s.ctx, cw = szerKarty(s, 900), px = 44 * s.u * s.p.rozmiar, pad = px * 0.7, a = E.outBack(T(s, 0, 0.45)), x0 = s.poz.x - cw / 2, ih = px * 2.2;
    const q = String(s.p.tekst || ""), nq = Math.floor(clamp((s.t - 0.4) / (Array.from(q).length * 0.035 / s.p.tempo)) * Array.from(q).length), tq = 0.4 + Array.from(q).length * 0.035 / s.p.tempo, wys = T(s, tq + 0.15, 0.3), odp = s.t - tq - 0.8;
    const uq = uloz(s, q, px, { maxW: cw * 0.6, align: "left", x: 0, y: 0, gora: true, lh: 1.25, waga: 500 }), ua = uloz(s, s.p.tekst2 || "", px, { maxW: cw - pad * 2 - px * 2, align: "left", x: 0, y: 0, gora: true, lh: 1.3, waga: 500 });
    const hq = uq.h + pad * 1.2, ha = ua.h + pad * 1.4, H = pad * 2 + hq + ha + pad + ih + pad, y0 = s.poz.y - H / 2;
    ctx.save(); wejscieKarty(s, s.poz.x, s.poz.y, a); karta(s, x0, y0, cw, H, 30 * s.u, rgba(s.k.tl, 0.96));
    const iy = y0 + H - pad - ih; ctx.fillStyle = rgba(s.k.t, 0.08); zaokr(ctx, x0 + pad, iy, cw - pad * 2, ih, ih / 2); ctx.fill();
    ctx.save(); ctx.beginPath(); ctx.rect(x0 + pad, iy, cw - pad * 2 - ih, ih); ctx.clip(); ctx.font = font(s, px * 0.85, 500); ctx.fillStyle = wys > 0 ? rgba(s.k.t, 0.4) : s.k.t; const vis = wys > 0 ? "Zapytaj o cokolwiek…" : Array.from(q).slice(0, nq).join(""), vw = ctx.measureText(vis).width;
    ctx.fillText(vis, Math.min(x0 + pad + ih * 0.4, x0 + cw - pad - ih * 1.3 - vw), iy + ih / 2); ctx.restore();
    const bx = x0 + cw - pad - ih / 2, by = iy + ih / 2, pb = 1 + Math.sin(clamp(T(s, tq, 0.25)) * PI) * 0.25; ctx.save(); ctx.translate(bx, by); ctx.scale(pb, pb); ctx.fillStyle = nq > 0 ? s.k.a : rgba(s.k.t, 0.2); ctx.beginPath(); ctx.arc(0, 0, ih * 0.38, 0, PI * 2); ctx.fill();
    ctx.strokeStyle = kontrast(s.k.a); ctx.lineWidth = ih * 0.07; ctx.lineCap = "round"; ctx.lineJoin = "round"; ctx.beginPath(); ctx.moveTo(0, ih * 0.18); ctx.lineTo(0, -ih * 0.16); ctx.moveTo(-ih * 0.14, -ih * 0.02); ctx.lineTo(0, -ih * 0.16); ctx.lineTo(ih * 0.14, -ih * 0.02); ctx.stroke(); ctx.restore();
    if (wys > 0) { const e = E.outBack(wys), bw = uq.w + pad * 1.6, qx = x0 + cw - pad - bw, qy = y0 + pad; ctx.save(); ctx.translate(qx + bw, qy + hq); ctx.scale(e, e); ctx.translate(-qx - bw, -qy - hq); ctx.fillStyle = s.k.g; zaokr(ctx, qx, qy, bw, hq, px * 0.6); ctx.fill(); ctx.font = uq.font; uq.slowa.forEach((w) => { ctx.fillStyle = kontrast(s.k.g); ctx.fillText(w.t, qx + pad * 0.8 + w.x, qy + pad * 0.6 + w.y); }); ctx.restore(); }
    if (odp > -0.5) { const ay = y0 + pad + hq + pad, gx = x0 + pad + px * 0.6, sp = E.outBack(okno(odp, -0.5, 0.4)); ctx.save(); ctx.translate(gx, ay + px * 0.6); ctx.scale(sp, sp); ctx.rotate(s.t * 2); ctx.fillStyle = s.k.a; gwiazda(ctx, 0, 0, 4, px * 0.6, px * 0.18); ctx.fill(); ctx.restore();
      if (odp > 0) { ctx.font = ua.font; const ile = Math.floor(odp / (0.09 / s.p.tempo)); ua.slowa.forEach((w) => { if (w.i > ile) return; ctx.fillStyle = w.wyr ? s.k.a : s.k.t; ctx.fillText(w.t, x0 + pad + px * 1.6 + w.x, ay + pad * 0.3 + w.y); }); }
      else for (let k = 0; k < 3; k++) { ctx.fillStyle = rgba(s.k.t, 0.3 + 0.5 * Math.max(0, Math.sin(s.t * 9 - k))); ctx.beginPath(); ctx.arc(x0 + pad + px * 1.9 + k * px * 0.6, ay + px * 0.6, px * 0.15, 0, PI * 2); ctx.fill(); } }
    ctx.restore();
  }, { pola: ["tekst", "tekst2"], czas: 6 });
  rolkiN("rolki-koperta-mail", "Nowa wiadomość e-mail (koperta)", { tekst: "Twoja rolka jest gotowa!", tekst2: "Kliknij, aby pobrać plik" }, (s) => {
    const ctx = s.ctx, w = Math.min(s.W * 0.8, 760 * s.u) * s.p.rozmiar, h = w * 0.62, cx = s.poz.x, cy = s.poz.y + h * 0.15, a = E.outBack(T(s, 0, 0.5)), ot = E.inOutCubic(T(s, 0.5, 0.4)), lt = E.outBack(T(s, 0.8, 0.6)), kl = ciemniej(s.k.g, 0.15), x0 = cx - w / 2, y0 = cy - h / 2;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(a, a); ctx.translate(-cx, -cy - (1 - a) * 200 * s.u);
    karta(s, x0, y0, w, h, 16 * s.u, ciemniej(s.k.g, 0.3));
    if (ot > 0.5) { ctx.save(); ctx.fillStyle = kl; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(cx, y0 - h * 0.55 * (ot - 0.5) * 2); ctx.lineTo(x0 + w, y0); ctx.closePath(); ctx.fill(); ctx.restore(); }
    if (lt > 0) { const lw = w * 0.88, lh = h * 0.95, ly = y0 + h * 0.1 - lh * 0.6 * lt; ctx.save(); ctx.beginPath(); ctx.rect(x0 - 50, y0 - h * 2, w + 100, h * 2 + h * 0.62); ctx.clip(); ctx.fillStyle = "#FFFFFF"; zaokr(ctx, cx - lw / 2, ly, lw, lh, 12 * s.u); ctx.fill();
      const px = lw * 0.065, u = uloz(s, s.p.tekst, px, { maxW: lw * 0.84, align: "left", x: cx - lw * 0.42, y: ly + lw * 0.07, gora: true, lh: 1.2, waga: 800 }); ctx.font = u.font; u.slowa.forEach((wd) => { ctx.fillStyle = wd.wyr ? s.k.g : "#111111"; ctx.fillText(wd.t, wd.x, wd.y); });
      if (s.p.tekst2) { ctx.font = font(s, px * 0.65, 500); ctx.fillStyle = "#6B7280"; ctx.fillText(s.p.tekst2, cx - lw * 0.42, ly + lw * 0.07 + u.h + px * 0.7); } ctx.fillStyle = "#E5E7EB"; for (let i = 0; i < 2; i++) ctx.fillRect(cx - lw * 0.42, ly + lw * 0.07 + u.h + px * (1.6 + i * 0.7), lw * (0.7 - i * 0.25), px * 0.25); ctx.restore(); }
    ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.moveTo(x0, y0 + h * 0.02); ctx.lineTo(cx, y0 + h * 0.55); ctx.lineTo(x0 + w, y0 + h * 0.02); ctx.lineTo(x0 + w, y0 + h); ctx.lineTo(x0, y0 + h); ctx.closePath(); ctx.fill();
    ctx.fillStyle = ciemniej(s.k.g, 0.08); ctx.beginPath(); ctx.moveTo(x0, y0 + h); ctx.lineTo(cx, y0 + h * 0.48); ctx.lineTo(x0 + w, y0 + h); ctx.closePath(); ctx.fill();
    if (ot <= 0.5) { ctx.fillStyle = kl; ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(cx, y0 + h * 0.55 * (1 - ot * 2)); ctx.lineTo(x0 + w, y0); ctx.closePath(); ctx.fill(); }
    const bd = E.outBackMocno(T(s, 0.3, 0.4)); if (bd > 0) { ctx.save(); ctx.translate(x0 + w - 10 * s.u, y0 + 10 * s.u); ctx.scale(bd, bd); ctx.fillStyle = czerwony; ctx.beginPath(); ctx.arc(0, 0, 38 * s.u, 0, PI * 2); ctx.fill(); ctx.font = font(s, 40 * s.u, 900); ctx.fillStyle = "#FFFFFF"; ctx.fillText("1", -ctx.measureText("1").width / 2, 2 * s.u); ctx.restore(); }
    ctx.restore();
  }, { pola: ["tekst", "tekst2"] });
  rolkiN("rolki-poziom-trudnosci", "Poziom trudności", { tekst: "Poziom trudności", tekst2: "*średni*", liczba: 3 }, (s) => {
    const ctx = s.ctx, px = 54 * s.u * s.p.rozmiar, n = 5, v = clamp(Math.round(+s.p.liczba || 0), 0, n), bw = px * 0.9, gap = px * 0.35, W = n * bw + (n - 1) * gap, x0 = s.poz.x - W / 2, base = s.poz.y + px * 1.2;
    const a = E.outCubic(T(s, 0, 0.4)); ctx.save(); ctx.globalAlpha = s.alfa * a; cien(s); const t1 = tekstP(s, s.p.tekst); ctx.font = font(s, px, 800); ctx.fillStyle = s.k.t; ctx.fillText(t1, s.poz.x - ctx.measureText(t1).width / 2, s.poz.y - px * 2.2); ctx.restore();
    for (let i = 0; i < n; i++) { const hmax = px * (0.8 + i * 0.55), e = E.outBackMocno(T(s, 0.2 + i * 0.1, 0.45)), on = i < v && s.t > (0.6 + i * 0.15) / s.p.tempo, x = x0 + i * (bw + gap); if (e <= 0) continue;
      ctx.fillStyle = on ? lerpKolor(s.k.a, s.k.g, i / (n - 1)) : rgba(s.k.t, 0.2); zaokr(ctx, x, base - hmax * e, bw, hmax * e, bw * 0.2); ctx.fill(); }
    if (s.p.tekst2) { const e = E.outBack(T(s, 0.7 + v * 0.15, 0.4)); if (e > 0) { const w = szerLinii(s, s.p.tekst2, px * 1.2, 900); ctx.save(); ctx.translate(s.poz.x, base + px * 1.3); ctx.scale(e, e); cien(s); linia(s, s.p.tekst2, -w / 2, 0, px * 1.2, 900); ctx.restore(); } }
  }, { pola: ["tekst", "tekst2", "liczba"], czas: 3.5 });
  rolkiN("rolki-bilet", "Bilet na wydarzenie", { tekst: "Koncert w plenerze", tekst2: "sob. 20.06 · 19:00 · Rynek", przed: "Wstęp", po: "Nr 0427" }, (s) => {
    const ctx = s.ctx, w = Math.min(s.W * 0.88, 980 * s.u) * s.p.rozmiar, h = w * 0.38, cx = s.poz.x, cy = s.poz.y, a = E.outBack(T(s, 0, 0.55)), sw = h * 0.85, oder = E.outCubic(T(s, 1.4, 0.5)) * 24 * s.u, x0 = cx - w / 2, y0 = cy - h / 2, r = h * 0.12;
    const ksz = (x, y, ww, z) => { ctx.beginPath(); ctx.moveTo(x + 14 * s.u, y); ctx.lineTo(x + ww - 14 * s.u, y); ctx.quadraticCurveTo(x + ww, y, x + ww, y + 14 * s.u); if (z !== 1) { ctx.lineTo(x + ww, y + h / 2 - r); ctx.arc(x + ww, y + h / 2, r, -PI / 2, PI / 2, true); } ctx.lineTo(x + ww, y + h - 14 * s.u); ctx.quadraticCurveTo(x + ww, y + h, x + ww - 14 * s.u, y + h); ctx.lineTo(x + 14 * s.u, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - 14 * s.u); if (z !== 0) { ctx.lineTo(x, y + h / 2 + r); ctx.arc(x, y + h / 2, r, PI / 2, -PI / 2, true); } ctx.lineTo(x, y + 14 * s.u); ctx.quadraticCurveTo(x, y, x + 14 * s.u, y); ctx.closePath(); };
    ctx.save(); ctx.translate(cx, cy); ctx.rotate((1 - a) * -0.5 - 0.04); ctx.scale(a, a); ctx.translate(-cx, -cy);
    ctx.save(); cien(s); ctx.fillStyle = "#FFFFFF"; ksz(x0, y0, w - sw, 0); ctx.fill(); ctx.restore();
    ctx.save(); ctx.translate(oder, oder * 0.4); ctx.translate(x0 + w - sw, y0 + h); ctx.rotate(oder / (24 * s.u) * 0.06); ctx.translate(-(x0 + w - sw), -(y0 + h)); cien(s); ctx.fillStyle = s.k.g; ksz(x0 + w - sw, y0, sw, 1); ctx.fill(); bezCienia(ctx);
    ctx.save(); ctx.translate(x0 + w - sw / 2, cy); ctx.rotate(-PI / 2); const lb = String(s.p.przed || "").toLocaleUpperCase("pl"); ctx.font = font(s, h * 0.15, 900); ctx.fillStyle = kontrast(s.k.g); ctx.fillText(lb, -ctx.measureText(lb).width / 2, -h * 0.08); ctx.font = font(s, h * 0.08, 600); const nr = s.p.po || ""; ctx.fillText(nr, -ctx.measureText(nr).width / 2, h * 0.12); ctx.restore(); ctx.restore();
    ctx.strokeStyle = "#CBD5E1"; ctx.lineWidth = 3 * s.u; ctx.setLineDash([10 * s.u, 8 * s.u]); ctx.beginPath(); ctx.moveTo(x0 + w - sw, y0 + r * 1.2); ctx.lineTo(x0 + w - sw, y0 + h - r * 1.2); ctx.stroke(); ctx.setLineDash([]);
    ctx.fillStyle = s.k.a; ctx.fillRect(x0 + h * 0.18, y0 + h * 0.18, h * 0.08, h * 0.64);
    const u = uloz(s, s.p.tekst, h * 0.2, { maxW: w - sw - h * 0.6, align: "left", x: x0 + h * 0.36, y: y0 + h * 0.2, gora: true, lh: 1.05, waga: 900 }); ctx.font = u.font; u.slowa.forEach((wd) => { ctx.fillStyle = wd.wyr ? s.k.g : "#111111"; ctx.fillText(wd.t, wd.x, wd.y); });
    if (s.p.tekst2) { ctx.font = font(s, h * 0.1, 600); ctx.fillStyle = "#475569"; ctx.fillText(s.p.tekst2, x0 + h * 0.36, Math.min(y0 + h * 0.8, u.y + u.h + h * 0.12)); }
    ctx.restore();
  }, { pola: ["tekst", "tekst2", "przed", "po"] });
  rolkiN("rolki-polaroid", "Ramka polaroid z podpisem", { tekst: "Wakacje *2026*" }, (s) => {
    const ctx = s.ctx, w = Math.min(s.W * 0.7, s.H * 0.42) * s.p.rozmiar, h = w * 1.2, cx = s.poz.x, cy = s.poz.y, e = T(s, 0, 0.7), y = lerp(-s.H * 0.6, 0, E.outBack(e)), rot = lerp(0.6, -0.06, E.outCubic(e)), m = w * 0.06;
    const c = warstwa(s, "polaroid", (x) => { x.translate(cx, cy + y); x.rotate(rot); x.fillStyle = "#FAFAF7"; const q = w - m * 2, z = 0.5; x.fillRect(-w / 2, -h / 2, w, m + z); x.fillRect(-w / 2, -h / 2 + m + q - z, w, h - m - q + z); x.fillRect(-w / 2, -h / 2 + m, m + z, q); x.fillRect(w / 2 - m - z, -h / 2 + m, m + z, q);
      x.fillStyle = rgba(s.k.a, 0.75); x.save(); x.translate(0, -h / 2); x.rotate(0.05); x.fillRect(-w * 0.18, -w * 0.05, w * 0.36, w * 0.1); x.restore();
      if (s.p.tekst) { const px = dopasuj(s, bezGw(s.p.tekst), w * 0.1, w * 0.85); x.textBaseline = "middle"; x.font = font(s, px, s.p.waga); const sl = slowaZ(tekstP(s, s.p.tekst)), sp = x.measureText(" ").width, tw = sl.reduce((a, q) => a + x.measureText(q.t).width, 0) + sp * (sl.length - 1); let xx = -tw / 2; sl.forEach((q) => { x.fillStyle = q.wyr ? s.k.g : "#222222"; x.fillText(q.t, xx, -h / 2 + w + (h - w) / 2 - m * 0.2); xx += x.measureText(q.t).width + sp; }); } });
    ctx.save(); cien(s, ctx, 1.4); ctx.drawImage(c, 0, 0); ctx.restore();
  }, { czas: 4 });
  rolkiN("rolki-wiadomosc-glosowa", "Wiadomość głosowa", { liczba: 14 }, (s) => {
    const ctx = s.ctx, w = Math.min(s.W * 0.82, 760 * s.u) * s.p.rozmiar, h = w * 0.2, x0 = s.poz.x - w / 2, y0 = s.poz.y - h / 2, a = E.outBack(T(s, 0, 0.45)), dl = Math.max(1, +s.p.liczba || 10), p = clamp((s.t - 0.6) / Math.max(0.5, s.T - s.p.wyjscie - 0.8));
    ctx.save(); ctx.translate(x0, y0 + h); ctx.scale(a, a); ctx.translate(-x0, -y0 - h); karta(s, x0, y0, w, h, h / 2, s.k.g);
    const r = h * 0.34, bx = x0 + h / 2; ctx.fillStyle = kontrast(s.k.g); ctx.beginPath(); ctx.arc(bx, y0 + h / 2, r, 0, PI * 2); ctx.fill(); ctx.fillStyle = s.k.g;
    if (s.t < 0.6 || p >= 1) { ctx.beginPath(); ctx.moveTo(bx - r * 0.3, y0 + h / 2 - r * 0.45); ctx.lineTo(bx + r * 0.5, y0 + h / 2); ctx.lineTo(bx - r * 0.3, y0 + h / 2 + r * 0.45); ctx.closePath(); ctx.fill(); } else { ctx.fillRect(bx - r * 0.35, y0 + h / 2 - r * 0.4, r * 0.25, r * 0.8); ctx.fillRect(bx + r * 0.1, y0 + h / 2 - r * 0.4, r * 0.25, r * 0.8); }
    const n = 34, wx = x0 + h * 1.0, ww = w - h * 2.1, bw = ww / n; for (let i = 0; i < n; i++) { const hh = (0.25 + 0.75 * Math.abs(Math.sin(i * 1.7) * Math.sin(i * 0.43 + 1))) * h * 0.5 * E.outCubic(T(s, 0.1 + i * 0.01, 0.3)); ctx.fillStyle = i / n < p ? kontrast(s.k.g) : rgba(kontrast(s.k.g), 0.4); zaokr(ctx, wx + i * bw + bw * 0.2, y0 + h / 2 - hh / 2, bw * 0.55, Math.max(2 * s.u, hh), bw * 0.25); ctx.fill(); }
    const sek = Math.floor(p < 1 && s.t > 0.6 ? dl * p : dl), t = `${Math.floor(sek / 60)}:${String(sek % 60).padStart(2, "0")}`; ctx.font = font(s, h * 0.24, 700); ctx.fillStyle = kontrast(s.k.g); ctx.fillText(t, x0 + w - h * 0.95, y0 + h / 2);
    ctx.restore();
  }, { pola: ["liczba"], czas: 5 });
  rolkiN("rolki-odtwarzacz", "Odtwarzacz muzyki", { tekst: "Letni wieczór", tekst2: "Nada Beats", liczba: 184 }, (s) => {
    const ctx = s.ctx, cw = szerKarty(s, 820), pad = cw * 0.06, ok = cw * 0.26, h = pad * 2 + ok + cw * 0.22, x0 = s.poz.x - cw / 2, y0 = s.poz.y - h / 2, a = E.outBack(T(s, 0, 0.5)), dl = Math.max(10, +s.p.liczba || 180), p = 0.32 + (s.t / Math.max(1, s.T)) * 0.1;
    ctx.save(); wejscieKarty(s, s.poz.x, s.poz.y, a); karta(s, x0, y0, cw, h, 34 * s.u, rgba(s.k.tl, 0.95));
    const g = ctx.createLinearGradient(x0 + pad, y0 + pad, x0 + pad + ok, y0 + pad + ok); g.addColorStop(0, s.k.g); g.addColorStop(1, s.k.a); ctx.fillStyle = g; zaokr(ctx, x0 + pad, y0 + pad, ok, ok, 18 * s.u); ctx.fill();
    for (let i = 0; i < 5; i++) { const hh = (0.25 + 0.6 * Math.abs(Math.sin(s.t * 6 + i * 1.3))) * ok * 0.5; ctx.fillStyle = rgba("#FFFFFF", 0.9); zaokr(ctx, x0 + pad + ok * 0.2 + i * ok * 0.13, y0 + pad + ok * 0.75 - hh, ok * 0.08, hh, ok * 0.03); ctx.fill(); }
    const tx = x0 + pad * 2 + ok; ctx.font = font(s, cw * 0.06, 800); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), tx, y0 + pad + ok * 0.32); ctx.font = font(s, cw * 0.042, 500); ctx.fillStyle = rgba(s.k.t, 0.7); ctx.fillText(s.p.tekst2 || "", tx, y0 + pad + ok * 0.62);
    const py = y0 + pad + ok + cw * 0.07, pw = cw - pad * 2; ctx.fillStyle = rgba(s.k.t, 0.2); zaokr(ctx, x0 + pad, py, pw, 8 * s.u, 4 * s.u); ctx.fill(); ctx.fillStyle = s.k.a; zaokr(ctx, x0 + pad, py, pw * p, 8 * s.u, 4 * s.u); ctx.fill(); ctx.beginPath(); ctx.arc(x0 + pad + pw * p, py + 4 * s.u, 12 * s.u, 0, PI * 2); ctx.fill();
    const fm = (v) => `${Math.floor(v / 60)}:${String(Math.floor(v % 60)).padStart(2, "0")}`; ctx.font = font(s, cw * 0.032, 600); ctx.fillStyle = rgba(s.k.t, 0.6); ctx.fillText(fm(dl * p), x0 + pad, py + cw * 0.045); const kt = fm(dl); ctx.fillText(kt, x0 + cw - pad - ctx.measureText(kt).width, py + cw * 0.045);
    const by = py + cw * 0.11, r = cw * 0.05; ctx.fillStyle = s.k.t; ctx.beginPath(); ctx.arc(s.poz.x, by, r, 0, PI * 2); ctx.fill(); ctx.fillStyle = s.k.tl; ctx.fillRect(s.poz.x - r * 0.35, by - r * 0.4, r * 0.25, r * 0.8); ctx.fillRect(s.poz.x + r * 0.1, by - r * 0.4, r * 0.25, r * 0.8);
    [-1, 1].forEach((k) => { ctx.fillStyle = s.k.t; ctx.save(); ctx.translate(s.poz.x + k * r * 3, by); ctx.scale(k, 1); ctx.beginPath(); ctx.moveTo(-r * 0.4, -r * 0.45); ctx.lineTo(r * 0.2, 0); ctx.lineTo(-r * 0.4, r * 0.45); ctx.closePath(); ctx.fill(); ctx.fillRect(r * 0.22, -r * 0.45, r * 0.14, r * 0.9); ctx.restore(); });
    ctx.restore();
  }, { pola: ["tekst", "tekst2", "liczba"], czas: 5 });
  rolkiN("rolki-cenzura", "Pasek cenzury", { tekst: "OCENZUROWANO", x: 0.5, y: 0.35 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), w = 620 * s.u * s.p.rozmiar, h = 120 * s.u * s.p.rozmiar, e = E.outQuint(T(s, 0, 0.35));
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(-0.04); ctx.beginPath(); ctx.rect(-w / 2, -h / 2, w * e, h); ctx.clip(); ctx.fillStyle = "#000000"; ctx.fillRect(-w / 2, -h / 2, w, h);
    if (s.p.tekst) { const px = dopasuj(s, s.p.tekst, h * 0.42, w * 0.85, 900); ctx.font = font(s, px, 900); ctx.fillStyle = Math.floor(s.t * 2) % 2 ? "#FFFFFF" : rgba("#FFFFFF", 0.75); const tw = ctx.measureText(tekstP(s, s.p.tekst)).width; ctx.fillText(tekstP(s, s.p.tekst), -tw / 2, 0); }
    ctx.restore();
  }, { pola: ["tekst", "xy"], czas: 3 });
  rolkiN("rolki-pieczatka", "Pieczątka przybita na ekranie", { tekst: "Zatwierdzone", x: 0.6, y: 0.4, wielkie: true }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), px = 74 * s.u * s.p.rozmiar, t = tekstP(s, s.p.tekst); ctx.font = font(s, px, 900); const tw = ctx.measureText(t).width, W = tw + px * 1.2, H = px * 1.9, e = T(s, 0, 0.28), sk = lerp(2.6, 1, E.inCubic(e)), kol = s.k.g;
    if (e <= 0) return; const c = warstwa(s, "pieczatka", (x) => { x.translate(cx, cy); x.rotate(-0.18); x.strokeStyle = kol; x.lineWidth = px * 0.12; zaokr(x, -W / 2, -H / 2, W, H, px * 0.25); x.stroke(); x.lineWidth = px * 0.04; zaokr(x, -W / 2 + px * 0.16, -H / 2 + px * 0.16, W - px * 0.32, H - px * 0.32, px * 0.15); x.stroke();
      x.font = font(s, px, 900); x.textBaseline = "middle"; x.fillStyle = kol; x.fillText(t, -tw / 2, px * 0.04);
      x.setTransform(1, 0, 0, 1, 0, 0); x.globalCompositeOperation = "destination-out"; const cs = Math.cos(-0.18), sn = Math.sin(-0.18);
      for (let i = 0; i < 260; i++) { const lx = (los(i) - 0.5) * W, ly = (los(i * 7) - 0.5) * H; x.globalAlpha = 0.4 + los(i * 3) * 0.6; x.beginPath(); x.arc(cx + lx * cs - ly * sn, cy + lx * sn + ly * cs, (1 + los(i * 11) * 4) * s.u, 0, PI * 2); x.fill(); } });
    ctx.save(); ctx.translate(cx, cy); ctx.scale(sk, sk); ctx.translate(-cx, -cy); ctx.globalAlpha = s.alfa * clamp(e * 2) * 0.92; ctx.drawImage(c, 0, 0); ctx.restore();
    const d = okno(s.t, 0.28, 0.5); if (d > 0 && d < 1) for (let i = 0; i < 14; i++) { const k = i / 14 * PI * 2, rr = (W * 0.55 + d * 120 * s.u); ctx.fillStyle = rgba(kol, (1 - d) * 0.7); ctx.beginPath(); ctx.arc(cx + Math.cos(k) * rr, cy + Math.sin(k) * rr * 0.5, 6 * s.u * (1 - d), 0, PI * 2); ctx.fill(); }
    const dr = s.t > 0.28 && s.t < 0.45 ? (los(Math.floor(s.t * 60)) - 0.5) * 6 * s.u : 0; void dr;
  }, { pola: ["tekst", "xy"], czas: 3 });
  rolkiN("rolki-skladniki", "Lista składników z ilościami", { tekst: "Składniki", lista: "Mąka pszenna: 500 g\nMleko: 250 ml\nDrożdże: 25 g\nCukier: 2 łyżki\n*Szczypta miłości*: ∞" }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista).map((x) => { const i = x.lastIndexOf(":"); return i > 0 ? [x.slice(0, i).trim(), x.slice(i + 1).trim()] : [x, ""]; }), cw = szerKarty(s, 820), px = 46 * s.u * s.p.rozmiar, pad = px * 0.9, lh = px * 1.6;
    const h = pad * 2 + px * 1.8 + el.length * lh, x0 = s.poz.x - cw / 2, y0 = s.poz.y - h / 2, a = E.outBack(T(s, 0, 0.45));
    ctx.save(); wejscieKarty(s, s.poz.x, s.poz.y, a); karta(s, x0, y0, cw, h, 28 * s.u, "#FFFBF2");
    ctx.font = font(s, px * 1.15, 900); ctx.fillStyle = s.k.g; ctx.fillText(tekstP(s, s.p.tekst), x0 + pad, y0 + pad + px * 0.55); ctx.fillStyle = s.k.a; ctx.fillRect(x0 + pad, y0 + pad + px * 1.25, px * 2.4 * E.inOutCubic(T(s, 0.2, 0.5)), 5 * s.u);
    el.forEach(([n, q], i) => {
      const e = E.outCubic(T(s, 0.35 + i * 0.16, 0.4)); if (e <= 0) return; const y = y0 + pad + px * 1.8 + (i + 0.5) * lh, wyr = /\*/.test(n), nn = bezGw(n); ctx.save(); ctx.globalAlpha *= e; ctx.translate((1 - e) * -40 * s.u, 0);
      ctx.font = font(s, px * 0.8, 600); ctx.fillStyle = wyr ? s.k.g : "#1F2937"; ctx.fillText(nn, x0 + pad, y); const nw = ctx.measureText(nn).width; ctx.font = font(s, px * 0.8, 800); const qw = ctx.measureText(q).width; ctx.fillStyle = "#1F2937"; ctx.fillText(q, x0 + cw - pad - qw, y);
      ctx.fillStyle = "#C9BFA9"; for (let xx = x0 + pad + nw + px * 0.4; xx < x0 + cw - pad - qw - px * 0.4; xx += px * 0.32) { ctx.beginPath(); ctx.arc(xx, y + px * 0.2, 2.5 * s.u, 0, PI * 2); ctx.fill(); } ctx.restore();
    });
    ctx.restore();
  }, { pola: ["tekst", "lista"], czas: 5 });
  rolkiN("rolki-powiadomienia-stos", "Lawina powiadomień", { tekst: "Sklep", lista: "Nowe zamówienie: 129 zł\nNowe zamówienie: 89 zł\nNowe zamówienie: 240 zł\nNowe zamówienie: 59 zł\nNowe zamówienie: 310 zł" }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista), cw = szerKarty(s, 880), px = 40 * s.u * s.p.rozmiar, h = px * 3.2, x0 = s.poz.x - cw / 2, krok = Math.max(0.25, (s.T - s.p.wyjscie - 0.6) / Math.max(1, el.length)), ile = Math.min(el.length, Math.floor(s.t / krok) + 1), top = s.poz.y - h * 0.9;
    for (let i = 0; i < ile; i++) {
      const glebia = ile - 1 - i, e = E.outBack(okno(s.t - i * krok, 0, 0.35)), sk = Math.pow(0.94, glebia) * lerp(0.9, 1, e), y = top + glebia * px * 0.55 - (1 - e) * h * 1.2, op = clamp(1 - (glebia - 2) * 0.5) * clamp(e * 2); if (op <= 0) continue;
      ctx.save(); ctx.translate(s.poz.x, y + h / 2); ctx.scale(sk, sk); ctx.globalAlpha = s.alfa * op; karta(s, -cw / 2, -h / 2, cw, h, px * 0.7, rgba("#F5F5F7", 0.97), ctx, 0.8);
      const r = px * 0.9; ctx.fillStyle = s.k.g; zaokr(ctx, -cw / 2 + px * 0.6, -r, r * 2, r * 2, r * 0.45); ctx.fill(); ikKoszyk(ctx, -cw / 2 + px * 0.6 + r, 0, r * 0.5, kontrast(s.k.g));
      const tx = -cw / 2 + px * 0.6 + r * 2 + px * 0.5; ctx.font = font(s, px * 0.7, 700); ctx.fillStyle = "#6B7280"; ctx.fillText(String(s.p.tekst || "").toLocaleUpperCase("pl"), tx, -px * 0.55); const tz = "teraz"; ctx.fillText(tz, cw / 2 - px * 0.6 - ctx.measureText(tz).width, -px * 0.55);
      ctx.font = font(s, px * 0.85, 700); ctx.fillStyle = "#111111"; ctx.fillText(el[i], tx, px * 0.5); ctx.restore();
    }
    const b = E.outBackMocno(okno(s.t, krok * (el.length - 1) + 0.3, 0.4)); if (b > 0) { const t = `+${el.length}`; ctx.save(); ctx.translate(x0 + cw - 10 * s.u, top - 10 * s.u); ctx.scale(b, b); ctx.fillStyle = czerwony; ctx.beginPath(); ctx.arc(0, 0, px * 0.9, 0, PI * 2); ctx.fill(); ctx.font = font(s, px * 0.85, 900); ctx.fillStyle = "#FFFFFF"; ctx.fillText(t, -ctx.measureText(t).width / 2, 0); ctx.restore(); }
  }, { pola: ["tekst", "lista"], czas: 4.5 });

  // ---------- wezwania do działania (v18) ----------
  const ikDzwonek = (c, x, y, r, k, pelny) => { c.save(); c.translate(x, y); c.fillStyle = k; c.strokeStyle = k; c.lineWidth = r * 0.16; c.lineJoin = "round"; c.beginPath(); c.moveTo(-r * 0.75, r * 0.45); c.quadraticCurveTo(-r * 0.55, r * 0.3, -r * 0.55, -r * 0.1); c.quadraticCurveTo(-r * 0.55, -r * 0.75, 0, -r * 0.8); c.quadraticCurveTo(r * 0.55, -r * 0.75, r * 0.55, -r * 0.1); c.quadraticCurveTo(r * 0.55, r * 0.3, r * 0.75, r * 0.45); c.closePath(); if (pelny) c.fill(); else c.stroke(); c.beginPath(); c.arc(0, r * 0.62, r * 0.17, 0, PI * 2); c.fill(); c.restore(); };
  function klik(s, x, y, tk, sk) { const ctx = s.ctx, r = okno(s.t, tk, 0.5); if (r > 0 && r < 1) { ctx.strokeStyle = rgba("#FFFFFF", 1 - r); ctx.lineWidth = 4 * s.u; ctx.beginPath(); ctx.arc(x, y, 18 * s.u + r * 60 * s.u, 0, PI * 2); ctx.stroke(); } kursor(ctx, x, y, (sk || 1.6) * s.u * s.p.rozmiar * (s.t > tk - 0.08 && s.t < tk + 0.12 ? 0.85 : 1)); }
  ctaN("cta-subskrybuj", "Subskrybuj z dzwonkiem", { tekst: "Subskrybuj", tekst2: "Subskrybujesz", wielkie: true }, (s) => {
    const ctx = s.ctx, px = 52 * s.u * s.p.rozmiar, k1 = 1.1 / s.p.tempo, k2 = 2.0 / s.p.tempo, po = s.t > k1, t = tekstP(s, po && s.p.tekst2 ? s.p.tekst2 : s.p.tekst);
    ctx.font = font(s, px, 800); const wmax = Math.max(ctx.measureText(tekstP(s, s.p.tekst)).width, ctx.measureText(tekstP(s, s.p.tekst2 || "")).width) + px * 1.6, h = px * 1.9, gap = px * 0.6, W = wmax + gap + h, x0 = s.poz.x - W / 2, cy = s.poz.y;
    const e = E.outBackMocno(T(s, 0, 0.4)), nac = s.t > k1 - 0.08 && s.t < k1 + 0.12 ? 0.92 : 1, bx = x0 + wmax / 2;
    ctx.save(); ctx.translate(bx, cy); ctx.scale(e * nac, e * nac); cien(s); ctx.fillStyle = po ? "#3F3F46" : s.k.g; zaokr(ctx, -wmax / 2, -h / 2, wmax, h, h * 0.25); ctx.fill(); bezCienia(ctx); ctx.fillStyle = po ? "#E4E4E7" : kontrast(s.k.g); const tw = ctx.measureText(t).width; ctx.fillText(t, -tw / 2, 0); ctx.restore();
    const d = E.outBackMocno(okno(s.t, k1 + 0.15, 0.4)); if (d > 0) { const dx = x0 + wmax + gap + h / 2, ring = s.t > k2 ? Math.sin((s.t - k2) * 25) * 0.4 * Math.exp(-(s.t - k2) * 3) : Math.sin(s.t * 12) * 0.08; ctx.save(); ctx.translate(dx, cy); ctx.scale(d, d); cien(s); ctx.fillStyle = s.t > k2 ? s.k.a : "#3F3F46"; ctx.beginPath(); ctx.arc(0, 0, h / 2, 0, PI * 2); ctx.fill(); bezCienia(ctx); ctx.rotate(ring); ikDzwonek(ctx, 0, -h * 0.02, h * 0.3, s.t > k2 ? kontrast(s.k.a) : "#FFFFFF", s.t > k2); ctx.restore();
      if (s.t > k2) { const w = okno(s.t, k2, 0.5); if (w < 1) for (let i = 0; i < 8; i++) { const a = i / 8 * PI * 2, d1 = h * (0.6 + w * 0.3), d2 = h * (0.7 + w * 0.5); ctx.strokeStyle = rgba(s.k.a, 1 - w); ctx.lineWidth = 5 * s.u; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(dx + Math.cos(a) * d1, cy + Math.sin(a) * d1); ctx.lineTo(dx + Math.cos(a) * d2, cy + Math.sin(a) * d2); ctx.stroke(); } } }
    const m1 = E.inOutCubic(okno(s.t, 0.4 / s.p.tempo, k1 - 0.45 / s.p.tempo)), m2 = E.inOutCubic(okno(s.t, k1 + 0.3, k2 - k1 - 0.35)), cx1 = bx + wmax * 0.2, cx2 = x0 + wmax + gap + h / 2;
    const kx = s.t < k1 + 0.3 ? lerp(x0 + W + 80 * s.u, cx1, m1) : lerp(cx1, cx2, m2), ky = s.t < k1 + 0.3 ? lerp(cy + h * 2.5, cy + h * 0.15, m1) : cy + h * 0.15; klik(s, kx, ky, s.t < k1 + 0.3 ? k1 : k2);
  }, { czas: 3.5 });
  ctaN("cta-przycisk-puls", "Przycisk z pulsującymi falami", { tekst: "Zapisz się teraz" }, (s) => {
    const ctx = s.ctx, px = 56 * s.u * s.p.rozmiar, e = E.outBackMocno(T(s, 0, 0.45)); ctx.font = font(s, px, 800); const t = tekstP(s, s.p.tekst), w = ctx.measureText(t).width + px * 1.8, h = px * 2;
    for (let i = 0; i < 3; i++) { const f = ((s.t * 0.8 + i / 3) % 1), g = f * 60 * s.u; if (s.t < 0.4) break; ctx.strokeStyle = rgba(s.k.g, (1 - f) * 0.8); ctx.lineWidth = 5 * s.u * (1 - f) + 1; zaokr(ctx, s.poz.x - w / 2 - g, s.poz.y - h / 2 - g, w + g * 2, h + g * 2, h / 2 + g); ctx.stroke(); }
    const b = 1 + 0.04 * Math.sin(s.t * 5); przycisk(s, t, s.poz.x, s.poz.y, px, s.k.g, e * b);
  });
  ctaN("cta-przycisk-rozwija", "Przycisk rozwija się ze strzałki", { tekst: "Sprawdź ofertę" }, (s) => {
    const ctx = s.ctx, px = 54 * s.u * s.p.rozmiar, h = px * 2, a = E.outBackMocno(T(s, 0, 0.4)), e = E.inOutCubic(T(s, 0.45, 0.55)); ctx.font = font(s, px, 800); const t = tekstP(s, s.p.tekst), tw = ctx.measureText(t).width, W = lerp(h, tw + h * 1.6, e), x0 = s.poz.x - W / 2, y0 = s.poz.y - h / 2;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.translate(-s.poz.x, -s.poz.y); karta(s, x0, y0, W, h, h / 2, s.k.g);
    ctx.save(); zaokr(ctx, x0, y0, W, h, h / 2); ctx.clip(); ctx.globalAlpha = s.alfa * clamp(e * 2 - 0.6); ctx.fillStyle = kontrast(s.k.g); ctx.fillText(t, x0 + h * 0.5, s.poz.y); ctx.restore();
    const ax = x0 + W - h / 2 + Math.max(0, Math.sin(s.t * 6)) * 8 * s.u * e, r = h * 0.36; ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(x0 + W - h / 2, s.poz.y, r * (0.8 + 0.2 * e), 0, PI * 2); ctx.fill();
    ctx.strokeStyle = kontrast(s.k.a); ctx.lineWidth = h * 0.07; ctx.lineCap = "round"; ctx.lineJoin = "round"; ctx.beginPath(); ctx.moveTo(ax - r * 0.4, s.poz.y); ctx.lineTo(ax + r * 0.4, s.poz.y); ctx.moveTo(ax + r * 0.05, s.poz.y - r * 0.35); ctx.lineTo(ax + r * 0.42, s.poz.y); ctx.lineTo(ax + r * 0.05, s.poz.y + r * 0.35); ctx.stroke(); ctx.restore();
  });
  ctaN("cta-przycisk-wypelnia", "Przycisk wypełnia się kolorem", { tekst: "Kup teraz" }, (s) => {
    const ctx = s.ctx, px = 58 * s.u * s.p.rozmiar, h = px * 2, a = E.outCubic(T(s, 0, 0.35)), e = E.inOutCubic(T(s, 0.4, 0.6)); ctx.font = font(s, px, 800); const t = tekstP(s, s.p.tekst), tw = ctx.measureText(t).width, W = tw + px * 2, x0 = s.poz.x - W / 2, y0 = s.poz.y - h / 2;
    ctx.save(); ctx.globalAlpha = s.alfa * a; ctx.strokeStyle = s.k.t; ctx.lineWidth = 5 * s.u; zaokr(ctx, x0, y0, W, h, h / 2); ctx.stroke(); ctx.fillStyle = s.k.t; ctx.fillText(t, s.poz.x - tw / 2, s.poz.y); ctx.restore();
    ctx.save(); zaokr(ctx, x0, y0, W, h, h / 2); ctx.clip(); ctx.beginPath(); ctx.rect(x0, y0, W * e, h); ctx.clip(); ctx.fillStyle = s.k.g; ctx.fillRect(x0, y0, W, h); ctx.fillStyle = kontrast(s.k.g); ctx.fillText(t, s.poz.x - tw / 2, s.poz.y);
    const b = T(s, 1.1, 0.6); if (b > 0 && b < 1) { const bx = lerp(x0 - h, x0 + W + h, E.inOutCubic(b)); ctx.fillStyle = "rgba(255,255,255,0.35)"; ctx.beginPath(); ctx.moveTo(bx, y0); ctx.lineTo(bx + h * 0.5, y0); ctx.lineTo(bx, y0 + h); ctx.lineTo(bx - h * 0.5, y0 + h); ctx.closePath(); ctx.fill(); } ctx.restore();
  });
  ctaN("cta-przycisk-3d", "Przycisk 3D wciskany kursorem", { tekst: "Zamów" }, (s) => {
    const ctx = s.ctx, px = 60 * s.u * s.p.rozmiar, h = px * 1.9, gl = 16 * s.u * s.p.rozmiar, k = 1.1 / s.p.tempo, a = E.outBackMocno(T(s, 0, 0.4)); ctx.font = font(s, px, 900); const t = tekstP(s, s.p.tekst), tw = ctx.measureText(t).width, W = tw + px * 2, x0 = s.poz.x - W / 2, y0 = s.poz.y - h / 2;
    const w = s.t < k - 0.05 ? 0 : s.t < k + 0.1 ? 1 : 1 - E.outElastic(okno(s.t, k + 0.1, 0.6)), z = gl * clamp(w);
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.translate(-s.poz.x, -s.poz.y); cien(s); ctx.fillStyle = ciemniej(s.k.g, 0.35); zaokr(ctx, x0, y0 + gl, W, h, h * 0.3); ctx.fill(); bezCienia(ctx);
    ctx.fillStyle = s.k.g; zaokr(ctx, x0, y0 + z, W, h, h * 0.3); ctx.fill(); ctx.fillStyle = "rgba(255,255,255,0.18)"; zaokr(ctx, x0 + 10 * s.u, y0 + z + 6 * s.u, W - 20 * s.u, h * 0.35, h * 0.18); ctx.fill();
    ctx.fillStyle = kontrast(s.k.g); ctx.fillText(t, s.poz.x - tw / 2, s.poz.y + z); ctx.restore();
    const m = E.inOutCubic(okno(s.t, 0.35, k - 0.4)); klik(s, lerp(x0 + W + 60 * s.u, s.poz.x + W * 0.2, m), lerp(s.poz.y + h * 2.4, s.poz.y + h * 0.2 + z, m), k);
  });
  ctaN("cta-link-w-opisie", "Link w opisie (strzałki w dół)", { tekst: "Link w opisie" }, (s) => {
    const ctx = s.ctx, px = 60 * s.u * s.p.rozmiar, e = E.outBack(T(s, 0, 0.45)), y = s.poz.y - px * 1.2; ctx.save(); ctx.globalAlpha = s.alfa * clamp(e * 2); cien(s); const w = szerLinii(s, s.p.tekst, px, 800); linia(s, s.p.tekst, s.poz.x - w / 2, y + (1 - e) * 30 * s.u, px, 800); ctx.restore();
    ctx.strokeStyle = s.k.a; ctx.lineWidth = 10 * s.u * s.p.rozmiar; ctx.lineCap = "round"; ctx.lineJoin = "round"; cien(s);
    for (let i = 0; i < 3; i++) { const f = ((s.t * 1.4 - i * 0.18) % 1 + 1) % 1, a = Math.sin(f * PI) * clamp((s.t - 0.3) * 3), yy = y + px * 1.1 + i * px * 0.65 + f * px * 0.3, r = px * 0.55; if (a <= 0) continue; ctx.globalAlpha = s.alfa * a; ctx.beginPath(); ctx.moveTo(s.poz.x - r, yy - r * 0.45); ctx.lineTo(s.poz.x, yy + r * 0.45); ctx.lineTo(s.poz.x + r, yy - r * 0.45); ctx.stroke(); }
    ctx.globalAlpha = s.alfa;
  }, { pola: ["tekst"] });
  ctaN("cta-odznaka-falista", "Falista odznaka promocji", { tekst: "-30%", tekst2: "tylko dziś", x: 0.72, y: 0.3 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), r = 170 * s.u * s.p.rozmiar, e = E.outBackMocno(T(s, 0, 0.55)), rot = (1 - e) * -2 + Math.sin(s.t * 1.5) * 0.06;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); ctx.rotate(rot); cien(s, ctx, 1.3); ctx.fillStyle = s.k.g; ctx.beginPath();
    for (let i = 0; i <= 120; i++) { const k = i / 120 * PI * 2, rr = r * (1 + 0.06 * Math.sin(k * 14)); i ? ctx.lineTo(Math.cos(k) * rr, Math.sin(k) * rr) : ctx.moveTo(Math.cos(k) * rr, Math.sin(k) * rr); } ctx.closePath(); ctx.fill(); bezCienia(ctx);
    ctx.strokeStyle = rgba(kontrast(s.k.g), 0.6); ctx.lineWidth = 3 * s.u; ctx.setLineDash([10 * s.u, 8 * s.u]); ctx.lineDashOffset = -s.t * 30 * s.u; ctx.beginPath(); ctx.arc(0, 0, r * 0.8, 0, PI * 2); ctx.stroke(); ctx.setLineDash([]);
    const p1 = dopasuj(s, s.p.tekst, r * 0.62, r * 1.3, 900); ctx.font = font(s, p1, 900); ctx.fillStyle = kontrast(s.k.g); const t = tekstP(s, s.p.tekst), w = ctx.measureText(t).width; ctx.fillText(t, -w / 2, s.p.tekst2 ? -r * 0.08 : 0);
    if (s.p.tekst2) { ctx.font = font(s, r * 0.18, 800); const t2 = String(s.p.tekst2).toLocaleUpperCase("pl"), w2 = ctx.measureText(t2).width; ctx.fillStyle = s.k.a; ctx.fillText(t2, -w2 / 2, r * 0.38); }
    ctx.restore();
    for (let i = 0; i < 4; i++) { const f = ((s.t * 0.7 + i * 0.25) % 1), k = i * 1.7 + 0.5, a = Math.sin(f * PI) * clamp(e); ctx.fillStyle = rgba(s.k.a, a); gwiazda(ctx, cx + Math.cos(k) * r * 1.25, cy + Math.sin(k) * r * 1.25, 4, r * 0.12 * a, r * 0.04 * a); ctx.fill(); }
  }, { pola: ["tekst", "tekst2", "xy"], dom: { pozycja: "srodek" } });
  ctaN("cta-wstega-rog", "Wstęga w rogu kadru", { tekst: "Promocja", wielkie: true }, (s) => {
    const ctx = s.ctx, lewa = s.poz.align === "left", dol = s.poz.y > s.H * 0.5, px = 46 * s.u * s.p.rozmiar, h = px * 1.8, d = 260 * s.u * s.p.rozmiar, e = E.outQuint(T(s, 0, 0.6));
    const cx = lewa ? 0 : s.W, cy = dol ? s.H : 0, kat = (lewa ? -1 : 1) * (dol ? -1 : 1) * PI / 4; ctx.save(); ctx.translate(cx, cy); ctx.rotate(kat); ctx.translate(0, (dol ? -1 : 1) * d * 0.72);
    const L = d * 3; ctx.translate((lewa ? -1 : 1) * (1 - e) * L * 0, 0); ctx.beginPath(); ctx.rect(-L / 2, -h / 2, L * e, h); ctx.clip(); cien(s); ctx.fillStyle = s.k.g; ctx.fillRect(-L / 2, -h / 2, L, h); bezCienia(ctx);
    ctx.fillStyle = rgba(kontrast(s.k.g), 0.35); ctx.fillRect(-L / 2, -h / 2 + 5 * s.u, L, 2 * s.u); ctx.fillRect(-L / 2, h / 2 - 7 * s.u, L, 2 * s.u);
    const t = tekstP(s, s.p.tekst), p1 = dopasuj(s, s.p.tekst, px, d * 1.3, 900); ctx.font = font(s, p1, 900); ctx.fillStyle = kontrast(s.k.g); ctx.fillText(t, -ctx.measureText(t).width / 2, 0); ctx.restore();
  }, { pola: ["tekst"], dom: { pozycja: "prawy-gora" } });
  const ikGlobus = (c, x, y, r, k) => { c.strokeStyle = k; c.lineWidth = r * 0.14; c.beginPath(); c.arc(x, y, r, 0, PI * 2); c.stroke(); c.beginPath(); c.ellipse(x, y, r * 0.45, r, 0, 0, PI * 2); c.stroke(); c.beginPath(); c.moveTo(x - r, y); c.lineTo(x + r, y); c.stroke(); };
  ctaN("cta-adres-strony", "Adres strony do wpisania", { tekst: "nadamedia.pl", tekst2: "Wejdź na" }, (s) => {
    const ctx = s.ctx, px = 54 * s.u * s.p.rozmiar, h = px * 1.9, url = String(s.p.tekst || ""); ctx.font = font(s, px, 700); const tw = ctx.measureText(url).width, W = tw + h * 1.6, x0 = s.poz.x - W / 2, y0 = s.poz.y - h / 2, a = E.outBack(T(s, 0, 0.45));
    if (s.p.tekst2) { const e = E.outCubic(T(s, 0, 0.4)); ctx.save(); ctx.globalAlpha = s.alfa * e; cien(s); ctx.font = font(s, px * 0.7, 600); ctx.fillStyle = s.k.t; const w2 = ctx.measureText(s.p.tekst2).width; ctx.fillText(s.p.tekst2, s.poz.x - w2 / 2, y0 - px * 0.7); ctx.restore(); }
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.translate(-s.poz.x, -s.poz.y); karta(s, x0, y0, W, h, h / 2, "#FFFFFF"); ikGlobus(ctx, x0 + h * 0.55, s.poz.y, h * 0.22, s.k.g);
    const zn = Array.from(url), n = Math.floor(clamp((s.t - 0.4) / (zn.length * 0.05 / s.p.tempo)) * zn.length), vis = zn.slice(0, n).join(""); ctx.font = font(s, px, 700); ctx.fillStyle = "#111111"; ctx.fillText(vis, x0 + h * 1.0, s.poz.y);
    const vw = ctx.measureText(vis).width; if (n < zn.length || Math.floor(s.t * 2.5) % 2 === 0) { ctx.fillStyle = s.k.g; ctx.fillRect(x0 + h * 1.0 + vw + 4 * s.u, s.poz.y - px * 0.45, 4 * s.u, px * 0.9); }
    const l = E.inOutCubic(okno(s.t, 0.5 + zn.length * 0.05 / s.p.tempo, 0.4)); ctx.fillStyle = s.k.a; ctx.fillRect(x0 + h * 1.0, s.poz.y + px * 0.55, tw * l, 5 * s.u); ctx.restore();
  });
  ctaN("cta-dolacz-spolecznosc", "Dołącz do społeczności", { tekst: "Dołącz do *2 300* twórców", tekst2: "Dołączam", lista: "AK; MN; ZW; PL; OB" }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista).slice(0, 6), r = 54 * s.u * s.p.rozmiar, n = el.length, W = r * 2 + (n) * r * 1.6, x0 = s.poz.x - W / 2, y = s.poz.y - r * 2.2, kol = [s.k.g, s.k.a, "#60A5FA", "#A78BFA", "#34D399", "#F472B6"];
    el.forEach((t, i) => { const e = E.outBackMocno(T(s, i * 0.1, 0.4)); if (e <= 0) return; const x = x0 + r + i * r * 1.6; ctx.save(); ctx.translate(x, y); ctx.scale(e, e); ctx.fillStyle = "#FFFFFF"; ctx.beginPath(); ctx.arc(0, 0, r * 1.08, 0, PI * 2); ctx.fill(); ctx.fillStyle = kol[i % kol.length]; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); ctx.font = font(s, r * 0.62, 800); ctx.fillStyle = kontrast(kol[i % kol.length]); const tw = ctx.measureText(t).width; ctx.fillText(t, -tw / 2, 0); ctx.restore(); });
    const b = E.outBackMocno(T(s, n * 0.1 + 0.1, 0.4)); if (b > 0) { const x = x0 + r + n * r * 1.6; ctx.save(); ctx.translate(x, y); ctx.scale(b, b); ctx.fillStyle = "#FFFFFF"; ctx.beginPath(); ctx.arc(0, 0, r * 1.08, 0, PI * 2); ctx.fill(); ctx.fillStyle = rgba(s.k.tl, 0.95); ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); ctx.font = font(s, r * 0.6, 900); ctx.fillStyle = s.k.t; ctx.fillText("+", -ctx.measureText("+").width / 2, 0); ctx.restore(); }
    podpis(s, y + r * 1.6, E.outCubic(T(s, 0.6, 0.5)), 58);
    if (s.p.tekst2) przycisk(s, tekstP(s, s.p.tekst2), s.poz.x, s.poz.y + r * 2.6, 46 * s.u * s.p.rozmiar, s.k.g, E.outBackMocno(T(s, 0.9, 0.45)));
  }, { pola: ["tekst", "tekst2", "lista"], dom: { pozycja: "srodek" }, czas: 3.5 });
  ctaN("cta-oznacz-znajomego", "Oznacz znajomego", { tekst: "Oznacz osobę, która *musi* to zobaczyć", lista: "@ania.kowal; @tomek_gotuje; @kasia.biega; @marek.foto" }, (s) => {
    const ctx = s.ctx, r = 90 * s.u * s.p.rozmiar, cy = s.poz.y - r * 1.3, e = E.outElastic(T(s, 0, 0.9)), sk = 1 + 0.06 * Math.sin(s.t * 6);
    ctx.save(); ctx.translate(s.poz.x, cy); ctx.scale(e * sk, e * sk); ctx.rotate(Math.sin(s.t * 3) * 0.1); cien(s); ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); bezCienia(ctx); ctx.font = font(s, r * 1.2, 900); ctx.fillStyle = kontrast(s.k.a); const at = "@"; ctx.fillText(at, -ctx.measureText(at).width / 2, -r * 0.05); ctx.restore();
    podpis(s, cy + r * 1.4, E.outCubic(T(s, 0.3, 0.5)), 56);
    const el = lista(s.p.lista); if (!el.length) return; const dl = 0.7 / s.p.tempo, tt = Math.max(0, s.t - 0.9), i = Math.floor(tt / dl) % el.length, f = (tt % dl) / dl, px = 46 * s.u * s.p.rozmiar, y = cy + r * 1.4 + 210 * s.u * s.p.rozmiar;
    if (s.t < 0.9) return; const a = E.outBack(okno(s.t, 0.9, 0.4)); ctx.font = font(s, px, 700); const w = Math.max(...el.map((x) => ctx.measureText(x).width)) + px * 1.6, h = px * 1.8;
    ctx.save(); ctx.translate(s.poz.x, y); ctx.scale(a, a); karta(s, -w / 2, -h / 2, w, h, h / 2, rgba(s.k.tl, 0.9)); ctx.beginPath(); ctx.rect(-w / 2, -h / 2, w, h); ctx.clip();
    const k = E.inOutCubic(clamp((f - 0.75) / 0.25)); [[el[i], -k * h], [el[(i + 1) % el.length], (1 - k) * h]].forEach(([t, dy]) => { ctx.fillStyle = s.k.t; ctx.fillText(t, -ctx.measureText(t).width / 2, dy); }); ctx.restore();
  }, { pola: ["tekst", "lista"], dom: { pozycja: "srodek" }, czas: 4 });
  ctaN("cta-cennik", "Karta cennika z planem", { tekst: "Pakiet Pro", liczba: 199, po: " zł / mies.", lista: "12 rolek miesięcznie\nNapisy i muzyka\n*Priorytetowy montaż*", tekst2: "Wybieram", przed: "Najpopularniejszy" }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista), cw = szerKarty(s, 700), px = 52 * s.u * s.p.rozmiar, pad = px * 0.9, lh = px * 1.5, h = pad * 2 + px * 4.4 + el.length * lh + px * 2.4, x0 = s.poz.x - cw / 2, y0 = s.poz.y - h / 2, a = E.outBack(T(s, 0, 0.5));
    ctx.save(); wejscieKarty(s, s.poz.x, s.poz.y, a); karta(s, x0, y0, cw, h, 34 * s.u, "#FFFFFF"); ctx.strokeStyle = s.k.g; ctx.lineWidth = 5 * s.u; zaokr(ctx, x0, y0, cw, h, 34 * s.u); ctx.stroke();
    if (s.p.przed) { const lb = String(s.p.przed).toLocaleUpperCase("pl"); ctx.font = font(s, px * 0.42, 900); const lw = ctx.measureText(lb).width + px; ctx.fillStyle = s.k.g; zaokr(ctx, s.poz.x - lw / 2, y0 - px * 0.4, lw, px * 0.8, px * 0.4); ctx.fill(); ctx.fillStyle = kontrast(s.k.g); ctx.fillText(lb, s.poz.x - lw / 2 + px * 0.5, y0); }
    ctx.font = font(s, px * 0.85, 800); ctx.fillStyle = "#374151"; const t1 = tekstP(s, s.p.tekst); ctx.fillText(t1, s.poz.x - ctx.measureText(t1).width / 2, y0 + pad + px * 0.5);
    const v = Math.round(wartosc(s, E.outCubic(T(s, 0.2, 1)))), cena = liczbaTekst(v); ctx.font = font(s, px * 2.2, 900); const cwid = ctx.measureText(cena).width; ctx.font = font(s, px * 0.6, 600); const pw = ctx.measureText(s.p.po || "").width, cx0 = s.poz.x - (cwid + pw + px * 0.2) / 2;
    ctx.font = font(s, px * 2.2, 900); ctx.fillStyle = "#111111"; ctx.fillText(cena, cx0, y0 + pad + px * 2.2); ctx.font = font(s, px * 0.6, 600); ctx.fillStyle = "#6B7280"; ctx.fillText(s.p.po || "", cx0 + cwid + px * 0.2, y0 + pad + px * 2.6);
    ctx.fillStyle = "#E5E7EB"; ctx.fillRect(x0 + pad, y0 + pad + px * 3.7, cw - pad * 2, 2 * s.u);
    el.forEach((t, i) => { const e = E.outBack(T(s, 0.5 + i * 0.15, 0.4)); if (e <= 0) return; const y = y0 + pad + px * 4.4 + (i + 0.5) * lh, r = px * 0.36; ctx.save(); ctx.translate(x0 + pad + r, y); ctx.scale(e, e); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); ptaszek(ctx, 0, 0, r * 0.5, 1, kontrast(s.k.g), 3.5 * s.u); ctx.restore();
      ctx.save(); ctx.globalAlpha *= clamp(e); linia(s, t, x0 + pad + r * 2.8, y, px * 0.8, 600, "#111111", s.k.g); ctx.restore(); });
    if (s.p.tekst2) przycisk(s, tekstP(s, s.p.tekst2), s.poz.x, y0 + h - pad - px * 0.6, px * 0.75, s.k.g, E.outBackMocno(T(s, 0.6 + el.length * 0.15, 0.4)));
    ctx.restore();
  }, { pola: ["tekst", "liczba", "po", "lista", "tekst2", "przed"], dom: { pozycja: "srodek" }, czas: 4 });
  ctaN("cta-gratis", "Prezent: pudełko się otwiera", { tekst: "GRATIS", tekst2: "do każdego zamówienia" }, (s) => {
    const ctx = s.ctx, b = 220 * s.u * s.p.rozmiar, cx = s.poz.x, by = s.poz.y + b * 0.35, a = E.outBack(T(s, 0, 0.45)), dr = s.t < 0.8 ? Math.sin(s.t * 40) * 0.04 * clamp((s.t - 0.4) * 4) : 0, o = E.outBack(T(s, 0.85, 0.5));
    ctx.save(); ctx.translate(cx, by); ctx.scale(a, a); ctx.rotate(dr);
    const tx = E.outBackMocno(T(s, 1.0, 0.5)); if (tx > 0) { const p1 = dopasuj(s, s.p.tekst, b * 0.6, s.W * 0.8, 900); ctx.save(); ctx.translate(0, -b * 0.45 - tx * b * 0.5); ctx.scale(tx, tx); cien(s, ctx, 1.4); ctx.font = font(s, p1, 900); ctx.fillStyle = s.k.a; const t = tekstP(s, s.p.tekst); ctx.fillText(t, -ctx.measureText(t).width / 2, 0); ctx.restore(); }
    cien(s); ctx.fillStyle = s.k.g; ctx.fillRect(-b / 2, -b * 0.45, b, b * 0.9); bezCienia(ctx); ctx.fillStyle = s.k.a; ctx.fillRect(-b * 0.08, -b * 0.45, b * 0.16, b * 0.9);
    ctx.save(); ctx.translate(-b * 0.58 + o * b * 0.75, -b * 0.45 - o * b * 0.55); ctx.rotate(o * 0.7); ctx.globalAlpha *= 1 - okno(s.t, 1.3, 0.4); ctx.fillStyle = ciemniej(s.k.g, 0.12); ctx.fillRect(0, -b * 0.22, b * 1.16, b * 0.22); ctx.fillStyle = s.k.a; ctx.fillRect(b * 0.5, -b * 0.22, b * 0.16, b * 0.22);
    ctx.strokeStyle = s.k.a; ctx.lineWidth = b * 0.06; ctx.beginPath(); ctx.ellipse(b * 0.45, -b * 0.3, b * 0.13, b * 0.08, -0.4, 0, PI * 2); ctx.stroke(); ctx.beginPath(); ctx.ellipse(b * 0.71, -b * 0.3, b * 0.13, b * 0.08, 0.4, 0, PI * 2); ctx.stroke(); ctx.restore();
    ctx.restore();
    const w = okno(s.t, 0.85, 0.8); if (w > 0 && w < 1) for (let i = 0; i < 12; i++) { const k = -PI / 2 + (i / 11 - 0.5) * PI * 1.1, d = b * (0.5 + w * 1.1); ctx.fillStyle = rgba(i % 2 ? s.k.a : "#FFFFFF", 1 - w); gwiazda(ctx, cx + Math.cos(k) * d, by - b * 0.5 + Math.sin(k) * d * 0.8, 4, b * 0.07, b * 0.025); ctx.fill(); }
    if (s.p.tekst2) podpis(s, by + b * 0.75, E.outCubic(T(s, 1.2, 0.5)), 50, "tekst2");
  }, { dom: { pozycja: "srodek" }, czas: 3.5 });
  ctaN("cta-darmowa-dostawa", "Darmowa dostawa (furgonetka)", { tekst: "Darmowa *dostawa*", tekst2: "od 100 zł" }, (s) => {
    const ctx = s.ctx, w = 300 * s.u * s.p.rozmiar, h = w * 0.55, e = E.outQuint(T(s, 0, 0.8)), cel = s.poz.x - w * 0.9, x = lerp(-w * 1.2, cel, e), y = s.poz.y, sq = s.t > 0.75 && s.t < 1.1 ? Math.sin((s.t - 0.75) / 0.35 * PI) * 0.06 : 0, kol = rgba("#FFFFFF", 1);
    if (e < 1) for (let i = 0; i < 4; i++) { ctx.fillStyle = rgba(s.k.t, 0.5 * (1 - e)); ctx.fillRect(x - w * (0.7 + i * 0.25), y - h * 0.3 + i * h * 0.18, w * 0.5, 5 * s.u); }
    ctx.save(); ctx.translate(x, y + h / 2); ctx.rotate(-sq); ctx.translate(0, -h / 2); cien(s); ctx.fillStyle = s.k.g; zaokr(ctx, -w / 2, -h / 2, w * 0.66, h * 0.8, 14 * s.u); ctx.fill();
    ctx.beginPath(); ctx.moveTo(w * 0.17, -h * 0.25); ctx.lineTo(w * 0.36, -h * 0.25); ctx.lineTo(w * 0.5, 0); ctx.lineTo(w * 0.5, h * 0.3); ctx.lineTo(w * 0.17, h * 0.3); ctx.closePath(); ctx.fill(); bezCienia(ctx);
    ctx.fillStyle = rgba("#FFFFFF", 0.8); ctx.beginPath(); ctx.moveTo(w * 0.22, -h * 0.17); ctx.lineTo(w * 0.33, -h * 0.17); ctx.lineTo(w * 0.43, 0); ctx.lineTo(w * 0.22, 0); ctx.closePath(); ctx.fill();
    ptaszek(ctx, -w * 0.17, -h * 0.1, h * 0.17, 1, kontrast(s.k.g), h * 0.06);
    [-w * 0.3, w * 0.32].forEach((wx) => { ctx.save(); ctx.translate(wx, h * 0.32); ctx.rotate(x / (h * 0.15)); ctx.fillStyle = "#1F2937"; ctx.beginPath(); ctx.arc(0, 0, h * 0.17, 0, PI * 2); ctx.fill(); ctx.fillStyle = "#D1D5DB"; ctx.fillRect(-h * 0.07, -h * 0.015, h * 0.14, h * 0.03); ctx.beginPath(); ctx.arc(0, 0, h * 0.06, 0, PI * 2); ctx.fill(); ctx.restore(); });
    ctx.restore(); void kol;
    const t = E.outCubic(T(s, 0.7, 0.5)); if (t <= 0) return; const tx = cel + w * 0.65; ctx.save(); ctx.globalAlpha = s.alfa * t; cien(s); linia(s, s.p.tekst, tx + (1 - t) * 40 * s.u, y - (s.p.tekst2 ? h * 0.18 : 0), 62 * s.u * s.p.rozmiar, 900);
    if (s.p.tekst2) { ctx.font = font(s, 40 * s.u * s.p.rozmiar, 600); ctx.fillStyle = rgba(s.k.t, 0.85); ctx.fillText(s.p.tekst2, tx + (1 - t) * 40 * s.u, y + h * 0.32); } ctx.restore();
  }, { dom: { pozycja: "srodek" }, czas: 3.5 });
  ctaN("cta-ostatnie-sztuki", "Ostatnie sztuki (pasek zapasu)", { tekst: "Zostały tylko *3 sztuki*!", liczba: 3, od: 20 }, (s) => {
    const ctx = s.ctx, W = Math.min(s.W * 0.78, 820 * s.u) * s.p.rozmiar, h = 34 * s.u * s.p.rozmiar, x0 = s.poz.x - W / 2, y = s.poz.y + 40 * s.u, max = Math.max(1, +s.p.od || 20), v = lerp(max, +s.p.liczba || 0, E.inOutCubic(T(s, 0.3, 1.2))), a = E.outCubic(T(s, 0, 0.4)), alarm = s.t > 1.5 / s.p.tempo && Math.floor(s.t * 3) % 2 === 0;
    ctx.save(); ctx.globalAlpha = s.alfa * a; ctx.fillStyle = rgba(s.k.t, 0.2); zaokr(ctx, x0, y, W, h, h / 2); ctx.fill(); const kol = v / max < 0.3 ? (alarm ? czerwony : "#F97316") : s.k.g; ctx.fillStyle = kol; zaokr(ctx, x0, y, Math.max(h, W * v / max), h, h / 2); ctx.fill();
    for (let i = 1; i < 10; i++) { ctx.fillStyle = rgba(s.k.tl, 0.35); ctx.fillRect(x0 + W * i / 10 - 1.5 * s.u, y, 3 * s.u, h); }
    cien(s); const ul = uloz(s, s.p.tekst, 60 * s.u * s.p.rozmiar, { y: y - 60 * s.u * s.p.rozmiar, align: "center", x: s.poz.x }); ctx.font = ul.font; ul.slowa.forEach((w) => { ctx.fillStyle = w.wyr ? (alarm ? czerwony : s.k.a) : s.k.t; ctx.fillText(w.t, w.x, w.y); });
    ctx.font = font(s, 38 * s.u * s.p.rozmiar, 700); ctx.fillStyle = rgba(s.k.t, 0.8); const t2 = `${Math.round(v)} / ${max}`; ctx.fillText(t2, x0 + W - ctx.measureText(t2).width, y + h + 34 * s.u); ctx.restore();
  }, { pola: ["tekst", "liczba", "od"], dom: { pozycja: "srodek" }, czas: 3.5 });
  ctaN("cta-ekran-koncowy", "Ekran końcowy z miejscami na filmy", { tekst: "Obejrzyj też", tekst2: "Subskrybuj" }, (s) => {
    const ctx = s.ctx, pion = s.H > s.W, fw = pion ? s.W * 0.78 : s.W * 0.34, fh = fw * 9 / 16, gap = 40 * s.u, px = 56 * s.u * s.p.rozmiar;
    const ram = pion ? [[s.W / 2 - fw / 2, s.H * 0.24], [s.W / 2 - fw / 2, s.H * 0.24 + fh + gap]] : [[s.W * 0.1, s.H * 0.3], [s.W * 0.1 + fw + gap, s.H * 0.3]];
    const e0 = E.outCubic(T(s, 0, 0.4)); ctx.save(); ctx.globalAlpha = s.alfa * e0; cien(s); const t = tekstP(s, s.p.tekst); ctx.font = font(s, px, 900); ctx.fillStyle = s.k.t; ctx.fillText(t, pion ? s.W / 2 - ctx.measureText(t).width / 2 : s.W * 0.1, ram[0][1] - px * 0.9); ctx.restore();
    ram.forEach(([x, y], i) => { const e = E.outBack(T(s, 0.15 + i * 0.15, 0.5)); if (e <= 0) return; ctx.save(); ctx.translate(x + fw / 2, y + fh / 2); ctx.scale(e, e); ctx.strokeStyle = s.k.t; ctx.lineWidth = 6 * s.u; ctx.setLineDash([18 * s.u, 12 * s.u]); ctx.lineDashOffset = -s.t * 30 * s.u; zaokr(ctx, -fw / 2, -fh / 2, fw, fh, 20 * s.u); ctx.stroke(); ctx.setLineDash([]);
      ctx.fillStyle = rgba(s.k.tl, 0.5); ctx.beginPath(); ctx.arc(0, 0, fh * 0.14, 0, PI * 2); ctx.fill(); ctx.fillStyle = s.k.t; ctx.beginPath(); ctx.moveTo(-fh * 0.04, -fh * 0.06); ctx.lineTo(fh * 0.07, 0); ctx.lineTo(-fh * 0.04, fh * 0.06); ctx.closePath(); ctx.fill(); ctx.restore(); });
    const r = (pion ? s.W * 0.11 : s.H * 0.13) * s.p.rozmiar, cx = pion ? s.W / 2 : s.W * 0.1 + fw * 2 + gap + r * 2.2, cy = pion ? ram[1][1] + fh + r * 1.8 : s.H * 0.3 + fh / 2, a = E.outBackMocno(T(s, 0.5, 0.5)); if (a <= 0) return;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(a, a); ctx.strokeStyle = s.k.g; ctx.lineWidth = r * 0.1; ctx.beginPath(); ctx.arc(0, 0, r * 1.1, 0, PI * 2); ctx.stroke(); ctx.restore(); awatar(s, cx, cy, r, s.k.g, a);
    if (s.p.tekst2) przycisk(s, tekstP(s, s.p.tekst2), cx, cy + r * 1.9, px * 0.6, s.k.g, E.outBackMocno(T(s, 0.7, 0.45)));
  }, { pola: ["tekst", "tekst2", "logo"], czas: 5 });
  ctaN("cta-przesun-w-bok", "Przesuń w bok (karuzela)", { tekst: "Przesuń, żeby zobaczyć więcej", liczba: 5 }, (s) => {
    const ctx = s.ctx, px = 52 * s.u * s.p.rozmiar, n = Math.max(2, Math.min(10, Math.round(+s.p.liczba || 5))), a = E.outCubic(T(s, 0, 0.4)), cyc = (s.t * 0.8) % 1, sw = E.inOutCubic(clamp((cyc - 0.15) / 0.55)), hx = s.poz.x + lerp(160, -160, sw) * s.u * s.p.rozmiar, hy = s.poz.y - px * 1.4;
    ctx.save(); ctx.globalAlpha = s.alfa * a; if (sw > 0 && sw < 1) { ctx.strokeStyle = rgba(s.k.a, 0.8); ctx.lineWidth = 8 * s.u; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(s.poz.x + 160 * s.u * s.p.rozmiar, hy - px * 0.9); ctx.lineTo(hx + px * 0.3, hy - px * 0.9); ctx.stroke(); }
    ctx.translate(hx, hy); ctx.rotate(-0.2 + sw * 0.1); cien(s); ctx.fillStyle = "#FFFFFF"; ctx.strokeStyle = "#111111"; ctx.lineWidth = 3 * s.u; const r = px * 0.9;
    zaokr(ctx, -r * 0.18, -r * 1.3, r * 0.36, r * 1.3, r * 0.18); ctx.fill(); ctx.stroke(); zaokr(ctx, -r * 0.45, -r * 0.25, r * 1.05, r * 1.0, r * 0.35); ctx.fill(); ctx.stroke(); ctx.restore();
    ctx.save(); ctx.globalAlpha = s.alfa * a; const dr = 9 * s.u * s.p.rozmiar, akt = Math.floor(s.t * 0.8) % n, dy = s.poz.y + px * 0.6; for (let i = 0; i < n; i++) { const x = s.poz.x + (i - (n - 1) / 2) * dr * 3.5; ctx.fillStyle = i === akt ? s.k.a : rgba(s.k.t, 0.4); zaokr(ctx, x - (i === akt ? dr * 2 : dr), dy - dr, i === akt ? dr * 4 : dr * 2, dr * 2, dr); ctx.fill(); }
    cien(s); const w = szerLinii(s, s.p.tekst, px * 0.85, 700); linia(s, s.p.tekst, s.poz.x - w / 2, dy + px * 1.2, px * 0.85, 700); ctx.restore();
  }, { pola: ["tekst", "liczba"], czas: 4 });
  ctaN("cta-glosowanie-emoji", "Głosuj emoji w komentarzu", { tekst: "Który kadr *lepszy*? Daj znać w komentarzu", lista: "🔥: Pierwszy\n❤️: Drugi" }, (s) => {
    const ctx = s.ctx, d = lista(s.p.lista).slice(0, 3).map((x) => { const i = x.indexOf(":"); return i > 0 ? [x.slice(0, i).trim(), x.slice(i + 1).trim()] : [x, ""]; }), n = d.length || 1, r = 110 * s.u * s.p.rozmiar, gap = r * 1.4, W = n * r * 2 + (n - 1) * gap, y = s.poz.y;
    d.forEach(([em, lb], i) => { const e = E.outElastic(T(s, 0.1 + i * 0.2, 0.9)), x = s.poz.x - W / 2 + r + i * (r * 2 + gap), puls = 1 + 0.12 * Math.max(0, Math.sin(s.t * 4 - i * PI)); if (e <= 0) return;
      ctx.save(); ctx.translate(x, y); ctx.scale(e * puls, e * puls); karta(s, -r, -r, r * 2, r * 2, r, rgba(s.k.tl, 0.8)); emoji(ctx, em, 0, r * 0.06, r * 1.15); ctx.restore();
      if (lb) { ctx.save(); ctx.globalAlpha = s.alfa * clamp(e); cien(s); ctx.font = font(s, r * 0.4, 800); ctx.fillStyle = s.k.t; ctx.fillText(lb, x - ctx.measureText(lb).width / 2, y + r * 1.45); ctx.restore(); }
      if (i < n - 1) { const vs = E.outBack(T(s, 0.4, 0.4)); ctx.save(); ctx.translate(x + r + gap / 2, y); ctx.scale(vs, vs); ctx.font = font(s, r * 0.45, 900); ctx.fillStyle = s.k.a; const t = "czy"; ctx.fillText(t, -ctx.measureText(t).width / 2, 0); ctx.restore(); } });
    podpis(s, y - r * 2.6, E.outCubic(T(s, 0, 0.5)), 56);
  }, { pola: ["tekst", "lista"], dom: { pozycja: "srodek" }, czas: 4 });
  ctaN("cta-przycisk-poswiata", "Przycisk z obiegającym światłem", { tekst: "Dołącz za darmo" }, (s) => {
    const ctx = s.ctx, px = 56 * s.u * s.p.rozmiar, h = px * 2, a = E.outBack(T(s, 0, 0.45)); ctx.font = font(s, px, 800); const t = tekstP(s, s.p.tekst), tw = ctx.measureText(t).width, W = tw + px * 2, x0 = s.poz.x - W / 2, y0 = s.poz.y - h / 2;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.translate(-s.poz.x, -s.poz.y); karta(s, x0, y0, W, h, h / 2, rgba(s.k.tl, 0.95)); ctx.strokeStyle = rgba(s.k.g, 0.35); ctx.lineWidth = 4 * s.u; zaokr(ctx, x0, y0, W, h, h / 2); ctx.stroke();
    const pk = []; for (let i = 0; i <= 160; i++) { const f = i / 160, L = 2 * (W - h) + PI * h, d = f * L; let x, y; if (d < W - h) { x = x0 + h / 2 + d; y = y0; } else if (d < W - h + PI * h / 2) { const k = -PI / 2 + (d - (W - h)) / (h / 2); x = x0 + W - h / 2 + Math.cos(k) * h / 2; y = s.poz.y + Math.sin(k) * h / 2; } else if (d < 2 * (W - h) + PI * h / 2) { x = x0 + W - h / 2 - (d - (W - h) - PI * h / 2); y = y0 + h; } else { const k = PI / 2 + (d - 2 * (W - h) - PI * h / 2) / (h / 2); x = x0 + h / 2 + Math.cos(k) * h / 2; y = s.poz.y + Math.sin(k) * h / 2; } pk.push([x, y]); }
    const g0 = (s.t * 0.6) % 1, n = 40; ctx.lineCap = "round"; for (let i = 0; i < n; i++) { const a1 = Math.floor(((g0 + i / 160) % 1) * 160), a2 = Math.min(160, a1 + 1); ctx.strokeStyle = rgba(i > n * 0.7 ? "#FFFFFF" : s.k.a, Math.pow(i / n, 1.5)); ctx.lineWidth = (3 + 5 * i / n) * s.u; ctx.beginPath(); ctx.moveTo(...pk[a1]); ctx.lineTo(...pk[a2]); ctx.stroke(); }
    ctx.fillStyle = s.k.t; ctx.fillText(t, s.poz.x - tw / 2, s.poz.y); ctx.restore();
  }, { pola: ["tekst"], czas: 4 });
  const ikOko = (c, x, y, r, k) => { c.strokeStyle = k; c.fillStyle = k; c.lineWidth = r * 0.16; c.beginPath(); c.moveTo(x - r, y); c.quadraticCurveTo(x, y - r * 1.1, x + r, y); c.quadraticCurveTo(x, y + r * 1.1, x - r, y); c.closePath(); c.stroke(); c.beginPath(); c.arc(x, y, r * 0.32, 0, PI * 2); c.fill(); };
  ctaN("cta-ogladaja-teraz", "Licznik oglądających teraz", { liczba: 1248, tekst: "osób ogląda teraz" }, (s) => {
    const ctx = s.ctx, px = 50 * s.u * s.p.rozmiar, v = Math.round((+s.p.liczba || 0) * E.outCubic(T(s, 0.1, 1.2)) + (s.t > 1.3 ? Math.sin(s.t * 2.3) * 7 + Math.sin(s.t * 5.1) * 3 : 0)), h = px * 1.9, a = E.outBack(T(s, 0, 0.45));
    const tv = liczbaTekst(Math.max(0, v)), tt = String(s.p.tekst || ""); ctx.font = font(s, px, 900); const w1 = ctx.measureText(liczbaTekst(+s.p.liczba || 0)).width; ctx.font = font(s, px * 0.8, 600); const w2 = ctx.measureText(tt).width, W = h * 1.4 + w1 + px * 0.4 + w2 + px, x0 = s.poz.x - W / 2, y0 = s.poz.y - h / 2;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.translate(-s.poz.x, -s.poz.y); karta(s, x0, y0, W, h, h / 2, rgba(s.k.tl, 0.9));
    const pd = 0.5 + 0.5 * Math.sin(s.t * 5); ctx.fillStyle = rgba(czerwony, 0.3 * pd); ctx.beginPath(); ctx.arc(x0 + h * 0.5, s.poz.y, h * 0.22 * (1 + pd * 0.6), 0, PI * 2); ctx.fill(); ctx.fillStyle = czerwony; ctx.beginPath(); ctx.arc(x0 + h * 0.5, s.poz.y, h * 0.14, 0, PI * 2); ctx.fill();
    ikOko(ctx, x0 + h * 1.05, s.poz.y, h * 0.2, s.k.t); ctx.font = font(s, px, 900); ctx.fillStyle = s.k.a; ctx.fillText(tv, x0 + h * 1.4, s.poz.y); ctx.font = font(s, px * 0.8, 600); ctx.fillStyle = s.k.t; ctx.fillText(tt, x0 + h * 1.4 + w1 + px * 0.4, s.poz.y); ctx.restore();
  }, { pola: ["liczba", "tekst"], dom: { pozycja: "gora" }, czas: 4 });
  ctaN("cta-ocen-nas", "Oceń nas: gwiazdki z kursorem", { tekst: "Oceń nas", tekst2: "Dziękujemy! ❤️" }, (s) => {
    const ctx = s.ctx, r = 64 * s.u * s.p.rozmiar, gap = r * 0.55, W = 5 * r * 2 + 4 * gap, x0 = s.poz.x - W / 2, y = s.poz.y, a = E.outCubic(T(s, 0, 0.4)), st = 0.5 / s.p.tempo, krok = 0.22 / s.p.tempo, kon = st + krok * 5;
    podpis(s, y - r * 2.4, a, 60);
    for (let i = 0; i < 5; i++) { const x = x0 + r + i * (r * 2 + gap), on = s.t > st + krok * (i + 0.6), p = E.outBackMocno(okno(s.t, st + krok * (i + 0.6), 0.3)), e = E.outBack(T(s, i * 0.06, 0.35)); if (e <= 0) continue;
      ctx.save(); ctx.translate(x, y); ctx.scale(e * (on ? 1 + 0.25 * Math.sin(p * PI) : 1), e * (on ? 1 + 0.25 * Math.sin(p * PI) : 1)); ctx.lineJoin = "round"; gwiazda(ctx, 0, 0, 5, r, r * 0.46); if (on) { ctx.fillStyle = "#FBBF24"; ctx.fill(); } else { ctx.strokeStyle = s.k.t; ctx.lineWidth = 5 * s.u; ctx.stroke(); } ctx.restore(); }
    if (s.t < kon + 0.3) { const m = clamp((s.t - st) / (krok * 5)), kx = lerp(x0 + r, x0 + W - r, m) + r * 0.3, ky = y + r * 0.4; klik(s, kx, ky, st + krok * (Math.min(4, Math.floor(m * 5)) + 0.6)); }
    if (s.p.tekst2) podpis(s, y + r * 1.8, E.outCubic(okno(s.t, kon + 0.1, 0.4)), 54, "tekst2");
  }, { dom: { pozycja: "srodek" }, czas: 3.5 });

  // ---------- liczby i wykresy (v18) ----------
  const tytulWykresu = (s, x, y, e, align) => { if (!s.p.tekst) return; const ctx = s.ctx; ctx.save(); ctx.globalAlpha = s.alfa * e; cien(s); const px = 54 * s.u * s.p.rozmiar, w = szerLinii(s, s.p.tekst, px, 800); linia(s, s.p.tekst, align === "center" ? x - w / 2 : x, y, px, 800); ctx.restore(); };
  liczbaN("liczby-kafelki-kpi", "Kafelki z wynikami (KPI)", { lista: "Zasięg: 128000\nPolubienia: 8400\nNowi klienci: 37\nZapisy: 1250", tekst: "Wyniki miesiąca" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista).slice(0, 6), kol = s.H > s.W ? 2 : Math.min(4, d.length), rz = Math.ceil(d.length / kol), gap = 26 * s.u, tw = Math.min((s.W * 0.88 - gap * (kol - 1)) / kol, 420 * s.u * s.p.rozmiar), th = tw * 0.72, W = kol * tw + (kol - 1) * gap, H = rz * th + (rz - 1) * gap, x0 = s.poz.x - W / 2, y0 = s.poz.y - H / 2;
    tytulWykresu(s, s.poz.x, y0 - 70 * s.u, E.outCubic(T(s, 0, 0.4)), "center");
    d.forEach((p, i) => {
      const e = E.outBack(T(s, 0.1 + i * 0.1, 0.45)); if (e <= 0) return; const x = x0 + (i % kol) * (tw + gap), y = y0 + Math.floor(i / kol) * (th + gap), v = p.v * E.outCubic(T(s, 0.3 + i * 0.1, 1.3)), wyr = /\*/.test(p.e);
      ctx.save(); ctx.translate(x + tw / 2, y + th / 2); ctx.scale(e, e); ctx.translate(-tw / 2, -th / 2); karta(s, 0, 0, tw, th, 24 * s.u, wyr ? s.k.g : rgba(s.k.tl, 0.92));
      ctx.font = font(s, th * 0.13, 600); ctx.fillStyle = wyr ? rgba(kontrast(s.k.g), 0.85) : rgba(s.k.t, 0.7); ctx.fillText(bezGw(p.e), tw * 0.1, th * 0.22);
      const t = (s.p.przed || "") + krotko(v) + (s.p.po || ""); ctx.font = font(s, dopasuj(s, t, th * 0.32, tw * 0.8, 900), 900); ctx.fillStyle = wyr ? kontrast(s.k.g) : s.k.t; ctx.fillText(t, tw * 0.1, th * 0.52);
      const sp = 7; ctx.strokeStyle = wyr ? kontrast(s.k.g) : s.k.a; ctx.lineWidth = 4 * s.u; ctx.lineJoin = "round"; const pk = []; for (let k = 0; k < sp; k++) pk.push([tw * 0.1 + k * tw * 0.8 / (sp - 1), th * 0.88 - (0.2 + 0.8 * (k / (sp - 1)) * (0.6 + 0.4 * los(i * 9 + k))) * th * 0.18]); sciezkaCzesc(ctx, pk, E.inOutCubic(T(s, 0.5 + i * 0.1, 0.8))); ctx.stroke();
      ctx.restore();
    });
  }, { pola: ["lista", "tekst", "przed", "po"], czas: 4 });
  liczbaN("liczby-pierscienie", "Pierścienie postępu (jak w zegarku)", { lista: "Ruch: 82\nTrening: 64\nSen: 91", po: "%" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista).slice(0, 4), R = 200 * s.u * s.p.rozmiar, gr = R * 0.17, pion = s.H > s.W, cx = pion ? s.poz.x : s.poz.x - R * 1.1, cy = pion ? s.poz.y - R * 0.45 : s.poz.y, kol = [s.k.g, s.k.a, "#60A5FA", "#34D399"], a = E.outBack(T(s, 0, 0.45));
    ctx.save(); ctx.translate(cx, cy); ctx.scale(a, a); ctx.lineCap = "round"; ctx.lineWidth = gr;
    d.forEach((p, i) => { const r = R - i * gr * 1.2, v = clamp(p.v / 100) * E.inOutCubic(T(s, 0.2 + i * 0.15, 1.3)); ctx.strokeStyle = rgba(kol[i], 0.2); ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.stroke(); if (v > 0) { ctx.strokeStyle = kol[i]; ctx.beginPath(); luk(ctx, 0, 0, r, -PI / 2, -PI / 2 + PI * 2 * v); ctx.stroke(); } });
    ctx.restore();
    const px = 46 * s.u * s.p.rozmiar, lx = pion ? s.poz.x - R : cx + R * 1.35, ly = pion ? cy + R * 1.35 : cy - (d.length - 1) * px * 0.9;
    d.forEach((p, i) => { const e = E.outCubic(T(s, 0.5 + i * 0.15, 0.4)); if (e <= 0) return; const y = ly + i * px * 1.8; ctx.save(); ctx.globalAlpha = s.alfa * e; cien(s); ctx.fillStyle = kol[i]; ctx.beginPath(); ctx.arc(lx + px * 0.35, y, px * 0.3, 0, PI * 2); ctx.fill();
      ctx.font = font(s, px * 0.8, 600); ctx.fillStyle = s.k.t; ctx.fillText(bezGw(p.e), lx + px, y); const t = Math.round(p.v * E.outCubic(T(s, 0.2 + i * 0.15, 1.3))) + (s.p.po || ""); ctx.font = font(s, px, 900); ctx.fillStyle = kol[i]; ctx.fillText(t, lx + (pion ? R * 2 - ctx.measureText(t).width : px * 6.5), y); ctx.restore(); });
  }, { pola: ["lista", "po"], czas: 4 });
  liczbaN("liczby-wskaznik", "Wskaźnik jak prędkościomierz", { liczba: 78, po: "%", tekst2: "zadowolenie klientów" }, (s) => {
    const ctx = s.ctx, r = 240 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y + r * 0.25, a = E.outBack(T(s, 0, 0.45)), max = +s.p.max || 100, e = T(s, 0.3, 1.4), v = clamp((+s.p.liczba || 0) / max) * (e < 1 ? E.outBack(e) : 1 + Math.sin(s.t * 9) * 0.003);
    ctx.save(); ctx.translate(cx, cy); ctx.scale(a, a); ctx.lineWidth = r * 0.16;
    const n = 40; for (let i = 0; i < n; i++) { const k0 = PI + i / n * PI, k1 = PI + (i + 0.92) / n * PI; ctx.strokeStyle = i / n <= v ? lerpKolor(s.k.a, s.k.g, i / n) : rgba(s.k.t, 0.15); ctx.beginPath(); ctx.arc(0, 0, r, k0, k1); ctx.stroke(); }
    for (let i = 0; i <= 10; i++) { const k = PI + i / 10 * PI; ctx.strokeStyle = rgba(s.k.t, 0.6); ctx.lineWidth = 3 * s.u; ctx.beginPath(); ctx.moveTo(Math.cos(k) * r * 0.74, Math.sin(k) * r * 0.74); ctx.lineTo(Math.cos(k) * r * (i % 5 ? 0.8 : 0.84), Math.sin(k) * r * (i % 5 ? 0.8 : 0.84)); ctx.stroke(); }
    const k = PI + v * PI; ctx.save(); ctx.rotate(k); cien(s); ctx.fillStyle = s.k.t; ctx.beginPath(); ctx.moveTo(r * 0.82, 0); ctx.lineTo(0, -r * 0.05); ctx.lineTo(-r * 0.12, 0); ctx.lineTo(0, r * 0.05); ctx.closePath(); ctx.fill(); ctx.restore();
    ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(0, 0, r * 0.09, 0, PI * 2); ctx.fill();
    const t = liczbaT(s, wartosc(s, clamp(E.outCubic(e)))); ctx.font = font(s, r * 0.36, 900); ctx.fillStyle = s.k.t; cien(s); ctx.fillText(t, -ctx.measureText(t).width / 2, r * 0.32); ctx.restore();
    podpis(s, cy + r * 0.62, E.outCubic(T(s, 0.6, 0.5)), 50, "tekst2");
  }, { pola: ["liczba", "po", "tekst2"], czas: 4 });
  liczbaN("liczby-tort", "Wykres kołowy z wysuniętym kawałkiem", { lista: "Instagram: 45\nTikTok: 30\nYouTube: 15\nInne: 10", tekst: "Skąd przychodzą klienci" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista).slice(0, 6), suma = d.reduce((a, p) => a + p.v, 0) || 1, r = 210 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y, kol = [s.k.g, s.k.a, "#60A5FA", "#A78BFA", "#34D399", "#F472B6"], naj = d.reduce((b, p, i) => (p.v > d[b].v ? i : b), 0);
    tytulWykresu(s, cx, cy - r * 1.75, E.outCubic(T(s, 0, 0.4)), "center");
    const e = E.inOutCubic(T(s, 0.2, 1.1)), wy = E.outBack(T(s, 1.3, 0.5)); let k0 = -PI / 2;
    d.forEach((p, i) => { const k1 = k0 + p.v / suma * PI * 2, kk = Math.min(k1, -PI / 2 + PI * 2 * e), km = (k0 + k1) / 2, o = i === naj ? wy * r * 0.12 : 0;
      if (kk > k0) { ctx.save(); ctx.translate(Math.cos(km) * o, Math.sin(km) * o); cien(s, ctx, 0.6); ctx.fillStyle = kol[i % kol.length]; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.arc(cx, cy, r, k0, kk); ctx.closePath(); ctx.fill(); bezCienia(ctx); ctx.strokeStyle = rgba(s.k.tl, 0.9); ctx.lineWidth = 3 * s.u; ctx.stroke(); ctx.restore(); }
      const l = E.outCubic(T(s, 1.1 + i * 0.12, 0.4)); if (l > 0) { const lx = cx + Math.cos(km) * r * 1.22, ly = cy + Math.sin(km) * r * 1.22, pr = Math.round(p.v / suma * 100) + "%", px = 40 * s.u * s.p.rozmiar; ctx.save(); ctx.globalAlpha = s.alfa * l; cien(s); ctx.font = font(s, px, 900); ctx.fillStyle = kol[i % kol.length]; const w1 = ctx.measureText(pr).width; ctx.font = font(s, px * 0.75, 600); const w2 = ctx.measureText(bezGw(p.e)).width, lewo = Math.cos(km) < -0.2, sr = Math.abs(Math.cos(km)) <= 0.2;
        const ax = sr ? lx - Math.max(w1, w2) / 2 : lewo ? lx - Math.max(w1, w2) : lx; ctx.font = font(s, px, 900); ctx.fillText(pr, ax, ly - px * 0.35); ctx.font = font(s, px * 0.75, 600); ctx.fillStyle = s.k.t; ctx.fillText(bezGw(p.e), ax, ly + px * 0.5); ctx.restore(); }
      k0 = k1; });
  }, { pola: ["lista", "tekst"], czas: 4 });
  liczbaN("liczby-obszar", "Wykres obszarowy z gradientem", { lista: "Pn: 12\nWt: 18\nŚr: 15\nCz: 26\nPt: 31\nSo: 44\nNd: 52", tekst: "Wyświetlenia (tys.)" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista), W = s.W * 0.8 * s.p.rozmiar, H = Math.min(s.H * 0.3, 480 * s.u) * s.p.rozmiar, x0 = s.poz.x - W / 2, y0 = s.poz.y + H / 2, max = Math.max(1, ...d.map((x) => x.v)) * 1.1, n = Math.max(2, d.length);
    const pk = d.map((p, i) => [x0 + W * i / (n - 1), y0 - H * p.v / max]), e = E.inOutCubic(T(s, 0.3, 1.4)), a = E.outCubic(T(s, 0, 0.4));
    tytulWykresu(s, x0, y0 - H - 70 * s.u, a);
    ctx.save(); ctx.globalAlpha = s.alfa * a; ctx.fillStyle = rgba(s.k.t, 0.15); for (let i = 0; i <= 3; i++) ctx.fillRect(x0, y0 - H * i / 3, W, 2 * s.u); ctx.restore();
    ctx.save(); ctx.beginPath(); ctx.rect(x0 - 20 * s.u, y0 - H * 1.2, (W + 40 * s.u) * e, H * 1.3); ctx.clip();
    const g = ctx.createLinearGradient(0, y0 - H, 0, y0); g.addColorStop(0, rgba(s.k.a, 0.65)); g.addColorStop(1, rgba(s.k.a, 0)); ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(x0, y0);
    pk.forEach((p, i) => { if (!i) { ctx.lineTo(...p); return; } const q = pk[i - 1], mx = (q[0] + p[0]) / 2; ctx.bezierCurveTo(mx, q[1], mx, p[1], p[0], p[1]); }); ctx.lineTo(x0 + W, y0); ctx.closePath(); ctx.fill();
    ctx.strokeStyle = s.k.a; ctx.lineWidth = 7 * s.u; ctx.lineJoin = "round"; ctx.beginPath(); pk.forEach((p, i) => { if (!i) { ctx.moveTo(...p); return; } const q = pk[i - 1], mx = (q[0] + p[0]) / 2; ctx.bezierCurveTo(mx, q[1], mx, p[1], p[0], p[1]); }); ctx.stroke(); ctx.restore();
    ctx.save(); ctx.globalAlpha = s.alfa * a; ctx.font = font(s, 32 * s.u * s.p.rozmiar, 600); ctx.fillStyle = rgba(s.k.t, 0.8); d.forEach((p, i) => { const t = bezGw(p.e); ctx.fillText(t, pk[i][0] - ctx.measureText(t).width / 2, y0 + 36 * s.u); }); ctx.restore();
    const ost = pk[pk.length - 1], b = E.outBack(T(s, 1.6, 0.4)); if (b > 0 && ost) { const t = liczbaT(s, d[d.length - 1].v), px = 44 * s.u * s.p.rozmiar; ctx.font = font(s, px, 900); const w = ctx.measureText(t).width + px; ctx.save(); ctx.translate(ost[0], ost[1] - px * 1.3); ctx.scale(b, b); karta(s, -w / 2, -px * 0.75, w, px * 1.5, px * 0.4, s.k.a); ctx.fillStyle = kontrast(s.k.a); ctx.fillText(t, -w / 2 + px * 0.5, 0); ctx.restore();
      ctx.fillStyle = "#FFFFFF"; ctx.beginPath(); ctx.arc(ost[0], ost[1], 12 * s.u * b, 0, PI * 2); ctx.fill(); ctx.strokeStyle = s.k.a; ctx.lineWidth = 5 * s.u; ctx.stroke(); }
  }, { pola: ["lista", "tekst", "przed", "po"], czas: 4 });
  liczbaN("liczby-swiece", "Wykres świecowy (giełda)", { tekst: "ETF World", liczba: 24, po: "+18,4%" }, (s) => {
    const ctx = s.ctx, n = Math.max(6, Math.min(60, Math.round(+s.p.liczba || 24))), W = s.W * 0.84 * s.p.rozmiar, H = Math.min(s.H * 0.32, 520 * s.u) * s.p.rozmiar, x0 = s.poz.x - W / 2, y0 = s.poz.y + H / 2, a = E.outCubic(T(s, 0, 0.4));
    const sw = [], krok = W / n; let c = 100; for (let i = 0; i < n; i++) { const o = c, ch = (los(i * 3.7) - 0.42) * 8 + i * 0.15; c = o + ch; const hi = Math.max(o, c) + los(i * 5.1) * 4, lo = Math.min(o, c) - los(i * 7.9) * 4; sw.push({ o, c, hi, lo }); }
    const mx = Math.max(...sw.map((q) => q.hi)), mn = Math.min(...sw.map((q) => q.lo)), Y = (v) => y0 - (v - mn) / (mx - mn) * H;
    ctx.save(); ctx.globalAlpha = s.alfa * a; ctx.fillStyle = rgba(s.k.t, 0.12); for (let i = 0; i <= 4; i++) ctx.fillRect(x0, y0 - H * i / 4, W, 2 * s.u); ctx.restore();
    if (s.p.tekst) { ctx.save(); ctx.globalAlpha = s.alfa * a; cien(s); ctx.font = font(s, 54 * s.u * s.p.rozmiar, 900); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), x0, y0 - H - 70 * s.u); ctx.restore(); }
    sw.forEach((q, i) => { const e = E.outBack(T(s, 0.2 + i * (1.3 / n), 0.3)); if (e <= 0) return; const x = x0 + krok * (i + 0.5), wzr = q.c >= q.o, kol = wzr ? zielony : czerwony, sr = (Y(q.o) + Y(q.c)) / 2;
      ctx.save(); ctx.translate(x, sr); ctx.scale(1, e); ctx.translate(-x, -sr); ctx.fillStyle = kol; ctx.fillRect(x - 1.5 * s.u, Y(q.hi), 3 * s.u, Y(q.lo) - Y(q.hi)); ctx.fillRect(x - krok * 0.32, Math.min(Y(q.o), Y(q.c)), krok * 0.64, Math.max(3 * s.u, Math.abs(Y(q.o) - Y(q.c)))); ctx.restore(); });
    const b = E.outBack(T(s, 1.6, 0.45)), ost = sw[sw.length - 1]; if (b > 0) { const t = String(s.p.po || ""), px = 46 * s.u * s.p.rozmiar; ctx.strokeStyle = rgba(zielony, 0.8); ctx.setLineDash([8 * s.u, 8 * s.u]); ctx.lineWidth = 2 * s.u; ctx.beginPath(); ctx.moveTo(x0, Y(ost.c)); ctx.lineTo(x0 + W, Y(ost.c)); ctx.stroke(); ctx.setLineDash([]);
      if (t) { ctx.font = font(s, px, 900); const w = ctx.measureText(t).width + px; ctx.save(); ctx.translate(x0 + W - w / 2, Y(ost.c) - px * 1.1); ctx.scale(b, b); karta(s, -w / 2, -px * 0.75, w, px * 1.5, px * 0.35, /^-/.test(t) ? czerwony : zielony); ctx.fillStyle = "#FFFFFF"; ctx.fillText(t, -w / 2 + px * 0.5, 0); ctx.restore(); } }
  }, { pola: ["tekst", "liczba", "po"], czas: 4 });
  liczbaN("liczby-zmiana", "Zmiana z jednej liczby na drugą", { od: 1200, liczba: 4800, po: " zł", tekst2: "miesięczny przychód z rolek" }, (s) => {
    const ctx = s.ctx, px = 150 * s.u * s.p.rozmiar, a = +s.p.od || 0, b = +s.p.liczba || 0, e1 = E.outCubic(T(s, 0, 0.4)), e2 = E.outBack(T(s, 0.45, 0.4)), e3 = E.outExpo(T(s, 0.6, 1.2)), pion = s.H > s.W;
    const t1 = `${s.p.przed || ""}${liczbaTekst(a, miejscaPo(s.p.od))}${s.p.po || ""}`, t2 = liczbaT(s, lerp(a, b, e3)), tk = liczbaT(s, b);
    const p1 = px * 0.45; ctx.font = font(s, p1, 700); const w1 = ctx.measureText(t1).width; const p2 = dopasuj(s, tk, px, s.W * (pion ? 0.86 : 0.5), 900); ctx.font = font(s, p2, 900); const w2 = ctx.measureText(tk).width;
    const y1 = pion ? s.poz.y - p2 * 0.95 : s.poz.y, x1 = pion ? s.poz.x - w1 / 2 : s.poz.x - (w1 + p2 + w2) / 2, x2 = pion ? s.poz.x - w2 / 2 : x1 + w1 + p2, y2 = pion ? s.poz.y + p2 * 0.25 : s.poz.y;
    ctx.save(); ctx.globalAlpha = s.alfa * e1; cien(s); ctx.font = font(s, p1, 700); ctx.fillStyle = rgba(s.k.t, 0.65); ctx.fillText(t1, x1, y1); bezCienia(ctx); const sk = E.inOutCubic(T(s, 0.4, 0.3)); ctx.strokeStyle = czerwony; ctx.lineWidth = 6 * s.u; ctx.beginPath(); ctx.moveTo(x1 - 6 * s.u, y1 + 4 * s.u); ctx.lineTo(x1 - 6 * s.u + (w1 + 12 * s.u) * sk, y1 - 4 * s.u); ctx.stroke(); ctx.restore();
    if (e2 > 0) { ctx.save(); const ax = pion ? s.poz.x : x1 + w1 + p2 * 0.5, ay = pion ? (y1 + y2) / 2 - p2 * 0.12 : y1; ctx.translate(ax, ay); ctx.scale(e2, e2); ctx.rotate(pion ? PI / 2 : 0); ctx.strokeStyle = s.k.a; ctx.lineWidth = p2 * 0.08; ctx.lineCap = "round"; ctx.lineJoin = "round"; const r = p2 * 0.22; ctx.beginPath(); ctx.moveTo(-r, 0); ctx.lineTo(r, 0); ctx.moveTo(r * 0.3, -r * 0.6); ctx.lineTo(r, 0); ctx.lineTo(r * 0.3, r * 0.6); ctx.stroke(); ctx.restore(); }
    if (e3 > 0) { ctx.save(); cien(s, ctx, 1.4); ctx.font = font(s, p2, 900); ctx.fillStyle = s.k.a; ctx.fillText(t2, x2, y2); ctx.restore(); }
    const zm = a ? Math.round((b - a) / Math.abs(a) * 100) : 0, bd = E.outBackMocno(T(s, 1.6, 0.4)); if (bd > 0 && a) { const t = (zm >= 0 ? "+" : "") + zm + "%", pb = p2 * 0.28; ctx.font = font(s, pb, 900); const w = ctx.measureText(t).width + pb; ctx.save(); ctx.translate(x2 + w2 - w / 2, y2 - p2 * 0.75); ctx.scale(bd, bd); ctx.rotate(0.06); karta(s, -w / 2, -pb * 0.75, w, pb * 1.5, pb * 0.4, zm >= 0 ? zielony : czerwony); ctx.fillStyle = "#FFFFFF"; ctx.fillText(t, -w / 2 + pb * 0.5, 0); ctx.restore(); }
    podpis(s, y2 + p2 * 0.8, E.outCubic(T(s, 0.9, 0.5)), 50, "tekst2");
  }, { pola: ["od", "liczba", "przed", "po", "tekst2"], czas: 4 });
  liczbaN("liczby-licznik-rolki", "Licznik mechaniczny (cyfry się kręcą)", { liczba: 25840, tekst2: "osób odwiedziło sklep" }, (s) => {
    const ctx = s.ctx, v = Math.round(Math.abs(+s.p.liczba || 0)), cyf = String(v).split(""), n = cyf.length, ch = 190 * s.u * s.p.rozmiar, cw = ch * 0.66, gap = 10 * s.u, W = n * cw + (n - 1) * gap, x0 = s.poz.x - W / 2, y0 = s.poz.y - ch / 2, a = E.outBack(T(s, 0, 0.45));
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.translate(-s.poz.x, -s.poz.y); karta(s, x0 - 20 * s.u, y0 - 20 * s.u, W + 40 * s.u, ch + 40 * s.u, 22 * s.u, "#111111");
    cyf.forEach((c, i) => { const x = x0 + i * (cw + gap), cel = +c + 10 * (n - i), e = E.outCubic(T(s, 0.2 + i * 0.1, 1.4 + (n - i) * 0.12)), poz = cel * e;
      ctx.save(); const g = ctx.createLinearGradient(0, y0, 0, y0 + ch); g.addColorStop(0, "#2A2A2A"); g.addColorStop(0.5, "#3A3A3A"); g.addColorStop(1, "#2A2A2A"); ctx.fillStyle = g; zaokr(ctx, x, y0, cw, ch, 10 * s.u); ctx.fill(); ctx.beginPath(); ctx.rect(x, y0, cw, ch); ctx.clip();
      ctx.font = font(s, ch * 0.66, 900); ctx.fillStyle = "#FFFFFF"; for (let k = Math.floor(poz) - 1; k <= Math.floor(poz) + 1; k++) { const t = String(((k % 10) + 10) % 10); ctx.fillText(t, x + cw / 2 - ctx.measureText(t).width / 2, s.poz.y - (poz - k) * ch * 0.95); }
      const sh = ctx.createLinearGradient(0, y0, 0, y0 + ch); sh.addColorStop(0, "rgba(0,0,0,0.6)"); sh.addColorStop(0.25, "rgba(0,0,0,0)"); sh.addColorStop(0.75, "rgba(0,0,0,0)"); sh.addColorStop(1, "rgba(0,0,0,0.6)"); ctx.fillStyle = sh; ctx.fillRect(x, y0, cw, ch); ctx.restore(); });
    ctx.fillStyle = "rgba(0,0,0,0.55)"; cyf.forEach((c, i) => ctx.fillRect(x0 + i * (cw + gap), s.poz.y - 1.5 * s.u, cw, 3 * s.u)); ctx.fillStyle = s.k.a; ctx.fillRect(x0 - 20 * s.u, y0 + ch + 20 * s.u - 6 * s.u, W + 40 * s.u, 6 * s.u); ctx.restore();
    podpis(s, y0 + ch + 70 * s.u, E.outCubic(T(s, 0.6, 0.5)), 50, "tekst2");
  }, { pola: ["liczba", "tekst2"], czas: 4 });
  liczbaN("liczby-metka", "Metka z ceną", { tekst: "149 zł", tekst2: "zamiast 199 zł", x: 0.62, y: 0.4 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), px = 92 * s.u * s.p.rozmiar; ctx.font = font(s, px, 900); const t = tekstP(s, s.p.tekst), tw = ctx.measureText(t).width, W = tw + px * 1.6, h = px * (s.p.tekst2 ? 2.4 : 1.8), sz = h * 0.5;
    const tt = s.t - 0.05, kat = -0.5 + 0.9 * (tt > 0 ? (1 - Math.exp(-tt * 2.2) * Math.cos(tt * 6)) : 0) * 0.5 + 0.06, a = E.outBack(T(s, 0, 0.4)), hx = cx - W / 2 - sz * 0.5, hy = cy;
    ctx.strokeStyle = "#D4C4A8"; ctx.lineWidth = 4 * s.u; ctx.beginPath(); ctx.moveTo(hx, hy); ctx.quadraticCurveTo(hx - 80 * s.u, hy - 120 * s.u, hx - 40 * s.u, hy - 240 * s.u); ctx.stroke();
    ctx.save(); ctx.translate(hx, hy); ctx.rotate(kat); ctx.scale(a, a); cien(s); ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(sz, -h / 2); ctx.lineTo(sz + W, -h / 2); ctx.lineTo(sz + W, h / 2); ctx.lineTo(sz, h / 2); ctx.closePath(); ctx.lineJoin = "round"; ctx.fill(); bezCienia(ctx);
    ctx.fillStyle = s.k.tl; ctx.beginPath(); ctx.arc(sz * 0.62, 0, h * 0.08, 0, PI * 2); ctx.fill(); ctx.strokeStyle = rgba(kontrast(s.k.a), 0.35); ctx.setLineDash([8 * s.u, 6 * s.u]); ctx.lineWidth = 2.5 * s.u; ctx.strokeRect(sz + px * 0.25, -h / 2 + px * 0.2, W - px * 0.45, h - px * 0.4); ctx.setLineDash([]);
    ctx.font = font(s, px, 900); ctx.fillStyle = kontrast(s.k.a); ctx.fillText(t, sz + (W - tw) / 2, s.p.tekst2 ? -h * 0.12 : 0);
    if (s.p.tekst2) { ctx.font = font(s, px * 0.34, 700); const w2 = ctx.measureText(s.p.tekst2).width, xx = sz + (W - w2) / 2, yy = h * 0.27; ctx.fillStyle = rgba(kontrast(s.k.a), 0.8); ctx.fillText(s.p.tekst2, xx, yy); ctx.fillRect(xx, yy, w2, 3 * s.u); }
    ctx.restore();
  }, { pola: ["tekst", "tekst2", "xy"], czas: 3.5 });
  liczbaN("liczby-kamienie-milowe", "Kamienie milowe (pionowa oś)", { lista: "2019: Pierwsza kamera\n2021: Własne studio\n2023: 100 klientów\n*2026*: Nada Studio" }, (s) => {
    const ctx = s.ctx, d = lista(s.p.lista).map((x) => { const i = x.indexOf(":"); return i > 0 ? [x.slice(0, i).trim(), x.slice(i + 1).trim()] : [x, ""]; }), n = Math.max(1, d.length), px = 48 * s.u * s.p.rozmiar, lh = Math.min(px * 3.6, s.H * 0.7 / n), H = lh * (n - 1), x = s.poz.align === "center" ? s.W * 0.32 : s.poz.x + px * 2.4, y0 = s.poz.y - H / 2;
    const krok = Math.max(0.35, (s.T - s.p.wyjscie - 0.8) / n), l = clamp((s.t - 0.1) / (krok * (n - 1) + 0.3)); ctx.fillStyle = rgba(s.k.t, 0.2); ctx.fillRect(x - 3 * s.u, y0, 6 * s.u, H); ctx.fillStyle = s.k.a; ctx.fillRect(x - 3 * s.u, y0, 6 * s.u, H * E.inOutCubic(l));
    d.forEach(([rok, opis], i) => { const e = E.outBackMocno(T(s, 0.1 + i * krok, 0.4)); if (e <= 0) return; const y = y0 + i * lh, wyr = /\*/.test(rok), r = bezGw(rok);
      ctx.save(); ctx.translate(x, y); ctx.scale(e, e); ctx.fillStyle = wyr ? s.k.a : s.k.g; ctx.beginPath(); ctx.arc(0, 0, px * 0.42, 0, PI * 2); ctx.fill(); ctx.strokeStyle = "#FFFFFF"; ctx.lineWidth = 4 * s.u; ctx.stroke(); ctx.restore();
      ctx.save(); ctx.globalAlpha = s.alfa * clamp(e); cien(s); ctx.font = font(s, px * 1.05, 900); ctx.fillStyle = wyr ? s.k.a : s.k.t; const rw = ctx.measureText(r).width; ctx.fillText(r, x - px * 0.9 - rw - (1 - e) * 30 * s.u, y);
      ctx.font = font(s, px * 0.8, 600); ctx.fillStyle = s.k.t; ctx.fillText(opis, x + px * 0.9 + (1 - e) * 30 * s.u, y); ctx.restore(); });
  }, { pola: ["lista"], dom: { pozycja: "srodek" }, czas: 5 });
  liczbaN("liczby-siatka-100", "Siatka 100 kropek (procent)", { liczba: 68, po: "%", tekst2: "widzów ogląda bez dźwięku" }, (s) => {
    const ctx = s.ctx, v = Math.round(clamp((+s.p.liczba || 0) / 100) * 100), k = 52 * s.u * s.p.rozmiar, W = k * 10, x0 = s.poz.x - W / 2, y0 = s.poz.y - W / 2 + k * 0.4, e = clamp((s.t - 0.4) / 1.4), ile = Math.round(v * E.inOutCubic(e));
    for (let i = 0; i < 100; i++) { const r = i % 10, c = Math.floor(i / 10), we = E.outBack(T(s, (r + c) * 0.02, 0.35)); if (we <= 0) continue; const on = i < ile; ctx.fillStyle = on ? s.k.a : rgba(s.k.t, 0.2); ctx.beginPath(); ctx.arc(x0 + c * k + k / 2, y0 + r * k + k / 2, k * 0.36 * we * (on && i === ile - 1 ? 1.25 : 1), 0, PI * 2); ctx.fill(); }
    const t = ile + (s.p.po || "%"); ctx.save(); ctx.globalAlpha = s.alfa * E.outCubic(T(s, 0.2, 0.4)); cien(s); ctx.font = font(s, k * 2.4, 900); ctx.fillStyle = s.k.t; ctx.fillText(t, s.poz.x - ctx.measureText(v + (s.p.po || "%")).width / 2, y0 - k * 1.6); ctx.restore();
    podpis(s, y0 + W + k * 0.6, E.outCubic(T(s, 0.6, 0.5)), 50, "tekst2");
  }, { pola: ["liczba", "po", "tekst2"], czas: 4 });
  liczbaN("liczby-termometr", "Termometr wypełnia się", { liczba: 85, po: "%", tekst2: "gorący temat!" }, (s) => {
    const ctx = s.ctx, h = 560 * s.u * s.p.rozmiar, w = h * 0.13, br = w * 1.15, cx = s.poz.x - w * 2, top = s.poz.y - h / 2 - br * 0.5, dol = top + h, v = clamp((+s.p.liczba || 0) / (+s.p.max || 100)) * E.inOutCubic(T(s, 0.3, 1.4)), a = E.outBack(T(s, 0, 0.4));
    ctx.save(); ctx.translate(cx, s.poz.y); ctx.scale(a, a); ctx.translate(-cx, -s.poz.y); karta(s, cx - w / 2 - 8 * s.u, top - 8 * s.u, w + 16 * s.u, h, w / 2 + 8 * s.u, "#FFFFFF"); ctx.fillStyle = "#FFFFFF"; ctx.beginPath(); ctx.arc(cx, dol, br + 8 * s.u, 0, PI * 2); ctx.fill();
    const kol = lerpKolor(s.k.a, s.k.g, v), lh = (h - br) * v; ctx.fillStyle = kol; ctx.beginPath(); ctx.arc(cx, dol, br, 0, PI * 2); ctx.fill(); zaokr(ctx, cx - w * 0.32, dol - br * 0.5 - lh, w * 0.64, lh + br * 0.5, w * 0.32); ctx.fill();
    for (let i = 0; i <= 10; i++) { const y = dol - br - (h - br * 1.5) * i / 10; ctx.fillStyle = "#9CA3AF"; ctx.fillRect(cx + w / 2 + 14 * s.u, y - 1.5 * s.u, i % 5 ? 18 * s.u : 34 * s.u, 3 * s.u); }
    ctx.restore(); const t = Math.round(v * (+s.p.max || 100)) + (s.p.po || ""); ctx.save(); ctx.globalAlpha = s.alfa * a; cien(s); ctx.font = font(s, 130 * s.u * s.p.rozmiar, 900); ctx.fillStyle = s.k.t; ctx.fillText(t, cx + w * 2.4, dol - br - (h - br * 1.5) * v); ctx.restore();
    if (s.p.tekst2) { const e = E.outCubic(T(s, 1.5, 0.5)); ctx.save(); ctx.globalAlpha = s.alfa * e; cien(s); ctx.font = font(s, 50 * s.u * s.p.rozmiar, 700); ctx.fillStyle = s.k.a; ctx.fillText(s.p.tekst2, cx + w * 2.4, dol - br - (h - br * 1.5) * v + 100 * s.u * s.p.rozmiar); ctx.restore(); }
  }, { pola: ["liczba", "po", "tekst2"], czas: 4 });
  liczbaN("liczby-wyscig", "Wyścig słupków (ranking się zmienia)", { lista: "TikTok: 10/35/70/120\nInstagram: 40/60/80/95\nYouTube: 30/45/55/70\nFacebook: 50/52/50/48", tekst: "Zasięgi w 2026 (tys.)" }, (s) => {
    const ctx = s.ctx, d = lista(s.p.lista).map((x) => { const i = x.indexOf(":"); return { e: i > 0 ? x.slice(0, i).trim() : x, v: (i > 0 ? x.slice(i + 1) : "0").split("/").map((y) => parseFloat(y.replace(",", ".")) || 0) }; }).slice(0, 8), n = d.length || 1;
    const kroki = Math.max(...d.map((x) => x.v.length)), p = clamp((s.t - 0.3) / Math.max(0.5, s.T - s.p.wyjscie - 0.8)) * (kroki - 1), wart = (x) => { const i = Math.min(x.v.length - 1, Math.floor(p)), j = Math.min(x.v.length - 1, i + 1), f = E.inOutCubic(p - Math.floor(p)); return lerp(x.v[i], x.v[j], f); };
    const v = d.map(wart), max = Math.max(1, ...v), kol = [s.k.g, s.k.a, "#60A5FA", "#A78BFA", "#34D399", "#F472B6", "#FBBF24", "#94A3B8"], W = s.W * 0.66 * s.p.rozmiar, bh = 60 * s.u * s.p.rozmiar, lh = bh * 1.5, x0 = s.poz.x - W / 2 + 40 * s.u, y0 = s.poz.y - (n - 1) * lh / 2;
    const rank = v.map((x, i) => [x, i]).sort((a, b) => b[0] - a[0]), poz = new Array(n); rank.forEach(([, i], r) => (poz[i] = r));
    tytulWykresu(s, s.poz.x, y0 - lh * 1.1, E.outCubic(T(s, 0, 0.4)), "center");
    d.forEach((x, i) => { const e = E.outCubic(T(s, i * 0.08, 0.45)); if (e <= 0) return; const rr = poz[i], y = y0 + rr * lh, bw = Math.max(bh * 0.4, W * v[i] / max) * e;
      ctx.save(); ctx.globalAlpha = s.alfa * e; ctx.fillStyle = kol[i % kol.length]; zaokr(ctx, x0, y - bh / 2, bw, bh, bh * 0.2); ctx.fill();
      ctx.font = font(s, bh * 0.48, 800); ctx.fillStyle = s.k.t; cien(s); const et = bezGw(x.e), ew = ctx.measureText(et).width; ctx.fillText(et, x0 - ew - 20 * s.u, y); ctx.fillText(liczbaTekst(Math.round(v[i])), x0 + bw + 18 * s.u, y); ctx.restore(); });
  }, { pola: ["lista", "tekst"], czas: 6 });
  liczbaN("liczby-aktywnosc", "Siatka aktywności (jak na GitHubie)", { tekst: "365 dni montażu", liczba: 26 }, (s) => {
    const ctx = s.ctx, tyg = Math.max(8, Math.min(53, Math.round(+s.p.liczba || 26))), k = Math.min(s.W * 0.88 / tyg, 34 * s.u * s.p.rozmiar), gap = k * 0.18, W = tyg * k, H = 7 * k, x0 = s.poz.x - W / 2, y0 = s.poz.y - H / 2;
    tytulWykresu(s, x0, y0 - 60 * s.u, E.outCubic(T(s, 0, 0.4)));
    for (let c = 0; c < tyg; c++) for (let r = 0; r < 7; r++) { const e = T(s, 0.2 + (c + r) * 0.02, 0.3); if (e <= 0) continue; const v = Math.pow(los(c * 7.3 + r * 3.1), 1.6) * (0.4 + 0.6 * c / tyg), lv = Math.floor(v * 4.99); ctx.fillStyle = lv === 0 ? rgba(s.k.t, 0.12) : rgba(s.k.a, 0.25 + lv * 0.19);
      const q = (k - gap) * E.outBack(e); zaokr(ctx, x0 + c * k + (k - q) / 2, y0 + r * k + (k - q) / 2, q, q, q * 0.2); ctx.fill(); }
    const e = E.outCubic(T(s, 1.0, 0.4)); if (e > 0) { ctx.save(); ctx.globalAlpha = s.alfa * e; ctx.font = font(s, k * 0.7, 600); ctx.fillStyle = rgba(s.k.t, 0.75); const lx = x0 + W - k * 7.5; ctx.fillText("mniej", lx - ctx.measureText("mniej").width - k * 0.4, y0 + H + k * 1.1); for (let i = 0; i < 5; i++) { ctx.fillStyle = i ? rgba(s.k.a, 0.25 + i * 0.19) : rgba(s.k.t, 0.12); zaokr(ctx, lx + i * k, y0 + H + k * 0.7, k - gap, k - gap, (k - gap) * 0.2); ctx.fill(); } ctx.fillStyle = rgba(s.k.t, 0.75); ctx.fillText("więcej", lx + 5 * k + k * 0.3, y0 + H + k * 1.1); ctx.restore(); }
  }, { pola: ["tekst", "liczba"], czas: 4 });
  liczbaN("liczby-lejek", "Lejek sprzedaży", { lista: "Wyświetlenia: 48000\nKliknięcia: 6200\nKoszyk: 890\n*Zakupy*: 312" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista).slice(0, 6), n = Math.max(1, d.length), W = Math.min(s.W * 0.86, 900 * s.u) * s.p.rozmiar, sh = Math.min(140 * s.u * s.p.rozmiar, s.H * 0.6 / n), gap = 10 * s.u, H = n * (sh + gap), y0 = s.poz.y - H / 2, kol = [s.k.g, lerpKolor(s.k.g, s.k.a, 0.33), lerpKolor(s.k.g, s.k.a, 0.66), s.k.a, "#60A5FA", "#A78BFA"];
    d.forEach((p, i) => { const e = E.outQuint(T(s, 0.1 + i * 0.2, 0.6)); if (e <= 0) return; const y = y0 + i * (sh + gap), wg = W * (1 - i / n * 0.62), wd = W * (1 - (i + 1) / n * 0.62);
      ctx.save(); ctx.translate(s.poz.x, y + sh / 2); ctx.scale(e, 1); cien(s, ctx, 0.6); ctx.fillStyle = kol[i % kol.length]; ctx.beginPath(); ctx.moveTo(-wg / 2, -sh / 2); ctx.lineTo(wg / 2, -sh / 2); ctx.lineTo(wd / 2, sh / 2); ctx.lineTo(-wd / 2, sh / 2); ctx.closePath(); ctx.fill(); ctx.restore();
      const t = E.outCubic(T(s, 0.35 + i * 0.2, 0.4)); if (t <= 0) return; ctx.save(); ctx.globalAlpha = s.alfa * t; const kt = kontrast(kol[i % kol.length]), px = sh * 0.3; ctx.font = font(s, px, 600); ctx.fillStyle = kt; const et = bezGw(p.e); ctx.fillText(et, s.poz.x - wd / 2 + px * 0.5, y + sh / 2);
      const vt = krotko(p.v * E.outCubic(T(s, 0.35 + i * 0.2, 1))); ctx.font = font(s, px * 1.3, 900); ctx.fillText(vt, s.poz.x + wd / 2 - px * 0.5 - ctx.measureText(vt).width, y + sh / 2);
      if (i > 0 && d[i - 1].v) { const pr = Math.round(p.v / d[i - 1].v * 1000) / 10 + "%"; ctx.font = font(s, px * 0.7, 700); ctx.fillStyle = s.k.t; cien(s); const tx = s.poz.x + W / 2 - W * 0.05 + 10 * s.u; ctx.beginPath(); ctx.moveTo(tx, y - gap / 2 - px * 0.25); ctx.lineTo(tx + px * 0.5, y - gap / 2 - px * 0.25); ctx.lineTo(tx + px * 0.25, y - gap / 2 + px * 0.2); ctx.closePath(); ctx.fill(); ctx.fillText(liczbaTekst(parseFloat(pr), 1).replace(",0", "") + "%", tx + px * 0.7, y - gap / 2); } ctx.restore(); });
  }, { pola: ["lista"], czas: 4.5 });
  liczbaN("liczby-radar", "Wykres radarowy (umiejętności)", { lista: "Montaż: 95\nKolor: 80\nDźwięk: 70\nGrafika: 85\nAnimacja: 75\nScenariusz: 60" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista).slice(0, 10), n = Math.max(3, d.length), R = 230 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y, a = E.outCubic(T(s, 0, 0.5)), e = E.outBack(T(s, 0.4, 0.9)), max = Math.max(100, ...d.map((x) => x.v)), pk = (i, r) => [cx + Math.cos(-PI / 2 + i / n * PI * 2) * r, cy + Math.sin(-PI / 2 + i / n * PI * 2) * r];
    ctx.save(); ctx.globalAlpha = s.alfa * a; ctx.strokeStyle = rgba(s.k.t, 0.2); ctx.lineWidth = 2 * s.u; for (let k = 1; k <= 4; k++) { ctx.beginPath(); for (let i = 0; i <= n; i++) { const p = pk(i % n, R * k / 4); i ? ctx.lineTo(...p) : ctx.moveTo(...p); } ctx.stroke(); } for (let i = 0; i < n; i++) { ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(...pk(i, R)); ctx.stroke(); } ctx.restore();
    if (e > 0) { ctx.beginPath(); d.forEach((p, i) => { const q = pk(i, R * p.v / max * e); i ? ctx.lineTo(...q) : ctx.moveTo(...q); }); ctx.closePath(); ctx.fillStyle = rgba(s.k.a, 0.35); ctx.fill(); ctx.strokeStyle = s.k.a; ctx.lineWidth = 6 * s.u; ctx.lineJoin = "round"; ctx.stroke(); d.forEach((p, i) => { const q = pk(i, R * p.v / max * e); ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(q[0], q[1], 9 * s.u, 0, PI * 2); ctx.fill(); }); }
    d.forEach((p, i) => { const l = E.outCubic(T(s, 0.5 + i * 0.08, 0.4)); if (l <= 0) return; const [x, y] = pk(i, R * 1.18), px = 36 * s.u * s.p.rozmiar, k = Math.cos(-PI / 2 + i / n * PI * 2); ctx.save(); ctx.globalAlpha = s.alfa * l; cien(s); ctx.font = font(s, px, 700); ctx.fillStyle = s.k.t; const t = bezGw(p.e), w = ctx.measureText(t).width; ctx.fillText(t, Math.abs(k) < 0.2 ? x - w / 2 : k < 0 ? x - w : x, y); ctx.restore(); });
  }, { pola: ["lista"], czas: 4 });
  liczbaN("liczby-podzial-paska", "Podział na jednym pasku (procenty)", { lista: "Kobiety: 62\nMężczyźni: 35\nInne: 3", tekst: "Kto ogląda kanał" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista).slice(0, 6), suma = d.reduce((a, p) => a + p.v, 0) || 1, W = s.W * 0.84 * s.p.rozmiar, h = 70 * s.u * s.p.rozmiar, x0 = s.poz.x - W / 2, y = s.poz.y, kol = [s.k.g, s.k.a, "#60A5FA", "#A78BFA", "#34D399", "#F472B6"], e = E.inOutCubic(T(s, 0.2, 1.1));
    tytulWykresu(s, x0, y - h * 2.3, E.outCubic(T(s, 0, 0.4)));
    ctx.save(); zaokr(ctx, x0, y - h / 2, W, h, h / 2); ctx.clip(); ctx.fillStyle = rgba(s.k.t, 0.15); ctx.fillRect(x0, y - h / 2, W, h); let x = x0;
    d.forEach((p, i) => { const w = W * p.v / suma; ctx.fillStyle = kol[i % kol.length]; ctx.fillRect(x, y - h / 2, Math.min(w, Math.max(0, x0 + W * e - x)), h); if (i) { ctx.fillStyle = rgba(s.k.tl, 0.9); ctx.fillRect(x - 2 * s.u, y - h / 2, 4 * s.u, h); } x += w; }); ctx.restore();
    x = x0; d.forEach((p, i) => { const w = W * p.v / suma, l = E.outBack(T(s, 0.8 + i * 0.15, 0.4)), pr = Math.round(p.v / suma * 100) + "%", px = 44 * s.u * s.p.rozmiar; if (l > 0) { ctx.save(); ctx.globalAlpha = s.alfa * clamp(l); cien(s); const mx = x + w / 2, gora = i % 2 === 0, ly = gora ? y - h * 0.95 : y + h * 0.95;
      ctx.font = font(s, px, 900); ctx.fillStyle = kol[i % kol.length]; const tw = ctx.measureText(pr).width; const lx = clamp(mx - tw / 2, x0, x0 + W - tw); ctx.fillText(pr, lx, ly + (gora ? -px * 0.1 : px * 0.1)); ctx.font = font(s, px * 0.65, 600); ctx.fillStyle = s.k.t; const et = bezGw(p.e), ew = ctx.measureText(et).width; ctx.fillText(et, clamp(mx - ew / 2, x0, x0 + W - ew), ly + (gora ? -px * 0.95 : px * 0.95)); ctx.restore(); } x += w; });
  }, { pola: ["lista", "tekst"], czas: 4 });
  liczbaN("liczby-kula-procent", "Kula wypełnia się płynem (procent)", { liczba: 72, po: "%", tekst2: "budżetu wydane na reklamy" }, (s) => {
    const ctx = s.ctx, r = 200 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y - r * 0.15, a = E.outBack(T(s, 0, 0.45)), v = clamp((+s.p.liczba || 0) / (+s.p.max || 100)) * E.inOutCubic(T(s, 0.3, 1.5)), poz = cy + r - 2 * r * v;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(a, a); ctx.translate(-cx, -cy); ctx.fillStyle = rgba(s.k.tl, 0.85); ctx.beginPath(); ctx.arc(cx, cy, r, 0, PI * 2); ctx.fill();
    ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, r * 0.94, 0, PI * 2); ctx.clip(); [[0.55, 1.3, -1], [1, 1, 1]].forEach(([op, sk, kier], j) => { ctx.fillStyle = rgba(j ? s.k.g : s.k.a, op); ctx.beginPath(); ctx.moveTo(cx - r, cy + r); for (let x = -r; x <= r; x += 8 * s.u) ctx.lineTo(cx + x, poz + Math.sin(x / r * PI * sk + s.t * 4 * kier) * r * 0.05); ctx.lineTo(cx + r, cy + r); ctx.closePath(); ctx.fill(); });
    const t = Math.round(v * (+s.p.max || 100)) + (s.p.po || ""); ctx.font = font(s, r * 0.5, 900); const tw = ctx.measureText(t).width; ctx.fillStyle = s.k.t; ctx.fillText(t, cx - tw / 2, cy); ctx.restore();
    ctx.strokeStyle = s.k.t; ctx.lineWidth = r * 0.04; ctx.beginPath(); ctx.arc(cx, cy, r, 0, PI * 2); ctx.stroke(); ctx.strokeStyle = "rgba(255,255,255,0.5)"; ctx.lineWidth = r * 0.05; ctx.lineCap = "round"; ctx.beginPath(); ctx.arc(cx, cy, r * 0.8, PI * 1.15, PI * 1.4); ctx.stroke(); ctx.restore();
    podpis(s, cy + r * 1.25, E.outCubic(T(s, 0.6, 0.5)), 50, "tekst2");
  }, { pola: ["liczba", "po", "tekst2"], czas: 4 });
  liczbaN("liczby-notowania", "Pasek notowań giełdowych", { lista: "WIG20: 2 456,10: +1,2\nS&P 500: 6 120,4: +0,8\nEUR/PLN: 4,27: -0,3\nZŁOTO: 2 715: +2,1\nBTC: 98 400: -1,5" }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista).map((x) => { const c = x.split(/:\s*/); return { n: c[0] || "", v: c[1] || "", z: c[2] || "" }; }), px = 40 * s.u * s.p.rozmiar, h = px * 2, y0 = s.poz.y - h / 2, e = E.outQuint(T(s, 0, 0.5));
    ctx.save(); ctx.beginPath(); ctx.rect(0, y0, s.W * e, h); ctx.clip(); ctx.fillStyle = rgba(s.k.tl, 0.95); ctx.fillRect(0, y0, s.W, h); ctx.fillStyle = s.k.a; ctx.fillRect(0, y0, s.W, 4 * s.u);
    const szer = el.map((q) => { ctx.font = font(s, px, 800); const a = ctx.measureText(q.n).width; ctx.font = font(s, px, 600); const b = ctx.measureText(q.v).width; ctx.font = font(s, px * 0.85, 800); const c = ctx.measureText(q.z + "%").width; return a + b + c + px * 4; }), suma = szer.reduce((a, b) => a + b, 0) || 1, off = (s.t * 140 * s.u) % suma;
    for (let x = -off; x < s.W; x += suma) { let xx = x; el.forEach((q, i) => { if (xx + szer[i] > 0 && xx < s.W) { const up = !/^-/.test(q.z), kol = up ? zielony : czerwony; ctx.font = font(s, px, 800); ctx.fillStyle = s.k.t; ctx.fillText(q.n, xx, s.poz.y); let p = xx + ctx.measureText(q.n).width + px * 0.5; ctx.font = font(s, px, 600); ctx.fillStyle = rgba(s.k.t, 0.85); ctx.fillText(q.v, p, s.poz.y); p += ctx.measureText(q.v).width + px * 0.5;
      ctx.fillStyle = kol; ctx.beginPath(); if (up) { ctx.moveTo(p, s.poz.y + px * 0.25); ctx.lineTo(p + px * 0.5, s.poz.y + px * 0.25); ctx.lineTo(p + px * 0.25, s.poz.y - px * 0.25); } else { ctx.moveTo(p, s.poz.y - px * 0.25); ctx.lineTo(p + px * 0.5, s.poz.y - px * 0.25); ctx.lineTo(p + px * 0.25, s.poz.y + px * 0.25); } ctx.closePath(); ctx.fill(); ctx.font = font(s, px * 0.85, 800); ctx.fillText((up && !/^\+/.test(q.z) ? "+" : "") + q.z + "%", p + px * 0.7, s.poz.y);
      ctx.fillStyle = rgba(s.k.t, 0.25); ctx.fillRect(xx + szer[i] - px * 1.2, y0 + h * 0.3, 2 * s.u, h * 0.4); } xx += szer[i]; }); }
    ctx.restore();
  }, { pola: ["lista"], dom: { pozycja: "dol" }, czas: 6 });
  liczbaN("liczby-tabela-porownawcza", "Tabela porównawcza (tak / nie)", { tekst: "My", tekst2: "Inni", lista: "Montaż w 24 h: tak/nie\nNapisy w cenie: tak/nie\nMuzyka z licencją: tak/tak\nPoprawki bez limitu: tak/nie" }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista).map((x) => { const i = x.lastIndexOf(":"); const w = (i > 0 ? x.slice(i + 1) : "").split("/").map((y) => /tak|yes|✓|\+|1/i.test(y)); return { e: i > 0 ? x.slice(0, i).trim() : x, a: w[0], b: w[1] }; }), cw = szerKarty(s, 900), px = 44 * s.u * s.p.rozmiar, rh = px * 1.9, kw = cw * 0.2, h = rh * (el.length + 1), x0 = s.poz.x - cw / 2, y0 = s.poz.y - h / 2, a = E.outBack(T(s, 0, 0.45));
    ctx.save(); wejscieKarty(s, s.poz.x, s.poz.y, a); karta(s, x0, y0, cw, h, 24 * s.u, rgba(s.k.tl, 0.95)); const ka = x0 + cw - kw * 2, kb = x0 + cw - kw;
    ctx.fillStyle = rgba(s.k.g, 0.25); ctx.fillRect(ka, y0, kw, h); ctx.fillStyle = s.k.g; ctx.fillRect(ka, y0, kw, rh);
    ctx.font = font(s, px * 0.85, 900); [[s.p.tekst, ka, kontrast(s.k.g)], [s.p.tekst2, kb, rgba(s.k.t, 0.7)]].forEach(([t, x, k]) => { const tt = tekstP(s, t || ""); ctx.fillStyle = k; ctx.fillText(tt, x + kw / 2 - ctx.measureText(tt).width / 2, y0 + rh / 2); });
    el.forEach((r, i) => { const y = y0 + rh * (i + 1), e = E.outCubic(T(s, 0.35 + i * 0.25, 0.4)); if (e <= 0) return; ctx.fillStyle = rgba(s.k.t, 0.1); ctx.fillRect(x0 + 20 * s.u, y, cw - 40 * s.u, 2 * s.u);
      ctx.save(); ctx.globalAlpha *= e; linia(s, r.e, x0 + px * 0.7, y + rh / 2, px * 0.8, 600); ctx.restore();
      [[r.a, ka], [r.b, kb]].forEach(([ok, x], j) => { const p = E.outBackMocno(T(s, 0.45 + i * 0.25 + j * 0.1, 0.35)); if (p <= 0) return; const ix = x + kw / 2, iy = y + rh / 2, rr = rh * 0.26; ctx.save(); ctx.translate(ix, iy); ctx.scale(p, p); ctx.fillStyle = ok ? zielony : rgba(czerwony, 0.9); ctx.beginPath(); ctx.arc(0, 0, rr, 0, PI * 2); ctx.fill(); if (ok) ptaszek(ctx, 0, 0, rr * 0.55, 1, "#FFFFFF", rr * 0.2); else krzyzyk(ctx, 0, 0, rr * 0.4, 1, "#FFFFFF", rr * 0.2); ctx.restore(); }); });
    ctx.restore();
  }, { pola: ["tekst", "tekst2", "lista"], czas: 4.5 });
  liczbaN("liczby-karta-kpi", "Karta wyniku z mini wykresem", { liczba: 18420, tekst2: "Przychód w tym miesiącu", po: " zł", lista: "9; 11; 10; 13; 12; 15; 18" }, (s) => {
    const ctx = s.ctx, cw = szerKarty(s, 760), h = cw * 0.55, x0 = s.poz.x - cw / 2, y0 = s.poz.y - h / 2, pad = cw * 0.07, a = E.outBack(T(s, 0, 0.45)), dane = lista(s.p.lista).map((x) => parseFloat(x.replace(",", ".")) || 0);
    ctx.save(); wejscieKarty(s, s.poz.x, s.poz.y, a); karta(s, x0, y0, cw, h, 30 * s.u, "#FFFFFF");
    ctx.font = font(s, cw * 0.045, 600); ctx.fillStyle = "#6B7280"; ctx.fillText(s.p.tekst2 || "", x0 + pad, y0 + pad + cw * 0.02);
    const t = liczbaT(s, wartosc(s, E.outExpo(T(s, 0.2, 1.4)))); ctx.font = font(s, dopasuj(s, t, cw * 0.13, cw * 0.62, 900), 900); ctx.fillStyle = "#111111"; ctx.fillText(t, x0 + pad, y0 + pad + cw * 0.12);
    if (dane.length > 1) { const zm = dane[0] ? Math.round((dane[dane.length - 1] - dane[0]) / Math.abs(dane[0]) * 100) : 0, bt = (zm >= 0 ? "+" : "") + zm + "%", b = E.outBackMocno(T(s, 1.2, 0.4)); if (b > 0) { ctx.font = font(s, cw * 0.04, 800); const bw = ctx.measureText(bt).width + cw * 0.07; ctx.save(); ctx.translate(x0 + cw - pad - bw / 2, y0 + pad + cw * 0.02); ctx.scale(b, b); ctx.fillStyle = rgba(zm >= 0 ? zielony : czerwony, 0.15); zaokr(ctx, -bw / 2, -cw * 0.035, bw, cw * 0.07, cw * 0.035); ctx.fill(); ctx.fillStyle = zm >= 0 ? "#15803D" : "#B91C1C"; ctx.fillText(bt, -bw / 2 + cw * 0.045, 0); const q = cw * 0.012, tx = -bw / 2 + cw * 0.022; ctx.beginPath(); if (zm >= 0) { ctx.moveTo(tx - q, q * 0.8); ctx.lineTo(tx + q, q * 0.8); ctx.lineTo(tx, -q); } else { ctx.moveTo(tx - q, -q * 0.8); ctx.lineTo(tx + q, -q * 0.8); ctx.lineTo(tx, q); } ctx.closePath(); ctx.fill(); ctx.restore(); } }
    const mn = Math.min(...dane), mx = Math.max(...dane), gx = x0 + pad, gw = cw - pad * 2, gy = y0 + h - pad, gh = h * 0.32, pk = dane.map((v, i) => [gx + gw * i / Math.max(1, dane.length - 1), gy - (mx > mn ? (v - mn) / (mx - mn) : 0.5) * gh]), e = E.inOutCubic(T(s, 0.5, 1.2));
    if (pk.length > 1) { ctx.save(); ctx.beginPath(); ctx.rect(gx - 10, gy - gh - 20, gw * e + 20, gh + 30); ctx.clip(); const g = ctx.createLinearGradient(0, gy - gh, 0, gy); g.addColorStop(0, rgba(s.k.g, 0.35)); g.addColorStop(1, rgba(s.k.g, 0)); ctx.fillStyle = g; ctx.beginPath(); ctx.moveTo(gx, gy); pk.forEach((p) => ctx.lineTo(...p)); ctx.lineTo(gx + gw, gy); ctx.closePath(); ctx.fill();
      ctx.strokeStyle = s.k.g; ctx.lineWidth = 6 * s.u; ctx.lineJoin = "round"; ctx.beginPath(); pk.forEach((p, i) => (i ? ctx.lineTo(...p) : ctx.moveTo(...p))); ctx.stroke(); ctx.restore(); if (e >= 1) { const q = pk[pk.length - 1]; ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(q[0], q[1], 10 * s.u, 0, PI * 2); ctx.fill(); } }
    ctx.restore();
  }, { pola: ["liczba", "od", "przed", "po", "tekst2", "lista"], czas: 4 });
  liczbaN("liczby-dwie-linie", "Dwie linie na wykresie (porównanie)", { lista: "Sty: 10/12\nLut: 18/14\nMar: 30/15\nKwi: 42/17\nMaj: 65/18", tekst: "My / Rynek" }, (s) => {
    const ctx = s.ctx, d = lista(s.p.lista).map((x) => { const i = x.indexOf(":"); const v = (i > 0 ? x.slice(i + 1) : "0/0").split("/").map((y) => parseFloat(y.replace(",", ".")) || 0); return { e: i > 0 ? x.slice(0, i).trim() : x, a: v[0] || 0, b: v[1] || 0 }; }), n = Math.max(2, d.length);
    const nz = String(s.p.tekst || "A / B").split("/").map((x) => x.trim()), W = s.W * 0.8 * s.p.rozmiar, H = Math.min(s.H * 0.3, 460 * s.u) * s.p.rozmiar, x0 = s.poz.x - W / 2, y0 = s.poz.y + H / 2, max = Math.max(1, ...d.map((x) => Math.max(x.a, x.b))) * 1.1, e = E.inOutCubic(T(s, 0.3, 1.5)), a = E.outCubic(T(s, 0, 0.4));
    ctx.save(); ctx.globalAlpha = s.alfa * a; ctx.fillStyle = rgba(s.k.t, 0.15); for (let i = 0; i <= 3; i++) ctx.fillRect(x0, y0 - H * i / 3, W, 2 * s.u); ctx.font = font(s, 32 * s.u * s.p.rozmiar, 600); ctx.fillStyle = rgba(s.k.t, 0.8); d.forEach((p, i) => { const x = x0 + W * i / (n - 1); ctx.fillText(p.e, x - ctx.measureText(p.e).width / 2, y0 + 36 * s.u); });
    const px = 42 * s.u * s.p.rozmiar; [[nz[0] || "A", s.k.a], [nz[1] || "B", rgba(s.k.t, 0.6)]].forEach(([t, k], i) => { const lx = x0 + i * W * 0.4, ly = y0 - H - 60 * s.u; ctx.fillStyle = k; ctx.fillRect(lx, ly - 4 * s.u, 40 * s.u, 8 * s.u); ctx.font = font(s, px, 800); ctx.fillStyle = s.k.t; ctx.fillText(t, lx + 56 * s.u, ly); }); ctx.restore();
    [["a", s.k.a, 8], ["b", rgba(s.k.t, 0.6), 6]].forEach(([k, kol, gr]) => { const pk = d.map((p, i) => [x0 + W * i / (n - 1), y0 - H * p[k] / max]); ctx.strokeStyle = kol; ctx.lineWidth = gr * s.u; ctx.lineJoin = "round"; ctx.lineCap = "round"; if (k === "b") ctx.setLineDash([14 * s.u, 10 * s.u]); const { koniec } = sciezkaCzesc(ctx, pk, e); ctx.stroke(); ctx.setLineDash([]); ctx.fillStyle = kol; ctx.beginPath(); ctx.arc(koniec[0], koniec[1], (gr + 4) * s.u, 0, PI * 2); ctx.fill(); });
    const g = E.outBack(T(s, 1.9, 0.4)); if (g > 0 && d.length) { const o = d[d.length - 1], xa = x0 + W, ya = y0 - H * o.a / max, yb = y0 - H * o.b / max, r = o.b ? Math.round(o.a / o.b * 10) / 10 : 0; ctx.save(); ctx.globalAlpha = s.alfa * clamp(g); ctx.strokeStyle = s.k.t; ctx.lineWidth = 3 * s.u; ctx.beginPath(); ctx.moveTo(xa + 24 * s.u, ya); ctx.lineTo(xa + 24 * s.u, yb); ctx.stroke();
      if (r) { const t = "x" + liczbaTekst(r, 1).replace(",0", ""); ctx.font = font(s, px * 1.1, 900); ctx.fillStyle = s.k.a; cien(s); const tw = ctx.measureText(t).width; ctx.fillText(t, Math.min(xa + 40 * s.u, s.W - tw - 20 * s.u), Math.min(ya, yb) - px * 1.1); } ctx.restore(); }
  }, { pola: ["lista", "tekst"], czas: 4 });
  liczbaN("liczby-babelki", "Wykres bąbelkowy", { lista: "Rolki: 120\nZdjęcia: 60\nKaruzele: 45\nRelacje: 30\nNa żywo: 15" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista).slice(0, 8).sort((a, b) => b.v - a.v), max = Math.max(1, ...d.map((x) => x.v)), R = 190 * s.u * s.p.rozmiar, kol = [s.k.g, s.k.a, "#60A5FA", "#A78BFA", "#34D399", "#F472B6", "#FBBF24", "#94A3B8"];
    const kola = []; d.forEach((p, i) => { const r = R * Math.sqrt(p.v / max); if (!i) { kola.push({ x: 0, y: 0, r }); return; } let best = null; for (let k = 0; k < 72; k++) { const a = k / 72 * PI * 2 + i; for (let dist = 0; dist < R * 6; dist += 6 * s.u) { const x = Math.cos(a) * dist, y = Math.sin(a) * dist * (s.H > s.W ? 1.3 : 0.75); if (kola.every((c) => Math.hypot(c.x - x, c.y - y) >= c.r + r + 8 * s.u)) { const sc = Math.hypot(x, y); if (!best || sc < best.sc) best = { x, y, sc }; break; } } } kola.push({ x: best ? best.x : 0, y: best ? best.y : 0, r }); });
    const bx = kola.reduce((a, c) => a + c.x, 0) / Math.max(1, kola.length), by = kola.reduce((a, c) => a + c.y, 0) / Math.max(1, kola.length);
    d.forEach((p, i) => { const c = kola[i], e = E.outElastic(T(s, 0.1 + i * 0.15, 0.9)); if (e <= 0) return; const x = s.poz.x + c.x - bx + Math.sin(s.t * 1.5 + i) * 4 * s.u, y = s.poz.y + c.y - by + Math.cos(s.t * 1.3 + i) * 4 * s.u, kk = kol[i % kol.length];
      ctx.save(); ctx.translate(x, y); ctx.scale(e, e); cien(s, ctx, 0.7); ctx.fillStyle = kk; ctx.beginPath(); ctx.arc(0, 0, c.r, 0, PI * 2); ctx.fill(); bezCienia(ctx);
      const t = liczbaTekst(p.v), et = bezGw(p.e); ctx.font = font(s, c.r * 0.42, 900); ctx.fillStyle = kontrast(kk); ctx.fillText(t, -ctx.measureText(t).width / 2, c.r > 70 * s.u ? -c.r * 0.12 : 0); if (c.r > 70 * s.u) { ctx.font = font(s, dopasuj(s, et, c.r * 0.22, c.r * 1.6, 600), 600); ctx.fillText(et, -ctx.measureText(et).width / 2, c.r * 0.3); } ctx.restore();
      if (c.r <= 70 * s.u) { ctx.save(); ctx.globalAlpha = s.alfa * clamp(e); cien(s); ctx.font = font(s, 30 * s.u * s.p.rozmiar, 700); ctx.fillStyle = s.k.t; ctx.fillText(et, x - ctx.measureText(et).width / 2, y + c.r + 26 * s.u); ctx.restore(); } });
  }, { pola: ["lista"], czas: 4 });
  liczbaN("liczby-cel-osiagniety", "Cel osiągnięty (licznik do celu)", { liczba: 10000, tekst2: "obserwujących!", po: "" }, (s) => {
    const ctx = s.ctx, r = 200 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y - r * 0.2, a = E.outBack(T(s, 0, 0.45)), kon = Math.max(1, s.T - s.p.wyjscie - 1.3), e = E.inOutCubic(okno(s.t, 0.3, kon - 0.3)), gotowe = s.t >= kon, g = E.outBackMocno(okno(s.t, kon, 0.45));
    ctx.save(); ctx.translate(cx, cy); ctx.scale(a * (1 + Math.sin(clamp(okno(s.t, kon, 0.4)) * PI) * 0.08), a * (1 + Math.sin(clamp(okno(s.t, kon, 0.4)) * PI) * 0.08)); ctx.lineWidth = r * 0.14; ctx.lineCap = "round"; ctx.strokeStyle = rgba(s.k.t, 0.15); ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.stroke();
    ctx.strokeStyle = gotowe ? zielony : s.k.a; ctx.beginPath(); luk(ctx, 0, 0, r, -PI / 2, -PI / 2 + PI * 2 * Math.max(0.001, e)); ctx.stroke();
    if (!gotowe) { const t = liczbaT(s, (+s.p.liczba || 0) * e); ctx.font = font(s, dopasuj(s, t, r * 0.5, r * 1.5, 900), 900); ctx.fillStyle = s.k.t; ctx.fillText(t, -ctx.measureText(t).width / 2, 0); }
    else { ctx.save(); ctx.scale(g, g); ctx.fillStyle = zielony; ctx.beginPath(); ctx.arc(0, 0, r * 0.72, 0, PI * 2); ctx.fill(); ptaszek(ctx, 0, 0, r * 0.38, E.outCubic(okno(s.t, kon + 0.1, 0.3)), "#FFFFFF", r * 0.12); ctx.restore(); }
    ctx.restore();
    if (gotowe) { const w = okno(s.t, kon, 1.2), kol = [s.k.g, s.k.a, "#FFFFFF", zielony]; for (let i = 0; i < 40; i++) { const k = los(i * 2.3) * PI * 2, v = (0.5 + los(i * 3.1)) * r * 2.2, x = cx + Math.cos(k) * v * E.outCubic(w), y = cy + Math.sin(k) * v * E.outCubic(w) + w * w * r; ctx.save(); ctx.globalAlpha = s.alfa * (1 - w); ctx.translate(x, y); ctx.rotate(w * 8 + i); ctx.fillStyle = kol[i % 4]; ctx.fillRect(-8 * s.u, -4 * s.u, 16 * s.u, 8 * s.u); ctx.restore(); }
      const t = liczbaT(s, +s.p.liczba || 0); ctx.save(); ctx.globalAlpha = s.alfa * g; cien(s); ctx.font = font(s, 90 * s.u * s.p.rozmiar, 900); ctx.fillStyle = s.k.a; ctx.fillText(t, cx - ctx.measureText(t).width / 2, cy + r * 1.45); ctx.restore(); podpis(s, cy + r * 1.75, g, 54, "tekst2"); }
  }, { pola: ["liczba", "przed", "po", "tekst2"], czas: 4 });

  // ---------- kształty, ramki i strzałki (v18) ----------
  function ksztaltN(id, nazwa, przyklad, fn, o = {}) { dodaj({ id, nazwa, kat: "ksztalty", czas: o.czas || 3, pola: o.pola || ["xy"], dom: o.dom, przyklad, rysuj: fn }); }
  /* Kierunek od punktu w stronę środka kadru (tam zwykle jest miejsce na strzałkę). */
  function kierDoSrodka(s, x, y) { const dx = s.W / 2 - x, dy = s.H / 2 - y, d = Math.hypot(dx, dy); return d < 1 ? [-0.7, 0.7] : [dx / d, dy / d]; }
  function grotStrzalki(ctx, x, y, kat, g) { ctx.beginPath(); ctx.moveTo(x - Math.cos(kat - 0.5) * g, y - Math.sin(kat - 0.5) * g); ctx.lineTo(x, y); ctx.lineTo(x - Math.cos(kat + 0.5) * g, y - Math.sin(kat + 0.5) * g); ctx.stroke(); }
  const prost = (s) => { const [ax, ay] = punkt(s), [bx, by] = punkt(s, "x2", "y2"); return [Math.min(ax, bx), Math.min(ay, by), Math.max(8, Math.abs(bx - ax)), Math.max(8, Math.abs(by - ay))]; };
  ksztaltN("ksztalt-strzalka-blokowa", "Duża strzałka wskazuje punkt", { tekst: "TUTAJ", x: 0.68, y: 0.38, wielkie: true }, (s) => {
    const ctx = s.ctx, [px0, py0] = punkt(s), [dx, dy] = kierDoSrodka(s, px0, py0), kat = Math.atan2(-dy, -dx), L = 300 * s.u * s.p.rozmiar, gr = L * 0.28, e = E.outBack(T(s, 0, 0.45)), b = Math.abs(Math.sin(s.t * 5)) * 26 * s.u * clamp(s.t - 0.4);
    ctx.save(); ctx.translate(px0 + dx * (30 * s.u + b + (1 - e) * 300 * s.u), py0 + dy * (30 * s.u + b + (1 - e) * 300 * s.u)); ctx.rotate(kat); ctx.globalAlpha = s.alfa * clamp(e * 2); cien(s, ctx, 1.2);
    ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(-L * 0.42, -gr * 1.05); ctx.lineTo(-L * 0.42, -gr * 0.45); ctx.lineTo(-L, -gr * 0.45); ctx.lineTo(-L, gr * 0.45); ctx.lineTo(-L * 0.42, gr * 0.45); ctx.lineTo(-L * 0.42, gr * 1.05); ctx.closePath(); ctx.lineJoin = "round"; ctx.fill(); bezCienia(ctx);
    ctx.strokeStyle = s.k.g; ctx.lineWidth = 6 * s.u; ctx.stroke();
    if (s.p.tekst) { const t = tekstP(s, s.p.tekst), p = dopasuj(s, t, gr * 0.62, L * 0.5, 900); ctx.save(); ctx.translate(-L * 0.68, 0); if (Math.cos(kat) < 0) ctx.rotate(PI); ctx.font = font(s, p, 900); ctx.fillStyle = kontrast(s.k.a); ctx.fillText(t, -ctx.measureText(t).width / 2, 0); ctx.restore(); }
    ctx.restore();
  }, { pola: ["tekst", "xy"] });
  ksztaltN("ksztalt-strzalka-petla", "Strzałka z pętelką", { x: 0.7, y: 0.32, x2: 0.28, y2: 0.62 }, (s) => {
    const ctx = s.ctx, [ax, ay] = punkt(s, "x2", "y2"), [bx, by] = punkt(s), dl = Math.hypot(bx - ax, by - ay) || 1, ux = (bx - ax) / dl, uy = (by - ay) / dl, nx = -uy, ny = ux, r = Math.min(90 * s.u * s.p.rozmiar, dl * 0.18), pk = [];
    const L = [ax + ux * dl * 0.5, ay + uy * dl * 0.5], P = (p, q) => [L[0] + ux * p + nx * q, L[1] + uy * p + ny * q];
    krzywa([ax, ay], P(-dl * 0.25, -dl * 0.12), L, 30).forEach((p) => pk.push(p)); for (let i = 1; i <= 40; i++) { const th = i / 40 * PI * 2; pk.push(P(r * Math.sin(th), -r * (1 - Math.cos(th)))); } krzywa(L, P(dl * 0.25, 0), [bx, by], 30).slice(1).forEach((p) => pk.push(p));
    const e = E.inOutCubic(T(s, 0, 1.0)); ctx.strokeStyle = s.k.a; ctx.lineWidth = 11 * s.u * s.p.rozmiar; ctx.lineCap = "round"; ctx.lineJoin = "round"; cien(s);
    const { koniec, kier } = sciezkaCzesc(ctx, odrecznie(pk, 3 * s.u, 4), e); ctx.stroke(); if (e > 0.9) grotStrzalki(ctx, koniec[0], koniec[1], kier, 44 * s.u * s.p.rozmiar * E.outBack(okno(e, 0.9, 0.1)));
  }, { pola: ["xy", "xy2"] });
  ksztaltN("ksztalt-strzalka-przerywana", "Przerywana strzałka między punktami", { x: 0.72, y: 0.3, x2: 0.25, y2: 0.7 }, (s) => {
    const ctx = s.ctx, a = punkt(s, "x2", "y2"), b = punkt(s), m = [(a[0] + b[0]) / 2 + (b[1] - a[1]) * 0.3, (a[1] + b[1]) / 2 - (b[0] - a[0]) * 0.3], pk = krzywa(a, m, b, 60), e = E.inOutCubic(T(s, 0.2, 0.9)), r = 14 * s.u * s.p.rozmiar;
    const st = E.outBack(T(s, 0, 0.35)); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(a[0], a[1], r * st, 0, PI * 2); ctx.fill(); ctx.strokeStyle = "#FFFFFF"; ctx.lineWidth = 4 * s.u; ctx.stroke();
    ctx.setLineDash([22 * s.u, 14 * s.u]); ctx.lineDashOffset = -s.t * 60 * s.u; ctx.strokeStyle = s.k.t; ctx.lineWidth = 7 * s.u * s.p.rozmiar; ctx.lineCap = "round"; cien(s); const { koniec, kier } = sciezkaCzesc(ctx, pk, e); ctx.stroke(); ctx.setLineDash([]);
    if (e > 0.05) { ctx.fillStyle = s.k.a; ctx.save(); ctx.translate(koniec[0], koniec[1]); ctx.rotate(kier); const g = 34 * s.u * s.p.rozmiar; ctx.beginPath(); ctx.moveTo(g * 0.4, 0); ctx.lineTo(-g * 0.7, -g * 0.55); ctx.lineTo(-g * 0.4, 0); ctx.lineTo(-g * 0.7, g * 0.55); ctx.closePath(); ctx.fill(); ctx.restore(); }
  }, { pola: ["xy", "xy2"] });
  ksztaltN("ksztalt-strzalki-trzy", "Trzy migające strzałki", { x: 0.65, y: 0.5 }, (s) => {
    const ctx = s.ctx, [px0, py0] = punkt(s), [dx, dy] = kierDoSrodka(s, px0, py0), kat = Math.atan2(-dy, -dx), r = 46 * s.u * s.p.rozmiar, a = E.outCubic(T(s, 0, 0.3));
    ctx.save(); ctx.translate(px0, py0); ctx.rotate(kat); ctx.strokeStyle = s.k.a; ctx.lineWidth = r * 0.32; ctx.lineCap = "round"; ctx.lineJoin = "round"; cien(s);
    for (let i = 0; i < 3; i++) { const f = ((s.t * 1.6 - i * 0.22) % 1 + 1) % 1, op = Math.max(0.2, Math.sin(f * PI)) * a, x = -r * 1.6 - (2 - i) * r * 1.25; ctx.globalAlpha = s.alfa * op; ctx.beginPath(); ctx.moveTo(x - r * 0.5, -r * 0.8); ctx.lineTo(x + r * 0.3, 0); ctx.lineTo(x - r * 0.5, r * 0.8); ctx.stroke(); }
    ctx.restore();
  });
  ksztaltN("ksztalt-dotkniecie", "Podwójne dotknięcie ekranu", { x: 0.5, y: 0.55 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), r = 60 * s.u * s.p.rozmiar, okres = 1.3 / s.p.tempo, lt = s.t % okres;
    [0.15, 0.42].forEach((tk) => { const w = okno(lt, tk, 0.6); if (w > 0 && w < 1) { ctx.strokeStyle = rgba("#FFFFFF", (1 - w) * 0.9); ctx.lineWidth = 5 * s.u; ctx.beginPath(); ctx.arc(cx, cy, r * (0.8 + w * 1.6), 0, PI * 2); ctx.stroke(); } });
    const nac = (lt > 0.12 && lt < 0.25) || (lt > 0.39 && lt < 0.52) ? 0.78 : 1, a = E.outBack(T(s, 0, 0.35)); ctx.save(); ctx.translate(cx, cy); ctx.scale(a * nac, a * nac); ctx.fillStyle = rgba("#FFFFFF", 0.35); ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); ctx.strokeStyle = "#FFFFFF"; ctx.lineWidth = 5 * s.u; ctx.stroke(); ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(0, 0, r * 0.35, 0, PI * 2); ctx.fill(); ctx.restore();
  });
  ksztaltN("ksztalt-prostokat-reczny", "Prostokąt rysowany ręcznie", { x: 0.22, y: 0.36, x2: 0.78, y2: 0.56 }, (s) => {
    const ctx = s.ctx, [x, y, w, h] = prost(s); ctx.strokeStyle = s.k.a; ctx.lineCap = "round"; ctx.lineJoin = "round"; cien(s);
    [[0, 0, 9], [0.35, 1, 5]].forEach(([od, z, gr]) => { const e = E.inOutCubic(T(s, od, 0.8)); if (e <= 0) return; const o = 10 * s.u, pk = obwodProst(x - o * z, y + o * 0.6 * z, w + o * 2 * z, h - o * z, 48); pk.push([pk[1][0] + 20 * s.u, pk[1][1] - 6 * s.u]); ctx.lineWidth = gr * s.u * s.p.rozmiar; sciezkaCzesc(ctx, odrecznie(pk, 7 * s.u, z * 5 + 1), e); ctx.stroke(); });
  }, { pola: ["xy", "xy2"] });
  ksztaltN("ksztalt-wyroznienie-obszaru", "Przyciemnienie poza prostokątem", { x: 0.18, y: 0.38, x2: 0.82, y2: 0.58 }, (s) => {
    const ctx = s.ctx, [x, y, w, h] = prost(s), e = E.inOutCubic(T(s, 0, 0.7)), X = lerp(0, x, e), Y = lerp(0, y, e), Wd = lerp(s.W, w, e), Hd = lerp(s.H, h, e), r = 24 * s.u * e;
    const c = warstwa(s, "obszar", (q) => { q.fillStyle = `rgba(0,0,0,${0.65 * e})`; q.fillRect(0, 0, s.W, s.H); q.globalCompositeOperation = "destination-out"; zaokr(q, X, Y, Wd, Hd, r); q.fill(); });
    ctx.drawImage(c, 0, 0); const b = E.outCubic(T(s, 0.6, 0.4)); if (b > 0) { ctx.strokeStyle = rgba(s.k.a, b); ctx.lineWidth = 5 * s.u; zaokr(ctx, X, Y, Wd, Hd, r); ctx.stroke(); }
  }, { pola: ["xy", "xy2"], czas: 3.5 });
  ksztaltN("ksztalt-lupa", "Lupa nad punktem", { x: 0.55, y: 0.45 }, (s) => {
    const ctx = s.ctx, [cx0, cy0] = punkt(s), r = 130 * s.u * s.p.rozmiar, e = E.outBack(T(s, 0, 0.5)), cx = cx0 + Math.sin(s.t * 1.6) * 8 * s.u, cy = cy0 + Math.cos(s.t * 1.3) * 6 * s.u;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); ctx.rotate((1 - e) * 0.8); cien(s, ctx, 1.3); ctx.strokeStyle = "#1F2937"; ctx.lineCap = "round"; ctx.lineWidth = r * 0.24; ctx.beginPath(); ctx.moveTo(r * 0.78, r * 0.78); ctx.lineTo(r * 1.6, r * 1.6); ctx.stroke();
    ctx.strokeStyle = s.k.g; ctx.lineWidth = r * 0.14; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.stroke(); bezCienia(ctx); ctx.fillStyle = "rgba(255,255,255,0.08)"; ctx.beginPath(); ctx.arc(0, 0, r * 0.93, 0, PI * 2); ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.7)"; ctx.lineWidth = r * 0.07; ctx.beginPath(); ctx.arc(0, 0, r * 0.72, PI * 1.1, PI * 1.45); ctx.stroke(); ctx.restore();
  });
  ksztaltN("ksztalt-iskry", "Błyski wokół punktu", { x: 0.5, y: 0.45 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), R = 200 * s.u * s.p.rozmiar, kol = [s.k.a, "#FFFFFF", s.k.g];
    for (let i = 0; i < 12; i++) { const k = los(i * 1.7) * PI * 2, d = R * (0.4 + los(i * 2.9) * 0.8), x = cx + Math.cos(k) * d, y = cy + Math.sin(k) * d * 0.8, f = ((s.t * (0.8 + los(i) * 0.6) + los(i * 5.3)) % 1), a = Math.sin(f * PI) * clamp(s.t * 3), r = (14 + los(i * 3.3) * 30) * s.u * s.p.rozmiar * a; if (r <= 0.5) continue;
      ctx.save(); ctx.translate(x, y); ctx.rotate(f * 1.5); ctx.fillStyle = kol[i % 3]; ctx.globalAlpha = s.alfa * a; ctx.beginPath(); ctx.moveTo(0, -r); ctx.quadraticCurveTo(0, 0, r, 0); ctx.quadraticCurveTo(0, 0, 0, r); ctx.quadraticCurveTo(0, 0, -r, 0); ctx.quadraticCurveTo(0, 0, 0, -r); ctx.fill(); ctx.restore(); }
  }, { czas: 3 });
  ksztaltN("ksztalt-kreski-zaskoczenia", "Kreski zaskoczenia (komiks)", { x: 0.62, y: 0.3 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), r = 70 * s.u * s.p.rozmiar, drg = Math.sin(s.t * 30) * 3 * s.u * clamp(1 - (s.t - 0.4) * 1.5); ctx.strokeStyle = s.k.a; ctx.lineCap = "round"; ctx.lineWidth = 11 * s.u * s.p.rozmiar; cien(s);
    [-0.9, -0.45, 0].forEach((k, i) => { const e = E.outBackMocno(T(s, i * 0.08, 0.35)); if (e <= 0) return; const kk = -PI / 2 + k + 0.45, x1 = cx + Math.cos(kk) * r, y1 = cy + Math.sin(kk) * r, x2 = cx + Math.cos(kk) * (r + r * (i === 1 ? 1.3 : 1.0) * e), y2 = cy + Math.sin(kk) * (r + r * (i === 1 ? 1.3 : 1.0) * e); ctx.beginPath(); ctx.moveTo(x1 + drg, y1); ctx.lineTo(x2 + drg, y2); ctx.stroke(); });
  });
  ksztaltN("ksztalt-wybuch-komiks", "Komiksowy wybuch z napisem", { tekst: "BUM!", x: 0.5, y: 0.42, wielkie: true }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), R = 230 * s.u * s.p.rozmiar, e = E.outBackMocno(T(s, 0, 0.35)), drg = s.t < 0.6 ? (los(Math.floor(s.t * 50)) - 0.5) * 12 * s.u : 0, n = 14;
    ctx.save(); ctx.translate(cx + drg, cy + drg * 0.6); ctx.scale(e, e); ctx.rotate(-0.08 + Math.sin(s.t * 2) * 0.03); cien(s, ctx, 1.3);
    const sz = (k, rr) => { ctx.beginPath(); for (let i = 0; i < n * 2; i++) { const a = i / (n * 2) * PI * 2, q = rr * (i % 2 ? 0.62 + los(i * 3.1) * 0.12 : 1 + los(i * 1.3) * 0.18); i ? ctx.lineTo(Math.cos(a) * q * 1.15, Math.sin(a) * q * 0.85) : ctx.moveTo(Math.cos(a) * q * 1.15, Math.sin(a) * q * 0.85); } ctx.closePath(); ctx.fillStyle = k; ctx.fill(); };
    sz(s.k.g, R); bezCienia(ctx); sz(s.k.a, R * 0.8);
    const t = tekstP(s, s.p.tekst), p = dopasuj(s, t, R * 0.55, R * 1.5, 900); ctx.font = font(s, p, 900); const w = ctx.measureText(t).width; ctx.lineJoin = "round"; ctx.lineWidth = p * 0.14; ctx.strokeStyle = "#111111"; ctx.strokeText(t, -w / 2, 0); ctx.fillStyle = "#FFFFFF"; ctx.fillText(t, -w / 2, 0); ctx.restore();
  }, { pola: ["tekst", "xy"], czas: 2.5 });
  ksztaltN("ksztalt-plama-plynna", "Płynna plama (dekoracja)", { x: 0.5, y: 0.5 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), R = 260 * s.u * s.p.rozmiar, e = E.outBack(T(s, 0, 0.8)), g = ctx.createLinearGradient(cx - R, cy - R, cx + R, cy + R); g.addColorStop(0, s.k.g); g.addColorStop(1, s.k.a);
    ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); ctx.rotate(s.t * 0.2); ctx.fillStyle = g; ctx.globalAlpha = s.alfa * 0.9; ctx.beginPath(); const n = 8, pk = [];
    for (let i = 0; i < n; i++) { const a = i / n * PI * 2, r = R * (0.85 + 0.15 * Math.sin(s.t * 1.7 + i * 2.1) + 0.08 * Math.sin(s.t * 2.9 + i * 1.3)); pk.push([Math.cos(a) * r, Math.sin(a) * r]); }
    for (let i = 0; i < n; i++) { const p = pk[i], q = pk[(i + 1) % n], m = [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2]; if (!i) { const z = pk[n - 1]; ctx.moveTo((z[0] + p[0]) / 2, (z[1] + p[1]) / 2); } ctx.quadraticCurveTo(p[0], p[1], m[0], m[1]); } ctx.closePath(); ctx.fill(); ctx.restore();
  }, { czas: 5 });
  ksztaltN("ksztalt-orbita", "Kropki krążące po orbicie", { x: 0.5, y: 0.45 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), R = 220 * s.u * s.p.rozmiar, e = E.outCubic(T(s, 0, 0.6)), kol = [s.k.a, s.k.g, "#FFFFFF"];
    ctx.strokeStyle = rgba(s.k.t, 0.25 * e); ctx.lineWidth = 2 * s.u; [[1, 0.45, 0.4], [0.75, 0.3, -0.5]].forEach(([k, sp, rot]) => { ctx.save(); ctx.translate(cx, cy); ctx.rotate(rot); ctx.beginPath(); ctx.ellipse(0, 0, R * k * e, R * k * sp * e, 0, 0, PI * 2); ctx.stroke(); ctx.restore(); });
    [[1, 0.45, 0.4, 1.3, 0], [1, 0.45, 0.4, 1.3, PI], [0.75, 0.3, -0.5, -1.8, 1]].forEach(([k, sp, rot, v, f0], i) => { for (let j = 0; j < 8; j++) { const a = s.t * v + f0 - j * 0.06 * Math.sign(v), x = Math.cos(a) * R * k * e, y = Math.sin(a) * R * k * sp * e; ctx.save(); ctx.translate(cx, cy); ctx.rotate(rot); ctx.globalAlpha = s.alfa * (1 - j / 8) * e; ctx.fillStyle = kol[i]; ctx.beginPath(); ctx.arc(x, y, 14 * s.u * s.p.rozmiar * (1 - j / 10), 0, PI * 2); ctx.fill(); ctx.restore(); } });
  }, { czas: 4 });
  ksztaltN("ksztalt-siatka-kropek", "Siatka kropek z falą (dekoracja)", { x: 0.75, y: 0.25 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), n = 7, k = 42 * s.u * s.p.rozmiar, x0 = cx - (n - 1) * k / 2, y0 = cy - (n - 1) * k / 2;
    for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) { const e = E.outBack(T(s, (i + j) * 0.03, 0.4)); if (e <= 0) continue; const d = Math.hypot(i - (n - 1) / 2, j - (n - 1) / 2), f = 0.6 + 0.4 * Math.sin(s.t * 4 - d * 0.9); ctx.fillStyle = (i + j) % 4 === 0 ? s.k.a : rgba(s.k.t, 0.85); ctx.beginPath(); ctx.arc(x0 + i * k, y0 + j * k, k * 0.16 * e * f, 0, PI * 2); ctx.fill(); }
  }, { czas: 4 });
  ksztaltN("ksztalt-zygzaki", "Zygzaki i fale (dekoracja)", { x: 0.3, y: 0.25 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), L = 320 * s.u * s.p.rozmiar, kol = [s.k.a, s.k.g, s.k.t]; ctx.lineCap = "round"; ctx.lineJoin = "round";
    kol.forEach((k, i) => { const e = E.inOutCubic(T(s, i * 0.15, 0.7)), y = cy + (i - 1) * 50 * s.u * s.p.rozmiar, pk = []; for (let j = 0; j <= 40; j++) { const f = j / 40; pk.push([cx - L / 2 + L * f, y + (i % 2 ? Math.sin(f * PI * 5 + s.t * 4) * 14 : (Math.abs(((f * 5 + s.t * 0.8) % 1) - 0.5) * 2 - 0.5) * 30) * s.u * s.p.rozmiar]); }
      ctx.strokeStyle = k; ctx.lineWidth = 8 * s.u * s.p.rozmiar; sciezkaCzesc(ctx, pk, e); ctx.stroke(); });
  }, { czas: 4 });
  ksztaltN("ksztalt-podkreslenie-reczne", "Podkreślenie pędzlem w punkcie", { x: 0.22, y: 0.55, x2: 0.78, y2: 0.55 }, (s) => {
    const ctx = s.ctx, a = punkt(s), b = punkt(s, "x2", "y2"), e = E.outCubic(T(s, 0, 0.5)), gr = 40 * s.u * s.p.rozmiar, n = 30, gora = [], dol = [];
    for (let i = 0; i <= n; i++) { const f = i / n * e, x = lerp(a[0], b[0], f), y = lerp(a[1], b[1], f) + Math.sin(f * PI) * -12 * s.u, w = gr * (0.35 + 0.65 * Math.sin(Math.min(1, f / e * 1.05) * PI * 0.9 + 0.15)) * (1 + (los(i) - 0.5) * 0.2); gora.push([x, y - w / 2]); dol.push([x, y + w / 2]); }
    ctx.fillStyle = s.k.a; cien(s); ctx.beginPath(); gora.forEach((p, i) => (i ? ctx.lineTo(...p) : ctx.moveTo(...p))); dol.reverse().forEach((p) => ctx.lineTo(...p)); ctx.closePath(); ctx.fill();
  }, { pola: ["xy", "xy2"], czas: 3 });
  ksztaltN("ksztalt-zdjecie-tasma", "Ramka zdjęcia przyklejona taśmą", { x: 0.5, y: 0.45 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), w = Math.min(s.W * 0.66, s.H * 0.5) * s.p.rozmiar, h = w * 1.25, gr = w * 0.04, e = E.outBack(T(s, 0, 0.5)), rot = lerp(-0.25, -0.03, e);
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(rot); ctx.scale(lerp(1.3, 1, e), lerp(1.3, 1, e)); ctx.globalAlpha = s.alfa * clamp(e * 2); cien(s, ctx, 1.2); ctx.strokeStyle = "#FFFFFF"; ctx.lineWidth = gr * 2; ctx.strokeRect(-w / 2 + gr, -h / 2 + gr, w - gr * 2, h - gr * 2); bezCienia(ctx);
    const ta = E.outBack(T(s, 0.35, 0.4)); [[-w / 2, -h / 2, -0.7], [w / 2, h / 2, -0.7]].forEach(([x, y, k]) => { ctx.save(); ctx.translate(x, y); ctx.rotate(k); ctx.scale(ta, ta); ctx.fillStyle = rgba(s.k.a, 0.82); ctx.fillRect(-w * 0.17, -w * 0.05, w * 0.34, w * 0.1); ctx.fillStyle = "rgba(255,255,255,0.25)"; ctx.fillRect(-w * 0.17, -w * 0.05, w * 0.34, w * 0.025); ctx.restore(); });
    ctx.restore();
  }, { czas: 3.5 });
  ksztaltN("ksztalt-ramka-neon", "Neonowa ramka", {}, (s) => {
    const ctx = s.ctx, m = Math.min(s.W, s.H) * 0.09 / s.p.rozmiar, r = 40 * s.u, t = s.t * s.p.tempo, mig = t < 0.8 ? (los(Math.floor(t * 20)) > 0.4 ? 1 : 0.15) : 0.9 + 0.1 * Math.sin(s.t * 7);
    ctx.save(); ctx.globalAlpha = s.alfa * mig; ctx.shadowColor = s.k.a; ctx.shadowBlur = 40 * s.u; ctx.strokeStyle = s.k.a; ctx.lineWidth = 10 * s.u; zaokr(ctx, m, m, s.W - m * 2, s.H - m * 2, r); ctx.stroke(); ctx.shadowBlur = 12 * s.u; ctx.strokeStyle = "#FFFFFF"; ctx.lineWidth = 3.5 * s.u; ctx.stroke(); ctx.restore();
  }, { pola: [], czas: 4 });
  ksztaltN("ksztalt-pasy-kinowe", "Pasy kinowe (format filmowy)", { liczba: 2.39 }, (s) => {
    const ctx = s.ctx, prop = Math.max(1, +s.p.liczba || 2.39), wPion = s.W / prop, pas = Math.max(0, (s.H - wPion) / 2), e = E.inOutCubic(T(s, 0, 0.7));
    if (s.H >= s.W) { const p = Math.max(s.H * 0.18, pas * 0.4); ctx.fillStyle = "#000000"; ctx.fillRect(0, 0, s.W, p * e); ctx.fillRect(0, s.H - p * e, s.W, p * e); }
    else { ctx.fillStyle = "#000000"; ctx.fillRect(0, 0, s.W, pas * e); ctx.fillRect(0, s.H - pas * e, s.W, pas * e); }
  }, { pola: ["liczba"], czas: 5 });
  ksztaltN("ksztalt-winieta", "Winieta (przyciemnione rogi)", { liczba: 70 }, (s) => {
    const ctx = s.ctx, moc = clamp((+s.p.liczba || 60) / 100) * E.outCubic(T(s, 0, 0.8)), R = Math.hypot(s.W, s.H) / 2, g = ctx.createRadialGradient(s.W / 2, s.H / 2, R * 0.35 / s.p.rozmiar, s.W / 2, s.H / 2, R);
    g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(0.6, `rgba(0,0,0,${0.35 * moc})`); g.addColorStop(1, `rgba(0,0,0,${0.9 * moc})`); ctx.fillStyle = g; ctx.fillRect(0, 0, s.W, s.H);
  }, { pola: ["liczba"], czas: 5 });
  ksztaltN("ksztalt-namierzanie", "Namierzanie celu", { tekst: "CEL", x: 0.55, y: 0.42 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), r = 140 * s.u * s.p.rozmiar, e = E.outCubic(T(s, 0, 0.8)), lock = s.t > 0.85 / s.p.tempo, R = lerp(r * 3, r, e), kol = lock ? s.k.a : s.k.t;
    ctx.save(); ctx.translate(cx, cy); ctx.rotate(s.t * (lock ? 0.6 : 3)); ctx.strokeStyle = kol; ctx.lineWidth = 6 * s.u; for (let i = 0; i < 4; i++) { ctx.beginPath(); ctx.arc(0, 0, R, i * PI / 2 + 0.2, i * PI / 2 + PI / 2 - 0.2); ctx.stroke(); } ctx.restore();
    ctx.strokeStyle = kol; ctx.lineWidth = 4 * s.u; [[-1, 0], [1, 0], [0, -1], [0, 1]].forEach(([a, b]) => { ctx.beginPath(); ctx.moveTo(cx + a * R * 0.55, cy + b * R * 0.55); ctx.lineTo(cx + a * R * 1.25, cy + b * R * 1.25); ctx.stroke(); });
    if (lock) { const k = E.outBack(okno(s.t, 0.85 / s.p.tempo, 0.3)), q = r * 0.45 * lerp(1.6, 1, k), d = q * 0.4; ctx.strokeStyle = s.k.a; ctx.lineWidth = 6 * s.u; [[-1, -1], [1, -1], [1, 1], [-1, 1]].forEach(([a, b]) => { ctx.beginPath(); ctx.moveTo(cx + a * q, cy + b * (q - d)); ctx.lineTo(cx + a * q, cy + b * q); ctx.lineTo(cx + a * (q - d), cy + b * q); ctx.stroke(); });
      if (s.p.tekst && Math.floor(s.t * 4) % 2 === 0) { ctx.font = font(s, r * 0.28, 800); ctx.fillStyle = s.k.a; ctx.fillText(tekstP(s, s.p.tekst), cx + R * 0.8, cy - R * 0.85); } }
    ctx.fillStyle = kol; ctx.beginPath(); ctx.arc(cx, cy, 6 * s.u, 0, PI * 2); ctx.fill();
  }, { pola: ["tekst", "xy"], czas: 3 });
  ksztaltN("ksztalt-wykrywanie-obiektu", "Wykrywanie obiektu (ramka AI)", { tekst: "Kawa 98%", x: 0.3, y: 0.35, x2: 0.7, y2: 0.62 }, (s) => {
    const ctx = s.ctx, [x, y, w, h] = prost(s), e = E.outQuint(T(s, 0, 0.5)), d = Math.min(w, h) * 0.18, kol = s.k.a, cx = x + w / 2, cy = y + h / 2, X = lerp(cx, x, e), Y = lerp(cy, y, e), Wd = w * e, Hd = h * e;
    ctx.fillStyle = rgba(kol, 0.08 * e); ctx.fillRect(X, Y, Wd, Hd); ctx.strokeStyle = kol; ctx.lineWidth = 5 * s.u; ctx.lineCap = "square";
    [[X, Y, 1, 1], [X + Wd, Y, -1, 1], [X + Wd, Y + Hd, -1, -1], [X, Y + Hd, 1, -1]].forEach(([a, b, k1, k2]) => { ctx.beginPath(); ctx.moveTo(a + k1 * d, b); ctx.lineTo(a, b); ctx.lineTo(a, b + k2 * d); ctx.stroke(); });
    ctx.strokeStyle = rgba(kol, 0.45); ctx.lineWidth = 1.5 * s.u; ctx.strokeRect(X, Y, Wd, Hd);
    const sk = ((s.t - 0.5) * 0.7) % 1; if (s.t > 0.5) { const yy = y + h * sk, g = ctx.createLinearGradient(0, yy - 60 * s.u, 0, yy); g.addColorStop(0, rgba(kol, 0)); g.addColorStop(1, rgba(kol, 0.45)); ctx.fillStyle = g; ctx.fillRect(x, Math.max(y, yy - 60 * s.u), w, Math.min(60 * s.u, yy - y)); ctx.fillStyle = kol; ctx.fillRect(x, yy - 1.5 * s.u, w, 3 * s.u); }
    if (s.p.tekst) { const l = E.outCubic(T(s, 0.45, 0.35)), px = 34 * s.u * s.p.rozmiar; ctx.font = font(s, px, 800); const tw = ctx.measureText(s.p.tekst).width + px; ctx.save(); ctx.beginPath(); ctx.rect(x - 3 * s.u, y - px * 1.5, tw * l + 3 * s.u, px * 1.5); ctx.clip(); ctx.fillStyle = kol; ctx.fillRect(x - 2.5 * s.u, y - px * 1.45, tw, px * 1.45); ctx.fillStyle = kontrast(kol); ctx.fillText(s.p.tekst, x + px * 0.5 - 2.5 * s.u, y - px * 0.72); ctx.restore(); }
  }, { pola: ["tekst", "xy", "xy2"], czas: 4 });
  ksztaltN("ksztalt-doodle", "Rysunki odręczne wokół punktu", { x: 0.5, y: 0.45 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), R = 230 * s.u * s.p.rozmiar; ctx.lineCap = "round"; ctx.lineJoin = "round"; ctx.lineWidth = 7 * s.u * s.p.rozmiar; cien(s);
    const ksz = [
      (c) => { const pk = []; for (let i = 0; i <= 40; i++) { const k = i / 40 * PI * 4, r = 6 + i * 0.9; pk.push([c[0] + Math.cos(k) * r * s.u * 1.3, c[1] + Math.sin(k) * r * s.u * 1.3]); } return pk; },
      (c) => { const pk = []; for (let i = 0; i <= 10; i++) { const k = -PI / 2 + i / 10 * PI * 2, r = (i % 2 ? 18 : 42) * s.u; pk.push([c[0] + Math.cos(k) * r, c[1] + Math.sin(k) * r]); } return pk; },
      (c) => [[c[0] - 40 * s.u, c[1]], [c[0] + 40 * s.u, c[1]], [c[0], c[1]], [c[0], c[1] - 40 * s.u], [c[0], c[1] + 40 * s.u]],
      (c) => { const pk = []; for (let i = 0; i <= 30; i++) { const f = i / 30; pk.push([c[0] - 50 * s.u + f * 100 * s.u, c[1] + Math.sin(f * PI * 3) * 14 * s.u]); } return pk; },
      (c) => { const pk = []; for (let i = 0; i <= 30; i++) { const k = i / 30 * PI * 2; pk.push([c[0] + Math.cos(k) * 22 * s.u, c[1] + Math.sin(k) * 22 * s.u]); } return pk; },
      (c) => [[c[0] - 18 * s.u, c[1] - 45 * s.u], [c[0] + 12 * s.u, c[1] - 5 * s.u], [c[0] - 12 * s.u, c[1] + 5 * s.u], [c[0] + 18 * s.u, c[1] + 45 * s.u]],
    ];
    ksz.forEach((f, i) => { const k = -PI / 2 + i / ksz.length * PI * 2 + 0.3, c = [cx + Math.cos(k) * R, cy + Math.sin(k) * R * 0.8], e = E.inOutCubic(T(s, i * 0.12, 0.5)); if (e <= 0) return; ctx.strokeStyle = i % 2 ? s.k.t : s.k.a; ctx.save(); ctx.translate(c[0], c[1]); ctx.rotate(Math.sin(s.t * 2 + i) * 0.08); ctx.translate(-c[0], -c[1]); sciezkaCzesc(ctx, f(c), e); ctx.stroke(); ctx.restore(); });
  }, { czas: 3.5 });
  ksztaltN("ksztalt-zaznaczenie-mrowki", "Zaznaczenie z maszerującymi mrówkami", { x: 0.25, y: 0.35, x2: 0.75, y2: 0.6 }, (s) => {
    const ctx = s.ctx, [x, y, w, h] = prost(s), e = E.outQuint(T(s, 0, 0.45)), Wd = w * e, Hd = h * e;
    ctx.lineWidth = 3 * s.u; ctx.strokeStyle = "#000000"; ctx.strokeRect(x, y, Wd, Hd); ctx.setLineDash([12 * s.u, 10 * s.u]); ctx.lineDashOffset = -s.t * 40 * s.u; ctx.strokeStyle = "#FFFFFF"; ctx.strokeRect(x, y, Wd, Hd); ctx.setLineDash([]);
    const a = E.outBack(T(s, 0.4, 0.35)); if (a > 0) { const q = 16 * s.u * a; [[0, 0], [0.5, 0], [1, 0], [1, 0.5], [1, 1], [0.5, 1], [0, 1], [0, 0.5]].forEach(([fx, fy]) => { ctx.fillStyle = "#FFFFFF"; ctx.fillRect(x + w * fx - q / 2, y + h * fy - q / 2, q, q); ctx.strokeStyle = s.k.g; ctx.lineWidth = 3 * s.u; ctx.strokeRect(x + w * fx - q / 2, y + h * fy - q / 2, q, q); });
      const t = `${Math.round(w / s.W * 100)} × ${Math.round(h / s.H * 100)}`, px = 28 * s.u; ctx.font = font(s, px, 700); const tw = ctx.measureText(t).width + px; ctx.globalAlpha = s.alfa * a; ctx.fillStyle = s.k.g; zaokr(ctx, x + w / 2 - tw / 2, y + h + px * 0.8, tw, px * 1.5, px * 0.4); ctx.fill(); ctx.fillStyle = kontrast(s.k.g); ctx.fillText(t, x + w / 2 - tw / 2 + px * 0.5, y + h + px * 1.55); ctx.globalAlpha = s.alfa; }
  }, { pola: ["xy", "xy2"], czas: 3.5 });
  function dlon(ctx, x, y, sk, kol) {
    ctx.save(); ctx.translate(x, y); ctx.scale(sk, sk); ctx.fillStyle = kol; ctx.strokeStyle = "#111111"; ctx.lineWidth = 3; ctx.lineJoin = "round";
    ctx.beginPath(); ctx.moveTo(-9, 0); ctx.quadraticCurveTo(-9, -9, 0, -9); ctx.quadraticCurveTo(9, -9, 9, 0); ctx.lineTo(9, 34); ctx.quadraticCurveTo(14, 28, 22, 31); ctx.quadraticCurveTo(28, 26, 36, 31); ctx.quadraticCurveTo(43, 28, 48, 35); ctx.lineTo(48, 62); ctx.quadraticCurveTo(48, 84, 26, 86); ctx.lineTo(8, 86); ctx.quadraticCurveTo(-8, 84, -16, 66); ctx.lineTo(-27, 44); ctx.quadraticCurveTo(-30, 35, -21, 34); ctx.quadraticCurveTo(-14, 34, -9, 44); ctx.closePath(); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(22, 31); ctx.lineTo(22, 46); ctx.moveTo(36, 31); ctx.lineTo(36, 46); ctx.stroke(); ctx.restore();
  }
  ksztaltN("ksztalt-dlon-wskazuje", "Dłoń wskazuje i stuka", { x: 0.5, y: 0.5 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), e = E.outCubic(T(s, 0, 0.6)), okres = 0.9 / s.p.tempo, lt = Math.max(0, s.t - 0.6) % okres, st = s.t > 0.6 ? Math.sin(clamp(lt / 0.25) * PI) : 0, sk = 2.4 * s.u * s.p.rozmiar;
    if (s.t > 0.6) { const w = clamp(lt / 0.6); ctx.strokeStyle = rgba(s.k.a, 1 - w); ctx.lineWidth = 5 * s.u; ctx.beginPath(); ctx.arc(cx, cy, 20 * s.u + w * 70 * s.u, 0, PI * 2); ctx.stroke(); }
    ctx.save(); cien(s, ctx, 1.2); dlon(ctx, cx + (1 - e) * 220 * s.u, cy + (1 - e) * 300 * s.u + 10 * s.u + st * -14 * s.u + 14 * s.u, sk * (1 - st * 0.06), "#FFFFFF"); ctx.restore();
  }, { czas: 3 });
  ksztaltN("ksztalt-wstega", "Wstęga z napisem", { tekst: "Najlepszy wybór", wielkie: true }, (s) => {
    const ctx = s.ctx, px = 54 * s.u * s.p.rozmiar, t = tekstP(s, s.p.tekst); ctx.font = font(s, px, 900); const tw = ctx.measureText(t).width, W = tw + px * 2, h = px * 1.8, cx = s.poz.x, cy = s.poz.y, e = E.outBack(T(s, 0, 0.6)), ko = ciemniej(s.k.g, 0.35), ogon = h * 1.1;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(Math.max(0.01, e), 1); cien(s);
    [-1, 1].forEach((k) => { ctx.fillStyle = ciemniej(s.k.g, 0.15); ctx.beginPath(); ctx.moveTo(k * (W / 2 - h * 0.2), -h * 0.2); ctx.lineTo(k * (W / 2 + ogon), -h * 0.2); ctx.lineTo(k * (W / 2 + ogon * 0.7), h * 0.45); ctx.lineTo(k * (W / 2 + ogon), h * 1.1 - h * 0.1); ctx.lineTo(k * (W / 2 - h * 0.2), h * 1.0); ctx.closePath(); ctx.fill();
      ctx.fillStyle = ko; ctx.beginPath(); ctx.moveTo(k * W / 2, h / 2); ctx.lineTo(k * (W / 2 - h * 0.2), h * 1.0); ctx.lineTo(k * (W / 2 - h * 0.2), h / 2); ctx.closePath(); ctx.fill(); });
    ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.moveTo(-W / 2, -h / 2); ctx.quadraticCurveTo(0, -h * 0.75, W / 2, -h / 2); ctx.lineTo(W / 2, h / 2); ctx.quadraticCurveTo(0, h * 0.25, -W / 2, h / 2); ctx.closePath(); ctx.fill(); bezCienia(ctx);
    ctx.globalAlpha = s.alfa * clamp(e * 2 - 0.8); ctx.fillStyle = kontrast(s.k.g); const zn = Array.from(t); let x = -tw / 2; zn.forEach((c) => { const cw = ctx.measureText(c).width, f = (x + cw / 2) / (W / 2); ctx.save(); ctx.translate(x + cw / 2, -h * 0.12 * (1 - f * f)); ctx.rotate(f * 0.12); ctx.fillText(c, -cw / 2, 0); ctx.restore(); x += cw; }); ctx.restore();
  }, { pola: ["tekst"], dom: { pozycja: "srodek" } });
  ksztaltN("ksztalt-tarcza", "Tarcza z ptaszkiem (gwarancja)", { tekst: "Gwarancja jakości" }, (s) => {
    const ctx = s.ctx, r = 150 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y - r * 0.35, e = E.outBackMocno(T(s, 0, 0.5)), ksz = (k) => { ctx.beginPath(); ctx.moveTo(0, -r * k); ctx.quadraticCurveTo(r * 0.55 * k, -r * 0.75 * k, r * 0.95 * k, -r * 0.8 * k); ctx.quadraticCurveTo(r * 1.0 * k, r * 0.35 * k, 0, r * 1.1 * k); ctx.quadraticCurveTo(-r * 1.0 * k, r * 0.35 * k, -r * 0.95 * k, -r * 0.8 * k); ctx.quadraticCurveTo(-r * 0.55 * k, -r * 0.75 * k, 0, -r * k); ctx.closePath(); };
    ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); cien(s, ctx, 1.3); ctx.fillStyle = s.k.g; ksz(1); ctx.fill(); bezCienia(ctx); ctx.fillStyle = ciemniej(s.k.g, 0.2); ksz(0.82); ctx.fill();
    ptaszek(ctx, 0, r * 0.02, r * 0.48, E.outCubic(T(s, 0.35, 0.4)), "#FFFFFF", r * 0.15);
    const b = T(s, 0.8, 0.6); if (b > 0 && b < 1) { ctx.save(); ksz(1); ctx.clip(); const x = lerp(-r * 1.6, r * 1.6, b); ctx.fillStyle = "rgba(255,255,255,0.35)"; ctx.beginPath(); ctx.moveTo(x - r * 0.2, -r * 1.2); ctx.lineTo(x + r * 0.15, -r * 1.2); ctx.lineTo(x - r * 0.25, r * 1.2); ctx.lineTo(x - r * 0.6, r * 1.2); ctx.closePath(); ctx.fill(); ctx.restore(); }
    ctx.restore(); podpis(s, cy + r * 1.45, E.outCubic(T(s, 0.4, 0.5)), 56);
  }, { pola: ["tekst"], dom: { pozycja: "srodek" } });
  ksztaltN("ksztalt-medal", "Rozeta / medal z napisem", { tekst: "NR 1", tekst2: "w regionie" }, (s) => {
    const ctx = s.ctx, r = 150 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y - r * 0.3, t0 = s.t - 0.05, kat = 0.4 * Math.exp(-t0 * 3) * Math.cos(t0 * 8) * (t0 > 0 ? 1 : 0), e = E.outBack(T(s, 0, 0.5));
    ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); ctx.rotate(kat); cien(s, ctx, 1.2);
    [-1, 1].forEach((k) => { ctx.fillStyle = k < 0 ? s.k.g : ciemniej(s.k.g, 0.2); ctx.beginPath(); ctx.moveTo(k * r * 0.15, r * 0.5); ctx.lineTo(k * r * 0.75, r * 1.75); ctx.lineTo(k * r * 0.48, r * 1.58); ctx.lineTo(k * r * 0.4, r * 1.9); ctx.lineTo(k * r * -0.2, r * 0.6); ctx.closePath(); ctx.fill(); });
    ctx.fillStyle = s.k.a; ctx.beginPath(); for (let i = 0; i <= 96; i++) { const a = i / 96 * PI * 2, q = r * (1 + 0.07 * Math.cos(a * 16)); i ? ctx.lineTo(Math.cos(a) * q, Math.sin(a) * q) : ctx.moveTo(Math.cos(a) * q, Math.sin(a) * q); } ctx.closePath(); ctx.fill(); bezCienia(ctx);
    ctx.fillStyle = ciemniej(s.k.a, 0.12); ctx.beginPath(); ctx.arc(0, 0, r * 0.78, 0, PI * 2); ctx.fill(); ctx.strokeStyle = rgba(kontrast(s.k.a), 0.5); ctx.lineWidth = 3 * s.u; ctx.beginPath(); ctx.arc(0, 0, r * 0.7, 0, PI * 2); ctx.stroke();
    const t = tekstP(s, s.p.tekst), p = dopasuj(s, t, r * 0.5, r * 1.2, 900); ctx.font = font(s, p, 900); ctx.fillStyle = kontrast(s.k.a); ctx.fillText(t, -ctx.measureText(t).width / 2, s.p.tekst2 ? -r * 0.08 : 0);
    if (s.p.tekst2) { const p2 = dopasuj(s, s.p.tekst2, r * 0.17, r * 1.1, 700); ctx.font = font(s, p2, 700); ctx.fillText(s.p.tekst2, -ctx.measureText(s.p.tekst2).width / 2, r * 0.32); }
    ctx.restore();
  }, { pola: ["tekst", "tekst2"], dom: { pozycja: "srodek" } });

  // ---------- przejścia (v18, cały kadr) ----------
  przejscieN("przejscie-iris", "Przejście: przesłona (iris)", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), [cx, cy] = punkt(s), R = Math.hypot(Math.max(cx, s.W - cx), Math.max(cy, s.H - cy)) * 1.02, r = b > 0 ? R * b : R * (1 - a);
    const c = warstwa(s, "iris", (x) => { x.fillStyle = s.k.tl; x.fillRect(0, 0, s.W, s.H); if (r > 0.5) { x.globalCompositeOperation = "destination-out"; x.beginPath(); x.arc(cx, cy, r, 0, PI * 2); x.fill(); } });
    ctx.drawImage(c, 0, 0); if (r > 0.5 && r < R) { ctx.strokeStyle = s.k.a; ctx.lineWidth = 14 * s.u; ctx.beginPath(); ctx.arc(cx, cy, r, 0, PI * 2); ctx.stroke(); }
  }, { pola: ["xy"] });
  przejscieN("przejscie-miekka-zaslona", "Przejście: miękka zasłona", (s) => {
    const ctx = s.ctx, p = E.inOutCubic(clamp(s.t / s.T)), F = s.W * 0.45, x1 = lerp(-F, s.W * 2 + F, p), x0 = x1 - s.W * 1.2 - F;
    const g = ctx.createLinearGradient(x0 - F, 0, x1 + F, 0), L = x1 + F - (x0 - F), st = (v) => clamp((v - (x0 - F)) / L);
    g.addColorStop(0, rgba(s.k.g, 0)); g.addColorStop(st(x0), rgba(s.k.g, 1)); g.addColorStop(st(x1), rgba(s.k.g, 1)); g.addColorStop(1, rgba(s.k.g, 0)); ctx.fillStyle = g; ctx.fillRect(0, 0, s.W, s.H);
  });
  przejscieN("przejscie-swiatlo", "Przejście: rozbłysk światła (light leak)", (s) => {
    const ctx = s.ctx, p = clamp(s.t / s.T), szczyt = Math.sin(p * PI), c = warstwa(s, "swiatlo", (x) => {
      x.globalCompositeOperation = "lighter"; [[s.k.a, 0.0, 0.9], [s.k.g, 0.25, 1.1], ["#FFF2D6", 0.5, 0.7]].forEach(([k, o, rr], i) => { const cx = lerp(-s.W * 0.3, s.W * 1.3, clamp(p * 1.2 - o * 0.3)) , cy = s.H * (0.3 + i * 0.25) + Math.sin(p * 4 + i) * s.H * 0.1, R = Math.max(s.W, s.H) * rr * (0.6 + szczyt * 0.6), g = x.createRadialGradient(cx, cy, 0, cx, cy, R);
        g.addColorStop(0, rgba(k, 0.95 * szczyt)); g.addColorStop(0.5, rgba(k, 0.45 * szczyt)); g.addColorStop(1, rgba(k, 0)); x.fillStyle = g; x.fillRect(0, 0, s.W, s.H); });
      x.fillStyle = `rgba(255,255,255,${Math.pow(szczyt, 6) * 0.9})`; x.fillRect(0, 0, s.W, s.H); });
    ctx.drawImage(c, 0, 0);
  }, { czas: 1.4 });
  przejscieN("przejscie-flara", "Przejście: flara obiektywu", (s) => {
    const ctx = s.ctx, p = clamp(s.t / s.T), sz = Math.sin(p * PI), cx = lerp(-s.W * 0.1, s.W * 1.1, E.inOutCubic(p)), cy = s.H * 0.42, c = warstwa(s, "flara", (x) => {
      x.globalCompositeOperation = "lighter"; const g = x.createRadialGradient(cx, cy, 0, cx, cy, Math.max(s.W, s.H) * 0.7 * sz + 1); g.addColorStop(0, `rgba(255,255,255,${sz})`); g.addColorStop(0.15, rgba(s.k.a, 0.8 * sz)); g.addColorStop(1, rgba(s.k.g, 0)); x.fillStyle = g; x.fillRect(0, 0, s.W, s.H);
      const h = 30 * s.u * (0.5 + sz), gs = x.createLinearGradient(0, cy - h, 0, cy + h); gs.addColorStop(0, "rgba(255,255,255,0)"); gs.addColorStop(0.5, `rgba(255,255,255,${0.9 * sz})`); gs.addColorStop(1, "rgba(255,255,255,0)"); x.fillStyle = gs; x.fillRect(0, cy - h, s.W, h * 2);
      for (let i = 1; i <= 4; i++) { const k = 1 - i * 0.45, gx = s.W / 2 + (cx - s.W / 2) * k * -1, gy = s.H / 2 + (cy - s.H / 2) * k * -1, r = (40 + i * 30) * s.u; x.fillStyle = rgba(i % 2 ? s.k.a : s.k.g, 0.25 * sz); x.beginPath(); for (let j = 0; j < 6; j++) { const a = j / 6 * PI * 2; j ? x.lineTo(gx + Math.cos(a) * r, gy + Math.sin(a) * r) : x.moveTo(gx + Math.cos(a) * r, gy + Math.sin(a) * r); } x.closePath(); x.fill(); }
      x.fillStyle = `rgba(255,255,255,${Math.pow(sz, 8) * 0.95})`; x.fillRect(0, 0, s.W, s.H); });
    ctx.drawImage(c, 0, 0);
  }, { czas: 1.2 });
  przejscieN("przejscie-zoom-promienie", "Przejście: zoom z promieniami", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), cx = s.W / 2, cy = s.H / 2, D = Math.hypot(s.W, s.H) / 2, sila = Math.sin(clamp(s.t / s.T) * PI);
    ctx.save(); ctx.translate(cx, cy); for (let i = 0; i < 70; i++) { const k = los(i * 1.9) * PI * 2, r0 = D * (0.25 + los(i * 3.3) * 0.5) * (1 - sila * 0.7), L = D * (0.3 + los(i * 4.7) * 0.6) * sila; ctx.strokeStyle = rgba(i % 3 ? "#FFFFFF" : s.k.a, 0.7 * sila); ctx.lineWidth = (2 + los(i) * 6) * s.u; ctx.beginPath(); ctx.moveTo(Math.cos(k) * r0, Math.sin(k) * r0); ctx.lineTo(Math.cos(k) * (r0 + L), Math.sin(k) * (r0 + L)); ctx.stroke(); } ctx.restore();
    const r = D * 1.05 * (b > 0 ? 1 : E.inExpo(a)), c = warstwa(s, "zoomprom", (x) => { x.fillStyle = s.k.g; x.beginPath(); x.arc(cx, cy, Math.max(0.1, r), 0, PI * 2); x.fill(); if (b > 0) { x.globalCompositeOperation = "destination-out"; x.beginPath(); x.arc(cx, cy, Math.max(0.1, D * 1.05 * E.outExpo(b)), 0, PI * 2); x.fill(); } });
    ctx.drawImage(c, 0, 0);
  }, { czas: 1 });
  function plamaAtr(x, cx, cy, R, z) { x.beginPath(); const n = 28; for (let i = 0; i <= n; i++) { const k = i / n * PI * 2, r = R * (0.82 + 0.18 * Math.sin(k * 5 + z) * Math.sin(k * 3 + z * 2) + 0.1 * los(i + z * 7)); i ? x.lineTo(cx + Math.cos(k) * r, cy + Math.sin(k) * r) : x.moveTo(cx + Math.cos(k) * r, cy + Math.sin(k) * r); } x.closePath(); x.fill(); }
  przejscieN("przejscie-atrament", "Przejście: plamy atramentu", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), D = Math.hypot(s.W, s.H), pk = [[0.5, 0.5, 0], [0.2, 0.25, 0.08], [0.8, 0.3, 0.12], [0.3, 0.8, 0.06], [0.75, 0.75, 0.15]];
    const c = warstwa(s, "atrament", (x) => { x.fillStyle = s.k.tl; pk.forEach(([px, py, o], i) => { const e = E.inOutCubic(clamp((a - o) / (1 - o))); if (e > 0) plamaAtr(x, px * s.W, py * s.H, D * 0.42 * e, i * 3.1); });
      if (b > 0) { x.globalCompositeOperation = "destination-out"; pk.forEach(([px, py, o], i) => { const e = E.inOutCubic(clamp((b - o) / (1 - o))); if (e > 0) plamaAtr(x, (1 - px) * s.W, (1 - py) * s.H, D * 0.42 * e, i * 5.7 + 2); }); } });
    ctx.drawImage(c, 0, 0);
  });
  function pedzel(x, s, y, h, f0, f1, z, kol) { const xa = lerp(-s.W * 0.15, s.W * 1.15, f0), xb = lerp(-s.W * 0.15, s.W * 1.15, f1); if (xb <= xa) return; x.fillStyle = kol; x.beginPath(); const n = 30; for (let i = 0; i <= n; i++) { const xx = lerp(xa, xb, i / n); x.lineTo(xx, y - h / 2 + (los(i * 2.1 + z) - 0.5) * h * 0.16 + Math.sin(i * 0.7 + z) * h * 0.04); } for (let k = 1; k < 8; k++) x.lineTo(xb + (los(k * 5.3 + z) - 0.3) * h * 0.3 * (1 - Math.abs(k - 4) / 5), y - h / 2 + h * k / 8); for (let i = n; i >= 0; i--) { const xx = lerp(xa, xb, i / n); x.lineTo(xx, y + h / 2 + (los(i * 3.7 + z) - 0.5) * h * 0.16 + Math.sin(i * 0.9 + z) * h * 0.04); } for (let k = 7; k > 0; k--) x.lineTo(xa - (los(k * 8.1 + z) - 0.3) * h * 0.3 * (1 - Math.abs(k - 4) / 5), y - h / 2 + h * k / 8); x.closePath(); x.fill();
    x.globalAlpha = 0.25; x.fillStyle = "#000000"; for (let k = 0; k < 6; k++) { const yy = y - h * 0.4 + los(k * 9 + z) * h * 0.8; x.fillRect(xa, yy, xb - xa, 1.5 * s.u); } x.globalAlpha = 1; }
  przejscieN("przejscie-pedzel", "Przejście: pociągnięcia pędzlem", (s) => {
    const ctx = s.ctx, n = 5, h = s.H / n * 1.35, [a, b] = fazy(s);
    const c = warstwa(s, "pedzel", (x) => { for (let i = 0; i < n; i++) { const y = (i + 0.5) * s.H / n, st = i * 0.12, e = E.inOutCubic(clamp((a - st) / 0.52)), e2 = E.inOutCubic(clamp((b - st) / 0.52)), lewo = i % 2 === 1;
      const f0 = lewo ? 1 - e : e2, f1 = lewo ? 1 - e2 : e; if (lewo) pedzel(x, s, y, h, Math.min(f0, f1), Math.max(f0, f1), i * 4, i % 2 ? s.k.a : s.k.g); else pedzel(x, s, y, h, f0, f1, i * 4, i % 2 ? s.k.a : s.k.g); } });
    ctx.drawImage(c, 0, 0);
  }, { czas: 1.4 });
  przejscieN("przejscie-kafelki-fala", "Przejście: fala obracających się kwadratów", (s) => {
    const ctx = s.ctx, k = Math.min(s.W, s.H) / 6, nx = Math.ceil(s.W / k) + 1, ny = Math.ceil(s.H / k) + 1, maxd = nx + ny;
    for (let i = 0; i < nx; i++) for (let j = 0; j < ny; j++) { const d = (i + j) / maxd, a = E.inOutCubic(clamp((s.t / s.T * 2 - d * 0.6) / 0.4)), b = E.inOutCubic(clamp(((s.t / s.T - 0.5) * 2 - d * 0.6) / 0.4)), q = a - b; if (q <= 0) continue;
      ctx.save(); ctx.translate(i * k + k / 2, j * k + k / 2); ctx.rotate((1 - a) * PI / 2 + b * PI / 2); const z = k * 1.45 * q; ctx.fillStyle = (i + j) % 2 ? s.k.g : ciemniej(s.k.g, 0.12); ctx.fillRect(-z / 2, -z / 2, z, z); ctx.restore(); }
  });
  przejscieN("przejscie-heksagony", "Przejście: plaster miodu", (s) => {
    const ctx = s.ctx, r = Math.min(s.W, s.H) / 7, w = r * Math.sqrt(3), cx = s.W / 2, cy = s.H / 2, D = Math.hypot(cx, cy) + r, p = clamp(s.t / s.T);
    for (let j = -1; j * r * 1.5 < s.H + r * 2; j++) for (let i = -1; i * w < s.W + w; i++) { const x = i * w + (j % 2 ? w / 2 : 0), y = j * r * 1.5, d = Math.hypot(x - cx, y - cy) / D, a = E.outBack(clamp((p * 2 - d * 0.55) / 0.45)), b = E.inCubic(clamp(((p - 0.5) * 2 - d * 0.55) / 0.45)), q = Math.max(0, a - b); if (q <= 0) continue;
      ctx.fillStyle = (i + j) % 3 === 0 ? s.k.a : s.k.g; ctx.beginPath(); for (let k = 0; k < 6; k++) { const ang = PI / 6 + k * PI / 3, rr = r * 1.04 * q; k ? ctx.lineTo(x + Math.cos(ang) * rr, y + Math.sin(ang) * rr) : ctx.moveTo(x + Math.cos(ang) * rr, y + Math.sin(ang) * rr); } ctx.closePath(); ctx.fill(); }
  }, { czas: 1.3 });
  przejscieN("przejscie-raster", "Przejście: rastrowe kropki", (s) => {
    const ctx = s.ctx, k = Math.min(s.W, s.H) / 14, nx = Math.ceil(s.W / k) + 1, ny = Math.ceil(s.H / k) + 1, p = clamp(s.t / s.T); ctx.fillStyle = s.k.g;
    for (let i = 0; i < nx; i++) for (let j = 0; j < ny; j++) { const d = (i / nx + j / ny) / 2, a = clamp((p * 2 - d * 0.7) / 0.3), b = clamp(((p - 0.5) * 2 - d * 0.7) / 0.3), q = a - b; if (q <= 0) continue; ctx.beginPath(); ctx.arc(i * k, j * k, k * 0.75 * E.inOutCubic(q), 0, PI * 2); ctx.fill(); }
  });
  przejscieN("przejscie-paski-spadaja", "Przejście: spadające paski", (s) => {
    const ctx = s.ctx, n = 9, w = s.W / n, p = clamp(s.t / s.T);
    for (let i = 0; i < n; i++) { const o = los(i * 3.3) * 0.18, a = E.outBounce(clamp((p - o) / 0.38)), b = E.inCubic(clamp((p - 0.52 - o * 0.8) / 0.4)), y0 = -s.H + s.H * a + s.H * b; ctx.fillStyle = [s.k.g, s.k.a, ciemniej(s.k.g, 0.2)][i % 3]; ctx.fillRect(i * w - 0.5, y0, w + 1, s.H); }
  }, { czas: 1.4 });
  przejscieN("przejscie-zegar", "Przejście: wskazówka zegara", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), cx = s.W / 2, cy = s.H / 2, D = Math.hypot(s.W, s.H), k0 = -PI / 2 + PI * 2 * b, k1 = -PI / 2 + PI * 2 * a;
    if (k1 - k0 > 0.001) { ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.moveTo(cx, cy); if (k1 - k0 >= PI * 2 - 1e-3) { ctx.rect(0, 0, s.W, s.H); } else { ctx.arc(cx, cy, D, k0, k1); ctx.closePath(); } ctx.fill(); }
    const kw = a < 1 ? k1 : k0; if (a < 1 || b > 0) { ctx.strokeStyle = s.k.a; ctx.lineWidth = 16 * s.u; ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(kw) * D, cy + Math.sin(kw) * D); ctx.stroke(); }
  });
  przejscieN("przejscie-kwadrat-obrot", "Przejście: obracający się kwadrat", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), cx = s.W / 2, cy = s.H / 2, D = Math.hypot(s.W, s.H) * 1.05, c = warstwa(s, "kwobr", (x) => {
      const kw = (q, rot) => { x.save(); x.translate(cx, cy); x.rotate(rot); x.fillRect(-q / 2, -q / 2, q, q); x.restore(); };
      x.fillStyle = s.k.g; kw(D * a, (1 - a) * PI); x.fillStyle = s.k.a; if (a < 1) { x.globalAlpha = 0.9; kw(D * a * 0.6, (1 - a) * -PI * 1.5); x.globalAlpha = 1; } if (b > 0) { x.setTransform(1, 0, 0, 1, 0, 0); x.globalCompositeOperation = "destination-out"; const q = D * b, rot = b * PI, cs = Math.cos(rot), sn = Math.sin(rot); x.beginPath(); [[-1, -1], [1, -1], [1, 1], [-1, 1]].forEach(([u, v], i) => { const px = u * q / 2, py = v * q / 2, X = cx + px * cs - py * sn, Y = cy + px * sn + py * cs; i ? x.lineTo(X, Y) : x.moveTo(X, Y); }); x.closePath(); x.fill(); } });
    ctx.drawImage(c, 0, 0);
  });
  function poszarpana(ctx, s, y, gora, z) { const n = 26; ctx.beginPath(); ctx.moveTo(0, gora ? s.H * 3 : -s.H * 3); ctx.lineTo(0, y); for (let i = 1; i <= n; i++) ctx.lineTo(s.W * i / n, y + (los(i * 2.7 + z) - 0.5) * 70 * s.u + Math.sin(i * 1.3 + z) * 14 * s.u); ctx.lineTo(s.W, gora ? s.H * 3 : -s.H * 3); ctx.closePath(); }
  przejscieN("przejscie-papier", "Przejście: podarty papier", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), kol = jasnosc(s.k.tl) > 0.6 ? s.k.tl : "#F4EFE6", m = 70 * s.u, yG = lerp(s.H + m, -m, a), yD = b > 0 ? lerp(s.H + m, -m, b) : s.H * 3, n = 26;
    if (a <= 0) return; const kraw = (y, z) => { const p = []; for (let i = 0; i <= n; i++) p.push([s.W * i / n, y + (los(i * 2.7 + z) - 0.5) * 60 * s.u + Math.sin(i * 1.3 + z) * 12 * s.u]); return p; }, g = kraw(yG, 1), d = kraw(yD, 5).reverse();
    ctx.save(); ctx.beginPath(); g.forEach((q, i) => (i ? ctx.lineTo(...q) : ctx.moveTo(...q))); d.forEach((q) => ctx.lineTo(...q)); ctx.closePath(); ctx.fillStyle = kol; ctx.fill(); ctx.clip();
    ctx.fillStyle = "rgba(0,0,0,0.05)"; for (let i = 0; i < 40; i++) ctx.fillRect(0, los(i * 7) * s.H, s.W, 1.5 * s.u); ctx.restore();
    ctx.lineJoin = "round"; ctx.lineWidth = 7 * s.u; ctx.strokeStyle = "rgba(255,255,255,0.95)"; ctx.beginPath(); g.forEach((q, i) => (i ? ctx.lineTo(...q) : ctx.moveTo(...q))); ctx.stroke();
    if (b > 0) { ctx.strokeStyle = "rgba(0,0,0,0.18)"; ctx.beginPath(); d.forEach((q, i) => (i ? ctx.lineTo(...q) : ctx.moveTo(...q))); ctx.stroke(); }
  }, { czas: 1.3 });
  przejscieN("przejscie-nozyce", "Przejście: cięcie po skosie", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), dx = s.W, dy = s.H;
    [[s.k.g, 1], [s.k.a, -1]].forEach(([k, z]) => { const o = z * (1 - a) * 1.1 + z * b * 1.1; ctx.fillStyle = k; ctx.beginPath(); if (z > 0) { ctx.moveTo(-dx * o, -dy * o); ctx.lineTo(s.W - dx * o, -dy * o); ctx.lineTo(-dx * o, s.H - dy * o); } else { ctx.moveTo(s.W - dx * o, -dy * o); ctx.lineTo(s.W - dx * o, s.H - dy * o); ctx.lineTo(-dx * o, s.H - dy * o); } ctx.closePath(); ctx.fill(); });
    const l = Math.sin(clamp(s.t / s.T) * PI); if (l > 0.6) { ctx.strokeStyle = rgba("#FFFFFF", (l - 0.6) * 2.5); ctx.lineWidth = 8 * s.u; ctx.beginPath(); ctx.moveTo(s.W, 0); ctx.lineTo(0, s.H); ctx.stroke(); }
  });
  przejscieN("przejscie-wielki-napis", "Przejście: plansza z dużym napisem", (s) => {
    const ctx = s.ctx, p = clamp(s.t / s.T), a = E.inOutCubic(clamp(p / 0.35)), wy = E.inCubic(clamp((p - 0.72) / 0.28)), cx = s.W / 2, cy = s.H / 2, R = Math.hypot(cx, cy) * 1.02, y = -wy * s.H;
    ctx.save(); ctx.translate(0, y); ctx.fillStyle = s.k.g; ctx.beginPath(); if (a >= 1) ctx.rect(0, 0, s.W, s.H); else ctx.arc(cx, cy, Math.max(0.1, R * a), 0, PI * 2); ctx.fill();
    const e = E.outBackMocno(clamp((p - 0.25) / 0.2)); if (e > 0 && s.p.tekst) { const t = tekstP(s, bezGw(s.p.tekst)), px = dopasuj(s, t, 220 * s.u * s.p.rozmiar, s.W * 0.86, 900), sk = lerp(2.2, 1, e); ctx.translate(cx, cy); ctx.scale(sk, sk); ctx.globalAlpha = s.alfa * clamp(e * 2); ctx.font = font(s, px, 900); ctx.fillStyle = kontrast(s.k.g); ctx.fillText(t, -ctx.measureText(t).width / 2, 0); }
    ctx.restore();
  }, { czas: 1.8, pola: ["tekst"] });
  znajdz("przejscie-wielki-napis").przyklad = { tekst: "Rozdział 2", wielkie: true };
  przejscieN("przejscie-piksele", "Przejście: rozsypka pikseli", (s) => {
    const ctx = s.ctx, k = Math.min(s.W, s.H) / 18, nx = Math.ceil(s.W / k), ny = Math.ceil(s.H / k), p = clamp(s.t / s.T), kol = [s.k.g, ciemniej(s.k.g, 0.1), s.k.a];
    for (let i = 0; i < nx; i++) for (let j = 0; j < ny; j++) { const r1 = los(i * 13.1 + j * 7.7) * 0.42, r2 = los(i * 3.9 + j * 11.3) * 0.42; if (p < r1 || p > 0.55 + r2) continue; ctx.fillStyle = p > 0.42 && p < 0.58 ? s.k.g : kol[(i * 7 + j * 3) % 3]; ctx.fillRect(i * k, j * k, k + 1, k + 1); }
  });
  przejscieN("przejscie-babelki", "Przejście: bąbelki", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), n = 16, M = Math.max(s.W, s.H), kol = [s.k.g, s.k.a, ciemniej(s.k.g, 0.15)], F1 = lerp(s.H + M * 0.25, -M * 0.2, a), F2 = lerp(s.H + M * 0.3, -M * 0.3, b);
    if (a <= 0) return; const c = warstwa(s, "babelki", (x) => {
      x.fillStyle = s.k.g; x.fillRect(0, F1, s.W, (b > 0 ? F2 : s.H + M) - F1);
      for (let i = 0; i < n; i++) { const bx = (i + 0.5) / n * s.W + (los(i * 2.3) - 0.5) * s.W / n, r = (0.05 + los(i * 4.1) * 0.07) * M, by = F1 + r * (0.3 - los(i * 6.7) * 0.9) - Math.sin(s.t * 6 + i) * r * 0.05; x.fillStyle = kol[i % 3]; x.beginPath(); x.arc(bx, by, r, 0, PI * 2); x.fill(); }
      if (b > 0) { x.globalCompositeOperation = "destination-out"; for (let i = 0; i < n; i++) { const bx = (i + 0.5) / n * s.W + (los(i * 9.1) - 0.5) * s.W / n, r = (0.05 + los(i * 3.7) * 0.07) * M; x.beginPath(); x.arc(bx, F2 - r * (0.3 - los(i * 5.3) * 0.9), r, 0, PI * 2); x.fill(); } x.fillRect(0, F2, s.W, s.H + M); } });
    ctx.drawImage(c, 0, 0);
  });
  przejscieN("przejscie-wstegi", "Przejście: kolorowe wstęgi", (s) => {
    const ctx = s.ctx, p = clamp(s.t / s.T), kol = [s.k.a, s.k.g, ciemniej(s.k.g, 0.25)], D = Math.hypot(s.W, s.H);
    ctx.save(); ctx.translate(s.W / 2, s.H / 2); ctx.rotate(-0.35);
    kol.forEach((k, i) => { const o = i * 0.08, a = E.inOutCubic(clamp((p - o) / 0.5)), b = E.inOutCubic(clamp((p - 0.45 - o) / 0.5)), x1 = -D / 2 - D * 0.3 + (D * 1.6) * a, x0 = -D / 2 - D * 0.3 + (D * 1.6) * b; if (x1 <= x0) return;
      ctx.fillStyle = k; ctx.beginPath(); const n = 40, amp = D * 0.06; ctx.moveTo(x0 + Math.sin(0 + i) * amp, -D); for (let j = 0; j <= n; j++) { const y = -D + 2 * D * j / n; ctx.lineTo(x1 + Math.sin(j * 0.5 + i + p * 6) * amp, y); } for (let j = n; j >= 0; j--) { const y = -D + 2 * D * j / n; ctx.lineTo(x0 + Math.sin(j * 0.5 + i + p * 6) * amp, y); } ctx.closePath(); ctx.fill(); });
    ctx.restore();
  }, { czas: 1.4 });
  przejscieN("przejscie-drzwi", "Przejście: drzwi", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), q = b > 0 ? 1 - b : a, w = s.W / 2, kat = (1 - q) * PI / 2, sz = w * Math.cos(kat), pers = Math.sin(kat) * s.H * 0.12;
    [[0, 1], [s.W, -1]].forEach(([x0, k], i) => { if (sz < 1) return; ctx.fillStyle = i ? ciemniej(s.k.g, 0.1) : s.k.g; ctx.beginPath(); ctx.moveTo(x0, 0); ctx.lineTo(x0 + k * sz, pers); ctx.lineTo(x0 + k * sz, s.H - pers); ctx.lineTo(x0, s.H); ctx.closePath(); ctx.fill();
      ctx.fillStyle = `rgba(0,0,0,${Math.sin(kat) * 0.45})`; ctx.fill(); ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(x0 + k * sz * 0.85, s.H / 2, 12 * s.u * Math.cos(kat), 0, PI * 2); ctx.fill(); });
  }, { czas: 1.3 });
  przejscieN("przejscie-pierscienie", "Przejście: pierścienie", (s) => {
    const ctx = s.ctx, p = clamp(s.t / s.T), cx = s.W / 2, cy = s.H / 2, D = Math.hypot(cx, cy) * 1.05, n = 6;
    for (let i = 0; i < n; i++) { const o = i / n * 0.35, a = E.inOutCubic(clamp((p - o) / 0.45)), b = E.inOutCubic(clamp((p - 0.5 - (n - 1 - i) / n * 0.3) / 0.45)), rz = D * a, rw = D * b; if (rz <= rw) continue;
      ctx.fillStyle = i % 2 ? s.k.a : s.k.g; ctx.beginPath(); ctx.arc(cx, cy, rz, 0, PI * 2); if (rw > 0.5) { ctx.moveTo(cx + rw, cy); ctx.arc(cx, cy, rw, 0, PI * 2, true); } ctx.fill(); }
  });
  przejscieN("przejscie-whip", "Przejście: szybki przelot (whip)", (s) => {
    const ctx = s.ctx, p = clamp(s.t / s.T), sz = Math.sin(p * PI), pelne = E.inOutCubic(clamp((sz - 0.75) / 0.25));
    for (let i = 0; i < 46; i++) { const y = los(i * 3.1) * s.H, h = (4 + los(i * 1.7) * 26) * s.u * (0.4 + sz), L = s.W * (0.3 + los(i * 5.3) * 0.9) * sz, x = lerp(s.W * 1.2, -s.W * 1.2 - L, clamp(p * 1.15 - los(i * 2.2) * 0.15)) ; ctx.fillStyle = rgba([s.k.g, s.k.a, "#FFFFFF"][i % 3], 0.5 + 0.5 * sz); ctx.fillRect(x, y, L, h); }
    if (pelne > 0) { ctx.globalAlpha = pelne; ctx.fillStyle = s.k.g; ctx.fillRect(0, 0, s.W, s.H); ctx.globalAlpha = 1; }
  }, { czas: 0.9 });
  przejscieN("przejscie-zygzak", "Przejście: zygzakowata krawędź", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), z = Math.min(s.W, s.H) / 9, n = Math.ceil(s.H / z) + 2;
    const pas = (x, kol) => { ctx.fillStyle = kol; ctx.beginPath(); ctx.moveTo(-10, -z); for (let i = 0; i <= n; i++) ctx.lineTo(x + (i % 2 ? z * 0.6 : -z * 0.6), -z + i * z); ctx.lineTo(-10, s.H + z); ctx.closePath(); ctx.fill(); };
    ctx.save(); if (b > 0) { ctx.beginPath(); ctx.rect(0, 0, s.W, s.H); ctx.clip(); } const xa = lerp(-z, s.W + z * 1.2, a), xa2 = lerp(-z, s.W + z * 1.2, E.inOutCubic(clamp((s.t / s.T) * 2 - 0.15)));
    if (b <= 0) { pas(xa, s.k.a); pas(xa2, s.k.g); } else { const xb = lerp(-z, s.W + z * 1.2, b); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.moveTo(s.W + 10, -z); for (let i = 0; i <= n; i++) ctx.lineTo(xb + (i % 2 ? z * 0.6 : -z * 0.6), -z + i * z); ctx.lineTo(s.W + 10, s.H + z); ctx.closePath(); ctx.fill(); }
    ctx.restore();
  });
  przejscieN("przejscie-wypalenie", "Przejście: wypalona klisza", (s) => {
    const ctx = s.ctx, p = clamp(s.t / s.T), sz = Math.sin(p * PI), c = warstwa(s, "wypal", (x) => {
      x.globalCompositeOperation = "lighter"; for (let i = 0; i < 7; i++) { const cx = (los(i * 3.3) * 0.8 + 0.1) * s.W + Math.sin(p * 5 + i) * s.W * 0.1, cy = (los(i * 7.1) * 0.8 + 0.1) * s.H, R = Math.max(s.W, s.H) * (0.25 + los(i * 1.9) * 0.4) * (0.3 + sz * 1.1), g = x.createRadialGradient(cx, cy, 0, cx, cy, R);
        g.addColorStop(0, `rgba(255,250,235,${0.95 * sz})`); g.addColorStop(0.3, `rgba(255,170,60,${0.8 * sz})`); g.addColorStop(0.7, `rgba(200,50,10,${0.5 * sz})`); g.addColorStop(1, "rgba(120,0,0,0)"); x.fillStyle = g; x.fillRect(0, 0, s.W, s.H); }
      x.globalCompositeOperation = "source-over"; x.fillStyle = `rgba(255,236,200,${Math.pow(sz, 5)})`; x.fillRect(0, 0, s.W, s.H); });
    ctx.drawImage(c, 0, 0);
  }, { czas: 1.5 });
  przejscieN("przejscie-szklo", "Przejście: rozbite szkło", (s) => {
    const ctx = s.ctx, p = clamp(s.t / s.T), [a, b] = fazy(s), nx = 5, ny = Math.round(5 * s.H / s.W) || 3, kw = s.W / nx, kh = s.H / ny, pk = (i, j) => [i * kw + (i > 0 && i < nx ? (los(i * 7 + j * 3) - 0.5) * kw * 0.6 : 0), j * kh + (j > 0 && j < ny ? (los(i * 5 + j * 11) - 0.5) * kh * 0.6 : 0)];
    if (a <= 0) return; let n = 0;
    for (let i = 0; i < nx; i++) for (let j = 0; j < ny; j++) { const A = pk(i, j), B = pk(i + 1, j), C = pk(i + 1, j + 1), D = pk(i, j + 1); [[A, B, C], [A, C, D]].forEach((tr) => { n++; const cx = (tr[0][0] + tr[1][0] + tr[2][0]) / 3, cy = (tr[0][1] + tr[1][1] + tr[2][1]) / 3, d = los(n * 3.7) * 0.3, we = E.outCubic(clamp((a - d) / 0.7)), wy = E.inCubic(clamp((b - d) / 0.7)); if (we <= 0) return;
      const dx = (cx - s.W / 2) * (1 - we) * 1.2, dy = (cy - s.H / 2) * (1 - we) * 1.2 + wy * s.H * (1.2 + los(n) * 0.6), rot = (los(n * 5.1) - 0.5) * 3 * ((1 - we) + wy); ctx.save(); ctx.translate(cx + dx, cy + dy); ctx.rotate(rot); ctx.globalAlpha = clamp(we * 3);
      ctx.fillStyle = n % 3 ? s.k.g : ciemniej(s.k.g, 0.08); ctx.beginPath(); tr.forEach((q, k) => (k ? ctx.lineTo(q[0] - cx, q[1] - cy) : ctx.moveTo(q[0] - cx, q[1] - cy))); ctx.closePath(); ctx.fill(); if (wy > 0 || we < 1) { ctx.strokeStyle = "rgba(255,255,255,0.6)"; ctx.lineWidth = 2 * s.u; ctx.stroke(); } ctx.restore(); }); }
    void p;
  }, { czas: 1.5 });

  // ---------- dodatkowe (v18) ----------
  belkaN("belka-pytanie-widza", "Pytanie od widza (Q&A)", { tekst: "Jak zacząć montować na telefonie?", tekst2: "@ola.kreuje", przed: "Pytanie od widza" }, (s) => {
    const ctx = s.ctx, px = 46 * s.u * s.p.rozmiar, maxW = Math.min(s.W * 0.8, 900 * s.u), u = uloz(s, "„" + bezGw(s.p.tekst) + "”", px, { maxW: maxW - px * 1.6, align: "left", x: 0, y: 0, gora: true, lh: 1.25, waga: 700 }), pad = px * 0.8, lbh = px * 0.9;
    const W = Math.max(u.w, szerLinii(s, s.p.przed || "", px * 0.5, 800) + px) + pad * 2, H = u.h + pad * 2 + (s.p.tekst2 ? px * 1.1 : 0), x0 = xWyr(s, W), y0 = s.poz.y - H / 2, e = E.outQuint(T(s, 0, 0.55)), a = E.outBackMocno(T(s, 0.15, 0.4));
    karta(s, x0, y0, W * e, H, 22 * s.u, rgba(s.k.tl, 0.93)); ctx.fillStyle = s.k.a; ctx.fillRect(x0, y0 + 20 * s.u, 8 * s.u, (H - 40 * s.u) * e);
    if (s.p.przed) { const lb = String(s.p.przed).toLocaleUpperCase("pl"); ctx.save(); ctx.translate(x0 + pad, y0); ctx.scale(a, a); ctx.font = font(s, px * 0.5, 800); const lw = ctx.measureText(lb).width + px; ctx.fillStyle = s.k.a; zaokr(ctx, 0, -lbh / 2, lw, lbh, lbh / 2); ctx.fill(); ctx.fillStyle = kontrast(s.k.a); ctx.fillText(lb, px * 0.5, 0); ctx.restore(); }
    ctx.save(); ctx.beginPath(); ctx.rect(x0, y0, W * e, H); ctx.clip(); ctx.font = u.font; u.slowa.forEach((w) => { const k = T(s, 0.35 + w.i * 0.05, 0.25); if (k <= 0) return; ctx.globalAlpha = s.alfa * k; ctx.fillStyle = s.k.t; ctx.fillText(w.t, x0 + pad + w.x, y0 + pad + w.y + (1 - k) * 10 * s.u); });
    if (s.p.tekst2) { const k = E.outCubic(T(s, 0.5 + u.slowa.length * 0.05, 0.4)); ctx.globalAlpha = s.alfa * k; ctx.font = font(s, px * 0.62, 600); ctx.fillStyle = s.k.a; ctx.fillText("— " + s.p.tekst2, x0 + pad, y0 + pad + u.h + px * 0.55); } ctx.restore();
  }, { pola: ["tekst", "tekst2", "przed"], czas: 5 });
  ksztaltN("ksztalt-serce-reczne", "Serce rysowane ręcznie wokół punktu", { x: 0.5, y: 0.45 }, (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), r = 170 * s.u * s.p.rozmiar, pk = [];
    for (let i = 0; i <= 90; i++) { const t = -PI * 0.15 + i / 90 * PI * 2.2, x = 16 * Math.pow(Math.sin(t), 3), y = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)); pk.push([cx + x / 16 * r, cy + y / 16 * r]); }
    const e = E.inOutCubic(T(s, 0, 0.9)), puls = 1 + 0.04 * Math.max(0, Math.sin((s.t - 1) * 7)) * (s.t > 1 ? 1 : 0); ctx.save(); ctx.translate(cx, cy); ctx.scale(puls, puls); ctx.translate(-cx, -cy);
    ctx.strokeStyle = s.k.a; ctx.lineWidth = 10 * s.u * s.p.rozmiar; ctx.lineCap = "round"; ctx.lineJoin = "round"; cien(s); sciezkaCzesc(ctx, odrecznie(pk, 5 * s.u, 2), e); ctx.stroke(); ctx.restore();
  });
  liczbaN("liczby-segmenty", "Ile części z całości (segmenty)", { liczba: 3, od: 4, tekst2: "rolki z 4 mają napisy" }, (s) => {
    const ctx = s.ctx, n = Math.max(2, Math.min(12, Math.round(+s.p.od || 4))), k = clamp(Math.round(+s.p.liczba || 0), 0, n), r = 190 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y - r * 0.2, gap = 0.06, a = E.outBack(T(s, 0, 0.45));
    ctx.save(); ctx.translate(cx, cy); ctx.scale(a, a); ctx.lineWidth = r * 0.3;
    for (let i = 0; i < n; i++) { const k0 = -PI / 2 + i / n * PI * 2 + gap, k1 = -PI / 2 + (i + 1) / n * PI * 2 - gap, on = i < k, e = E.outBackMocno(T(s, 0.35 + i * 0.18, 0.35)); ctx.strokeStyle = rgba(s.k.t, 0.15); ctx.beginPath(); ctx.arc(0, 0, r, k0, k1); ctx.stroke();
      if (on && e > 0) { ctx.save(); ctx.scale(lerp(1.2, 1, clamp(e)), lerp(1.2, 1, clamp(e))); ctx.globalAlpha *= clamp(e * 2); ctx.strokeStyle = s.k.a; ctx.beginPath(); ctx.arc(0, 0, r, k0, k1); ctx.stroke(); ctx.restore(); } }
    const ile = Math.min(k, Math.max(0, Math.floor((s.t - 0.35) / 0.18 + 1))), t = `${ile}/${n}`; ctx.font = font(s, r * 0.55, 900); ctx.fillStyle = s.k.t; cien(s); ctx.fillText(t, -ctx.measureText(t).width / 2, 0); ctx.restore();
    podpis(s, cy + r * 1.4, E.outCubic(T(s, 0.6 + k * 0.18, 0.5)), 50, "tekst2");
  }, { pola: ["liczba", "od", "tekst2"], czas: 4 });
  tekstN("tekst-dopisek", "Tekst z odręcznym dopiskiem i strzałką", { tekst: "Montaż w *24 godziny*", tekst2: "serio!" }, (s) => {
    const ul = uloz(s, s.p.tekst, 96 * s.u * s.p.rozmiar), ctx = s.ctx; if (!ul.slowa.length) return; ctx.font = ul.font;
    const e = E.outCubic(T(s, 0, 0.5)); ctx.save(); ctx.globalAlpha = s.alfa * e; cien(s); ul.slowa.forEach((w) => piszSlowo(s, w, null, ctx, 0, (1 - e) * 24 * s.u)); ctx.restore();
    if (!s.p.tekst2) return; const cel = celWyr(ul), x1 = cel[cel.length - 1].x + cel[cel.length - 1].w, y1 = cel[0].y - ul.px * 0.6, nx = Math.min(s.W - 120 * s.u, x1 + 80 * s.u), ny = y1 - 150 * s.u * s.p.rozmiar;
    const a = E.inOutCubic(T(s, 0.5, 0.5)), pk = krzywa([nx - 10 * s.u, ny + 40 * s.u], [nx + 30 * s.u, y1 - 20 * s.u], [x1 - 10 * s.u, y1 + 5 * s.u], 30); ctx.strokeStyle = s.k.a; ctx.lineWidth = 6 * s.u * s.p.rozmiar; ctx.lineCap = "round"; ctx.lineJoin = "round";
    const { koniec, kier } = sciezkaCzesc(ctx, odrecznie(pk, 2.5 * s.u, 3), a); if (a > 0) ctx.stroke(); if (a > 0.9) grotStrzalki(ctx, koniec[0], koniec[1], kier, 26 * s.u * s.p.rozmiar);
    const b = E.outBackMocno(T(s, 0.85, 0.4)); if (b > 0) { const px = 64 * s.u * s.p.rozmiar; ctx.save(); ctx.translate(nx, ny); ctx.rotate(-0.12); ctx.scale(b, b); ctx.font = font(s, px, 700); ctx.fillStyle = s.k.a; const t = s.p.tekst2, w = ctx.measureText(t).width; ctx.fillText(t, -w / 2, 0); ctx.fillRect(-w / 2, px * 0.5, w * E.outCubic(T(s, 1.1, 0.4)), 4 * s.u); ctx.restore(); }
  }, { pola: ["tekst", "tekst2"], czas: 3.5 });
  rolkiN("rolki-budzik", "Budzik dzwoni", { tekst: "*Pobudka!* Czas na trening" }, (s) => {
    const ctx = s.ctx, r = 150 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y - r * 0.4, a = E.outBack(T(s, 0, 0.45)), dz = s.t > 0.5, drg = dz ? Math.sin(s.t * 60) * 0.08 : 0;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(a, a); ctx.rotate(drg); cien(s, ctx, 1.2);
    [-1, 1].forEach((k) => { ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(k * r * 0.62, -r * 0.82, r * 0.34, PI, 0); ctx.closePath(); ctx.save(); ctx.translate(k * r * 0.62, -r * 0.82); ctx.rotate(k * 0.6); ctx.translate(-k * r * 0.62, r * 0.82); ctx.fill(); ctx.restore(); ctx.strokeStyle = "#1F2937"; ctx.lineWidth = r * 0.1; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(k * r * 0.5, r * 0.8); ctx.lineTo(k * r * 0.7, r * 1.08); ctx.stroke(); });
    ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); bezCienia(ctx); ctx.fillStyle = "#FFFFFF"; ctx.beginPath(); ctx.arc(0, 0, r * 0.8, 0, PI * 2); ctx.fill();
    for (let i = 0; i < 12; i++) { ctx.save(); ctx.rotate(i * PI / 6); ctx.fillStyle = "#1F2937"; ctx.fillRect(-r * 0.02, -r * 0.72, r * 0.04, i % 3 ? r * 0.06 : r * 0.12); ctx.restore(); }
    ctx.strokeStyle = "#1F2937"; ctx.lineCap = "round"; ctx.lineWidth = r * 0.07; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(0, -r * 0.42); ctx.stroke(); ctx.lineWidth = r * 0.05; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(r * 0.5, 0); ctx.stroke(); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, r * 0.07, 0, PI * 2); ctx.fill(); ctx.restore();
    if (dz) { const f = (s.t * 2.5) % 1; ctx.strokeStyle = rgba(s.k.a, 1 - f); ctx.lineWidth = 7 * s.u; ctx.lineCap = "round"; [-1, 1].forEach((k) => { for (let j = 0; j < 3; j++) { const kk = -PI / 2 + k * (0.55 + j * 0.3), d1 = r * (1.25 + f * 0.25), d2 = r * (1.45 + f * 0.35); ctx.beginPath(); ctx.moveTo(cx + Math.cos(kk) * d1, cy + Math.sin(kk) * d1); ctx.lineTo(cx + Math.cos(kk) * d2, cy + Math.sin(kk) * d2); ctx.stroke(); } }); }
    podpis(s, cy + r * 1.5, E.outCubic(T(s, 0.4, 0.5)), 62);
  }, { czas: 3.5 });

  // ---------- rysowanie klatki ----------
  function stan(ctx, preset, t, p0, W, H) {
    const p = Object.assign({}, DOMYSLNE, preset.dom || {}, p0 || {});
    ["rozmiar", "tempo", "wyjscie", "waga", "liczba", "x", "y", "x2", "y2", "interlinia", "odstep", "szerokosc", "obrys", "cien_moc", "przesun_x", "przesun_y", "obrot", "krycie", "opoznienie"].forEach((k) => { if (p[k] !== "" && p[k] != null && !isNaN(+p[k])) p[k] = +p[k]; });
    if (!(p.tempo > 0)) p.tempo = 1;
    const T = +p.czas || preset.czas || 3;
    const poz = POZYCJE[p.pozycja] || POZYCJE[(preset.dom && preset.dom.pozycja) || "srodek"];
    if (!(p.interlinia > 0)) p.interlinia = 1; if (!(p.szerokosc > 0)) p.szerokosc = 1;
    return {
      ctx, p, t, T, W, H, u: Math.min(W, H) / 1080, alfa: 1,
      k: { g: p.kolor_glowny, a: p.kolor_akcent, t: p.kolor_tekstu, tl: p.kolor_tla },
      poz: { x: poz[0] * W, y: poz[1] * H, align: poz[2] },
      wyj: preset.pelne ? 0 : okno(t, T - p.wyjscie, p.wyjscie),
    };
  }
  function znajdz(id) { return PRESETY.find((x) => x.id === id) || null; }
  // dodatkowe wejście nakładane na każdy preset (panel: „Wejście całości”)
  const WEJSCIA = {
    "": null, "z-dolu": (e, s, ctx) => ctx.translate(0, (1 - E.outCubic(e)) * 140 * s.u), "z-gory": (e, s, ctx) => ctx.translate(0, -(1 - E.outCubic(e)) * 140 * s.u),
    "z-lewej": (e, s, ctx) => ctx.translate(-(1 - E.outCubic(e)) * 220 * s.u, 0), "z-prawej": (e, s, ctx) => ctx.translate((1 - E.outCubic(e)) * 220 * s.u, 0),
    "zoom": (e, s, ctx) => { const k = lerp(0.82, 1, E.outExpo(e)); ctx.translate(s.poz.x, s.poz.y); ctx.scale(k, k); ctx.translate(-s.poz.x, -s.poz.y); },
    "obrot": (e, s, ctx) => { ctx.translate(s.poz.x, s.poz.y); ctx.rotate((1 - E.outQuint(e)) * -0.2); ctx.translate(-s.poz.x, -s.poz.y); },
    "zanik": null,
  };
  function rysuj(ctx, id, t, p, W, H) {
    const preset = typeof id === "string" ? znajdz(id) : id;
    if (!preset) throw new Error("Nie ma presetu " + id);
    { const sp = (p || {}).sprezystosc; SPREZYNA = sp == null || sp === "" || isNaN(+sp) ? DOMYSLNE.sprezystosc : clamp(+sp, 0, 1.5); }
    const op = +((p || {}).opoznienie) || 0;
    if (op) { if (t < op) return stan(ctx, preset, 0, p, W, H); t -= op; }
    const s = stan(ctx, preset, t, p, W, H);
    if (t < 0 || t > s.T + 1e-6) return s;
    ctx.save();
    ctx.textBaseline = "middle"; ctx.textAlign = "left";
    const P = s.p;
    // przesunięcie, obrót i krycie całości
    if (P.przesun_x || P.przesun_y) ctx.translate(P.przesun_x * W, P.przesun_y * H);
    if (P.obrot) { ctx.translate(s.poz.x, s.poz.y); ctx.rotate(P.obrot * Math.PI / 180); ctx.translate(-s.poz.x, -s.poz.y); }
    const we = P.wejscie_styl && P.wejscie_styl !== "brak" ? okno(t, 0, 0.55 / P.tempo) : 1;
    if (we < 1 && WEJSCIA[P.wejscie_styl]) WEJSCIA[P.wejscie_styl](we, s, ctx);
    if (s.wyj > 0) {
      const e = E.inCubic(s.wyj), styl = P.wyjscie_styl;
      if (styl !== "brak") s.alfa = 1 - e;
      if (styl === "w-gore") ctx.translate(0, -60 * s.u * e);
      if (styl === "w-dol") ctx.translate(0, 60 * s.u * e);
      if (styl === "w-lewo") ctx.translate(-120 * s.u * e, 0);
      if (styl === "w-prawo") ctx.translate(120 * s.u * e, 0);
      if (styl === "zoom") { ctx.translate(s.poz.x, s.poz.y); ctx.scale(1 + 0.25 * e, 1 + 0.25 * e); ctx.translate(-s.poz.x, -s.poz.y); }
      if (styl === "zoom-out") { ctx.translate(s.poz.x, s.poz.y); ctx.scale(1 - 0.4 * e, 1 - 0.4 * e); ctx.translate(-s.poz.x, -s.poz.y); }
      if (styl === "rozmycie" && e > 0.02) ctx.filter = `blur(${(e * 24 * s.u).toFixed(1)}px)`;
    }
    if (P.wejscie_styl && P.wejscie_styl !== "brak" && we < 1) s.alfa *= E.outCubic(we);
    s.alfa *= P.krycie == null ? 1 : clamp(+P.krycie);
    ctx.globalAlpha = s.alfa;
    // odstęp liter i obrys tekstu działają na każdy napis rysowany przez preset
    const zmiany = [];
    if (P.odstep && "letterSpacing" in ctx) { const st = ctx.letterSpacing; ctx.letterSpacing = Math.round(P.odstep * 100 * s.u * P.rozmiar) + "px"; zmiany.push(() => (ctx.letterSpacing = st)); }
    if (P.obrys > 0) {
      const ft = ctx.fillText, gr = P.obrys * 4 * s.u * P.rozmiar;
      ctx.fillText = function (tx, x, y, m) {
        this.save(); this.strokeStyle = P.kolor_obrysu || "#000"; this.lineWidth = gr * 2; this.lineJoin = "round"; this.miterLimit = 2;
        if (m != null) this.strokeText(tx, x, y, m); else this.strokeText(tx, x, y); this.restore();
        return m != null ? ft.call(this, tx, x, y, m) : ft.call(this, tx, x, y);
      };
      zmiany.push(() => { try { delete ctx.fillText; } catch (e) {} if (ctx.fillText !== ft) ctx.fillText = ft; });
    }
    try { preset.rysuj(s); } finally { zmiany.forEach((f) => f()); ctx.restore(); }
    return s;
  }
  function czas(id, p) { const pr = znajdz(id); return (pr ? (+((p || {}).czas) || pr.czas || 3) : 3) + (+((p || {}).opoznienie) || 0); }
  /* Ile sekund od początku trwa wejście (do momentu, gdy obraz się uspokaja). Panel chroni ten fragment przy rozciąganiu na osi. */
  function wejscie(id, p, W = 180, H = 320) {
    const pr = znajdz(id); if (!pr) return 0.8;
    const T = czas(id, p), pw = (p || {}).wyjscie != null ? (p || {}).wyjscie : (pr.dom && pr.dom.wyjscie != null ? pr.dom.wyjscie : DOMYSLNE.wyjscie), wyj = pr.pelne ? 0 : (+pw || 0), granica = Math.max(0.2, T - wyj - 0.05);
    const c = nowyCanvas(W, H), x = c.getContext("2d");
    const klatka = (t) => { x.setTransform(1, 0, 0, 1, 0, 0); x.globalAlpha = 1; x.filter = "none"; x.clearRect(0, 0, W, H); try { rysuj(x, pr, t, p, W, H); } catch (e) {} return x.getImageData(0, 0, W, H).data.slice(); };
    const krok = 1 / 15, ruch = [];
    let poprz = klatka(0);
    for (let t = krok; t <= granica + 1e-6; t += krok) {
      const d = klatka(t); let zm = 0;
      for (let i = 3; i < d.length; i += 4) if (Math.abs(d[i] - poprz[i]) + Math.abs(d[i - 1] - poprz[i - 1]) + Math.abs(d[i - 2] - poprz[i - 2]) > 24) zm++;
      ruch.push({ t, r: zm > Math.max(2, W * H * 0.0002) }); poprz = d;
    }
    const ost = ruch.filter((k) => k.r).pop();
    if (!ost) return Math.min(granica, 0.3);
    // obraz stoi po ostatnim ruchu: chronimy wejście do tego miejsca, środek się wydłuża
    if (granica - ost.t >= 0.4) return +Math.min(granica, ost.t + krok).toFixed(2);
    // ruch trwa do końca (pasek postępu, lista pojawiająca się punkt po punkcie, migający kursor):
    // nic nie chronimy na początku, przy wydłużaniu cały ruch rozkłada się na dłuższy czas (wyjście zostaje stałe)
    return 0;
  }
  return {
    PRESETY, KATEGORIE, DOMYSLNE, POZYCJE, WEJSCIA, E, dodaj, znajdz, rysuj, czas, wejscie,
    ustawFabryke: (f) => { fabryka = f; },
    pomoc: { E, clamp, lerp, okno, los, rgba, kontrast, ciemniej, zaokr, gwiazda, serce, kursor, ptaszek, sciezkaCzesc, krzywa, uloz, znaki, dopasuj, font, tekstP, slowaZ, cien, bezCienia, piszSlowo, lista, pary, liczbaTekst, warstwa, punkt },
  };
});

/* Jak napisać preset (np. w narzedzia/animacje/wlasne/moj-preset.js):

NMAnim.dodaj({
  id: "moj-preset", nazwa: "Mój preset", kat: "wlasne", czas: 3,
  pola: ["tekst", "tekst2"],                 // które pola pokazać w panelu: tekst, tekst2, lista, liczba, od, przed, po, emoji, xy, xy2, logo
  dom: { pozycja: "dol" },                   // domyślne parametry tego presetu
  przyklad: { tekst: "Przykład" },           // tekst do podglądu w galerii
  rysuj(s) {
    // s.ctx (canvas 2D), s.t (s), s.T (czas całości), s.W, s.H, s.u (jednostka: 1 przy 1080 px krótszego boku),
    // s.p (parametry), s.k.g / s.k.a / s.k.t / s.k.tl (kolory marki: główny, akcent, tekst, tło), s.poz {x, y, align}
    const { okno, E, uloz, piszSlowo } = NMAnim.pomoc;
    const ul = uloz(s, s.p.tekst, 90 * s.u * s.p.rozmiar);
    s.ctx.font = ul.font;
    ul.slowa.forEach((w) => { const e = E.outCubic(okno(s.t, w.i * 0.1, 0.4)); s.ctx.globalAlpha = s.alfa * e; piszSlowo(s, w); });
  },
});

Zasady: tło przezroczyste (nie zamalowuj kadru, chyba że to przejście z pelne: true), kolory tylko z s.k,
font z s.p.font, wielkości mnożone przez s.u i s.p.rozmiar, wejście krótkie (do ~0,8 s / s.p.tempo),
wyjście robi biblioteka sama (s.alfa), więc używaj ctx.globalAlpha = s.alfa * ... zamiast = ....
*/
