"""Animacje z biblioteki (napisy, belki, grafiki do rolek, liczby, przejścia) jako pliki wideo z przezroczystością.

  python narzedzia/animacje.py lista [--gust spokojne] [--wszystkie]     presety (id, nazwa, kategoria, pola, gust);
         gust z narzedzia/animacje/gust.json: „spokojne” (pierwszy wybór), „social” (energiczne, z umiarem);
         presety „unikaj” (kicz, clip-art, efekciarskie przejścia) są ukryte, chyba że --wszystkie
  python narzedzia/animacje.py marka --klient klienci/<x>                 kolory, font i logo, których animacje użyją
  python narzedzia/animacje.py render --preset pop-slowa --wyjscie wyniki/<...>/napis.mov
         [--klient klienci/<x>] [--parametry '{"tekst": "Hej *Ty*", "czas": 3}'] [--format pion|poziom|kwadrat|1080x1920]
         [--fps 30] [--podglad]
  python narzedzia/animacje.py galeria --wyjscie wyniki/galeria.png [--klient klienci/<x>]

Wyjście .mov = ProRes 4444 z przezroczystością (kładziesz na ścieżce nad filmem w Premiere), .webm = z alfą do sieci,
.mp4 = na jednolitym tle. --podglad zapisuje obok arkusz 8 klatek (<nazwa>_podglad.png) do obejrzenia.

Marka klienta: klienci/<x>/animacje.json (zapisuje panel w Premiere albo Claude), a gdy go nie ma:
brandbook/karta_klienta.json (paleta: 1. kolor = główny, 2. = akcent; font nagłówków). Parametry z --parametry
wygrywają z marką. Własne presety: narzedzia/animacje/wlasne/*.js (wzór na końcu narzedzia/animacje/animacje.js).

Wymaga Node.js i jednorazowo: npm install w folderze narzedzia/animacje (robi to panel_premiere.py --instaluj i sprawdz.py).
"""
import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, wynik  # noqa: E402

FOLDER = Path(__file__).resolve().parent / "animacje"
FORMATY = {"pion": (1080, 1920), "poziom": (1920, 1080), "kwadrat": (1080, 1080), "4x5": (1080, 1350)}
OBRAZY = {".png", ".jpg", ".jpeg", ".webp"}


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


def node():
    n = shutil.which("node")
    if not n:
        blad("Brak Node.js. Zainstaluj ze strony nodejs.org (wersja LTS) i uruchom ponownie.")
    if not (FOLDER / "node_modules" / "@napi-rs" / "canvas").exists():
        npm = shutil.which("npm") or shutil.which("npm.cmd")
        if not npm:
            blad("Brak npm (instaluje się razem z Node.js).")
        r = subprocess.run([npm, "install", "--no-audit", "--no-fund"], cwd=FOLDER, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", shell=sys.platform == "win32")
        if r.returncode != 0:
            blad("Nie udało się zainstalować biblioteki do animacji (npm install w narzedzia/animacje): " + r.stderr[-400:])
    return n


def uruchom_node(args):
    r = subprocess.run([node(), str(FOLDER / "render.js"), *args], capture_output=True, text=True, encoding="utf-8", errors="replace")
    for linia in r.stderr.splitlines():
        if linia.startswith("POSTEP:"):
            print(linia, file=sys.stderr)
    try:
        d = json.loads(r.stdout[r.stdout.index("{"):])
    except Exception:
        blad("Render animacji nie zwrócił wyniku: " + (r.stderr or r.stdout)[-600:])
    if not d.get("ok"):
        blad(d.get("blad", "błąd renderu"))
    return d


def marka(klient):
    """Parametry marki dla animacji + lista plików fontów do wczytania."""
    if not klient:
        return {}, None
    f = sciezka(klient)
    p = {}
    karta = f / "brandbook" / "karta_klienta.json"
    if karta.exists():
        try:
            k = json.loads(karta.read_text(encoding="utf-8"))
            pal = k.get("paleta") or []
            if pal:
                p["kolor_glowny"] = pal[0]
            if len(pal) > 1:
                p["kolor_akcent"] = pal[1]
            if (k.get("fonts") or {}).get("heading"):
                p["font"] = k["fonts"]["heading"]
        except Exception:
            pass
    wlasne = f / "animacje.json"
    if wlasne.exists():
        try:
            p.update({k: v for k, v in json.loads(wlasne.read_text(encoding="utf-8")).items() if v not in (None, "")})
        except Exception:
            pass
    logo = p.pop("logo", None)
    if not logo:
        kand = sorted([x for x in (f / "logo").glob("*.*") if x.suffix.lower() in OBRAZY]) if (f / "logo").exists() else []
        kand += sorted(x for x in f.glob("logo*.*") if x.suffix.lower() in OBRAZY)
        logo = str(kand[0]) if kand else None
    return p, (str(sciezka(logo)) if logo else None)


def pliki_fontow(nazwa, klient, wagi=(400, 500, 600, 700, 800, 900)):
    if not nazwa:
        return []
    import fonty
    folder = sciezka(klient) / "fonty" if klient else None
    wyn = []
    for w in wagi:
        try:
            plik, _ = fonty.znajdz_wage(nazwa, w, folder, pobieraj=True)
            if plik and plik not in wyn:
                wyn.append(plik)
        except Exception:
            continue
    return wyn


def rozmiar(fmt):
    if fmt in FORMATY:
        return FORMATY[fmt]
    try:
        w, h = fmt.lower().split("x")
        return int(w), int(h)
    except Exception:
        blad(f"Format „{fmt}”: użyj pion, poziom, kwadrat, 4x5 albo np. 1080x1920.")


def render(preset, wyjscie, klient=None, parametry=None, fmt="pion", fps=30, podglad=False, tlo=None):
    p, logo = marka(klient)
    if parametry:
        p.update(json.loads(parametry) if isinstance(parametry, str) else parametry)
    W, H = rozmiar(fmt)
    cel = sciezka(wyjscie)
    spec = {"preset": preset, "parametry": p, "W": W, "H": H, "fps": fps, "wyjscie": str(cel),
            "fonty": pliki_fontow(p.get("font", "Montserrat"), klient), "logo": logo}
    if podglad:
        spec["podglad"] = str(cel.with_name(cel.stem + "_podglad.png"))
        if tlo:
            spec["tlo"] = str(sciezka(tlo))
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8") as t:
        json.dump(spec, t, ensure_ascii=False)
    try:
        d = uruchom_node(["--spec", t.name])
    finally:
        Path(t.name).unlink(missing_ok=True)
    d.pop("ok", None)
    wynik(**d, parametry=p, uwaga="Plik .mov połóż na ścieżce wideo nad filmem (ma przezroczyste tło).")


if __name__ == "__main__":
    a = argparse.ArgumentParser(description="Animacje z biblioteki")
    sub = a.add_subparsers(dest="tryb", required=True)
    li = sub.add_parser("lista"); li.add_argument("--gust", choices=["spokojne", "social"]); li.add_argument("--wszystkie", action="store_true")
    m = sub.add_parser("marka"); m.add_argument("--klient", required=True)
    r = sub.add_parser("render")
    r.add_argument("--preset", required=True); r.add_argument("--wyjscie", required=True)
    r.add_argument("--klient"); r.add_argument("--parametry"); r.add_argument("--format", default="pion")
    r.add_argument("--fps", type=int, default=30); r.add_argument("--podglad", action="store_true"); r.add_argument("--tlo")
    g = sub.add_parser("galeria"); g.add_argument("--wyjscie", required=True); g.add_argument("--klient")
    x = a.parse_args()
    if x.tryb == "lista":
        d = uruchom_node(["--lista"]); d.pop("ok", None)
        try:
            g = json.loads((FOLDER / "gust.json").read_text(encoding="utf-8"))
        except Exception:
            g = {}
        spok, unik = set(g.get("spokojne") or []), set(g.get("unikaj") or [])
        klucz = "presety" if isinstance(d.get("presety"), list) else None
        if klucz:
            for pr in d[klucz]:
                pr["gust"] = "spokojne" if pr["id"] in spok else "unikaj" if pr["id"] in unik else "social"
            ukryte = 0
            if not x.wszystkie:
                przed = len(d[klucz]); d[klucz] = [pr for pr in d[klucz] if pr["gust"] != "unikaj"]; ukryte = przed - len(d[klucz])
            if x.gust:
                d[klucz] = [pr for pr in d[klucz] if pr["gust"] == x.gust]
            d["uwaga_gust"] = (f"Ukryto {ukryte} presetów z listy „unikaj” (kicz, clip-art, efekciarskie przejścia): użyj ich tylko na wyraźną prośbę albo gdy wzór klienta je ma (--wszystkie). " if ukryte else "") + "Pierwszy wybór: gust „spokojne”. Zasady: sekcja „Gust: ruch, napisy i umiar” w CLAUDE.md."
        wynik(**d)
    elif x.tryb == "marka":
        p, logo = marka(x.klient); wynik(parametry=p, logo=logo)
    elif x.tryb == "render":
        render(x.preset, x.wyjscie, x.klient, x.parametry, x.format, x.fps, x.podglad, x.tlo)
    else:
        p, _ = marka(x.klient)
        d = uruchom_node(["--galeria", str(sciezka(x.wyjscie)), "--fonty", ",".join(pliki_fontow(p.get("font", "Montserrat"), x.klient))])
        d.pop("ok", None); wynik(**d)
