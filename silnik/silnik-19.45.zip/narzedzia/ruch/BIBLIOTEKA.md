# Biblioteka „Ruch”: jak zbudowana jest każda animacja

Każda pozycja to folder `narzedzia/ruch/biblioteka/<id>/` (albo `narzedzia/ruch/wlasne/<id>/` dla „Moje”) z dwoma plikami:

- `index.html`: kompozycja HyperFrames (HTML + CSS + GSAP). Wzór: `narzedzia/ruch/baza/start.html`.
- `meta.json`: opis dla panelu i dla Claude.

Render i podgląd: `python narzedzia/ruch.py render --szablon <id> --wyjscie x.mov --podglad [--tlo kadr.jpg] [--wartosci '{...}']`.
Szybki arkusz bez filmu: `python narzedzia/ruch.py klatki --szablon <id> --wyjscie arkusz.jpg`.

## index.html: zasady techniczne

- Ładuje dokładnie: `lib/ruch.css`, `lib/marka.css`, `lib/gsap.min.js` (w `<head>`), a na końcu `<body>` `lib/ruch.js` i potem własny `<script>`. Nic z internetu (żadnych CDN, Google Fonts, obrazków z sieci).
- Korzeń: `<div id="root" data-composition-id="main" data-start="0" data-duration="{{czas}}" data-width="{{W}}" data-height="{{H}}" data-motion-blur="on">`, a w nim jeden `<div class="clip" data-start="0" data-duration="{{czas}}">` z całą treścią. `{{W}}`, `{{H}}`, `{{czas}}` podmienia `ruch.py`.
- Tło przezroczyste (body bez tła). Wyjątek: przejścia i pełne plansze (`"pelny": true` w meta), które same zakrywają kadr.
- Skrypt: `const v = R.domyslne({...domyślne pól, czas: {{czas}}}); R.zastosujMarke();`, budowa DOM, `R.tekst()`, `R.dopasuj()`, `R.linie()`, potem `const os = R.os();` i ruch tylko na tej osi (`os.fromTo/ to/ set` z czasem jako 3. argumentem), na końcu `R.wyjscie(os, cele, {...})` i `os.seek(0)`.
- Wszystko liczone od `R.czas` (pole `czas` z panelu = długość klipu na osi): wejście na początku (0,3–0,9 s), trzymanie, zejście w ostatnich 0,25–0,4 s. Animacja musi wyglądać dobrze przy czasie od 1,5 s do 10 s.
- Rozmiary tylko w jednostkach zależnych od kadru: zmienne `--t-xxl … --t-xs`, `calc(var(--u) * Npx)`, `%`, `vw`/`vh`. Ta sama kompozycja ma działać w pionie 1080×1920, w poziomie 1920×1080 i w kwadracie (klasy `html.pion`, `html.poziom`, `html.kwadrat` do drobnych zmian układu).
- Kolory tylko ze zmiennych: `--glowny` (tło plakietek, plamy marki), `--akcent` (wyróżnienia, linie, przyciski), `--tekst` (tekst na ciemnym/zdjęciu), `--tekst-ciemny` (tekst na jasnej plakietce), `--tlo`. Font: `var(--font)` (nagłówki, `--waga`), `var(--font-tekst)` (dopiski). Wyróżnienie w tekście: `*słowo*` → klasa `akcent`.
- Pola z panelu czytasz z `v` (np. `v.tekst`, `v.tekst2`, `v.liczba`, `v.obraz`). Obraz/film z pola dostajesz jako ścieżkę względną (`lib/media/...`) albo pusty tekst: zawsze miej wersję bez obrazu (np. plama koloru).
- Pozycja bloku: `R.pozycja(el, v.pozycja)` (bezpieczne strefy telefonu wbudowane). Pole `pozycja` dodaj do meta, gdy ma sens.
- Bez zewnętrznych bibliotek poza GSAP. Bez `Math.random()` bez ziarna (render musi być powtarzalny: użyj prostego generatora z ziarnem).

- Liczby i wszystko, co zmienia się co klatkę, aktualizuj przez animowaną właściwość albo setter obiektu (`gsap.to(obj, {wartosc: 100})` z `set wartosc(v) { el.textContent = ... }`), nie przez `onUpdate`: HyperFrames przewija oś z wyłączonymi zdarzeniami i `onUpdate` w renderze się nie wykona.
- Zejście ma się skończyć przed końcem klipu (ostatnia klatka pusta): start zejścia najpóźniej `R.czas - dl - 0.07`. `R.wyjscie` robi to sam.
- Pola trafiają do HyperFrames z przedrostkiem `w_` (`R.v` go usuwa), więc pole może się nazywać jak token (`tekst`, `akcent`) bez psucia kolorów marki.

## meta.json

```json
{"id": "naglowek-maska", "nazwa": "Nagłówek z maski", "kat": "tekst", "czas": 3.5, "pelny": false,
 "opis": "Linie nagłówka wysuwają się spod niewidocznej krawędzi, akcent w kolorze marki. Spokojny, premium.",
 "gust": "spokojne",
 "pola": [
   {"id": "tekst", "typ": "tekst", "etykieta": "Nagłówek", "domyslnie": "Naturalne *woski* sojowe"},
   {"id": "tekst2", "typ": "tekst", "etykieta": "Dopisek", "domyslnie": ""},
   {"id": "pozycja", "typ": "wybor", "etykieta": "Pozycja", "opcje": ["lewy-dol", "srodek", "lewy-gora", "dol"], "domyslnie": "lewy-dol"}
 ]}
```
Typy pól: `tekst`, `tekst-dlugi`, `liczba`, `wybor` (z `opcje`), `kolor`, `obraz`, `film`, `przelacznik`. Kategorie (`kat`): `tekst`, `belki`, `liczby`, `cta`, `rolki`, `przejscia`, `tla`. `gust`: `spokojne` albo `social`.

## Zasady wyglądu (z sekcji „Gust” w CLAUDE.md)

- Nowocześnie i z umiarem: jak dobre rolki marek w 2026 r., nie jak szablon z prezentacji. Żadnych emoji, clip-artu, medali, gwiazdek, glitchy, neonów, tęcz, długich cieni.
- Duża typografia: nagłówek co najmniej `--t-l` (zwykle `--t-xl`), dopisek o połowę mniejszy, najwyżej 2 grubości, ciasna interlinia (0.95–1.05) i lekko ujemny odstęp liter w nagłówkach.
- Ruch: szybki start i miękkie hamowanie (`expo.out`, `power3.out`/`power4.out`), bez odbijania (`back`, `elastic`, `bounce` zakazane, poza gustem „social” i tam najwyżej `back.out(1.2)`). Kolejne elementy co 0,06–0,1 s. Jeden ruch na element. Odsłanianie maską, przesunięcie o 20–60 px z rozmyciem, skala 0.96→1, linie rysowane od lewej.
- Zejście krótsze od wejścia, spokojne (zanik, maska, lekki ruch w górę).
- Czytelność na każdym zdjęciu bez „pływającego” cienia: plakietka/pasek koloru, delikatny gradient pod tekstem albo bardzo krótki cień tylko do kontrastu.
- Bezpieczne strefy (pion): nic ważnego w górnych 14%, dolnych 25% i prawych 12% kadru.

## Kontrola przed oddaniem

1. `python narzedzia/ruch.py render --szablon <id> --wyjscie <tmp>.mov --podglad --tlo <zdjęcie albo film>` dla domyślnych wartości i dla długiego tekstu (np. 9 słów) oraz w formacie `poziom`.
2. Obejrzyj arkusz (Read): tekst się mieści, nic nie wychodzi poza kadr, jest czytelne, ruch ma fazy wejścia, trzymania i zejścia, nic nie stoi w bezpiecznej strefie.
3. Popraw i powtórz (do 3 razy).
