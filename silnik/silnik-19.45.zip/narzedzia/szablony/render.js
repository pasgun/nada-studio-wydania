/* Szablony rolek bez After Effects: podgląd, render do pliku i opis dla After Effects. Uruchamia go narzedzia/szablony.py.
 *
 *   node narzedzia/szablony/render.js --lista
 *   node narzedzia/szablony/render.js --galeria wyniki/galeria.png [--fonty a.ttf,b.ttf]
 *   node narzedzia/szablony/render.js --spec spec.json
 *
 * spec.json:
 * { "szablon": "ed-walizka", "W": 1080, "H": 1920, "fps": 30,
 *   "wartosci": {"pola": {"tytul": "..."}, "zdjecia": {"z1": "C:/zdjecia/a.jpg"}, "ustawieniaZdjec": {"z1": {"skala": 1.2, "x": 0, "y": -0.2, "bw": true}},
 *                "kolory": {"tl": "#111", "t": "#fff", "a": "#ff6b2c"}, "fonty": {"n": {"rodzina": "Oswald", "waga": 700}, "t": {"rodzina": "Montserrat"}}, "czas": 8},
 *   "fonty": ["pliki .ttf do wczytania"],
 *   "wyjscie": "plik.mov|.mp4|.webm",  "podglad": "arkusz.png",  "ae": "opis_dla_ae.json" }
 */
"use strict";
const fs = require("fs");
const path = require("path");
const cp = require("child_process");
const { createCanvas, GlobalFonts, loadImage } = require(require.resolve("@napi-rs/canvas", { paths: [path.join(__dirname, "..", "animacje")] }));
/* Node (@napi-rs/canvas): pełny okrąg ctx.arc(…, start, start + 2π) nic nie rysuje (w Premiere i Studio rysuje),
   więc pełne łuki dzielimy na dwie połówki. Dotyczy np. licznika w kółku przy 100%. */
(function () {
  const proto = Object.getPrototypeOf(createCanvas(1, 1).getContext("2d")), arc = proto.arc;
  proto.arc = function (x, y, r, a, b, ccw) {
    if (Math.abs(b - a) >= Math.PI * 2 - 1e-9) { const k = ccw ? -1 : 1; arc.call(this, x, y, r, a, a + k * Math.PI, ccw); return arc.call(this, x, y, r, a + k * Math.PI, a + k * Math.PI * 2 - k * 1e-6, ccw); }
    return arc.call(this, x, y, r, a, b, ccw);
  };
})();

const NMSzablony = require("./szablony.js");
global.NMSzablony = NMSzablony;
NMSzablony.ustawFabryke((w, h) => createCanvas(w, h));
const WLASNE = path.join(__dirname, "wlasne");
if (fs.existsSync(WLASNE)) for (const f of fs.readdirSync(WLASNE).filter((x) => x.endsWith(".js")).sort()) {
  try { require(path.join(WLASNE, f)); } catch (e) { process.stderr.write(`POSTEP: Błąd w szablonie ${f}: ${e.message}\n`); }
}

const arg = (n) => { const i = process.argv.indexOf(n); return i >= 0 ? process.argv[i + 1] : null; };
const wynik = (o) => process.stdout.write(JSON.stringify(Object.assign({ ok: true }, o), null, 1) + "\n");
const blad = (t) => { process.stdout.write(JSON.stringify({ ok: false, blad: t }) + "\n"); process.exit(1); };
function fonty(lista) { (lista || []).forEach((f) => { if (f && fs.existsSync(f)) GlobalFonts.registerFromPath(f); }); }
function szachownica(a, w, h, k) { for (let y = 0; y < h; y += k) for (let x = 0; x < w; x += k) { a.fillStyle = ((x / k + y / k) % 2) ? "#3a3a3a" : "#2b2b2b"; a.fillRect(x, y, k, k); } }

async function wartosci(w) {
  const v = Object.assign({}, w || {}), zd = {};
  for (const [k, p] of Object.entries(v.zdjecia || {})) { if (p && fs.existsSync(p)) zd[k] = await loadImage(p); }
  v.plikiZdjec = Object.assign({}, v.zdjecia || {});
  v.zdjecia = zd;
  return v;
}

async function render(spec) {
  const sz = NMSzablony.znajdz(spec.szablon);
  if (!sz) blad(`Nie ma szablonu „${spec.szablon}”. Lista: node narzedzia/szablony/render.js --lista`);
  fonty(spec.fonty);
  const W = spec.W || 1080, H = spec.H || 1920, fps = spec.fps || 30, v = await wartosci(spec.wartosci);
  const T = NMSzablony.czas(sz, v), n = Math.max(1, Math.round(T * fps));
  const c = createCanvas(W, H), ctx = c.getContext("2d"), out = {};
  [spec.ae, spec.podglad, spec.wyjscie].filter(Boolean).forEach((p) => fs.mkdirSync(path.dirname(path.resolve(p)), { recursive: true }));
  if (spec.ae) {
    const opis = NMSzablony.doAE(ctx, sz, v, W, H);
    fs.writeFileSync(spec.ae, JSON.stringify(opis, null, 1), "utf8");
    out.ae = path.resolve(spec.ae);
  }
  if (spec.podglad) {
    const kol = 4, ile = 8, sk = Math.min(1, 420 / H), w = Math.round(W * sk), h = Math.round(H * sk);
    const ark = createCanvas(w * kol, h * 2), a = ark.getContext("2d");
    for (let i = 0; i < ile; i++) {
      const t = (i + 0.5) / ile * T; ctx.clearRect(0, 0, W, H); NMSzablony.rysuj(ctx, sz, t, v, W, H);
      const x = (i % kol) * w, y = Math.floor(i / kol) * h;
      a.drawImage(c, x, y, w, h);
      a.fillStyle = "rgba(0,0,0,.6)"; a.fillRect(x, y, 64, 20); a.fillStyle = "#fff"; a.font = "13px sans-serif"; a.fillText(t.toFixed(1) + " s", x + 5, y + 14);
    }
    fs.mkdirSync(path.dirname(path.resolve(spec.podglad)), { recursive: true });
    fs.writeFileSync(spec.podglad, ark.toBuffer("image/png"));
    out.podglad = path.resolve(spec.podglad);
  }
  if (spec.wyjscie) {
    const plik = path.resolve(spec.wyjscie), ext = path.extname(plik).toLowerCase();
    fs.mkdirSync(path.dirname(plik), { recursive: true });
    const kod = ext === ".mov" ? ["-c:v", "prores_ks", "-profile:v", "4444", "-pix_fmt", "yuva444p10le", "-vendor", "apl0"]
      : ext === ".webm" ? ["-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p", "-b:v", "6M", "-auto-alt-ref", "0"]
      : ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "17"];
    const ff = cp.spawn(spec.ffmpeg || "ffmpeg", ["-hide_banner", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", `${W}x${H}`, "-r", String(fps), "-i", "-", ...kod, plik],
      { stdio: ["pipe", "ignore", "pipe"] });
    let err = ""; ff.stderr.on("data", (d) => (err += d));
    const pisz = (b) => new Promise((ok) => (ff.stdin.write(b) ? ok() : ff.stdin.once("drain", ok)));
    for (let i = 0; i < n; i++) {
      ctx.clearRect(0, 0, W, H); NMSzablony.rysuj(ctx, sz, i / fps, v, W, H);
      await pisz(Buffer.from(ctx.getImageData(0, 0, W, H).data.buffer));
      if (i % fps === 0) process.stderr.write(`POSTEP: Klatka ${i + 1} z ${n}\n`);
    }
    ff.stdin.end();
    if ((await new Promise((ok) => ff.on("close", ok))) !== 0) blad("ffmpeg: " + err.slice(-400));
    out.plik = plik;
  }
  wynik(Object.assign({ szablon: sz.id, czas_s: T, klatek: n, W, H }, out));
}

async function galeria(cel, f, t0) {
  fonty(f);
  const pr = NMSzablony.SZABLONY, kol = 8, w = 216, h = 384 + 22;
  const ark = createCanvas(kol * w, Math.ceil(pr.length / kol) * h), a = ark.getContext("2d"), c = createCanvas(540, 960), ctx = c.getContext("2d");
  a.fillStyle = "#111"; a.fillRect(0, 0, ark.width, ark.height);
  pr.forEach((s, i) => {
    const x = (i % kol) * w, y = Math.floor(i / kol) * h;
    try { ctx.clearRect(0, 0, 540, 960); NMSzablony.rysuj(ctx, s, t0 != null ? t0 : Math.min(s.czas - 0.8, 3), {}, 540, 960); a.drawImage(c, x + 2, y + 2, w - 4, h - 26); }
    catch (e) { a.fillStyle = "#f55"; a.font = "12px sans-serif"; a.fillText("BŁĄD " + e.message, x + 4, y + 30); }
    a.fillStyle = "#ddd"; a.font = "12px sans-serif"; a.fillText(s.id, x + 4, y + h - 8);
  });
  fs.writeFileSync(cel, ark.toBuffer("image/png"));
  wynik({ galeria: path.resolve(cel), szablonow: pr.length });
}

(async () => {
  try {
    if (process.argv.includes("--lista")) wynik({ kategorie: NMSzablony.KATEGORIE, szablony: NMSzablony.SZABLONY.map((s) => ({ id: s.id, nazwa: s.nazwa, kat: s.kat, czas: s.czas, pola: s.pola })) });
    else if (arg("--galeria")) await galeria(arg("--galeria"), (arg("--fonty") || "").split(",").filter(Boolean), arg("--czas") ? +arg("--czas") : null);
    else if (arg("--spec")) await render(JSON.parse(fs.readFileSync(arg("--spec"), "utf8")));
    else blad("Użycie: --lista | --galeria plik.png | --spec spec.json");
  } catch (e) { blad(String(e && e.stack || e)); }
})();
