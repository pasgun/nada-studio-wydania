/* Szablony rolek i stories Studio Nadamedia (w stylu szablonów Instagram Stories z Envato).
 *
 * Szablon to PRZEPIS, nie wideo: lista warstw (zdjęcia, teksty, kształty) z ruchem wejścia i wyjścia.
 * Z jednego przepisu powstaje:
 *   - podgląd i render (canvas): panel w Premiere/After Effects, Studio, node (render.js),
 *   - edytowalna kompozycja After Effects (ae_buduj.jsx dostaje wynik NMSzablony.doAE(...)).
 *
 * Układ bazowy 1080 × 1920 (9:16). Kolory to żetony: $tl (tło), $t (tekst), $a (akcent), $g (plama / drugie tło),
 * $d (tekst drugorzędny) albo zwykły #hex. Fonty: "n" (nagłówki, domyślnie Oswald) i "t" (tekst, domyślnie Montserrat).
 *
 * Warstwy:
 *   prost   {x, y, w, h, kolor, r (zaokrąglenie), obrys (grubość: tylko obrys)}
 *   kolo    {x, y (środek), r, kolor, obrys}
 *   trojkat {x, y (środek), r, kolor, obrot}
 *   linia   {x1, y1, x2, y2, kolor, g (grubość)}
 *   cien    {x, y, w, h, kolor, od (krycie u góry), do (krycie u dołu)}   pionowe przejście koloru (np. pod tekst na zdjęciu)
 *   zdjecie {pole, x, y, w, h, maska: prost|kolo|romb|luk|zaokr|{x,y,w,h}, r, bw, ruch: [skala_od, skala_do], dopasuj: wypelnij|zawrzyj}
 *   tekst   {pole albo tekst, x, y (góra), rozmiar, font n|t, waga, kolor, wyr lewo|srodek|prawo, szer (zawijanie), interlinia,
 *            rozstaw (1/1000 em jak w AE), wielkie, obrot}
 * Każda warstwa: we {typ, t, d, e} (wejście), wy {...} (wyjście; domyślnie wspólne wyjście szablonu), krycie, obrot.
 * Ruchy: zanik, gora, dol, lewo, prawo, skala, pop, zoom, odkryj-lewo, odkryj-prawo, odkryj-gora, odkryj-dol,
 *        maska-gora, rysuj (linia, obrys), pisz (tekst litera po literze), licz (liczba w tekście rośnie od zera).
 * Wygładzenie e: plynnie (domyślnie), ostro, sprezyna.
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.NMSzablony = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  const BW = 1080, BH = 1920;
  const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
  const lerp = (a, b, t) => a + (b - a) * t;
  const EASE = {
    plynnie: (t) => 1 - Math.pow(1 - t, 4),
    ostro: (t) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t)),
    sprezyna: (t) => { const c1 = 2.2, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
    lin: (t) => t,
    wej: (t) => t * t * t,
  };

  // ---------- kolory ----------
  function hex(h) {
    let s = String(h || "#000").replace("#", "").trim();
    if (s.length === 3) s = s.split("").map((c) => c + c).join("");
    const n = parseInt(s.slice(0, 6), 16) || 0;
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  const rgba = (h, a) => { const [r, g, b] = hex(h); return `rgba(${r},${g},${b},${a})`; };
  function kolor(k, kol) { return typeof k === "string" && k[0] === "$" ? (kol[k.slice(1)] || "#ff00ff") : k || kol.t; }

  // ---------- pola ----------
  const zd = (id, etykieta) => ({ id, typ: "zdjecie", etykieta });
  const tx = (id, etykieta, dom, wiersze) => ({ id, typ: "tekst", etykieta, dom, wiersze: wiersze || (String(dom).includes("\n") ? 2 : 1) });
  const lg = (id, etykieta) => ({ id, typ: "zdjecie", etykieta, logo: true });

  // ---------- warstwy (skróty do pisania szablonów) ----------
  const W = (typ, t = 0, d = 0.7, e) => ({ typ, t, d, e });
  const P = (x, y, w, h, kolor, o = {}) => ({ typ: "prost", x, y, w, h, kolor, ...o });
  const K = (x, y, r, kolor, o = {}) => ({ typ: "kolo", x, y, r, kolor, ...o });
  const TR = (x, y, r, kolor, o = {}) => ({ typ: "trojkat", x, y, r, kolor, ...o });
  const L = (x1, y1, x2, y2, kolor, g = 3, o = {}) => ({ typ: "linia", x1, y1, x2, y2, kolor, g, ...o });
  const C = (x, y, w, h, kolor, od, doo, o = {}) => ({ typ: "cien", x, y, w, h, kolor, od, do: doo, ...o });
  const Z = (pole, x, y, w, h, o = {}) => ({ typ: "zdjecie", pole, x, y, w, h, ...o });
  const T = (pole, x, y, o = {}) => ({ typ: "tekst", pole, x, y, ...o });
  const TL = (tekst, x, y, o = {}) => ({ typ: "tekst", tekst, x, y, ...o });

  const CIEMNE = { tl: "#111111", t: "#FFFFFF", a: "#FFFFFF", g: "#2A2A2A", d: "#9C9C9C" };
  const JASNE = { tl: "#ECECEC", t: "#111111", a: "#111111", g: "#FFFFFF", d: "#7A7A7A" };
  const BIALE = { tl: "#FFFFFF", t: "#111111", a: "#111111", g: "#F1F1F1", d: "#8A8A8A" };

  const KATEGORIE = [
    { id: "edytorskie", nazwa: "Edytorskie" },
    { id: "minimal", nazwa: "Minimalistyczne" },
    { id: "ksztalty", nazwa: "Koła i romby" },
    { id: "kolaz", nazwa: "Kolaże" },
    { id: "statystyki", nazwa: "Liczby i obserwujący" },
    { id: "cytaty", nazwa: "Cytaty i hasła" },
    { id: "promocje", nazwa: "Promocje i produkty" },
    { id: "wydarzenia", nazwa: "Wydarzenia" },
    { id: "lifestyle", nazwa: "Podróże i lifestyle" },
    { id: "zakonczenia", nazwa: "Zapowiedzi i zakończenia" },
    { id: "wlasne", nazwa: "Własne" },
  ];

  const SZABLONY = [];
  const dodaj = (s) => { const i = SZABLONY.findIndex((x) => x.id === s.id); if (i >= 0) SZABLONY.splice(i, 1, s); else SZABLONY.push(s); return s; };

  // ======================= EDYTORSKIE =======================
  dodaj({ id: "ed-walizka", nazwa: "Zdjęcie u góry, tytuł na dole", kat: "edytorskie", czas: 8, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie główne"), zd("z2", "Małe zdjęcie w kółku"), tx("etykieta", "Nadtytuł", "GET INSPIRED"), tx("tytul", "Tytuł", "LIVE LIFE\nOUT OF A SUITCASE"),
      tx("opis", "Opis", "Krótki opis w dwóch linijkach, który dopowiada, o co chodzi w tej historii.", 2), tx("stopka", "Stopka", "TWOJASTRONA.PL")],
    warstwy: [
      Z("z1", 0, 0, 1080, 1010, { ruch: [1.15, 1], we: W("odkryj-gora", 0.05, 1) }),
      P(800, 830, 150, 440, "$d", { r: 75, krycie: 0.55, we: W("odkryj-gora", 0.7, 0.7) }),
      Z("z2", 810, 1125, 130, 130, { maska: "kolo", we: W("pop", 1.2, 0.6, "sprezyna") }),
      T("etykieta", 90, 1100, { rozmiar: 24, font: "t", waga: 600, rozstaw: 250, kolor: "$d", we: W("lewo", 0.8, 0.6) }),
      T("tytul", 90, 1150, { rozmiar: 104, font: "n", waga: 700, interlinia: 1.02, wielkie: true, maks: 700, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 90, 1420, { rozmiar: 30, font: "t", szer: 640, kolor: "$d", interlinia: 1.45, we: W("gora", 1.3, 0.6) }),
      T("stopka", 90, 1790, { rozmiar: 24, font: "t", waga: 600, rozstaw: 200, we: W("zanik", 1.6, 0.6) }),
      L(870, 1795, 990, 1795, "$t", 3, { we: W("rysuj", 1.7, 0.6) }),
    ] });
  dodaj({ id: "ed-kola", nazwa: "Dwa zdjęcia w kołach i linia", kat: "edytorskie", czas: 8, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie w dużym kole"), zd("z2", "Zdjęcie w małym kole"), tx("tytul", "Tytuł", "STRESS LESS\nAND ENJOY THE BEST"), tx("opis", "Opis", "Lorem ipsum dolor sit amet, consectetur adipiscing elit sed do eiusmod.", 2), tx("stopka", "Stopka", "TWOJASTRONA.PL")],
    warstwy: [
      L(70, 1190, 1010, 560, "$t", 3, { we: W("rysuj", 0.2, 1.1) }),
      Z("z1", 160, 320, 560, 560, { maska: "kolo", bw: true, ruch: [1.2, 1.05], we: W("skala", 0.3, 0.9) }),
      Z("z2", 560, 740, 430, 430, { maska: "kolo", ruch: [1.15, 1], we: W("skala", 0.6, 0.9) }),
      K(470, 1060, 18, "$t", { we: W("pop", 1.1, 0.5, "sprezyna") }),
      T("tytul", 90, 1330, { rozmiar: 104, font: "n", waga: 700, interlinia: 1.02, wielkie: true, we: W("maska-gora", 1.0, 0.8) }),
      T("opis", 90, 1580, { rozmiar: 30, font: "t", szer: 640, kolor: "$d", interlinia: 1.45, we: W("gora", 1.3, 0.6) }),
      P(90, 1750, 6, 60, "$t", { we: W("odkryj-gora", 1.4, 0.5) }),
      T("stopka", 90, 1830, { rozmiar: 22, font: "t", waga: 600, rozstaw: 200, kolor: "$d", we: W("zanik", 1.6, 0.6) }),
      P(950, 1790, 40, 40, "$t", { we: W("pop", 1.7, 0.5) }),
    ] });
  dodaj({ id: "ed-portret", nazwa: "Portret w ramce na jasnym tle", kat: "edytorskie", czas: 8, kolory: JASNE,
    pola: [zd("z1", "Portret"), tx("nad", "Nadtytuł", "EXPERIENCE THE DIFFERENCE"), tx("tytul", "Tytuł", "FAVORITE BRANDS\nAND HOTTEST TRENDS"), tx("opis", "Opis", "Opis w jednej albo dwóch linijkach pod tytułem.", 2), tx("p1", "Przycisk 1", "PROMO"), tx("p2", "Przycisk 2", "SKLEP")],
    warstwy: [
      P(170, 230, 740, 1000, "#111111", { we: W("odkryj-dol", 0.05, 0.8) }),
      Z("z1", 210, 270, 660, 920, { bw: true, ruch: [1.15, 1], we: W("zanik", 0.5, 0.9) }),
      L(820, 160, 1040, 520, "$t", 3, { we: W("rysuj", 0.9, 0.7) }),
      K(120, 1000, 14, "$t", { we: W("pop", 1.0, 0.5) }), K(960, 600, 10, "$t", { we: W("pop", 1.1, 0.5) }),
      T("nad", 540, 1300, { rozmiar: 22, font: "t", waga: 600, rozstaw: 250, wyr: "srodek", we: W("zanik", 0.9, 0.6) }),
      T("tytul", 540, 1345, { rozmiar: 92, font: "n", waga: 700, interlinia: 1.04, wielkie: true, wyr: "srodek", we: W("maska-gora", 1.0, 0.8) }),
      T("opis", 540, 1560, { rozmiar: 28, font: "t", szer: 760, wyr: "srodek", kolor: "$d", we: W("gora", 1.3, 0.6) }),
      P(360, 1680, 160, 58, "$t", { obrys: 3, we: W("zanik", 1.5, 0.5) }), T("p1", 440, 1696, { rozmiar: 22, font: "t", waga: 700, wyr: "srodek", rozstaw: 150, we: W("zanik", 1.5, 0.5) }),
      P(560, 1680, 160, 58, "$t", { we: W("zanik", 1.6, 0.5) }), T("p2", 640, 1696, { rozmiar: 22, font: "t", waga: 700, wyr: "srodek", rozstaw: 150, kolor: "$tl", we: W("zanik", 1.6, 0.5) }),
      L(420, 1830, 660, 1830, "$t", 4, { we: W("rysuj", 1.8, 0.6) }),
    ] });
  dodaj({ id: "ed-przygoda", nazwa: "Duże zdjęcie, dwa małe i przycisk play", kat: "edytorskie", czas: 8, kolory: JASNE,
    pola: [zd("z1", "Zdjęcie główne"), zd("z2", "Małe zdjęcie 1"), zd("z3", "Małe zdjęcie 2"), tx("nad", "Nadtytuł", "GET TRAVEL INSPIRED"), tx("tytul", "Tytuł", "THE ADVENTURE\nLIFESTYLE"), tx("opis", "Opis", "Krótki opis przygody w jednej linijce.")],
    warstwy: [
      P(0, 0, 1080, 160, "#111111", { we: W("odkryj-dol", 0, 0.5) }),
      T("nad", 90, 64, { rozmiar: 22, font: "t", waga: 600, rozstaw: 200, kolor: "#FFFFFF", we: W("zanik", 0.4, 0.5) }),
      Z("z1", 60, 200, 960, 880, { ruch: [1.15, 1], we: W("odkryj-dol", 0.2, 0.9) }),
      Z("z2", 30, 700, 280, 190, { we: W("lewo", 0.8, 0.6) }), Z("z3", 30, 905, 280, 190, { we: W("lewo", 0.95, 0.6) }),
      T("tytul", 540, 1170, { rozmiar: 96, font: "n", waga: 700, interlinia: 1.02, wielkie: true, wyr: "srodek", we: W("maska-gora", 1.0, 0.8) }),
      T("opis", 540, 1400, { rozmiar: 28, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.3, 0.6) }),
      P(470, 1520, 140, 140, "#1D2B4A", { r: 10, we: W("pop", 1.4, 0.6, "sprezyna") }), TR(548, 1590, 36, "#FFFFFF", { obrot: 90, we: W("pop", 1.55, 0.6, "sprezyna") }),
      L(130, 1590, 220, 1590, "$t", 4, { we: W("rysuj", 1.6, 0.5) }), L(860, 1590, 950, 1590, "$t", 4, { we: W("rysuj", 1.6, 0.5) }),
    ] });
  dodaj({ id: "ed-okladka", nazwa: "Okładka magazynu", kat: "edytorskie", czas: 7, kolory: { ...CIEMNE, a: "#FFFFFF" },
    pola: [zd("z1", "Zdjęcie na całość"), tx("tytul", "Nazwa magazynu", "VOGUE STYLE"), tx("numer", "Numer i data", "NR 10 · PAŹDZIERNIK 2026"), tx("naglowek", "Nagłówek", "Nowa kolekcja\njuż jest"), tx("opis", "Dopisek", "Wywiad, sesja i 12 stron inspiracji")],
    warstwy: [
      Z("z1", 0, 0, 1080, 1920, { ruch: [1.2, 1.02], we: W("zanik", 0, 0.8) }),
      C(0, 0, 1080, 520, "#000000", 0.55, 0), C(0, 1180, 1080, 740, "#000000", 0, 0.75),
      T("tytul", 540, 110, { rozmiar: 190, font: "n", waga: 700, wyr: "srodek", wielkie: true, rozstaw: 20, we: W("maska-gora", 0.3, 0.9) }),
      T("numer", 540, 340, { rozmiar: 24, font: "t", waga: 600, wyr: "srodek", rozstaw: 300, we: W("zanik", 0.8, 0.6) }),
      T("naglowek", 80, 1450, { rozmiar: 96, font: "n", waga: 700, interlinia: 1.0, wielkie: true, szer: 900, we: W("maska-gora", 0.9, 0.8) }),
      L(80, 1700, 300, 1700, "$a", 5, { we: W("rysuj", 1.2, 0.6) }),
      T("opis", 80, 1740, { rozmiar: 30, font: "t", szer: 900, we: W("gora", 1.3, 0.6) }),
    ] });
  dodaj({ id: "ed-polaroid", nazwa: "Zdjęcie w białej ramce", kat: "edytorskie", czas: 7, kolory: { ...CIEMNE, g: "#FFFFFF" },
    pola: [zd("z1", "Zdjęcie"), tx("podpis", "Podpis na ramce", "summer '26"), tx("tytul", "Tytuł", "MEMORIES\nWE MADE"), tx("opis", "Opis", "Krótki opis albo miejsce")],
    warstwy: [
      P(150, 260, 780, 940, "$g", { obrot: -4, we: W("pop", 0.1, 0.8, "sprezyna") }),
      Z("z1", 190, 300, 700, 720, { obrot: -4, ruch: [1.12, 1], we: W("zanik", 0.5, 0.7) }),
      T("podpis", 540, 1060, { rozmiar: 44, font: "t", waga: 500, wyr: "srodek", kolor: "#222222", obrot: -4, we: W("pisz", 0.9, 0.8) }),
      T("tytul", 90, 1350, { rozmiar: 120, font: "n", waga: 700, interlinia: 1.0, wielkie: true, we: W("maska-gora", 1.0, 0.8) }),
      T("opis", 90, 1620, { rozmiar: 30, font: "t", kolor: "$d", we: W("gora", 1.3, 0.6) }),
      L(90, 1720, 290, 1720, "$t", 4, { we: W("rysuj", 1.5, 0.6) }),
    ] });
  dodaj({ id: "ed-pasy", nazwa: "Zdjęcie w trzech pasach", kat: "edytorskie", czas: 7, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "URBAN\nSTORIES"), tx("opis", "Opis", "Miasto, ludzie i światło")],
    warstwy: [
      Z("z1", 90, 150, 900, 1150, { maska: { x: 90, y: 150, w: 290, h: 1150 }, ruch: [1.12, 1], we: W("odkryj-dol", 0.1, 0.8) }),
      Z("z1", 90, 150, 900, 1150, { maska: { x: 395, y: 150, w: 290, h: 1150 }, ruch: [1.12, 1], we: W("odkryj-gora", 0.25, 0.8) }),
      Z("z1", 90, 150, 900, 1150, { maska: { x: 700, y: 150, w: 290, h: 1150 }, ruch: [1.12, 1], we: W("odkryj-dol", 0.4, 0.8) }),
      T("tytul", 90, 1400, { rozmiar: 130, font: "n", waga: 700, interlinia: 0.98, wielkie: true, we: W("maska-gora", 1.0, 0.8) }),
      T("opis", 90, 1680, { rozmiar: 32, font: "t", kolor: "$d", we: W("gora", 1.3, 0.6) }),
      P(930, 1690, 60, 60, "$a", { obrys: 3, we: W("pop", 1.5, 0.5) }),
    ] });

  // ======================= MINIMAL =======================
  dodaj({ id: "mi-pionowy", nazwa: "Pionowy napis obok zdjęcia", kat: "minimal", czas: 8, kolory: BIALE,
    pola: [zd("z1", "Zdjęcie"), tx("slowo", "Pionowy napis", "Minimalist"), tx("tag", "Mały napis u góry", "#twojprofil"), tx("opis", "Opis", "Krótki opis pod zdjęciem.")],
    warstwy: [
      T("tag", 170, 330, { rozmiar: 30, font: "t", waga: 500, we: W("zanik", 0.2, 0.6) }),
      L(170, 385, 520, 385, "$t", 2, { we: W("rysuj", 0.3, 0.6) }),
      Z("z1", 330, 520, 580, 900, { bw: true, ruch: [1.1, 1], we: W("odkryj-gora", 0.4, 0.9) }),
      TR(380, 570, 70, "#111111", { obrot: 225, we: W("zanik", 1.0, 0.5) }),
      T("slowo", 245, 1420, { rozmiar: 88, font: "t", waga: 700, obrot: -90, we: W("odkryj-dol", 0.8, 0.8) }),
      T("opis", 330, 1480, { rozmiar: 28, font: "t", szer: 560, kolor: "$d", we: W("gora", 1.2, 0.6) }),
    ] });
  dodaj({ id: "mi-projekt", nazwa: "Imię, projekt i zdjęcie", kat: "minimal", czas: 8, kolory: BIALE,
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł (cienki)", "Your name\nProject"), tx("podpis", "Podpis", "ONLY ON INSTAGRAM"), tx("przycisk", "Przycisk", "SPRAWDŹ")],
    warstwy: [
      L(200, 280, 200, 470, "$t", 2, { we: W("rysuj", 0.1, 0.5) }),
      T("tytul", 230, 280, { rozmiar: 84, font: "t", waga: 300, interlinia: 1.05, we: W("lewo", 0.3, 0.8) }),
      Z("z1", 240, 620, 600, 760, { bw: true, ruch: [1.12, 1], we: W("odkryj-dol", 0.5, 0.9) }),
      T("podpis", 540, 1470, { rozmiar: 26, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, we: W("zanik", 1.1, 0.6) }),
      P(470, 1570, 140, 44, "#111111", { we: W("odkryj-lewo", 1.3, 0.5) }),
      T("przycisk", 540, 1580, { rozmiar: 18, font: "t", waga: 700, wyr: "srodek", rozstaw: 200, kolor: "#FFFFFF", we: W("zanik", 1.5, 0.4) }),
    ] });
  dodaj({ id: "mi-blok", nazwa: "Zdjęcie na kolorowym bloku", kat: "minimal", czas: 8, kolory: { ...BIALE, a: "#E8B730" },
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "Stories"), tx("opis", "Opis", "Minimalistyczny opis w dwóch krótkich linijkach tekstu.", 2)],
    warstwy: [
      P(300, 360, 560, 760, "$a", { we: W("odkryj-gora", 0.1, 0.8) }),
      Z("z1", 220, 440, 560, 760, { ruch: [1.12, 1], we: W("odkryj-dol", 0.4, 0.9) }),
      T("tytul", 540, 1340, { rozmiar: 64, font: "t", waga: 600, wyr: "srodek", rozstaw: 120, we: W("maska-gora", 1.0, 0.7) }),
      T("opis", 540, 1450, { rozmiar: 26, font: "t", wyr: "srodek", szer: 620, kolor: "$d", interlinia: 1.5, we: W("gora", 1.2, 0.6) }),
      L(500, 1600, 580, 1600, "$t", 3, { we: W("rysuj", 1.4, 0.5) }),
    ] });
  dodaj({ id: "mi-ramka", nazwa: "Zdjęcie z przesuniętą ramką", kat: "minimal", czas: 8, kolory: BIALE,
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "After Effects\ntemplate"), tx("etykieta", "Etykieta", "STYLE")],
    warstwy: [
      Z("z1", 270, 330, 600, 900, { ruch: [1.12, 1], we: W("zanik", 0.2, 0.8) }),
      P(220, 400, 560, 940, "$t", { obrys: 4, we: W("rysuj", 0.6, 1.0) }),
      P(440, 1310, 200, 50, "#111111", { we: W("odkryj-lewo", 1.0, 0.5) }),
      T("etykieta", 540, 1322, { rozmiar: 22, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, kolor: "#FFFFFF", we: W("zanik", 1.2, 0.4) }),
      T("tytul", 540, 1450, { rozmiar: 64, font: "t", waga: 600, wyr: "srodek", rozstaw: 80, interlinia: 1.1, we: W("maska-gora", 1.2, 0.8) }),
    ] });
  dodaj({ id: "mi-dwa", nazwa: "Dwa zdjęcia jedno nad drugim", kat: "minimal", czas: 8, kolory: BIALE,
    pola: [zd("z1", "Zdjęcie górne"), zd("z2", "Zdjęcie dolne"), tx("tytul", "Tytuł", "Envato\nmarket"), tx("etykieta", "Etykieta", "INSTAGRAM"), tx("opis", "Opis", "Krótki tekst o projekcie w kilku linijkach, wyrównany do lewej.", 3)],
    warstwy: [
      T("tytul", 120, 220, { rozmiar: 76, font: "t", waga: 700, interlinia: 1.05, we: W("lewo", 0.2, 0.8) }),
      Z("z1", 600, 160, 380, 820, { bw: true, ruch: [1.1, 1], we: W("odkryj-dol", 0.3, 0.9) }),
      T("etykieta", 120, 560, { rozmiar: 24, font: "t", waga: 600, rozstaw: 250, we: W("zanik", 0.8, 0.6) }),
      T("opis", 120, 640, { rozmiar: 26, font: "t", szer: 420, kolor: "$d", interlinia: 1.5, we: W("gora", 1.0, 0.6) }),
      Z("z2", 120, 1060, 840, 700, { ruch: [1.12, 1], we: W("odkryj-gora", 0.9, 0.9) }),
    ] });
  dodaj({ id: "mi-tekst", nazwa: "Sam napis między liniami", kat: "minimal", czas: 6, kolory: BIALE,
    pola: [tx("nad", "Mały napis", "MINIMALISM"), tx("tytul", "Napis", "Less is\nmore"), tx("podpis", "Podpis", "kolekcja jesień 2026")],
    warstwy: [
      T("nad", 540, 620, { rozmiar: 24, font: "t", waga: 600, wyr: "srodek", rozstaw: 400, we: W("zanik", 0.1, 0.6) }),
      L(240, 700, 840, 700, "$t", 2, { we: W("rysuj", 0.2, 0.8) }),
      T("tytul", 540, 780, { rozmiar: 150, font: "t", waga: 300, wyr: "srodek", interlinia: 1.0, we: W("maska-gora", 0.5, 0.9) }),
      L(240, 1150, 840, 1150, "$t", 2, { we: W("rysuj", 0.6, 0.8) }),
      T("podpis", 540, 1200, { rozmiar: 30, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.0, 0.6) }),
    ] });

  // ======================= KSZTAŁTY =======================
  dodaj({ id: "ks-romby", nazwa: "Zdjęcia w rombach", kat: "ksztalty", czas: 8, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie w dużym rombie"), zd("z2", "Zdjęcie w małym rombie"), tx("tytul", "Tytuł", "KEEP CALM AND\nNEVER STOP TRAVELLING"), tx("stopka", "Stopka", "@twojprofil")],
    warstwy: [
      T("tytul", 540, 230, { rozmiar: 64, font: "n", waga: 700, interlinia: 1.05, wielkie: true, wyr: "srodek", we: W("maska-gora", 0.1, 0.8) }),
      Z("z1", 200, 520, 680, 680, { maska: "romb", ruch: [1.15, 1], we: W("skala", 0.4, 0.9) }),
      Z("z2", 330, 1130, 420, 420, { maska: "romb", bw: true, ruch: [1.15, 1], we: W("skala", 0.7, 0.9) }),
      K(170, 1300, 12, "$t", { we: W("pop", 1.1, 0.4) }), K(910, 860, 12, "$t", { we: W("pop", 1.2, 0.4) }),
      T("stopka", 540, 1760, { rozmiar: 28, font: "t", waga: 600, wyr: "srodek", rozstaw: 120, kolor: "$d", we: W("zanik", 1.3, 0.6) }),
    ] });
  dodaj({ id: "ks-kolo", nazwa: "Duże koło ze zdjęciem", kat: "ksztalty", czas: 8, kolory: JASNE,
    pola: [zd("z1", "Zdjęcie w kole"), tx("tytul", "Tytuł", "FALL IN LOVE\nWITH THE COLLECTION"), tx("opis", "Opis", "Nowe wzory, te same wygody. Sprawdź całą kolekcję.", 2), tx("przycisk", "Przycisk", "KUP TERAZ")],
    warstwy: [
      K(540, 680, 390, "$t", { obrys: 3, we: W("rysuj", 0.1, 1.0) }),
      Z("z1", 180, 320, 720, 720, { maska: "kolo", bw: true, ruch: [1.2, 1.02], we: W("skala", 0.3, 0.9) }),
      L(90, 680, 150, 680, "$t", 3, { we: W("rysuj", 0.8, 0.4) }), L(930, 680, 990, 680, "$t", 3, { we: W("rysuj", 0.8, 0.4) }),
      T("tytul", 540, 1180, { rozmiar: 86, font: "n", waga: 700, wyr: "srodek", interlinia: 1.04, wielkie: true, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 540, 1410, { rozmiar: 28, font: "t", wyr: "srodek", szer: 760, kolor: "$d", we: W("gora", 1.2, 0.6) }),
      P(390, 1560, 300, 80, "$t", { we: W("odkryj-lewo", 1.4, 0.6) }),
      T("przycisk", 540, 1584, { rozmiar: 26, font: "t", waga: 700, wyr: "srodek", rozstaw: 200, kolor: "$tl", we: W("zanik", 1.6, 0.4) }),
    ] });
  dodaj({ id: "ks-luk", nazwa: "Zdjęcie w łuku", kat: "ksztalty", czas: 8, kolory: { tl: "#EFE8DF", t: "#2B2420", a: "#B8794A", g: "#FFFFFF", d: "#8C7B6E" },
    pola: [zd("z1", "Zdjęcie w łuku"), tx("nad", "Nadtytuł", "NEW SEASON"), tx("tytul", "Tytuł", "Slow\nmornings"), tx("opis", "Opis", "Kawa, światło i dobra książka.")],
    warstwy: [
      Z("z1", 190, 260, 700, 1000, { maska: "luk", ruch: [1.15, 1], we: W("odkryj-gora", 0.1, 1.0) }),
      K(860, 300, 70, "$a", { we: W("pop", 0.8, 0.6, "sprezyna") }),
      T("nad", 540, 1340, { rozmiar: 24, font: "t", waga: 600, wyr: "srodek", rozstaw: 400, kolor: "$a", we: W("zanik", 0.9, 0.6) }),
      T("tytul", 540, 1390, { rozmiar: 120, font: "t", waga: 300, wyr: "srodek", interlinia: 1.0, we: W("maska-gora", 1.0, 0.8) }),
      T("opis", 540, 1680, { rozmiar: 30, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.3, 0.6) }),
    ] });
  dodaj({ id: "ks-zaokr", nazwa: "Zaokrąglone kafle", kat: "ksztalty", czas: 8, kolory: { tl: "#101820", t: "#FFFFFF", a: "#7CE0C3", g: "#1C2833", d: "#8FA3B5" },
    pola: [zd("z1", "Zdjęcie 1"), zd("z2", "Zdjęcie 2"), zd("z3", "Zdjęcie 3"), tx("tytul", "Tytuł", "Weekend\nvibes"), tx("tag", "Tag", "#lifestyle")],
    warstwy: [
      Z("z1", 80, 180, 560, 760, { maska: "zaokr", r: 60, ruch: [1.12, 1], we: W("gora", 0.1, 0.8) }),
      Z("z2", 660, 180, 340, 360, { maska: "zaokr", r: 60, we: W("gora", 0.25, 0.8) }),
      Z("z3", 660, 560, 340, 380, { maska: "zaokr", r: 60, we: W("gora", 0.4, 0.8) }),
      P(80, 980, 920, 560, "$g", { r: 60, we: W("gora", 0.55, 0.8) }),
      T("tytul", 150, 1060, { rozmiar: 130, font: "n", waga: 700, interlinia: 0.98, wielkie: true, we: W("maska-gora", 0.9, 0.8) }),
      P(150, 1420, 260, 64, "$a", { r: 32, we: W("odkryj-lewo", 1.2, 0.5) }),
      T("tag", 280, 1437, { rozmiar: 28, font: "t", waga: 700, wyr: "srodek", kolor: "$tl", we: W("zanik", 1.4, 0.4) }),
    ] });

  // ======================= KOLAŻE =======================
  dodaj({ id: "ko-trzy", nazwa: "Kolaż: jedno duże i dwa małe", kat: "kolaz", czas: 8, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie duże"), zd("z2", "Zdjęcie małe 1"), zd("z3", "Zdjęcie małe 2"), tx("tytul", "Tytuł", "INSTAGRAM\nSTORIES"), tx("opis", "Opis", "Lorem ipsum dolor sit amet")],
    warstwy: [
      Z("z1", 80, 160, 920, 900, { ruch: [1.12, 1], we: W("odkryj-dol", 0.1, 0.8) }),
      Z("z2", 80, 1090, 445, 460, { bw: true, we: W("odkryj-gora", 0.4, 0.8) }),
      Z("z3", 555, 1090, 445, 460, { we: W("odkryj-dol", 0.55, 0.8) }),
      P(0, 1600, 1080, 320, "$tl"),
      T("tytul", 80, 1610, { rozmiar: 90, font: "n", waga: 700, interlinia: 0.98, wielkie: true, we: W("maska-gora", 0.9, 0.7) }),
      T("opis", 1000, 1690, { rozmiar: 26, font: "t", wyr: "prawo", kolor: "$d", we: W("zanik", 1.2, 0.6) }),
    ] });
  dodaj({ id: "ko-siatka", nazwa: "Siatka 2×2 z tytułem w środku", kat: "kolaz", czas: 8, kolory: BIALE,
    pola: [zd("z1", "Zdjęcie 1"), zd("z2", "Zdjęcie 2"), zd("z3", "Zdjęcie 3"), zd("z4", "Zdjęcie 4"), tx("tytul", "Tytuł w środku", "OUR\nWEEK")],
    warstwy: [
      Z("z1", 0, 0, 540, 960, { ruch: [1.1, 1], we: W("odkryj-dol", 0.0, 0.7) }),
      Z("z2", 540, 0, 540, 960, { ruch: [1.1, 1], we: W("odkryj-gora", 0.15, 0.7) }),
      Z("z3", 0, 960, 540, 960, { ruch: [1.1, 1], we: W("odkryj-dol", 0.3, 0.7) }),
      Z("z4", 540, 960, 540, 960, { ruch: [1.1, 1], we: W("odkryj-gora", 0.45, 0.7) }),
      P(290, 760, 500, 400, "$tl", { we: W("skala", 0.8, 0.6) }),
      T("tytul", 540, 810, { rozmiar: 130, font: "n", waga: 700, wyr: "srodek", interlinia: 0.95, wielkie: true, we: W("maska-gora", 1.0, 0.7) }),
    ] });
  dodaj({ id: "ko-film", nazwa: "Klatki filmu", kat: "kolaz", czas: 8, kolory: CIEMNE,
    pola: [zd("z1", "Klatka 1"), zd("z2", "Klatka 2"), zd("z3", "Klatka 3"), tx("tytul", "Tytuł", "SHOT ON\nFILM")],
    warstwy: [
      P(140, 0, 800, 1920, "#000000", { we: W("zanik", 0, 0.4) }),
      ...[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].flatMap((i) => [P(165, 40 + i * 160, 40, 70, "#2B2B2B"), P(875, 40 + i * 160, 40, 70, "#2B2B2B")]),
      Z("z1", 240, 140, 600, 460, { we: W("odkryj-dol", 0.2, 0.7) }),
      Z("z2", 240, 640, 600, 460, { bw: true, we: W("odkryj-dol", 0.4, 0.7) }),
      Z("z3", 240, 1140, 600, 460, { we: W("odkryj-dol", 0.6, 0.7) }),
      T("tytul", 540, 1660, { rozmiar: 80, font: "n", waga: 700, wyr: "srodek", interlinia: 1.0, wielkie: true, we: W("maska-gora", 1.0, 0.7) }),
    ] });
  dodaj({ id: "ko-schodki", nazwa: "Zdjęcia schodkami", kat: "kolaz", czas: 8, kolory: { tl: "#F4F1EC", t: "#111111", a: "#111111", g: "#FFFFFF", d: "#777777" },
    pola: [zd("z1", "Zdjęcie 1"), zd("z2", "Zdjęcie 2"), zd("z3", "Zdjęcie 3"), tx("tytul", "Tytuł", "NEW\nPOST"), tx("tag1", "Tag 1", "Fashion"), tx("tag2", "Tag 2", "Beauty blog")],
    warstwy: [
      T("tytul", 90, 160, { rozmiar: 150, font: "n", waga: 700, interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.1, 0.8) }),
      Z("z1", 520, 140, 470, 620, { bw: true, we: W("lewo", 0.3, 0.8) }),
      Z("z2", 300, 700, 470, 620, { we: W("prawo", 0.5, 0.8) }),
      Z("z3", 90, 1260, 470, 520, { bw: true, we: W("lewo", 0.7, 0.8) }),
      P(620, 1500, 300, 70, "$t", { r: 35, obrys: 3, we: W("zanik", 1.1, 0.5) }), T("tag1", 770, 1520, { rozmiar: 26, font: "t", wyr: "srodek", we: W("zanik", 1.1, 0.5) }),
      P(620, 1600, 300, 70, "$t", { r: 35, obrys: 3, we: W("zanik", 1.25, 0.5) }), T("tag2", 770, 1620, { rozmiar: 26, font: "t", wyr: "srodek", we: W("zanik", 1.25, 0.5) }),
    ] });

  // ======================= STATYSTYKI =======================
  dodaj({ id: "st-obserwujacy", nazwa: "Licznik obserwujących", kat: "statystyki", czas: 8, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie"), tx("liczba", "Liczba", "70K"), tx("podpis", "Podpis pod liczbą", "FOLLOWERS"), tx("tytul", "Tytuł", "INSTA\nSTORIES"), tx("opis", "Opis", "Dziękujemy, że jesteście z nami!")],
    warstwy: [
      T("liczba", 330, 200, { rozmiar: 210, font: "n", waga: 700, wyr: "srodek", we: W("licz", 0.1, 1.4) }),
      T("podpis", 330, 450, { rozmiar: 40, font: "n", waga: 500, wyr: "srodek", rozstaw: 80, we: W("zanik", 0.6, 0.6) }),
      P(110, 560, 440, 560, "$t", { obrys: 3, we: W("rysuj", 0.5, 0.9) }),
      Z("z1", 140, 590, 380, 500, { ruch: [1.12, 1], we: W("zanik", 0.8, 0.7) }),
      T("opis", 330, 1170, { rozmiar: 26, font: "t", wyr: "srodek", szer: 400, kolor: "$d", we: W("gora", 1.0, 0.6) }),
      L(640, 140, 640, 1780, "$d", 2, { we: W("rysuj", 0.3, 1.0) }),
      T("tytul", 680, 1340, { rozmiar: 124, font: "n", waga: 700, interlinia: 0.95, wielkie: true, we: W("maska-gora", 1.0, 0.8) }),
      K(960, 1740, 48, "$t", { obrys: 3, we: W("pop", 1.4, 0.5) }), TL("NEW", 960, 1725, { rozmiar: 24, font: "t", waga: 700, wyr: "srodek", we: W("zanik", 1.5, 0.4) }),
    ] });
  dodaj({ id: "st-followers-bialy", nazwa: "FOLLOWERS i liczba na białym", kat: "statystyki", czas: 8, kolory: { ...BIALE, d: "#B5B5B5" },
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "FOLLOWERS"), tx("liczba", "Liczba", "73K"), tx("w1", "Napis 1", "LIKE"), tx("w2", "Napis 2", "SHARE"), tx("w3", "Napis 3", "FOLLOW")],
    warstwy: [
      T("tytul", 80, 170, { rozmiar: 110, font: "n", waga: 700, wielkie: true, we: W("maska-gora", 0.1, 0.7) }),
      T("liczba", 1000, 170, { rozmiar: 110, font: "n", waga: 300, wyr: "prawo", kolor: "$d", we: W("licz", 0.4, 1.2) }),
      T("w1", 80, 330, { rozmiar: 24, font: "t", waga: 600, rozstaw: 200, we: W("zanik", 0.7, 0.5) }),
      T("w2", 540, 330, { rozmiar: 24, font: "t", waga: 600, rozstaw: 200, wyr: "srodek", we: W("zanik", 0.8, 0.5) }),
      T("w3", 1000, 330, { rozmiar: 24, font: "t", waga: 600, rozstaw: 200, wyr: "prawo", we: W("zanik", 0.9, 0.5) }),
      Z("z1", 80, 420, 920, 1420, { ruch: [1.12, 1], we: W("odkryj-dol", 0.5, 0.9) }),
    ] });
  dodaj({ id: "st-trzy", nazwa: "Trzy liczby", kat: "statystyki", czas: 8, kolory: CIEMNE,
    pola: [tx("tytul", "Tytuł", "2026 W LICZBACH"), tx("l1", "Liczba 1", "120+"), tx("o1", "Opis 1", "zrealizowanych projektów"), tx("l2", "Liczba 2", "35K"), tx("o2", "Opis 2", "obserwujących"), tx("l3", "Liczba 3", "98%"), tx("o3", "Opis 3", "zadowolonych klientów")],
    warstwy: [
      T("tytul", 90, 200, { rozmiar: 44, font: "t", waga: 700, rozstaw: 150, we: W("lewo", 0.1, 0.7) }),
      ...[0, 1, 2].flatMap((i) => [
        L(90, 470 + i * 430, 990, 470 + i * 430, "$d", 2, { we: W("rysuj", 0.3 + i * 0.25, 0.7) }),
        T("l" + (i + 1), 90, 510 + i * 430, { rozmiar: 190, font: "n", waga: 700, we: W("licz", 0.4 + i * 0.25, 1.2) }),
        T("o" + (i + 1), 90, 740 + i * 430, { rozmiar: 32, font: "t", kolor: "$d", we: W("gora", 0.7 + i * 0.25, 0.6) }),
      ]),
    ] });
  dodaj({ id: "st-procent", nazwa: "Duży procent na zdjęciu", kat: "statystyki", czas: 7, kolory: { ...CIEMNE, a: "#F5C542" },
    pola: [zd("z1", "Zdjęcie w tle"), tx("liczba", "Liczba", "87%"), tx("opis", "Opis", "klientów poleca nas\nznajomym")],
    warstwy: [
      Z("z1", 0, 0, 1080, 1920, { ruch: [1.15, 1.02], bw: true, we: W("zanik", 0, 0.8) }),
      P(0, 0, 1080, 1920, "#000000", { krycie: 0.5 }),
      T("liczba", 540, 640, { rozmiar: 320, font: "n", waga: 700, wyr: "srodek", kolor: "$a", we: W("licz", 0.3, 1.5) }),
      L(390, 1060, 690, 1060, "$t", 4, { we: W("rysuj", 1.0, 0.6) }),
      T("opis", 540, 1110, { rozmiar: 54, font: "t", waga: 600, wyr: "srodek", interlinia: 1.2, we: W("gora", 1.1, 0.7) }),
    ] });

  // ======================= CYTATY I HASŁA =======================
  dodaj({ id: "cy-cudzyslow", nazwa: "Cytat z dużym cudzysłowem", kat: "cytaty", czas: 8, kolory: BIALE,
    pola: [tx("cytat", "Cytat", "Najlepszy czas na start był wczoraj. Drugi najlepszy jest dziś.", 3), tx("autor", "Autor", "— Twoje imię")],
    warstwy: [
      TL("“", 90, 330, { rozmiar: 360, font: "n", waga: 700, kolor: "$a", we: W("pop", 0.1, 0.7, "sprezyna") }),
      T("cytat", 90, 700, { rozmiar: 76, font: "t", waga: 600, szer: 880, interlinia: 1.25, we: W("maska-gora", 0.4, 0.9) }),
      L(90, 1300, 250, 1300, "$t", 4, { we: W("rysuj", 1.0, 0.5) }),
      T("autor", 90, 1340, { rozmiar: 34, font: "t", kolor: "$d", we: W("gora", 1.1, 0.6) }),
      TL("”", 990, 1400, { rozmiar: 360, font: "n", waga: 700, wyr: "prawo", kolor: "$g", we: W("zanik", 1.2, 0.6) }),
    ] });
  dodaj({ id: "cy-zdjecie", nazwa: "Cytat na przyciemnionym zdjęciu", kat: "cytaty", czas: 8, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie w tle"), tx("cytat", "Cytat", "Rób to, co kochasz, a nie przepracujesz ani jednego dnia.", 3), tx("autor", "Autor", "KONFUCJUSZ")],
    warstwy: [
      Z("z1", 0, 0, 1080, 1920, { ruch: [1.15, 1.02], we: W("zanik", 0, 0.8) }),
      P(0, 0, 1080, 1920, "#000000", { krycie: 0.55 }),
      P(140, 640, 800, 640, "$t", { obrys: 3, we: W("rysuj", 0.3, 1.0) }),
      T("cytat", 540, 760, { rozmiar: 62, font: "t", waga: 600, wyr: "srodek", szer: 680, interlinia: 1.3, we: W("gora", 0.7, 0.8) }),
      T("autor", 540, 1180, { rozmiar: 28, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, kolor: "$d", we: W("zanik", 1.1, 0.6) }),
    ] });
  dodaj({ id: "cy-hashtagi", nazwa: "Hashtagi na zdjęciu", kat: "cytaty", czas: 8, kolory: { ...CIEMNE, a: "#FFFFFF" },
    pola: [zd("z1", "Zdjęcie"), tx("lista", "Hashtagi (każdy w linii)", "#CREATE\n#MOOD\n#CHANGE\n#WORLD\n#BE CUTE", 5)],
    warstwy: [
      Z("z1", 0, 0, 1080, 1920, { bw: true, ruch: [1.15, 1], we: W("zanik", 0, 0.8) }),
      P(0, 0, 1080, 1920, "#000000", { krycie: 0.35 }),
      T("lista", 90, 1000, { rozmiar: 104, font: "n", waga: 700, interlinia: 1.05, wielkie: true, we: W("pisz", 0.4, 1.6) }),
    ] });
  dodaj({ id: "cy-karta", nazwa: "Czarna karta z hasłami", kat: "cytaty", czas: 8, kolory: BIALE,
    pola: [tx("lista", "Hasła (każde w linii)", "#CREATE\n#YOUR\n#VISION\n#BE YOUNG\n#BE COOL", 5), tx("podpis", "Podpis", "nadamedia")],
    warstwy: [
      P(280, 520, 520, 880, "#111111", { we: W("odkryj-dol", 0.1, 0.7) }),
      T("lista", 340, 640, { rozmiar: 70, font: "n", waga: 700, interlinia: 1.1, wielkie: true, kolor: "#FFFFFF", we: W("pisz", 0.6, 1.4) }),
      T("podpis", 540, 1480, { rozmiar: 28, font: "t", waga: 600, wyr: "srodek", rozstaw: 300, kolor: "$d", we: W("zanik", 1.4, 0.6) }),
    ] });
  dodaj({ id: "cy-haslo", nazwa: "Hasło dużymi literami", kat: "cytaty", czas: 6, kolory: { tl: "#111111", t: "#FFFFFF", a: "#FF5A36", g: "#1E1E1E", d: "#8A8A8A" },
    pola: [tx("tytul", "Hasło", "DON'T\nSTOP\nCREATING"), tx("podpis", "Podpis", "@twojprofil")],
    warstwy: [
      T("tytul", 90, 560, { rozmiar: 230, font: "n", waga: 700, interlinia: 0.92, wielkie: true, we: W("maska-gora", 0.1, 0.9) }),
      P(90, 1300, 300, 18, "$a", { we: W("odkryj-lewo", 0.8, 0.6) }),
      T("podpis", 90, 1380, { rozmiar: 34, font: "t", waga: 600, kolor: "$d", we: W("zanik", 1.0, 0.6) }),
    ] });

  // ======================= PROMOCJE =======================
  dodaj({ id: "pr-rabat", nazwa: "Rabat procentowy", kat: "promocje", czas: 7, kolory: { tl: "#111111", t: "#FFFFFF", a: "#FF3D3D", g: "#FFFFFF", d: "#A0A0A0" },
    pola: [zd("z1", "Zdjęcie produktu"), tx("liczba", "Rabat", "-50%"), tx("tytul", "Tytuł", "BLACK WEEK"), tx("opis", "Dopisek", "tylko do niedzieli"), tx("przycisk", "Przycisk", "KUP TERAZ")],
    warstwy: [
      Z("z1", 0, 0, 1080, 1000, { ruch: [1.15, 1], we: W("odkryj-gora", 0, 0.8) }),
      T("tytul", 90, 1060, { rozmiar: 70, font: "n", waga: 700, rozstaw: 80, wielkie: true, we: W("lewo", 0.5, 0.6) }),
      T("liczba", 70, 1150, { rozmiar: 330, font: "n", waga: 700, kolor: "$a", we: W("pop", 0.7, 0.8, "sprezyna") }),
      T("opis", 90, 1560, { rozmiar: 40, font: "t", waga: 500, kolor: "$d", we: W("gora", 1.0, 0.6) }),
      P(90, 1680, 420, 110, "$a", { we: W("odkryj-lewo", 1.2, 0.6) }),
      T("przycisk", 300, 1714, { rozmiar: 36, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, we: W("zanik", 1.4, 0.4) }),
    ] });
  dodaj({ id: "pr-produkt", nazwa: "Produkt z ceną", kat: "promocje", czas: 7, kolory: { tl: "#E9E4DC", t: "#1A1A1A", a: "#1A1A1A", g: "#FFFFFF", d: "#7A746C" },
    pola: [zd("z1", "Zdjęcie produktu"), tx("nazwa", "Nazwa", "Ceramic Vase"), tx("opis", "Opis", "Ręcznie robiona, 25 cm"), tx("cena", "Cena", "189 zł")],
    warstwy: [
      P(140, 220, 800, 1080, "$g", { we: W("skala", 0.05, 0.7) }),
      Z("z1", 180, 260, 720, 1000, { ruch: [1.1, 1], we: W("zanik", 0.4, 0.7) }),
      K(860, 1240, 130, "$a", { we: W("pop", 0.9, 0.7, "sprezyna") }),
      T("cena", 860, 1210, { rozmiar: 54, font: "n", waga: 700, wyr: "srodek", kolor: "$tl", we: W("zanik", 1.1, 0.4) }),
      T("nazwa", 140, 1420, { rozmiar: 90, font: "t", waga: 300, we: W("maska-gora", 1.0, 0.7) }),
      T("opis", 140, 1550, { rozmiar: 34, font: "t", kolor: "$d", we: W("gora", 1.2, 0.6) }),
    ] });
  dodaj({ id: "pr-nowosc", nazwa: "Nowość w sklepie", kat: "promocje", czas: 7, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "NEW\nARRIVAL"), tx("opis", "Opis", "Zobacz w sklepie online"), tx("link", "Link", "sklep.pl")],
    warstwy: [
      Z("z1", 0, 0, 1080, 1920, { ruch: [1.15, 1], we: W("zoom", 0, 1.0) }),
      C(0, 1000, 1080, 920, "#000000", 0, 0.85),
      T("tytul", 90, 1200, { rozmiar: 200, font: "n", waga: 700, interlinia: 0.92, wielkie: true, we: W("maska-gora", 0.5, 0.9) }),
      T("opis", 90, 1600, { rozmiar: 36, font: "t", we: W("gora", 1.0, 0.6) }),
      P(90, 1700, 240, 66, "$t", { r: 33, obrys: 3, we: W("zanik", 1.2, 0.5) }), T("link", 210, 1719, { rozmiar: 26, font: "t", waga: 700, wyr: "srodek", we: W("zanik", 1.2, 0.5) }),
    ] });
  dodaj({ id: "pr-kolekcja", nazwa: "Kolekcja: trzy produkty", kat: "promocje", czas: 8, kolory: BIALE,
    pola: [zd("z1", "Produkt 1"), zd("z2", "Produkt 2"), zd("z3", "Produkt 3"), tx("tytul", "Tytuł", "AUTUMN\nCOLLECTION"), tx("p1", "Podpis 1", "Płaszcz · 499 zł"), tx("p2", "Podpis 2", "Sweter · 249 zł"), tx("p3", "Podpis 3", "Szal · 129 zł")],
    warstwy: [
      T("tytul", 90, 120, { rozmiar: 120, font: "n", waga: 700, interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.1, 0.8) }),
      ...[0, 1, 2].flatMap((i) => [
        Z("z" + (i + 1), 90, 440 + i * 480, 420, 420, { we: W("lewo", 0.4 + i * 0.2, 0.7) }),
        T("p" + (i + 1), 560, 620 + i * 480, { rozmiar: 40, font: "t", waga: 500, we: W("prawo", 0.6 + i * 0.2, 0.6) }),
        L(560, 690 + i * 480, 760, 690 + i * 480, "$t", 3, { we: W("rysuj", 0.7 + i * 0.2, 0.5) }),
      ]),
    ] });

  // ======================= WYDARZENIA =======================
  dodaj({ id: "wy-data", nazwa: "Wydarzenie z datą", kat: "wydarzenia", czas: 8, kolory: { tl: "#0F0F14", t: "#FFFFFF", a: "#C9A96E", g: "#1A1A22", d: "#9A98A6" },
    pola: [zd("z1", "Zdjęcie"), tx("dzien", "Dzień", "18"), tx("miesiac", "Miesiąc", "LISTOPAD"), tx("tytul", "Nazwa wydarzenia", "GALA\nBIZNESU"), tx("miejsce", "Miejsce i godzina", "Warszawa · 19:00")],
    warstwy: [
      Z("z1", 0, 0, 1080, 1100, { bw: true, ruch: [1.15, 1], we: W("odkryj-gora", 0, 0.9) }),
      C(0, 700, 1080, 400, "$tl", 0, 1),
      T("dzien", 90, 1000, { rozmiar: 260, font: "n", waga: 700, kolor: "$a", we: W("licz", 0.5, 1.0) }),
      T("miesiac", 400, 1110, { rozmiar: 44, font: "t", waga: 600, rozstaw: 300, we: W("lewo", 0.8, 0.6) }),
      L(400, 1190, 990, 1190, "$a", 2, { we: W("rysuj", 0.9, 0.6) }),
      T("tytul", 90, 1330, { rozmiar: 140, font: "n", waga: 700, interlinia: 0.95, wielkie: true, we: W("maska-gora", 1.0, 0.8) }),
      T("miejsce", 90, 1680, { rozmiar: 36, font: "t", kolor: "$d", we: W("gora", 1.3, 0.6) }),
    ] });
  dodaj({ id: "wy-odliczanie", nazwa: "Już za X dni", kat: "wydarzenia", czas: 6, kolory: { tl: "#141414", t: "#FFFFFF", a: "#4ADE80", g: "#222222", d: "#8A8A8A" },
    pola: [tx("nad", "Nad liczbą", "JUŻ ZA"), tx("liczba", "Liczba", "3"), tx("pod", "Pod liczbą", "DNI"), tx("opis", "Opis", "Premiera nowej kolekcji")],
    warstwy: [
      K(540, 900, 380, "$a", { obrys: 6, we: W("rysuj", 0.1, 1.0) }),
      T("nad", 540, 600, { rozmiar: 50, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, we: W("zanik", 0.3, 0.6) }),
      T("liczba", 540, 680, { rozmiar: 360, font: "n", waga: 700, wyr: "srodek", kolor: "$a", we: W("pop", 0.5, 0.8, "sprezyna") }),
      T("pod", 540, 1100, { rozmiar: 50, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, we: W("zanik", 0.8, 0.6) }),
      T("opis", 540, 1400, { rozmiar: 40, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.0, 0.6) }),
    ] });
  dodaj({ id: "wy-zaproszenie", nazwa: "Zaproszenie w ramce", kat: "wydarzenia", czas: 8, kolory: { tl: "#F5F0E8", t: "#2A2420", a: "#A88B5D", g: "#FFFFFF", d: "#8C8073" },
    pola: [tx("nad", "Nadtytuł", "ZAPRASZAMY NA"), tx("tytul", "Tytuł", "Wieczór\nautorski"), tx("data", "Data", "24.11.2026 · 18:00"), tx("miejsce", "Miejsce", "Galeria Sztuki, Kraków")],
    warstwy: [
      P(90, 160, 900, 1600, "$a", { obrys: 3, we: W("rysuj", 0.1, 1.2) }),
      P(120, 190, 840, 1540, "$a", { obrys: 1, we: W("rysuj", 0.3, 1.2) }),
      T("nad", 540, 560, { rozmiar: 30, font: "t", waga: 600, wyr: "srodek", rozstaw: 400, kolor: "$a", we: W("zanik", 0.6, 0.6) }),
      T("tytul", 540, 660, { rozmiar: 140, font: "t", waga: 300, wyr: "srodek", interlinia: 1.0, we: W("maska-gora", 0.8, 0.9) }),
      L(440, 1040, 640, 1040, "$a", 2, { we: W("rysuj", 1.1, 0.6) }),
      T("data", 540, 1100, { rozmiar: 44, font: "t", waga: 600, wyr: "srodek", we: W("gora", 1.2, 0.6) }),
      T("miejsce", 540, 1180, { rozmiar: 34, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.35, 0.6) }),
    ] });
  dodaj({ id: "wy-prelegent", nazwa: "Prelegent / gość", kat: "wydarzenia", czas: 8, kolory: { tl: "#0B1F3A", t: "#FFFFFF", a: "#22C55E", g: "#13294B", d: "#9FB3CC" },
    pola: [zd("z1", "Zdjęcie osoby"), tx("nad", "Nadtytuł", "PRELEGENT"), tx("imie", "Imię i nazwisko", "Anna Kowalska"), tx("rola", "Funkcja", "CEO, Emerald Media"), tx("temat", "Temat", "Jak budować markę w social mediach", 2)],
    warstwy: [
      P(0, 0, 1080, 1920, "$g", { we: W("zanik", 0, 0.3) }),
      Z("z1", 240, 260, 600, 600, { maska: "kolo", ruch: [1.15, 1], we: W("skala", 0.2, 0.8) }),
      K(540, 560, 320, "$a", { obrys: 5, we: W("rysuj", 0.4, 1.0) }),
      T("nad", 540, 980, { rozmiar: 28, font: "t", waga: 700, wyr: "srodek", rozstaw: 400, kolor: "$a", we: W("zanik", 0.8, 0.6) }),
      T("imie", 540, 1040, { rozmiar: 96, font: "n", waga: 700, wyr: "srodek", wielkie: true, we: W("maska-gora", 0.9, 0.7) }),
      T("rola", 540, 1170, { rozmiar: 36, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.1, 0.6) }),
      L(440, 1290, 640, 1290, "$a", 3, { we: W("rysuj", 1.2, 0.5) }),
      T("temat", 540, 1350, { rozmiar: 52, font: "t", waga: 600, wyr: "srodek", szer: 860, interlinia: 1.25, we: W("gora", 1.3, 0.6) }),
    ] });

  // ======================= LIFESTYLE =======================
  dodaj({ id: "li-pelne", nazwa: "Pełne zdjęcie i tytuł na dole", kat: "lifestyle", czas: 7, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie"), tx("nad", "Nadtytuł", "TRAVEL DIARY"), tx("tytul", "Tytuł", "LOST IN\nLISBON"), tx("opis", "Opis", "3 dni, 40 km pieszo i najlepsze pastéis")],
    warstwy: [
      Z("z1", 0, 0, 1080, 1920, { ruch: [1.18, 1.02], we: W("zoom", 0, 1.1) }),
      C(0, 900, 1080, 1020, "#000000", 0, 0.8),
      T("nad", 90, 1280, { rozmiar: 26, font: "t", waga: 700, rozstaw: 400, we: W("lewo", 0.6, 0.6) }),
      T("tytul", 90, 1340, { rozmiar: 170, font: "n", waga: 700, interlinia: 0.92, wielkie: true, we: W("maska-gora", 0.7, 0.9) }),
      T("opis", 90, 1700, { rozmiar: 34, font: "t", we: W("gora", 1.1, 0.6) }),
    ] });
  dodaj({ id: "li-pocztowka", nazwa: "Pocztówka z miejsca", kat: "lifestyle", czas: 7, kolory: { tl: "#D9CFC1", t: "#2B2B2B", a: "#C0392B", g: "#FFFFFF", d: "#6E6458" },
    pola: [zd("z1", "Zdjęcie"), tx("miejsce", "Miejsce", "Santorini"), tx("wsp", "Współrzędne", "36.3932° N, 25.4615° E"), tx("opis", "Opis", "Greetings from")],
    warstwy: [
      P(90, 300, 900, 1180, "$g", { obrot: 3, we: W("pop", 0.1, 0.8, "sprezyna") }),
      Z("z1", 130, 340, 820, 900, { obrot: 3, ruch: [1.12, 1], we: W("zanik", 0.4, 0.7) }),
      T("opis", 540, 1280, { rozmiar: 36, font: "t", waga: 400, wyr: "srodek", obrot: 3, kolor: "$d", we: W("zanik", 0.8, 0.6) }),
      T("miejsce", 540, 1320, { rozmiar: 100, font: "n", waga: 700, wyr: "srodek", obrot: 3, wielkie: true, we: W("maska-gora", 0.9, 0.8) }),
      K(860, 300, 70, "$a", { obrys: 4, we: W("rysuj", 1.2, 0.7) }),
      T("wsp", 540, 1640, { rozmiar: 30, font: "t", wyr: "srodek", kolor: "$d", we: W("pisz", 1.3, 1.0) }),
    ] });
  dodaj({ id: "li-podzial", nazwa: "Podział: zdjęcie i kolor", kat: "lifestyle", czas: 7, kolory: { tl: "#1F3A2E", t: "#F4EDE1", a: "#E9B872", g: "#2A4A3B", d: "#B8C4B9" },
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "Green\nliving"), tx("opis", "Opis", "Pięć roślin, które przeżyją wszystko", 2), tx("numer", "Numer", "01")],
    warstwy: [
      Z("z1", 0, 0, 1080, 960, { ruch: [1.15, 1], we: W("odkryj-dol", 0, 0.9) }),
      T("numer", 980, 1030, { rozmiar: 120, font: "n", waga: 700, wyr: "prawo", kolor: "$a", we: W("zanik", 0.7, 0.6) }),
      T("tytul", 90, 1060, { rozmiar: 160, font: "t", waga: 300, interlinia: 0.95, we: W("maska-gora", 0.6, 0.9) }),
      T("opis", 90, 1460, { rozmiar: 38, font: "t", szer: 760, kolor: "$d", interlinia: 1.35, we: W("gora", 1.0, 0.6) }),
      L(90, 1650, 330, 1650, "$a", 4, { we: W("rysuj", 1.2, 0.6) }),
    ] });
  dodaj({ id: "li-kroki", nazwa: "Lista kroków ze zdjęciem", kat: "lifestyle", czas: 9, kolory: BIALE,
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "MORNING\nROUTINE"), tx("k1", "Krok 1", "Szklanka wody"), tx("k2", "Krok 2", "10 minut ruchu"), tx("k3", "Krok 3", "Kawa bez telefonu"), tx("k4", "Krok 4", "Plan na dzień")],
    warstwy: [
      Z("z1", 540, 0, 540, 1920, { ruch: [1.15, 1], we: W("odkryj-dol", 0, 0.9) }),
      T("tytul", 70, 170, { rozmiar: 104, font: "n", waga: 700, interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.3, 0.8) }),
      ...[0, 1, 2, 3].flatMap((i) => [
        TL("0" + (i + 1), 70, 620 + i * 260, { rozmiar: 64, font: "n", waga: 700, kolor: "$d", we: W("zanik", 0.7 + i * 0.25, 0.5) }),
        T("k" + (i + 1), 70, 710 + i * 260, { rozmiar: 36, font: "t", waga: 600, szer: 420, we: W("lewo", 0.75 + i * 0.25, 0.6) }),
        L(70, 800 + i * 260, 300, 800 + i * 260, "$t", 2, { we: W("rysuj", 0.8 + i * 0.25, 0.5) }),
      ]),
    ] });

  // ======================= ZAPOWIEDZI I ZAKOŃCZENIA =======================
  dodaj({ id: "za-nowy-post", nazwa: "Nowy post (przesuń w górę)", kat: "zakonczenia", czas: 6, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie z posta"), tx("tytul", "Tytuł", "NOWY\nPOST"), tx("opis", "Opis", "zobacz na profilu")],
    warstwy: [
      T("tytul", 540, 220, { rozmiar: 170, font: "n", waga: 700, wyr: "srodek", interlinia: 0.92, wielkie: true, we: W("maska-gora", 0.1, 0.8) }),
      P(240, 620, 600, 750, "#FFFFFF", { we: W("pop", 0.4, 0.8, "sprezyna") }),
      Z("z1", 270, 650, 540, 600, { ruch: [1.12, 1], we: W("zanik", 0.7, 0.6) }),
      TR(540, 1560, 40, "$t", { obrot: 0, we: W("gora", 1.0, 0.6) }), TR(540, 1620, 40, "$t", { obrot: 0, krycie: 0.5, we: W("gora", 1.1, 0.6) }),
      T("opis", 540, 1700, { rozmiar: 34, font: "t", waga: 600, wyr: "srodek", rozstaw: 150, we: W("zanik", 1.2, 0.6) }),
    ] });
  dodaj({ id: "za-obserwuj", nazwa: "Obserwuj profil", kat: "zakonczenia", czas: 6, kolory: { tl: "#111111", t: "#FFFFFF", a: "#3B82F6", g: "#1E1E1E", d: "#9A9A9A" },
    pola: [zd("z1", "Zdjęcie profilowe"), tx("nick", "Nick", "@nadamedia"), tx("opis", "Opis", "Więcej takich treści codziennie"), tx("przycisk", "Przycisk", "OBSERWUJ")],
    warstwy: [
      K(540, 620, 230, "$a", { obrys: 8, we: W("rysuj", 0.1, 0.9) }),
      Z("z1", 330, 410, 420, 420, { maska: "kolo", ruch: [1.12, 1], we: W("skala", 0.3, 0.7) }),
      T("nick", 540, 940, { rozmiar: 76, font: "t", waga: 700, wyr: "srodek", we: W("maska-gora", 0.6, 0.7) }),
      T("opis", 540, 1060, { rozmiar: 36, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 0.8, 0.6) }),
      P(300, 1200, 480, 120, "$a", { r: 24, we: W("pop", 1.0, 0.7, "sprezyna") }),
      T("przycisk", 540, 1238, { rozmiar: 40, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, we: W("zanik", 1.2, 0.4) }),
    ] });
  dodaj({ id: "za-dziekuje", nazwa: "Dziękuję za obejrzenie", kat: "zakonczenia", czas: 5, kolory: BIALE,
    pola: [lg("logo", "Logo"), tx("tytul", "Tekst", "Thanks for watching"), tx("opis", "Pod spodem", "do zobaczenia jutro")],
    warstwy: [
      Z("logo", 390, 560, 300, 300, { dopasuj: "zawrzyj", we: W("skala", 0.1, 0.7) }),
      T("tytul", 540, 960, { rozmiar: 80, font: "t", waga: 300, wyr: "srodek", we: W("maska-gora", 0.4, 0.8) }),
      L(470, 1100, 610, 1100, "$t", 2, { we: W("rysuj", 0.8, 0.5) }),
      T("opis", 540, 1140, { rozmiar: 32, font: "t", wyr: "srodek", kolor: "$d", we: W("zanik", 1.0, 0.6) }),
    ] });
  dodaj({ id: "za-pytanie", nazwa: "Pytanie do widzów", kat: "zakonczenia", czas: 7, kolory: { tl: "#FFD43B", t: "#111111", a: "#111111", g: "#FFFFFF", d: "#5C4A00" },
    pola: [tx("nad", "Nadtytuł", "PYTANIE DNIA"), tx("pytanie", "Pytanie", "Kawa czy herbata?"), tx("o1", "Odpowiedź A", "KAWA ☕"), tx("o2", "Odpowiedź B", "HERBATA 🍵")],
    warstwy: [
      T("nad", 540, 500, { rozmiar: 32, font: "t", waga: 800, wyr: "srodek", rozstaw: 400, we: W("zanik", 0.1, 0.6) }),
      T("pytanie", 540, 600, { rozmiar: 120, font: "n", waga: 700, wyr: "srodek", szer: 900, interlinia: 1.0, wielkie: true, we: W("maska-gora", 0.3, 0.8) }),
      P(140, 1060, 800, 150, "$g", { r: 75, we: W("lewo", 0.8, 0.6) }), T("o1", 540, 1110, { rozmiar: 52, font: "t", waga: 800, wyr: "srodek", we: W("zanik", 0.9, 0.5) }),
      P(140, 1260, 800, 150, "$g", { r: 75, we: W("prawo", 1.0, 0.6) }), T("o2", 540, 1310, { rozmiar: 52, font: "t", waga: 800, wyr: "srodek", we: W("zanik", 1.1, 0.5) }),
    ] });
  dodaj({ id: "za-tytulowa", nazwa: "Plansza tytułowa serii", kat: "zakonczenia", czas: 5, kolory: { tl: "#111111", t: "#FFFFFF", a: "#FF6B2C", g: "#1E1E1E", d: "#9A9A9A" },
    pola: [tx("numer", "Odcinek", "ODC. 07"), tx("tytul", "Tytuł", "JAK ZACZĄĆ\nNAGRYWAĆ"), tx("opis", "Seria", "seria: montaż od zera")],
    warstwy: [
      P(90, 700, 30, 360, "$a", { we: W("odkryj-gora", 0.1, 0.5) }),
      T("numer", 160, 690, { rozmiar: 40, font: "t", waga: 700, rozstaw: 300, kolor: "$a", we: W("lewo", 0.3, 0.6) }),
      T("tytul", 160, 760, { rozmiar: 130, font: "n", waga: 700, interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.4, 0.8) }),
      T("opis", 160, 1080, { rozmiar: 36, font: "t", kolor: "$d", we: W("gora", 0.8, 0.6) }),
    ] });

  // ---------- zdjęcia zastępcze (gdy nie ma pliku) ----------
  const ZASTEPCZE = [["#C9B8A6", "#5E4B3C"], ["#A9B7C6", "#33414F"], ["#C7C2B8", "#4A4740"], ["#B9A3A0", "#4C3633"], ["#AFC0A8", "#36452F"], ["#D2C1A0", "#6B5634"]];
  let fabryka = null;
  function nowyCanvas(w, h) {
    if (fabryka) return fabryka(w, h);
    if (typeof OffscreenCanvas !== "undefined") return new OffscreenCanvas(w, h);
    const c = document.createElement("canvas"); c.width = w; c.height = h; return c;
  }
  const pamiecZastepczych = {};
  function zastepcze(nr, w = 800, h = 1000) {
    const k = nr + "_" + w + "x" + h;
    if (pamiecZastepczych[k]) return pamiecZastepczych[k];
    const c = nowyCanvas(w, h), x = c.getContext("2d"), [a, b] = ZASTEPCZE[nr % ZASTEPCZE.length];
    const g = x.createLinearGradient(0, 0, w * 0.4, h); g.addColorStop(0, a); g.addColorStop(1, b);
    x.fillStyle = g; x.fillRect(0, 0, w, h);
    x.globalAlpha = 0.18; x.fillStyle = "#FFFFFF";
    x.beginPath(); x.arc(w * 0.68, h * 0.3, Math.min(w, h) * 0.28, 0, Math.PI * 2); x.fill();
    x.globalAlpha = 0.12; x.fillStyle = "#000000";
    x.beginPath(); x.ellipse(w * 0.4, h * 0.95, w * 0.7, h * 0.32, 0, 0, Math.PI * 2); x.fill();
    x.globalAlpha = 0.5; x.strokeStyle = "#FFFFFF"; x.lineWidth = Math.max(2, w / 180);
    const s = Math.min(w, h) * 0.12, cx = w / 2, cy = h / 2;
    x.strokeRect(cx - s, cy - s * 0.7, s * 2, s * 1.4); x.beginPath(); x.arc(cx, cy, s * 0.4, 0, Math.PI * 2); x.stroke();
    x.globalAlpha = 1;
    return (pamiecZastepczych[k] = c);
  }

  // ---------- przygotowanie szablonu z wartościami ----------
  const FONTY_DOM = { n: { rodzina: "Oswald", waga: 700 }, t: { rodzina: "Montserrat", waga: 400 } };
  function znajdz(id) { return SZABLONY.find((s) => s.id === id) || null; }
  /* wartosci: {pola: {id: tekst}, zdjecia: {id: obraz|null}, ustawieniaZdjec: {id: {skala, x, y, bw, ruch}}, kolory: {...},
                skaleTekstow: {_wszystkie: 1, <pole>: 1.2} (mnożniki wielkości tekstów),
                fonty: {n: {rodzina, waga}, t: {...}}, czas (s), tempo (mnożnik) } */
  function stan(sz, wart = {}) {
    const kol = Object.assign({}, sz.kolory || CIEMNE, wart.kolory || {});
    const fonty = { n: Object.assign({}, FONTY_DOM.n, (wart.fonty || {}).n || {}), t: Object.assign({}, FONTY_DOM.t, (wart.fonty || {}).t || {}) };
    const czas = +wart.czas || sz.czas || 7;
    const tempo = +wart.tempo || 1;
    const wyjscie = Object.assign({ typ: "zanik", d: 0.45 }, sz.wyjscie || {}, wart.wyjscie || {});
    return { sz, kol, fonty, czas, tempo, wyjscie, wart };
  }
  function tekstPola(st, w) {
    if (w.tekst != null) return String(w.tekst);
    const pola = st.wart.pola || {}, p = (st.sz.pola || []).find((x) => x.id === w.pole);
    const v = pola[w.pole] != null ? pola[w.pole] : p ? p.dom : "";
    return String(v == null ? "" : v);
  }
  const fontCSS = (st, w, px) => {
    const f = st.fonty[w.font || "t"];
    return `${f.kursywa ? "italic " : ""}${f.wymus ? f.waga : (w.waga || f.waga)} ${Math.max(1, Math.round(px))}px "${f.rodzina}", "Segoe UI", Arial, sans-serif`;
  };
  function szerTekstu(ctx, t, rozstawPx) {
    if (!rozstawPx) return ctx.measureText(t).width;
    let s = 0; for (const c of Array.from(t)) s += ctx.measureText(c).width + rozstawPx; return Math.max(0, s - rozstawPx);
  }
  /* Układ tekstu w jednostkach bazowych: linie, szerokość, wysokość, linia bazowa pierwszego wiersza. */
  function ukladTekstu(ctx, st, w) {
    let t = tekstPola(st, w);
    if (w.wielkie) t = t.toLocaleUpperCase("pl");
    const sk = st.wart.skaleTekstow || {}, mn = (+sk._wszystkie || 1) * (+sk[w.pole] || 1); // wielkość ustawiona w panelu
    let px = (w.rozmiar || 40) * mn, rozstaw = (w.rozstaw || 0) / 1000 * px;
    ctx.font = fontCSS(st, w, px);
    if (!w.szer) {
      // dłuższy tekst niż w przykładzie: zmniejsz font, żeby nie wyszedł poza kadr ani na sąsiednie elementy
      const wyr0 = w.wyr || "lewo", limit = w.maks || (wyr0 === "srodek" ? 2 * Math.min(w.x, BW - w.x) - 100 : wyr0 === "prawo" ? w.x - 70 : BW - w.x - 70);
      const najszersza = Math.max(0, ...t.split(/\n/).map((l) => szerTekstu(ctx, l, rozstaw)));
      if (!w.obrot && najszersza > limit && limit > 50) { px *= limit / najszersza; rozstaw = (w.rozstaw || 0) / 1000 * px; ctx.font = fontCSS(st, w, px); }
    }
    const linie = [];
    t.split(/\n/).forEach((akapit) => {
      if (!w.szer) { linie.push(akapit); return; }
      let biez = "";
      akapit.split(/\s+/).filter(Boolean).forEach((sl) => {
        const prob = biez ? biez + " " + sl : sl;
        if (biez && szerTekstu(ctx, prob, rozstaw) > w.szer) { linie.push(biez); biez = sl; } else biez = prob;
      });
      linie.push(biez);
    });
    const lh = px * (w.interlinia || 1.2), szer = Math.max(0, ...linie.map((l) => szerTekstu(ctx, l, rozstaw)));
    const wyr = w.wyr || "lewo", lewa = wyr === "srodek" ? w.x - szer / 2 : wyr === "prawo" ? w.x - szer : w.x;
    return { linie, px, lh, rozstaw, szer, wys: lh * (linie.length - 1) + px * 0.9, lewa, gora: w.y, baza: w.y + px * 0.78, wyr };
  }
  function granice(ctx, st, w) {
    if (w.typ === "kolo" || w.typ === "trojkat") return { x: w.x - w.r, y: w.y - w.r, w: w.r * 2, h: w.r * 2 };
    if (w.typ === "linia") return { x: Math.min(w.x1, w.x2), y: Math.min(w.y1, w.y2), w: Math.abs(w.x2 - w.x1) || w.g, h: Math.abs(w.y2 - w.y1) || w.g };
    if (w.typ === "tekst") { const u = ukladTekstu(ctx, st, w); return { x: u.lewa, y: w.y, w: u.szer, h: u.wys, u }; }
    return { x: w.x, y: w.y, w: w.w, h: w.h };
  }

  // ---------- ruch ----------
  function okno(t, od, dl) { return dl <= 0 ? (t >= od ? 1 : 0) : clamp((t - od) / dl); }
  function animacja(st, w, t) {
    const r = { a: 1, dx: 0, dy: 0, sk: 1, clip: null, frac: 1, raw: 1, maskaGora: 0 };
    const we = w.we, tempo = st.tempo;
    if (we) {
      const raw = okno(t, we.t / tempo, (we.d || 0.7) / tempo), e = (EASE[we.e || "plynnie"] || EASE.plynnie)(raw);
      r.raw = raw;
      switch (we.typ) {
        case "zanik": r.a *= e; break;
        case "gora": r.dy += (1 - e) * 90; r.a *= e; break;
        case "dol": r.dy -= (1 - e) * 90; r.a *= e; break;
        case "lewo": r.dx -= (1 - e) * 140; r.a *= e; break;
        case "prawo": r.dx += (1 - e) * 140; r.a *= e; break;
        case "skala": r.sk *= 0.82 + 0.18 * e; r.a *= e; break;
        case "pop": r.sk *= Math.max(0, EASE.sprezyna(raw)); r.a *= clamp(raw * 3); break;
        case "zoom": r.sk *= 1.25 - 0.25 * e; r.a *= e; break;
        case "odkryj-lewo": r.clip = [0, 0, e, 1]; break;
        case "odkryj-prawo": r.clip = [1 - e, 0, 1, 1]; break;
        case "odkryj-gora": r.clip = [0, 0, 1, e]; break;
        case "odkryj-dol": r.clip = [0, 1 - e, 1, 1]; break;
        case "maska-gora": r.maskaGora = 1 - e; break;
        case "rysuj": r.frac = e; break;
        case "pisz": r.frac = raw; break;
        case "licz": r.frac = e; r.a *= clamp(raw * 4); break;
      }
    }
    const wy = w.wy || st.wyjscie;
    if (wy && wy.typ !== "brak") {
      const start = wy.t != null ? wy.t : st.czas - (wy.d || 0.45);
      const x = EASE.wej(okno(t, start, wy.d || 0.45));
      if (x > 0) {
        switch (wy.typ) {
          case "gora": r.dy -= x * 90; r.a *= 1 - x; break;
          case "lewo": r.dx -= x * 140; r.a *= 1 - x; break;
          case "skala": r.sk *= 1 - 0.18 * x; r.a *= 1 - x; break;
          default: r.a *= 1 - x;
        }
      }
    }
    r.a *= w.krycie == null ? 1 : w.krycie;
    return r;
  }

  // ---------- rysowanie ----------
  function sciezkaMaski(ctx, m, x, y, w, h, r) {
    ctx.beginPath();
    if (m && typeof m === "object") { ctx.rect(m.x, m.y, m.w, m.h); return; }
    if (m === "kolo") ctx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
    else if (m === "romb") { ctx.moveTo(x + w / 2, y); ctx.lineTo(x + w, y + h / 2); ctx.lineTo(x + w / 2, y + h); ctx.lineTo(x, y + h / 2); ctx.closePath(); }
    else if (m === "luk") { ctx.moveTo(x, y + h); ctx.lineTo(x, y + w / 2); ctx.arc(x + w / 2, y + w / 2, w / 2, Math.PI, 0); ctx.lineTo(x + w, y + h); ctx.closePath(); }
    else if (m === "zaokr") zaokr(ctx, x, y, w, h, r || 40, true);
    else ctx.rect(x, y, w, h);
  }
  function zaokr(ctx, x, y, w, h, r, bezBegin) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    if (!bezBegin) ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function obwodProst(x, y, w, h) { return [[x, y], [x + w, y], [x + w, y + h], [x, y + h], [x, y]]; }
  function czescSciezki(ctx, pkt, e) {
    let suma = 0; const dl = [];
    for (let i = 1; i < pkt.length; i++) { const d = Math.hypot(pkt[i][0] - pkt[i - 1][0], pkt[i][1] - pkt[i - 1][1]); dl.push(d); suma += d; }
    let zost = suma * clamp(e); ctx.beginPath(); ctx.moveTo(...pkt[0]);
    for (let i = 1; i < pkt.length && zost > 0; i++) { const k = Math.min(1, zost / dl[i - 1]); ctx.lineTo(lerp(pkt[i - 1][0], pkt[i][0], k), lerp(pkt[i - 1][1], pkt[i][1], k)); zost -= dl[i - 1]; }
  }
  function liczba(t, frac) {
    const m = String(t).match(/^([^\d-]*)(-?[\d]+(?:[.,]\d+)?)(.*)$/s);
    if (!m) return t;
    const v = parseFloat(m[2].replace(",", ".")), miejsca = (m[2].split(/[.,]/)[1] || "").length;
    return m[1] + (v * frac).toFixed(miejsca).replace(".", m[2].includes(",") ? "," : ".") + m[3];
  }
  function obrazDla(st, pole) { const z = (st.wart.zdjecia || {})[pole]; return z && (z.videoWidth || z.naturalWidth || z.width) ? z : null; }
  function rysujZdjecie(ctx, st, w, idx) {
    const us = (st.wart.ustawieniaZdjec || {})[w.pole] || {};
    const img = obrazDla(st, w.pole) || (w.dopasuj === "zawrzyj" ? null : zastepcze(idx, Math.round(w.w), Math.round(w.h)));
    ctx.save();
    if (w.obrot) { ctx.translate(w.x + w.w / 2, w.y + w.h / 2); ctx.rotate(w.obrot * Math.PI / 180); ctx.translate(-(w.x + w.w / 2), -(w.y + w.h / 2)); }
    sciezkaMaski(ctx, w.maska, w.x, w.y, w.w, w.h, w.r); ctx.clip();
    if (!img) { // logo bez pliku: napis zastępczy
      ctx.fillStyle = rgba(st.kol.t, 0.15); ctx.fillRect(w.x, w.y, w.w, w.h);
      ctx.fillStyle = st.kol.t; ctx.font = `600 ${Math.round(w.h * 0.14)}px "Segoe UI", Arial`; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.fillText("LOGO", w.x + w.w / 2, w.y + w.h / 2); ctx.restore(); return;
    }
    const iw = img.videoWidth || img.naturalWidth || img.width, ih = img.videoHeight || img.naturalHeight || img.height;
    const pas = w.dopasuj === "zawrzyj" ? Math.min(w.w / iw, w.h / ih) : Math.max(w.w / iw, w.h / ih);
    const ruch = us.ruch === "brak" ? [1, 1] : us.ruch === "oddal" ? [1, 1.15] : (w.ruch || [1, 1]);
    const p = clamp(st.t / st.czas), sk = pas * (+us.skala || 1) * lerp(ruch[0], ruch[1], EASE.plynnie(p));
    const dw = iw * sk, dh = ih * sk;
    const cx = w.x + w.w / 2 + (+us.x || 0) * w.w / 2, cy = w.y + w.h / 2 + (+us.y || 0) * w.h / 2;
    if ((w.bw && us.bw !== false) || us.bw === true) ctx.filter = "grayscale(1)";
    ctx.drawImage(img, cx - dw / 2, cy - dh / 2, dw, dh);
    ctx.restore();
  }
  function rysujTekst(ctx, st, w, a, b) {
    const u = b.u, kol = kolor(w.kolor || "$t", st.kol);
    ctx.font = fontCSS(st, w, u.px); ctx.fillStyle = kol; ctx.textBaseline = "alphabetic"; ctx.textAlign = "left";
    let linie = u.linie;
    if (w.we && w.we.typ === "pisz") {
      const wszystkie = linie.join("\n"), n = Math.floor(wszystkie.length * a.frac);
      linie = wszystkie.slice(0, n).split("\n");
    }
    if (w.we && w.we.typ === "licz") linie = linie.map((l) => liczba(l, a.frac));
    linie.forEach((l, i) => {
      const sz = szerTekstu(ctx, l, u.rozstaw);
      let x = u.wyr === "srodek" ? w.x - sz / 2 : u.wyr === "prawo" ? w.x - sz : w.x;
      const y = u.baza + i * u.lh;
      if (!u.rozstaw) ctx.fillText(l, x, y);
      else for (const c of Array.from(l)) { ctx.fillText(c, x, y); x += ctx.measureText(c).width + u.rozstaw; }
    });
  }
  function rysujWarstwe(ctx, st, w, t, idx) {
    const b = granice(ctx, st, w), a = animacja(st, w, t);
    if (a.a <= 0.001) return;
    ctx.save();
    ctx.globalAlpha = a.a;
    ctx.translate(a.dx, a.dy);
    const cx = b.x + b.w / 2, cy = b.y + b.h / 2;
    if (a.sk !== 1) { ctx.translate(cx, cy); ctx.scale(a.sk, a.sk); ctx.translate(-cx, -cy); }
    if (w.obrot && w.typ !== "zdjecie" && w.typ !== "trojkat") {
      const ox = w.typ === "tekst" ? w.x : cx, oy = w.typ === "tekst" ? w.y : cy;
      ctx.translate(ox, oy); ctx.rotate(w.obrot * Math.PI / 180); ctx.translate(-ox, -oy);
    }
    if (a.clip) { const [x0, y0, x1, y1] = a.clip; ctx.beginPath(); ctx.rect(b.x + b.w * x0 - 2, b.y + b.h * y0 - 2, b.w * (x1 - x0) + 4, b.h * (y1 - y0) + 4); ctx.clip(); }
    if (a.maskaGora) { ctx.beginPath(); ctx.rect(b.x - 40, b.y - 10, b.w + 80, b.h + 30); ctx.clip(); ctx.translate(0, a.maskaGora * (b.h + 30)); }
    const kol = kolor(w.kolor, st.kol);
    switch (w.typ) {
      case "prost":
        if (w.obrys) {
          ctx.strokeStyle = kol; ctx.lineWidth = w.obrys;
          if (w.we && w.we.typ === "rysuj") { czescSciezki(ctx, obwodProst(w.x, w.y, w.w, w.h), a.frac); ctx.stroke(); }
          else { if (w.r) zaokr(ctx, w.x, w.y, w.w, w.h, w.r); else { ctx.beginPath(); ctx.rect(w.x, w.y, w.w, w.h); } ctx.stroke(); }
        } else { ctx.fillStyle = kol; if (w.r) { zaokr(ctx, w.x, w.y, w.w, w.h, w.r); ctx.fill(); } else ctx.fillRect(w.x, w.y, w.w, w.h); }
        break;
      case "kolo":
        ctx.beginPath();
        if (w.obrys) {
          const e = w.we && w.we.typ === "rysuj" ? a.frac : 1;
          // pełny okrąg od 0 do 2π: @napi-rs/canvas (render.js) nie rysuje okręgu zaczętego od -90° i zamkniętego po pełnym obrocie
          if (e >= 0.9999) ctx.arc(w.x, w.y, w.r, 0, Math.PI * 2); else ctx.arc(w.x, w.y, w.r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * e);
          ctx.strokeStyle = kol; ctx.lineWidth = w.obrys; ctx.stroke();
        }
        else { ctx.arc(w.x, w.y, w.r, 0, Math.PI * 2); ctx.fillStyle = kol; ctx.fill(); }
        break;
      case "trojkat": {
        ctx.translate(w.x, w.y); ctx.rotate(((w.obrot || 0) - 90) * Math.PI / 180);
        ctx.beginPath(); for (let i = 0; i < 3; i++) { const k = (i * 2 * Math.PI) / 3; ctx[i ? "lineTo" : "moveTo"](Math.cos(k) * w.r, Math.sin(k) * w.r); }
        ctx.closePath(); ctx.fillStyle = kol; ctx.fill(); break;
      }
      case "linia": ctx.strokeStyle = kol; ctx.lineWidth = w.g; ctx.lineCap = "butt"; czescSciezki(ctx, [[w.x1, w.y1], [w.x2, w.y2]], a.frac); ctx.stroke(); break;
      case "cien": {
        const g = ctx.createLinearGradient(0, w.y, 0, w.y + w.h); g.addColorStop(0, rgba(kol, w.od)); g.addColorStop(1, rgba(kol, w.do));
        ctx.fillStyle = g; ctx.fillRect(w.x, w.y, w.w, w.h); break;
      }
      case "zdjecie": rysujZdjecie(ctx, st, w, idx); break;
      case "tekst": rysujTekst(ctx, st, w, a, b); break;
    }
    ctx.restore();
  }
  /* Klatka szablonu w czasie t (s) na płótnie W×H. */
  function rysuj(ctx, szOrId, t, wart, W, H, opcje = {}) {
    const sz = typeof szOrId === "string" ? znajdz(szOrId) : szOrId;
    if (!sz) throw new Error("Nie ma szablonu " + szOrId);
    const st = stan(sz, wart); st.t = t;
    ctx.save();
    ctx.scale(W / BW, H / BH);
    if (!opcje.bezTla) {
      const a = animacja(st, { we: { typ: "zanik", t: 0, d: 0.25 }, wy: { typ: "brak" } }, t);
      ctx.globalAlpha = a.a; ctx.fillStyle = st.kol.tl; ctx.fillRect(0, 0, BW, BH); ctx.globalAlpha = 1;
    }
    const nrPola = {};
    sz.warstwy.forEach((w) => { if (w.typ === "zdjecie" && !(w.pole in nrPola)) nrPola[w.pole] = Object.keys(nrPola).length; });
    sz.warstwy.forEach((w) => { const idx = w.typ === "zdjecie" ? nrPola[w.pole] : 0; try { rysujWarstwe(ctx, st, w, t, idx); } catch (e) { /* pojedyncza warstwa nie psuje klatki */ } });
    ctx.restore();
    return st;
  }
  function czas(szOrId, wart) { const sz = typeof szOrId === "string" ? znajdz(szOrId) : szOrId; return sz ? stan(sz, wart).czas : 7; }

  /* Opis dla After Effects: wszystko policzone (kolory, linie tekstu, granice), w pikselach kompozycji W×H. */
  const WAGI = { 100: "Thin", 200: "ExtraLight", 300: "Light", 400: "Regular", 500: "Medium", 600: "SemiBold", 700: "Bold", 800: "ExtraBold", 900: "Black" };
  function doAE(ctx, szOrId, wart, W = BW, H = BH) {
    const sz = typeof szOrId === "string" ? znajdz(szOrId) : szOrId, st = stan(sz, wart), s = W / BW;
    const k = (v) => v * s, rgb01 = (h) => hex(h).map((v) => +(v / 255).toFixed(4));
    const wynik = { id: sz.id, nazwa: sz.nazwa, W, H, czas: st.czas, tlo: rgb01(st.kol.tl), warstwy: [] };
    const tempo = st.tempo, an = (x) => x && Object.assign({}, x, { t: (x.t || 0) / tempo, d: (x.d || 0.7) / tempo });
    sz.warstwy.forEach((w, i) => {
      const b = granice(ctx, st, w);
      const o = { typ: w.typ, nazwa: "", x: k(b.x), y: k(b.y), w: k(b.w), h: k(b.h), krycie: w.krycie == null ? 1 : w.krycie, obrot: w.obrot || 0,
        we: an(w.we), wy: w.wy || Object.assign({}, st.wyjscie, { t: st.wyjscie.t != null ? st.wyjscie.t : st.czas - (st.wyjscie.d || 0.45) }) };
      if (w.kolor) o.kolor = rgb01(kolor(w.kolor, st.kol));
      if (w.typ === "prost") Object.assign(o, { r: k(w.r || 0), obrys: w.obrys ? k(w.obrys) : 0, nazwa: "Kształt " + (i + 1) });
      if (w.typ === "kolo") Object.assign(o, { cx: k(w.x), cy: k(w.y), promien: k(w.r), obrys: w.obrys ? k(w.obrys) : 0, nazwa: "Koło " + (i + 1) });
      if (w.typ === "trojkat") Object.assign(o, { cx: k(w.x), cy: k(w.y), promien: k(w.r), nazwa: "Trójkąt " + (i + 1) });
      if (w.typ === "linia") Object.assign(o, { x1: k(w.x1), y1: k(w.y1), x2: k(w.x2), y2: k(w.y2), g: k(w.g), nazwa: "Linia " + (i + 1) });
      if (w.typ === "cien") Object.assign(o, { od: w.od, do: w.do, nazwa: "Cień " + (i + 1) });
      if (w.typ === "zdjecie") {
        const us = (st.wart.ustawieniaZdjec || {})[w.pole] || {};
        const m = w.maska && typeof w.maska === "object" ? { x: k(w.maska.x), y: k(w.maska.y), w: k(w.maska.w), h: k(w.maska.h) } : (w.maska || "prost");
        Object.assign(o, { pole: w.pole, plik: ((st.wart.plikiZdjec || {})[w.pole]) || null, klip: ((st.wart.klipy || {})[w.pole]) || null, maska: m, r: k(w.r || 40), bw: (w.bw && us.bw !== false) || us.bw === true,
          ruch: us.ruch === "brak" ? [1, 1] : us.ruch === "oddal" ? [1, 1.15] : (w.ruch || [1, 1]), skala: +us.skala || 1, przes: [+us.x || 0, +us.y || 0],
          dopasuj: w.dopasuj || "wypelnij", nazwa: ((sz.pola || []).find((p) => p.id === w.pole) || {}).etykieta || w.pole });
      }
      if (w.typ === "tekst") {
        const u = b.u, f = st.fonty[w.font || "t"], waga = f.wymus ? f.waga : (w.waga || f.waga);
        Object.assign(o, { linie: u.linie, rozmiar: k(u.px), rodzina: f.rodzina, waga, font: f.rodzina.replace(/\s+/g, "") + "-" + ((WAGI[waga] || "Regular") + (f.kursywa ? "Italic" : "")).replace("RegularItalic", "Italic"),
          wyr: u.wyr, rozstaw: w.rozstaw || 0, interlinia: k(u.lh), px: k(w.x), baza: k(u.baza), wielkie: !!w.wielkie,
          kolor: rgb01(kolor(w.kolor || "$t", st.kol)), nazwa: ((sz.pola || []).find((p) => p.id === w.pole) || {}).etykieta || (u.linie[0] || "Tekst").slice(0, 24) });
      }
      wynik.warstwy.push(o);
    });
    return wynik;
  }


  // =====================================================================
  // ---------- wersja 17: dużo nowych szablonów w każdej kategorii ----------
  // =====================================================================
  KATEGORIE.splice(KATEGORIE.findIndex((k) => k.id === "wlasne"), 0, { id: "porady", nazwa: "Porady i listy" }, { id: "opinie", nazwa: "Opinie i rekomendacje" });
  const PAL = {
    noc: CIEMNE, papier: JASNE, biel: BIALE,
    granat: { tl: "#0F1B33", t: "#FFFFFF", a: "#F5C542", g: "#1C2C4F", d: "#9FB0CF" },
    oliwka: { tl: "#2F3A2C", t: "#F3EFE6", a: "#D9B26A", g: "#44533F", d: "#B6BFA9" },
    roz: { tl: "#F7E3E1", t: "#3B1F27", a: "#E2557A", g: "#FFFFFF", d: "#9B6F78" },
    piasek: { tl: "#E9DFCF", t: "#2A2420", a: "#B5651D", g: "#F7F2EA", d: "#8C7E6E" },
    limonka: { tl: "#111111", t: "#FFFFFF", a: "#C6F432", g: "#222222", d: "#A0A0A0" },
    fiolet: { tl: "#1B1033", t: "#FFFFFF", a: "#A78BFA", g: "#2D1B54", d: "#B8A9D9" },
    czerwien: { tl: "#141414", t: "#FFFFFF", a: "#FF3D3D", g: "#262626", d: "#A3A3A3" },
    mieta: { tl: "#DFF3EA", t: "#0F2E24", a: "#13A37A", g: "#FFFFFF", d: "#5E8577" },
    pomarancz: { tl: "#FF6B2C", t: "#FFFFFF", a: "#111111", g: "#FF8A57", d: "#FFE1D2" },
    zolty: { tl: "#FFD23F", t: "#111111", a: "#111111", g: "#FFFFFF", d: "#5C4A00" },
    niebo: { tl: "#EAF2FF", t: "#0B1F44", a: "#2563EB", g: "#FFFFFF", d: "#6B7FA3" },
  };
  const S = (o) => dodaj(o);
  const Zp = (pole, x, y, w, h, o = {}) => Z(pole, x, y, w, h, Object.assign({ ruch: [1.14, 1] }, o));

  // ---------- EDYTORSKIE ----------
  [["ed-pelne-ramka", "Pełne zdjęcie z ramką i tytułem", "noc"], ["ed-pelne-ramka-jasne", "Zdjęcie z ramką na jasnym", "papier"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "edytorskie", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie"), tx("nad", "Nadtytuł", "HISTORIA MARKI"), tx("tytul", "Tytuł", "Tworzymy\nz pasją"), tx("opis", "Opis", "Od małej pracowni do marki, którą zna cała Polska.", 2)],
    warstwy: [
      Zp("z1", 60, 60, 960, 1220, { we: W("odkryj-dol", 0.05, 0.9) }),
      P(100, 100, 880, 1140, "$tl", { obrys: 4, we: W("rysuj", 0.6, 0.9) }),
      T("nad", 90, 1350, { rozmiar: 24, font: "t", waga: 700, rozstaw: 250, kolor: "$a", we: W("lewo", 0.8, 0.6) }),
      T("tytul", 90, 1400, { rozmiar: 110, font: "n", waga: 700, interlinia: 1.0, wielkie: true, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 90, 1660, { rozmiar: 32, font: "t", szer: 880, kolor: "$d", interlinia: 1.4, we: W("gora", 1.3, 0.6) }),
    ] }));
  [["ed-dwa-pionowe", "Dwa pionowe zdjęcia i tytuł", "biel"], ["ed-dwa-pionowe-granat", "Dwa pionowe zdjęcia, granat", "granat"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "edytorskie", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie lewe"), zd("z2", "Zdjęcie prawe"), tx("tytul", "Tytuł", "Przed sezonem"), tx("opis", "Opis", "Nowe kolory, nowe formy i więcej światła.", 2), tx("stopka", "Stopka", "NR 04 / 2026")],
    warstwy: [
      Zp("z1", 60, 200, 470, 900, { we: W("odkryj-gora", 0.1, 0.9) }),
      Zp("z2", 550, 340, 470, 900, { we: W("odkryj-dol", 0.3, 0.9) }),
      T("tytul", 90, 1300, { rozmiar: 104, font: "n", waga: 700, wielkie: true, szer: 900, we: W("maska-gora", 0.8, 0.8) }),
      L(90, 1560, 400, 1560, "$a", 5, { we: W("rysuj", 1.1, 0.6) }),
      T("opis", 90, 1600, { rozmiar: 32, font: "t", szer: 800, kolor: "$d", interlinia: 1.4, we: W("gora", 1.2, 0.6) }),
      T("stopka", 990, 1790, { rozmiar: 24, font: "t", waga: 600, rozstaw: 200, wyr: "prawo", we: W("zanik", 1.5, 0.6) }),
    ] }));
  [["ed-luk", "Zdjęcie w łuku", "piasek"], ["ed-luk-oliwka", "Zdjęcie w łuku, oliwka", "oliwka"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "edytorskie", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie"), tx("nad", "Nadtytuł", "NOWA KOLEKCJA"), tx("tytul", "Tytuł", "Spokój\nw detalach"), tx("opis", "Opis", "Ręcznie robione, w małych seriach.")],
    warstwy: [
      T("nad", 540, 160, { rozmiar: 26, font: "t", waga: 700, rozstaw: 300, wyr: "srodek", kolor: "$a", we: W("zanik", 0.1, 0.6) }),
      Zp("z1", 190, 260, 700, 1000, { maska: "luk", we: W("odkryj-gora", 0.2, 1.0) }),
      T("tytul", 540, 1340, { rozmiar: 112, font: "n", waga: 700, wyr: "srodek", interlinia: 1.0, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 540, 1610, { rozmiar: 32, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.2, 0.6) }),
      K(540, 1760, 10, "$a", { we: W("pop", 1.4, 0.5) }),
    ] }));
  S({ id: "ed-gazeta", nazwa: "Strona gazety z kolumnami", kat: "edytorskie", czas: 8, kolory: PAL.papier,
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "WIELKI DZIEŃ\nDLA MIASTA"), tx("opis", "Lead", "Po trzech latach przygotowań otwieramy nowe miejsce w samym centrum. Zobacz, co przygotowaliśmy.", 3), tx("stopka", "Stopka", "WYDANIE SPECJALNE")],
    warstwy: [
      T("stopka", 90, 110, { rozmiar: 24, font: "t", waga: 800, rozstaw: 300, we: W("zanik", 0.1, 0.5) }),
      L(90, 160, 990, 160, "$t", 4, { we: W("rysuj", 0.2, 0.6) }), L(90, 172, 990, 172, "$t", 1, { we: W("rysuj", 0.3, 0.6) }),
      T("tytul", 90, 220, { rozmiar: 120, font: "n", waga: 700, interlinia: 0.98, wielkie: true, we: W("maska-gora", 0.4, 0.8) }),
      Zp("z1", 90, 520, 900, 820, { bw: true, we: W("odkryj-dol", 0.7, 0.9) }),
      T("opis", 90, 1400, { rozmiar: 34, font: "t", szer: 900, interlinia: 1.45, we: W("gora", 1.1, 0.7) }),
      L(90, 1760, 990, 1760, "$t", 2, { we: W("rysuj", 1.4, 0.6) }),
    ] });

  // ---------- MINIMALISTYCZNE ----------
  [["mi-srodek", "Małe zdjęcie na środku", "biel"], ["mi-srodek-noc", "Małe zdjęcie na środku, ciemne", "noc"], ["mi-srodek-roz", "Małe zdjęcie na środku, róż", "roz"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "minimal", czas: 7, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "mniej znaczy więcej"), tx("opis", "Podpis", "kolekcja jesień 2026")],
    warstwy: [
      Zp("z1", 290, 560, 500, 640, { we: W("skala", 0.1, 0.9) }),
      T("tytul", 540, 1290, { rozmiar: 54, font: "t", waga: 300, wyr: "srodek", rozstaw: 60, we: W("maska-gora", 0.7, 0.7) }),
      T("opis", 540, 1380, { rozmiar: 24, font: "t", waga: 600, wyr: "srodek", rozstaw: 300, kolor: "$d", wielkie: true, we: W("zanik", 1.0, 0.6) }),
      L(490, 470, 590, 470, "$t", 2, { we: W("rysuj", 0.6, 0.5) }),
    ] }));
  [["mi-linia", "Tytuł z cienką linią", "biel"], ["mi-linia-mieta", "Tytuł z cienką linią, mięta", "mieta"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "minimal", czas: 7, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "Prosto.\nCzysto.\nPięknie."), tx("stopka", "Stopka", "twojastrona.pl")],
    warstwy: [
      T("tytul", 90, 220, { rozmiar: 100, font: "t", waga: 300, interlinia: 1.1, we: W("lewo", 0.1, 0.9) }),
      L(90, 640, 90, 1780, "$t", 2, { we: W("rysuj", 0.4, 1.0) }),
      Zp("z1", 160, 700, 830, 1000, { we: W("odkryj-gora", 0.5, 0.9) }),
      T("stopka", 990, 1800, { rozmiar: 24, font: "t", waga: 500, wyr: "prawo", kolor: "$d", we: W("zanik", 1.3, 0.6) }),
    ] }));
  S({ id: "mi-slowo", nazwa: "Jedno wielkie słowo", kat: "minimal", czas: 6, kolory: PAL.biel,
    pola: [tx("slowo", "Słowo", "focus"), tx("opis", "Podpis", "Twoja myśl na dziś")],
    warstwy: [
      T("slowo", 540, 760, { rozmiar: 250, font: "t", waga: 800, wyr: "srodek", rozstaw: -30, we: W("maska-gora", 0.1, 0.9) }),
      T("opis", 540, 1080, { rozmiar: 30, font: "t", waga: 500, wyr: "srodek", kolor: "$d", we: W("zanik", 0.8, 0.6) }),
      K(540, 1200, 8, "$t", { we: W("pop", 1.1, 0.5) }),
    ] });

  // ---------- KOŁA I ROMBY ----------
  [["ks-trzy-kola", "Trzy zdjęcia w kołach", "noc"], ["ks-trzy-kola-roz", "Trzy zdjęcia w kołach, róż", "roz"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "ksztalty", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie duże"), zd("z2", "Zdjęcie średnie"), zd("z3", "Zdjęcie małe"), tx("tytul", "Tytuł", "Weekend\nw górach"), tx("opis", "Opis", "Trzy dni, dwa szczyty, jedna ekipa.")],
    warstwy: [
      Zp("z1", 90, 180, 620, 620, { maska: "kolo", we: W("skala", 0.1, 0.9) }),
      Zp("z2", 600, 640, 400, 400, { maska: "kolo", we: W("skala", 0.35, 0.9) }),
      Zp("z3", 220, 900, 260, 260, { maska: "kolo", we: W("skala", 0.6, 0.9) }),
      K(890, 300, 60, "$a", { we: W("pop", 0.9, 0.5, "sprezyna") }),
      T("tytul", 90, 1320, { rozmiar: 120, font: "n", waga: 700, interlinia: 0.98, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 90, 1600, { rozmiar: 32, font: "t", kolor: "$d", we: W("gora", 1.2, 0.6) }),
    ] }));
  [["ks-romb", "Zdjęcie w rombie", "granat"], ["ks-romb-jasny", "Zdjęcie w rombie, jasne", "piasek"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "ksztalty", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "NOWY\nROZDZIAŁ"), tx("opis", "Opis", "Zaczynamy od dziś")],
    warstwy: [
      Zp("z1", 140, 240, 800, 800, { maska: "romb", we: W("skala", 0.1, 1.0) }),
      TR(540, 1180, 40, "$a", { obrot: 180, we: W("pop", 0.8, 0.5) }),
      T("tytul", 540, 1270, { rozmiar: 130, font: "n", waga: 700, wyr: "srodek", interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 540, 1560, { rozmiar: 34, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.2, 0.6) }),
    ] }));
  [["ks-kolo-tlo", "Wielkie koło za zdjęciem", "pomarancz"], ["ks-kolo-tlo-limonka", "Wielkie koło za zdjęciem, limonka", "limonka"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "ksztalty", czas: 7, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie (najlepiej wycięta postać lub produkt)"), tx("tytul", "Tytuł", "ENERGIA\nNA CAŁY DZIEŃ"), tx("opis", "Opis", "Nowy smak już w sklepach")],
    warstwy: [
      K(540, 720, 470, "$g", { we: W("skala", 0.05, 0.9, "sprezyna") }),
      K(540, 720, 520, "$a", { obrys: 4, we: W("rysuj", 0.4, 1.0) }),
      Zp("z1", 190, 330, 700, 820, { maska: "kolo", we: W("gora", 0.5, 0.8) }),
      T("tytul", 540, 1320, { rozmiar: 110, font: "n", waga: 700, wyr: "srodek", interlinia: 0.98, wielkie: true, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 540, 1580, { rozmiar: 34, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.2, 0.6) }),
    ] }));

  // ---------- KOLAŻE ----------
  [["ko-siatka-4", "Siatka czterech zdjęć", "biel"], ["ko-siatka-4-noc", "Siatka czterech zdjęć, ciemna", "noc"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "kolaz", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie 1"), zd("z2", "Zdjęcie 2"), zd("z3", "Zdjęcie 3"), zd("z4", "Zdjęcie 4"), tx("tytul", "Tytuł", "Nasz tydzień"), tx("opis", "Opis", "Najlepsze chwile z planu")],
    warstwy: [
      T("tytul", 90, 150, { rozmiar: 96, font: "n", waga: 700, we: W("maska-gora", 0.05, 0.7) }),
      T("opis", 90, 290, { rozmiar: 30, font: "t", kolor: "$d", we: W("zanik", 0.4, 0.6) }),
      Zp("z1", 60, 400, 470, 620, { we: W("skala", 0.3, 0.7) }), Zp("z2", 550, 400, 470, 620, { we: W("skala", 0.45, 0.7) }),
      Zp("z3", 60, 1040, 470, 620, { we: W("skala", 0.6, 0.7) }), Zp("z4", 550, 1040, 470, 620, { we: W("skala", 0.75, 0.7) }),
      P(60, 1700, 960, 6, "$a", { we: W("odkryj-lewo", 1.2, 0.6) }),
    ] }));
  [["ko-rozrzucone", "Rozrzucone zdjęcia", "piasek"], ["ko-rozrzucone-fiolet", "Rozrzucone zdjęcia, fiolet", "fiolet"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "kolaz", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie 1"), zd("z2", "Zdjęcie 2"), zd("z3", "Zdjęcie 3"), tx("tytul", "Tytuł", "Wspomnienia\nz lata")],
    warstwy: [
      P(120, 200, 560, 700, "$g", { obrot: -6, we: W("pop", 0.1, 0.7, "sprezyna") }), Zp("z1", 150, 230, 500, 600, { obrot: -6, we: W("zanik", 0.3, 0.6) }),
      P(420, 620, 560, 700, "$g", { obrot: 5, we: W("pop", 0.4, 0.7, "sprezyna") }), Zp("z2", 450, 650, 500, 600, { obrot: 5, we: W("zanik", 0.6, 0.6) }),
      P(140, 1060, 480, 560, "$g", { obrot: -2, we: W("pop", 0.7, 0.7, "sprezyna") }), Zp("z3", 165, 1085, 430, 470, { obrot: -2, we: W("zanik", 0.9, 0.6) }),
      T("tytul", 990, 1660, { rozmiar: 96, font: "n", waga: 700, wyr: "prawo", interlinia: 1.0, we: W("maska-gora", 1.1, 0.8) }),
    ] }));
  [["ko-pasy-poziome", "Trzy zdjęcia w poziomych pasach", "noc"], ["ko-pasy-poziome-zolty", "Trzy pasy, żółty", "zolty"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "kolaz", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie 1"), zd("z2", "Zdjęcie 2"), zd("z3", "Zdjęcie 3"), tx("tytul", "Tytuł", "TRZY KROKI"), tx("opis", "Opis", "do lepszej formy")],
    warstwy: [
      Zp("z1", 0, 0, 1080, 520, { we: W("odkryj-lewo", 0.05, 0.8) }), Zp("z2", 0, 540, 1080, 520, { we: W("odkryj-prawo", 0.25, 0.8) }), Zp("z3", 0, 1080, 1080, 520, { we: W("odkryj-lewo", 0.45, 0.8) }),
      P(0, 1600, 1080, 320, "$tl", { we: W("odkryj-gora", 0.6, 0.6) }),
      T("tytul", 90, 1640, { rozmiar: 100, font: "n", waga: 700, wielkie: true, we: W("maska-gora", 0.9, 0.7) }),
      T("opis", 90, 1780, { rozmiar: 34, font: "t", kolor: "$d", we: W("gora", 1.1, 0.6) }),
    ] }));

  // ---------- LICZBY I OBSERWUJĄCY ----------
  [["st-wielka-liczba", "Wielka liczba na środku", "limonka"], ["st-wielka-liczba-granat", "Wielka liczba, granat", "granat"], ["st-wielka-liczba-biel", "Wielka liczba, białe tło", "biel"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "statystyki", czas: 7, kolory: PAL[p],
    pola: [tx("nad", "Nad liczbą", "W TYM ROKU"), tx("liczba", "Liczba", "250 000"), tx("opis", "Pod liczbą", "osób obejrzało nasze rolki"), tx("stopka", "Stopka", "dziękujemy!")],
    warstwy: [
      T("nad", 540, 640, { rozmiar: 30, font: "t", waga: 700, rozstaw: 250, wyr: "srodek", kolor: "$d", we: W("zanik", 0.1, 0.6) }),
      T("liczba", 540, 720, { rozmiar: 200, font: "n", waga: 700, wyr: "srodek", kolor: "$a", maks: 960, we: W("licz", 0.3, 1.5) }),
      T("opis", 540, 1000, { rozmiar: 40, font: "t", waga: 600, wyr: "srodek", szer: 860, we: W("gora", 1.0, 0.6) }),
      L(440, 1170, 640, 1170, "$a", 5, { we: W("rysuj", 1.3, 0.5) }),
      T("stopka", 540, 1230, { rozmiar: 30, font: "t", wyr: "srodek", kolor: "$d", we: W("zanik", 1.5, 0.5) }),
    ] }));
  [["st-wykres", "Słupki wzrostu", "noc"], ["st-wykres-mieta", "Słupki wzrostu, mięta", "mieta"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "statystyki", czas: 8, kolory: PAL[p],
    pola: [tx("tytul", "Tytuł", "Wzrost obserwujących"), tx("l1", "Wartość 1", "2K"), tx("l2", "Wartość 2", "9K"), tx("l3", "Wartość 3", "24K"), tx("l4", "Wartość 4", "61K"), tx("opis", "Podpis", "styczeń – kwiecień")],
    warstwy: [
      T("tytul", 90, 220, { rozmiar: 70, font: "n", waga: 700, szer: 900, we: W("maska-gora", 0.1, 0.7) }),
      ...[260, 480, 760, 1100].map((h, i) => P(110 + i * 230, 1600 - h, 180, h, i === 3 ? "$a" : "$g", { r: 12, we: W("odkryj-gora", 0.4 + i * 0.2, 0.8) })),
      ...[260, 480, 760, 1100].map((h, i) => T("l" + (i + 1), 200 + i * 230, 1600 - h - 80, { rozmiar: 46, font: "t", waga: 800, wyr: "srodek", we: W("licz", 0.7 + i * 0.2, 0.8) })),
      L(90, 1620, 990, 1620, "$d", 3, { we: W("rysuj", 0.3, 0.6) }),
      T("opis", 90, 1680, { rozmiar: 32, font: "t", kolor: "$d", we: W("zanik", 1.5, 0.6) }),
    ] }));
  [["st-kamien-milowy", "Kamień milowy z konfetti", "fiolet"], ["st-kamien-milowy-roz", "Kamień milowy, róż", "roz"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "statystyki", czas: 7, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie profilowe"), tx("liczba", "Liczba", "100K"), tx("tytul", "Tytuł", "Jest nas już"), tx("opis", "Opis", "Dziękuję za każde serduszko!")],
    warstwy: [
      ...[[160, 260, 22], [920, 320, 16], [220, 1500, 18], [860, 1450, 24], [540, 180, 12], [980, 900, 14], [100, 900, 12]].map(([x, y, r], i) => K(x, y, r, i % 2 ? "$a" : "$t", { we: W("pop", 0.8 + i * 0.08, 0.5, "sprezyna") })),
      Zp("z1", 390, 330, 300, 300, { maska: "kolo", we: W("skala", 0.1, 0.7) }),
      T("tytul", 540, 720, { rozmiar: 60, font: "t", waga: 600, wyr: "srodek", we: W("zanik", 0.4, 0.6) }),
      T("liczba", 540, 800, { rozmiar: 280, font: "n", waga: 700, wyr: "srodek", kolor: "$a", we: W("licz", 0.5, 1.4) }),
      T("opis", 540, 1160, { rozmiar: 40, font: "t", wyr: "srodek", szer: 860, we: W("gora", 1.2, 0.6) }),
    ] }));

  // ---------- CYTATY I HASŁA ----------
  [["cy-duzy-cudzyslow", "Duży cudzysłów", "noc"], ["cy-duzy-cudzyslow-piasek", "Duży cudzysłów, piasek", "piasek"], ["cy-duzy-cudzyslow-granat", "Duży cudzysłów, granat", "granat"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "cytaty", czas: 8, kolory: PAL[p],
    pola: [tx("cytat", "Cytat", "Nie musisz być wielki, żeby zacząć. Musisz zacząć, żeby być wielki.", 3), tx("autor", "Autor", "— Zig Ziglar")],
    warstwy: [
      TL("“", 90, 380, { rozmiar: 420, font: "n", waga: 700, kolor: "$a", we: W("pop", 0.05, 0.7, "sprezyna") }),
      T("cytat", 90, 760, { rozmiar: 74, font: "n", waga: 600, szer: 900, interlinia: 1.2, we: W("maska-gora", 0.4, 1.0) }),
      L(90, 1400, 260, 1400, "$a", 5, { we: W("rysuj", 1.2, 0.5) }),
      T("autor", 90, 1440, { rozmiar: 36, font: "t", waga: 600, kolor: "$d", we: W("lewo", 1.3, 0.6) }),
    ] }));
  [["cy-na-zdjeciu", "Cytat na zdjęciu", "noc"], ["cy-na-zdjeciu-oliwka", "Cytat na zdjęciu, oliwka", "oliwka"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "cytaty", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie w tle"), tx("cytat", "Cytat", "Najlepszy moment na start jest teraz.", 2), tx("autor", "Podpis", "@twojprofil")],
    warstwy: [
      Zp("z1", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.8) }),
      P(0, 0, 1080, 1920, "#000000", { krycie: 0.45, we: W("zanik", 0.2, 0.6) }),
      T("cytat", 540, 760, { rozmiar: 96, font: "n", waga: 700, wyr: "srodek", szer: 900, interlinia: 1.1, kolor: "#FFFFFF", we: W("maska-gora", 0.5, 1.0) }),
      L(470, 1150, 610, 1150, "$a", 5, { we: W("rysuj", 1.2, 0.5) }),
      T("autor", 540, 1190, { rozmiar: 32, font: "t", waga: 600, wyr: "srodek", kolor: "#FFFFFF", we: W("zanik", 1.3, 0.6) }),
    ] }));
  [["cy-haslo-pasy", "Hasło na kolorowych pasach", "pomarancz"], ["cy-haslo-pasy-zolty", "Hasło na pasach, żółty", "zolty"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "cytaty", czas: 6, kolory: PAL[p],
    pola: [tx("w1", "Linia 1", "RÓB"), tx("w2", "Linia 2", "TO, CO"), tx("w3", "Linia 3", "KOCHASZ")],
    warstwy: [
      ...[0, 1, 2].flatMap((i) => [P(0, 560 + i * 280, 1080, 240, i === 1 ? "$a" : "$g", { we: W(i % 2 ? "odkryj-prawo" : "odkryj-lewo", 0.1 + i * 0.2, 0.6) }),
        T("w" + (i + 1), 540, 590 + i * 280, { rozmiar: 160, font: "n", waga: 700, wyr: "srodek", wielkie: true, kolor: i === 1 ? "$tl" : "$t", we: W("maska-gora", 0.4 + i * 0.2, 0.6) })]),
    ] }));

  // ---------- PROMOCJE I PRODUKTY ----------
  [["pr-premiera", "Premiera produktu", "noc"], ["pr-premiera-niebo", "Premiera produktu, niebieski", "niebo"], ["pr-premiera-roz", "Premiera produktu, róż", "roz"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "promocje", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie produktu"), tx("nad", "Nadtytuł", "PREMIERA"), tx("nazwa", "Nazwa produktu", "Krem nocny\nRegeneracja"), tx("opis", "Opis", "Z witaminą C i kwasem hialuronowym"), tx("cena", "Cena", "89 zł"), tx("przycisk", "Przycisk", "ZAMÓW")],
    warstwy: [
      P(90, 160, 900, 1000, "$g", { r: 40, we: W("skala", 0.05, 0.7) }),
      Zp("z1", 140, 210, 800, 900, { maska: "zaokr", r: 30, we: W("zanik", 0.3, 0.7) }),
      P(90, 120, 280, 80, "$a", { r: 40, we: W("pop", 0.6, 0.5, "sprezyna") }), T("nad", 230, 140, { rozmiar: 30, font: "t", waga: 800, wyr: "srodek", rozstaw: 200, kolor: "$tl", we: W("zanik", 0.7, 0.4) }),
      T("nazwa", 90, 1230, { rozmiar: 90, font: "n", waga: 700, interlinia: 1.0, szer: 900, we: W("maska-gora", 0.8, 0.8) }),
      T("opis", 90, 1460, { rozmiar: 32, font: "t", kolor: "$d", szer: 900, we: W("gora", 1.1, 0.6) }),
      T("cena", 90, 1570, { rozmiar: 110, font: "n", waga: 700, kolor: "$a", we: W("pop", 1.3, 0.6, "sprezyna") }),
      P(640, 1600, 350, 110, "$t", { r: 55, we: W("odkryj-lewo", 1.4, 0.5) }), T("przycisk", 815, 1634, { rozmiar: 36, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, kolor: "$tl", we: W("zanik", 1.6, 0.4) }),
    ] }));
  [["pr-wyprzedaz", "Wyprzedaż z wielkim napisem", "czerwien"], ["pr-wyprzedaz-zolty", "Wyprzedaż, żółty", "zolty"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "promocje", czas: 6, kolory: PAL[p],
    pola: [tx("w1", "Napis", "SALE"), tx("rabat", "Rabat", "do -70%"), tx("opis", "Kiedy", "tylko ten weekend"), tx("przycisk", "Przycisk", "SPRAWDŹ")],
    warstwy: [
      T("w1", 540, 420, { rozmiar: 400, font: "n", waga: 700, wyr: "srodek", wielkie: true, we: W("maska-gora", 0.05, 0.8) }),
      P(140, 980, 800, 200, "$a", { obrot: -4, we: W("pop", 0.5, 0.6, "sprezyna") }),
      T("rabat", 540, 1010, { rozmiar: 130, font: "n", waga: 700, wyr: "srodek", kolor: "$tl", obrot: -4, we: W("zanik", 0.7, 0.4) }),
      T("opis", 540, 1290, { rozmiar: 44, font: "t", waga: 600, wyr: "srodek", we: W("gora", 0.9, 0.6) }),
      P(340, 1500, 400, 110, "$t", { obrys: 4, r: 55, we: W("rysuj", 1.1, 0.7) }), T("przycisk", 540, 1534, { rozmiar: 38, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, we: W("zanik", 1.3, 0.4) }),
    ] }));
  [["pr-trzy-produkty", "Trzy produkty z cenami", "biel"], ["pr-trzy-produkty-piasek", "Trzy produkty, piasek", "piasek"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "promocje", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Produkt 1"), zd("z2", "Produkt 2"), zd("z3", "Produkt 3"), tx("tytul", "Tytuł", "Nowości tygodnia"), tx("c1", "Cena 1", "49 zł"), tx("c2", "Cena 2", "79 zł"), tx("c3", "Cena 3", "129 zł")],
    warstwy: [
      T("tytul", 90, 150, { rozmiar: 84, font: "n", waga: 700, szer: 900, we: W("maska-gora", 0.05, 0.7) }),
      ...[0, 1, 2].flatMap((i) => [P(90, 360 + i * 500, 900, 440, "$g", { r: 30, we: W("odkryj-lewo", 0.3 + i * 0.2, 0.7) }),
        Zp("z" + (i + 1), 120, 390 + i * 500, 380, 380, { maska: "zaokr", r: 20, we: W("skala", 0.5 + i * 0.2, 0.6) }),
        T("c" + (i + 1), 940, 520 + i * 500, { rozmiar: 90, font: "n", waga: 700, wyr: "prawo", kolor: "$a", we: W("pop", 0.7 + i * 0.2, 0.6, "sprezyna") })]),
    ] }));

  // ---------- WYDARZENIA ----------
  [["wy-bilet", "Bilet na wydarzenie", "granat"], ["wy-bilet-limonka", "Bilet na wydarzenie, limonka", "limonka"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "wydarzenia", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Nazwa", "NOC\nKONCERTÓW"), tx("data", "Data", "14.11.2026"), tx("godz", "Godzina", "20:00"), tx("miejsce", "Miejsce", "Klub Stodoła, Warszawa"), tx("przycisk", "Przycisk", "KUP BILET")],
    warstwy: [
      Zp("z1", 0, 0, 1080, 900, { we: W("odkryj-gora", 0, 0.8) }),
      P(80, 820, 920, 900, "$g", { r: 30, we: W("gora", 0.4, 0.7) }),
      T("tytul", 140, 880, { rozmiar: 110, font: "n", waga: 700, interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.7, 0.8) }),
      L(140, 1170, 940, 1170, "$d", 3, { we: W("rysuj", 0.9, 0.6) }),
      T("data", 140, 1210, { rozmiar: 64, font: "n", waga: 700, kolor: "$a", we: W("lewo", 1.0, 0.6) }),
      T("godz", 940, 1210, { rozmiar: 64, font: "n", waga: 700, wyr: "prawo", we: W("prawo", 1.1, 0.6) }),
      T("miejsce", 140, 1320, { rozmiar: 34, font: "t", kolor: "$d", szer: 800, we: W("gora", 1.2, 0.6) }),
      P(140, 1500, 800, 120, "$a", { r: 60, we: W("odkryj-lewo", 1.4, 0.6) }), T("przycisk", 540, 1538, { rozmiar: 40, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, kolor: "$tl", we: W("zanik", 1.6, 0.4) }),
    ] }));
  [["wy-odliczanie-dni", "Zostało X dni", "noc"], ["wy-odliczanie-dni-fiolet", "Zostało X dni, fiolet", "fiolet"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "wydarzenia", czas: 6, kolory: PAL[p],
    pola: [tx("nad", "Nad liczbą", "ZOSTAŁO"), tx("liczba", "Liczba", "3"), tx("pod", "Pod liczbą", "DNI"), tx("opis", "Do czego", "do startu zapisów")],
    warstwy: [
      T("nad", 540, 420, { rozmiar: 60, font: "n", waga: 700, wyr: "srodek", rozstaw: 200, we: W("zanik", 0.1, 0.6) }),
      K(540, 900, 330, "$a", { obrys: 10, we: W("rysuj", 0.2, 1.0) }),
      T("liczba", 540, 700, { rozmiar: 400, font: "n", waga: 700, wyr: "srodek", we: W("pop", 0.6, 0.7, "sprezyna") }),
      T("pod", 540, 1290, { rozmiar: 80, font: "n", waga: 700, wyr: "srodek", rozstaw: 200, kolor: "$a", we: W("gora", 0.9, 0.6) }),
      T("opis", 540, 1420, { rozmiar: 36, font: "t", wyr: "srodek", kolor: "$d", we: W("zanik", 1.2, 0.6) }),
    ] }));
  [["wy-agenda", "Plan dnia wydarzenia", "biel"], ["wy-agenda-granat", "Plan dnia, granat", "granat"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "wydarzenia", czas: 8, kolory: PAL[p],
    pola: [tx("tytul", "Tytuł", "Plan dnia"), tx("g1", "Godzina 1", "10:00"), tx("p1", "Punkt 1", "Otwarcie i kawa"), tx("g2", "Godzina 2", "11:30"), tx("p2", "Punkt 2", "Warsztaty z montażu"), tx("g3", "Godzina 3", "14:00"), tx("p3", "Punkt 3", "Panel dyskusyjny"), tx("g4", "Godzina 4", "17:00"), tx("p4", "Punkt 4", "After party")],
    warstwy: [
      T("tytul", 90, 200, { rozmiar: 110, font: "n", waga: 700, we: W("maska-gora", 0.05, 0.7) }),
      L(180, 480, 180, 1640, "$d", 3, { we: W("rysuj", 0.3, 1.2) }),
      ...[0, 1, 2, 3].flatMap((i) => [K(180, 520 + i * 360, 22, "$a", { we: W("pop", 0.5 + i * 0.25, 0.5, "sprezyna") }),
        T("g" + (i + 1), 240, 480 + i * 360, { rozmiar: 54, font: "n", waga: 700, kolor: "$a", we: W("lewo", 0.55 + i * 0.25, 0.5) }),
        T("p" + (i + 1), 240, 560 + i * 360, { rozmiar: 40, font: "t", waga: 600, szer: 760, we: W("lewo", 0.65 + i * 0.25, 0.5) })]),
    ] }));

  // ---------- PODRÓŻE I LIFESTYLE ----------
  [["li-pocztowka-ramka", "Pocztówka w ramce", "piasek"], ["li-pocztowka-niebo", "Pocztówka, niebieski", "niebo"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "lifestyle", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie"), tx("nad", "Pozdrowienia z", "POZDROWIENIA Z"), tx("miejsce", "Miejsce", "Lizbony"), tx("opis", "Opis", "5 dni, 40 km pieszo i milion pasteis de nata.", 2)],
    warstwy: [
      P(80, 200, 920, 1200, "$g", { obrot: 2, we: W("pop", 0.05, 0.8, "sprezyna") }),
      Zp("z1", 120, 240, 840, 960, { obrot: 2, we: W("zanik", 0.4, 0.7) }),
      T("nad", 540, 1240, { rozmiar: 28, font: "t", waga: 700, rozstaw: 300, wyr: "srodek", kolor: "$d", obrot: 2, we: W("zanik", 0.9, 0.5) }),
      T("miejsce", 540, 1440, { rozmiar: 150, font: "n", waga: 700, wyr: "srodek", kolor: "$a", obrot: -3, we: W("pop", 1.0, 0.7, "sprezyna") }),
      T("opis", 540, 1680, { rozmiar: 32, font: "t", wyr: "srodek", szer: 860, we: W("gora", 1.3, 0.6) }),
    ] }));
  [["li-mapa-trasa", "Trasa podróży", "oliwka"], ["li-mapa-trasa-noc", "Trasa podróży, ciemna", "noc"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "lifestyle", czas: 8, kolory: PAL[p],
    pola: [tx("tytul", "Tytuł", "Nasza trasa"), tx("m1", "Miejsce 1", "Kraków"), tx("m2", "Miejsce 2", "Wiedeń"), tx("m3", "Miejsce 3", "Wenecja"), tx("m4", "Miejsce 4", "Rzym"), tx("opis", "Opis", "2400 km w 10 dni")],
    warstwy: [
      T("tytul", 90, 180, { rozmiar: 110, font: "n", waga: 700, we: W("maska-gora", 0.05, 0.7) }),
      L(200, 560, 820, 860, "$a", 6, { we: W("rysuj", 0.4, 0.6) }), L(820, 860, 300, 1180, "$a", 6, { we: W("rysuj", 0.9, 0.6) }), L(300, 1180, 780, 1500, "$a", 6, { we: W("rysuj", 1.4, 0.6) }),
      ...[[200, 560], [820, 860], [300, 1180], [780, 1500]].flatMap(([x, y], i) => [K(x, y, 30, "$t", { we: W("pop", 0.3 + i * 0.5, 0.5, "sprezyna") }),
        T("m" + (i + 1), x + (i % 2 ? -60 : 60), y - 30, { rozmiar: 50, font: "t", waga: 700, wyr: i % 2 ? "prawo" : "lewo", we: W("zanik", 0.4 + i * 0.5, 0.5) })]),
      T("opis", 540, 1700, { rozmiar: 36, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 2.0, 0.6) }),
    ] }));
  [["li-dzien", "Mój dzień w trzech kadrach", "roz"], ["li-dzien-mieta", "Mój dzień, mięta", "mieta"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "lifestyle", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Rano"), zd("z2", "Południe"), zd("z3", "Wieczór"), tx("tytul", "Tytuł", "Mój dzień"), tx("e1", "Podpis 1", "rano"), tx("e2", "Podpis 2", "w pracy"), tx("e3", "Podpis 3", "wieczorem")],
    warstwy: [
      T("tytul", 540, 130, { rozmiar: 100, font: "n", waga: 700, wyr: "srodek", we: W("maska-gora", 0.05, 0.7) }),
      ...[0, 1, 2].flatMap((i) => [Zp("z" + (i + 1), 140 + (i % 2) * 300, 320 + i * 520, 500, 440, { maska: "zaokr", r: 30, we: W(i % 2 ? "prawo" : "lewo", 0.3 + i * 0.25, 0.7) }),
        T("e" + (i + 1), i % 2 ? 380 : 700, 540 + i * 520, { rozmiar: 46, font: "t", waga: 700, wyr: i % 2 ? "prawo" : "lewo", kolor: "$a", we: W("zanik", 0.6 + i * 0.25, 0.5) })]),
    ] }));

  // ---------- ZAPOWIEDZI I ZAKOŃCZENIA ----------
  [["za-dzieki-logo", "Dzięki z logo", "noc"], ["za-dzieki-logo-pomarancz", "Dzięki z logo, pomarańcz", "pomarancz"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "zakonczenia", czas: 5, kolory: PAL[p],
    pola: [lg("logo", "Logo"), tx("tytul", "Tytuł", "Dzięki,\nże jesteś!"), tx("opis", "Opis", "Zostaw komentarz i obserwuj po więcej")],
    warstwy: [
      Z("logo", 390, 300, 300, 300, { dopasuj: "zawrzyj", we: W("pop", 0.1, 0.7, "sprezyna") }),
      T("tytul", 540, 780, { rozmiar: 140, font: "n", waga: 700, wyr: "srodek", interlinia: 0.98, we: W("maska-gora", 0.4, 0.8) }),
      T("opis", 540, 1140, { rozmiar: 38, font: "t", wyr: "srodek", szer: 860, kolor: "$d", we: W("gora", 0.9, 0.6) }),
    ] }));
  [["za-zapowiedz", "Zapowiedź: już wkrótce", "fiolet"], ["za-zapowiedz-granat", "Zapowiedź, granat", "granat"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "zakonczenia", czas: 6, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie (rozmyte w tle)"), tx("nad", "Nadtytuł", "JUŻ WKRÓTCE"), tx("tytul", "Tytuł", "Coś\nwielkiego"), tx("data", "Data", "01.12")],
    warstwy: [
      Zp("z1", 0, 0, 1080, 1920, { we: W("zanik", 0, 1.0) }),
      P(0, 0, 1080, 1920, "$tl", { krycie: 0.7, we: W("zanik", 0.2, 0.6) }),
      T("nad", 540, 600, { rozmiar: 40, font: "t", waga: 700, rozstaw: 400, wyr: "srodek", kolor: "$a", we: W("zanik", 0.5, 0.7) }),
      T("tytul", 540, 700, { rozmiar: 200, font: "n", waga: 700, wyr: "srodek", interlinia: 0.92, wielkie: true, we: W("maska-gora", 0.8, 0.9) }),
      P(390, 1200, 300, 110, "$a", { r: 55, we: W("pop", 1.3, 0.6, "sprezyna") }), T("data", 540, 1222, { rozmiar: 60, font: "n", waga: 700, wyr: "srodek", kolor: "$tl", we: W("zanik", 1.5, 0.4) }),
    ] }));
  [["za-link", "Link w bio", "limonka"], ["za-link-biel", "Link w bio, białe", "biel"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "zakonczenia", czas: 5, kolory: PAL[p],
    pola: [tx("tytul", "Tytuł", "Całość\nna YouTube"), tx("przycisk", "Przycisk", "LINK W BIO"), tx("opis", "Opis", "pełny odcinek: 42 minuty")],
    warstwy: [
      T("tytul", 540, 560, { rozmiar: 150, font: "n", waga: 700, wyr: "srodek", interlinia: 0.95, we: W("maska-gora", 0.1, 0.8) }),
      TR(540, 1020, 50, "$a", { obrot: 0, we: W("gora", 0.6, 0.5) }),
      P(240, 1100, 600, 140, "$a", { r: 70, we: W("pop", 0.7, 0.6, "sprezyna") }),
      T("przycisk", 540, 1143, { rozmiar: 50, font: "t", waga: 800, wyr: "srodek", rozstaw: 120, kolor: "$tl", we: W("zanik", 0.9, 0.4) }),
      T("opis", 540, 1330, { rozmiar: 34, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.1, 0.6) }),
    ] }));

  // ---------- PORADY I LISTY (nowa kategoria) ----------
  [["po-lista-5", "5 porad w punktach", "noc"], ["po-lista-5-mieta", "5 porad, mięta", "mieta"], ["po-lista-5-zolty", "5 porad, żółty", "zolty"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "porady", czas: 9, kolory: PAL[p],
    pola: [tx("tytul", "Tytuł", "5 sposobów\nna lepsze rolki"), ...[1, 2, 3, 4, 5].map((i) => tx("p" + i, "Punkt " + i, ["Pierwsze 2 sekundy to hak", "Napisy na środku kadru", "Cięcie co 2–3 sekundy", "Muzyka pod emocję", "Jasne wezwanie na końcu"][i - 1]))],
    warstwy: [
      T("tytul", 90, 200, { rozmiar: 96, font: "n", waga: 700, interlinia: 1.0, szer: 900, we: W("maska-gora", 0.05, 0.8) }),
      ...[0, 1, 2, 3, 4].flatMap((i) => [K(140, 680 + i * 230, 46, "$a", { we: W("pop", 0.6 + i * 0.25, 0.5, "sprezyna") }),
        TL(String(i + 1), 140, 650 + i * 230, { rozmiar: 54, font: "n", waga: 700, wyr: "srodek", kolor: "$tl", we: W("zanik", 0.7 + i * 0.25, 0.4) }),
        T("p" + (i + 1), 220, 655 + i * 230, { rozmiar: 44, font: "t", waga: 600, szer: 780, we: W("lewo", 0.65 + i * 0.25, 0.5) })]),
    ] }));
  [["po-tak-nie", "Tak / nie: dobre i złe praktyki", "biel"], ["po-tak-nie-noc", "Tak / nie, ciemne", "noc"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "porady", czas: 8, kolory: PAL[p],
    pola: [tx("tytul", "Tytuł", "Rób tak, nie tak"), tx("tak", "Dobrze", "Krótki hak w pierwszej sekundzie", 2), tx("nie", "Źle", "Długi wstęp i przedstawianie się", 2)],
    warstwy: [
      T("tytul", 540, 220, { rozmiar: 96, font: "n", waga: 700, wyr: "srodek", we: W("maska-gora", 0.05, 0.7) }),
      P(90, 480, 900, 560, "#22C55E", { r: 30, krycie: 0.18, we: W("odkryj-lewo", 0.3, 0.7) }), K(200, 600, 60, "#22C55E", { we: W("pop", 0.6, 0.5, "sprezyna") }), TL("TAK", 200, 582, { rozmiar: 34, font: "t", waga: 800, wyr: "srodek", kolor: "#FFFFFF", we: W("zanik", 0.7, 0.4) }),
      T("tak", 300, 560, { rozmiar: 50, font: "t", waga: 700, szer: 640, we: W("lewo", 0.7, 0.6) }),
      P(90, 1120, 900, 560, "#EF4444", { r: 30, krycie: 0.18, we: W("odkryj-lewo", 1.0, 0.7) }), K(200, 1240, 60, "#EF4444", { we: W("pop", 1.3, 0.5, "sprezyna") }), TL("NIE", 200, 1222, { rozmiar: 34, font: "t", waga: 800, wyr: "srodek", kolor: "#FFFFFF", we: W("zanik", 1.4, 0.4) }),
      T("nie", 300, 1200, { rozmiar: 50, font: "t", waga: 700, szer: 640, we: W("lewo", 1.4, 0.6) }),
    ] }));
  [["po-krok", "Krok po kroku ze zdjęciem", "piasek"], ["po-krok-granat", "Krok po kroku, granat", "granat"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "porady", czas: 7, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie"), tx("nr", "Numer kroku", "KROK 1"), tx("tytul", "Tytuł", "Ustaw światło z boku"), tx("opis", "Opis", "Okno albo lampa pod kątem 45° da miękki, filmowy cień.", 2)],
    warstwy: [
      Zp("z1", 0, 0, 1080, 1100, { we: W("odkryj-gora", 0, 0.8) }),
      P(90, 1040, 300, 100, "$a", { r: 50, we: W("pop", 0.5, 0.5, "sprezyna") }), T("nr", 240, 1064, { rozmiar: 40, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, kolor: "$tl", we: W("zanik", 0.6, 0.4) }),
      T("tytul", 90, 1200, { rozmiar: 90, font: "n", waga: 700, szer: 900, interlinia: 1.0, we: W("maska-gora", 0.7, 0.8) }),
      T("opis", 90, 1480, { rozmiar: 36, font: "t", szer: 900, kolor: "$d", interlinia: 1.4, we: W("gora", 1.1, 0.6) }),
    ] }));
  [["po-mit-fakt", "Mit i fakt", "fiolet"], ["po-mit-fakt-biel", "Mit i fakt, białe", "biel"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "porady", czas: 8, kolory: PAL[p],
    pola: [tx("mit", "Mit", "Do rolek potrzebujesz drogiego sprzętu", 2), tx("fakt", "Fakt", "Telefon i dobre światło wystarczą na start", 2)],
    warstwy: [
      P(90, 300, 300, 110, "#EF4444", { r: 20, we: W("pop", 0.1, 0.5, "sprezyna") }), TL("MIT", 240, 322, { rozmiar: 60, font: "n", waga: 700, wyr: "srodek", kolor: "#FFFFFF", we: W("zanik", 0.2, 0.4) }),
      T("mit", 90, 460, { rozmiar: 70, font: "n", waga: 700, szer: 900, interlinia: 1.05, we: W("maska-gora", 0.3, 0.8) }),
      L(90, 920, 990, 920, "$d", 3, { we: W("rysuj", 0.9, 0.6) }),
      P(90, 1000, 340, 110, "#22C55E", { r: 20, we: W("pop", 1.2, 0.5, "sprezyna") }), TL("FAKT", 260, 1022, { rozmiar: 60, font: "n", waga: 700, wyr: "srodek", kolor: "#FFFFFF", we: W("zanik", 1.3, 0.4) }),
      T("fakt", 90, 1160, { rozmiar: 70, font: "n", waga: 700, szer: 900, interlinia: 1.05, kolor: "$a", we: W("maska-gora", 1.4, 0.8) }),
    ] }));

  // ---------- OPINIE I REKOMENDACJE (nowa kategoria) ----------
  [["op-opinia", "Opinia klienta z gwiazdkami", "biel"], ["op-opinia-noc", "Opinia klienta, ciemna", "noc"], ["op-opinia-roz", "Opinia klienta, róż", "roz"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "opinie", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie klienta"), tx("opinia", "Opinia (wpisz prawdziwą)", "Wpisz tu opinię klienta, którą dostałeś (np. z Google).", 3), tx("autor", "Imię i nazwisko", "Imię Nazwisko"), tx("rola", "Kim jest", "klientka od 2024")],
    warstwy: [
      ...[0, 1, 2, 3, 4].map((i) => K(300 + i * 120, 340, 34, "#F5B301", { we: W("pop", 0.1 + i * 0.1, 0.4, "sprezyna") })),
      T("opinia", 540, 460, { rozmiar: 62, font: "n", waga: 600, wyr: "srodek", szer: 900, interlinia: 1.25, we: W("maska-gora", 0.6, 1.0) }),
      Zp("z1", 440, 1120, 200, 200, { maska: "kolo", we: W("skala", 1.2, 0.6) }),
      T("autor", 540, 1360, { rozmiar: 44, font: "t", waga: 700, wyr: "srodek", we: W("gora", 1.4, 0.5) }),
      T("rola", 540, 1430, { rozmiar: 30, font: "t", wyr: "srodek", kolor: "$d", we: W("zanik", 1.5, 0.5) }),
    ] }));
  [["op-polecam", "Polecam: produkt z opisem", "piasek"], ["op-polecam-limonka", "Polecam, limonka", "limonka"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "opinie", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie produktu"), tx("nad", "Nadtytuł", "MÓJ HIT MIESIĄCA"), tx("nazwa", "Nazwa", "Kamera X200"), tx("plus", "Zalety", "lekka · świetna stabilizacja · 4K 60 kl./s", 2)],
    warstwy: [
      T("nad", 90, 160, { rozmiar: 30, font: "t", waga: 800, rozstaw: 250, kolor: "$a", we: W("lewo", 0.05, 0.6) }),
      Zp("z1", 90, 240, 900, 1000, { maska: "zaokr", r: 40, we: W("odkryj-gora", 0.2, 0.9) }),
      T("nazwa", 90, 1320, { rozmiar: 110, font: "n", waga: 700, szer: 900, we: W("maska-gora", 0.8, 0.8) }),
      T("plus", 90, 1500, { rozmiar: 38, font: "t", szer: 900, kolor: "$d", interlinia: 1.4, we: W("gora", 1.1, 0.6) }),
      K(920, 1200, 70, "$a", { we: W("pop", 1.3, 0.6, "sprezyna") }), TL("10/10", 920, 1180, { rozmiar: 36, font: "t", waga: 800, wyr: "srodek", kolor: "$tl", we: W("zanik", 1.4, 0.4) }),
    ] }));
  [["op-przed-po", "Przed i po", "noc"], ["op-przed-po-biel", "Przed i po, białe", "biel"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "opinie", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Przed"), zd("z2", "Po"), tx("e1", "Podpis 1", "PRZED"), tx("e2", "Podpis 2", "PO"), tx("opis", "Opis", "3 miesiące współpracy")],
    warstwy: [
      Zp("z1", 0, 0, 1080, 900, { bw: true, we: W("odkryj-lewo", 0.05, 0.8) }),
      Zp("z2", 0, 920, 1080, 900, { we: W("odkryj-prawo", 0.5, 0.8) }),
      P(60, 60, 240, 90, "$tl", { r: 45, we: W("pop", 0.6, 0.5, "sprezyna") }), T("e1", 180, 78, { rozmiar: 40, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, we: W("zanik", 0.7, 0.4) }),
      P(60, 980, 200, 90, "$a", { r: 45, we: W("pop", 1.0, 0.5, "sprezyna") }), T("e2", 160, 998, { rozmiar: 40, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, kolor: "$tl", we: W("zanik", 1.1, 0.4) }),
      P(0, 1820, 1080, 100, "$tl", { we: W("odkryj-gora", 1.2, 0.5) }), T("opis", 540, 1846, { rozmiar: 36, font: "t", waga: 600, wyr: "srodek", we: W("zanik", 1.3, 0.5) }),
    ] }));

  // >>> wersja 18 (szablony na Twój film)
  // =====================================================================
  // ---------- wersja 18: szablony na Twój film + nowe w każdej kategorii ----------
  // Pole „film” to zwykłe pole zdjęcia: w panelu Premiere można w nie wstawić zaznaczony klip z osi (render go odtwarza).
  // =====================================================================
  KATEGORIE.unshift({ id: "film", nazwa: "Na Twój film" });
  const PAL2 = Object.assign({}, PAL, {
    krem: { tl: "#F3EEE6", t: "#1D1B18", a: "#D9572B", g: "#FFFFFF", d: "#857C70" },
    morski: { tl: "#0E2A2F", t: "#F2F7F5", a: "#3DD6B5", g: "#17404A", d: "#93B3B0" },
    wino: { tl: "#2A0F17", t: "#FBEFEF", a: "#F2A65A", g: "#43202B", d: "#C49AA2" },
    neon: { tl: "#0B0B1A", t: "#FFFFFF", a: "#FF2D95", g: "#1B1B33", d: "#9A9AC0" },
    kobalt: { tl: "#2340F5", t: "#FFFFFF", a: "#FFE14D", g: "#3A55FF", d: "#C9D2FF" },
    newsCz: { tl: "#0B0B0B", t: "#FFFFFF", a: "#E11D2E", g: "#FFFFFF", d: "#BBBBBB" },
    newsNb: { tl: "#071A3A", t: "#FFFFFF", a: "#1E6BFF", g: "#FFFFFF", d: "#AFC3E8" },
  });
  // warianty kolorystyczne jednego układu: [[id, nazwa, paleta], ...], f(kolory) zwraca resztę szablonu
  const V = (lista, f) => lista.forEach(([id, nazwa, p]) => S(Object.assign({ id, nazwa }, f(PAL2[p]), { kolory: PAL2[p] })));
  const zf = (id = "film", etykieta = "Twój film albo zdjęcie") => zd(id, etykieta);
  const ZF = (pole, x, y, w, h, o = {}) => Z(pole, x, y, w, h, Object.assign({ ruch: [1.06, 1] }, o)); // film: delikatny ruch
  const BIA = "#FFFFFF", CZA = "#000000";

  // ======================= NA TWÓJ FILM =======================
  V([["fi-pelny-tytul", "Film na cały ekran, tytuł na dole", "noc"], ["fi-pelny-tytul-limonka", "Film na cały ekran, tytuł z limonką", "limonka"]], () => ({ kat: "film", czas: 7,
    pola: [zf(), tx("nad", "Nadtytuł", "NOWY ODCINEK"), tx("tytul", "Tytuł", "TO ZMIENIŁO\nWSZYSTKO"), tx("opis", "Opis", "Zobacz do końca, bo najlepsze jest na samym końcu.", 2)],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.6) }),
      C(0, 950, 1080, 970, CZA, 0, 0.88),
      P(90, 1302, 70, 8, "$a", { we: W("odkryj-lewo", 0.5, 0.5) }),
      T("nad", 180, 1294, { rozmiar: 28, font: "t", waga: 700, rozstaw: 250, kolor: "$a", we: W("lewo", 0.6, 0.6) }),
      T("tytul", 90, 1350, { rozmiar: 150, font: "n", waga: 700, interlinia: 0.95, wielkie: true, kolor: BIA, we: W("maska-gora", 0.7, 0.8) }),
      T("opis", 90, 1680, { rozmiar: 34, font: "t", szer: 860, interlinia: 1.4, kolor: BIA, we: W("gora", 1.1, 0.6) }),
    ] }));
  V([["fi-tytul-gora", "Film na cały ekran, tytuł u góry", "noc"]], () => ({ kat: "film", czas: 7,
    pola: [zf(), tx("nad", "Nadtytuł", "PORADNIK"), tx("tytul", "Tytuł", "3 TRIKI\nDO MONTAŻU"), tx("nick", "Nick", "@twojprofil")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.6) }),
      C(0, 0, 1080, 820, CZA, 0.8, 0),
      T("nad", 90, 150, { rozmiar: 28, font: "t", waga: 700, rozstaw: 300, kolor: "$a", we: W("zanik", 0.3, 0.6) }),
      T("tytul", 90, 205, { rozmiar: 130, font: "n", waga: 700, interlinia: 1.02, wielkie: true, kolor: BIA, we: W("maska-gora", 0.4, 0.8) }),
      P(90, 1720, 380, 84, "$a", { r: 42, we: W("odkryj-lewo", 1.0, 0.6) }),
      T("nick", 280, 1745, { rozmiar: 32, font: "t", waga: 700, wyr: "srodek", maks: 340, kolor: "$tl", we: W("zanik", 1.2, 0.4) }),
    ] }));
  V([["fi-okno-belki", "Film w oknie z belkami marki", "noc"], ["fi-okno-belki-biel", "Film w oknie z belkami, białe", "biel"]], () => ({ kat: "film", czas: 8,
    pola: [zf(), tx("marka", "Nazwa marki", "TWOJA MARKA"), tx("tytul", "Tytuł", "Jak nagrywać\ntelefonem"), tx("opis", "Opis", "Krótki poradnik w 60 sekund"), tx("stopka", "Stopka", "TWOJASTRONA.PL")],
    warstwy: [
      P(0, 0, 1080, 200, "$g", { we: W("odkryj-dol", 0, 0.5) }),
      T("marka", 90, 76, { rozmiar: 48, font: "n", waga: 700, wielkie: true, rozstaw: 80, maks: 800, we: W("lewo", 0.3, 0.6) }),
      K(980, 102, 16, "$a", { we: W("pop", 0.5, 0.5, "sprezyna") }),
      ZF("film", 60, 250, 960, 1200, { maska: "zaokr", r: 40, we: W("skala", 0.2, 0.8) }),
      T("tytul", 90, 1500, { rozmiar: 86, font: "n", waga: 700, interlinia: 1.0, szer: 900, we: W("maska-gora", 0.8, 0.8) }),
      T("opis", 90, 1690, { rozmiar: 32, font: "t", kolor: "$d", szer: 900, we: W("gora", 1.1, 0.6) }),
      P(0, 1800, 1080, 120, "$a", { we: W("odkryj-gora", 1.2, 0.5) }),
      T("stopka", 540, 1846, { rozmiar: 28, font: "t", waga: 700, wyr: "srodek", rozstaw: 200, kolor: "$tl", we: W("zanik", 1.4, 0.5) }),
    ] }));
  V([["fi-poziomy", "Film poziomy w pionowym kadrze", "noc"]], () => ({ kat: "film", czas: 8,
    pola: [zf("film", "Twój film albo zdjęcie (poziome)"), tx("nad", "Nadtytuł", "Z PLANU"), tx("tytul", "Tytuł", "ZŁOTA\nGODZINA"), tx("opis", "Opis", "Kilka sekund z naszego ostatniego wyjazdu na plan zdjęciowy.", 2), tx("stopka", "Stopka", "TWOJASTRONA.PL")],
    warstwy: [
      T("nad", 540, 400, { rozmiar: 28, font: "t", waga: 700, rozstaw: 300, wyr: "srodek", kolor: "$a", we: W("zanik", 0.1, 0.6) }),
      T("tytul", 540, 450, { rozmiar: 110, font: "n", waga: 700, wyr: "srodek", interlinia: 1.05, wielkie: true, we: W("maska-gora", 0.2, 0.8) }),
      ZF("film", 0, 780, 1080, 608, { we: W("odkryj-lewo", 0.4, 0.9) }),
      L(490, 1460, 590, 1460, "$a", 4, { we: W("rysuj", 1.0, 0.5) }),
      T("opis", 540, 1500, { rozmiar: 34, font: "t", wyr: "srodek", szer: 820, interlinia: 1.4, kolor: "$d", we: W("gora", 1.1, 0.6) }),
      T("stopka", 540, 1780, { rozmiar: 24, font: "t", waga: 700, rozstaw: 300, wyr: "srodek", kolor: "$d", we: W("zanik", 1.4, 0.6) }),
    ] }));
  V([["fi-poziomy-tlo", "Film poziomy na własnym tle", "noc"], ["fi-poziomy-tlo-fiolet", "Film poziomy na własnym tle, fiolet", "fiolet"]], () => ({ kat: "film", czas: 8,
    pola: [zf("film", "Twój film albo zdjęcie (poziome)"), tx("tytul", "Tytuł", "KULISY\nNAGRANIA"), tx("opis", "Opis", "Tak powstawał nasz najnowszy spot"), tx("nick", "Nick", "@twojprofil")],
    warstwy: [
      Z("film", 0, 0, 1080, 1920, { ruch: [1.3, 1.2], we: W("zanik", 0, 0.8) }),
      P(0, 0, 1080, 1920, "$tl", { krycie: 0.72 }),
      T("tytul", 540, 260, { rozmiar: 140, font: "n", waga: 700, wyr: "srodek", interlinia: 0.92, wielkie: true, we: W("maska-gora", 0.3, 0.8) }),
      P(54, 650, 972, 556, "$a", { obrys: 6, we: W("rysuj", 0.5, 0.9) }),
      ZF("film", 70, 666, 940, 524, { we: W("skala", 0.6, 0.8) }),
      T("opis", 540, 1290, { rozmiar: 38, font: "t", waga: 600, wyr: "srodek", szer: 900, we: W("gora", 1.0, 0.6) }),
      T("nick", 540, 1700, { rozmiar: 30, font: "t", waga: 700, wyr: "srodek", rozstaw: 100, kolor: "$a", we: W("zanik", 1.3, 0.6) }),
    ] }));
  V([["fi-karta", "Film w karcie, nagłówek i podpis", "biel"], ["fi-karta-mieta", "Film w karcie, mięta", "mieta"]], () => ({ kat: "film", czas: 8,
    pola: [zf(), tx("tytul", "Nagłówek", "Najlepszy\nmoment dnia"), tx("tag", "Etykieta na filmie", "NOWOŚĆ"), tx("opis", "Podpis pod filmem", "Krótki podpis pod filmem, który dopowiada, co widać.", 2), tx("stopka", "Stopka", "@twojprofil")],
    warstwy: [
      T("tytul", 90, 150, { rozmiar: 100, font: "n", waga: 700, interlinia: 1.0, szer: 900, we: W("maska-gora", 0.05, 0.8) }),
      P(70, 440, 940, 1140, "$g", { r: 56, we: W("gora", 0.3, 0.7) }),
      ZF("film", 90, 460, 900, 1100, { maska: "zaokr", r: 40, we: W("zanik", 0.5, 0.7) }),
      P(120, 490, 230, 64, "$a", { r: 32, we: W("pop", 0.9, 0.5, "sprezyna") }),
      T("tag", 235, 509, { rozmiar: 26, font: "t", waga: 800, wyr: "srodek", rozstaw: 100, maks: 200, kolor: "$tl", we: W("zanik", 1.0, 0.4) }),
      T("opis", 90, 1630, { rozmiar: 36, font: "t", waga: 500, szer: 900, interlinia: 1.35, we: W("gora", 1.1, 0.6) }),
      T("stopka", 90, 1800, { rozmiar: 26, font: "t", waga: 700, rozstaw: 150, kolor: "$d", we: W("zanik", 1.3, 0.6) }),
    ] }));
  V([["fi-telefon", "Film w ramce telefonu", "zolty"], ["fi-telefon-noc", "Film w ramce telefonu, ciemne", "noc"]], () => ({ kat: "film", czas: 8,
    pola: [zf("film", "Twój film albo zdjęcie (ekran telefonu)"), tx("tytul", "Tytuł", "ZOBACZ, JAK\nTO DZIAŁA"), tx("opis", "Opis", "Pobierz aplikację za darmo"), tx("przycisk", "Przycisk", "POBIERZ")],
    warstwy: [
      T("tytul", 540, 110, { rozmiar: 96, font: "n", waga: 700, wyr: "srodek", interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.05, 0.8) }),
      P(250, 330, 580, 1180, "#161616", { r: 80, we: W("gora", 0.3, 0.8) }),
      P(250, 330, 580, 1180, "$d", { r: 80, obrys: 4, krycie: 0.6, we: W("gora", 0.3, 0.8) }),
      ZF("film", 272, 352, 536, 1136, { maska: "zaokr", r: 62, we: W("zanik", 0.7, 0.6) }),
      P(480, 372, 120, 34, "#161616", { r: 17, we: W("zanik", 0.8, 0.4) }),
      T("opis", 540, 1565, { rozmiar: 36, font: "t", waga: 600, wyr: "srodek", we: W("gora", 1.0, 0.6) }),
      P(330, 1650, 420, 110, "$a", { r: 55, we: W("pop", 1.2, 0.6, "sprezyna") }),
      T("przycisk", 540, 1686, { rozmiar: 38, font: "t", waga: 800, wyr: "srodek", rozstaw: 120, maks: 360, kolor: "$tl", we: W("zanik", 1.4, 0.4) }),
    ] }));
  V([["fi-dwa-gora-dol", "Dwa filmy: góra i dół", "noc"]], () => ({ kat: "film", czas: 8,
    pola: [zf("film", "Górny film albo zdjęcie"), zf("film2", "Dolny film albo zdjęcie"), tx("e1", "Podpis górny", "WERSJA A"), tx("e2", "Podpis dolny", "WERSJA B"), tx("tytul", "Pytanie w środku", "KTÓRA LEPSZA?")],
    warstwy: [
      ZF("film", 0, 0, 1080, 900, { we: W("odkryj-dol", 0, 0.8) }),
      ZF("film2", 0, 1020, 1080, 900, { we: W("odkryj-gora", 0.2, 0.8) }),
      P(0, 900, 1080, 120, "$a", { we: W("odkryj-lewo", 0.5, 0.6) }),
      T("tytul", 540, 937, { rozmiar: 60, font: "n", waga: 700, wyr: "srodek", wielkie: true, kolor: "$tl", we: W("maska-gora", 0.8, 0.6) }),
      P(60, 790, 300, 76, "$tl", { r: 38, krycie: 0.85, we: W("lewo", 1.0, 0.5) }),
      T("e1", 210, 812, { rozmiar: 32, font: "t", waga: 800, wyr: "srodek", maks: 260, we: W("zanik", 1.1, 0.4) }),
      P(60, 1060, 300, 76, "$tl", { r: 38, krycie: 0.85, we: W("lewo", 1.2, 0.5) }),
      T("e2", 210, 1082, { rozmiar: 32, font: "t", waga: 800, wyr: "srodek", maks: 260, we: W("zanik", 1.3, 0.4) }),
    ] }));
  V([["fi-dwa-obok", "Dwa filmy obok siebie", "biel"], ["fi-dwa-obok-granat", "Dwa filmy obok siebie, granat", "granat"]], () => ({ kat: "film", czas: 8,
    pola: [zf("film", "Lewy film albo zdjęcie"), zf("film2", "Prawy film albo zdjęcie"), tx("tytul", "Tytuł", "JA vs ONA"), tx("e1", "Podpis lewy", "Ja"), tx("e2", "Podpis prawy", "Ona"), tx("opis", "Opis", "ten sam przepis, dwa różne efekty")],
    warstwy: [
      T("tytul", 540, 130, { rozmiar: 120, font: "n", waga: 700, wyr: "srodek", wielkie: true, we: W("maska-gora", 0.05, 0.7) }),
      ZF("film", 40, 340, 490, 1220, { maska: "zaokr", r: 30, we: W("gora", 0.3, 0.8) }),
      ZF("film2", 550, 340, 490, 1220, { maska: "zaokr", r: 30, we: W("gora", 0.45, 0.8) }),
      K(540, 950, 58, "$a", { we: W("pop", 0.9, 0.5, "sprezyna") }),
      TL("VS", 540, 925, { rozmiar: 50, font: "n", waga: 700, wyr: "srodek", kolor: "$tl", we: W("zanik", 1.0, 0.4) }),
      T("e1", 285, 1610, { rozmiar: 54, font: "n", waga: 700, wyr: "srodek", maks: 470, we: W("gora", 1.0, 0.5) }),
      T("e2", 795, 1610, { rozmiar: 54, font: "n", waga: 700, wyr: "srodek", maks: 470, we: W("gora", 1.1, 0.5) }),
      T("opis", 540, 1760, { rozmiar: 30, font: "t", wyr: "srodek", kolor: "$d", we: W("zanik", 1.3, 0.6) }),
    ] }));
  V([["fi-przed-po", "Przed i po: dwa filmy z suwakiem", "noc"]], () => ({ kat: "film", czas: 8,
    pola: [zf("film", "Film albo zdjęcie „przed”"), zf("film2", "Film albo zdjęcie „po”"), tx("e1", "Podpis 1", "PRZED"), tx("e2", "Podpis 2", "PO")],
    warstwy: [
      ZF("film", 0, 0, 1080, 950, { bw: true, we: W("odkryj-lewo", 0, 0.8) }),
      ZF("film2", 0, 970, 1080, 950, { we: W("odkryj-prawo", 0.4, 0.8) }),
      P(0, 948, 1080, 24, "$tl", { we: W("odkryj-lewo", 0.8, 0.5) }),
      K(540, 960, 74, "$a", { we: W("pop", 1.0, 0.5, "sprezyna") }),
      TR(540, 930, 20, "$tl", { obrot: 0, we: W("zanik", 1.2, 0.4) }), TR(540, 990, 20, "$tl", { obrot: 180, we: W("zanik", 1.2, 0.4) }),
      P(60, 70, 250, 84, CZA, { r: 42, krycie: 0.6, we: W("lewo", 0.5, 0.5) }),
      T("e1", 185, 95, { rozmiar: 36, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, maks: 210, kolor: BIA, we: W("zanik", 0.6, 0.4) }),
      P(60, 1776, 250, 84, "$a", { r: 42, we: W("lewo", 1.1, 0.5) }),
      T("e2", 185, 1801, { rozmiar: 36, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, maks: 210, kolor: "$tl", we: W("zanik", 1.2, 0.4) }),
    ] }));
  V([["fi-reakcja", "Reakcja: mały film na dużym", "noc"]], () => ({ kat: "film", czas: 8,
    pola: [zf("film", "Duży film albo zdjęcie (oglądany)"), zf("film2", "Mały film albo zdjęcie (Twoja reakcja)"), tx("nad", "Etykieta", "REAKCJA"), tx("tytul", "Tytuł", "PIERWSZY RAZ\nTO WIDZĘ")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.6) }),
      C(0, 1150, 1080, 770, CZA, 0, 0.85),
      P(620, 110, 400, 540, BIA, { r: 40, we: W("pop", 0.4, 0.7, "sprezyna") }),
      ZF("film2", 632, 122, 376, 516, { maska: "zaokr", r: 30, we: W("zanik", 0.6, 0.5) }),
      P(90, 1440, 260, 70, "$a", { r: 35, we: W("odkryj-lewo", 0.9, 0.5) }),
      T("nad", 220, 1461, { rozmiar: 30, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, maks: 230, kolor: "$tl", we: W("zanik", 1.0, 0.4) }),
      T("tytul", 90, 1540, { rozmiar: 110, font: "n", waga: 700, interlinia: 0.95, wielkie: true, kolor: BIA, we: W("maska-gora", 1.0, 0.8) }),
    ] }));
  V([["fi-reakcja-kolo", "Reakcja w kółku na filmie", "limonka"]], () => ({ kat: "film", czas: 8,
    pola: [zf("film", "Duży film albo zdjęcie"), zf("film2", "Film albo zdjęcie w kółku (Twoja twarz)"), tx("tytul", "Tytuł", "OGLĄDAM TO\nPIERWSZY RAZ"), tx("nick", "Nick", "@twojprofil")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.6) }),
      C(0, 0, 1080, 700, CZA, 0.75, 0),
      T("tytul", 90, 150, { rozmiar: 110, font: "n", waga: 700, interlinia: 0.95, wielkie: true, kolor: BIA, we: W("maska-gora", 0.3, 0.8) }),
      ZF("film2", 80, 1370, 440, 440, { maska: "kolo", we: W("pop", 0.6, 0.7, "sprezyna") }),
      K(300, 1590, 232, "$a", { obrys: 10, we: W("rysuj", 0.8, 0.8) }),
      P(560, 1648, 440, 90, "$a", { r: 45, we: W("odkryj-lewo", 1.1, 0.5) }),
      T("nick", 780, 1675, { rozmiar: 36, font: "t", waga: 700, wyr: "srodek", maks: 400, kolor: "$tl", we: W("zanik", 1.3, 0.4) }),
    ] }));
  V([["fi-podcast", "Podcast: dwie osoby jedna nad drugą", "noc"], ["fi-podcast-granat", "Podcast: dwie osoby, granat", "granat"]], () => ({ kat: "film", czas: 8,
    pola: [zf("film", "Film: osoba 1"), zf("film2", "Film: osoba 2"), tx("nazwa", "Nazwa podcastu", "NAZWA PODCASTU"), tx("odc", "Odcinek", "ODC. 12"), tx("imie1", "Osoba 1", "Anna Kowalska"), tx("imie2", "Osoba 2", "Piotr Nowak"), tx("temat", "Temat odcinka", "Jak zacząć własny biznes?")],
    warstwy: [
      T("nazwa", 70, 74, { rozmiar: 64, font: "n", waga: 700, wielkie: true, maks: 700, we: W("lewo", 0.05, 0.6) }),
      T("odc", 1010, 96, { rozmiar: 30, font: "t", waga: 700, wyr: "prawo", rozstaw: 100, kolor: "$a", we: W("zanik", 0.3, 0.6) }),
      ZF("film", 0, 220, 1080, 770, { we: W("odkryj-dol", 0.1, 0.8) }),
      ZF("film2", 0, 1000, 1080, 770, { we: W("odkryj-gora", 0.3, 0.8) }),
      P(40, 878, 470, 80, "$a", { r: 14, we: W("lewo", 0.8, 0.5) }),
      T("imie1", 70, 900, { rozmiar: 36, font: "t", waga: 800, maks: 410, kolor: "$tl", we: W("zanik", 0.9, 0.4) }),
      P(40, 1658, 470, 80, "$a", { r: 14, we: W("lewo", 1.0, 0.5) }),
      T("imie2", 70, 1680, { rozmiar: 36, font: "t", waga: 800, maks: 410, kolor: "$tl", we: W("zanik", 1.1, 0.4) }),
      T("temat", 540, 1815, { rozmiar: 38, font: "t", waga: 600, wyr: "srodek", we: W("gora", 1.2, 0.6) }),
    ] }));
  V([["fi-podcast-kola", "Podcast: dwie osoby w kołach", "fiolet"], ["fi-podcast-kola-piasek", "Podcast w kołach, piasek", "piasek"]], () => ({ kat: "film", czas: 8,
    pola: [zf("film", "Film: osoba 1"), zf("film2", "Film: osoba 2"), tx("nad", "Nadtytuł", "PODCAST"), tx("imie1", "Osoba 1", "Anna"), tx("imie2", "Osoba 2", "Piotr"), tx("tytul", "Temat", "ROZMOWA\nO PIENIĄDZACH"), tx("odc", "Odcinek", "ODCINEK 24")],
    warstwy: [
      T("nad", 540, 230, { rozmiar: 34, font: "t", waga: 700, wyr: "srodek", rozstaw: 400, kolor: "$a", we: W("zanik", 0.05, 0.6) }),
      ZF("film", 60, 370, 460, 460, { maska: "kolo", we: W("skala", 0.2, 0.8) }),
      ZF("film2", 560, 370, 460, 460, { maska: "kolo", we: W("skala", 0.35, 0.8) }),
      K(290, 600, 244, "$a", { obrys: 6, we: W("rysuj", 0.5, 0.8) }), K(790, 600, 244, "$a", { obrys: 6, we: W("rysuj", 0.6, 0.8) }),
      T("imie1", 290, 890, { rozmiar: 46, font: "t", waga: 700, wyr: "srodek", maks: 440, we: W("gora", 0.8, 0.5) }),
      T("imie2", 790, 890, { rozmiar: 46, font: "t", waga: 700, wyr: "srodek", maks: 440, we: W("gora", 0.9, 0.5) }),
      T("tytul", 540, 1040, { rozmiar: 110, font: "n", waga: 700, wyr: "srodek", interlinia: 0.95, wielkie: true, we: W("maska-gora", 1.0, 0.8) }),
      ...[60, 120, 90, 170, 130, 210, 150, 240, 180, 120, 220, 160, 250, 140, 190, 110, 160, 90, 130, 70, 100].map((h, i) =>
        P(250 + i * 28, 1460 - h / 2, 16, h, "$a", { r: 8, we: W("odkryj-gora", 1.1 + i * 0.03, 0.4) })),
      T("odc", 540, 1680, { rozmiar: 30, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, kolor: "$d", we: W("zanik", 1.6, 0.6) }),
    ] }));
  V([["fi-wiadomosci", "Wiadomości: pilne na filmie", "newsCz"], ["fi-wiadomosci-niebieskie", "Wiadomości, niebieskie", "newsNb"]], () => ({ kat: "film", czas: 8,
    pola: [zf(), tx("tag", "Etykieta", "PILNE"), tx("live", "Na żywo", "NA ŻYWO"), tx("kat", "Dział", "WIADOMOŚCI"), tx("tytul", "Nagłówek", "NOWE PRZEPISY OD\nPONIEDZIAŁKU"), tx("godz", "Godzina", "12:45"), tx("pasek", "Pasek na dole", "Więcej informacji na naszym profilu")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.5) }),
      C(0, 1150, 1080, 770, CZA, 0, 0.75),
      P(60, 120, 210, 72, "$a", { we: W("odkryj-lewo", 0.2, 0.4) }),
      T("tag", 165, 132, { rozmiar: 42, font: "n", waga: 700, wyr: "srodek", maks: 180, kolor: BIA, we: W("zanik", 0.3, 0.3) }),
      P(270, 120, 240, 72, BIA, { we: W("odkryj-lewo", 0.4, 0.4) }),
      K(305, 156, 11, "$a", { we: W("pop", 0.6, 0.4) }),
      T("live", 328, 141, { rozmiar: 28, font: "t", waga: 800, maks: 165, kolor: "#111111", we: W("zanik", 0.6, 0.3) }),
      P(60, 1430, 340, 72, "$a", { we: W("odkryj-lewo", 0.6, 0.4) }),
      T("kat", 85, 1444, { rozmiar: 38, font: "n", waga: 700, maks: 290, kolor: BIA, we: W("zanik", 0.7, 0.3) }),
      P(60, 1502, 960, 200, BIA, { we: W("odkryj-lewo", 0.7, 0.5) }),
      T("tytul", 90, 1530, { rozmiar: 64, font: "n", waga: 700, szer: 900, interlinia: 1.05, wielkie: true, kolor: "#111111", we: W("maska-gora", 1.0, 0.6) }),
      P(0, 1760, 1080, 96, "#111111", { we: W("odkryj-gora", 1.0, 0.4) }),
      P(0, 1760, 200, 96, "$a", { we: W("odkryj-gora", 1.0, 0.4) }),
      T("godz", 100, 1789, { rozmiar: 40, font: "n", waga: 700, wyr: "srodek", maks: 170, kolor: BIA, we: W("zanik", 1.2, 0.4) }),
      T("pasek", 230, 1792, { rozmiar: 32, font: "t", waga: 600, maks: 790, kolor: BIA, we: W("lewo", 1.3, 0.6) }),
    ] }));
  V([["fi-belka", "Film z belką imienia", "noc"], ["fi-belka-limonka", "Film z belką imienia, limonka", "limonka"]], () => ({ kat: "film", czas: 7,
    pola: [zf(), tx("imie", "Imię i nazwisko", "Anna Kowalska"), tx("rola", "Funkcja", "założycielka studia"), tx("logo", "Mały napis u góry", "WYWIAD")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.5) }),
      C(0, 1300, 1080, 620, CZA, 0, 0.6),
      T("logo", 990, 110, { rozmiar: 28, font: "t", waga: 800, wyr: "prawo", rozstaw: 300, kolor: BIA, we: W("zanik", 0.3, 0.6) }),
      P(60, 1500, 16, 170, "$a", { we: W("odkryj-gora", 0.5, 0.4) }),
      P(76, 1500, 720, 100, "$g", { we: W("odkryj-lewo", 0.6, 0.6) }),
      T("imie", 110, 1520, { rozmiar: 58, font: "n", waga: 700, maks: 660, we: W("maska-gora", 0.9, 0.5) }),
      P(76, 1600, 540, 70, "$a", { we: W("odkryj-lewo", 0.8, 0.6) }),
      T("rola", 110, 1617, { rozmiar: 32, font: "t", waga: 600, maks: 480, kolor: "$tl", we: W("zanik", 1.1, 0.4) }),
    ] }));
  V([["fi-przycisk", "Film z przyciskiem na końcu", "noc"], ["fi-przycisk-pomarancz", "Film z przyciskiem, pomarańcz", "pomarancz"]], () => ({ kat: "film", czas: 7,
    pola: [zf(), tx("tytul", "Tytuł", "Ostatnie\nwolne miejsca"), tx("przycisk", "Przycisk", "ZAPISZ SIĘ"), tx("opis", "Pod przyciskiem", "link w opisie profilu")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.5) }),
      C(0, 900, 1080, 1020, CZA, 0, 0.85),
      T("tytul", 540, 1170, { rozmiar: 120, font: "n", waga: 700, wyr: "srodek", interlinia: 0.98, kolor: BIA, we: W("maska-gora", 0.5, 0.8) }),
      TR(540, 1480, 26, "$a", { obrot: 180, we: W("dol", 1.1, 0.5) }),
      P(240, 1540, 600, 130, "$a", { r: 65, we: W("pop", 1.2, 0.6, "sprezyna") }),
      T("przycisk", 540, 1585, { rozmiar: 46, font: "t", waga: 800, wyr: "srodek", rozstaw: 100, maks: 520, kolor: "$tl", we: W("zanik", 1.4, 0.4) }),
      T("opis", 540, 1720, { rozmiar: 30, font: "t", wyr: "srodek", kolor: BIA, we: W("zanik", 1.6, 0.5) }),
    ] }));
  V([["fi-polaroid", "Film w ramce polaroidu", "piasek"]], () => ({ kat: "film", czas: 7,
    pola: [zf(), tx("podpis", "Podpis na ramce", "wakacje '26"), tx("tytul", "Tytuł", "WSPOMNIENIA\nZ LATA"), tx("opis", "Opis", "Chorwacja, sierpień")],
    warstwy: [
      P(130, 200, 820, 1060, BIA, { obrot: -3, we: W("pop", 0.05, 0.8, "sprezyna") }),
      ZF("film", 165, 240, 740, 800, { obrot: -3, we: W("zanik", 0.4, 0.6) }),
      T("podpis", 558, 1100, { rozmiar: 54, font: "t", waga: 500, wyr: "srodek", kolor: "#222222", obrot: -3, maks: 700, we: W("pisz", 0.9, 0.8) }),
      T("tytul", 90, 1380, { rozmiar: 120, font: "n", waga: 700, interlinia: 0.98, wielkie: true, we: W("maska-gora", 1.0, 0.8) }),
      T("opis", 90, 1660, { rozmiar: 34, font: "t", kolor: "$d", we: W("gora", 1.3, 0.6) }),
      L(90, 1760, 290, 1760, "$a", 4, { we: W("rysuj", 1.5, 0.6) }),
    ] }));
  V([["fi-tasma", "Film na taśmie filmowej", "krem"]], () => ({ kat: "film", czas: 8,
    pola: [zf(), tx("kadr", "Napis pod kadrem", "KADR 01"), tx("tytul", "Tytuł", "KLATKA\nPO KLATCE"), tx("opis", "Opis", "Kulisy naszego planu")],
    warstwy: [
      P(120, 0, 840, 1470, "#0A0A0A", { we: W("odkryj-dol", 0, 0.7) }),
      ...[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].flatMap((i) => [P(146, 30 + i * 110, 46, 64, "$tl", { r: 8, we: W("zanik", 0.3 + i * 0.03, 0.3) }), P(888, 30 + i * 110, 46, 64, "$tl", { r: 8, we: W("zanik", 0.3 + i * 0.03, 0.3) })]),
      ZF("film", 230, 110, 620, 1230, { we: W("odkryj-dol", 0.5, 0.8) }),
      T("kadr", 540, 1385, { rozmiar: 28, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, kolor: BIA, maks: 600, we: W("zanik", 1.0, 0.5) }),
      T("tytul", 90, 1530, { rozmiar: 110, font: "n", waga: 700, interlinia: 0.95, wielkie: true, we: W("maska-gora", 1.0, 0.8) }),
      T("opis", 990, 1800, { rozmiar: 30, font: "t", wyr: "prawo", kolor: "$d", we: W("zanik", 1.3, 0.6) }),
    ] }));
  V([["fi-top3", "Top 3 z filmem i listą", "noc"], ["fi-top3-zolty", "Top 3 z filmem, żółty", "zolty"]], () => ({ kat: "film", czas: 9,
    pola: [zf(), tx("tag", "Etykieta na filmie", "TOP 3"), tx("tytul", "Tytuł", "Miejsca, które musisz\nzobaczyć"), tx("p1", "Punkt 1", "Morskie Oko o świcie"), tx("p2", "Punkt 2", "Dolina Chochołowska"), tx("p3", "Punkt 3", "Kasprowy Wierch")],
    warstwy: [
      ZF("film", 60, 110, 960, 860, { maska: "zaokr", r: 40, we: W("odkryj-dol", 0.05, 0.8) }),
      P(90, 140, 220, 96, "$a", { r: 22, we: W("pop", 0.6, 0.5, "sprezyna") }),
      T("tag", 200, 160, { rozmiar: 56, font: "n", waga: 700, wyr: "srodek", maks: 190, kolor: "$tl", we: W("zanik", 0.7, 0.4) }),
      T("tytul", 60, 1020, { rozmiar: 80, font: "n", waga: 700, interlinia: 1.0, szer: 960, we: W("maska-gora", 0.6, 0.8) }),
      ...[0, 1, 2].flatMap((i) => [
        K(110, 1310 + i * 185, 44, "$a", { we: W("pop", 0.9 + i * 0.25, 0.5, "sprezyna") }),
        TL(String(i + 1), 110, 1287 + i * 185, { rozmiar: 54, font: "n", waga: 700, wyr: "srodek", kolor: "$tl", we: W("zanik", 1.0 + i * 0.25, 0.4) }),
        T("p" + (i + 1), 185, 1291 + i * 185, { rozmiar: 44, font: "t", waga: 600, maks: 820, we: W("lewo", 0.95 + i * 0.25, 0.5) }),
      ]),
      L(60, 1800, 1020, 1800, "$d", 2, { we: W("rysuj", 1.7, 0.6) }),
    ] }));
  V([["fi-opinia", "Opinia klienta z filmem", "biel"], ["fi-opinia-noc", "Opinia z filmem, ciemne", "noc"]], () => ({ kat: "film", czas: 8,
    pola: [zf("film", "Film albo zdjęcie klienta"), tx("opinia", "Opinia (wpisz prawdziwą)", "„Wpisz tu prawdziwą opinię klienta, najlepiej krótką i konkretną.”", 3), tx("autor", "Imię i nazwisko", "Imię Nazwisko"), tx("rola", "Kim jest", "klientka od 2024")],
    warstwy: [
      ZF("film", 90, 110, 900, 1090, { maska: "zaokr", r: 44, we: W("odkryj-dol", 0.05, 0.8) }),
      ...[0, 1, 2, 3, 4].map((i) => K(380 + i * 80, 1280, 26, "#F5B301", { we: W("pop", 0.6 + i * 0.08, 0.4, "sprezyna") })),
      T("opinia", 540, 1360, { rozmiar: 50, font: "n", waga: 600, wyr: "srodek", szer: 900, interlinia: 1.2, we: W("maska-gora", 0.9, 0.9) }),
      L(490, 1580, 590, 1580, "$a", 4, { we: W("rysuj", 1.3, 0.4) }),
      T("autor", 540, 1620, { rozmiar: 42, font: "t", waga: 700, wyr: "srodek", we: W("gora", 1.4, 0.5) }),
      T("rola", 540, 1685, { rozmiar: 30, font: "t", wyr: "srodek", kolor: "$d", we: W("zanik", 1.5, 0.5) }),
    ] }));
  V([["fi-produkt", "Produkt na filmie z ceną", "piasek"], ["fi-produkt-noc", "Produkt na filmie, ciemne", "noc"]], () => ({ kat: "film", czas: 8,
    pola: [zf("film", "Film albo zdjęcie produktu"), tx("cena", "Cena", "189 zł"), tx("nazwa", "Nazwa", "Wazon\nceramiczny"), tx("opis", "Opis", "Ręcznie robiony, 25 cm"), tx("przycisk", "Przycisk", "ZAMÓW TERAZ")],
    warstwy: [
      ZF("film", 140, 130, 800, 1130, { maska: "luk", we: W("odkryj-gora", 0.05, 0.9) }),
      K(860, 1200, 140, "$a", { we: W("pop", 0.8, 0.6, "sprezyna") }),
      T("cena", 860, 1170, { rozmiar: 64, font: "n", waga: 700, wyr: "srodek", maks: 230, kolor: "$tl", we: W("zanik", 1.0, 0.4) }),
      T("nazwa", 90, 1330, { rozmiar: 100, font: "n", waga: 700, interlinia: 0.98, szer: 660, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 90, 1560, { rozmiar: 34, font: "t", kolor: "$d", maks: 900, we: W("gora", 1.2, 0.6) }),
      P(90, 1670, 440, 110, "$t", { r: 55, we: W("odkryj-lewo", 1.4, 0.5) }),
      T("przycisk", 310, 1705, { rozmiar: 34, font: "t", waga: 800, wyr: "srodek", rozstaw: 100, maks: 390, kolor: "$tl", we: W("zanik", 1.6, 0.4) }),
    ] }));
  V([["fi-relacja", "Relacja z wydarzenia", "noc"], ["fi-relacja-granat", "Relacja z wydarzenia, granat", "granat"]], () => ({ kat: "film", czas: 8,
    pola: [zf(), tx("dzien", "Dzień", "18"), tx("miesiac", "Miesiąc", "LISTOPAD"), tx("nad", "Nadtytuł", "RELACJA"), tx("tytul", "Nazwa wydarzenia", "GALA\nBIZNESU 2026"), tx("miejsce", "Miejsce", "Warszawa · Hotel Bristol")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.5) }),
      C(0, 1100, 1080, 820, CZA, 0, 0.85),
      P(60, 100, 230, 250, "$a", { we: W("odkryj-dol", 0.3, 0.6) }),
      T("dzien", 175, 112, { rozmiar: 140, font: "n", waga: 700, wyr: "srodek", maks: 200, kolor: "$tl", we: W("licz", 0.5, 0.9) }),
      T("miesiac", 175, 285, { rozmiar: 28, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, maks: 200, kolor: "$tl", we: W("zanik", 0.7, 0.5) }),
      T("nad", 90, 1430, { rozmiar: 30, font: "t", waga: 700, rozstaw: 400, kolor: "$a", we: W("lewo", 0.7, 0.6) }),
      T("tytul", 90, 1480, { rozmiar: 130, font: "n", waga: 700, interlinia: 0.95, wielkie: true, kolor: BIA, we: W("maska-gora", 0.8, 0.8) }),
      T("miejsce", 90, 1770, { rozmiar: 32, font: "t", kolor: BIA, we: W("gora", 1.2, 0.6) }),
    ] }));
  V([["fi-vlog", "Vlog: dzień z życia", "limonka"]], () => ({ kat: "film", czas: 7,
    pola: [zf(), tx("nad", "Nad liczbą", "DZIEŃ"), tx("liczba", "Numer dnia", "12"), tx("tytul", "Tytuł", "Mój dzień\nw podróży"), tx("miejsce", "Miejsce", "Lizbona, Portugalia")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.5) }),
      C(0, 0, 1080, 560, CZA, 0.55, 0), C(0, 1250, 1080, 670, CZA, 0, 0.8),
      T("nad", 1000, 110, { rozmiar: 34, font: "t", waga: 700, wyr: "prawo", rozstaw: 300, kolor: BIA, we: W("zanik", 0.2, 0.5) }),
      T("liczba", 1000, 168, { rozmiar: 240, font: "n", waga: 700, wyr: "prawo", kolor: "$a", we: W("licz", 0.3, 1.0) }),
      T("tytul", 70, 1490, { rozmiar: 100, font: "n", waga: 700, interlinia: 0.98, kolor: BIA, we: W("maska-gora", 0.6, 0.8) }),
      P(60, 1720, 640, 100, CZA, { r: 50, krycie: 0.55, we: W("odkryj-lewo", 1.0, 0.5) }),
      K(115, 1770, 14, "$a", { we: W("pop", 1.2, 0.4) }),
      T("miejsce", 145, 1756, { rozmiar: 34, font: "t", waga: 700, maks: 530, kolor: BIA, we: W("zanik", 1.2, 0.4) }),
    ] }));
  V([["fi-luk", "Film w łuku z tytułem", "krem"], ["fi-luk-oliwka", "Film w łuku, oliwka", "oliwka"]], () => ({ kat: "film", czas: 8,
    pola: [zf(), tx("nad", "Nadtytuł", "NOWA KOLEKCJA"), tx("tytul", "Tytuł", "Spokojne\nporanki"), tx("opis", "Opis", "Kawa, światło i dobra książka.")],
    warstwy: [
      T("nad", 540, 150, { rozmiar: 26, font: "t", waga: 700, rozstaw: 400, wyr: "srodek", kolor: "$a", we: W("zanik", 0.05, 0.6) }),
      ZF("film", 190, 240, 700, 1060, { maska: "luk", we: W("odkryj-gora", 0.2, 1.0) }),
      K(870, 330, 80, "$a", { we: W("pop", 0.8, 0.6, "sprezyna") }),
      T("tytul", 540, 1370, { rozmiar: 120, font: "t", waga: 300, wyr: "srodek", interlinia: 1.0, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 540, 1660, { rozmiar: 32, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.2, 0.6) }),
    ] }));
  V([["fi-kolo", "Film w dużym kole", "noc"], ["fi-kolo-kobalt", "Film w dużym kole, kobalt", "kobalt"]], () => ({ kat: "film", czas: 8,
    pola: [zf(), tx("tytul", "Tytuł", "W CENTRUM\nUWAGI"), tx("opis", "Opis", "Nowy projekt już na profilu"), tx("tag", "Etykieta", "#nowość")],
    warstwy: [
      K(540, 760, 455, "$a", { obrys: 4, we: W("rysuj", 0.05, 1.0) }),
      ZF("film", 130, 350, 820, 820, { maska: "kolo", we: W("skala", 0.2, 0.9) }),
      K(150, 400, 16, "$a", { we: W("pop", 0.9, 0.4) }), K(950, 1140, 22, "$a", { we: W("pop", 1.0, 0.4) }),
      T("tytul", 540, 1300, { rozmiar: 110, font: "n", waga: 700, wyr: "srodek", interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.8, 0.8) }),
      T("opis", 540, 1550, { rozmiar: 34, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.1, 0.6) }),
      P(380, 1660, 320, 80, "$a", { r: 40, we: W("pop", 1.3, 0.5, "sprezyna") }),
      T("tag", 540, 1685, { rozmiar: 32, font: "t", waga: 700, wyr: "srodek", maks: 280, kolor: "$tl", we: W("zanik", 1.4, 0.4) }),
    ] }));
  V([["fi-ramka-gruba", "Film w grubej kolorowej ramce", "pomarancz"], ["fi-ramka-gruba-kobalt", "Film w grubej ramce, kobalt", "kobalt"]], () => ({ kat: "film", czas: 7,
    pola: [zf(), tx("tytul", "Tytuł", "WIELKIE\nOTWARCIE"), tx("naklejka", "Naklejka", "NOWE"), tx("opis", "Opis", "sobota, 10:00 · ul. Długa 5")],
    warstwy: [
      ZF("film", 60, 60, 960, 1480, { we: W("skala", 0.05, 0.8) }),
      K(890, 1500, 120, "$a", { we: W("pop", 0.7, 0.6, "sprezyna") }),
      T("naklejka", 890, 1478, { rozmiar: 50, font: "n", waga: 700, wyr: "srodek", maks: 200, kolor: "$tl", obrot: -10, we: W("zanik", 0.9, 0.4) }),
      T("tytul", 70, 1580, { rozmiar: 120, font: "n", waga: 700, interlinia: 0.92, wielkie: true, maks: 700, we: W("maska-gora", 0.6, 0.8) }),
      T("opis", 70, 1830, { rozmiar: 30, font: "t", waga: 600, we: W("gora", 1.0, 0.6) }),
    ] }));
  V([["fi-poradnik", "Poradnik: krok z filmem", "noc"], ["fi-poradnik-biel", "Poradnik: krok z filmem, białe", "biel"]], () => ({ kat: "film", czas: 8,
    pola: [zf(), tx("krok", "Numer kroku", "KROK 2"), tx("tytul", "Tytuł", "Ustaw ostrość\nna oczy"), tx("rada", "Wskazówka", "Dotknij ekranu na twarzy i przytrzymaj, żeby zablokować ostrość.", 3)],
    warstwy: [
      P(70, 110, 260, 70, "$a", { r: 35, we: W("pop", 0.05, 0.5, "sprezyna") }),
      T("krok", 200, 130, { rozmiar: 30, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, maks: 220, kolor: "$tl", we: W("zanik", 0.2, 0.4) }),
      T("tytul", 70, 220, { rozmiar: 86, font: "n", waga: 700, interlinia: 1.0, szer: 940, we: W("maska-gora", 0.2, 0.8) }),
      ZF("film", 60, 440, 960, 1110, { maska: "zaokr", r: 36, we: W("odkryj-dol", 0.4, 0.8) }),
      P(60, 1590, 960, 230, "$g", { r: 30, we: W("gora", 0.9, 0.6) }),
      K(140, 1660, 36, "$a", { we: W("pop", 1.1, 0.5, "sprezyna") }),
      TL("!", 140, 1630, { rozmiar: 54, font: "n", waga: 700, wyr: "srodek", kolor: "$tl", we: W("zanik", 1.2, 0.3) }),
      T("rada", 205, 1625, { rozmiar: 34, font: "t", waga: 500, szer: 770, interlinia: 1.35, we: W("zanik", 1.2, 0.6) }),
    ] }));
  V([["fi-pytanie", "Film i pytanie do widzów", "zolty"], ["fi-pytanie-noc", "Film i pytanie, ciemne", "noc"]], () => ({ kat: "film", czas: 8,
    pola: [zf(), tx("pytanie", "Pytanie", "CO BYŚ\nWYBRAŁ?"), tx("o1", "Odpowiedź A", "Góry"), tx("o2", "Odpowiedź B", "Morze"), tx("opis", "Dopisek", "Napisz w komentarzu!")],
    warstwy: [
      ZF("film", 0, 0, 1080, 980, { we: W("odkryj-dol", 0, 0.8) }),
      T("pytanie", 540, 1040, { rozmiar: 110, font: "n", waga: 700, wyr: "srodek", interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.5, 0.8) }),
      P(90, 1320, 900, 150, "$g", { r: 75, we: W("lewo", 0.9, 0.6) }),
      TL("A", 170, 1355, { rozmiar: 70, font: "n", waga: 700, wyr: "srodek", kolor: "$a", we: W("zanik", 1.0, 0.4) }),
      T("o1", 540, 1371, { rozmiar: 50, font: "t", waga: 800, wyr: "srodek", maks: 640, kolor: "$t", we: W("zanik", 1.0, 0.5) }),
      P(90, 1500, 900, 150, "$g", { r: 75, we: W("prawo", 1.1, 0.6) }),
      TL("B", 170, 1535, { rozmiar: 70, font: "n", waga: 700, wyr: "srodek", kolor: "$a", we: W("zanik", 1.2, 0.4) }),
      T("o2", 540, 1551, { rozmiar: 50, font: "t", waga: 800, wyr: "srodek", maks: 640, kolor: "$t", we: W("zanik", 1.2, 0.5) }),
      T("opis", 540, 1740, { rozmiar: 32, font: "t", waga: 600, wyr: "srodek", kolor: "$d", we: W("zanik", 1.5, 0.6) }),
    ] }));
  V([["fi-przepis", "Przepis z filmem", "krem"], ["fi-przepis-oliwka", "Przepis z filmem, oliwka", "oliwka"]], () => ({ kat: "film", czas: 9,
    pola: [zf(), tx("czas", "Czas przygotowania", "15 MIN"), tx("tytul", "Nazwa dania", "Makaron w 15 minut"), tx("skladniki", "Składniki (każdy w linii)", "• 200 g makaronu\n• 2 ząbki czosnku\n• oliwa i parmezan\n• świeża bazylia", 4), tx("opis", "Pasek na dole", "PRZEPIS W OPISIE")],
    warstwy: [
      ZF("film", 60, 90, 960, 900, { maska: "zaokr", r: 40, we: W("odkryj-dol", 0.05, 0.8) }),
      P(780, 120, 210, 80, "$tl", { r: 40, we: W("pop", 0.6, 0.5, "sprezyna") }),
      T("czas", 885, 143, { rozmiar: 32, font: "t", waga: 800, wyr: "srodek", maks: 180, we: W("zanik", 0.7, 0.4) }),
      T("tytul", 60, 1040, { rozmiar: 88, font: "n", waga: 700, szer: 960, interlinia: 1.0, we: W("maska-gora", 0.6, 0.8) }),
      L(60, 1245, 260, 1245, "$a", 5, { we: W("rysuj", 0.9, 0.5) }),
      T("skladniki", 60, 1290, { rozmiar: 46, font: "t", waga: 500, interlinia: 1.5, we: W("pisz", 1.0, 1.4) }),
      P(60, 1700, 960, 110, "$a", { r: 55, we: W("odkryj-lewo", 1.6, 0.5) }),
      T("opis", 540, 1736, { rozmiar: 34, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, maks: 880, kolor: "$tl", we: W("zanik", 1.8, 0.4) }),
    ] }));
  V([["fi-nieruchomosc", "Nieruchomość na filmie", "granat"], ["fi-nieruchomosc-biel", "Nieruchomość na filmie, białe", "biel"]], () => ({ kat: "film", czas: 9,
    pola: [zf("film", "Film albo zdjęcie mieszkania"), tx("tag", "Etykieta", "NA SPRZEDAŻ"), tx("cena", "Cena", "749 000 zł"), tx("adres", "Adres", "Kraków, Podgórze"),
      tx("w1", "Wartość 1", "68 m²"), tx("o1", "Opis 1", "metraż"), tx("w2", "Wartość 2", "3"), tx("o2", "Opis 2", "pokoje"), tx("w3", "Wartość 3", "2026"), tx("o3", "Opis 3", "rok budowy"), tx("kontakt", "Kontakt", "tel. 600 000 000")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1150, { we: W("odkryj-gora", 0, 0.8) }),
      P(60, 80, 330, 80, "$a", { r: 40, we: W("pop", 0.5, 0.5, "sprezyna") }),
      T("tag", 225, 105, { rozmiar: 30, font: "t", waga: 800, wyr: "srodek", rozstaw: 100, maks: 290, kolor: "$tl", we: W("zanik", 0.6, 0.4) }),
      T("cena", 90, 1200, { rozmiar: 120, font: "n", waga: 700, kolor: "$a", maks: 900, we: W("licz", 0.6, 1.0) }),
      T("adres", 90, 1370, { rozmiar: 40, font: "t", waga: 600, maks: 900, we: W("gora", 0.9, 0.6) }),
      ...[0, 1, 2].flatMap((i) => [
        P(90 + i * 310, 1470, 280, 210, "$g", { r: 24, we: W("gora", 1.0 + i * 0.15, 0.6) }),
        T("w" + (i + 1), 230 + i * 310, 1505, { rozmiar: 64, font: "n", waga: 700, wyr: "srodek", maks: 250, we: W("zanik", 1.1 + i * 0.15, 0.5) }),
        T("o" + (i + 1), 230 + i * 310, 1610, { rozmiar: 26, font: "t", waga: 600, wyr: "srodek", maks: 250, kolor: "$d", we: W("zanik", 1.2 + i * 0.15, 0.5) }),
      ]),
      T("kontakt", 90, 1760, { rozmiar: 32, font: "t", waga: 600, kolor: "$d", we: W("zanik", 1.6, 0.6) }),
    ] }));
  V([["fi-zapowiedz", "Zapowiedź na filmie: już wkrótce", "noc"], ["fi-zapowiedz-czerwien", "Zapowiedź na filmie, czerwony", "czerwien"]], () => ({ kat: "film", czas: 6,
    pola: [zf(), tx("nad", "Nadtytuł", "JUŻ WKRÓTCE"), tx("tytul", "Tytuł", "NOWY\nSEZON"), tx("data", "Data", "01.12")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.8) }),
      P(0, 0, 1080, 1920, CZA, { krycie: 0.5, we: W("zanik", 0.2, 0.6) }),
      L(140, 760, 940, 760, "$a", 3, { we: W("rysuj", 0.3, 0.7) }),
      T("nad", 540, 800, { rozmiar: 40, font: "t", waga: 700, rozstaw: 400, wyr: "srodek", kolor: "$a", we: W("zanik", 0.5, 0.7) }),
      T("tytul", 540, 890, { rozmiar: 230, font: "n", waga: 700, wyr: "srodek", interlinia: 0.9, wielkie: true, kolor: BIA, we: W("maska-gora", 0.7, 0.9) }),
      P(390, 1410, 300, 110, "$a", { r: 55, we: W("pop", 1.2, 0.6, "sprezyna") }),
      T("data", 540, 1432, { rozmiar: 60, font: "n", waga: 700, wyr: "srodek", maks: 260, kolor: "$tl", we: W("zanik", 1.4, 0.4) }),
    ] }));
  V([["fi-trzy-filmy", "Trzy filmy jeden pod drugim", "noc"]], () => ({ kat: "film", czas: 8,
    pola: [zf("film", "Film albo zdjęcie 1"), zf("film2", "Film albo zdjęcie 2"), zf("film3", "Film albo zdjęcie 3"), tx("tytul", "Tytuł", "MÓJ WEEKEND"), tx("e1", "Podpis 1", "piątek"), tx("e2", "Podpis 2", "sobota"), tx("e3", "Podpis 3", "niedziela")],
    warstwy: [
      T("tytul", 540, 90, { rozmiar: 120, font: "n", waga: 700, wyr: "srodek", wielkie: true, we: W("maska-gora", 0.05, 0.7) }),
      ...[0, 1, 2].flatMap((i) => [
        ZF(i ? "film" + (i + 1) : "film", 0, 270 + i * 555, 1080, 535, { we: W(i % 2 ? "odkryj-prawo" : "odkryj-lewo", 0.2 + i * 0.2, 0.8) }),
        P(i % 2 ? 750 : 40, 715 + i * 555, 290, 70, "$tl", { r: 35, krycie: 0.9, we: W("pop", 0.8 + i * 0.2, 0.5, "sprezyna") }),
        T("e" + (i + 1), i % 2 ? 895 : 185, 734 + i * 555, { rozmiar: 32, font: "t", waga: 700, wyr: "srodek", maks: 250, we: W("zanik", 0.9 + i * 0.2, 0.4) }),
      ]),
    ] }));
  V([["fi-wizjer", "Wizjer kamery z REC", "noc"]], () => ({ kat: "film", czas: 7,
    pola: [zf(), tx("rec", "Napis przy kropce", "REC"), tx("kod", "Kod czasowy", "00:12:48"), tx("tytul", "Tytuł", "KULISY NAGRANIA"), tx("info", "Dane kamery", "4K · 25 KL/S · ISO 800")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.5) }),
      C(0, 0, 1080, 360, CZA, 0.45, 0), C(0, 1500, 1080, 420, CZA, 0, 0.6),
      ...[[60, 60, 1, 1], [1020, 60, -1, 1], [60, 1860, 1, -1], [1020, 1860, -1, -1]].flatMap(([x, y, sx, sy], i) => [
        L(x, y, x + sx * 130, y, "$a", 6, { we: W("rysuj", 0.2 + i * 0.1, 0.5) }), L(x, y, x, y + sy * 130, "$a", 6, { we: W("rysuj", 0.2 + i * 0.1, 0.5) })]),
      K(130, 160, 18, "#FF3B30", { we: W("pop", 0.6, 0.4) }),
      T("rec", 165, 143, { rozmiar: 36, font: "t", waga: 800, kolor: BIA, maks: 300, we: W("zanik", 0.6, 0.4) }),
      T("kod", 950, 143, { rozmiar: 36, font: "t", waga: 600, wyr: "prawo", kolor: BIA, we: W("zanik", 0.7, 0.4) }),
      L(505, 960, 575, 960, BIA, 3, { krycie: 0.8, we: W("rysuj", 0.8, 0.4) }), L(540, 925, 540, 995, BIA, 3, { krycie: 0.8, we: W("rysuj", 0.8, 0.4) }),
      T("tytul", 130, 1650, { rozmiar: 64, font: "n", waga: 700, wielkie: true, kolor: BIA, maks: 820, we: W("maska-gora", 1.0, 0.6) }),
      T("info", 130, 1755, { rozmiar: 28, font: "t", waga: 600, kolor: BIA, krycie: 0.85, maks: 820, we: W("zanik", 1.2, 0.5) }),
    ] }));
  V([["fi-okladka", "Okładka magazynu na filmie", "noc"]], () => ({ kat: "film", czas: 7,
    pola: [zf(), tx("tytul", "Nazwa magazynu", "STYL"), tx("numer", "Numer i data", "NR 11 · LISTOPAD 2026"), tx("naglowek", "Nagłówek", "Twarz\nsezonu"), tx("opis", "Dopisek", "Wywiad, sesja i kulisy nagrania")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.7) }),
      C(0, 0, 1080, 560, CZA, 0.6, 0), C(0, 1180, 1080, 740, CZA, 0, 0.8),
      T("tytul", 540, 90, { rozmiar: 250, font: "n", waga: 700, wyr: "srodek", wielkie: true, rozstaw: 30, kolor: "$a", we: W("maska-gora", 0.2, 0.9) }),
      T("numer", 540, 400, { rozmiar: 24, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, kolor: BIA, we: W("zanik", 0.7, 0.6) }),
      T("naglowek", 80, 1430, { rozmiar: 120, font: "n", waga: 700, interlinia: 0.95, wielkie: true, kolor: BIA, we: W("maska-gora", 0.9, 0.8) }),
      L(80, 1700, 300, 1700, "$a", 5, { we: W("rysuj", 1.2, 0.6) }),
      T("opis", 80, 1740, { rozmiar: 32, font: "t", szer: 900, kolor: BIA, we: W("gora", 1.3, 0.6) }),
    ] }));
  V([["fi-film-zdjecia", "Duży film i dwa zdjęcia", "biel"]], () => ({ kat: "film", czas: 8,
    pola: [zf(), zd("z1", "Zdjęcie 1"), zd("z2", "Zdjęcie 2"), tx("tytul", "Tytuł", "Z NASZEGO\nWARSZTATU"), tx("opis", "Opis", "jeden dzień, trzy kadry")],
    warstwy: [
      ZF("film", 60, 100, 960, 1060, { we: W("odkryj-dol", 0.05, 0.8) }),
      C(60, 760, 960, 400, CZA, 0, 0.7),
      T("tytul", 110, 930, { rozmiar: 100, font: "n", waga: 700, interlinia: 0.95, wielkie: true, kolor: BIA, we: W("maska-gora", 0.6, 0.8) }),
      Zp("z1", 60, 1190, 470, 520, { we: W("gora", 0.8, 0.7) }),
      Zp("z2", 550, 1190, 470, 520, { we: W("gora", 0.95, 0.7) }),
      T("opis", 60, 1760, { rozmiar: 32, font: "t", waga: 600, kolor: "$d", we: W("zanik", 1.3, 0.6) }),
      P(940, 1760, 80, 8, "$a", { we: W("odkryj-lewo", 1.4, 0.4) }),
    ] }));
  V([["fi-rabat", "Promocja z filmem i rabatem", "czerwien"], ["fi-rabat-zolty", "Promocja z filmem, żółty", "zolty"]], () => ({ kat: "film", czas: 7,
    pola: [zf("film", "Film albo zdjęcie produktu"), tx("rabat", "Rabat", "-30%"), tx("tytul", "Tytuł", "WIELKA\nWYPRZEDAŻ"), tx("opis", "Kiedy", "tylko do niedzieli"), tx("przycisk", "Przycisk", "KUP TERAZ")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1150, { we: W("odkryj-gora", 0, 0.8) }),
      K(850, 1150, 180, "$a", { we: W("pop", 0.6, 0.7, "sprezyna") }),
      T("rabat", 850, 1085, { rozmiar: 130, font: "n", waga: 700, wyr: "srodek", maks: 320, kolor: "$tl", obrot: -8, we: W("zanik", 0.8, 0.4) }),
      T("tytul", 90, 1230, { rozmiar: 110, font: "n", waga: 700, interlinia: 0.95, wielkie: true, maks: 560, we: W("maska-gora", 0.7, 0.8) }),
      T("opis", 90, 1490, { rozmiar: 38, font: "t", waga: 500, kolor: "$d", we: W("gora", 1.0, 0.6) }),
      P(90, 1620, 480, 120, "$t", { r: 60, we: W("odkryj-lewo", 1.2, 0.5) }),
      T("przycisk", 330, 1659, { rozmiar: 40, font: "t", waga: 800, wyr: "srodek", rozstaw: 100, maks: 430, kolor: "$tl", we: W("zanik", 1.4, 0.4) }),
    ] }));
  V([["fi-wywiad", "Wywiad: pytanie nad filmem", "noc"], ["fi-wywiad-mieta", "Wywiad: pytanie nad filmem, mięta", "mieta"]], () => ({ kat: "film", czas: 8,
    pola: [zf(), tx("etyk", "Etykieta", "PYTANIE"), tx("pytanie", "Pytanie", "Co było najtrudniejsze na samym początku?", 2), tx("imie", "Imię i nazwisko", "Marta Zielińska"), tx("rola", "Funkcja", "fotografka ślubna")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.5) }),
      C(0, 1400, 1080, 520, CZA, 0, 0.75),
      P(60, 110, 960, 330, "$g", { r: 30, we: W("gora", 0.3, 0.6) }),
      P(100, 150, 230, 56, "$a", { r: 28, we: W("pop", 0.5, 0.4) }),
      T("etyk", 215, 166, { rozmiar: 24, font: "t", waga: 800, wyr: "srodek", rozstaw: 200, maks: 200, kolor: "$tl", we: W("zanik", 0.6, 0.3) }),
      T("pytanie", 100, 240, { rozmiar: 56, font: "n", waga: 600, szer: 880, interlinia: 1.12, we: W("maska-gora", 0.7, 0.7) }),
      P(60, 1640, 14, 140, "$a", { we: W("odkryj-gora", 1.0, 0.4) }),
      T("imie", 100, 1640, { rozmiar: 60, font: "n", waga: 700, kolor: BIA, maks: 880, we: W("lewo", 1.1, 0.5) }),
      T("rola", 100, 1730, { rozmiar: 32, font: "t", kolor: BIA, krycie: 0.85, we: W("lewo", 1.2, 0.5) }),
    ] }));
  V([["fi-ciekawostka", "Czy wiesz, że…? na filmie", "zolty"], ["fi-ciekawostka-limonka", "Czy wiesz, że…?, limonka", "limonka"]], () => ({ kat: "film", czas: 8,
    pola: [zf(), tx("nad", "Nagłówek dymka", "CZY WIESZ, ŻE…"), tx("fakt", "Ciekawostka", "Ośmiornica ma trzy serca i niebieską krew?", 3), tx("zrodlo", "Źródło", "źródło: wpisz, skąd to wiesz")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.5) }),
      C(0, 1000, 1080, 920, CZA, 0, 0.6),
      TR(200, 1205, 46, "$a", { obrot: 0, we: W("pop", 0.5, 0.5, "sprezyna") }),
      P(60, 1220, 960, 450, "$a", { r: 40, we: W("pop", 0.4, 0.7, "sprezyna") }),
      T("nad", 110, 1275, { rozmiar: 46, font: "n", waga: 700, wielkie: true, rozstaw: 60, maks: 860, kolor: "$tl", we: W("lewo", 0.7, 0.5) }),
      T("fakt", 110, 1360, { rozmiar: 56, font: "t", waga: 700, szer: 860, interlinia: 1.2, kolor: "$tl", we: W("maska-gora", 0.9, 0.8) }),
      T("zrodlo", 110, 1600, { rozmiar: 26, font: "t", waga: 500, kolor: "$tl", krycie: 0.7, maks: 860, we: W("zanik", 1.3, 0.5) }),
    ] }));
  V([["fi-cytat", "Cytat na filmie", "noc"]], () => ({ kat: "film", czas: 8,
    pola: [zf(), tx("cytat", "Cytat", "Nie czekaj na idealny moment. Weź chwilę i zrób ją idealną.", 3), tx("autor", "Autor", "— Twoje imię")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.8) }),
      P(0, 0, 1080, 1920, CZA, { krycie: 0.5, we: W("zanik", 0.2, 0.6) }),
      TL("“", 90, 640, { rozmiar: 360, font: "n", waga: 700, kolor: "$a", we: W("pop", 0.4, 0.7, "sprezyna") }),
      T("cytat", 90, 980, { rozmiar: 84, font: "n", waga: 600, szer: 900, interlinia: 1.15, kolor: BIA, we: W("maska-gora", 0.6, 1.0) }),
      L(90, 1510, 250, 1510, "$a", 5, { we: W("rysuj", 1.3, 0.5) }),
      T("autor", 90, 1550, { rozmiar: 36, font: "t", waga: 600, kolor: BIA, we: W("lewo", 1.4, 0.6) }),
    ] }));
  V([["fi-ekran", "Nagranie ekranu w oknie przeglądarki", "noc"], ["fi-ekran-niebo", "Nagranie ekranu w oknie, niebieski", "niebo"]], () => ({ kat: "film", czas: 8,
    pola: [zf("film", "Nagranie ekranu (film albo zrzut)"), tx("nad", "Nadtytuł", "PORADNIK"), tx("tytul", "Tytuł", "Jak to zrobić\nw 3 kliknięciach"), tx("adres", "Adres w pasku", "twojastrona.pl"), tx("opis", "Opis", "Pokazuję krok po kroku, bez instalowania czegokolwiek.", 2), tx("przycisk", "Przycisk", "WYPRÓBUJ")],
    warstwy: [
      T("nad", 90, 150, { rozmiar: 28, font: "t", waga: 700, rozstaw: 300, kolor: "$a", we: W("zanik", 0.05, 0.6) }),
      T("tytul", 90, 200, { rozmiar: 92, font: "n", waga: 700, interlinia: 1.0, szer: 900, we: W("maska-gora", 0.1, 0.8) }),
      P(60, 470, 960, 870, "$g", { r: 24, we: W("gora", 0.3, 0.7) }),
      K(110, 507, 12, "#FF5F57", { we: W("pop", 0.6, 0.3) }), K(150, 507, 12, "#FEBC2E", { we: W("pop", 0.65, 0.3) }), K(190, 507, 12, "#28C840", { we: W("pop", 0.7, 0.3) }),
      P(240, 487, 600, 40, "$tl", { r: 20, krycie: 0.6, we: W("zanik", 0.6, 0.4) }),
      T("adres", 265, 496, { rozmiar: 22, font: "t", waga: 500, kolor: "$d", maks: 560, we: W("zanik", 0.7, 0.4) }),
      ZF("film", 80, 546, 920, 774, { ruch: [1, 1], we: W("zanik", 0.6, 0.6) }),
      T("opis", 90, 1400, { rozmiar: 36, font: "t", szer: 900, interlinia: 1.4, kolor: "$d", we: W("gora", 1.0, 0.6) }),
      P(90, 1580, 420, 110, "$a", { r: 55, we: W("odkryj-lewo", 1.2, 0.5) }),
      T("przycisk", 300, 1615, { rozmiar: 36, font: "t", waga: 800, wyr: "srodek", rozstaw: 120, maks: 370, kolor: "$tl", we: W("zanik", 1.4, 0.4) }),
    ] }));
  V([["fi-wynik", "Wynik meczu na filmie", "czerwien"]], () => ({ kat: "film", czas: 7,
    pola: [zf(), tx("d1", "Drużyna 1", "GOSPODARZE"), tx("wynik", "Wynik", "2 : 1"), tx("d2", "Drużyna 2", "GOŚCIE"), tx("tytul", "Tytuł", "ZWYCIĘSTWO!"), tx("opis", "Opis", "Skrót meczu · 12. kolejka")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.5) }),
      C(0, 1400, 1080, 520, CZA, 0, 0.8),
      P(60, 110, 960, 260, "$tl", { r: 30, krycie: 0.9, we: W("dol", 0.2, 0.6) }),
      T("d1", 225, 222, { rozmiar: 34, font: "t", waga: 800, wyr: "srodek", maks: 270, we: W("zanik", 0.5, 0.5) }),
      T("wynik", 540, 155, { rozmiar: 150, font: "n", waga: 700, wyr: "srodek", maks: 280, kolor: "$a", we: W("pop", 0.6, 0.6, "sprezyna") }),
      T("d2", 855, 222, { rozmiar: 34, font: "t", waga: 800, wyr: "srodek", maks: 270, we: W("zanik", 0.5, 0.5) }),
      T("tytul", 90, 1620, { rozmiar: 120, font: "n", waga: 700, wielkie: true, kolor: BIA, we: W("maska-gora", 0.9, 0.7) }),
      T("opis", 90, 1780, { rozmiar: 32, font: "t", waga: 600, kolor: BIA, we: W("gora", 1.2, 0.6) }),
    ] }));
  V([["fi-zobacz-tez", "Plansza końcowa: zobacz też", "noc"], ["fi-zobacz-tez-biel", "Plansza końcowa: zobacz też, białe", "biel"]], () => ({ kat: "film", czas: 6,
    pola: [zf("film", "Fragment innego filmu"), tx("nad", "Nadtytuł", "ZOBACZ TEŻ"), tx("tytul", "Tytuł filmu", "Poprzedni odcinek: montaż na telefonie", 2), tx("przycisk", "Przycisk", "OBSERWUJ")],
    warstwy: [
      T("nad", 540, 190, { rozmiar: 36, font: "t", waga: 700, wyr: "srodek", rozstaw: 400, kolor: "$a", we: W("zanik", 0.05, 0.6) }),
      P(130, 290, 820, 1020, "$a", { r: 48, obrys: 5, we: W("zanik", 0.2, 0.6) }),
      ZF("film", 150, 310, 780, 980, { maska: "zaokr", r: 36, we: W("skala", 0.2, 0.7) }),
      K(540, 800, 84, CZA, { krycie: 0.55, we: W("pop", 0.7, 0.5, "sprezyna") }),
      TR(552, 800, 40, BIA, { obrot: 90, we: W("pop", 0.8, 0.5, "sprezyna") }),
      T("tytul", 540, 1370, { rozmiar: 66, font: "n", waga: 700, wyr: "srodek", szer: 880, interlinia: 1.1, we: W("maska-gora", 0.8, 0.7) }),
      P(290, 1600, 500, 120, "$a", { r: 60, we: W("pop", 1.1, 0.6, "sprezyna") }),
      T("przycisk", 540, 1639, { rozmiar: 40, font: "t", waga: 800, wyr: "srodek", rozstaw: 120, maks: 440, kolor: "$tl", we: W("zanik", 1.3, 0.4) }),
    ] }));
  V([["fi-liczby", "Film i trzy liczby", "noc"], ["fi-liczby-mieta", "Film i trzy liczby, mięta", "mieta"]], () => ({ kat: "film", czas: 8,
    pola: [zf(), tx("tytul", "Tytuł", "Nasz rok w liczbach"), tx("l1", "Liczba 1", "120"), tx("o1", "Opis 1", "projektów"), tx("l2", "Liczba 2", "35K"), tx("o2", "Opis 2", "obserwujących"), tx("l3", "Liczba 3", "98%"), tx("o3", "Opis 3", "poleceń")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1120, { we: W("odkryj-gora", 0, 0.8) }),
      C(0, 800, 1080, 320, "$tl", 0, 1),
      T("tytul", 90, 1080, { rozmiar: 84, font: "n", waga: 700, maks: 900, we: W("maska-gora", 0.5, 0.7) }),
      ...[0, 1, 2].flatMap((i) => [
        P(60 + i * 330, 1270, 300, 470, "$g", { r: 30, we: W("gora", 0.8 + i * 0.15, 0.6) }),
        T("l" + (i + 1), 210 + i * 330, 1370, { rozmiar: 110, font: "n", waga: 700, wyr: "srodek", maks: 260, kolor: "$a", we: W("licz", 0.9 + i * 0.15, 1.0) }),
        T("o" + (i + 1), 210 + i * 330, 1550, { rozmiar: 30, font: "t", waga: 600, wyr: "srodek", szer: 250, interlinia: 1.3, we: W("zanik", 1.1 + i * 0.15, 0.5) }),
      ]),
    ] }));
  V([["fi-lista-obok", "Film obok listy punktów", "biel"], ["fi-lista-obok-granat", "Film obok listy, granat", "granat"]], () => ({ kat: "film", czas: 9,
    pola: [zf(), tx("tytul", "Tytuł", "MOJA\nRUTYNA"), tx("k1", "Punkt 1", "Szklanka wody"), tx("k2", "Punkt 2", "10 minut ruchu"), tx("k3", "Punkt 3", "Kawa bez telefonu"), tx("k4", "Punkt 4", "Plan na dzień")],
    warstwy: [
      ZF("film", 540, 0, 540, 1920, { we: W("odkryj-dol", 0, 0.9) }),
      T("tytul", 60, 170, { rozmiar: 110, font: "n", waga: 700, interlinia: 0.95, wielkie: true, maks: 440, we: W("maska-gora", 0.3, 0.8) }),
      ...[0, 1, 2, 3].flatMap((i) => [
        K(95, 720 + i * 290, 36, "$a", { we: W("pop", 0.7 + i * 0.25, 0.5, "sprezyna") }),
        TL(String(i + 1), 95, 696 + i * 290, { rozmiar: 44, font: "n", waga: 700, wyr: "srodek", kolor: "$tl", we: W("zanik", 0.8 + i * 0.25, 0.4) }),
        T("k" + (i + 1), 150, 700 + i * 290, { rozmiar: 42, font: "t", waga: 600, szer: 360, interlinia: 1.25, we: W("lewo", 0.75 + i * 0.25, 0.6) }),
      ]),
    ] }));
  V([["fi-pasek-dol", "Film z paskiem tytułu na dole", "noc"], ["fi-pasek-dol-zolty", "Film z paskiem na dole, żółty", "zolty"]], () => ({ kat: "film", czas: 7,
    pola: [zf(), tx("tytul", "Tytuł", "Tak wygląda nasz dzień pracy"), tx("nick", "Nick", "@twojprofil")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1560, { we: W("zanik", 0, 0.5) }),
      P(0, 1560, 1080, 12, "$a", { we: W("odkryj-lewo", 0.3, 0.5) }),
      T("tytul", 70, 1620, { rozmiar: 76, font: "n", waga: 700, szer: 940, interlinia: 1.02, we: W("maska-gora", 0.5, 0.8) }),
      K(90, 1838, 10, "$a", { we: W("pop", 1.0, 0.4) }),
      T("nick", 115, 1824, { rozmiar: 28, font: "t", waga: 700, kolor: "$d", we: W("zanik", 1.0, 0.5) }),
    ] }));
  V([["fi-ramka-elegancka", "Film w podwójnej cienkiej ramce", "krem"], ["fi-ramka-elegancka-noc", "Film w podwójnej ramce, ciemne", "noc"]], () => ({ kat: "film", czas: 8,
    pola: [zf(), tx("nad", "Nadtytuł", "EST. 2019"), tx("tytul", "Tytuł", "Atelier\nSmaku"), tx("opis", "Opis", "kuchnia sezonowa · Kraków")],
    warstwy: [
      P(80, 80, 920, 1760, "$a", { obrys: 2, we: W("rysuj", 0.05, 1.2) }),
      P(100, 100, 880, 1720, "$a", { obrys: 1, we: W("rysuj", 0.2, 1.2) }),
      ZF("film", 160, 170, 760, 1080, { we: W("zanik", 0.4, 0.8) }),
      T("nad", 540, 1320, { rozmiar: 24, font: "t", waga: 600, wyr: "srodek", rozstaw: 500, kolor: "$a", we: W("zanik", 0.8, 0.6) }),
      T("tytul", 540, 1370, { rozmiar: 130, font: "t", waga: 300, wyr: "srodek", interlinia: 0.98, we: W("maska-gora", 0.9, 0.9) }),
      L(490, 1655, 590, 1655, "$a", 2, { we: W("rysuj", 1.2, 0.5) }),
      T("opis", 540, 1690, { rozmiar: 28, font: "t", wyr: "srodek", kolor: "$d", we: W("zanik", 1.3, 0.6) }),
    ] }));
  V([["fi-rolka-hak", "Hak: wielki napis na filmie", "noc"]], () => ({ kat: "film", czas: 5,
    pola: [zf(), tx("tytul", "Napis (hak)", "NIE RÓB\nTEGO BŁĘDU"), tx("opis", "Pod spodem", "zostań do końca")],
    warstwy: [
      ZF("film", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.4) }),
      P(0, 0, 1080, 1920, CZA, { krycie: 0.25 }),
      P(60, 760, 960, 400, "$a", { obrot: -3, we: W("pop", 0.1, 0.6, "sprezyna") }),
      T("tytul", 540, 805, { rozmiar: 150, font: "n", waga: 700, wyr: "srodek", interlinia: 0.95, wielkie: true, kolor: "$tl", obrot: -3, maks: 880, we: W("zanik", 0.3, 0.3) }),
      T("opis", 540, 1240, { rozmiar: 40, font: "t", waga: 700, wyr: "srodek", kolor: BIA, we: W("gora", 0.8, 0.5) }),
    ] }));

  // ======================= EDYTORSKIE =======================
  V([["ed-spis-tresci", "Spis treści ze zdjęciem", "papier"], ["ed-spis-tresci-granat", "Spis treści, granat", "granat"]], () => ({ kat: "edytorskie", czas: 9,
    pola: [zd("z1", "Zdjęcie"), tx("nad", "Nadtytuł", "W TYM NUMERZE"), tx("tytul", "Tytuł", "Spis\ntreści"), tx("opis", "Opis", "Wszystko, co ważne w tym miesiącu.", 2),
      tx("s1", "Strona 1", "04"), tx("p1", "Temat 1", "Jak zaczęliśmy: historia małej pracowni"), tx("s2", "Strona 2", "12"), tx("p2", "Temat 2", "Pięć rzeczy, które zmieniły nasz warsztat"), tx("s3", "Strona 3", "27"), tx("p3", "Temat 3", "Plan na nowy sezon")],
    warstwy: [
      Zp("z1", 540, 0, 540, 960, { we: W("odkryj-dol", 0, 0.8) }),
      T("nad", 70, 150, { rozmiar: 26, font: "t", waga: 700, rozstaw: 300, kolor: "$a", maks: 420, we: W("zanik", 0.2, 0.6) }),
      T("tytul", 70, 210, { rozmiar: 130, font: "n", waga: 700, interlinia: 0.95, maks: 420, we: W("maska-gora", 0.3, 0.8) }),
      T("opis", 70, 520, { rozmiar: 30, font: "t", szer: 400, interlinia: 1.4, kolor: "$d", we: W("gora", 0.6, 0.6) }),
      ...[0, 1, 2].flatMap((i) => [
        T("s" + (i + 1), 70, 1040 + i * 270, { rozmiar: 100, font: "n", waga: 700, kolor: "$a", we: W("zanik", 0.8 + i * 0.2, 0.5) }),
        T("p" + (i + 1), 260, 1060 + i * 270, { rozmiar: 40, font: "t", waga: 600, szer: 740, interlinia: 1.25, we: W("lewo", 0.85 + i * 0.2, 0.6) }),
        L(70, 1230 + i * 270, 1010, 1230 + i * 270, "$d", 2, { we: W("rysuj", 0.9 + i * 0.2, 0.6) }),
      ]),
    ] }));
  V([["ed-wywiad-pytanie", "Wywiad: pytanie i odpowiedź", "biel"]], () => ({ kat: "edytorskie", czas: 9,
    pola: [zd("z1", "Zdjęcie rozmówcy"), tx("imie", "Imię i nazwisko", "Marta Zielińska"), tx("rola", "Kim jest", "fotografka, 12 lat w zawodzie"), tx("pyt", "Pytanie", "Od czego zacząć, jeśli chcę robić lepsze zdjęcia?", 2),
      tx("odp", "Odpowiedź", "Od światła. Zanim kupisz nowy sprzęt, naucz się patrzeć, skąd pada światło i jak zmienia twarz. To darmowe i działa od razu.", 4)],
    warstwy: [
      Zp("z1", 60, 110, 960, 760, { we: W("odkryj-dol", 0, 0.8) }),
      T("imie", 60, 920, { rozmiar: 90, font: "n", waga: 700, maks: 960, we: W("maska-gora", 0.5, 0.7) }),
      T("rola", 60, 1035, { rozmiar: 30, font: "t", kolor: "$d", maks: 960, we: W("zanik", 0.7, 0.6) }),
      L(60, 1110, 1020, 1110, "$d", 2, { we: W("rysuj", 0.8, 0.6) }),
      TL("P:", 60, 1160, { rozmiar: 44, font: "n", waga: 700, kolor: "$a", we: W("zanik", 0.9, 0.4) }),
      T("pyt", 140, 1160, { rozmiar: 44, font: "t", waga: 700, szer: 880, interlinia: 1.25, we: W("gora", 0.9, 0.6) }),
      TL("O:", 60, 1330, { rozmiar: 44, font: "n", waga: 700, kolor: "$a", we: W("zanik", 1.1, 0.4) }),
      T("odp", 140, 1334, { rozmiar: 38, font: "t", szer: 880, interlinia: 1.45, kolor: "$d", we: W("gora", 1.1, 0.6) }),
    ] }));
  V([["ed-numer-wydania", "Wielki numer wydania", "pomarancz"]], () => ({ kat: "edytorskie", czas: 7,
    pola: [zd("z1", "Zdjęcie"), tx("numer", "Numer", "07"), tx("tytul", "Tytuł", "NUMER\nSIÓDMY"), tx("opis", "Opis", "Wydanie o odwadze, zmianie i nowych początkach")],
    warstwy: [
      T("numer", 1010, 40, { rozmiar: 560, font: "n", waga: 700, wyr: "prawo", kolor: "$a", we: W("maska-gora", 0.05, 0.9) }),
      T("tytul", 70, 150, { rozmiar: 44, font: "t", waga: 800, rozstaw: 200, wielkie: true, interlinia: 1.3, maks: 320, we: W("lewo", 0.4, 0.6) }),
      L(70, 300, 230, 300, "$t", 4, { we: W("rysuj", 0.5, 0.5) }),
      Zp("z1", 60, 640, 960, 1000, { we: W("odkryj-gora", 0.4, 0.9) }),
      T("opis", 70, 1700, { rozmiar: 40, font: "t", waga: 600, szer: 940, interlinia: 1.3, we: W("gora", 1.0, 0.6) }),
    ] }));

  // ======================= MINIMALISTYCZNE =======================
  V([["mi-kropka", "Zdjęcie z kropką i słowem", "piasek"]], () => ({ kat: "minimal", czas: 7,
    pola: [zd("z1", "Zdjęcie"), tx("slowo", "Słowo", "spokój"), tx("opis", "Podpis", "kolekcja 2026")],
    warstwy: [
      Zp("z1", 240, 420, 600, 780, { we: W("odkryj-gora", 0.1, 0.9) }),
      K(840, 420, 44, "$a", { we: W("pop", 0.8, 0.6, "sprezyna") }),
      T("slowo", 540, 1300, { rozmiar: 100, font: "t", waga: 300, wyr: "srodek", rozstaw: 40, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 540, 1450, { rozmiar: 26, font: "t", waga: 600, wyr: "srodek", rozstaw: 300, wielkie: true, kolor: "$d", we: W("zanik", 1.2, 0.6) }),
    ] }));
  V([["mi-kadr-cienki", "Pełne zdjęcie z cienką ramką", "noc"]], () => ({ kat: "minimal", czas: 7,
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "cisza przed świtem"), tx("opis", "Podpis", "Tatry, październik")],
    warstwy: [
      Zp("z1", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.8) }),
      C(0, 1300, 1080, 620, CZA, 0, 0.6),
      P(60, 60, 960, 1800, BIA, { obrys: 2, we: W("rysuj", 0.3, 1.2) }),
      T("tytul", 120, 1640, { rozmiar: 64, font: "t", waga: 300, kolor: BIA, maks: 840, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 120, 1745, { rozmiar: 24, font: "t", waga: 600, rozstaw: 300, wielkie: true, kolor: BIA, we: W("zanik", 1.2, 0.6) }),
    ] }));
  V([["mi-dwa-slowa", "Dwa słowa i linia", "biel"], ["mi-dwa-slowa-mieta", "Dwa słowa i linia, mięta", "mieta"]], () => ({ kat: "minimal", czas: 6,
    pola: [tx("w1", "Słowo 1", "mniej"), tx("w2", "Słowo 2", "więcej"), tx("opis", "Podpis", "Mniej rzeczy, więcej czasu na to, co ważne.", 2)],
    warstwy: [
      T("w1", 90, 660, { rozmiar: 160, font: "t", waga: 300, we: W("lewo", 0.1, 0.8) }),
      L(90, 900, 990, 900, "$t", 2, { we: W("rysuj", 0.4, 0.8) }),
      T("w2", 990, 940, { rozmiar: 160, font: "t", waga: 800, wyr: "prawo", kolor: "$a", we: W("prawo", 0.6, 0.8) }),
      T("opis", 90, 1300, { rozmiar: 30, font: "t", szer: 620, interlinia: 1.45, kolor: "$d", we: W("gora", 1.0, 0.6) }),
      K(980, 1330, 10, "$t", { we: W("pop", 1.2, 0.4) }),
    ] }));

  // ======================= KOŁA I ROMBY =======================
  V([["ks-kopula", "Zdjęcie pod kopułą", "noc"]], () => ({ kat: "ksztalty", czas: 8,
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "PONAD\nCHMURAMI"), tx("opis", "Opis", "Zdjęcia z porannego lotu balonem")],
    warstwy: [
      Zp("z1", 60, 140, 960, 1180, { maska: "luk", we: W("odkryj-gora", 0.05, 1.0) }),
      K(540, 620, 520, "$a", { obrys: 3, krycie: 0.5, we: W("rysuj", 0.6, 1.2) }),
      T("tytul", 540, 1390, { rozmiar: 130, font: "n", waga: 700, wyr: "srodek", interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 540, 1680, { rozmiar: 34, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.2, 0.6) }),
    ] }));
  V([["ks-zespol", "Zespół: trzy osoby w kołach", "biel"]], () => ({ kat: "ksztalty", czas: 9,
    pola: [zd("z1", "Osoba 1"), zd("z2", "Osoba 2"), zd("z3", "Osoba 3"), tx("tytul", "Tytuł", "NASZA\nEKIPA"), tx("n1", "Imię 1", "Anna"), tx("r1", "Rola 1", "montaż i kolor"), tx("n2", "Imię 2", "Piotr"), tx("r2", "Rola 2", "zdjęcia i dron"), tx("n3", "Imię 3", "Ola"), tx("r3", "Rola 3", "grafika i animacje"), tx("stopka", "Stopka", "TWOJASTRONA.PL")],
    warstwy: [
      T("tytul", 90, 160, { rozmiar: 130, font: "n", waga: 700, interlinia: 1.05, wielkie: true, we: W("maska-gora", 0.05, 0.8) }),
      ...[0, 1, 2].flatMap((i) => [
        Zp("z" + (i + 1), 90, 540 + i * 390, 300, 300, { maska: "kolo", we: W("skala", 0.4 + i * 0.25, 0.7) }),
        K(240, 690 + i * 390, 166, "$a", { obrys: 4, we: W("rysuj", 0.5 + i * 0.25, 0.8) }),
        T("n" + (i + 1), 460, 630 + i * 390, { rozmiar: 64, font: "n", waga: 700, maks: 550, we: W("lewo", 0.6 + i * 0.25, 0.6) }),
        T("r" + (i + 1), 460, 720 + i * 390, { rozmiar: 32, font: "t", kolor: "$d", maks: 550, we: W("lewo", 0.7 + i * 0.25, 0.6) }),
      ]),
      T("stopka", 540, 1780, { rozmiar: 24, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, kolor: "$d", we: W("zanik", 1.4, 0.6) }),
    ] }));
  V([["ks-kapsula", "Zdjęcie w kształcie kapsuły", "mieta"], ["ks-kapsula-noc", "Zdjęcie w kapsule, ciemne", "noc"]], () => ({ kat: "ksztalty", czas: 8,
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "Zielony\nweekend"), tx("opis", "Opis", "Las, rower i zero zasięgu")],
    warstwy: [
      P(250, 230, 520, 1100, "$a", { r: 260, obrys: 4, we: W("zanik", 0.5, 0.7) }),
      Zp("z1", 290, 190, 520, 1100, { maska: "zaokr", r: 260, we: W("odkryj-gora", 0.1, 1.0) }),
      K(830, 300, 18, "$a", { we: W("pop", 0.9, 0.4) }), K(230, 1200, 12, "$a", { we: W("pop", 1.0, 0.4) }),
      T("tytul", 540, 1400, { rozmiar: 120, font: "t", waga: 300, wyr: "srodek", interlinia: 1.0, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 540, 1680, { rozmiar: 32, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.2, 0.6) }),
    ] }));

  // ======================= KOLAŻE =======================
  V([["ko-mozaika", "Mozaika pięciu zdjęć", "biel"], ["ko-mozaika-noc", "Mozaika pięciu zdjęć, ciemna", "noc"]], () => ({ kat: "kolaz", czas: 8,
    pola: [zd("z1", "Zdjęcie duże"), zd("z2", "Zdjęcie 2"), zd("z3", "Zdjęcie 3"), zd("z4", "Zdjęcie 4"), zd("z5", "Zdjęcie 5"), tx("tytul", "Tytuł", "MAJ W KADRACH"), tx("opis", "Opis", "najlepsze chwile miesiąca")],
    warstwy: [
      Zp("z1", 60, 60, 620, 820, { we: W("skala", 0.05, 0.7) }),
      Zp("z2", 700, 60, 320, 400, { we: W("skala", 0.2, 0.7) }),
      Zp("z3", 700, 480, 320, 400, { we: W("skala", 0.35, 0.7) }),
      Zp("z4", 60, 900, 320, 560, { we: W("skala", 0.5, 0.7) }),
      Zp("z5", 400, 900, 620, 560, { we: W("skala", 0.65, 0.7) }),
      T("tytul", 60, 1530, { rozmiar: 120, font: "n", waga: 700, wielkie: true, we: W("maska-gora", 0.9, 0.7) }),
      T("opis", 60, 1690, { rozmiar: 34, font: "t", kolor: "$d", we: W("gora", 1.1, 0.6) }),
      P(60, 1800, 140, 8, "$a", { we: W("odkryj-lewo", 1.3, 0.5) }),
    ] }));
  V([["ko-paski-pionowe", "Cztery zdjęcia w pionowych paskach", "piasek"]], () => ({ kat: "kolaz", czas: 8,
    pola: [zd("z1", "Zdjęcie 1"), zd("z2", "Zdjęcie 2"), zd("z3", "Zdjęcie 3"), zd("z4", "Zdjęcie 4"), tx("tytul", "Tytuł", "CZTERY\nPORY ROKU"), tx("opis", "Opis", "jedno miejsce, cztery kadry")],
    warstwy: [
      ...[0, 1, 2, 3].map((i) => Zp("z" + (i + 1), 60 + i * 245, i % 2 ? 220 : 120, 235, 1200, { we: W(i % 2 ? "odkryj-gora" : "odkryj-dol", 0.1 + i * 0.15, 0.8) })),
      T("tytul", 60, 1470, { rozmiar: 120, font: "n", waga: 700, interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.8, 0.8) }),
      T("opis", 60, 1740, { rozmiar: 32, font: "t", kolor: "$d", we: W("gora", 1.1, 0.6) }),
    ] }));
  V([["ko-polaroidy", "Trzy polaroidy z podpisami", "roz"]], () => ({ kat: "kolaz", czas: 8,
    pola: [zd("z1", "Zdjęcie 1"), zd("z2", "Zdjęcie 2"), zd("z3", "Zdjęcie 3"), tx("c1", "Podpis 1", "plaża"), tx("c2", "Podpis 2", "kolacja"), tx("c3", "Podpis 3", "zachód słońca"), tx("tytul", "Tytuł", "LATO\n2026")],
    warstwy: [
      ...[[90, 110, -5], [450, 570, 4], [70, 1170, -2]].flatMap(([x, y, o], i) => {
        const s = Math.sin(o * Math.PI / 180);
        return [P(x, y, 540, 640, BIA, { obrot: o, we: W("pop", 0.1 + i * 0.3, 0.7, "sprezyna") }),
          Zp("z" + (i + 1), x + 30 + Math.round(50 * s), y + 30, 480, 480, { obrot: o, we: W("zanik", 0.3 + i * 0.3, 0.6) }),
          T("c" + (i + 1), x + 270 - Math.round(250 * s), y + 545, { rozmiar: 40, font: "t", waga: 500, wyr: "srodek", kolor: "#222222", obrot: o, we: W("pisz", 0.5 + i * 0.3, 0.6) })];
      }),
      T("tytul", 990, 1500, { rozmiar: 130, font: "n", waga: 700, wyr: "prawo", interlinia: 0.95, wielkie: true, we: W("maska-gora", 1.2, 0.8) }),
    ] }));

  // ======================= LICZBY I OBSERWUJĄCY =======================
  V([["st-paski", "Paski z procentami", "noc"], ["st-paski-mieta", "Paski z procentami, mięta", "mieta"]], () => ({ kat: "statystyki", czas: 8,
    pola: [tx("tytul", "Tytuł", "Co lubicie\nnajbardziej?"), tx("e1", "Pozycja 1", "Poradniki"), tx("v1", "Wynik 1", "82%"), tx("e2", "Pozycja 2", "Kulisy"), tx("v2", "Wynik 2", "64%"), tx("e3", "Pozycja 3", "Recenzje"), tx("v3", "Wynik 3", "47%"), tx("e4", "Pozycja 4", "Vlogi"), tx("v4", "Wynik 4", "30%"), tx("opis", "Podpis", "ankieta: 1200 głosów")],
    warstwy: [
      T("tytul", 90, 200, { rozmiar: 100, font: "n", waga: 700, interlinia: 1.0, szer: 900, we: W("maska-gora", 0.05, 0.8) }),
      ...[0.82, 0.64, 0.47, 0.3].flatMap((p, i) => [
        T("e" + (i + 1), 90, 600 + i * 270, { rozmiar: 42, font: "t", waga: 600, maks: 640, we: W("lewo", 0.4 + i * 0.2, 0.5) }),
        T("v" + (i + 1), 990, 590 + i * 270, { rozmiar: 56, font: "n", waga: 700, wyr: "prawo", kolor: "$a", we: W("licz", 0.5 + i * 0.2, 0.9) }),
        P(90, 680 + i * 270, 900, 44, "$g", { r: 22, we: W("zanik", 0.4 + i * 0.2, 0.4) }),
        P(90, 680 + i * 270, Math.round(900 * p), 44, "$a", { r: 22, we: W("odkryj-lewo", 0.5 + i * 0.2, 0.9) }),
      ]),
      T("opis", 90, 1720, { rozmiar: 30, font: "t", kolor: "$d", we: W("zanik", 1.5, 0.6) }),
    ] }));
  V([["st-bylo-jest", "Było i jest: porównanie liczb", "granat"]], () => ({ kat: "statystyki", czas: 8,
    pola: [tx("nad", "Nadtytuł", "PO 6 MIESIĄCACH"), tx("e1", "Podpis 1", "BYŁO"), tx("l1", "Liczba 1", "1 200"), tx("e2", "Podpis 2", "JEST"), tx("l2", "Liczba 2", "48 000"), tx("opis", "Opis", "obserwujących na Instagramie", 2)],
    warstwy: [
      T("nad", 540, 260, { rozmiar: 32, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, kolor: "$a", we: W("zanik", 0.05, 0.6) }),
      T("e1", 540, 420, { rozmiar: 34, font: "t", waga: 700, wyr: "srodek", rozstaw: 200, kolor: "$d", we: W("zanik", 0.3, 0.5) }),
      T("l1", 540, 480, { rozmiar: 200, font: "n", waga: 700, wyr: "srodek", kolor: "$d", we: W("licz", 0.4, 0.9) }),
      TR(540, 840, 56, "$a", { obrot: 180, we: W("dol", 0.9, 0.5) }),
      T("e2", 540, 960, { rozmiar: 34, font: "t", waga: 700, wyr: "srodek", rozstaw: 200, we: W("zanik", 1.0, 0.5) }),
      T("l2", 540, 1020, { rozmiar: 300, font: "n", waga: 700, wyr: "srodek", kolor: "$a", we: W("licz", 1.1, 1.3) }),
      T("opis", 540, 1420, { rozmiar: 42, font: "t", waga: 600, wyr: "srodek", szer: 860, interlinia: 1.3, we: W("gora", 1.5, 0.6) }),
    ] }));
  V([["st-zdjecie-wzrost", "Zdjęcie i wielki wzrost w procentach", "zolty"]], () => ({ kat: "statystyki", czas: 7,
    pola: [zd("z1", "Zdjęcie"), tx("liczba", "Liczba", "+240%"), tx("opis", "Opis", "więcej zamówień po wprowadzeniu rolek", 2), tx("zrodlo", "Dopisek", "dane: styczeń – czerwiec 2026")],
    warstwy: [
      Zp("z1", 0, 0, 1080, 1000, { we: W("odkryj-gora", 0, 0.8) }),
      T("liczba", 70, 1030, { rozmiar: 330, font: "n", waga: 700, kolor: "$a", we: W("licz", 0.5, 1.2) }),
      T("opis", 90, 1450, { rozmiar: 50, font: "t", waga: 700, szer: 900, interlinia: 1.2, we: W("gora", 1.0, 0.6) }),
      T("zrodlo", 90, 1700, { rozmiar: 28, font: "t", kolor: "$d", we: W("zanik", 1.3, 0.6) }),
    ] }));

  // ======================= CYTATY I HASŁA =======================
  V([["cy-wpis", "Cytat jako wpis w sieci", "biel"], ["cy-wpis-noc", "Cytat jako wpis, ciemny", "noc"]], () => ({ kat: "cytaty", czas: 8,
    pola: [zd("z1", "Zdjęcie profilowe"), tx("nad", "Nadtytuł", "MYŚL DNIA"), tx("imie", "Imię", "Twoje Imię"), tx("nick", "Nick", "@twojprofil"), tx("wpis", "Treść wpisu", "Najlepsza inwestycja to ta w siebie. Kurs, książka, dobry mentor. Reszta przychodzi później.", 4), tx("meta", "Data", "12:45 · 5 lis 2026")],
    warstwy: [
      T("nad", 540, 420, { rozmiar: 30, font: "t", waga: 700, wyr: "srodek", rozstaw: 400, kolor: "$d", we: W("zanik", 0.05, 0.6) }),
      P(60, 560, 960, 800, "$g", { r: 40, we: W("gora", 0.1, 0.7) }),
      Zp("z1", 110, 620, 120, 120, { maska: "kolo", we: W("pop", 0.3, 0.6, "sprezyna") }),
      T("imie", 260, 630, { rozmiar: 40, font: "t", waga: 700, maks: 700, we: W("lewo", 0.4, 0.5) }),
      T("nick", 260, 690, { rozmiar: 30, font: "t", kolor: "$d", maks: 700, we: W("lewo", 0.5, 0.5) }),
      T("wpis", 110, 800, { rozmiar: 58, font: "t", waga: 500, szer: 860, interlinia: 1.3, we: W("pisz", 0.7, 1.6) }),
      L(110, 1220, 970, 1220, "$d", 2, { krycie: 0.5, we: W("rysuj", 1.2, 0.6) }),
      T("meta", 110, 1260, { rozmiar: 28, font: "t", kolor: "$d", we: W("zanik", 1.3, 0.6) }),
    ] }));
  V([["cy-pasek-skos", "Hasło z ukośnym paskiem", "roz"]], () => ({ kat: "cytaty", czas: 6,
    pola: [tx("l1", "Linia 1", "Rób mniej,"), tx("l2", "Linia 2 (na pasku)", "ale lepiej."), tx("autor", "Podpis", "@twojprofil")],
    warstwy: [
      T("l1", 540, 640, { rozmiar: 150, font: "n", waga: 700, wyr: "srodek", we: W("maska-gora", 0.1, 0.8) }),
      P(30, 870, 1020, 200, "$a", { obrot: -3, we: W("odkryj-lewo", 0.5, 0.6) }),
      T("l2", 540, 893, { rozmiar: 150, font: "n", waga: 700, wyr: "srodek", kolor: "$g", obrot: -3, we: W("zanik", 0.8, 0.4) }),
      T("autor", 540, 1220, { rozmiar: 32, font: "t", waga: 600, wyr: "srodek", kolor: "$d", we: W("gora", 1.1, 0.6) }),
    ] }));
  V([["cy-narozniki", "Cytat w narożnikach", "oliwka"]], () => ({ kat: "cytaty", czas: 8,
    pola: [tx("cytat", "Cytat", "Nie musisz widzieć całych schodów. Wystarczy, że zrobisz pierwszy krok.", 4), tx("autor", "Autor", "MARTIN LUTHER KING")],
    warstwy: [
      ...[[120, 520, 1, 1], [960, 520, -1, 1], [120, 1400, 1, -1], [960, 1400, -1, -1]].flatMap(([x, y, sx, sy], i) => [
        L(x, y, x + sx * 120, y, "$a", 5, { we: W("rysuj", 0.1 + i * 0.1, 0.5) }), L(x, y, x, y + sy * 120, "$a", 5, { we: W("rysuj", 0.1 + i * 0.1, 0.5) })]),
      T("cytat", 540, 680, { rozmiar: 66, font: "t", waga: 600, wyr: "srodek", szer: 740, interlinia: 1.3, we: W("maska-gora", 0.5, 1.0) }),
      T("autor", 540, 1250, { rozmiar: 28, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, kolor: "$a", we: W("zanik", 1.2, 0.6) }),
    ] }));

  // ======================= PROMOCJE I PRODUKTY =======================
  V([["pr-kod-rabatowy", "Kod rabatowy w ramce", "noc"], ["pr-kod-rabatowy-roz", "Kod rabatowy, róż", "roz"]], () => ({ kat: "promocje", czas: 7,
    pola: [tx("tytul", "Tytuł", "-20%\nNA WSZYSTKO"), tx("nad", "Nad kodem", "WPISZ KOD"), tx("kod", "Kod", "NADA20"), tx("opis", "Ważność", "ważny do 30.11"), tx("przycisk", "Przycisk", "DO SKLEPU")],
    warstwy: [
      T("tytul", 540, 330, { rozmiar: 140, font: "n", waga: 700, wyr: "srodek", interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.05, 0.8) }),
      T("nad", 540, 760, { rozmiar: 28, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, kolor: "$d", we: W("zanik", 0.5, 0.5) }),
      ...[...Array(20).keys()].flatMap((i) => [P(144 + i * 40, 820, 24, 5, "$t", { we: W("zanik", 0.6 + i * 0.02, 0.3) }), P(144 + i * 40, 1080, 24, 5, "$t", { we: W("zanik", 0.6 + i * 0.02, 0.3) })]),
      ...[...Array(7).keys()].flatMap((i) => [P(140, 830 + i * 36, 5, 20, "$t", { we: W("zanik", 0.7, 0.3) }), P(935, 830 + i * 36, 5, 20, "$t", { we: W("zanik", 0.7, 0.3) })]),
      T("kod", 540, 895, { rozmiar: 120, font: "n", waga: 700, wyr: "srodek", rozstaw: 100, kolor: "$a", maks: 740, we: W("pop", 0.9, 0.6, "sprezyna") }),
      T("opis", 540, 1160, { rozmiar: 36, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.1, 0.6) }),
      P(290, 1360, 500, 120, "$a", { r: 60, we: W("pop", 1.3, 0.6, "sprezyna") }),
      T("przycisk", 540, 1399, { rozmiar: 40, font: "t", waga: 800, wyr: "srodek", rozstaw: 120, maks: 440, kolor: "$tl", we: W("zanik", 1.5, 0.4) }),
    ] }));
  V([["pr-stara-cena", "Stara i nowa cena", "biel"]], () => ({ kat: "promocje", czas: 7,
    pola: [zd("z1", "Zdjęcie produktu"), tx("rabat", "Rabat", "-38%"), tx("nazwa", "Nazwa", "Słuchawki\nbezprzewodowe"), tx("stara", "Stara cena", "399 zł"), tx("nowa", "Nowa cena", "249 zł")],
    warstwy: [
      Zp("z1", 90, 110, 900, 1000, { maska: "zaokr", r: 40, we: W("odkryj-dol", 0.05, 0.8) }),
      K(880, 1100, 120, "#FF3D3D", { we: W("pop", 0.6, 0.6, "sprezyna") }),
      T("rabat", 880, 1074, { rozmiar: 64, font: "n", waga: 700, wyr: "srodek", maks: 200, kolor: BIA, we: W("zanik", 0.8, 0.4) }),
      T("nazwa", 90, 1180, { rozmiar: 86, font: "n", waga: 700, interlinia: 1.0, szer: 680, we: W("maska-gora", 0.7, 0.8) }),
      T("stara", 90, 1420, { rozmiar: 60, font: "t", waga: 500, kolor: "$d", we: W("zanik", 1.0, 0.5) }),
      L(80, 1462, 310, 1440, "#FF3D3D", 6, { we: W("rysuj", 1.2, 0.4) }),
      T("nowa", 90, 1500, { rozmiar: 170, font: "n", waga: 700, kolor: "$a", we: W("pop", 1.3, 0.6, "sprezyna") }),
    ] }));
  V([["pr-darmowa-dostawa", "Darmowa dostawa", "kobalt"]], () => ({ kat: "promocje", czas: 7,
    pola: [tx("nad", "Nadtytuł", "TYLKO W TYM TYGODNIU"), tx("tytul", "Tytuł", "DARMOWA\nDOSTAWA"), tx("opis", "Warunek", "przy zamówieniu od 99 zł"), tx("przycisk", "Przycisk", "ZAMÓW")],
    warstwy: [
      T("nad", 90, 400, { rozmiar: 28, font: "t", waga: 700, rozstaw: 300, kolor: "$a", we: W("zanik", 0.05, 0.6) }),
      T("tytul", 90, 460, { rozmiar: 190, font: "n", waga: 700, interlinia: 0.9, wielkie: true, we: W("maska-gora", 0.2, 0.9) }),
      P(90, 880, 560, 16, "$a", { we: W("odkryj-lewo", 0.7, 0.6) }),
      T("opis", 90, 960, { rozmiar: 46, font: "t", waga: 600, szer: 900, we: W("gora", 0.9, 0.6) }),
      P(560, 1180, 330, 210, "$a", { r: 18, we: W("prawo", 1.0, 0.7) }),
      P(900, 1250, 140, 140, "$a", { r: 18, we: W("prawo", 1.05, 0.7) }),
      P(925, 1270, 70, 50, "$tl", { r: 8, we: W("prawo", 1.05, 0.7) }),
      K(660, 1400, 42, "$t", { we: W("pop", 1.3, 0.5, "sprezyna") }), K(960, 1400, 42, "$t", { we: W("pop", 1.35, 0.5, "sprezyna") }),
      ...[0, 1, 2].map((i) => L(380 + i * 40, 1230 + i * 60, 520, 1230 + i * 60, "$t", 6, { krycie: 0.5, we: W("rysuj", 1.2 + i * 0.1, 0.4) })),
      P(90, 1600, 440, 120, "$t", { r: 60, we: W("odkryj-lewo", 1.4, 0.5) }),
      T("przycisk", 310, 1639, { rozmiar: 40, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, maks: 390, kolor: "$tl", we: W("zanik", 1.6, 0.4) }),
    ] }));

  // ======================= WYDARZENIA =======================
  V([["wy-webinar", "Webinar z prowadzącym", "granat"]], () => ({ kat: "wydarzenia", czas: 9,
    pola: [zd("z1", "Zdjęcie prowadzącego"), tx("tag", "Etykieta", "WEBINAR · ONLINE"), tx("tytul", "Temat", "Jak zwiększyć\nzasięgi w 2027"), tx("imie", "Prowadzący", "Anna Kowalska"), tx("rola", "Kim jest", "strateżka social media, 8 lat doświadczenia", 2),
      tx("data", "Data", "24.11"), tx("godz", "Godzina", "godz. 19:00 · na żywo"), tx("plan", "Program (każdy punkt w linii)", "• 3 sprawdzone formaty rolek\n• analiza Twojego profilu\n• pytania na żywo", 3), tx("przycisk", "Przycisk", "ZAPISZ SIĘ ZA DARMO")],
    warstwy: [
      P(90, 130, 380, 70, "$a", { r: 35, we: W("pop", 0.05, 0.5, "sprezyna") }),
      T("tag", 280, 151, { rozmiar: 26, font: "t", waga: 800, wyr: "srodek", rozstaw: 100, maks: 340, kolor: "$tl", we: W("zanik", 0.2, 0.4) }),
      T("tytul", 90, 250, { rozmiar: 96, font: "n", waga: 700, interlinia: 1.0, szer: 900, we: W("maska-gora", 0.2, 0.8) }),
      Zp("z1", 90, 520, 340, 340, { maska: "kolo", we: W("skala", 0.5, 0.7) }),
      K(260, 690, 186, "$a", { obrys: 5, we: W("rysuj", 0.6, 0.8) }),
      T("imie", 490, 600, { rozmiar: 54, font: "n", waga: 700, maks: 520, we: W("lewo", 0.7, 0.6) }),
      T("rola", 490, 690, { rozmiar: 28, font: "t", szer: 500, interlinia: 1.35, kolor: "$d", we: W("lewo", 0.8, 0.6) }),
      T("data", 90, 970, { rozmiar: 130, font: "n", waga: 700, kolor: "$a", we: W("maska-gora", 0.9, 0.7) }),
      T("godz", 90, 1135, { rozmiar: 40, font: "t", waga: 600, we: W("gora", 1.0, 0.6) }),
      L(90, 1230, 990, 1230, "$d", 2, { krycie: 0.6, we: W("rysuj", 1.0, 0.6) }),
      T("plan", 90, 1280, { rozmiar: 38, font: "t", interlinia: 1.55, we: W("pisz", 1.1, 1.2) }),
      P(90, 1600, 900, 130, "$a", { r: 65, we: W("odkryj-lewo", 1.5, 0.6) }),
      T("przycisk", 540, 1643, { rozmiar: 42, font: "t", waga: 800, wyr: "srodek", rozstaw: 80, maks: 820, kolor: "$tl", we: W("zanik", 1.7, 0.4) }),
    ] }));
  V([["wy-otwarcie", "Wielkie otwarcie ze wstęgą", "czerwien"]], () => ({ kat: "wydarzenia", czas: 8,
    pola: [zd("z1", "Zdjęcie miejsca"), tx("wstega", "Napis na wstędze", "WIELKIE OTWARCIE"), tx("data", "Data", "12.12.2026"), tx("godz", "Dzień i godzina", "sobota, od 10:00"), tx("adres", "Adres", "ul. Długa 5, Kraków"), tx("opis", "Dopisek", "Na pierwszych 50 gości czeka prezent!", 2)],
    warstwy: [
      Zp("z1", 0, 0, 1080, 1100, { we: W("odkryj-gora", 0, 0.8) }),
      P(0, 1040, 1080, 110, "$a", { we: W("odkryj-lewo", 0.5, 0.7) }),
      T("wstega", 540, 1073, { rozmiar: 46, font: "n", waga: 700, wyr: "srodek", rozstaw: 100, maks: 940, kolor: "$t", we: W("zanik", 0.8, 0.4) }),
      T("data", 540, 1250, { rozmiar: 130, font: "n", waga: 700, wyr: "srodek", we: W("maska-gora", 1.0, 0.8) }),
      T("godz", 540, 1420, { rozmiar: 44, font: "t", waga: 600, wyr: "srodek", kolor: "$d", we: W("gora", 1.2, 0.6) }),
      T("adres", 540, 1490, { rozmiar: 38, font: "t", wyr: "srodek", we: W("gora", 1.3, 0.6) }),
      T("opis", 540, 1630, { rozmiar: 36, font: "t", waga: 700, wyr: "srodek", szer: 860, interlinia: 1.3, kolor: "$a", we: W("zanik", 1.5, 0.6) }),
    ] }));
  V([["wy-kalendarz", "Kartka z kalendarza", "piasek"], ["wy-kalendarz-noc", "Kartka z kalendarza, ciemna", "noc"]], () => ({ kat: "wydarzenia", czas: 7,
    pola: [tx("miesiac", "Miesiąc", "LISTOPAD"), tx("dzien", "Dzień", "24"), tx("tydz", "Dzień tygodnia", "wtorek"), tx("tytul", "Tytuł", "Zapisz datę!"), tx("opis", "Opis", "Premiera naszego nowego kursu", 2)],
    warstwy: [
      P(190, 380, 700, 820, "$g", { r: 40, we: W("pop", 0.05, 0.7, "sprezyna") }),
      P(190, 380, 700, 180, "$a", { r: 40, we: W("zanik", 0.3, 0.4) }), P(190, 480, 700, 80, "$a", { we: W("zanik", 0.3, 0.4) }),
      K(350, 380, 24, "$t", { we: W("pop", 0.4, 0.4) }), K(730, 380, 24, "$t", { we: W("pop", 0.45, 0.4) }),
      T("miesiac", 540, 440, { rozmiar: 64, font: "n", waga: 700, wyr: "srodek", wielkie: true, rozstaw: 80, maks: 620, kolor: "$tl", we: W("zanik", 0.5, 0.4) }),
      T("dzien", 540, 600, { rozmiar: 380, font: "n", waga: 700, wyr: "srodek", maks: 640, we: W("licz", 0.6, 1.0) }),
      T("tydz", 540, 1080, { rozmiar: 40, font: "t", waga: 600, wyr: "srodek", kolor: "$d", we: W("zanik", 0.9, 0.5) }),
      T("tytul", 540, 1320, { rozmiar: 100, font: "n", waga: 700, wyr: "srodek", we: W("maska-gora", 1.0, 0.7) }),
      T("opis", 540, 1470, { rozmiar: 38, font: "t", wyr: "srodek", szer: 860, interlinia: 1.35, kolor: "$d", we: W("gora", 1.2, 0.6) }),
    ] }));

  // ======================= PODRÓŻE I LIFESTYLE =======================
  V([["li-przepis-talerz", "Przepis: talerz i składniki", "krem"]], () => ({ kat: "lifestyle", czas: 9,
    pola: [zd("z1", "Zdjęcie dania"), tx("tytul", "Nazwa dania", "Shakshuka"), tx("e1", "Etykieta 1", "CZAS"), tx("w1", "Wartość 1", "25 min"), tx("e2", "Etykieta 2", "PORCJE"), tx("w2", "Wartość 2", "2"), tx("e3", "Etykieta 3", "POZIOM"), tx("w3", "Wartość 3", "łatwy"),
      tx("skladniki", "Składniki (każdy w linii)", "• 4 jajka\n• puszka pomidorów\n• papryka i cebula\n• kmin, papryka wędzona", 4)],
    warstwy: [
      K(540, 500, 380, "$g", { we: W("skala", 0.05, 0.8) }),
      Zp("z1", 200, 160, 680, 680, { maska: "kolo", we: W("skala", 0.2, 0.8) }),
      T("tytul", 540, 920, { rozmiar: 110, font: "n", waga: 700, wyr: "srodek", we: W("maska-gora", 0.6, 0.8) }),
      ...[0, 1, 2].flatMap((i) => [
        T("e" + (i + 1), 220 + i * 320, 1110, { rozmiar: 24, font: "t", waga: 700, wyr: "srodek", rozstaw: 200, kolor: "$a", maks: 280, we: W("zanik", 0.8 + i * 0.1, 0.5) }),
        T("w" + (i + 1), 220 + i * 320, 1150, { rozmiar: 46, font: "t", waga: 700, wyr: "srodek", maks: 280, we: W("gora", 0.85 + i * 0.1, 0.5) }),
      ]),
      L(90, 1260, 990, 1260, "$d", 2, { krycie: 0.5, we: W("rysuj", 1.0, 0.6) }),
      T("skladniki", 140, 1310, { rozmiar: 42, font: "t", waga: 500, interlinia: 1.5, we: W("pisz", 1.1, 1.4) }),
    ] }));
  V([["li-stylizacja", "Stylizacja dnia z cenami", "biel"]], () => ({ kat: "lifestyle", czas: 9,
    pola: [zd("z1", "Zdjęcie stylizacji"), tx("tytul", "Tytuł", "OUTFIT\nDNIA"), tx("e1", "Rzecz 1", "Płaszcz wełniany"), tx("c1", "Cena 1", "499 zł"), tx("e2", "Rzecz 2", "Sweter z kaszmiru"), tx("c2", "Cena 2", "249 zł"), tx("e3", "Rzecz 3", "Botki skórzane"), tx("c3", "Cena 3", "389 zł"), tx("sklep", "Sklep", "sklep.pl")],
    warstwy: [
      Zp("z1", 0, 0, 620, 1920, { we: W("odkryj-dol", 0, 0.9) }),
      T("tytul", 670, 150, { rozmiar: 100, font: "n", waga: 700, interlinia: 0.95, wielkie: true, maks: 360, we: W("maska-gora", 0.4, 0.8) }),
      ...[0, 1, 2].flatMap((i) => [
        T("e" + (i + 1), 670, 560 + i * 380, { rozmiar: 34, font: "t", waga: 600, szer: 360, interlinia: 1.25, we: W("prawo", 0.7 + i * 0.25, 0.6) }),
        T("c" + (i + 1), 670, 680 + i * 380, { rozmiar: 70, font: "n", waga: 700, kolor: "$a", maks: 360, we: W("licz", 0.8 + i * 0.25, 0.8) }),
        L(670, 800 + i * 380, 1020, 800 + i * 380, "$d", 2, { we: W("rysuj", 0.9 + i * 0.25, 0.5) }),
      ]),
      T("sklep", 670, 1780, { rozmiar: 28, font: "t", waga: 700, rozstaw: 100, kolor: "$d", maks: 360, we: W("zanik", 1.6, 0.6) }),
    ] }));
  V([["li-bilet-lot", "Następny przystanek: bilet lotniczy", "niebo"], ["li-bilet-lot-noc", "Następny przystanek, ciemne", "noc"]], () => ({ kat: "lifestyle", czas: 8,
    pola: [zd("z1", "Zdjęcie celu podróży"), tx("nad", "Nadtytuł", "NASTĘPNY PRZYSTANEK"), tx("skad", "Skąd (kod)", "KRK"), tx("dokad", "Dokąd (kod)", "LIS"), tx("skad2", "Skąd (miasto)", "Kraków"), tx("dokad2", "Dokąd (miasto)", "Lizbona"), tx("data", "Data", "14.03.2027"), tx("godz", "Godzina", "06:40"), tx("opis", "Opis", "5 dni, 3 miasta i jeden plecak.")],
    warstwy: [
      Zp("z1", 0, 0, 1080, 1100, { we: W("odkryj-gora", 0, 0.8) }),
      P(60, 980, 960, 760, "$g", { r: 40, we: W("gora", 0.4, 0.7) }),
      T("nad", 110, 1040, { rozmiar: 26, font: "t", waga: 700, rozstaw: 300, kolor: "$a", we: W("zanik", 0.6, 0.5) }),
      T("skad", 110, 1100, { rozmiar: 140, font: "n", waga: 700, wielkie: true, maks: 330, we: W("lewo", 0.7, 0.6) }),
      T("dokad", 970, 1100, { rozmiar: 140, font: "n", waga: 700, wyr: "prawo", wielkie: true, maks: 330, we: W("prawo", 0.8, 0.6) }),
      L(420, 1180, 660, 1180, "$d", 3, { we: W("rysuj", 0.9, 0.6) }),
      TR(560, 1180, 30, "$a", { obrot: 90, we: W("pop", 1.1, 0.5, "sprezyna") }),
      T("skad2", 110, 1270, { rozmiar: 32, font: "t", kolor: "$d", maks: 400, we: W("zanik", 1.0, 0.5) }),
      T("dokad2", 970, 1270, { rozmiar: 32, font: "t", wyr: "prawo", kolor: "$d", maks: 400, we: W("zanik", 1.0, 0.5) }),
      L(110, 1360, 970, 1360, "$d", 2, { krycie: 0.5, we: W("rysuj", 1.1, 0.6) }),
      T("data", 110, 1400, { rozmiar: 52, font: "n", waga: 700, we: W("gora", 1.2, 0.5) }),
      T("godz", 970, 1400, { rozmiar: 52, font: "n", waga: 700, wyr: "prawo", kolor: "$a", we: W("gora", 1.25, 0.5) }),
      T("opis", 110, 1530, { rozmiar: 34, font: "t", szer: 860, interlinia: 1.35, we: W("zanik", 1.4, 0.6) }),
    ] }));

  // ======================= ZAPOWIEDZI I ZAKOŃCZENIA =======================
  V([["za-subskrybuj", "Subskrybuj z dzwonkiem", "czerwien"]], () => ({ kat: "zakonczenia", czas: 6,
    pola: [zd("z1", "Zdjęcie albo logo kanału"), tx("kanal", "Nazwa kanału", "Nazwa kanału"), tx("opis", "Opis", "nowe odcinki w każdy piątek"), tx("przycisk", "Przycisk", "SUBSKRYBUJ"), tx("dzwonek", "Pod dzwonkiem", "i kliknij dzwonek")],
    warstwy: [
      Zp("z1", 390, 360, 300, 300, { maska: "kolo", we: W("pop", 0.05, 0.6, "sprezyna") }),
      T("kanal", 540, 740, { rozmiar: 86, font: "n", waga: 700, wyr: "srodek", we: W("maska-gora", 0.3, 0.7) }),
      T("opis", 540, 870, { rozmiar: 36, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 0.5, 0.6) }),
      P(240, 1030, 600, 140, "$a", { r: 70, we: W("pop", 0.7, 0.6, "sprezyna") }),
      T("przycisk", 540, 1076, { rozmiar: 48, font: "t", waga: 800, wyr: "srodek", rozstaw: 100, maks: 540, kolor: "$t", we: W("zanik", 0.9, 0.4) }),
      P(495, 1300, 90, 100, "$t", { r: 45, we: W("pop", 1.1, 0.5, "sprezyna") }),
      P(470, 1370, 140, 34, "$t", { r: 12, we: W("pop", 1.1, 0.5, "sprezyna") }),
      K(540, 1422, 15, "$t", { we: W("pop", 1.2, 0.4) }),
      L(445, 1300, 425, 1270, "$t", 5, { we: W("rysuj", 1.3, 0.3) }), L(635, 1300, 655, 1270, "$t", 5, { we: W("rysuj", 1.3, 0.3) }),
      T("dzwonek", 540, 1490, { rozmiar: 32, font: "t", wyr: "srodek", kolor: "$d", we: W("zanik", 1.4, 0.5) }),
    ] }));
  V([["za-nastepny-odcinek", "Następny odcinek ze zdjęciem", "fiolet"]], () => ({ kat: "zakonczenia", czas: 6,
    pola: [zd("z1", "Kadr z następnego odcinka"), tx("nad", "Nadtytuł", "NASTĘPNY ODCINEK"), tx("tytul", "Tytuł", "JAK USTAWIĆ\nŚWIATŁO"), tx("kiedy", "Kiedy", "PIĄTEK, 18:00"), tx("opis", "Opis", "Obserwuj, żeby go nie przegapić")],
    warstwy: [
      T("nad", 90, 180, { rozmiar: 28, font: "t", waga: 700, rozstaw: 300, kolor: "$a", we: W("zanik", 0.05, 0.6) }),
      T("tytul", 90, 235, { rozmiar: 120, font: "n", waga: 700, interlinia: 1.04, wielkie: true, we: W("maska-gora", 0.1, 0.8) }),
      Zp("z1", 90, 580, 900, 900, { maska: "zaokr", r: 40, we: W("odkryj-dol", 0.4, 0.8) }),
      K(540, 1030, 90, CZA, { krycie: 0.5, we: W("pop", 0.8, 0.5, "sprezyna") }),
      TR(553, 1030, 44, BIA, { obrot: 90, we: W("pop", 0.9, 0.5, "sprezyna") }),
      T("kiedy", 90, 1550, { rozmiar: 64, font: "n", waga: 700, kolor: "$a", we: W("lewo", 1.0, 0.6) }),
      T("opis", 90, 1660, { rozmiar: 34, font: "t", kolor: "$d", we: W("gora", 1.2, 0.6) }),
    ] }));
  V([["za-kontakt", "Dane kontaktowe", "noc"], ["za-kontakt-biel", "Dane kontaktowe, białe", "biel"]], () => ({ kat: "zakonczenia", czas: 7,
    pola: [lg("logo", "Logo"), tx("tytul", "Tytuł", "Porozmawiajmy"), tx("e1", "Etykieta 1", "TELEFON"), tx("v1", "Telefon", "600 000 000"), tx("e2", "Etykieta 2", "E-MAIL"), tx("v2", "E-mail", "kontakt@twojastrona.pl"), tx("e3", "Etykieta 3", "STRONA"), tx("v3", "Strona", "twojastrona.pl"), tx("opis", "Dopisek", "odpowiadamy w ciągu 24 godzin")],
    warstwy: [
      Z("logo", 390, 230, 300, 300, { dopasuj: "zawrzyj", we: W("pop", 0.05, 0.6, "sprezyna") }),
      T("tytul", 540, 620, { rozmiar: 110, font: "n", waga: 700, wyr: "srodek", we: W("maska-gora", 0.3, 0.7) }),
      ...["T", "@", "W"].flatMap((z, i) => [
        P(90, 850 + i * 220, 900, 180, "$g", { r: 30, we: W("lewo", 0.5 + i * 0.15, 0.6) }),
        K(180, 940 + i * 220, 46, "$a", { we: W("pop", 0.7 + i * 0.15, 0.5, "sprezyna") }),
        TL(z, 180, 919 + i * 220, { rozmiar: 46, font: "n", waga: 700, wyr: "srodek", kolor: "$tl", we: W("zanik", 0.8 + i * 0.15, 0.4) }),
        T("e" + (i + 1), 260, 890 + i * 220, { rozmiar: 24, font: "t", waga: 700, rozstaw: 200, kolor: "$d", maks: 700, we: W("zanik", 0.8 + i * 0.15, 0.4) }),
        T("v" + (i + 1), 260, 935 + i * 220, { rozmiar: 44, font: "t", waga: 700, maks: 690, we: W("zanik", 0.85 + i * 0.15, 0.4) }),
      ]),
      T("opis", 540, 1580, { rozmiar: 32, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.3, 0.6) }),
    ] }));

  // ======================= PORADY I LISTY =======================
  V([["po-checklista", "Lista do odhaczenia", "biel"], ["po-checklista-zolty", "Lista do odhaczenia, żółty", "zolty"]], () => ({ kat: "porady", czas: 9,
    pola: [tx("tytul", "Tytuł", "Przed nagraniem\nsprawdź:"), ...["Naładowana bateria", "Czysty obiektyw", "Wolne miejsce na karcie", "Światło od przodu", "Wyciszony telefon"].map((d, i) => tx("p" + (i + 1), "Punkt " + (i + 1), d)), tx("opis", "Podpis", "zapisz, żeby nie zapomnieć")],
    warstwy: [
      T("tytul", 90, 200, { rozmiar: 96, font: "n", waga: 700, interlinia: 1.0, szer: 900, we: W("maska-gora", 0.05, 0.8) }),
      ...[0, 1, 2, 3, 4].flatMap((i) => [
        P(90, 540 + i * 220, 96, 96, "$t", { r: 18, obrys: 5, we: W("zanik", 0.4 + i * 0.3, 0.4) }),
        L(110, 590 + i * 220, 132, 614 + i * 220, "$a", 9, { we: W("rysuj", 0.6 + i * 0.3, 0.15) }),
        L(132, 614 + i * 220, 172, 562 + i * 220, "$a", 9, { we: W("rysuj", 0.75 + i * 0.3, 0.2) }),
        T("p" + (i + 1), 230, 566 + i * 220, { rozmiar: 46, font: "t", waga: 600, maks: 780, we: W("lewo", 0.45 + i * 0.3, 0.5) }),
      ]),
      T("opis", 90, 1720, { rozmiar: 30, font: "t", kolor: "$d", we: W("zanik", 2.0, 0.6) }),
    ] }));
  V([["po-blad-rozwiazanie", "Błąd i rozwiązanie", "noc"]], () => ({ kat: "porady", czas: 9,
    pola: [tx("e1", "Etykieta 1", "BŁĄD"), tx("blad", "Błąd", "Nagrywanie pod światło", 2), tx("blad_op", "Co się dzieje", "Twarz wychodzi ciemna, a tło przepalone.", 2), tx("e2", "Etykieta 2", "ROZWIĄZANIE"), tx("rozw", "Rozwiązanie", "Stań twarzą do okna albo dodaj lampę z przodu.", 3)],
    warstwy: [
      P(0, 0, 1080, 950, "#EF4444", { krycie: 0.14, we: W("odkryj-dol", 0, 0.6) }),
      K(150, 270, 60, "#EF4444", { we: W("pop", 0.2, 0.5, "sprezyna") }),
      L(126, 246, 174, 294, BIA, 8, { we: W("rysuj", 0.4, 0.2) }), L(174, 246, 126, 294, BIA, 8, { we: W("rysuj", 0.5, 0.2) }),
      T("e1", 240, 240, { rozmiar: 50, font: "n", waga: 700, kolor: "#EF4444", we: W("lewo", 0.3, 0.5) }),
      T("blad", 90, 400, { rozmiar: 110, font: "n", waga: 700, szer: 900, interlinia: 1.02, we: W("maska-gora", 0.5, 0.8) }),
      T("blad_op", 90, 680, { rozmiar: 44, font: "t", szer: 900, interlinia: 1.35, kolor: "$d", we: W("gora", 0.8, 0.6) }),
      P(0, 970, 1080, 950, "#22C55E", { krycie: 0.14, we: W("odkryj-gora", 1.1, 0.6) }),
      K(150, 1230, 60, "#22C55E", { we: W("pop", 1.3, 0.5, "sprezyna") }),
      L(122, 1232, 143, 1255, BIA, 8, { we: W("rysuj", 1.5, 0.15) }), L(143, 1255, 180, 1208, BIA, 8, { we: W("rysuj", 1.6, 0.2) }),
      T("e2", 240, 1200, { rozmiar: 50, font: "n", waga: 700, kolor: "#22C55E", we: W("lewo", 1.4, 0.5) }),
      T("rozw", 90, 1360, { rozmiar: 74, font: "t", waga: 700, szer: 900, interlinia: 1.2, we: W("maska-gora", 1.6, 0.8) }),
    ] }));
  V([["po-dwie-kolumny", "Porównanie w dwóch kolumnach", "granat"]], () => ({ kat: "porady", czas: 9,
    pola: [tx("tytul", "Tytuł", "Co wybrać na start?"), tx("na", "Kolumna A", "TELEFON"), tx("nb", "Kolumna B", "APARAT"),
      ...["zawsze pod ręką", "szybki montaż w apce", "słabszy w nocy", "tani start"].map((d, i) => tx("a" + (i + 1), "A: punkt " + (i + 1), d)),
      ...["lepsza jakość obrazu", "wymienne obiektywy", "świetny w nocy", "większy koszt"].map((d, i) => tx("b" + (i + 1), "B: punkt " + (i + 1), d)), tx("wniosek", "Wniosek", "Na start wystarczy telefon")],
    warstwy: [
      T("tytul", 540, 170, { rozmiar: 90, font: "n", waga: 700, wyr: "srodek", we: W("maska-gora", 0.05, 0.7) }),
      P(60, 380, 450, 140, "$a", { r: 30, we: W("odkryj-lewo", 0.3, 0.5) }), T("na", 285, 418, { rozmiar: 70, font: "n", waga: 700, wyr: "srodek", maks: 400, kolor: "$tl", we: W("zanik", 0.4, 0.4) }),
      P(570, 380, 450, 140, "$g", { r: 30, we: W("odkryj-lewo", 0.4, 0.5) }), T("nb", 795, 418, { rozmiar: 70, font: "n", waga: 700, wyr: "srodek", maks: 400, we: W("zanik", 0.5, 0.4) }),
      L(540, 580, 540, 1620, "$d", 2, { krycie: 0.6, we: W("rysuj", 0.5, 1.0) }),
      ...[0, 1, 2, 3].flatMap((i) => [
        T("a" + (i + 1), 285, 620 + i * 250, { rozmiar: 40, font: "t", waga: 600, wyr: "srodek", szer: 420, interlinia: 1.25, we: W("lewo", 0.7 + i * 0.2, 0.5) }),
        T("b" + (i + 1), 795, 620 + i * 250, { rozmiar: 40, font: "t", waga: 600, wyr: "srodek", szer: 420, interlinia: 1.25, we: W("prawo", 0.75 + i * 0.2, 0.5) }),
      ]),
      P(60, 1680, 960, 130, "$g", { r: 65, we: W("pop", 1.6, 0.6, "sprezyna") }),
      T("wniosek", 540, 1724, { rozmiar: 42, font: "t", waga: 700, wyr: "srodek", maks: 880, kolor: "$a", we: W("zanik", 1.8, 0.4) }),
    ] }));

  // ======================= OPINIE I REKOMENDACJE =======================
  V([["op-srednia-ocena", "Średnia ocena z gwiazdkami", "biel"], ["op-srednia-ocena-noc", "Średnia ocena, ciemna", "noc"]], () => ({ kat: "opinie", czas: 8,
    pola: [tx("nad", "Nadtytuł", "OCENA KLIENTÓW"), tx("ocena", "Ocena (wpisz prawdziwą)", "4,9"), tx("z", "Pod oceną", "na 5 · wpisz liczbę opinii"), tx("opis", "Podpis", "Dziękujemy za każdą opinię!")],
    warstwy: [
      T("nad", 540, 330, { rozmiar: 30, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, kolor: "$d", we: W("zanik", 0.05, 0.6) }),
      T("ocena", 540, 420, { rozmiar: 320, font: "n", waga: 700, wyr: "srodek", we: W("licz", 0.2, 1.2) }),
      T("z", 540, 790, { rozmiar: 40, font: "t", waga: 500, wyr: "srodek", kolor: "$d", we: W("zanik", 0.8, 0.6) }),
      ...[0, 1, 2, 3, 4].map((i) => K(380 + i * 80, 930, 28, "#F5B301", { we: W("pop", 0.9 + i * 0.1, 0.4, "sprezyna") })),
      ...[0.86, 0.09, 0.03, 0.01, 0.01].flatMap((p, i) => [
        TL(String(5 - i), 170, 1060 + i * 90, { rozmiar: 36, font: "n", waga: 700, wyr: "srodek", kolor: "$d", we: W("zanik", 1.2 + i * 0.08, 0.4) }),
        P(220, 1072 + i * 90, 700, 26, "$g", { r: 13, we: W("zanik", 1.2 + i * 0.08, 0.4) }),
        P(220, 1072 + i * 90, Math.max(26, Math.round(700 * p)), 26, "#F5B301", { r: 13, we: W("odkryj-lewo", 1.3 + i * 0.08, 0.7) }),
      ]),
      T("opis", 540, 1600, { rozmiar: 40, font: "t", waga: 600, wyr: "srodek", szer: 860, we: W("gora", 1.8, 0.6) }),
    ] }));
  V([["op-wiadomosc", "Opinia jako wiadomość na czacie", "niebo"]], () => ({ kat: "opinie", czas: 9,
    pola: [zd("z1", "Zdjęcie klienta"), tx("nad", "Nadtytuł", "WIADOMOŚĆ OD KLIENTA"), tx("m1", "Wiadomość 1", "Dzień dobry! Chciałam tylko podziękować.", 2), tx("m2", "Wiadomość 2 (wpisz prawdziwą)", "Wpisz tu prawdziwą wiadomość, którą dostałeś od klienta.", 3), tx("m3", "Twoja odpowiedź", "Dziękujemy, to dla nas wiele znaczy!", 2), tx("podpis", "Podpis", "prawdziwe wiadomości od naszych klientów")],
    warstwy: [
      T("nad", 540, 330, { rozmiar: 30, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, kolor: "$a", we: W("zanik", 0.05, 0.6) }),
      Zp("z1", 80, 700, 120, 120, { maska: "kolo", we: W("pop", 0.2, 0.5, "sprezyna") }),
      P(230, 510, 770, 230, "$g", { r: 40, we: W("lewo", 0.3, 0.5) }),
      T("m1", 270, 555, { rozmiar: 44, font: "t", waga: 500, szer: 690, interlinia: 1.3, we: W("zanik", 0.4, 0.4) }),
      P(230, 770, 770, 310, "$g", { r: 40, we: W("lewo", 0.8, 0.5) }),
      T("m2", 270, 815, { rozmiar: 44, font: "t", waga: 500, szer: 690, interlinia: 1.3, we: W("zanik", 0.9, 0.4) }),
      P(240, 1160, 760, 230, "$a", { r: 40, we: W("prawo", 1.4, 0.5) }),
      T("m3", 280, 1205, { rozmiar: 44, font: "t", waga: 600, szer: 680, interlinia: 1.3, kolor: "$g", we: W("zanik", 1.5, 0.4) }),
      T("podpis", 540, 1620, { rozmiar: 30, font: "t", wyr: "srodek", szer: 860, kolor: "$d", we: W("zanik", 1.8, 0.6) }),
    ] }));
  V([["op-trzy-opinie", "Trzy krótkie opinie", "piasek"]], () => ({ kat: "opinie", czas: 9,
    pola: [tx("tytul", "Tytuł", "Co mówią\nklienci"), ...[1, 2, 3].flatMap((i) => [tx("o" + i, "Opinia " + i + " (wpisz prawdziwą)", "Wpisz tu krótką, prawdziwą opinię klienta.", 2), tx("a" + i, "Autor " + i, "— Imię N.")])],
    warstwy: [
      T("tytul", 90, 150, { rozmiar: 100, font: "n", waga: 700, interlinia: 1.0, we: W("maska-gora", 0.05, 0.8) }),
      ...[0, 1, 2].flatMap((i) => [
        P(60, 440 + i * 450, 960, 400, "$g", { r: 30, we: W("gora", 0.4 + i * 0.3, 0.6) }),
        ...[0, 1, 2, 3, 4].map((j) => K(130 + j * 48, 510 + i * 450, 16, "#F5B301", { we: W("pop", 0.6 + i * 0.3 + j * 0.05, 0.3) })),
        T("o" + (i + 1), 110, 570 + i * 450, { rozmiar: 44, font: "t", waga: 600, szer: 860, interlinia: 1.3, we: W("zanik", 0.6 + i * 0.3, 0.5) }),
        T("a" + (i + 1), 110, 740 + i * 450, { rozmiar: 30, font: "t", waga: 700, kolor: "$a", we: W("zanik", 0.7 + i * 0.3, 0.5) }),
      ]),
    ] }));
  // <<< wersja 18

  return { SZABLONY, KATEGORIE, BAZA: [BW, BH], dodaj, znajdz, rysuj, czas, doAE, stan, zastepcze,
    ustawFabryke: (f) => { fabryka = f; }, pomoc: { W, P, K, TR, L, C, Z, T, TL, zd, tx, lg, CIEMNE, JASNE, BIALE } };
});
