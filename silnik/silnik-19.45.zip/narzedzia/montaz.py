"""Montaż rolki z planu (plan.json): sceny + lektor + napisy słowo po słowie + logo + plansza końcowa + muzyka.

Użycie:
  python narzedzia/montaz.py zloz --plan wyniki/X/plan.json
  python narzedzia/montaz.py klatki --plik wyniki/X/rolka.mp4 [--ile 5]     (kadry do sprawdzenia)

Przykładowy plan.json (ścieżki względem folderu silnika albo bezwzględne):
{
  "folder_klienta": "klienci/instytut-edukacji-finansowej",
  "wyjscie": "wyniki/2026-10-20_ABCD_czym-jest-etf/rolka.mp4",
  "format": [1080, 1920], "fps": 30,
  "lektor": "wyniki/.../lektor.mp3",
  "slowa": "wyniki/.../slowa.json",
  "dopasuj_do_lektora": true,            // rozciąga sceny tak, żeby trwały tyle co lektor
  "sceny": [
    {"plik": "wyniki/.../sceny/s1.mp4", "czas": 3.5, "start": 0},
    {"plik": "wyniki/.../sceny/s2.png", "czas": 3, "ruch": "przybliz", "przejscie": "zoom-in"}
  ],
  "napisy": { styl napisów ze Studio (zadanie.napisy), opis pól na górze narzedzia/napisy.py },   // false = bez napisów
  "logo": {"plik": "klienci/.../logo.png", "szerokosc": 220, "pozycja": "gora"},
  "plansza_koncowa": {"tekst": "Zainwestuj w swoją przyszłość", "przycisk": "Dowiedz się więcej", "czas": 2.5,
                      "tlo": "#0B1F3A", "kolor_tekstu": "#FFFFFF", "kolor_przycisku": "#22C55E", "kolor_tekstu_przycisku": "#0B1F3A"},
  "muzyka": {"plik": "muzyka/podklad.mp3", "glosnosc": 0.18, "start": 0},   // start = od której sekundy utworu
  "premiere": true                       // dodatkowo timeline do Premiere (folder premiere/ obok rolki)
}

Ruch kamery w scenie ("ruch"): brak, przybliz, oddal, pan-prawo, pan-lewo, pan-gora, pan-dol (obrazy i wideo).
Przejście DO sceny ("przejscie", opcjonalnie "przejscie_czas" w s): ciecie (domyślnie), zoom-in, zoom-out,
  whip-lewo, whip-prawo, whip-gora, whip-dol, smuga-lewo, smuga-prawo, fade, przenikanie, czern, flash,
  kolo, rozmycie, pixel, zoom-przenikanie. To samo pole działa w "plansza_koncowa".
Nakładki (animacje z narzedzia/animacje.py, szablony z narzedzia/szablony.py): "nakladki": [{"plik": "wyniki/.../napis.mov", "czas": 2.4}]
  (czas na osi rolki; MOV z przezroczystością kładzie się na obraz, MP4 zasłania całość, np. plansza ze szablonu).
Efekty dźwiękowe: "efekty_dzwiekowe": [{"plik": "wyniki/.../whoosh.wav", "czas": 3.2, "glosnosc": 0.6}] (czas na osi rolki).
  "efekty_auto": true dokłada samo whoosh/swish/błysk przy dynamicznych przejściach (narzedzia/efekty.py; pliki z
  muzyka/efekty/ mają pierwszeństwo przed wbudowanymi z narzedzia/dzwieki/), "efekty_glosnosc": 0.25 (domyślnie, ledwo słyszalne) mnoży ich głośność.
Napisy SRT obok rolki i w premiere/: tylko przy "srt": true (domyślnie brak, żeby nie było podwójnych napisów).

Własne nagrania (pola sceny):
  "start": 12.4, "czas": 3.2      fragment klipu od 12,4 s, długości 3,2 s (dokładnie, bez rozciągania)
  "dzwiek": true                   zostaw oryginalny dźwięk fragmentu (np. gadająca głowa); "glosnosc": 1.0
  "slowa": "nagrania/x/_analiza/C0001_slowa.json"   napisy słowo po słowie z mowy w nagraniu
  "napisy_wlasne": [{"tekst": "Hej, to ja", "od": 0.2, "do": 1.4}]   gotowe linie (np. tłumaczenie), czasy względem sceny
  "dzwiek_z": {"plik": "nagrania/x/C0001.MP4", "start": 15.2}   obraz z tej sceny (np. przebitka), a dźwięk i napisy
                                   z innego klipu: mowa leci dalej pod przebitką; wymaga "dzwiek": true
Przy scenach z "dzwiek": true ustaw "dopasuj_do_lektora": false.
"""
import argparse
import json
import math
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, wynik  # noqa: E402
import fonty  # noqa: E402

ROZSZ_OBRAZ = {".png", ".jpg", ".jpeg", ".webp"}


def sciezka(p):
    if not p:
        return None
    p = Path(p)
    return p if p.is_absolute() else (KATALOG_SILNIKA / p)


def ffmpeg(args, cwd=None, opis="ffmpeg"):
    if not shutil.which("ffmpeg"):
        blad("Nie znaleziono ffmpeg. Zainstaluj: winget install Gyan.FFmpeg, potem zamknij i otwórz terminal.")
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *map(str, args)], cwd=cwd, capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        blad(f"{opis} nie powiódł się:\n{r.stderr[-1500:]}")


def dlugosc(plik):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(plik)], capture_output=True, text=True, encoding="utf-8", errors="replace")
    try:
        return float(r.stdout.strip())
    except ValueError:
        return 0.0


def hex_rgb(h, dom=(255, 255, 255)):
    h = (h or "").lstrip("#")
    if len(h) != 6:
        return dom
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def ass_kolor(h):
    r, g, b = hex_rgb(h)
    return f"&H00{b:02X}{g:02X}{r:02X}"


# ---------- sceny ----------
def scena_wideo(wej, wyj, czas, W, H, fps, start=0.0):
    vf = f"scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},fps={fps},setsar=1,format=yuv420p"
    ffmpeg(["-ss", f"{start:.3f}", "-stream_loop", "-1", "-i", wej, "-t", f"{czas:.3f}", "-vf", vf, "-an",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-r", fps, wyj], opis=f"scena {Path(wej).name}")


def scena_obraz(wej, wyj, czas, W, H, fps, ruch="przybliz"):
    klatki = max(1, int(round(czas * fps)))
    zakres = 0.12
    if ruch == "oddal":
        z = f"{1 + zakres}-{zakres}*on/{klatki}"
    elif ruch == "brak":
        z = "1"
    else:
        z = f"1+{zakres}*on/{klatki}"
    vf = (f"scale={W * 2}:{H * 2}:force_original_aspect_ratio=increase,crop={W * 2}:{H * 2},"
          f"zoompan=z='{z}':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s={W}x{H}:fps={fps},setsar=1,format=yuv420p")
    ffmpeg(["-loop", "1", "-framerate", fps, "-i", wej, "-frames:v", klatki, "-vf", vf,
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-r", fps, wyj], opis=f"obraz {Path(wej).name}")


# ---------- ruch kamery i przejścia ----------
RUCHY = {"brak", "przybliz", "oddal", "pan-prawo", "pan-lewo", "pan-gora", "pan-dol"}
# przejście -> (filtr xfade, domyślny czas w s); te działają przez nakładkę dwóch ujęć
PRZEJSCIA_XFADE = {
    "fade": ("fade", 0.4), "przenikanie": ("dissolve", 0.4), "czern": ("fadeblack", 0.5), "flash": ("fadewhite", 0.3),
    "whip-lewo": ("slideleft", 0.25), "whip-prawo": ("slideright", 0.25), "whip-gora": ("slideup", 0.25),
    "whip-dol": ("slidedown", 0.25), "smuga-lewo": ("smoothleft", 0.35), "smuga-prawo": ("smoothright", 0.35),
    "kolo": ("circleopen", 0.4), "rozmycie": ("hblur", 0.3), "pixel": ("pixelize", 0.4), "zoom-przenikanie": ("zoomin", 0.35),
}
# te robią ruch na krawędziach ujęć (bez nakładki), jak presety „zoom transition”
PRZEJSCIA_KRAWEDZ = {"zoom-in", "zoom-out"}


def wyrazenia_ruchu(N, ruch, wej_kraw, wyj_kraw, fps):
    """Wyrażenia zoompan (z, x, y) dla ujęcia o N klatkach głównych."""
    # ruch kamery: pół liniowy, pół „miękki start i hamowanie” (bez mechanicznego stałego tempa), mniejszy zakres niż dawniej
    L = f"(min(on,{N})/{N})"
    P = f"(0.5*{L}+0.5*(0.5-0.5*cos(PI*{L})))"
    baza = {"brak": "1", "przybliz": f"(1+0.08*{P})", "oddal": f"(1.08-0.08*{P})"}.get(ruch, "1.12")
    z = baza
    k = max(2, round(0.22 * fps))
    if wyj_kraw == "zoom-in":
        z += f"*if(gte(on,{N - k}),1+0.8*pow(min((on-{N - k})/{k},1),2),1)"
    if wej_kraw == "zoom-in":
        z += f"*if(lt(on,{k}),1+0.8*pow(1-on/{k},2),1)"
    if wej_kraw == "zoom-out":
        k2 = max(3, round(0.4 * fps))
        z += f"*if(lt(on,{k2}),1+0.6*pow(1-on/{k2},3),1)"
    x = "iw/2-(iw/zoom/2)"
    y = "ih/2-(ih/zoom/2)"
    if ruch == "pan-prawo":
        x = f"(iw-iw/zoom)*{P}"
    elif ruch == "pan-lewo":
        x = f"(iw-iw/zoom)*(1-{P})"
    elif ruch == "pan-gora":
        y = f"(ih-ih/zoom)*(1-{P})"
    elif ruch == "pan-dol":
        y = f"(ih-ih/zoom)*{P}"
    return z, x, y


def scena(wej, wyj, czas, ekstra, W, H, fps, start=0.0, ruch="brak", wej_kraw=None, wyj_kraw=None):
    """Renderuje ujęcie: czas główny + ekstra (zapas na przejście). Obrazy i wideo, z ruchem kamery."""
    wej = Path(wej)
    obraz = wej.suffix.lower() in ROZSZ_OBRAZ
    N = max(1, round(czas * fps))
    # zapas na przejście + 1 klatka: xfade przerywa się, gdy pierwsze ujęcie kończy się dokładnie z końcem przejścia
    N_calosc = N + (round(ekstra * fps) + 1 if ekstra > 0 else 0)
    ruch = ruch if ruch in RUCHY else "brak"
    if not obraz and ruch == "brak" and not wej_kraw and not wyj_kraw:
        vf = f"fps={fps},scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},setsar=1,format=yuv420p"
        ffmpeg(["-ss", f"{start:.3f}", "-stream_loop", "-1", "-i", wej, "-frames:v", N_calosc, "-vf", vf, "-an",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-r", fps, wyj], opis=f"scena {wej.name}")
        return
    skala = 2 if obraz else 1.5
    SW, SH = int(W * skala) // 2 * 2, int(H * skala) // 2 * 2
    z, x, y = wyrazenia_ruchu(N, ruch, wej_kraw, wyj_kraw, fps)
    zp = f"zoompan=z='{z}':x='{x}':y='{y}':d=1:s={W}x{H}:fps={fps}"
    if obraz:
        wejscie = ["-loop", "1", "-framerate", fps, "-i", wej]
        vf = f"scale={SW}:{SH}:force_original_aspect_ratio=increase,crop={SW}:{SH},{zp},setsar=1,format=yuv420p"
    else:
        wejscie = ["-ss", f"{start:.3f}", "-stream_loop", "-1", "-i", wej]
        vf = f"fps={fps},scale={SW}:{SH}:force_original_aspect_ratio=increase,crop={SW}:{SH},{zp},setsar=1,format=yuv420p"
    ffmpeg([*wejscie, "-frames:v", N_calosc, "-vf", vf, "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "17", "-r", fps, wyj],
           opis=f"scena {wej.name}")


def sklej_z_przejsciami(klipy, poczatki, przejscia, wyj, fps):
    """Łączy ujęcia filtrem xfade; przejscia[i] dotyczy wejścia w ujęcie i (i>=1): (filtr, czas) albo None = cięcie."""
    wejscia, filtry = [], []
    for k in klipy:
        wejscia += ["-i", k]
    poprz = "[0:v]"
    for i in range(1, len(klipy)):
        filtr, d = przejscia[i] or ("fade", 1.0 / fps)
        filtry.append(f"{poprz}[{i}:v]xfade=transition={filtr}:duration={d:.3f}:offset={poczatki[i]:.3f}[x{i}]")
        poprz = f"[x{i}]"
    ffmpeg([*wejscia, "-filter_complex", ";".join(filtry), "-map", poprz, "-c:v", "libx264", "-preset", "veryfast",
            "-crf", "17", "-pix_fmt", "yuv420p", "-r", fps, wyj], opis="przejścia między ujęciami")


# ---------- plansza końcowa ----------
def zawin(tekst, font, max_szer, rysunek):
    slowa, linie, biez = tekst.split(), [], ""
    for s in slowa:
        proba = (biez + " " + s).strip()
        if rysunek.textlength(proba, font=font) <= max_szer:
            biez = proba
        else:
            if biez:
                linie.append(biez)
            biez = s
    if biez:
        linie.append(biez)
    return linie


def plansza_png(cfg, W, H, font_plik, logo, wyj):
    from PIL import Image, ImageDraw, ImageFont

    tlo = hex_rgb(cfg.get("tlo"), (15, 23, 42))
    B = min(W, int(H * 1.25))  # baza wielkości: w poziomie liczona od wysokości
    img = Image.new("RGB", (W, H), tlo)
    d = ImageDraw.Draw(img)
    y = int(H * 0.30)
    if logo and Path(logo).exists():
        lg = Image.open(logo).convert("RGBA")
        sz = int(B * 0.42)
        lg.thumbnail((sz, int(H * 0.14)))
        img.paste(lg, ((W - lg.width) // 2, int(H * 0.30) - lg.height - 60), lg)
    rozmiar = int(B * 0.085)
    font = ImageFont.truetype(font_plik, rozmiar) if font_plik else ImageFont.load_default()
    linie = zawin(cfg.get("tekst", ""), font, min(W * 0.84, B * 1.1), d)
    kol = hex_rgb(cfg.get("kolor_tekstu"), (255, 255, 255))
    for linia in linie:
        w = d.textlength(linia, font=font)
        d.text(((W - w) / 2, y), linia, font=font, fill=kol)
        y += int(rozmiar * 1.18)
    if cfg.get("przycisk"):
        fb = ImageFont.truetype(font_plik, int(B * 0.05)) if font_plik else font
        tw = d.textlength(cfg["przycisk"], font=fb)
        bw, bh = tw + B * 0.14, B * 0.13
        bx, by = (W - bw) / 2, y + H * 0.05
        d.rounded_rectangle([bx, by, bx + bw, by + bh], radius=bh / 2, fill=hex_rgb(cfg.get("kolor_przycisku"), (34, 197, 94)))
        bbox = d.textbbox((0, 0), cfg["przycisk"], font=fb)
        d.text((bx + (bw - tw) / 2, by + (bh - (bbox[3] - bbox[1])) / 2 - bbox[1]), cfg["przycisk"], font=fb,
               fill=hex_rgb(cfg.get("kolor_tekstu_przycisku"), (15, 23, 42)))
    img.save(wyj)


# ---------- napisy ----------
# Napisy rysuje narzedzia/napisy.py (styl jak w Submagic); tu zostaje tylko zgodność nazw.
from napisy import zapisz_srt  # noqa: E402,F401


# ---------- składanie ----------
def zloz(plan_plik):
    plan_plik = sciezka(plan_plik)
    plan = json.loads(Path(plan_plik).read_text(encoding="utf-8"))
    W, H = plan.get("format", [1080, 1920])
    fps = int(plan.get("fps", 30))
    wyjscie = sciezka(plan["wyjscie"])
    if "efekty_auto" not in plan:
        # zadanie z panelu (aftermovie) mówi, czy chcesz efekty przy przejściach: wtedy nie zależy to od planu mózgu
        for zj in (Path(plan_plik).parent / "zadanie_panel.json", Path(plan_plik).parent / "zadanie.json",
                   wyjscie.parent / "zadanie_panel.json", wyjscie.parent / "zadanie.json"):
            try:
                zd = json.loads(zj.read_text(encoding="utf-8-sig"))
                zd = zd.get("zadanie", zd) if isinstance(zd, dict) else {}
                if isinstance(zd, dict) and isinstance(zd.get("efekty_dzwiekowe"), bool):
                    plan["efekty_auto"] = bool(zd["efekty_dzwiekowe"])
                    break
            except Exception:
                pass
    roboczy = wyjscie.parent / "_robocze"
    roboczy.mkdir(parents=True, exist_ok=True)
    folder_kl = sciezka(plan.get("folder_klienta")) if plan.get("folder_klienta") else None
    fonty_kl = (folder_kl / "fonty") if folder_kl else roboczy

    lektor = sciezka(plan.get("lektor"))
    if lektor and not lektor.exists():
        blad(f"Brak pliku lektora: {lektor}")
    dl_lektora = dlugosc(lektor) if lektor else 0.0

    sceny = plan.get("sceny") or []
    if not sceny:
        blad("Plan nie ma scen")
    for s in sceny:
        if not sciezka(s["plik"]).exists():
            blad(f"Brak pliku sceny: {s['plik']}")
    czasy = [float(s.get("czas", 3)) for s in sceny]
    if lektor and plan.get("dopasuj_do_lektora", True):
        cel = dl_lektora + 0.35
        k = cel / sum(czasy)
        czasy = [c * k for c in czasy]
    # czasy dokładnie w klatkach, żeby obraz, dźwięk, napisy i przejścia trafiały co do klatki
    czasy = [max(1, round(c * fps)) / fps for c in czasy]

    # 1. lista ujęć (sceny + plansza) i przejścia między nimi
    pk = plan.get("plansza_koncowa")
    font_naglowka = fonty.znajdz(fonty_kl, (plan.get("napisy") or {}).get("font"), gruby=True)
    logo = sciezka((plan.get("logo") or {}).get("plik"))
    elementy = []
    for i, (s_, czas) in enumerate(zip(sceny, czasy)):
        wej = sciezka(s_["plik"])
        domyslny = ("przybliz" if i % 2 == 0 else "oddal") if wej.suffix.lower() in ROZSZ_OBRAZ else "brak"
        elementy.append({"plik": wej, "czas": czas, "start": float(s_.get("start", 0)), "ruch": s_.get("ruch", domyslny),
                         "przejscie": s_.get("przejscie"), "przejscie_czas": s_.get("przejscie_czas")})
    czas_planszy = 0.0
    if pk and pk.get("tekst"):
        czas_planszy = max(1, round(float(pk.get("czas", 2.5)) * fps)) / fps
        png = roboczy / "plansza.png"
        plansza_png(pk, W, H, font_naglowka, logo, png)
        elementy.append({"plik": png, "czas": czas_planszy, "start": 0.0, "ruch": "brak",
                         "przejscie": pk.get("przejscie"), "przejscie_czas": pk.get("przejscie_czas")})
    przejscia = [None] * len(elementy)
    for i in range(1, len(elementy)):
        nazwa = elementy[i]["przejscie"]
        if nazwa in PRZEJSCIA_XFADE:
            filtr, d = PRZEJSCIA_XFADE[nazwa]
            d = float(elementy[i]["przejscie_czas"] or d)
            d = min(d, elementy[i - 1]["czas"] * 0.8, elementy[i]["czas"] * 0.8)
            przejscia[i] = (filtr, max(1, round(d * fps)) / fps)
    tryb_xfade = any(przejscia)
    poczatki_el = [sum(e["czas"] for e in elementy[:i]) for i in range(len(elementy))]

    # 2. render ujęć (z zapasem na przejście i ruchem kamery)
    klipy = []
    for i, e in enumerate(elementy):
        ekstra = 0.0
        if i + 1 < len(elementy) and tryb_xfade:
            ekstra = przejscia[i + 1][1] if przejscia[i + 1] else 1.0 / fps
        wej_k = e["przejscie"] if e["przejscie"] in PRZEJSCIA_KRAWEDZ and i > 0 else None
        wyj_k = "zoom-in" if i + 1 < len(elementy) and elementy[i + 1]["przejscie"] == "zoom-in" else None
        wyj = roboczy / f"s{i:02d}.mp4"
        scena(e["plik"], wyj, e["czas"], ekstra, W, H, fps, e["start"], e["ruch"], wej_k, wyj_k)
        klipy.append(wyj)

    # 3. sklejenie obrazu
    baza = roboczy / "baza.mp4"
    if tryb_xfade:
        sklej_z_przejsciami(klipy, poczatki_el, przejscia, baza, fps)
    else:
        lista = roboczy / "lista.txt"
        lista.write_text("".join(f"file '{k.as_posix()}'\n" for k in klipy), encoding="utf-8")
        ffmpeg(["-f", "concat", "-safe", "0", "-i", lista, "-c", "copy", baza], opis="sklejanie scen")
    calosc = dlugosc(baza)
    koniec_tresci = calosc - czas_planszy

    # 4. napisy (pliki obok siebie, żeby ścieżki w filtrze nie miały dwukropków z Windows)
    poczatki = [sum(czasy[:i]) for i in range(len(czasy))]
    slowa_wszystkie, linie_wlasne = [], []
    przes = float(plan.get("przesuniecie_napisow", 0))
    slowa_plik = sciezka(plan.get("slowa"))
    if slowa_plik and slowa_plik.exists():
        slowa_wszystkie += [{**w, "start": w["start"] + przes, "koniec": w["koniec"] + przes}
                            for w in json.loads(slowa_plik.read_text(encoding="utf-8"))]
    for i, (s_, czas) in enumerate(zip(sceny, czasy)):
        st = float((s_.get("dzwiek_z") or {}).get("start", s_.get("start", 0)))
        if s_.get("slowa") and sciezka(s_["slowa"]).exists():
            pierwsza = True
            for w in json.loads(sciezka(s_["slowa"]).read_text(encoding="utf-8")):
                if w["start"] >= st - 0.05 and w["koniec"] <= st + czas + 0.1:
                    slowa_wszystkie.append({"slowo": w["slowo"], "start": max(0.0, w["start"] - st) + poczatki[i],
                                            "koniec": min(czas, w["koniec"] - st) + poczatki[i], "nowa": pierwsza})
                    pierwsza = False
        for l in s_.get("napisy_wlasne") or []:
            linie_wlasne.append({"tekst": l["tekst"], "od": poczatki[i] + float(l["od"]), "do": poczatki[i] + float(l["do"])})
    slowa_wszystkie.sort(key=lambda w: w["start"])
    napisy_nakl = None
    styl_napisow = plan.get("napisy")
    if styl_napisow is not False and (slowa_wszystkie or linie_wlasne):
        import napisy as napisy_mod
        styl = napisy_mod.wczytaj_styl(styl_napisow or {})
        if not (styl_napisow or {}).get("font") and font_naglowka:
            styl["font"] = fonty.rodzina(font_naglowka)
        slowa_n = sorted(slowa_wszystkie + napisy_mod.slowa_z_linii(linie_wlasne), key=lambda w: w["start"])
        napisy_nakl = napisy_mod.nakladka(slowa_n, styl, W, H, fps, roboczy / "napisy", koniec_tresci, fonty_kl)
        napisy_mod.zapisz_srt(napisy_nakl["srt"], roboczy / "napisy.srt")

    # 4b. oryginalny dźwięk scen (własne nagrania)
    dzwiek_scen = None
    if any(s_.get("dzwiek") for s_ in sceny):
        kawalki = []
        for i, (s_, czas) in enumerate(zip(sceny, czasy)):
            cel = roboczy / f"a{i:02d}.wav"
            zrodlo = s_.get("dzwiek_z") or {}
            wej = sciezka(zrodlo.get("plik") or s_["plik"])
            st_a = float(zrodlo.get("start", s_.get("start", 0)))
            ma_audio = s_.get("dzwiek") and wej.suffix.lower() not in ROZSZ_OBRAZ and subprocess.run(
                ["ffprobe", "-v", "error", "-select_streams", "a", "-show_entries", "stream=index", "-of", "csv=p=0", str(wej)],
                capture_output=True, text=True, encoding="utf-8", errors="replace").stdout.strip() != ""
            if ma_audio:
                g = float(s_.get("glosnosc", 1.0))
                ffmpeg(["-ss", f"{st_a:.3f}", "-i", wej, "-t", f"{czas:.3f}", "-vn", "-ac", 2, "-ar", 48000,
                        "-af", f"volume={g},afade=t=in:d=0.03,afade=t=out:st={max(0, czas - 0.05):.3f}:d=0.05,apad,atrim=0:{czas:.3f}",
                        "-c:a", "pcm_s16le", cel], opis=f"dźwięk sceny {i + 1}")
            else:
                ffmpeg(["-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-t", f"{czas:.3f}", "-c:a", "pcm_s16le", cel], opis="cisza")
            kawalki.append(cel)
        if czas_planszy:
            cel = roboczy / "a_plansza.wav"
            ffmpeg(["-f", "lavfi", "-i", "anullsrc=r=48000:cl=stereo", "-t", f"{czas_planszy:.3f}", "-c:a", "pcm_s16le", cel], opis="cisza")
            kawalki.append(cel)
        lista_a = roboczy / "lista_audio.txt"
        lista_a.write_text("".join(f"file '{k.as_posix()}'\n" for k in kawalki), encoding="utf-8")
        dzwiek_scen = roboczy / "dzwiek_scen.wav"
        ffmpeg(["-f", "concat", "-safe", "0", "-i", lista_a, "-c", "copy", dzwiek_scen], opis="sklejanie dźwięku scen")

    # 5. finał: logo + napisy + dźwięk
    wejscia = ["-i", baza]
    nr = 1
    filtry = []
    v = "[0:v]"
    if logo and logo.exists():
        lcfg = plan.get("logo") or {}
        szer = int(lcfg.get("szerokosc", round(W * 0.16)))
        # poza paskiem aplikacji u góry (14%) i poza opisem u dołu (25%)
        y = int(H * 0.15) if lcfg.get("pozycja", "gora") == "gora" else int(H * 0.68)
        wejscia += ["-i", logo]
        filtry.append(f"[{nr}:v]scale={szer}:-1[lg]")
        filtry.append(f"{v}[lg]overlay=(W-w)/2:{y}:enable='lt(t,{koniec_tresci:.2f})'[vl]")
        v = "[vl]"
        nr += 1
    # animacje i szablony nałożone na film (MOV z przezroczystością albo MP4 na całą klatkę)
    for k, nk in enumerate(plan.get("nakladki") or []):
        pl = sciezka(nk.get("plik"))
        if not pl or not pl.exists():
            continue
        wejscia += (["-c:v", "libvpx-vp9"] if pl.suffix.lower() == ".webm" else []) + ["-i", pl]  # dekoder VP9 z przezroczystością
        t0 = float(nk.get("czas", 0))
        filtry.append(f"[{nr}:v]scale={W}:{H}:force_original_aspect_ratio=decrease,format=rgba,setpts=PTS-STARTPTS+{t0:.3f}/TB[nk{k}]")
        filtry.append(f"{v}[nk{k}]overlay=(W-w)/2:(H-h)/2:eof_action=pass:format=auto[vn{k}]")
        v = f"[vn{k}]"
        nr += 1
    if napisy_nakl:
        wejscia += ["-f", "concat", "-safe", "0", "-i", (Path("napisy") / "lista.txt").as_posix()]
        filtry.append(f"{v}[{nr}:v]overlay=0:{napisy_nakl['y']}:eof_action=pass:format=auto[vout]")
        nr += 1
    else:
        filtry.append(f"{v}null[vout]")

    glosy = []  # wejścia z mową: lektor i/lub oryginalny dźwięk scen
    if lektor:
        wejscia += ["-i", lektor]
        glosy.append(nr)
        nr += 1
    if dzwiek_scen:
        wejscia += ["-i", dzwiek_scen]
        glosy.append(nr)
        nr += 1
    muz = plan.get("muzyka") or {}
    muz_plik = sciezka(muz.get("plik"))
    nr_m = None
    if muz_plik and muz_plik.exists():
        wejscia += ["-ss", f"{float(muz.get('start', 0)):.3f}", "-stream_loop", "-1", "-i", muz_plik]
        nr_m = nr
        nr += 1
    a_out = None
    zanik = max(0.0, calosc - 1.2)
    norm = "loudnorm=I=-14:TP=-1.5:LRA=11,aresample=48000,asetpts=N/SR/TB"
    fmt = "aformat=sample_rates=48000:channel_layouts=stereo"
    if glosy:
        for j, n in enumerate(glosy):
            filtry.append(f"[{n}:a]{fmt},apad,atrim=0:{calosc:.2f}[g{j}]")
        if len(glosy) > 1:
            filtry.append("".join(f"[g{j}]" for j in range(len(glosy))) + f"amix=inputs={len(glosy)}:duration=first:normalize=0[glos]")
        else:
            filtry.append("[g0]anull[glos]")
        if nr_m is not None:
            g = float(muz.get("glosnosc", 0.18))
            filtry.append("[glos]asplit=2[gl1][gl2]")
            filtry.append(f"[{nr_m}:a]{fmt},atrim=0:{calosc:.2f},volume={g},afade=t=out:st={zanik:.2f}:d=1.2[mz]")
            filtry.append("[mz][gl2]sidechaincompress=threshold=0.03:ratio=6:attack=20:release=400[mzd]")
            filtry.append(f"[gl1][mzd]amix=inputs=2:duration=first:normalize=0,{norm}[amain]")
        else:
            filtry.append(f"[glos]{norm}[amain]")
        a_out = "[amain]"
    elif nr_m is not None:
        filtry.append(f"[{nr_m}:a]{fmt},atrim=0:{calosc:.2f},volume={muz.get('glosnosc', 0.5)},afade=t=out:st={zanik:.2f}:d=1.2[amain]")
        a_out = "[amain]"

    efekty = [e for e in (plan.get("efekty_dzwiekowe") or []) if sciezka(e.get("plik")) and sciezka(e["plik"]).exists()]
    if plan.get("efekty_auto"):
        # whoosh, swish i błysk przy dynamicznych przejściach (biblioteka narzedzia/dzwieki/ albo pliki z muzyka/efekty/)
        import efekty as efekty_mod
        prz_auto = [{"rodzaj": elementy[i]["przejscie"], "czas": poczatki_el[i],
                     "d": przejscia[i][1] if przejscia[i] else 0.0} for i in range(1, len(elementy)) if elementy[i]["przejscie"]]
        dodane = efekty_mod.auto_efekty(prz_auto, calosc, glosnosc_mnoznik=float(plan.get("efekty_glosnosc", 0.25)),
                                        juz=[float(e.get("czas", 0)) for e in efekty])
        efekty += dodane
        if dodane:
            print(f"[montaż] efekty dźwiękowe przy przejściach: {len(dodane)}", file=sys.stderr)
    if efekty:
        etyk = []
        for j, e in enumerate(efekty):
            wejscia += ["-i", sciezka(e["plik"])]
            ms = int(float(e.get("czas", 0)) * 1000)
            filtry.append(f"[{nr}:a]{fmt},volume={float(e.get('glosnosc', 0.6))},adelay={ms}|{ms},apad,atrim=0:{calosc:.2f}[e{j}]")
            etyk.append(f"[e{j}]")
            nr += 1
        wszystkie = ([a_out] if a_out else []) + etyk
        filtry.append("".join(wszystkie) + f"amix=inputs={len(wszystkie)}:duration=first:normalize=0,alimiter=limit=0.95[aout]")
        a_out = "[aout]"
    elif a_out:
        filtry.append(f"{a_out}anull[aout]")
        a_out = "[aout]"

    wyjscie.parent.mkdir(parents=True, exist_ok=True)
    args = [*wejscia, "-filter_complex", ";".join(filtry), "-map", "[vout]"]
    if a_out:
        args += ["-map", a_out, "-c:a", "aac", "-b:a", "192k", "-ar", "48000"]
    args += ["-c:v", "libx264", "-preset", "medium", "-crf", "19", "-pix_fmt", "yuv420p", "-r", fps,
             "-t", f"{calosc:.2f}", "-movflags", "+faststart", wyjscie.resolve()]
    ffmpeg(args, cwd=roboczy, opis="montaż końcowy")

    # 6. lżejsza wersja do wgrania na stronę Studio (limit 20 MB)
    podglad = None
    rozmiar_mb = wyjscie.stat().st_size / 1e6
    if rozmiar_mb > 19:
        podglad = wyjscie.with_name(wyjscie.stem + "_podglad.mp4")
        kbps = int(17.5 * 8000 / calosc) - 128
        ffmpeg(["-i", wyjscie, "-c:v", "libx264", "-b:v", f"{kbps}k", "-maxrate", f"{kbps}k", "-bufsize", f"{kbps * 2}k",
                "-c:a", "aac", "-b:a", "128k", "-movflags", "+faststart", podglad], opis="wersja podglądowa")

    # 7. oś czasu do eksportu (Premiere) i napisy SRT obok rolki (tylko przy "srt": true; domyślnie nie,
    #    bo odtwarzacze i Premiere doczytują SRT jako drugie, zwykłe napisy obok wypalonych)
    srt_rob = roboczy / "napisy.srt"
    srt = None
    if srt_rob.exists() and plan.get("srt", False):
        srt = wyjscie.with_name(wyjscie.stem + "_napisy.srt")
        shutil.copy(srt_rob, srt)
    os_czasu = {
        "nazwa": wyjscie.stem, "W": W, "H": H, "fps": fps, "calosc": calosc,
        "elementy": [{"plik": str(e["plik"]), "start": e["start"], "czas": e["czas"], "od": poczatki_el[i],
                      "ruch": e["ruch"], "przejscie": e["przejscie"],
                      "przejscie_d": (przejscia[i][1] if przejscia[i] else (0.22 if e["przejscie"] in PRZEJSCIA_KRAWEDZ else None))}
                     for i, e in enumerate(elementy)],
        "sceny_audio": [{"dzwiek": bool(s_.get("dzwiek")), "glosnosc": float(s_.get("glosnosc", 1.0)),
                         "dzwiek_z": ({"plik": str(sciezka(s_["dzwiek_z"]["plik"])), "start": float(s_["dzwiek_z"].get("start", 0))}
                                      if s_.get("dzwiek_z") else None)} for s_ in sceny],
        "lektor": str(lektor) if lektor else None,
        "muzyka": ({"plik": str(muz_plik), "glosnosc": float(muz.get("glosnosc", 0.18)), "start": float(muz.get("start", 0))} if muz_plik and muz_plik.exists() else None),
        "efekty": [{"plik": str(sciezka(e["plik"])), "czas": float(e.get("czas", 0)), "glosnosc": float(e.get("glosnosc", 0.6))} for e in efekty],
        "plansza_png": str(roboczy / "plansza.png") if czas_planszy else None,
        "logo": ({"plik": str(logo), "szerokosc": int((plan.get("logo") or {}).get("szerokosc", round(W * 0.16))),
                  "pozycja": (plan.get("logo") or {}).get("pozycja", "gora"), "do": koniec_tresci} if logo and logo.exists() else None),
        "srt": str(srt) if srt else None,
        # animacje, szablony i animowane logo nałożone na film: eksport do Premiere kładzie je na ścieżkach nad ujęciami
        "nakladki": [{"plik": str(sciezka(nk["plik"])), "czas": float(nk.get("czas", 0))}
                     for nk in (plan.get("nakladki") or []) if nk.get("plik") and sciezka(nk["plik"]) and sciezka(nk["plik"]).exists()],
    }
    (wyjscie.parent / f"{wyjscie.stem}_os_czasu.json").write_text(json.dumps(os_czasu, ensure_ascii=False, indent=1), encoding="utf-8")
    premiere_xml = None
    if plan.get("premiere"):
        import premiere
        premiere_xml = premiere.eksport(os_czasu, wyjscie.parent / "premiere")

    wynik(plik=str(wyjscie), dlugosc_s=round(calosc, 2), rozmiar_mb=round(rozmiar_mb, 1),
          podglad_do_studio=str(podglad) if podglad else str(wyjscie),
          font_napisow=napisy_nakl["font"] if napisy_nakl else None, sceny=len(sceny), czasy_scen=[round(c, 2) for c in czasy],
          napisy_srt=str(srt) if srt else None, premiere=premiere_xml)


def klatki(plik, ile):
    plik = sciezka(plik)
    calosc = dlugosc(plik)
    folder = plik.parent / "kontrola"
    folder.mkdir(exist_ok=True)
    pliki = []
    for i in range(ile):
        t = calosc * (i + 0.5) / ile
        cel = folder / f"klatka_{i + 1}_{t:.1f}s.jpg"
        ffmpeg(["-ss", f"{t:.2f}", "-i", plik, "-frames:v", 1, "-vf", "scale=540:-1", "-q:v", 3, cel], opis="klatka")
        pliki.append(str(cel))
    wynik(klatki=pliki)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Montaż rolek")
    sub = p.add_subparsers(dest="tryb", required=True)
    z = sub.add_parser("zloz"); z.add_argument("--plan", required=True)
    k = sub.add_parser("klatki"); k.add_argument("--plik", required=True); k.add_argument("--ile", type=int, default=5)
    a = p.parse_args()
    if a.tryb == "zloz":
        zloz(a.plan)
    else:
        klatki(a.plik, a.ile)
