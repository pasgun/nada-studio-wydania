"""„Ruch”: nowe animacje i grafiki ruchome Nada Studio (HyperFrames: HTML + GSAP), render do MOV z przezroczystością.

  python narzedzia/ruch.py lista [--kat tekst]                       biblioteka (narzedzia/ruch/biblioteka) + „Moje” (narzedzia/ruch/wlasne)
  python narzedzia/ruch.py render --szablon <id> --wyjscie <plik.mov> [--wartosci '{"tekst": "Hej *Ty*", "czas": 3}']
         [--klient klienci/<x>] [--format pion|poziom|kwadrat|4x5|1080x1920] [--fps 30] [--jakosc szkic|dobra]
         [--podglad] [--tlo <kadr.jpg albo film.mp4>] [--tlo-od <s>]
  python narzedzia/ruch.py render --projekt <folder z index.html> --wyjscie <plik.mov> [...]   własna animacja (np. napisana przez Claude)
  python narzedzia/ruch.py nowy --folder <folder> [--czas 4] [--format pion]   start nowej animacji: index.html + lib/ do edycji
  python narzedzia/ruch.py zapisz --projekt <folder> --id <id> --nazwa "..." [--kat tekst] [--opis "..."]   dodaje do „Moje” (panel, Studio)
  python narzedzia/ruch.py klatki --projekt <folder>|--szablon <id> --wyjscie <arkusz.jpg> [--czasy 0.2,0.6,1.5] [--tlo ...]   szybki podgląd bez renderu filmu
  python narzedzia/ruch.py galeria --wyjscie <arkusz.jpg> [--klient ...]   arkusz całej biblioteki (i podglad.jpg każdej pozycji)
  python narzedzia/ruch.py strona --url https://firma.pl [--folder klienci/<x>/brandbook/_zrodla]   dane marki ze strony (dembrandt + tekst strony)
  python narzedzia/ruch.py hf <polecenie HyperFrames> [...]   dowolne polecenie HyperFrames (lint, check, snapshot, beats, measure, catalog, add, docs ...)
  python narzedzia/ruch.py sprawdz                              Node, HyperFrames, Chrome

Wyjście: .mov = ProRes 4444 z przezroczystością (na ścieżkę nad filmem), .webm = z alfą, .mp4 = pełny kadr.
Kolory i fonty klienta: z klienci/<x>/marka.md (role), animacje.json i karta z brandbooka; pola z --wartosci wygrywają.
Każda kompozycja ładuje lib/gsap.min.js, lib/ruch.css, lib/marka.css i lib/ruch.js (pomocnik R: tekst, linie, dopasuj, os, wyjscie,
pozycja w bezpiecznych strefach). Wzór nowej animacji: narzedzia/ruch/baza/start.html. HyperFrames przez npx nie działa w zadaniach
w tle: zawsze przez ten plik (ruch.py hf ...). Telemetria HyperFrames jest wyłączona.

Wymaga Node.js 22 i Google Chrome (albo Edge). Biblioteki Node instaluje apka; brakujące instaluje sam ten plik (npm ci w narzedzia/ruch).
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, postep, wynik  # noqa: E402

FOLDER = Path(__file__).resolve().parent / "ruch"
BIBLIOTEKA = FOLDER / "biblioteka"
WLASNE = FOLDER / "wlasne"
BAZA = FOLDER / "baza"
FORMATY = {"pion": (1080, 1920), "poziom": (1920, 1080), "kwadrat": (1080, 1080), "4x5": (1080, 1350)}
WIN = sys.platform.startswith("win")
FL = 0x08000000 if WIN else 0


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


# ---------- Node, HyperFrames, Chrome ----------
def _npm():
    return shutil.which("npm") or shutil.which("npm.cmd")


def _instaluj(folder, bez_opcjonalnych=False):
    npm = _npm()
    if not npm:
        blad("Brak npm (instaluje się razem z Node.js). Apka Nada Studio instaluje Node sama: Ustawienia apki > Programy.")
    postep(f"Instaluję biblioteki Node w {folder.name} (jednorazowo, kilka minut)…")
    cmd = [npm, "ci" if (folder / "package-lock.json").exists() else "install", "--no-audit", "--no-fund"] + (["--omit=optional"] if bez_opcjonalnych else [])
    r = subprocess.run(cmd, cwd=folder, capture_output=True, text=True, encoding="utf-8", errors="replace", shell=WIN, creationflags=FL)
    if r.returncode != 0:
        blad(f"Nie udało się zainstalować bibliotek Node (narzedzia/ruch/{'' if folder == FOLDER else folder.name}): " + (r.stderr or r.stdout)[-500:])


def node():
    n = shutil.which("node")
    if not n:
        blad("Brak Node.js (wersja 22). Apka Nada Studio instaluje go sama: Ustawienia apki > Programy.")
    if not (FOLDER / "node_modules" / "hyperframes" / "package.json").exists():
        _instaluj(FOLDER)
    return n


def chrome():
    """Przeglądarka do renderu: NADA_CHROME, Chrome, Edge (Windows/Mac), Chromium z Playwright (Linux)."""
    kand = [os.environ.get("NADA_CHROME", "")]
    if WIN:
        for baza in (os.environ.get("PROGRAMFILES", r"C:\Program Files"), os.environ.get("PROGRAMFILES(X86)", r"C:\Program Files (x86)"), os.environ.get("LOCALAPPDATA", "")):
            if baza:
                kand += [os.path.join(baza, "Google", "Chrome", "Application", "chrome.exe"), os.path.join(baza, "Microsoft", "Edge", "Application", "msedge.exe")]
    elif sys.platform == "darwin":
        kand += ["/Applications/Google Chrome.app/Contents/MacOS/Google Chrome", "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"]
    else:
        import glob
        kand += sorted(glob.glob("/opt/pw-browsers/chromium_headless_shell-*/*/chrome-headless-shell")) + sorted(glob.glob(os.path.expanduser("~/.cache/ms-playwright/chromium_headless_shell-*/*/chrome-headless-shell")))
        kand += [shutil.which(x) or "" for x in ("google-chrome", "chromium", "chromium-browser")]
    for k in kand:
        if k and os.path.isfile(k):
            return k
    return None


def srodowisko():
    env = dict(os.environ, HYPERFRAMES_NO_TELEMETRY="1", DO_NOT_TRACK="1", HYPERFRAMES_SKIP_SKILLS="1", HYPERFRAMES_NO_UPDATE_CHECK="1", HYPERFRAMES_RENDER_LOCK="off")
    ch = chrome()
    if ch:
        env["HYPERFRAMES_BROWSER_PATH"] = ch
    ff = shutil.which("ffmpeg")
    if ff:
        env["HYPERFRAMES_FFMPEG_PATH"] = ff
    fp = shutil.which("ffprobe")
    if fp:
        env["HYPERFRAMES_FFPROBE_PATH"] = fp
    return env


def hf(args, cwd=None, czas=1800):
    """Uruchamia CLI HyperFrames z lokalnego node_modules (bez npx i bez telemetrii)."""
    n = node()
    cli = FOLDER / "node_modules" / "hyperframes" / "dist" / "cli.js"
    if not cli.exists():
        bin_ = json.loads((FOLDER / "node_modules" / "hyperframes" / "package.json").read_text(encoding="utf-8")).get("bin")
        rel = bin_ if isinstance(bin_, str) else (bin_ or {}).get("hyperframes")
        cli = FOLDER / "node_modules" / "hyperframes" / rel
    return subprocess.run([n, str(cli), *args], cwd=cwd or FOLDER, capture_output=True, text=True, encoding="utf-8", errors="replace",
                          env=srodowisko(), timeout=czas, creationflags=FL)


# ---------- marka klienta ----------
def _role_z_marki(klient):
    """Blok JSON z rolami kolorów z klienci/<x>/marka.md (pisze go Claude)."""
    if not klient:
        return {}
    f = sciezka(klient) / "marka.md"
    if not f.exists():
        return {}
    t = f.read_text(encoding="utf-8", errors="replace")
    for m in re.finditer(r"\{[^{}]*\"(?:tlo_ciemne|akcent)\"[^{}]*\}", t):
        try:
            return json.loads(m.group(0))
        except Exception:
            continue
    return {}


def marka(klient):
    """Kolory, font i logo dla animacji: marka.md (role) > animacje.json > karta z brandbooka."""
    import animacje
    p, logo = animacje.marka(klient) if klient else ({}, None)
    role = _role_z_marki(klient)
    mapa = {"tlo_ciemne": "kolor_glowny", "akcent": "kolor_akcent", "tekst_na_ciemnym": "kolor_tekstu"}
    wlasne = sciezka(klient) / "animacje.json" if klient else None
    for k, v in mapa.items():
        # animacje.json (zapisany świadomie w panelu) wygrywa z rolami z marka.md
        if role.get(k) and not (wlasne and wlasne.exists() and v in json.loads(wlasne.read_text(encoding="utf-8") or "{}")):
            p[v] = role[k]
    if klient:
        karta = sciezka(klient) / "brandbook" / "karta_klienta.json"
        try:
            body = (json.loads(karta.read_text(encoding="utf-8")).get("fonts") or {}).get("body") if karta.exists() else None
            if body and "font_tekst" not in p:
                p["font_tekst"] = body
        except Exception:
            pass
    p.pop("cien", None); p.pop("sprezystosc", None)
    return p, logo


def _font_face(nazwa, klient, cel_fonty, wagi=(400, 500, 600, 700, 800, 900)):
    """@font-face dla fontu marki (pliki klienta albo Google Fonts przez narzedzia/fonty.py), pliki kopiuje do lib/fonts."""
    if not nazwa:
        return ""
    import fonty
    folder = sciezka(klient) / "fonty" if klient else None
    reguly, uzyte = [], set()
    for w in wagi:
        try:
            plik, _ = fonty.znajdz_wage(nazwa, w, folder, pobieraj=True)
        except Exception:
            plik = None
        if not plik or not Path(plik).exists():
            continue
        # fonty.py przy nieudanym pobraniu oddaje font zapasowy: nie rejestrujemy go pod nazwą marki
        if nazwa.replace(" ", "").lower() not in Path(plik).stem.replace(" ", "").lower() and nazwa.replace(" ", "").lower() not in str(Path(plik).parent).replace(" ", "").lower():
            continue
        nazwa_pliku = Path(plik).name
        if nazwa_pliku not in uzyte:
            shutil.copy2(plik, cel_fonty / nazwa_pliku)
            uzyte.add(nazwa_pliku)
        fmt = "opentype" if nazwa_pliku.lower().endswith(".otf") else "truetype"
        reguly.append(f'@font-face {{ font-family: "{nazwa}"; src: url("fonts/{nazwa_pliku}") format("{fmt}"); font-weight: {w}; font-display: block; }}')
    return "\n".join(reguly)


def marka_css(p, klient, lib):
    (lib / "fonts").mkdir(parents=True, exist_ok=True)
    font = p.get("font") or "Montserrat"
    font_t = p.get("font_tekst") or font
    css = [_font_face(font, klient, lib / "fonts")]
    if font_t != font:
        css.append(_font_face(font_t, klient, lib / "fonts", wagi=(400, 500, 600)))
    zm = {"--glowny": p.get("kolor_glowny"), "--akcent": p.get("kolor_akcent"), "--tekst": p.get("kolor_tekstu"), "--tlo": p.get("kolor_tla")}
    linie = [f"  {k}: {v};" for k, v in zm.items() if v]
    linie.append(f'  --font: "{font}", var(--font-zapas);')
    linie.append(f'  --font-tekst: "{font_t}", var(--font-zapas);')
    if p.get("waga"):
        linie.append(f"  --waga: {int(p['waga'])};")
    css.append(":root {\n" + "\n".join(linie) + "\n}")
    (lib / "marka.css").write_text("\n".join(c for c in css if c) + "\n", encoding="utf-8")


# ---------- biblioteka ----------
def meta(folder):
    m = {}
    try:
        m = json.loads((folder / "meta.json").read_text(encoding="utf-8"))
    except Exception:
        pass
    m.setdefault("id", folder.name)
    m.setdefault("nazwa", folder.name)
    m.setdefault("kat", "tekst")
    m.setdefault("czas", 3)
    m.setdefault("pola", [])
    return m


def lista(kat=None):
    wyn = []
    for zrodlo, baza in (("biblioteka", BIBLIOTEKA), ("moje", WLASNE)):
        if not baza.exists():
            continue
        for f in sorted(baza.iterdir()):
            if (f / "index.html").exists():
                m = meta(f)
                m["zrodlo"] = zrodlo
                m["folder"] = str(f)
                m["podglad"] = str(f / "podglad.jpg") if (f / "podglad.jpg").exists() else None
                if not kat or m.get("kat") == kat:
                    wyn.append(m)
    return wyn


def znajdz(id_):
    for baza in (WLASNE, BIBLIOTEKA):
        f = baza / id_
        if (f / "index.html").exists():
            return f
    blad(f"Nie ma animacji „{id_}”. Lista: python narzedzia/ruch.py lista")


def rozmiar(fmt):
    if fmt in FORMATY:
        return FORMATY[fmt]
    try:
        w, h = str(fmt).lower().split("x")
        return int(w), int(h)
    except Exception:
        blad(f"Format „{fmt}”: użyj pion, poziom, kwadrat, 4x5 albo np. 1080x1920.")


def przygotuj(zrodlo, cel, wartosci, klient, W, H):
    """Kopia kompozycji do folderu roboczego: lib/ (gsap, ruch.js, ruch.css, marka.css, fonty), {{W}} {{H}} {{czas}} w HTML."""
    node()
    if cel.exists():
        shutil.rmtree(cel, ignore_errors=True)
    shutil.copytree(zrodlo, cel, ignore=shutil.ignore_patterns("renders", "*.mov", "*.mp4", "*.webm", "podglad*.jpg", "_ruch*", ".ruch_*"))
    lib = cel / "lib"
    lib.mkdir(exist_ok=True)
    shutil.copy2(FOLDER / "node_modules" / "gsap" / "dist" / "gsap.min.js", lib / "gsap.min.js")
    for f in ("ruch.js", "ruch.css"):
        shutil.copy2(BAZA / "lib" / f, lib / f)
    p, logo = marka(klient)
    p.update({k: v for k, v in wartosci.items() if k in ("kolor_glowny", "kolor_akcent", "kolor_tekstu", "kolor_tla", "font", "font_tekst", "waga") and v})
    marka_css(p, klient, lib)
    if logo and Path(logo).exists() and "logo" not in wartosci:
        shutil.copy2(logo, lib / ("logo" + Path(logo).suffix.lower()))
        wartosci["logo"] = "lib/logo" + Path(logo).suffix.lower()
    elif wartosci.get("logo") and Path(sciezka(wartosci["logo"])).exists():
        src = sciezka(wartosci["logo"])
        shutil.copy2(src, lib / ("logo" + src.suffix.lower()))
        wartosci["logo"] = "lib/logo" + src.suffix.lower()
    # pliki z pól (zdjęcia, film) kopiowane do lib/media, żeby przeglądarka je widziała
    (lib / "media").mkdir(exist_ok=True)
    for k, v in list(wartosci.items()):
        if isinstance(v, str) and re.search(r"\.(png|jpe?g|webp|gif|svg|mp4|mov|webm)$", v, re.I) and not v.startswith("lib/"):
            src = sciezka(v)
            if src.exists():
                nazwa = hashlib.sha1(str(src).encode()).hexdigest()[:8] + src.suffix.lower()
                shutil.copy2(src, lib / "media" / nazwa)
                wartosci[k] = "lib/media/" + nazwa
    czas = float(wartosci.get("czas") or meta(zrodlo).get("czas") or 3)
    wartosci["czas"] = czas
    html = (cel / "index.html").read_text(encoding="utf-8")
    html = html.replace("{{W}}", str(W)).replace("{{H}}", str(H)).replace("{{czas}}", f"{czas:g}")
    (cel / "index.html").write_text(html, encoding="utf-8")
    return wartosci, czas


def _ffmpeg():
    return shutil.which("ffmpeg") or "ffmpeg"


def arkusz(film, wyjscie, czas, tlo=None, tlo_od=0.0, kadrow=8, W=1080, H=1920, fps=30):
    """Arkusz kontrolny: dokładne klatki animacji (wejście gęściej, trzymanie, zejście) nałożone na tło (kadr, film albo szare)."""
    import io
    from PIL import Image
    n = max(1, int(round(czas * fps)))
    kl = sorted({min(n - 1, x) for x in (3, 7, 13, 24, n // 2, n - 12, n - 6, n - 2) if x >= 0})[:kadrow]
    sel = "+".join(f"eq(n\\,{x})" for x in kl)
    r = subprocess.run([_ffmpeg(), "-v", "error", "-i", str(film), "-vf", f"select='{sel}'", "-fps_mode", "passthrough", "-f", "image2pipe", "-vcodec", "png", "-"],
                       capture_output=True, creationflags=FL)
    raw, klatki, i = r.stdout, [], 0
    while raw:
        j = raw.find(b"\x89PNG", i + 1)
        try:
            klatki.append(Image.open(io.BytesIO(raw[i: j if j > 0 else len(raw)])).convert("RGBA"))
        except Exception:
            pass
        if j < 0:
            break
        i = j
    if not klatki:
        return None, []
    w, h = klatki[0].size
    if tlo:
        tp = sciezka(tlo)
        if tp.suffix.lower() in (".mp4", ".mov", ".webm", ".mkv"):
            rr = subprocess.run([_ffmpeg(), "-v", "error", "-ss", str(tlo_od or 0), "-i", str(tp), "-frames:v", "1", "-f", "image2pipe", "-vcodec", "png", "-"], capture_output=True, creationflags=FL)
            b = Image.open(io.BytesIO(rr.stdout)).convert("RGBA")
        else:
            b = Image.open(tp).convert("RGBA")
        s_ = max(w / b.width, h / b.height)
        b = b.resize((int(b.width * s_ + 1), int(b.height * s_ + 1)))
        b = b.crop(((b.width - w) // 2, (b.height - h) // 2, (b.width - w) // 2 + w, (b.height - h) // 2 + h))
    else:
        b = Image.new("RGBA", (w, h), (107, 111, 118, 255))
    sz = 270 if h > w else 480
    kafle = []
    for f in klatki:
        c = b.copy(); c.alpha_composite(f); kafle.append(c.convert("RGB").resize((sz, int(sz * h / w))))
    ark = Image.new("RGB", (len(kafle) * (sz + 4) - 4, kafle[0].height), (17, 17, 17))
    for k, t in enumerate(kafle):
        ark.paste(t, (k * (sz + 4), 0))
    ark.save(str(wyjscie), quality=86)
    return str(wyjscie), [round(x / fps, 2) for x in kl]


def render(szablon=None, projekt=None, wyjscie=None, wartosci=None, klient=None, fmt="pion", fps=30, jakosc="dobra", podglad=False, tlo=None, tlo_od=0.0, ciche=False):
    zrodlo = znajdz(szablon) if szablon else sciezka(projekt)
    if not (zrodlo / "index.html").exists():
        blad(f"W {zrodlo} nie ma index.html.")
    W, H = rozmiar(fmt)
    out = sciezka(wyjscie)
    out.parent.mkdir(parents=True, exist_ok=True)
    w = dict(json.loads(wartosci) if isinstance(wartosci, str) else (wartosci or {}))
    for pole in meta(zrodlo).get("pola", []):
        if pole.get("id") and pole.get("domyslnie") is not None and w.get(pole["id"]) is None:  # pusty tekst z panelu = świadomie wyłączona linia
            w[pole["id"]] = pole["domyslnie"]
    robocze = Path(tempfile.mkdtemp(prefix="ruch_"))
    try:
        w, czas = przygotuj(zrodlo, robocze / "projekt", w, klient, W, H)
        fmt_wyj = {".mov": "mov", ".webm": "webm", ".mp4": "mp4", ".gif": "gif"}.get(out.suffix.lower(), "mov")
        if not ciche:
            postep(f"Renderuję {zrodlo.name} ({czas:g} s, {W}x{H})…")
        args = ["render", str(robocze / "projekt"), "--format", fmt_wyj, "-o", str(out), "--fps", str(fps), "--quiet",
                "-q", "draft" if jakosc == "szkic" else "looks", "--variables", json.dumps({"w_" + k: v for k, v in w.items()}, ensure_ascii=False)]
        t0 = time.time()
        r = hf(args, cwd=robocze)
        if r.returncode != 0 or not out.exists():
            blad("HyperFrames nie wyrenderował animacji: " + ((r.stderr or "") + (r.stdout or ""))[-900:])
        wyn = {"plik": str(out), "czas": czas, "format": [W, H], "sekund_renderu": round(time.time() - t0, 1)}
        if podglad:
            ark, t = arkusz(out, out.with_name(out.stem + "_podglad.jpg"), czas, tlo, tlo_od, W=W, H=H, fps=fps)
            wyn["podglad"] = ark
            wyn["podglad_czasy"] = t
        return wyn
    finally:
        shutil.rmtree(robocze, ignore_errors=True)


def klatki(szablon=None, projekt=None, wyjscie=None, wartosci=None, klient=None, fmt="pion", czasy=None, tlo=None):
    """Szybki podgląd: krótki render szkicu i arkusz klatek (bez zapisu filmu)."""
    tmp = Path(tempfile.mkdtemp(prefix="ruchk_"))
    try:
        r = render(szablon, projekt, tmp / "k.mov", wartosci, klient, fmt, 30, "szkic", False, ciche=True)
        W, H = r["format"]
        ark, t = arkusz(tmp / "k.mov", sciezka(wyjscie), r["czas"], tlo, W=W, H=H)
        return {"arkusz": ark, "czasy": t, "czas": r["czas"]}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def nowy(folder, czas=4, fmt="pion"):
    f = sciezka(folder)
    f.mkdir(parents=True, exist_ok=True)
    if not (f / "index.html").exists():
        shutil.copy2(BAZA / "start.html", f / "index.html")
    if not (f / "meta.json").exists():
        (f / "meta.json").write_text(json.dumps({"id": f.name, "nazwa": f.name, "kat": "tekst", "czas": czas, "opis": "",
                                                 "pola": [{"id": "tekst", "typ": "tekst", "etykieta": "Tekst", "domyslnie": "Twój *tekst* tutaj"}]},
                                                ensure_ascii=False, indent=1), encoding="utf-8")
    return {"folder": str(f), "html": str(f / "index.html"), "meta": str(f / "meta.json"),
            "pomocnik": str(BAZA / "lib" / "ruch.js"), "wzory": str(BIBLIOTEKA),
            "dalej": f"Edytuj index.html (wzory w narzedzia/ruch/biblioteka/*/index.html), potem: python narzedzia/ruch.py render --projekt {folder} --wyjscie <plik.mov> --podglad [--tlo <kadr>]"}


def zapisz(projekt, id_, nazwa, kat="tekst", opis=""):
    src = sciezka(projekt)
    id_ = re.sub(r"[^a-z0-9-]+", "-", id_.lower()).strip("-") or "moja"
    cel = WLASNE / id_
    if cel.exists():
        shutil.rmtree(cel)
    shutil.copytree(src, cel, ignore=shutil.ignore_patterns("lib", "renders", "*.mov", "*.mp4", "*.webm", "_*"))
    m = meta(cel)
    m.update({"id": id_, "nazwa": nazwa or m.get("nazwa") or id_, "kat": kat or m.get("kat"), "opis": opis or m.get("opis", ""), "zrodlo": "moje",
              "utworzono": time.strftime("%Y-%m-%d %H:%M")})
    (cel / "meta.json").write_text(json.dumps(m, ensure_ascii=False, indent=1), encoding="utf-8")
    try:
        k = klatki(projekt=str(cel), wyjscie=str(cel / "podglad_arkusz.jpg"))
        # pojedynczy kadr do galerii: środek animacji
        tmp = Path(tempfile.mkdtemp(prefix="ruchp_"))
        render(projekt=str(cel), wyjscie=tmp / "p.mov", jakosc="szkic", ciche=True)
        subprocess.run([_ffmpeg(), "-y", "-v", "error", "-f", "lavfi", "-i", "color=c=0x2a2c31:s=1080x1920", "-ss", str(max(0.1, m.get("czas", 3) * 0.55)), "-i", str(tmp / "p.mov"),
                        "-filter_complex", "[0:v][1:v]overlay=format=auto,scale=360:-2", "-frames:v", "1", str(cel / "podglad.jpg")], capture_output=True, creationflags=FL)
        shutil.rmtree(tmp, ignore_errors=True)
    except SystemExit:
        k = None
    return {"id": id_, "folder": str(cel), "podglad": str(cel / "podglad.jpg") if (cel / "podglad.jpg").exists() else None}


def _miniatura(film, t, kadr, szer=360):
    """Jedna klatka animacji (z przezroczystością) na szarym tle jako podglad.jpg do galerii w panelu."""
    import io
    from PIL import Image
    r = subprocess.run([_ffmpeg(), "-v", "error", "-ss", f"{t:.2f}", "-i", str(film), "-frames:v", "1", "-f", "image2pipe", "-vcodec", "png", "-"],
                       capture_output=True, creationflags=FL)
    if not r.stdout:
        return False
    f = Image.open(io.BytesIO(r.stdout)).convert("RGBA")
    if not f.getbbox() or f.getchannel("A").getextrema()[1] == 0:
        return False
    b = Image.new("RGBA", f.size, (42, 44, 49, 255))
    b.alpha_composite(f)
    b.convert("RGB").resize((szer, int(szer * f.height / f.width))).save(str(kadr), quality=86)
    return True


def galeria(wyjscie, klient=None):
    pozycje = lista()
    tmp = Path(tempfile.mkdtemp(prefix="ruchg_"))
    kafle = []
    try:
        for i, m in enumerate(pozycje):
            postep(f"Galeria {i + 1}/{len(pozycje)}: {m['id']}")
            f = Path(m["folder"])
            try:
                r = render(szablon=m["id"], wyjscie=tmp / f"{i}.mov", klient=klient, jakosc="szkic", ciche=True)
            except SystemExit:
                continue
            kadr = f / "podglad.jpg"
            t = max(0.1, r["czas"] * (0.25 if m.get("kat") == "przejscia" else 0.35 if m.get("pelny") else 0.55))  # przejście w połowie zakrywa cały kadr
            _miniatura(tmp / f"{i}.mov", t, kadr)
            (tmp / f"{i}.mov").unlink(missing_ok=True)
            if kadr.exists():
                kafle.append((kadr, m["nazwa"]))
        if not kafle:
            blad("Nie udało się zrobić galerii.")
        lista_pl = tmp / "lista.txt"
        kol = 8
        wej = []
        for k, _ in kafle:
            wej += ["-i", str(k)]
        n = len(kafle)
        rzedy = -(-n // kol)
        filtr = "".join(f"[{i}:v]scale=180:320,setsar=1[k{i}];" for i in range(n))
        filtr += "".join(f"[k{i}]" for i in range(n)) + f"xstack=inputs={n}:layout=" + "|".join(f"{(i % kol) * 180}_{(i // kol) * 320}" for i in range(n)) + f":fill=0x111111" if n > 1 else "[k0]copy"
        subprocess.run([_ffmpeg(), "-y", "-v", "error", *wej, "-filter_complex", filtr, "-frames:v", "1", str(sciezka(wyjscie))], capture_output=True, creationflags=FL)
        lista_pl.unlink(missing_ok=True)
        return {"galeria": str(sciezka(wyjscie)), "pozycji": n, "rzedow": rzedy}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ---------- dane marki ze strony ----------
def strona(url, folder=None):
    """Dane marki ze strony: dembrandt (kolory z rolami, typografia, logo) przez Chrome + kontakt i teksty."""
    import socket
    import urllib.request
    if not re.match(r"^https?://", url):
        url = "https://" + url
    sfolder = FOLDER / "strona"
    if not (sfolder / "node_modules" / "dembrandt" / "package.json").exists():
        _instaluj(sfolder, bez_opcjonalnych=True)
    ch = chrome()
    if not ch:
        blad("Do czytania strony potrzebny jest Google Chrome albo Microsoft Edge.")
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        port = s.getsockname()[1]
    profil = Path(tempfile.mkdtemp(prefix="ruchs_"))
    pr = subprocess.Popen([ch, "--headless=new", f"--remote-debugging-port={port}", f"--user-data-dir={profil}", "--no-first-run", "--disable-gpu",
                           "--no-default-browser-check", "--disable-extensions", "--window-size=1440,1000"] + (["--no-sandbox"] if not WIN and hasattr(os, "geteuid") and os.geteuid() == 0 else []) + ["about:blank"],
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=FL)
    dane, uwagi = {}, []
    try:
        for _ in range(60):
            try:
                urllib.request.urlopen(f"http://127.0.0.1:{port}/json/version", timeout=1).read()
                break
            except Exception:
                time.sleep(0.25)
        n = node()
        cli = sfolder / "node_modules" / "dembrandt" / "dist" / "index.js"
        env = dict(os.environ, BROWSER_CDP_ENDPOINT=f"http://127.0.0.1:{port}", DEMBRANDT_NO_HEADED_FALLBACK="1", DO_NOT_TRACK="1", NO_COLOR="1")
        postep(f"Czytam stronę {url}…")
        r = subprocess.run([n, str(cli), url, "--json-only", "--no-headed-fallback"], capture_output=True, text=True, encoding="utf-8", errors="replace",
                           env=env, timeout=180, creationflags=FL, cwd=sfolder)
        try:
            dane = json.loads(r.stdout[r.stdout.index("{"):])
        except Exception:
            uwagi.append("dembrandt nie odczytał strony: " + (r.stderr or r.stdout)[-300:])
        if isinstance(dane, dict) and dane.get("error"):
            uwagi.append("dembrandt: " + str((dane["error"] or {}).get("message", dane["error"]))[:300])
            dane = {}
    finally:
        pr.terminate()
        try:
            pr.wait(timeout=5)
        except Exception:
            pr.kill()
        shutil.rmtree(profil, ignore_errors=True)
    # tekst strony, kontakt, kandydaci na logo (brandbook.py)
    html = ""
    try:
        import requests
        rr = requests.get(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/126 Safari/537.36"}, timeout=30)
        if "charset" not in rr.headers.get("content-type", "").lower():
            rr.encoding = "utf-8"
        html = rr.text
    except Exception as e:
        uwagi.append(f"Nie pobrałem HTML strony: {e}")
    return _karta_ze_strony(url, dane, html, folder, uwagi)


def _karta_ze_strony(url, d, html, folder, uwagi):
    import html as H
    def na_hex(x):
        x = str(x or "").strip()
        m = re.match(r"^#([0-9a-fA-F]{6})$", x)
        if m:
            return "#" + m.group(1).upper()
        m = re.match(r"^#([0-9a-fA-F])([0-9a-fA-F])([0-9a-fA-F])$", x)
        if m:
            return "#" + "".join(c * 2 for c in m.groups()).upper()
        m = re.match(r"^rgba?\(\s*(\d+)[,\s]+(\d+)[,\s]+(\d+)(?:[,\s/]+([\d.]+))?", x)
        if m and (m.group(4) is None or float(m.group(4)) > 0.5):
            return "#%02X%02X%02X" % tuple(min(255, int(v)) for v in m.groups()[:3])
        return None

    def hexy(lista):
        out = []
        for c in lista:
            h = na_hex((c.get("normalized") or c.get("hex") or c.get("value") or c.get("color") or "") if isinstance(c, dict) else c)
            if h and h not in out:
                out.append(h)
        return out
    kol = d.get("colors") or {}
    paleta, role = [], {}
    if isinstance(kol, dict):
        for rola in ("primary", "secondary", "accent", "background", "text"):
            v = kol.get(rola)
            if isinstance(v, (dict, str)):
                h = hexy([v])
                if h:
                    role[rola] = h[0]
        sem = kol.get("semantic") or {}
        if isinstance(sem, dict):
            for rola, v in sem.items():
                h = hexy([v] if not isinstance(v, list) else v)
                if h and rola not in role:
                    role[rola] = h[0]
        paleta = hexy(kol.get("palette") or kol.get("all") or [])
    elif isinstance(kol, list):
        paleta = hexy(kol)
    for rola in ("primary", "accent", "secondary"):
        if role.get(rola) and role[rola] not in paleta:
            paleta.insert(0, role[rola])
    # kolejność: główny, akcent, reszta (bez prawie-białych i prawie-czarnych na początku)
    def neutralny(h):
        r, g, b = int(h[1:3], 16), int(h[3:5], 16), int(h[5:7], 16)
        return max(r, g, b) - min(r, g, b) < 14
    pierwsze = [role[x] for x in ("primary", "accent", "secondary") if role.get(x)]
    reszta = [h for h in paleta if h not in pierwsze]
    paleta = (pierwsze + [h for h in reszta if not neutralny(h)] + [h for h in reszta if neutralny(h)])[:8]
    typ = d.get("typography") or {}
    fonty = []
    if isinstance(typ, dict):
        style = [st for st in (typ.get("styles") or []) if isinstance(st, dict)]
        kol = lambda st: 0 if re.search(r"h1|h2|head|display|title", str(st.get("context", "")), re.I) else 1
        for st in sorted(style, key=lambda st: (kol(st), -(st.get("count") or 0))):
            n = (st.get("family") or "").split(",")[0].strip().strip("'\"")
            if n and n not in fonty and n.lower() not in ("inherit", "sans-serif", "serif", "system-ui", "-apple-system", "arial", "helvetica"):
                fonty.append(n)
    for k in ("families", "fontFamilies", "fonts"):
        for f in (typ.get(k) or []) if isinstance(typ, dict) else []:
            n = f.get("family") or f.get("name") if isinstance(f, dict) else str(f)
            n = (n or "").split(",")[0].strip().strip("'\"")
            if n and n.lower() not in ("inherit", "sans-serif", "serif", "system-ui", "-apple-system") and n not in fonty:
                fonty.append(n)
    if isinstance(typ, dict):
        for st in (typ.get("styles") or [])[:30]:
            n = (st.get("family") or st.get("fontFamily") or "").split(",")[0].strip().strip("'\"") if isinstance(st, dict) else ""
            if n and n not in fonty and n.lower() not in ("inherit", "sans-serif", "serif"):
                fonty.append(n)
    # kontakt i nazwa z HTML
    tekst = re.sub(r"<(script|style|noscript)[^>]*>.*?</\1>", " ", html, flags=re.S | re.I)
    maile = list(dict.fromkeys(m.lower() for m in re.findall(r"[\w.+-]+@[\w-]+\.[\w.-]+", H.unescape(re.sub(r"<[^>]+>", " ", tekst)) + " " + " ".join(re.findall(r'mailto:([^"\'?>]+)', html)))
                               if not re.search(r"\.(png|jpe?g|webp|svg|gif)$", m, re.I) and "sentry" not in m and "example" not in m))
    tel = [re.sub(r"\s+", " ", t).strip() for t in re.findall(r'tel:([+\d\s()-]{7,})', html)]
    if not tel:
        tel = [re.sub(r"\s+", " ", t).strip() for t in re.findall(r"(?:\+48[\s-]?)?(?:\d{3}[\s-]\d{3}[\s-]\d{3}|\d{2}[\s-]\d{3}[\s-]\d{2}[\s-]\d{2})", H.unescape(re.sub(r"<[^>]+>", " ", tekst)))]
    def meta_tag(nazwa):
        m = re.search(rf'<meta[^>]+(?:property|name)=["\']{nazwa}["\'][^>]+content=["\']([^"\']*)', html, flags=re.I) or re.search(rf'<meta[^>]+content=["\']([^"\']*)["\'][^>]+(?:property|name)=["\']{nazwa}["\']', html, flags=re.I)
        return H.unescape(m.group(1)).strip() if m else ""
    tytul = H.unescape((re.search(r"<title[^>]*>(.*?)</title>", html, flags=re.S | re.I) or [None, ""])[1]).strip()
    nazwa = meta_tag("og:site_name") or re.split(r"\s[|–—-]\s", tytul)[0].strip() if (meta_tag("og:site_name") or tytul) else ""
    opis = meta_tag("description") or meta_tag("og:description")
    # logo: dembrandt albo kandydaci z HTML
    logo_url = None
    lg = d.get("logo") or {}
    if isinstance(lg, dict):
        logo_url = lg.get("url") or lg.get("src")
    elif isinstance(lg, list) and lg:
        logo_url = lg[0].get("url") if isinstance(lg[0], dict) else str(lg[0])
    if not logo_url:
        for tag in re.findall(r"<img[^>]+>", html, flags=re.I):
            if re.search(r"logo|brand", tag, flags=re.I):
                m = re.search(r'src=["\']([^"\']+)', tag)
                if m:
                    logo_url = m.group(1)
                    break
    logo_dane = None
    if logo_url:
        from urllib.parse import urljoin
        logo_url = urljoin(url, logo_url)
        try:
            import base64
            import requests
            lr = requests.get(logo_url, headers={"User-Agent": "Mozilla/5.0"}, timeout=20)
            typ_l = lr.headers.get("content-type", "").split(";")[0] or "image/png"
            if lr.ok and typ_l.startswith("image/") and len(lr.content) < 3_000_000:
                logo_dane = f"data:{typ_l};base64," + base64.b64encode(lr.content).decode("ascii")
                if folder:
                    fo = sciezka(folder)
                    fo.mkdir(parents=True, exist_ok=True)
                    ext = {"image/svg+xml": ".svg", "image/jpeg": ".jpg", "image/webp": ".webp"}.get(typ_l, ".png")
                    (fo / ("logo_ze_strony" + ext)).write_bytes(lr.content)
        except Exception as e:
            uwagi.append(f"Logo: {e}")
    karta = {"name": nazwa, "www": url, "email": maile[0] if maile else "", "tel": tel[0] if tel else "", "paleta": paleta,
             "fonts": {"heading": fonty[0] if fonty else "", "body": fonty[1] if len(fonty) > 1 else (fonty[0] if fonty else "")}, "opis": opis}
    if folder:
        fo = sciezka(folder)
        fo.mkdir(parents=True, exist_ok=True)
        (fo / "strona_dembrandt.json").write_text(json.dumps(d, ensure_ascii=False, indent=1)[:2_000_000], encoding="utf-8")
    return {"karta": karta, "role": role, "fonty_wszystkie": fonty[:8], "logo": logo_dane, "logo_url": logo_url, "uwagi": uwagi}


def sprawdz():
    n = shutil.which("node")
    wer = subprocess.run([n, "--version"], capture_output=True, text=True, creationflags=FL).stdout.strip() if n else None
    hf_ok = (FOLDER / "node_modules" / "hyperframes" / "package.json").exists()
    return {"node": wer, "node_22": bool(wer and int(wer.lstrip("v").split(".")[0]) >= 22), "hyperframes": hf_ok,
            "dembrandt": (FOLDER / "strona" / "node_modules" / "dembrandt" / "package.json").exists(), "chrome": chrome(),
            "biblioteka": len(lista())}


if __name__ == "__main__":
    a = argparse.ArgumentParser(description="Ruch: animacje HyperFrames")
    sub = a.add_subparsers(dest="tryb", required=True)
    s = sub.add_parser("lista"); s.add_argument("--kat")
    for nazwa in ("render", "klatki"):
        r = sub.add_parser(nazwa)
        r.add_argument("--szablon"); r.add_argument("--projekt"); r.add_argument("--wyjscie", required=True)
        r.add_argument("--wartosci"); r.add_argument("--klient"); r.add_argument("--format", default="pion"); r.add_argument("--tlo")
        if nazwa == "render":
            r.add_argument("--fps", type=int, default=30); r.add_argument("--jakosc", default="dobra", choices=["szkic", "dobra"])
            r.add_argument("--podglad", action="store_true"); r.add_argument("--tlo-od", type=float, default=0.0)
        else:
            r.add_argument("--czasy")
    s = sub.add_parser("nowy"); s.add_argument("--folder", required=True); s.add_argument("--czas", type=float, default=4); s.add_argument("--format", default="pion")
    s = sub.add_parser("zapisz"); s.add_argument("--projekt", required=True); s.add_argument("--id", required=True); s.add_argument("--nazwa", default=""); s.add_argument("--kat", default="tekst"); s.add_argument("--opis", default="")
    s = sub.add_parser("galeria"); s.add_argument("--wyjscie", required=True); s.add_argument("--klient")
    s = sub.add_parser("strona"); s.add_argument("--url", required=True); s.add_argument("--folder")
    sub.add_parser("sprawdz")
    s = sub.add_parser("hf"); s.add_argument("reszta", nargs=argparse.REMAINDER)
    x = a.parse_args()
    if x.tryb == "lista":
        wynik(animacje=lista(x.kat))
    elif x.tryb == "render":
        if not (x.szablon or x.projekt):
            blad("Podaj --szablon <id> albo --projekt <folder>.")
        wynik(**render(x.szablon, x.projekt, x.wyjscie, x.wartosci, x.klient, x.format, x.fps, x.jakosc, x.podglad, x.tlo, x.tlo_od),
              uwaga="Plik .mov połóż na ścieżce wideo nad filmem (ma przezroczyste tło). Obejrzyj arkusz podglądu (Read).")
    elif x.tryb == "klatki":
        wynik(**klatki(x.szablon, x.projekt, x.wyjscie, x.wartosci, x.klient, x.format, x.czasy, x.tlo))
    elif x.tryb == "nowy":
        wynik(**nowy(x.folder, x.czas, x.format))
    elif x.tryb == "zapisz":
        wynik(**zapisz(x.projekt, x.id, x.nazwa, x.kat, x.opis))
    elif x.tryb == "galeria":
        wynik(**galeria(x.wyjscie, x.klient))
    elif x.tryb == "strona":
        wynik(**strona(x.url, x.folder))
    elif x.tryb == "sprawdz":
        wynik(**sprawdz())
    elif x.tryb == "hf":
        reszta = [r for r in x.reszta if r != "--"]
        zakazane = {"publish", "billing", "login", "logout", "auth", "upgrade", "telemetry", "open", "preview", "present", "reverse", "usage", "feedback", "cloud", "lambda", "cloudrun", "templates", "catch-up", "history"}
        if reszta and reszta[0] in zakazane:
            blad(f"Polecenie HyperFrames „{reszta[0]}” jest wyłączone w silniku (konto HeyGen, wysyłanie plików albo okno podglądu).")
        r = hf(reszta, cwd=KATALOG_SILNIKA)
        print((r.stdout or "") + (("\n" + r.stderr) if r.returncode and r.stderr else ""))
        sys.exit(r.returncode)
