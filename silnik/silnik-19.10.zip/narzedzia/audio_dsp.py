"""Obróbka dźwięku dla asystenta audio (narzedzia/audio_asystent.py): wszystko liczy się na tym komputerze.

Dźwięk trzymamy w surowych plikach float32 48 kHz (pliki .f32 w folderze tymczasowym) i czytamy je kawałkami
(np.memmap), więc nawet godzina nagrania nie zapcha pamięci. Każdy krok zachowuje dokładnie tę samą liczbę próbek,
żeby dźwięk nie przesunął się względem obrazu.

Kroki dla mowy (jak Voice Isolation, Dialogue Leveler, De-Esser i Dialogue Matcher w DaVinci, plus to, co ma Audition):
  diagnoza()     szum tła, pogłos, buczenie sieci 50/60 Hz, przestery, syczenie, barwa (widmo mowy)
  buczenie       wąskie filtry na 50/60 Hz i harmonicznych (tylko gdy buczenie jest)
  przester       odbudowa obciętych szczytów (adeclip) tylko wokół miejsc z przesterem
  odszumianie    sieć neuronowa RNNoise (model w narzedzia/audio_modele) + odszumianie widmowe afftdn
  pogłos         WPE (weighted prediction error): z nagrania odejmowane jest echo pomieszczenia
  barwa          dopasowanie barwy mikrofonów do siebie + korekcja mowy (dudnienie, czytelność, powietrze)
  de-esser       przyciszenie syczących „s”, „sz”, „c”
  wyrównanie     leveler: każda fraza w podobnej głośności (bez podbijania ciszy)
  kompresja      wygładzenie szczytów
  bramka         ekspander: przycisza tło między słowami (z wyprzedzeniem, nie ucina początków słów)
"""
import gc
import math
import os
import re
import subprocess
import tempfile
from pathlib import Path

import numpy as np

SR = 48000
MODELE = Path(__file__).resolve().parent / "audio_modele"
POZIOMY = {"wyl": 0, "lekko": 1, "srednio": 2, "mocno": 3}


class BladAudio(Exception):
    pass


# ---------- ffmpeg i pliki surowe ----------
def ffmpeg(args, opis, cwd=None):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-nostdin", "-y", *map(str, args)], capture_output=True,
                       text=True, encoding="utf-8", errors="replace", cwd=cwd)
    if r.returncode != 0:
        raise BladAudio(f"{opis}: {r.stderr[-600:]}")
    return r


def surowe_we(ch):
    return ["-f", "f32le", "-ar", SR, "-ac", ch]


class Folder:
    """Folder tymczasowy na pliki .f32 (sprzątany na końcu)."""

    def __init__(self, baza=None):
        self.p = Path(tempfile.mkdtemp(prefix="nada_audio_", dir=baza))
        self.n = 0

    def nowy(self, nazwa="x"):
        self.n += 1
        return self.p / f"{self.n:04d}_{re.sub(r'[^A-Za-z0-9_]+', '_', nazwa)[:40]}.f32"

    def sprzataj(self):
        gc.collect()  # zamyka pliki, które numpy jeszcze trzyma otwarte (Windows nie usuwa otwartych plików)
        for x in self.p.glob("*"):
            try:
                x.unlink()
            except OSError:
                pass
        try:
            self.p.rmdir()
        except OSError:
            pass


def probki(raw, ch):
    return os.path.getsize(raw) // (4 * ch)


def dopasuj(raw, n, ch):
    """Ustawia dokładnie n próbek (dopisuje ciszę albo obcina)."""
    with open(raw, "r+b") as f:
        f.truncate(n * ch * 4)


def czytaj(raw, ch=1, tryb="r"):
    n = probki(raw, ch)
    if n == 0:
        return np.zeros((0, ch) if ch > 1 else 0, dtype=np.float32)
    m = np.memmap(raw, dtype=np.float32, mode=tryb, shape=(n, ch) if ch > 1 else (n,))
    return m


def nowy_raw(sciezka, n, ch=1):
    with open(sciezka, "wb") as f:
        f.truncate(n * ch * 4)
    return np.memmap(sciezka, dtype=np.float32, mode="r+", shape=(n, ch) if ch > 1 else (n,))


def z_pliku(wej, cel, ch=1, ss=None, t=None, kanal=None, filtr=None):
    """Plik audio/wideo -> surowe float32 48 kHz. kanal: numer kanału pliku (1..), None = całość zmiksowana."""
    args = []
    if ss is not None:
        args += ["-ss", f"{max(0.0, ss):.4f}"]
    if t is not None:
        args += ["-t", f"{t:.4f}"]
    args += ["-i", wej, "-vn", "-sn", "-dn"]
    f = []
    if kanal:
        f.append(f"pan=mono|c0=c{kanal - 1}")
    if filtr:
        f.append(filtr)
    if f:
        args += ["-af", ",".join(f)]
    args += ["-ac", ch, "-ar", SR, "-f", "f32le", cel]
    ffmpeg(args, f"odczyt {Path(wej).name}")
    if t is not None:
        dopasuj(cel, int(round(t * SR)), ch)


def opoznienie(a, b, max_s=0.25):
    """O ile próbek b (wynik filtra) jest opóźnione względem a (wejście): korelacja w najgłośniejszym fragmencie."""
    n = min(len(a), len(b))
    if n < SR // 2:
        return 0
    env = ramki_db(a[:n], hop=0.1, okno=0.1)
    okno_r = min(len(env), 80)  # 8 s
    if len(env) > okno_r:
        moc = np.convolve(10 ** (env / 10), np.ones(okno_r), mode="valid")
        i0 = int(moc.argmax()) * int(SR * 0.1)
    else:
        i0 = 0
    L = min(n - i0, okno_r * int(SR * 0.1))
    m = int(max_s * SR)
    x = np.asarray(a[i0:i0 + L], dtype=np.float64)
    a0, b0 = max(0, i0 - m), min(n, i0 + L + m)
    y = np.asarray(b[a0:b0], dtype=np.float64)
    if np.std(x) < 1e-6 or np.std(y) < 1e-6:
        return 0
    N = 1 << int(np.ceil(np.log2(len(x) + len(y))))
    c = np.fft.irfft(np.fft.rfft(y, N) * np.conj(np.fft.rfft(x, N)), N)
    lagi = np.arange(-(i0 - a0), (b0 - a0) - L - (i0 - a0) + 1)
    wart = c[(lagi + (i0 - a0)) % N]
    k = int(np.argmax(np.abs(wart)))
    norm = abs(wart[k]) / (np.linalg.norm(x) * np.linalg.norm(np.asarray(b[i0:i0 + L], dtype=np.float64)) + 1e-12)
    return int(lagi[k]) if norm > 0.2 else 0


def przesun(raw, lag, ch=1):
    """Cofa dźwięk o lag próbek (usuwa opóźnienie filtra), długość bez zmian."""
    if not lag:
        return
    x = czytaj(raw, ch, "r+")
    if lag > 0:
        x[:-lag] = x[lag:].copy() if len(x) < SR * 600 else _kopiuj_kawalkami(x, lag)
        x[-lag:] = 0
    else:
        x[-lag:] = x[:lag].copy()
        x[:-lag] = 0
    x.flush()


def _kopiuj_kawalkami(x, lag):
    krok = SR * 30
    for a in range(0, len(x) - lag, krok):
        b = min(len(x) - lag, a + krok)
        x[a:b] = x[a + lag:b + lag]
    return x[:-lag]


def filtruj(wej, cel, filtr, ch=1, cwd=None, opis="filtr", kompensuj=True):
    """Surowe -> filtr ffmpeg -> surowe, z zachowaniem liczby próbek i bez przesunięcia w czasie
    (niektóre filtry, np. afftdn, opóźniają dźwięk o kilkadziesiąt ms: mierzymy to i cofamy)."""
    n = probki(wej, ch)
    ffmpeg([*surowe_we(ch), "-i", Path(wej).resolve(), "-af", filtr, "-f", "f32le", "-ac", ch, "-ar", SR, Path(cel).resolve()], opis, cwd=cwd)
    dopasuj(cel, n, ch)
    if kompensuj:
        k0 = lambda x: x if x.ndim == 1 else x[:, 0]  # noqa: E731  (pierwszy kanał wystarczy, bez kopii całości)
        lag = opoznienie(k0(czytaj(wej, ch)), k0(czytaj(cel, ch)))
        przesun(cel, lag, ch)
    return cel


def do_wav(raw, wav, ch=1, ch_wy=None):
    ffmpeg([*surowe_we(ch), "-i", raw, "-ac", ch_wy or ch, "-c:a", "pcm_s24le", wav], "zapis WAV")


def glosnosc(raw, ch=1, tp=False):
    """Głośność zintegrowana (LUFS) i opcjonalnie true peak (dBTP) przez ebur128 w ffmpeg."""
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-nostdin", *map(str, surowe_we(ch)), "-i", str(raw), "-af",
                        "ebur128=framelog=quiet" + (":peak=true" if tp else ""), "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    m = re.findall(r"I:\s+(-?[\d.]+) LUFS", r.stderr)
    i = float(m[-1]) if m else -70.0
    i = i if i > -69 else None
    if not tp:
        return i
    p = re.findall(r"Peak:\s+(-?[\d.]+|-inf) dBFS", r.stderr)
    return i, (float(p[-1]) if p and p[-1] != "-inf" else None)


# ---------- obwiednie ----------
def ramki_db(x, hop=0.01, okno=0.03):
    """Poziom w dB co `hop` sekund (średnia moc w oknie `okno`). x: jednokanałowe (może być memmap)."""
    h = int(SR * hop)
    n = len(x) // h
    if n == 0:
        return np.full(1, -120.0)
    moc = np.empty(n, dtype=np.float64)
    krok = h * 20000
    for a in range(0, n * h, krok):
        b = min(n * h, a + krok)
        c = np.asarray(x[a:b], dtype=np.float32)
        moc[a // h:b // h] = np.square(c).reshape(-1, h).mean(axis=1)
    k = max(1, int(round(okno / hop)))
    if k > 1:
        moc = np.convolve(moc, np.ones(k) / k, mode="same")
    return 10 * np.log10(moc + 1e-12)


def mono_z(x):
    return x if x.ndim == 1 else x.mean(axis=1)


def wygladz(g, a_gora, a_dol):
    """Jednobiegunowe wygładzanie z innym czasem w górę i w dół (a = współczynnik na ramkę)."""
    out = np.empty_like(g)
    v = g[0] if len(g) else 0.0
    for i, x in enumerate(g):
        a = a_gora if x > v else a_dol
        v = a * v + (1 - a) * x
        out[i] = v
    return out


def wygladz_obustronnie(g, tau_ramek):
    a = math.exp(-1.0 / max(1e-3, tau_ramek))
    f = wygladz(g, a, a)
    return wygladz(f[::-1], a, a)[::-1]


def rozszerz(maska, w_przod, w_tyl):
    """Rozszerza aktywne fragmenty maski o w_przod ramek przed i w_tyl ramek po."""
    if not maska.any():
        return maska
    idx = np.flatnonzero(np.diff(np.r_[0, maska.astype(np.int8), 0]))
    pocz, kon = idx[::2], idx[1::2]
    out = np.zeros_like(maska)
    for a, b in zip(pocz, kon):
        out[max(0, a - w_przod):min(len(maska), b + w_tyl)] = True
    return out


def zamknij_przerwy(maska, max_przerwa, min_dl=0):
    m = maska.copy()
    idx = np.flatnonzero(np.diff(np.r_[0, m.astype(np.int8), 0]))
    pocz, kon = idx[::2], idx[1::2]
    for k in range(len(pocz) - 1):
        if pocz[k + 1] - kon[k] <= max_przerwa:
            m[kon[k]:pocz[k + 1]] = True
    if min_dl:
        idx = np.flatnonzero(np.diff(np.r_[0, m.astype(np.int8), 0]))
        for a, b in zip(idx[::2], idx[1::2]):
            if b - a < min_dl:
                m[a:b] = False
    return m


def mnoz_obwiednia(raw, g_ramki, hop, ch=1, raw_wyj=None):
    """Mnoży dźwięk przez obwiednię wzmocnienia (liniową) podaną co `hop` sekund, interpolowaną do próbek."""
    x = czytaj(raw, ch, "r" if raw_wyj else "r+")
    y = x if raw_wyj is None else nowy_raw(raw_wyj, len(x), ch)
    h = SR * hop
    t_r = (np.arange(len(g_ramki)) + 0.5) * h
    krok = SR * 30
    for a in range(0, len(x), krok):
        b = min(len(x), a + krok)
        g = np.interp(np.arange(a, b), t_r, g_ramki).astype(np.float32)
        y[a:b] = x[a:b] * (g[:, None] if ch > 1 else g)
    y.flush()
    del y
    return raw_wyj or raw


# ---------- diagnoza mowy ----------
TERCJE = np.array([100, 125, 160, 200, 250, 315, 400, 500, 630, 800, 1000, 1250, 1600, 2000, 2500, 3150, 4000, 5000, 6300, 8000, 10000, 12500], float)


def _okno(n):
    return np.hanning(n + 1)[:-1].astype(np.float32)  # okno Hanna (okresowe)


def _psd(x, nper=4096):
    """Średnie widmo mocy (metoda Welcha: ramki z oknem Hanna, zakładka 50%)."""
    x = np.asarray(x, dtype=np.float32)
    nper = int(min(nper, 1 << int(np.log2(max(256, len(x))))))
    w = _okno(nper)
    hop = nper // 2
    n_fr = max(1, 1 + (len(x) - nper) // hop)
    if len(x) < nper:
        x = np.r_[x, np.zeros(nper - len(x), np.float32)]
    acc = np.zeros(nper // 2 + 1)
    for a in range(0, n_fr, 256):
        b = min(n_fr, a + 256)
        idx = np.arange(nper)[None, :] + hop * np.arange(a, b)[:, None]
        acc += (np.abs(np.fft.rfft(x[idx] * w, axis=1)) ** 2).sum(axis=0)
    p = acc / (n_fr * SR * float((w ** 2).sum()))
    p[1:-1] *= 2
    return np.fft.rfftfreq(nper, 1 / SR), p


def stft(x, nfft, hop):
    """Widmo krótkoczasowe (F x T); brzegi odbite, żeby początek i koniec były obrobione jak środek."""
    x = np.asarray(x, dtype=np.float32)
    w = _okno(nfft)
    xp = np.pad(x, (nfft // 2, nfft // 2 + hop), mode="reflect")
    n_fr = 1 + (len(xp) - nfft) // hop
    Y = np.empty((nfft // 2 + 1, n_fr), dtype=np.complex64)
    for a in range(0, n_fr, 512):
        b = min(n_fr, a + 512)
        idx = np.arange(nfft)[None, :] + hop * np.arange(a, b)[:, None]
        Y[:, a:b] = np.fft.rfft(xp[idx] * w, axis=1).T
    return Y


def istft(Y, nfft, hop, n):
    """Odwrotność stft(): nakładanie ramek z tym samym oknem i normalizacją, wynik o długości n."""
    w = _okno(nfft)
    T = Y.shape[1]
    dl = nfft + hop * (T - 1)
    out = np.zeros(dl, np.float32)
    norm = np.zeros(dl, np.float32)
    for a in range(0, T, 512):
        b = min(T, a + 512)
        fr = np.fft.irfft(Y[:, a:b].T, n=nfft, axis=1).astype(np.float32) * w
        for k in range(b - a):
            i = (a + k) * hop
            out[i:i + nfft] += fr[k]
            norm[i:i + nfft] += w * w
    out /= np.maximum(norm, 1e-6)
    out = out[nfft // 2:nfft // 2 + n]
    return np.r_[out, np.zeros(n - len(out), np.float32)] if len(out) < n else out


def fragment_mowy(x, env, hop=0.01, ile_s=90, prog=None):
    """Sklejone fragmenty z mową (głośne ramki), do pomiarów widma."""
    if prog is None:
        prog = np.percentile(env, 70)
    akt = zamknij_przerwy(env > prog, 5, 10)
    h = int(SR * hop)
    kaw = []
    suma = 0
    idx = np.flatnonzero(np.diff(np.r_[0, akt.astype(np.int8), 0]))
    for a, b in zip(idx[::2], idx[1::2]):
        kaw.append(np.asarray(x[a * h:b * h], dtype=np.float32))
        suma += (b - a) * h
        if suma > ile_s * SR:
            break
    return np.concatenate(kaw) if kaw else np.asarray(x[:SR * 10], dtype=np.float32)


def fragment_cichy(x, env, hop=0.01, ile_s=30):
    prog = np.percentile(env, 25)
    akt = env <= prog
    h = int(SR * hop)
    sel = np.flatnonzero(akt)[: int(ile_s / hop)]
    if len(sel) < 20:
        return None
    return np.concatenate([np.asarray(x[i * h:(i + 1) * h], dtype=np.float32) for i in sel])


def barwa_mowy(x_mowa):
    """Widmo mowy w pasmach tercjowych (dB)."""
    f, p = _psd(x_mowa)
    out = []
    for fc in TERCJE:
        a, b = fc / 2 ** (1 / 6), fc * 2 ** (1 / 6)
        sel = (f >= a) & (f < b)
        out.append(10 * np.log10(p[sel].mean() + 1e-20) if sel.any() else -120)
    return np.array(out)


def _pasmo(barwa, a, b):
    sel = (TERCJE >= a) & (TERCJE <= b)
    return 10 * np.log10(np.mean(10 ** (barwa[sel] / 10)) + 1e-20)


def buczenie(x_cichy, x_mowa=None):
    """Szuka buczenia sieci 50/60 Hz (i harmonicznych) w cichych miejscach. -> (f0, [harmoniczne], siła dB)"""
    probka = x_cichy if x_cichy is not None and len(x_cichy) > SR * 2 else x_mowa
    if probka is None or len(probka) < SR:
        return None, [], 0.0
    f, p = _psd(probka, nper=min(len(probka), 65536))
    df = f[1] - f[0]
    najlepsze = (None, [], 0.0)
    for f0 in (50.0, 60.0):
        harm, sily = [], []
        for k in range(1, 9):
            fk = f0 * k
            if fk > 1000:
                break
            i = int(round(fk / df))
            szczyt = p[max(0, i - 2):i + 3].max()
            sasiad = np.r_[p[max(0, i - int(12 / df)):max(0, i - int(4 / df))], p[i + int(4 / df):i + int(12 / df)]]
            if not len(sasiad):
                continue
            prom = 10 * np.log10((szczyt + 1e-20) / (np.median(sasiad) + 1e-20))
            if prom > 8:
                harm.append(float(fk))
                sily.append(float(prom))
        sila = float(np.mean(sorted(sily)[-3:])) if sily else 0.0
        if len(harm) >= 2 and sila > najlepsze[2]:
            najlepsze = (f0, harm, sila)
    return najlepsze


def przestery(x):
    """Miejsca z obciętymi szczytami: co najmniej 4 próbki z rzędu „przyklejone” do tego samego maksimum
    (płaski szczyt). -> lista (od_s, do_s); pusta, gdy płaskich szczytów jest mniej niż 2."""
    wyn = []
    krok = SR * 30
    szczyt = 0.0
    for a in range(0, len(x), krok):
        szczyt = max(szczyt, float(np.abs(np.asarray(x[a:a + krok])).max(initial=0)))
    if szczyt < 0.1:
        return wyn
    prog = szczyt - max(2e-4, szczyt * 2e-3)
    runow = 0
    for a in range(0, len(x), krok):
        c = np.abs(np.asarray(x[a:a + krok], dtype=np.float32)) >= prog
        if not c.any():
            continue
        d = np.diff(np.r_[0, c.astype(np.int8), 0])
        st, kn = np.flatnonzero(d == 1), np.flatnonzero(d == -1)
        for s_, k_ in zip(st, kn):
            if k_ - s_ >= 4:
                runow += 1
                t = (a + s_) / SR
                if wyn and t - wyn[-1][1] < 0.3:
                    wyn[-1] = (wyn[-1][0], (a + k_) / SR)
                else:
                    wyn.append((float(t), float((a + k_) / SR)))
    return wyn if runow >= 2 else []


def poglos_s(env, szum_db, hop=0.01):
    """Szacowany czas pogłosu (RT60, s) z najszybszych spadków głośności po końcach sylab.
    W suchym nagraniu dźwięk po sylabie gaśnie bardzo szybko; w pogłosie gaśnie najwyżej tak szybko jak echo pokoju."""
    w = 5  # 50 ms
    nach = []
    gora = np.percentile(env, 95)
    for i in range(0, len(env) - w):
        a, b = env[i], env[i + w]
        if a > szum_db + 25 and a > gora - 30 and b > szum_db + 6:
            nach.append((b - a) / (w * hop))
    if len(nach) < 30:
        return None
    najszybszy = np.percentile(nach, 2)  # dB/s (ujemne)
    if najszybszy >= -1:
        return None
    return float(min(3.0, 60.0 / -najszybszy))


def diagnoza(x):
    """x: mowa, jeden kanał 48 kHz (np. memmap). Zwraca pomiary i propozycje ustawień (0 wył … 3 mocno)."""
    env = ramki_db(x)
    env_g = env[env > -100]
    if len(env_g) < 100:
        return {"cisza": True}
    szum = float(np.percentile(env_g, 10))
    mowa = float(np.percentile(env_g, 95))
    snr = mowa - szum
    xm = fragment_mowy(x, env)
    xc = fragment_cichy(x, env)
    f0, harm, sila_b = buczenie(xc, xm)
    prz = przestery(x)
    rt = poglos_s(env, szum)
    bw = barwa_mowy(xm)
    sycz = _pasmo(bw, 5000, 8000) - _pasmo(bw, 1000, 2500)
    minuty = max(len(x) / SR / 60, 0.1)
    rek = {
        "odszumianie": 0 if szum < -72 or snr > 55 else 1 if snr > 42 else 2 if snr > 28 else 3,
        "poglos": 0 if rt is None or rt < 0.3 else 1 if rt < 0.45 else 2 if rt < 0.7 else 3,
        "buczenie": 2 if f0 else 0,
        "przester": 2 if len(prz) >= 1 else 0,
        "deesser": 0 if sycz < -14 else 1 if sycz < -10 else 2 if sycz < -6 else 3,
        "bramka": 0 if szum < -70 else 1 if snr > 35 else 2,
        "barwa": 2, "kompresja": 2, "wyrownanie": 2,
    }
    rek = {k: int(v) for k, v in rek.items()}
    return {"szum_db": round(szum, 1), "mowa_db": round(mowa, 1), "snr_db": round(snr, 1), "buczenie_hz": f0, "buczenie_harm": harm,
            "buczenie_db": round(sila_b, 1), "przestery": len(prz), "przestery_min": round(len(prz) / minuty, 1),
            "przestery_miejsca": prz[:200], "poglos_s": round(rt, 2) if rt else None, "syczenie_db": round(float(sycz), 1),
            "barwa": [round(float(v), 1) for v in bw], "rekomendacja": rek}


# ---------- kroki obróbki mowy ----------
def filtr_buczenia(f0, harm, poziom):
    if not f0 or not poziom:
        return None
    q = {1: 40, 2: 25, 3: 15}[poziom]
    lista = sorted(set(harm) | {f0, f0 * 2, f0 * 3})
    return ",".join(f"bandreject=f={f:g}:width_type=q:w={q}" for f in lista if f < 1200)


def napraw_przestery(raw, miejsca):
    """Odbudowa obciętych szczytów: w każdym płaskim fragmencie krzywa (wielomian) dopasowana do próbek przed i po
    przesterze odtwarza szczyt fali (najwyżej 3 razy ponad poziom obcięcia). Tylko wokół wykrytych miejsc."""
    if not miejsca:
        return 0
    x = czytaj(raw, 1, "r+")
    zrobione = 0
    for a, b in miejsca:
        i0, j0 = max(0, int((a - 0.05) * SR)), min(len(x), int((b + 0.05) * SR))
        if j0 - i0 < 16:
            continue
        seg = np.array(x[i0:j0], dtype=np.float64)
        szczyt = np.abs(seg).max()
        prog = szczyt - max(2e-4, szczyt * 2e-3)
        c = np.abs(seg) >= prog
        d = np.diff(np.r_[0, c.astype(np.int8), 0])
        st, kn = np.flatnonzero(d == 1), np.flatnonzero(d == -1)
        zmiana = False
        for s_, k_ in zip(st, kn):
            dl = k_ - s_
            if dl < 2 or dl > int(0.004 * SR) or s_ < 8 or k_ + 8 > len(seg):
                continue
            ok = np.r_[np.arange(s_ - 8, s_), np.arange(k_, k_ + 8)]
            ok = ok[~c[ok]]
            if len(ok) < 6:
                continue
            sr_ = (s_ + k_) / 2.0
            wsp = np.polyfit(ok - sr_, seg[ok], 3)
            nowe = np.polyval(wsp, np.arange(s_, k_) - sr_)
            znak = np.sign(seg[s_:k_].mean())
            nowe = znak * np.clip(np.abs(nowe), prog, 3 * prog)
            seg[s_:k_] = nowe
            zmiana = True
        if zmiana:
            x[i0:j0] = seg.astype(np.float32)
            zrobione += 1
    x.flush()
    return zrobione


def filtr_odszumiania(poziom, szum_db, ai=True):
    """Sieć neuronowa RNNoise (model „beguiling-drafter”: głos z szumem nagrania) + odszumianie widmowe afftdn.
    Zmierzone na próbkach: lekko ok. 9 dB mniej szumu, średnio ok. 14 dB, mocno ok. 20–24 dB, głos bez zmian głośności.
    afftdn liczy próg szumu w swojej skali: ok. 24 dB nad zmierzonym poziomem szumu w ciszy."""
    if not poziom:
        return None, None
    nf = max(-80, min(-20, round(szum_db + 24)))
    jest_model = ai and (MODELE / "bd.rnnn").exists()
    if poziom == 1 or not jest_model:
        nr = {1: 10, 2: 16, 3: 24}[poziom]
        return f"afftdn=nr={nr}:nf={nf}", None
    mix, nr = {2: (0.7, 8), 3: (1.0, 14)}[poziom]
    return f"arnndn=m=bd.rnnn:mix={mix},afftdn=nr={nr}:nf={nf}", str(MODELE)


def po_blokach(raw, funkcja, blok_s=8.0, zakl_s=1.0):
    """Przetwarza długie nagranie blokami z zakładką (płynne przejście liniowe na zakładce, wagi sumują się do 1).
    Wynik trafia do osobnego pliku (czytamy zawsze oryginał), potem zastępuje raw. Pamięć: tylko jeden blok."""
    x = czytaj(raw, 1)
    n = len(x)
    cel = Path(str(raw) + ".blk")
    y = nowy_raw(cel, n, 1)
    blok, z = int(blok_s * SR), int(zakl_s * SR)
    start = 0
    while start < n:
        a = start
        b = min(n, start + blok + z)
        seg = np.asarray(x[a:b], dtype=np.float32)
        out = funkcja(seg)
        w = np.ones(len(seg), np.float32)
        if a > 0:
            w[:z] = np.linspace(0, 1, z, endpoint=False, dtype=np.float32)
        if b < n:
            w[-z:] = 1 - np.linspace(0, 1, z, endpoint=False, dtype=np.float32)
        y[a:b] += out[:len(seg)] * w
        start += blok
    y.flush()
    del y, x
    gc.collect()
    os.replace(cel, raw)


def wpe(raw, sila, poziom, ustawienia=None):
    """Usuwanie pogłosu metodą WPE (Nakatani i in.): w każdym paśmie częstotliwości przewiduje echo z wcześniejszych
    ramek i je odejmuje. Bloki po 8 s z zakładką 1 s. sila 0–1: ile echa odjąć."""
    if sila <= 0:
        return
    taps = {1: 8, 2: 10, 3: 14}[poziom]
    delay, iters, nfft, hop = 3, 3, 1024, 256
    if ustawienia:
        taps, delay, iters, nfft, hop = ustawienia

    def jeden(seg):
        if len(seg) < nfft * 4:
            return seg
        Y = stft(seg, nfft, hop)
        F, T = Y.shape
        Yt = np.zeros((F, taps, T), dtype=np.complex64)
        for k in range(taps):
            d = delay + k
            if d < T:
                Yt[:, k, d:] = Y[:, :T - d]
        D = Y
        eye = np.eye(taps, dtype=np.complex64)[None]
        for _ in range(iters):
            lam = np.abs(D) ** 2
            lam = (np.roll(lam, 1, axis=1) + lam + np.roll(lam, -1, axis=1)) / 3
            lam = np.maximum(lam, lam.max(axis=1, keepdims=True) * 1e-4 + 1e-12).astype(np.float32)
            Ytw = Yt / lam[:, None, :]
            R = Ytw @ np.conj(Yt).transpose(0, 2, 1)
            P = Ytw @ np.conj(Y)[:, :, None]
            tr = np.real(np.trace(R, axis1=1, axis2=2))[:, None, None] / taps
            G = np.linalg.solve(R + eye * (tr * 1e-3 + 1e-9), P)
            echo = (np.conj(G).transpose(0, 2, 1) @ Yt)[:, 0, :]
            D = Y - echo
        Z = Y - sila * (Y - D)
        return istft(Z, nfft, hop, len(seg))

    po_blokach(raw, jeden, 8.0, 1.0)


def poglos_widmowy(raw, rt60, beta, zakres_db):
    """Wygaszanie ogona pogłosu (metoda Lebarta): ogon to przygaszona kopia dźwięku sprzed ok. 50 ms
    (gaśnie z prędkością zależną od czasu pogłosu pokoju); tam, gdzie ogon przeważa nad głosem, pasmo jest przyciszane
    (najwyżej o zakres_db), a wzmocnienie jest wygładzane, żeby nie było „bulgotania”."""
    rt60 = float(min(2.0, max(0.25, rt60 or 0.5)))
    nfft, hop = 1024, 256
    T_l = 0.05
    d = int(round(T_l * SR / hop))
    delta = 3 * math.log(10) / rt60
    tlum = math.exp(-2 * delta * T_l)
    g_min = 10 ** (-zakres_db / 20)
    a_cz = 0.5  # wygładzanie mocy w czasie

    def jeden(seg):
        if len(seg) < nfft * 4:
            return seg
        Y = stft(seg, nfft, hop)
        P = (np.abs(Y) ** 2).astype(np.float32)
        Ps = np.empty_like(P)
        Ps[:, 0] = P[:, 0] * (1 - a_cz)
        for k in range(1, P.shape[1]):
            Ps[:, k] = a_cz * Ps[:, k - 1] + (1 - a_cz) * P[:, k]
        late = np.zeros_like(Ps)
        late[:, d:] = tlum * Ps[:, :-d]
        G = np.clip(1 - beta * late / (Ps + 1e-12), g_min, 1.0)
        G = (np.roll(G, 1, 0) + G + np.roll(G, -1, 0)) / 3
        G = (np.roll(G, 1, 1) + 2 * G + np.roll(G, -1, 1)) / 4
        return istft(Y * G, nfft, hop, len(seg))

    po_blokach(raw, jeden, 10.0, 1.0)


def eq_dopasowania(barwa_wlasna, barwa_cel, sila):
    """Krzywa korekcji (dB na tercję), żeby mikrofon brzmiał jak cel; wygładzona i ograniczona do ±6 dB."""
    d = (np.asarray(barwa_cel) - np.asarray(barwa_wlasna))
    d -= np.average(d, weights=np.where((TERCJE >= 300) & (TERCJE <= 3000), 1.0, 0.2))  # bez zmiany głośności
    d = np.convolve(np.r_[d[0], d, d[-1]], np.ones(3) / 3, mode="valid")
    return np.clip(d * sila, -6, 6)


def eq_mowy(barwa, poziom):
    """Korekcja mowy według pomiaru: mniej dudnienia, więcej czytelności i powietrza (tylko gdy trzeba)."""
    if not poziom:
        return np.zeros(len(TERCJE))
    s = {1: 0.5, 2: 0.8, 3: 1.1}[poziom]
    srodek = _pasmo(barwa, 1000, 2000)
    g = np.zeros(len(TERCJE))
    bud = _pasmo(barwa, 200, 400) - srodek
    if bud > 5:
        g += np.where((TERCJE >= 160) & (TERCJE <= 500), -min(4.5, (bud - 5) * 0.6 + 1.5) * s, 0)
    obec = _pasmo(barwa, 2500, 5000) - srodek
    if obec < -7:
        g += np.where((TERCJE >= 2000) & (TERCJE <= 5000), min(4.0, (-7 - obec) * 0.5 + 1.0) * s, 0)
    pow_ = _pasmo(barwa, 8000, 12500) - srodek
    if pow_ < -18:
        g += np.where(TERCJE >= 8000, min(3.0, (-18 - pow_) * 0.3 + 0.5) * s, 0)
    return g


def filtr_eq(krzywa):
    if krzywa is None or not np.any(np.abs(krzywa) > 0.2):
        return None
    wpisy = ";".join(f"entry({f:g},{g:.2f})" for f, g in zip(TERCJE, krzywa))
    wpisy = f"entry(20,{krzywa[0]:.2f});" + wpisy + f";entry(20000,{krzywa[-1]:.2f})"
    return f"firequalizer=gain_entry='{wpisy}':zero_phase=on:delay=0.05"


def filtr_deessera(poziom):
    if not poziom:
        return None
    i, m = {1: (0.25, 0.35), 2: (0.45, 0.5), 3: (0.65, 0.7)}[poziom]
    return f"deesser=i={i}:m={m}:f=0.5"


FILTR_K = "highshelf=f=1681:g=4:t=q:w=0.707,highpass=f=38:p=2"  # ważenie K (jak w pomiarze LUFS)


def glosnosc_krotka(raw, ch=1, hop=0.05, okno=0.4):
    """Głośność krótkoterminowa (ważenie K jak w LUFS) co `hop` s."""
    kw = Path(str(raw) + ".k")
    filtruj(raw, kw, FILTR_K, ch=ch, opis="ważenie K", kompensuj=False)
    x = czytaj(kw, ch)
    h = int(SR * hop)
    n = len(x) // h
    moc = np.zeros(max(n, 1))
    krok = h * 600
    for a in range(0, n * h, krok):
        b = min(n * h, a + krok)
        blok = np.asarray(x[a:b], dtype=np.float32)
        kw2 = (blok * blok) if ch == 1 else (blok * blok).sum(axis=1)
        moc[a // h:b // h] = kw2.reshape(-1, h).mean(axis=1)
    del x
    gc.collect()
    try:
        kw.unlink()
    except OSError:
        pass
    k = max(1, int(round(okno / hop)))
    moc = np.convolve(moc, np.ones(k) / k, mode="same")
    return -0.691 + 10 * np.log10(moc + 1e-12)


def wyrownaj(raw, poziom, cel_lufs=-20.0, przebicia=None):
    """Leveler mowy: frazy do podobnej głośności (jak Dialogue Leveler). Cisza nie jest podbijana.
    przebicia: maska co 10 ms, gdzie ten mikrofon słyszy tylko innego mówcę (tam nic nie podbijamy)."""
    if not poziom:
        return None
    zakres, sila, tau = {1: (6, 0.5, 8), 2: (10, 0.75, 6), 3: (14, 0.95, 5)}[poziom]
    hop = 0.05
    L = glosnosc_krotka(raw, hop=hop, okno=0.8)
    Ls = glosnosc_krotka(raw, hop=hop, okno=hop)  # krótkie okna: szum w przerwach między słowami
    Lg = L[L > -90]
    Lsg = Ls[Ls > -90]
    if len(Lg) < 20 or len(Lsg) < 20:
        return None
    szum = np.percentile(Lsg, 10)
    akt = (L > max(szum + 8, -55)) & (L > np.percentile(Lg, 95) - 25)
    if akt.sum() < 10:
        return None
    if przebicia is not None and len(przebicia):
        k = int(round(hop / 0.01))
        pb = np.zeros(len(L), bool)
        m = przebicia[:len(L) * k]
        pb[:len(m) // k] = m[:len(m) // k * k].reshape(-1, k).mean(axis=1) > 0.5
        akt &= ~pb
    if akt.sum() < 10:
        return None
    g = np.full(len(L), np.nan)
    g[akt] = np.clip((cel_lufs - L[akt]) * sila, -zakres, zakres)
    # poza mową trzymamy wzmocnienie sąsiednich fraz, ale nie podbijamy ciszy powyżej 0 dB ponad otoczenie
    i = np.arange(len(g))
    gi = np.interp(i, i[akt], g[akt])
    gi = np.where(akt, gi, np.minimum(gi, np.maximum(0.0, gi) * 0.5))
    if przebicia is not None and len(przebicia):
        gi = np.where(pb, np.minimum(gi, 0.0), gi)
    gi = wygladz_obustronnie(gi, tau)
    mnoz_obwiednia(raw, (10 ** (gi / 20)).astype(np.float32), hop)
    return {"min_db": round(float(gi.min()), 1), "max_db": round(float(gi.max()), 1)}


def filtr_kompresji(poziom, glos_db=None):
    """Kompresor mowy z progiem względem zmierzonego poziomu głosu (glos_db: 95. percentyl poziomu w dB):
    na najgłośniejszych sylabach ok. 3 / 6 / 9 dB przyciszenia (lekko / średnio / mocno)."""
    if not poziom:
        return None
    pod, ratio = {1: (6, 2), 2: (9, 3), 3: (12, 4)}[poziom]
    prog = (glos_db - pod) if glos_db is not None else {1: -22, 2: -24, 3: -27}[poziom]
    prog = max(-50.0, min(-6.0, prog))
    return f"acompressor=threshold={prog:.1f}dB:ratio={ratio}:attack=8:release=160:knee=4:makeup=1:detection=rms"


def poziom_glosu(raw):
    e = ramki_db(czytaj(raw), hop=0.01, okno=0.03)
    e = e[e > -100]
    return float(np.percentile(e, 95)) if len(e) > 50 else None


def bramka(raw, poziom, przebicia=None):
    """Ekspander: przycisza tło między słowami. Otwiera się 15 ms przed głosem, trzyma 150 ms, zamyka w 120 ms.
    przebicia: maska co 10 ms, gdzie ten mikrofon słyszy tylko innego mówcę: tam bramka też przycisza."""
    if not poziom:
        return None
    zasieg = {1: 8, 2: 14, 3: 24}[poziom]
    hop = 0.005
    x = czytaj(raw)
    env = ramki_db(x, hop=hop, okno=0.015)
    eg = env[env > -110]
    if len(eg) < 100:
        return None
    szum, glos = np.percentile(eg, 10), np.percentile(eg, 95)
    if glos - szum < 12:
        return None
    prog = szum + max(6.0, 0.3 * (glos - szum))
    otw = env > prog
    pb = None
    if przebicia is not None and len(przebicia):
        pb = np.repeat(np.asarray(przebicia, bool), 2)[:len(env)]
        pb = np.r_[pb, np.zeros(len(env) - len(pb), bool)]
        otw &= ~pb
    otw = rozszerz(otw, 3, 30)           # 15 ms przed, 150 ms po
    otw = zamknij_przerwy(otw, 40)       # przerwy krótsze niż 200 ms zostają otwarte
    if pb is not None:
        otw &= ~(pb & ~rozszerz(env > prog + 10, 3, 30))
    # miękko: tuż pod progiem przyciszamy mniej (ekspander, nie twarda bramka)
    pod = np.clip((prog - env) / 10.0, 0, 1)
    g_db = np.where(otw, 0.0, -zasieg * pod)
    if pb is not None:  # cudzy głos w tym mikrofonie: przyciszony mocniej (co najmniej 15 dB)
        g_db = np.where(otw, 0.0, np.where(pb, -max(zasieg, 15), g_db))
    g = 10 ** (g_db / 20)
    a_otw, a_zam = math.exp(-1 / 0.6), math.exp(-1 / 24)  # 3 ms / 120 ms przy kroku 5 ms
    g = wygladz(g, a_otw, a_zam)
    mnoz_obwiednia(raw, g.astype(np.float32), hop)
    if pb is not None:
        sygnal = env > -100
        proc = float((pb & sygnal).sum()) / max(1, int(sygnal.sum())) * 100
    else:
        proc = 0
    return {"prog_db": round(float(prog), 1), "zasieg_db": zasieg, "przebicia_proc": round(proc)}


# ---------- muzyka pod mową ----------
def aktywnosc_mowy(raw_mowa, hop=0.01):
    """Maska mowy (0–1) co `hop` s: z wyprzedzeniem 0,25 s, puszczana 0,6 s po frazie, krótkie pauzy wypełnione."""
    x = czytaj(raw_mowa)
    env = ramki_db(x, hop=hop, okno=0.05)
    eg = env[env > -110]
    if len(eg) < 50:
        return np.zeros(len(env), np.float32)
    prog = max(np.percentile(eg, 97) - 28, np.percentile(eg, 10) + 10, -55)
    m = env > prog
    m = zamknij_przerwy(m, int(0.7 / hop), int(0.12 / hop))
    m = rozszerz(m, int(0.25 / hop), int(0.6 / hop))
    k = int(0.3 / hop)
    okno = np.hanning(2 * k + 1)
    okno /= okno.sum()
    return np.clip(np.convolve(m.astype(np.float32), okno, mode="same"), 0, 1).astype(np.float32)


def wycisz_pod_mowa(raw, maska, duck_db, hop=0.01, ch=2, raw_rzezba=None):
    """Ściszanie (ducking) obwiednią mowy; raw_rzezba = ta sama ścieżka z wyciętym pasmem mowy (miejsce dla głosu),
    wmiksowywana tylko tam, gdzie ktoś mówi."""
    x = czytaj(raw, ch, "r+")
    r = czytaj(raw_rzezba, ch) if raw_rzezba else None
    h = SR * hop
    t_r = (np.arange(len(maska)) + 0.5) * h
    krok = SR * 30
    g_min = 10 ** (-duck_db / 20)
    for a in range(0, len(x), krok):
        b = min(len(x), a + krok)
        m = np.interp(np.arange(a, b), t_r, maska).astype(np.float32)[:, None]
        blok = np.asarray(x[a:b], dtype=np.float32)
        if r is not None:
            blok = blok * (1 - m) + np.asarray(r[a:b], dtype=np.float32) * m
        x[a:b] = blok * (1 - m * (1 - g_min))
    x.flush()


def ustaw_glosnosc(raw, cel, ch, korekta=0.0):
    zm = glosnosc(raw, ch)
    if zm is None:
        return None
    zysk = cel - zm + korekta
    x = czytaj(raw, ch, "r+")
    k = np.float32(10 ** (zysk / 20))
    krok = SR * 30
    for a in range(0, len(x), krok):
        x[a:a + krok] = x[a:a + krok] * k
    x.flush()
    return zysk


def maski_przebic(raws):
    """Dla kilku mikrofonów: maska (co 10 ms) miejsc, gdzie inny mikrofon jest o 8 dB głośniejszy,
    czyli ten słyszy tylko przebicie cudzego głosu."""
    if len(raws) < 2:
        return [None] * len(raws)
    env = [ramki_db(czytaj(r), hop=0.01, okno=0.05) for r in raws]
    n = min(len(e) for e in env)
    env = np.array([e[:n] for e in env])
    wyn = []
    for i in range(len(raws)):
        inni = np.delete(env, i, axis=0).max(axis=0)
        m = (inni > env[i] + 8) & (inni > -50)
        m = zamknij_przerwy(m, 10, 8)
        wyn.append(m)
    return wyn
