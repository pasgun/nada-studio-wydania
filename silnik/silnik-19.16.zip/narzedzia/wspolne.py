"""Wspólne funkcje dla narzędzi silnika: klucze z .env, zapytania HTTP, pobieranie plików."""
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import sciezki  # noqa: E402,F401  programy z apki Nada Studio w PATH

try:
    import requests
except ImportError:  # czytelny komunikat zamiast stack trace
    sys.exit("Brak biblioteki 'requests'. Uruchom: python -m pip install -r requirements.txt")

KATALOG_SILNIKA = Path(__file__).resolve().parent.parent

# Polskie znaki w konsoli Windows
for _strumien in (sys.stdout, sys.stderr):
    try:
        _strumien.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass


def wczytaj_env():
    """Wczytuje klucze z pliku .env w folderze silnika (bez dodatkowych bibliotek)."""
    plik = KATALOG_SILNIKA / ".env"
    if not plik.exists():
        return
    for linia in plik.read_text(encoding="utf-8-sig").splitlines():
        linia = linia.strip()
        if not linia or linia.startswith("#") or "=" not in linia:
            continue
        klucz, wartosc = linia.split("=", 1)
        wartosc = wartosc.strip().strip('"').strip("'")
        if wartosc and klucz.strip() not in os.environ:
            os.environ[klucz.strip()] = wartosc


def klucz(nazwa):
    wczytaj_env()
    wartosc = os.environ.get(nazwa, "").strip()
    if not wartosc:
        blad(f"Brak klucza {nazwa} w pliku .env (folder silnika). Wklej go tam i spróbuj ponownie.")
    return wartosc


def higgsfield_dane(wymagane=True):
    """Dane logowania Higgsfield jako 'ID:SECRET'.

    Panel open.higgsfield.ai może pokazać jeden klucz (często już w postaci ID:SECRET)
    albo dwie osobne wartości. Obsługujemy oba warianty.
    """
    wczytaj_env()
    kid = os.environ.get("HIGGSFIELD_KEY_ID", "").strip()
    sec = os.environ.get("HIGGSFIELD_KEY_SECRET", "").strip()
    jeden = os.environ.get("HIGGSFIELD_API_KEY", "").strip()
    if kid and sec:
        return f"{kid}:{sec}"
    if jeden:
        return jeden
    if wymagane:
        blad("Brak klucza Higgsfield w .env. Wpisz HIGGSFIELD_API_KEY=klucz z open.higgsfield.ai "
             "(jeśli panel daje dwie wartości, wpisz je razem: ID:SECRET).")
    return ""


def blad(tekst, kod=1):
    print(json.dumps({"ok": False, "blad": tekst}, ensure_ascii=False))
    sys.exit(kod)


def wynik(**dane):
    print(json.dumps({"ok": True, **dane}, ensure_ascii=False, indent=2))


def zapytanie(metoda, url, *, naglowki=None, json_body=None, params=None, proby=3, timeout=120):
    """Zapytanie HTTP z ponawianiem przy chwilowych błędach (429, 5xx, zerwane połączenie)."""
    ostatni = None
    for proba in range(1, proby + 1):
        try:
            r = requests.request(metoda, url, headers=naglowki, json=json_body, params=params, timeout=timeout)
        except requests.RequestException as e:
            ostatni = f"Błąd połączenia: {e}"
            time.sleep(3 * proba)
            continue
        if r.status_code in (429, 500, 502, 503, 504):
            ostatni = f"HTTP {r.status_code}: {r.text[:300]}"
            time.sleep(5 * proba)
            continue
        if r.status_code >= 400:
            blad(f"HTTP {r.status_code} z {url.split('?')[0]}: {r.text[:600]}")
        return r
    blad(f"Serwis nie odpowiada po {proby} próbach. Ostatni błąd: {ostatni}")


def pobierz(url, cel, naglowki=None):
    cel = Path(cel)
    cel.parent.mkdir(parents=True, exist_ok=True)
    with requests.get(url, headers=naglowki, stream=True, timeout=300) as r:
        if r.status_code >= 400:
            blad(f"Nie udało się pobrać pliku ({r.status_code}): {url[:120]}")
        with open(cel, "wb") as f:
            for kawalek in r.iter_content(1 << 16):
                f.write(kawalek)
    return cel


def czekaj(funkcja_statusu, *, co_ile=4, limit_s=900, opis="zadanie"):
    """Odpytuje serwis aż zadanie się skończy. funkcja_statusu zwraca (gotowe: bool, dane)."""
    start = time.time()
    while True:
        gotowe, dane = funkcja_statusu()
        if gotowe:
            return dane
        if time.time() - start > limit_s:
            blad(f"{opis}: przekroczono limit czasu {limit_s // 60} min. Sprawdź panel serwisu.")
        time.sleep(co_ile)


def postep(tekst, ulamek=None):
    """Krótki komunikat o postępie (na stderr, żeby nie mieszał się z wynikiem JSON). Czyta go m.in. panel w Premiere.

    Gdy zadanie uruchomił panel (zmienna NM_POSTEP = ścieżka do postep.json), komunikat i ułamek (0–1, postęp
    w obecnym etapie) trafiają też do tego pliku: panel rysuje z niego pasek postępu i szacowany czas.
    """
    print(f"POSTEP: {tekst}", file=sys.stderr, flush=True)
    if ulamek is not None:
        print(f"POSTEP%: {max(0.0, min(1.0, float(ulamek))):.3f}", file=sys.stderr, flush=True)
    plik = os.environ.get("NM_POSTEP")
    if plik:
        zapisz_postep(plik, tekst=tekst, ulamek=ulamek)


def zapisz_postep(plik, **pola):
    """Dopisuje pola do postep.json (bez kasowania innych). Błędy zapisu ignoruje: postęp to tylko informacja."""
    import json as _json
    import time as _time
    try:
        p = Path(plik)
        dane = _json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
        for k, v in pola.items():
            if v is not None:
                dane[k] = v
        dane["aktualizacja"] = _time.time()
        tmp = p.with_suffix(".tmp")
        tmp.write_text(_json.dumps(dane, ensure_ascii=False, indent=1), encoding="utf-8")
        os.replace(tmp, p)
    except Exception:
        pass


def slug_zwarty(tekst, dlugosc=40):
    """„Emerald Media” -> „emeraldmedia”: małe litery i cyfry, bez polskich znaków, spacji i myślników."""
    import unicodedata
    t = unicodedata.normalize("NFD", str(tekst or "").replace("ł", "l").replace("Ł", "L")).encode("ascii", "ignore").decode().lower()
    return "".join(c for c in t if c.isalnum())[:dlugosc]


def folder_wynikow(klient, projekt, data=None, utworz=True, zadanie_id="", klient_folder="", panel=False):
    """Folder zadania: wyniki/<Klient>/<Tytuł zadania> (porządek opisany w narzedzia/porzadek.py).
    To samo zadanie (ten sam numer) wraca do swojego folderu; inne o tej samej nazwie dostaje „(2)”."""
    import porzadek
    return porzadek.folder_zadania(klient, projekt, zadanie_id, klient_folder, utworz, podfolder="Panel Premiere" if panel else None)


if __name__ == "__main__":
    import argparse
    _p = argparse.ArgumentParser(description="Folder zadania: wyniki/<Klient>/<Tytuł zadania>")
    _p.add_argument("--klient", default="", help="nazwa klienta (klient.nazwa ze Studio)")
    _p.add_argument("--projekt", required=True, help="tytuł zadania")
    _p.add_argument("--id", default="", help="numer zadania ze Studio (zadanie.id): to samo zadanie wraca do swojego folderu")
    _p.add_argument("--klient-folder", default="", help="folder klienta, np. klienci/emerald-media")
    _p.add_argument("--panel", action="store_true", help="rzeczy z panelu Premiere (animacje, napisy): wyniki/<Klient>/Panel Premiere/")
    _p.add_argument("--data", default=None, help="(nieużywane, zostawione dla zgodności)")
    _a = _p.parse_args()
    _f = folder_wynikow(_a.klient, _a.projekt, zadanie_id=_a.id, klient_folder=_a.klient_folder, panel=_a.panel)
    wynik(folder=str(_f.relative_to(KATALOG_SILNIKA)).replace("\\", "/"), sciezka=str(_f))
