﻿/* Nada Studio: buduje edytowalną kompozycję After Effects z opisu szablonu (NMSzablony.doAE).
 *
 * Powstają trzy rodzaje kompozycji:
 *   „Klip – <nazwa>”      klip z osi Premiere (ten sam fragment, który był na osi), gdy szablon dostał klip zamiast zdjęcia,
 *   „<szablon> – edycja”  wszystkie warstwy szablonu do zmiany (teksty, kształty, ruch, zdjęcia/klipy w prekompozycjach),
 *   „<szablon>”           ta idzie do Premiere przez Dynamic Link (zawiera kompozycję edycji).
 *
 * Każde zdjęcie ląduje w osobnej prekompozycji (podmiana: Alt + przeciągnij nowe zdjęcie na warstwę w prekompozycji,
 * kadrowanie: zwykła skala i pozycja w prekompozycji). Teksty to zwykłe warstwy tekstowe, kształty to warstwy kształtów,
 * ruch to klatki kluczowe z wygładzeniem (Easy Ease), więc wszystko zmienisz jak w każdym projekcie.
 *
 * Wywołanie (skrypt startowy pisze panel):
 *   $.evalFile(new File(".../ae_buduj.jsx"));
 *   NM_AE_BUDUJ(OPIS, {projekt: "C:/.../x_szablony.aep" albo null = bieżący projekt, nazwaKomp: "Szablon 1", fps: 25});
 */

function nm_ae_folder(nazwa, rodzic) {
    var gdzie = rodzic || app.project.rootFolder;
    for (var i = 1; i <= gdzie.numItems; i++) {
        var it = gdzie.item(i);
        if (it instanceof FolderItem && it.name === nazwa) return it;
    }
    var f = app.project.items.addFolder(nazwa);
    f.parentFolder = gdzie;
    return f;
}

function nm_ae_wymiary(prop) {
    var t = prop.propertyValueType;
    if (t === PropertyValueType.TwoD_SPATIAL || t === PropertyValueType.ThreeD_SPATIAL || t === PropertyValueType.SHAPE ||
        t === PropertyValueType.OneD || t === PropertyValueType.COLOR) return (t === PropertyValueType.COLOR) ? 4 : 1;
    if (t === PropertyValueType.TwoD) return 2;
    if (t === PropertyValueType.ThreeD) return 3;
    return 1;
}

function nm_ae_gladko(prop) {
    if (!prop || !prop.numKeys) return;
    var n = nm_ae_wymiary(prop);
    for (var k = 1; k <= prop.numKeys; k++) {
        var we = [], wy = [];
        for (var i = 0; i < n; i++) { we.push(new KeyframeEase(0, 33)); wy.push(new KeyframeEase(0, 80)); }
        try { prop.setTemporalEaseAtKey(k, we, wy); } catch (e) {}
    }
}

function nm_ae_klucze(prop, pary) {
    for (var i = 0; i < pary.length; i++) prop.setValueAtTime(pary[i][0], pary[i][1]);
    nm_ae_gladko(prop);
}

function nm_ae_ksztalt(comp, nazwa) {
    var l = comp.layers.addShape();
    l.name = nazwa;
    var g = l.property("ADBE Root Vectors Group").addProperty("ADBE Vector Group");
    g.name = nazwa;
    return { l: l, c: g.property("ADBE Vectors Group") };
}

function nm_ae_wypelnienie(c, kolor) {
    c.addProperty("ADBE Vector Graphic - Fill").property("ADBE Vector Fill Color").setValue(kolor);
}

function nm_ae_obrys(c, kolor, g, rysuj) {
    if (rysuj) c.addProperty("ADBE Vector Filter - Trim");
    var s = c.addProperty("ADBE Vector Graphic - Stroke");
    s.property("ADBE Vector Stroke Color").setValue(kolor);
    s.property("ADBE Vector Stroke Width").setValue(g);
    // dodanie obrysu unieważnia wcześniejsze odwołanie do „Trim Paths”: pobieramy je od nowa
    return rysuj ? c.property("ADBE Vector Filter - Trim") : null;
}

function nm_ae_ksztalt_maski(typ, x, y, w, h, r) {
    var s = new Shape();
    if (typ === "kolo") {
        var k = 0.5523, cx = x + w / 2, cy = y + h / 2, rx = w / 2, ry = h / 2;
        s.vertices = [[cx, y], [x + w, cy], [cx, y + h], [x, cy]];
        s.inTangents = [[-rx * k, 0], [0, -ry * k], [rx * k, 0], [0, ry * k]];
        s.outTangents = [[rx * k, 0], [0, ry * k], [-rx * k, 0], [0, -ry * k]];
    } else if (typ === "romb") {
        s.vertices = [[x + w / 2, y], [x + w, y + h / 2], [x + w / 2, y + h], [x, y + h / 2]];
    } else if (typ === "luk") {
        var rr = w / 2, kk = 0.5523 * rr;
        s.vertices = [[x, y + h], [x, y + rr], [x + rr, y], [x + w, y + rr], [x + w, y + h]];
        s.inTangents = [[0, 0], [0, 0], [-kk, 0], [0, -kk], [0, 0]];
        s.outTangents = [[0, 0], [0, -kk], [kk, 0], [0, 0], [0, 0]];
    } else if (typ === "zaokr") {
        var q = Math.min(r || 40, w / 2, h / 2), t = 0.5523 * q;
        s.vertices = [[x + q, y], [x + w - q, y], [x + w, y + q], [x + w, y + h - q], [x + w - q, y + h], [x + q, y + h], [x, y + h - q], [x, y + q]];
        s.inTangents = [[-t, 0], [0, 0], [0, -t], [0, 0], [t, 0], [0, 0], [0, t], [0, 0]];
        s.outTangents = [[0, 0], [t, 0], [0, 0], [0, t], [0, 0], [-t, 0], [0, 0], [0, -t]];
    } else {
        s.vertices = [[x, y], [x + w, y], [x + w, y + h], [x, y + h]];
    }
    s.closed = true;
    return s;
}

function nm_ae_maska(layer, ksztalt, nazwa, tryb) {
    var m = layer.property("ADBE Mask Parade").addProperty("ADBE Mask Atom");
    m.name = nazwa;
    if (tryb) m.maskMode = tryb;
    if (ksztalt) m.property("ADBE Mask Shape").setValue(ksztalt);
    return m;
}

/* Ruch wejścia i wyjścia. lr = prostokąt warstwy w jej własnych współrzędnych [x, y, w, h] (do masek odkrywania). */
function nm_ae_ruch(layer, o, lr, s, trim, tekstProp) {
    var tr = layer.property("ADBE Transform Group");
    var pos = tr.property("ADBE Position"), sk = tr.property("ADBE Scale"), op = tr.property("ADBE Opacity");
    var p0 = pos.value, baza = (o.krycie == null ? 1 : o.krycie) * 100;
    var we = o.we, wy = o.wy;
    var kO = [], kP = [], kS = [];
    if (we) {
        var t0 = we.t, t1 = we.t + we.d, typ = we.typ;
        var przes = { gora: [0, 90], dol: [0, -90], lewo: [-140, 0], prawo: [140, 0] }[typ];
        if (przes) { kP.push([t0, [p0[0] + przes[0] * s, p0[1] + przes[1] * s]]); kP.push([t1, p0]); }
        if (typ === "zanik" || przes || typ === "skala" || typ === "zoom") { kO.push([t0, 0]); kO.push([t1, baza]); }
        if (typ === "skala") { kS.push([t0, [82, 82]]); kS.push([t1, [100, 100]]); }
        if (typ === "zoom") { kS.push([t0, [125, 125]]); kS.push([t1, [100, 100]]); }
        if (typ === "pop") { kS.push([t0, [0, 0]]); kS.push([t0 + we.d * 0.6, [110, 110]]); kS.push([t1, [100, 100]]); kO.push([t0, 0]); kO.push([t0 + we.d * 0.3, baza]); }
        if (typ === "licz") { kO.push([t0, 0]); kO.push([t0 + we.d * 0.25, baza]); }
        if (typ.indexOf("odkryj-") === 0) {
            var x = lr[0], y = lr[1], w = lr[2], h = lr[3], m = nm_ae_maska(layer, null, "Odkrycie", MaskMode.INTERSECT), mp = m.property("ADBE Mask Shape");
            var start = { "odkryj-lewo": [x, y, 0.5, h], "odkryj-prawo": [x + w - 0.5, y, 0.5, h], "odkryj-gora": [x, y, w, 0.5], "odkryj-dol": [x, y + h - 0.5, w, 0.5] }[typ];
            nm_ae_klucze(mp, [[t0, nm_ae_ksztalt_maski("prost", start[0], start[1], start[2], start[3])], [t1, nm_ae_ksztalt_maski("prost", x, y, w, h)]]);
        }
        if (typ === "maska-gora") {
            var hh = lr[3] + 30 * s, m2 = nm_ae_maska(layer, null, "Maska wjazdu", MaskMode.INTERSECT), mp2 = m2.property("ADBE Mask Shape");
            nm_ae_klucze(mp2, [[t0, nm_ae_ksztalt_maski("prost", lr[0] - 40 * s, lr[1] - 10 * s - hh, lr[2] + 80 * s, lr[3] + 40 * s)],
                               [t1, nm_ae_ksztalt_maski("prost", lr[0] - 40 * s, lr[1] - 10 * s, lr[2] + 80 * s, lr[3] + 40 * s)]]);
            kP.push([t0, [p0[0], p0[1] + hh]]); kP.push([t1, p0]);
        }
        if (typ === "rysuj" && trim) nm_ae_klucze(trim.property("ADBE Vector Trim End"), [[t0, 0], [t1, 100]]);
        if ((typ === "pisz" || typ === "licz") && tekstProp) {
            var T0 = String(t0), D = String(we.d);
            tekstProp.expression = typ === "pisz"
                ? "var s = \"\" + value; var p = Math.max(0, Math.min(1, (time - " + T0 + ") / " + D + ")); s.substr(0, Math.floor(s.length * p));"
                : "var s = \"\" + value; var m = s.match(/^([^\\d-]*)(-?\\d+(?:[.,]\\d+)?)([\\s\\S]*)$/);\n" +
                  "if (!m) { s } else { var p = Math.max(0, Math.min(1, (time - " + T0 + ") / " + D + ")); p = 1 - Math.pow(1 - p, 4);\n" +
                  "var dec = (m[2].split(/[.,]/)[1] || \"\").length; var v = parseFloat(m[2].replace(\",\", \".\")) * p;\n" +
                  "m[1] + v.toFixed(dec).replace(\".\", m[2].indexOf(\",\") >= 0 ? \",\" : \".\") + m[3] }";
        }
    }
    if (wy && wy.typ !== "brak") {
        var t2 = wy.t, t3 = wy.t + (wy.d || 0.45);
        kO.push([t2, baza]); kO.push([t3, 0]);
        if (wy.typ === "gora") { kP.push([t2, p0]); kP.push([t3, [p0[0], p0[1] - 90 * s]]); }
    }
    if (!kO.length && baza !== 100) op.setValue(baza);
    if (kO.length) nm_ae_klucze(op, kO);
    if (kP.length) nm_ae_klucze(pos, kP);
    if (kS.length) nm_ae_klucze(sk, kS);
}

function nm_ae_zdjecie(comp, o, czas, fps, folder, opcje) {
    var w = Math.max(4, Math.round(o.w)), h = Math.max(4, Math.round(o.h));
    var pc = app.project.items.addComp(o.nazwa + (o.klip ? " (klip)" : " (zdjęcie)"), w, h, 1, czas, fps);
    pc.parentFolder = folder;
    var fl = null;
    if (o.klip && o.klip.plik && new File(o.klip.plik).exists) {
        try {
            var kc = nm_ae_komp_klipu(o.klip, fps, folder);
            fl = pc.layers.add(kc);
            var dopk = o.dopasuj === "zawrzyj" ? Math.min(w / kc.width, h / kc.height) : Math.max(w / kc.width, h / kc.height);
            var bk = dopk * 100 * (o.skala || 1);
            fl.property("ADBE Transform Group").property("ADBE Position").setValue([w / 2 + o.przes[0] * w / 2, h / 2 + o.przes[1] * h / 2]);
            fl.property("ADBE Transform Group").property("ADBE Scale").setValue([bk, bk]);
            if (o.bw) { try { fl.property("ADBE Effect Parade").addProperty("ADBE Tint"); } catch (e0) {} }
            fl.name = "Klip (podmień)";
        } catch (ek) { nm_ae_log(opcje || {}, "klip " + o.klip.plik + ": " + ek.toString()); fl = null; }
    }
    if (!fl && o.plik) {
        var f = new File(o.plik);
        if (f.exists) {
            var it = app.project.importFile(new ImportOptions(f));
            it.parentFolder = folder;
            fl = pc.layers.add(it);
            var iw = it.width, ih = it.height;
            var dop = o.dopasuj === "zawrzyj" ? Math.min(w / iw, h / ih) : Math.max(w / iw, h / ih);
            var bazowa = dop * 100 * (o.skala || 1);
            fl.property("ADBE Transform Group").property("ADBE Position").setValue([w / 2 + o.przes[0] * w / 2, h / 2 + o.przes[1] * h / 2]);
            var sk = fl.property("ADBE Transform Group").property("ADBE Scale");
            if (o.ruch && o.ruch[0] !== o.ruch[1]) nm_ae_klucze(sk, [[0, [bazowa * o.ruch[0], bazowa * o.ruch[0]]], [czas, [bazowa * o.ruch[1], bazowa * o.ruch[1]]]]);
            else sk.setValue([bazowa, bazowa]);
            if (o.bw) { try { fl.property("ADBE Effect Parade").addProperty("ADBE Tint"); } catch (e1) {} }
        }
    }
    if (!fl) { fl = pc.layers.addSolid([0.45, 0.45, 0.47], "Wstaw zdjęcie tutaj", w, h, 1); }
    if (!o.klip) fl.name = "Zdjęcie (podmień)";
    var L = comp.layers.add(pc);
    L.name = o.nazwa;
    L.property("ADBE Transform Group").property("ADBE Position").setValue([o.x + o.w / 2, o.y + o.h / 2]);
    if (o.obrot) L.property("ADBE Transform Group").property("ADBE Rotate Z").setValue(o.obrot);
    if (typeof o.maska === "object" && o.maska) nm_ae_maska(L, nm_ae_ksztalt_maski("prost", o.maska.x - o.x, o.maska.y - o.y, o.maska.w, o.maska.h), "Kształt zdjęcia");
    else if (o.maska && o.maska !== "prost") nm_ae_maska(L, nm_ae_ksztalt_maski(o.maska, 0, 0, w, h, o.r), "Kształt zdjęcia");
    return { l: L, lr: [0, 0, w, h] };
}

function nm_ae_tekst(comp, o) {
    var l = comp.layers.addText(o.linie.join("\r"));
    l.name = o.nazwa || "Tekst";
    var tp = l.property("ADBE Text Properties").property("ADBE Text Document");
    var d = tp.value;
    try { d.resetCharStyle(); d.resetParagraphStyle(); } catch (e0) {}
    d.fontSize = o.rozmiar;
    try { d.font = o.font; } catch (e1) {}
    d.applyFill = true;
    d.fillColor = o.kolor;
    d.applyStroke = false;
    d.tracking = o.rozstaw || 0;
    d.justification = o.wyr === "srodek" ? ParagraphJustification.CENTER_JUSTIFY : o.wyr === "prawo" ? ParagraphJustification.RIGHT_JUSTIFY : ParagraphJustification.LEFT_JUSTIFY;
    try { d.autoLeading = false; d.leading = o.interlinia; } catch (e2) {}
    tp.setValue(d);
    var tr = l.property("ADBE Transform Group");
    var r = l.sourceRectAtTime(0, false);
    if (o.obrot) {
        // obrót wokół lewego górnego rogu tekstu, jak w podglądzie
        var dy = o.baza - o.y;
        tr.property("ADBE Anchor Point").setValue([0, -dy]);
        tr.property("ADBE Position").setValue([o.px, o.y]);
        tr.property("ADBE Rotate Z").setValue(o.obrot);
    } else {
        var a = [r.left + r.width / 2, r.top + r.height / 2];
        tr.property("ADBE Anchor Point").setValue(a);
        tr.property("ADBE Position").setValue([o.px + a[0], o.baza + a[1]]);
    }
    return { l: l, lr: [r.left, r.top, r.width, r.height], tekst: tp };
}

var NM_AE_KLIPY = {};

function nm_ae_zapisz(sciezka, tekst, dopisz) {
    if (!sciezka) return;
    try {
        var f = new File(sciezka);
        f.encoding = "UTF-8";
        f.open(dopisz ? "a" : "w");
        f.write(tekst);
        f.close();
    } catch (e) {}
}
function nm_ae_log(opcje, t) { nm_ae_zapisz(opcje.log, new Date().toString() + " " + t + "\n", true); }
function nm_ae_wynik(opcje, t) { nm_ae_zapisz(opcje.wynik, t, false); }

/* Kompozycja z klipem z osi Premiere: ten sam fragment (od klip.od, długość klip.dl), pełna rozdzielczość źródła, bez dźwięku. */
function nm_ae_komp_klipu(klip, fps, folder) {
    var klucz = klip.plik + "|" + klip.od + "|" + klip.dl;
    if (NM_AE_KLIPY[klucz]) return NM_AE_KLIPY[klucz];
    var it = app.project.importFile(new ImportOptions(new File(klip.plik)));
    it.parentFolder = folder;
    var w = it.width || 1920, h = it.height || 1080, dl = Math.max(0.1, klip.dl || it.duration || 5);
    var kc = app.project.items.addComp("Klip – " + (klip.nazwa || it.name), w, h, it.pixelAspect || 1, dl, fps);
    kc.parentFolder = folder;
    var l = kc.layers.add(it);
    l.startTime = -(klip.od || 0);
    try { l.audioEnabled = false; } catch (e1) {}
    NM_AE_KLIPY[klucz] = kc;
    return kc;
}

function NM_AE_BUDUJ(opis, opcje) {
    opcje = opcje || {};
    NM_AE_KLIPY = {};
    app.beginUndoGroup("Studio Nadamedia: szablon");
    try {
        // Jak Dynamic Link: pracujemy w projekcie, który jest otwarty w After Effects. Gdy nie jest jeszcze zapisany,
        // zapisujemy go jako projekt szablonów obok projektu Premiere (opcje.projekt).
        if (!app.project) app.newProject();
        var fps = opcje.fps || 25, czas = opis.czas, W = opis.W, H = opis.H, s = W / 1080;
        var glowny = nm_ae_folder("Studio Nadamedia – szablony");
        var nazwa = opcje.nazwaKomp || opis.nazwa;
        var folder = nm_ae_folder(nazwa, glowny);
        // dwie kompozycje: „nazwa – edycja” (tu są wszystkie warstwy do zmiany) i „nazwa” (ta idzie do Premiere przez Dynamic Link)
        var comp = app.project.items.addComp(nazwa + " – edycja", W, H, 1, czas, fps);
        comp.parentFolder = folder;
        comp.bgColor = opis.tlo;
        var tlo = comp.layers.addSolid(opis.tlo, "Tło", W, H, 1);
        nm_ae_klucze(tlo.property("ADBE Transform Group").property("ADBE Opacity"), [[0, 0], [0.25, 100]]);
        for (var i = 0; i < opis.warstwy.length; i++) {
            var o = opis.warstwy[i], wyn = null, trim = null, tekst = null;
            try {
            if (o.typ === "zdjecie") wyn = nm_ae_zdjecie(comp, o, czas, fps, folder, opcje);
            else if (o.typ === "tekst") { wyn = nm_ae_tekst(comp, o); tekst = wyn.tekst; }
            else if (o.typ === "prost" || o.typ === "cien") {
                var k = nm_ae_ksztalt(comp, o.nazwa);
                var rp = k.c.addProperty("ADBE Vector Shape - Rect");
                rp.property("ADBE Vector Rect Size").setValue([o.w, o.h]);
                if (o.r) rp.property("ADBE Vector Rect Roundness").setValue(o.r);
                if (o.obrys) trim = nm_ae_obrys(k.c, o.kolor, o.obrys, o.we && o.we.typ === "rysuj");
                else nm_ae_wypelnienie(k.c, o.kolor);
                k.l.property("ADBE Transform Group").property("ADBE Position").setValue([o.x + o.w / 2, o.y + o.h / 2]);
                if (o.obrot) k.l.property("ADBE Transform Group").property("ADBE Rotate Z").setValue(o.obrot);
                if (o.typ === "cien") {
                    // przejście przezroczystości: maska z miękką krawędzią w połowie wysokości
                    var dol = o["do"] > o.od, mk = dol ? nm_ae_ksztalt_maski("prost", -o.w / 2 - 3000, 0, o.w + 6000, o.h / 2 + 4000)
                                                         : nm_ae_ksztalt_maski("prost", -o.w / 2 - 3000, -o.h / 2 - 4000, o.w + 6000, o.h / 2 + 4000);
                    var mm = nm_ae_maska(k.l, mk, "Przejście");
                    mm.property("ADBE Mask Feather").setValue([0, o.h]);
                    o.krycie = Math.max(o.od, o["do"]);
                }
                wyn = { l: k.l, lr: [-o.w / 2, -o.h / 2, o.w, o.h] };
            } else if (o.typ === "kolo") {
                var k2 = nm_ae_ksztalt(comp, o.nazwa);
                k2.c.addProperty("ADBE Vector Shape - Ellipse").property("ADBE Vector Ellipse Size").setValue([o.promien * 2, o.promien * 2]);
                if (o.obrys) trim = nm_ae_obrys(k2.c, o.kolor, o.obrys, o.we && o.we.typ === "rysuj");
                else nm_ae_wypelnienie(k2.c, o.kolor);
                k2.l.property("ADBE Transform Group").property("ADBE Position").setValue([o.cx, o.cy]);
                wyn = { l: k2.l, lr: [-o.promien, -o.promien, o.promien * 2, o.promien * 2] };
            } else if (o.typ === "trojkat") {
                var k3 = nm_ae_ksztalt(comp, o.nazwa);
                var gw = k3.c.addProperty("ADBE Vector Shape - Star");
                gw.property("ADBE Vector Star Type").setValue(2);
                gw.property("ADBE Vector Star Points").setValue(3);
                gw.property("ADBE Vector Star Outer Radius").setValue(o.promien);
                nm_ae_wypelnienie(k3.c, o.kolor);
                k3.l.property("ADBE Transform Group").property("ADBE Position").setValue([o.cx, o.cy]);
                k3.l.property("ADBE Transform Group").property("ADBE Rotate Z").setValue(o.obrot || 0);
                wyn = { l: k3.l, lr: [-o.promien, -o.promien, o.promien * 2, o.promien * 2] };
            } else if (o.typ === "linia") {
                var k4 = nm_ae_ksztalt(comp, o.nazwa), cx = (o.x1 + o.x2) / 2, cy = (o.y1 + o.y2) / 2;
                var sh = new Shape(); sh.vertices = [[o.x1 - cx, o.y1 - cy], [o.x2 - cx, o.y2 - cy]]; sh.closed = false;
                k4.c.addProperty("ADBE Vector Shape - Group").property("ADBE Vector Shape").setValue(sh);
                trim = nm_ae_obrys(k4.c, o.kolor, o.g, true);
                if (!(o.we && o.we.typ === "rysuj")) trim.property("ADBE Vector Trim End").setValue(100);
                k4.l.property("ADBE Transform Group").property("ADBE Position").setValue([cx, cy]);
                wyn = { l: k4.l, lr: [-Math.abs(o.x2 - o.x1) / 2, -Math.abs(o.y2 - o.y1) / 2, Math.abs(o.x2 - o.x1), Math.abs(o.y2 - o.y1)] };
            }
            if (wyn) nm_ae_ruch(wyn.l, o, wyn.lr, s, trim, tekst);
            } catch (ew) { nm_ae_log(opcje, "warstwa " + (i + 1) + " (" + o.typ + " " + (o.nazwa || "") + "): " + ew.toString() + " linia " + ew.line); }
        }
        var link = app.project.items.addComp(nazwa, W, H, 1, czas, fps);
        link.parentFolder = glowny;
        link.bgColor = opis.tlo;
        link.layers.add(comp);
        var plikProj = app.project.file;
        if (plikProj) app.project.save();
        else if (opcje.projekt) { plikProj = new File(opcje.projekt); app.project.save(plikProj); }
        // w podglądzie: najpierw kompozycja z klipem (jeśli jest), potem kompozycja edycji jako aktywna
        for (var kk in NM_AE_KLIPY) { try { NM_AE_KLIPY[kk].openInViewer(); } catch (e5) {} }
        try { comp.openInViewer(); } catch (e3) {}
        app.endUndoGroup();
        var w = "ok|" + (plikProj ? plikProj.fsName : "") + "|" + link.name;
        nm_ae_wynik(opcje, w);
        return w;
    } catch (e) {
        app.endUndoGroup();
        var b = "blad|" + e.toString() + " (linia " + e.line + ")";
        nm_ae_log(opcje, b);
        nm_ae_wynik(opcje, b);
        return b;
    }
}
