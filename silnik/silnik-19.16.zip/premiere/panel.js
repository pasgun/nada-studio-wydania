/* Studio Nadamedia, panel w Premiere: uruchamia silnik (Python), Claude Code i bibliotekę animacji na tym komputerze. */
"use strict";
(function () { // wszystko w środku, żeby nazwy nie zderzały się z tymi, które Premiere podaje panelowi
const NODE_REQ = typeof require === "function" ? require : (window.cep_node && window.cep_node.require);
if (!NODE_REQ) throw new Error("Panel nie ma dostępu do Node.js. Uruchom ponownie: python narzedzia\\panel_premiere.py --instaluj i zrestartuj Premiere.");
const PROC = typeof process !== "undefined" ? process : window.cep_node.process;
const BUF = typeof Buffer !== "undefined" ? Buffer : window.cep_node.Buffer;
const fs = NODE_REQ("fs");
const path = NODE_REQ("path");
const cp = NODE_REQ("child_process");

const CEPI = window.__adobe_cep__;
let HOST = "PPRO";
try { HOST = JSON.parse(CEPI.getHostEnvironment()).appName || "PPRO"; } catch (e) {}
const $ = (id) => document.getElementById(id);
const $$ = (sel, el = document) => Array.from(el.querySelectorAll(sel));
const stan = { folder: null, raport: null, info: null, widok: "dom" };
const q = (s) => JSON.stringify(String(s));
const czekaj = (ms) => new Promise((r) => setTimeout(r, ms));
const URL_PLIKU = (p) => "file:///" + String(p).replace(/\\/g, "/").split("/").map((x, i) => (i === 0 && /:$/.test(x) ? x : encodeURIComponent(x))).join("/");

function folderPanelu() {
  let p = "";
  try { p = decodeURI(CEPI.getSystemPath("extension")); } catch (e) { p = decodeURI(location.pathname).replace(/\/[^/]*$/, ""); }
  p = p.replace(/^file:\/{2,3}/, "");
  if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1);
  return p;
}
let cfg = {};
try { cfg = JSON.parse(fs.readFileSync(path.join(folderPanelu(), "config.json"), "utf8")); } catch (e) {}
const SILNIK = cfg.silnik || "";
const zapisz = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} };
const wczytaj = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } };
/* pliki silnika (rejestr animacji, błędy, kolor, stock): _system/<nazwa>; stary wyniki/_<nazwa> przenosi się sam */
const SYS_GOTOWE = {};
function SYS(n) {
  const nowy = path.join(SILNIK, "_system", n);
  if (!SYS_GOTOWE[n]) {
    SYS_GOTOWE[n] = true;
    try {
      fs.mkdirSync(nowy, { recursive: true });
      const stary = path.join(SILNIK, "wyniki", n === "after-effects" ? "after-effects-robocze" : "_" + n);
      if (fs.existsSync(stary)) {
        fs.readdirSync(stary).forEach((x) => { const c = path.join(nowy, x); if (!fs.existsSync(c)) { try { fs.renameSync(path.join(stary, x), c); } catch (e) {} } });
        try { fs.rmdirSync(stary); } catch (e) {}
      }
    } catch (e) {}
  }
  return nowy;
}
/* folder klienta w wynikach: wyniki/<Nazwa klienta> (nazwa z klienci/<folder>/klient.json albo ładnie z nazwy folderu) */
function nazwaKlientaPanel() {
  const k = ($("klient") && $("klient").value) || "";
  if (!k) return "Bez klienta";
  try { const d = JSON.parse(fs.readFileSync(path.join(SILNIK, "klienci", k, "klient.json"), "utf8")); if (d.nazwa) return String(d.nazwa).replace(/[<>:"/\\|?*]/g, "-").trim(); } catch (e) {}
  const s = k.split(/[-_\s]+/).filter(Boolean);
  return s.map((w) => (w.length <= 3 && s.length === 1 ? w.toUpperCase() : w[0].toUpperCase() + w.slice(1))).join(" ") || "Bez klienta";
}
const wynikiKlienta = () => path.join(SILNIK, "wyniki", nazwaKlientaPanel());

// ---------- log i uruchamianie ----------
function log(t, klasa) {
  const l = $("log");
  l.hidden = false;
  const d = document.createElement("div");
  if (klasa) d.className = klasa;
  d.textContent = t;
  l.appendChild(d);
  l.scrollTop = l.scrollHeight;
}
function jsx(skrypt) {
  return new Promise((ok) => CEPI.evalScript(skrypt, (w) => { try { ok(JSON.parse(w)); } catch (e) { ok({ ok: false, blad: String(w) }); } }));
}
const powloka = (program) => /\.(cmd|bat)$/i.test(program || "");
const cudzyslow = (a) => `"${String(a).replace(/"/g, '\\"')}"`;
// programy z apki Nada Studio (Python, ffmpeg, Node, Claude Code) dopisane do PATH, gdy nie ma ich w PATH systemu
const ENV = () => {
  const e = Object.assign({}, PROC.env, { PYTHONIOENCODING: "utf-8", PYTHONUTF8: "1" });
  const k = Object.keys(e).find((x) => x.toUpperCase() === "PATH") || "PATH";
  const dod = (cfg.sciezki || []).filter((x) => x && !String(e[k] || "").includes(x));
  if (dod.length) e[k] = dod.join(PROC.platform === "win32" ? ";" : ":") + (PROC.platform === "win32" ? ";" : ":") + (e[k] || "");
  return e;
};

function uruchom(program, args, opcje = {}) {
  return new Promise((ok) => {
    const sh = powloka(program);
    let p;
    try {
      p = cp.spawn(sh ? cudzyslow(program) : program, sh ? args.map(cudzyslow) : args, { cwd: SILNIK, windowsHide: true, shell: sh, env: ENV() });
    } catch (e) { ok({ kod: -1, out: "", err: String(e) }); return; }
    let out = "", err = "";
    p.stdout.on("data", (d) => (out += d.toString("utf8")));
    p.stderr.on("data", (d) => {
      const t = d.toString("utf8");
      err += t;
      t.split(/\r?\n/).forEach((l) => {
        if (l.startsWith("POSTEP%:")) { opcje.naPostep && opcje.naPostep(parseFloat(l.slice(8)), null); return; }
        if (!l.startsWith("POSTEP:")) return;
        if (opcje.naPostep) opcje.naPostep(null, l.slice(7).trim()); else log("… " + l.slice(7).trim());
      });
    });
    if (opcje.wejscie) p.stdin.write(opcje.wejscie);
    p.stdin.end();
    const limit = setTimeout(() => { try { p.kill(); } catch (e) {} }, opcje.limitMs || 3 * 3600 * 1000);
    p.on("error", (e) => { clearTimeout(limit); ok({ kod: -1, out, err: err + String(e) }); });
    p.on("close", (kod) => { clearTimeout(limit); ok({ kod, out, err }); });
  });
}
async function python(skrypt, args, naPostep) {
  const r = await uruchom(cfg.python || "python", [path.join(SILNIK, "narzedzia", skrypt), ...args], naPostep ? { naPostep } : {});
  const i = r.out.indexOf("{");
  let d = null;
  try { d = JSON.parse(r.out.slice(i)); } catch (e) {}
  if (!d) return { ok: false, blad: (r.err || r.out || "brak odpowiedzi").slice(-600) };
  return d;
}
const otworz = (p) => p && cp.exec(PROC.platform === "win32" ? `start "" "${p}"` : `open "${p}"`);
const otworzFolder = (p) => p && cp.exec(PROC.platform === "win32" ? `explorer "${p}"` : `open "${p}"`);

// ---------- sekwencja i klient ----------
async function odswiezInfo() {
  if (HOST === "AEFT") {
    const a = await jsx("nm_ae_info()");
    const k = a.ok && a.komp;
    stan.info = a.ok ? { ok: true, ae: true, projekt: a.projekt, nazwa: k ? k.nazwa : "(brak aktywnej kompozycji)", szer: k ? k.szer : 1080, wys: k ? k.wys : 1920, fps: k ? k.fps : 25, glowica: k ? k.czas : 0, klipy: 0, material_s: 0, wideo: [], audio: [] } : null;
    $("seq").textContent = stan.info ? stan.info.nazwa : (a.blad || "After Effects");
    $("seqInfo").textContent = k ? `${k.szer}×${k.wys}` : "";
    if (stan.info) anFormat();
    return stan.info || a;
  }
  const i = await jsx("nm_info()");
  stan.info = i.ok ? i : null;
  $("seq").textContent = i.ok ? i.nazwa : (i.blad || "brak sekwencji");
  $("seqInfo").textContent = i.ok ? `${i.szer}×${i.wys} · ${Math.round(i.fps * 100) / 100} kl/s` : "";
  if (i.ok) { mcSciezki(); amSzacuj(); anFormat(); }
  return i;
}
function klienci() {
  const f = path.join(SILNIK, "klienci");
  try { return fs.readdirSync(f, { withFileTypes: true }).filter((d) => d.isDirectory() && !d.name.startsWith("_") && !d.name.startsWith(".")).map((d) => d.name).sort(); } catch (e) { return []; }
}
function folderKlienta() { const k = $("klient").value; return k ? path.join(SILNIK, "klienci", k) : null; }
function wypelnijKlientow() {
  const s = $("klient"), b = wczytaj("nm-klient", "");
  s.innerHTML = '<option value="">— bez klienta —</option>' + klienci().map((k) => `<option>${k.replace(/</g, "")}</option>`).join("");
  s.value = klienci().includes(b) ? b : "";
}
$("klient").onchange = () => { zapisz("nm-klient", $("klient").value); amLoga(); anMarkaKlienta(); szMarkaKlienta(true); nMarkaKlienta(); };

async function folderWynikow(klient, projekt, jakoZadanie) {
  // narzędzia panelu: wyniki/<Klient>/Panel Premiere/<sekwencja> <narzędzie>; aftermovie (z tytułem): wyniki/<Klient>/<tytuł>
  const args = ["--klient", $("klient").value ? nazwaKlientaPanel() : (klient || ""), "--klient-folder", $("klient").value || "", "--projekt", projekt];
  if (!jakoZadanie) args.push("--panel");
  const d = await python("wspolne.py", args);
  if (!d.ok) throw new Error(d.blad);
  return path.join(SILNIK, d.folder);
}
async function przygotuj(dopisek, tytulZadania) {
  if (!SILNIK || !fs.existsSync(SILNIK)) throw new Error("Panel nie zna folderu silnika. Uruchom ponownie: python narzedzia\\panel_premiere.py --instaluj");
  const info = await odswiezInfo();
  if (!info.ok) throw new Error(info.blad);
  const folder = tytulZadania ? await folderWynikow("", tytulZadania, true) : await folderWynikow($("klient").value ? "" : "Bez klienta", info.nazwa + " " + dopisek);
  stan.folder = folder;
  const xml = path.join(folder, "sekwencja.xml");
  log("Zapisuję sekwencję…");
  const e = await jsx(`nm_eksportuj(${q(xml)})`);
  if (!e.ok) throw new Error(e.blad);
  return { info, folder, xml };
}

/* ---------- dźwięk z osi przez Premiere ----------
   Premiere sam renderuje dźwięk ścieżki (albo całego miksu), więc narzędzia dostają dokładnie to, co słychać:
   wybór kanałów, Fill Left, głośności klipów i ścieżek, efekty audio, zagnieżdżone sekwencje. Do eksportu potrzebny jest
   preset WAV (.epr) z instalacji Premiere albo Media Encodera: szukamy go raz i zapamiętujemy. */
let PRESET_WAV = null;
function czyPresetWav(plik) {
  try { const fd = fs.openSync(plik, "r"), b = BUF.alloc(262144), n = fs.readSync(fd, b, 0, 262144, 0); fs.closeSync(fd); return /<ExporterFileType>\s*1463899717\s*</.test(b.toString("utf8", 0, n)); } catch (e) { return false; }
}
async function presetWav() {
  if (PRESET_WAV && fs.existsSync(PRESET_WAV)) return PRESET_WAV;
  const zap = wczytaj("nm-preset-wav", "");
  if (zap && fs.existsSync(zap) && czyPresetWav(zap)) return (PRESET_WAV = zap);
  const pr = await jsx("nm_folder_premiere()");
  const app = pr.ok ? pr.sciezka : "";
  const foldery = [];
  if (app) [path.join(app, "MediaIO", "systempresets"), path.join(app, "Contents", "MediaIO", "systempresets"), path.join(path.dirname(app), "MediaIO", "systempresets")].forEach((x) => foldery.push(x));
  const adobe = PROC.platform === "win32" ? path.join(PROC.env.ProgramFiles || "C:\\Program Files", "Adobe") : "/Applications";
  try { fs.readdirSync(adobe).filter((n) => /Media Encoder|Premiere/i.test(n)).forEach((n) => { foldery.push(path.join(adobe, n, "MediaIO", "systempresets")); foldery.push(path.join(adobe, n, n + ".app", "Contents", "MediaIO", "systempresets")); }); } catch (e) {}
  const dom = PROC.env.USERPROFILE || PROC.env.HOME || "";
  if (dom) foldery.push(path.join(dom, "Documents", "Adobe"));
  const znalezione = [];
  const szukaj = (dir, gl) => {
    if (gl > 5 || znalezione.length > 40) return;
    let lista; try { lista = fs.readdirSync(dir, { withFileTypes: true }); } catch (e) { return; }
    for (const e of lista) {
      const pe = path.join(dir, e.name);
      if (e.isDirectory()) szukaj(pe, gl + 1);
      else if (/\.epr$/i.test(e.name) && czyPresetWav(pe)) znalezione.push(pe);
    }
  };
  foldery.forEach((f) => szukaj(f, 0));
  if (!znalezione.length) return null;
  const ocena = (p) => (/48/.test(path.basename(p)) ? 2 : 0) + (/16|24/.test(path.basename(p)) ? 1 : 0) + (/systempresets/i.test(p) ? 1 : 0);
  znalezione.sort((a, b) => ocena(b) - ocena(a));
  PRESET_WAV = znalezione[0];
  zapisz("nm-preset-wav", PRESET_WAV);
  return PRESET_WAV;
}
/* solo = numer ścieżki A (od 1): tylko ta ścieżka; 0 = cały miks tak, jak słychać (z Twoimi wyciszeniami). */
async function eksportAudio(info, folder, solo) {
  const preset = await presetWav();
  if (!preset) { log("Nie znalazłem w Premiere presetu WAV do eksportu dźwięku (Premiere i Media Encoder mają go standardowo; sprawdź, czy Media Encoder jest zainstalowany).", "e"); return null; }
  const dir = path.join(folder, "dzwiek_z_osi");
  fs.mkdirSync(dir, { recursive: true });
  const plik = path.join(dir, solo ? `A${solo}.wav` : "miks.wav");
  const w = await jsx(`nm_eksport_audio(${JSON.stringify({ id: info.id, plik, preset, solo: solo || 0 })})`);
  if (!w.ok || !fs.existsSync(plik)) { log(`Premiere nie wyeksportował dźwięku ${solo ? "A" + solo : "osi"} (${w.blad || w.odp || "?"}).`, "e"); return null; }
  return plik;
}

// ---------- widoki ----------
function pokaz(v) {
  stan.widok = v;
  $$("section[data-v]").forEach((s) => (s.hidden = s.dataset.v !== v));
  $("doNarzedzi").hidden = v === "dom"; $("logoPanelu").hidden = v !== "dom"; window.scrollTo(0, 0);
  $("wyniki").hidden = ["dom", "animacje", "aftermovie", "szablony"].includes(v);
  zapisz("nm-widok", v);
  if (v === "animacje") anStart(); else anStop();
  if (v === "szablony") szStart(); else szStop();
  if (v === "kolor") kolStart();
  if (v === "stock") stStart();
  if (v === "napisy") { const pierwszy = !N_STYLE.length; nGaleria(); nUstawStyl(nStan.id, !pierwszy || !!wczytaj("nm-napisy", null)); zaladujRodzine($("nFont").value, null, $("nWaga").value); nPrzywroc(); }
}
$$("[data-idz]").forEach((b) => (b.onclick = () => pokaz(b.dataset.idz)));
function segment(id, naZmiane) {
  const el = $(id);
  $$("button", el).forEach((b) => (b.onclick = () => {
    $$("button", el).forEach((x) => x.setAttribute("aria-pressed", String(x === b)));
    naZmiane && naZmiane(b.dataset.v || b.dataset.p);
  }));
}
const wartoscSeg = (id) => { const b = $$("button", $(id)).find((x) => x.getAttribute("aria-pressed") === "true"); return b ? (b.dataset.v || b.dataset.p) : null; };
const ustawSeg = (id, v) => $$("button", $(id)).forEach((x) => x.setAttribute("aria-pressed", String((x.dataset.v || x.dataset.p) === v)));
function suwak(id, jedn, cyfry = 2) {
  const el = $(id), o = $(id + "O");
  const pokazW = () => { if (!o) return; let t = (+el.value).toFixed(cyfry); if (t.includes(".")) t = t.replace(/\.?0+$/, ""); o.textContent = t + jedn; };
  el.addEventListener("input", pokazW); pokazW();
}

// ---------- blokada przycisków przy pracy w panelu ----------
async function zablokuj(fn) {
  $$("button.glowny").forEach((b) => (b.disabled = true));
  $("log").innerHTML = "";
  $("lista").innerHTML = "";
  $("akcje").hidden = true;
  zapamietaj();
  try { await fn(); } catch (e) { log("Błąd: " + (e.message || e), "e"); }
  $$("button.glowny").forEach((b) => (b.disabled = false));
}

// ======================= CIĘCIE =======================
const POLA_CIECIA = ["cisza", "claude", "pauza", "zostaw", "wpadki", "jezyk", "silnik", "nazwy", "ciBezWyc"];
/* Ścieżki audio wyciszone w Premiere (M): przycisk M nie trafia do pliku XML, więc pytamy Premiere wprost. */
const wyciszone = (info) => ((info && info.audio) || []).filter((a) => a.wyciszona).map((a) => a.nr);
function zapamietaj() {
  const u = {};
  POLA_CIECIA.forEach((k) => (u[k] = $(k).type === "checkbox" ? $(k).checked : $(k).value));
  zapisz("nm-ustawienia", u);
  mcZapamietaj();
  amZapamietaj();
}
function przywroc() {
  const u = wczytaj("nm-ustawienia", {});
  Object.keys(u).forEach((k) => { if (!$(k)) return; if ($(k).type === "checkbox") $(k).checked = u[k]; else $(k).value = u[k]; });
}
suwak("pauza", " s", 1); suwak("zostaw", " s", 2);

const usunPlik = (p) => { try { if (p && fs.existsSync(p)) fs.unlinkSync(p); } catch (e) {} };
async function analiza(folder, xml, pomin = [], audio = null) {
  if (audio) log("Dźwięk z osi tak, jak go słychać w Premiere (z Twoimi ustawieniami kanałów, głośności i wyciszeniami).");
  else if (pomin.length) log(`Pomijam wyciszone ścieżki: ${pomin.map((n) => "A" + n).join(", ")}.`);
  log("Rozpoznaję mowę (przy długich nagraniach to potrwa)…");
  const args = ["analizuj", "--xml", xml, "--folder", folder, "--jezyk", $("jezyk").value, "--silnik", $("silnik").value,
    "--min-pauza", $("pauza").value, "--zostaw", $("zostaw").value, "--pomin", pomin.join(",")];
  if (audio) args.push("--audio", audio);
  const a = await python("ciecie.py", args);
  usunPlik(audio); // silnik zrobił już z niego swój mały plik do rozpoznania mowy
  if (!a.ok) throw new Error(a.blad);
  log(`Mowa: ${a.slow} słów (${a.silnik}). Cisza do wycięcia: ${a.cisza_do_wyciecia_s} s. Wpadki z reguł: ${a.wpadek_z_regul}.`);
  return a;
}
async function claudeWpadki(folder) {
  if (!cfg.claude) { log("Nie znalazłem Claude Code na tym komputerze, zostają wpadki z reguł.", "e"); return; }
  log("Claude sprawdza wpadki…");
  const prompt = fs.readFileSync(path.join(SILNIK, "narzedzia", "prompty", "wpadki.md"), "utf8")
    .split("{FOLDER}").join(path.relative(SILNIK, folder).split(path.sep).join("/"));
  const r = await uruchom(cfg.claude, ["-p", "--output-format", "json", "--allowedTools", "Read"], { wejscie: prompt, limitMs: 20 * 60 * 1000 });
  let tekst = r.out;
  try { tekst = JSON.parse(r.out).result || r.out; } catch (e) {}
  const m = String(tekst).match(/\[[\s\S]*\]/);
  let lista = null;
  try { lista = m ? JSON.parse(m[0]) : null; } catch (e) {}
  if (!Array.isArray(lista)) { log("Claude nie zwrócił listy wpadek, zostają wpadki z reguł. " + (r.err || "").slice(-200), "e"); return; }
  lista = lista.filter((w) => typeof w.od === "number" && typeof w.do === "number" && w.do > w.od);
  fs.writeFileSync(path.join(folder, "wpadki.json"), JSON.stringify(lista, null, 1), "utf8");
  log(`Claude znalazł wpadek: ${lista.length}.`);
}
async function tnij(folder, xml, cisza = $("cisza").checked, wpadki = $("wpadki").value, pomin = [], audio = null) {
  await analiza(folder, xml, pomin, audio);
  if (wpadki !== "pomin" && $("claude").checked) await claudeWpadki(folder);
  log("Tworzę nową sekwencję…");
  const args = ["zastosuj", "--xml", xml, "--folder", folder, "--wpadki", wpadki];
  if (!cisza) args.push("--bez-ciszy");
  const z = await python("ciecie.py", args);
  if (!z.ok) throw new Error(z.blad);
  log(`Było ${Math.round(z.bylo_s)} s, jest ${Math.round(z.jest_s)} s (${z.ciec} cięć, ${z.markerow} markerów).`, "o");
  (z.uwagi || []).forEach((u) => log(u));
  return z;
}
function pokazListe(lista) {
  const l = $("lista");
  l.innerHTML = "";
  (lista || []).forEach((w) => {
    const b = document.createElement("button");
    const t = document.createElement("b");
    t.textContent = new Date(w.t * 1000).toISOString().substr(11, 8);
    b.appendChild(t);
    b.appendChild(document.createTextNode(w.opis.replace(/^\[[^\]]*\]\s*/, "")));
    b.onclick = () => jsx(`nm_idz(${Number(w.t)})`);
    l.appendChild(b);
  });
}
async function importuj(xml, nazwa) {
  const im = await jsx(`nm_importuj(${q(xml)}, ${q(nazwa || path.basename(xml, ".xml"))})`);
  if (!im.ok) { log(im.blad, "e"); return im; }
  log("Otwarto sekwencję: " + im.nazwa, "o");
  // timeline z silnika: dynamiczne przejścia Premiere + sprawdzenie, czy muzyka i efekty dźwiękowe są na osi
  const plikD = xml.replace(/\.xml$/i, "_dodatki.json"), d = fs.existsSync(plikD) ? czytajJson(plikD) : null;
  if (d) {
    try {
      const w = await jsx(`nm_dodatki_sekwencji(${JSON.stringify(d)})`);
      if (!w.ok) log("Przejścia i dźwięk po imporcie: " + w.blad, "e");
      else {
        const cz = [];
        if ((d.przejscia || []).length) cz.push(`przejścia Premiere: ${w.przejscia} z ${d.przejscia.length}` + (w.przejscia_brak.length ? ` (bez przejścia zostały markery w ${w.przejscia_brak.map((t) => czasTC(t)).join(", ")})` : ""));
        if (w.muzyka) cz.push(w.muzyka === "jest" ? "muzyka na osi" : "muzyka: " + w.muzyka);
        if (w.efekty_dodane) cz.push(`efekty dźwiękowe dołożone: ${w.efekty_dodane}`);
        if (cz.length) log("Po imporcie: " + cz.join(" · ") + ".", "o");
        (w.uwagi || []).forEach((u) => log(u, "e"));
      }
    } catch (e) { log("Przejścia i dźwięk po imporcie: " + (e.message || e), "e"); }
  }
  return im;
}
$("start").onclick = () => zablokuj(async () => {
  const { info, folder, xml } = await przygotuj("ciecie");
  // dźwięk do rozpoznania mowy: miks z Premiere tak, jak słychać (wyciszone ścieżki są w nim wyciszone)
  const audio = $("ciBezWyc").checked ? (log("Pobieram z Premiere dźwięk osi…"), await eksportAudio(info, folder, 0)) : null;
  if ($("ciBezWyc").checked && !audio) log("Do samego rozpoznania mowy biorę dźwięk z plików nagrań (to nie zmienia dźwięku na osi).");
  const z = await tnij(folder, xml, $("cisza").checked, $("wpadki").value, $("ciBezWyc").checked ? wyciszone(info) : [], audio);
  stan.raport = z.raport;
  await zastosujCiecie(info, z);
  pokazListe(z.lista);
  $("akcje").hidden = false;
});
/* Cięcie w samym Premiere: kopia sekwencji pocięta żyletką, więc klipy zostają te same (efekty, Lumetri, zoomy
   z klatkami kluczowymi, ustawienia kanałów audio, głośności). Gdy Premiere się nie zgodzi: nowa sekwencja z pliku XML. */
async function zastosujCiecie(info, z) {
  let w = null;
  if (z.ciecia && z.ciecia.length && info && info.id) {
    log("Tnę kopię sekwencji w Premiere (efekty, Lumetri, zoomy i ustawienia kanałów zostają)…");
    const d = { id: info.id, nazwa: z.nazwa, ciecia: z.ciecia, fps: z.fps, markery: z.markery || [], grupy: z.grupy || [], zablokowane: z.zablokowane || [] };
    w = await jsx(`nm_tnij_w_premiere(${JSON.stringify(d)})`);
  }
  if (w && w.ok) {
    log(`Otwarto sekwencję: ${w.nazwa}. Usunięte kawałki: ${w.usuniete}, przesunięte klipy: ${w.przesuniete}` + (w.polaczone ? `, obraz z dźwiękiem połączony w ${w.polaczone} miejscach` : "") + ".", "o");
    if ((z.zablokowane || []).length) log(`Zablokowane ścieżki (${z.zablokowane.join(", ")}) zostały bez cięć: skróć je ręcznie.`);
    (w.uwagi || []).forEach((u) => log(u, "e"));
    return w;
  }
  if (w) log("Cięcie w samym Premiere się nie udało (" + (w.blad || "?") + ")" + (w.zmieniono ? "; niedokończona kopia ma dopisek „NIEDOKOŃCZONE”" : "") +
    ". Wczytuję wersję z pliku XML: w niej Premiere gubi część efektów i ustawień kanałów.", "e");
  return importuj(z.xml, z.nazwa);
}
$("startTekst").onclick = () => zablokuj(async () => {
  const { info, folder, xml } = await przygotuj("transkrypcja");
  const audio = $("ciBezWyc").checked ? (log("Pobieram z Premiere dźwięk osi…"), await eksportAudio(info, folder, 0)) : null;
  if ($("ciBezWyc").checked && !audio) log("Do samego rozpoznania mowy biorę dźwięk z plików nagrań (to nie zmienia dźwięku na osi).");
  await analiza(folder, xml, $("ciBezWyc").checked ? wyciszone(info) : [], audio);
  const t = await python("ciecie.py", ["tekst", "--folder", folder, "--nazwy", $("nazwy").value]);
  if (!t.ok) throw new Error(t.blad);
  stan.raport = t.txt;
  log("Gotowe: " + path.basename(t.txt) + " i " + path.basename(t.srt), "o");
  $("akcje").hidden = false;
});
$("otworzFolder").onclick = () => otworzFolder(stan.folder);
$("otworzRaport").onclick = () => otworz(stan.raport);

// ======================= MULTICAM =======================
const MC_SUWAKI = [
  { k: "min_ujecie", n: "Najkrótsze ujęcie", min: 1, max: 8, step: 0.5, j: " s", o: "im więcej, tym rzadziej zmienia kamerę" },
  { k: "wtracenia", n: "Ignoruj krótkie wtrącenia", min: 0.3, max: 3, step: 0.1, j: " s", o: "„mhm”, „tak” krótsze niż tyle nie przełączają kamery" },
  { k: "przebicia_db", n: "Odporność na przebicia mikrofonów", min: 3, max: 20, step: 1, j: " dB", o: "więcej = głos, który wpada do cudzego mikrofonu, rzadziej przełącza kamerę" },
  { k: "czulosc", n: "Czułość mikrofonów", min: 0.1, max: 0.8, step: 0.05, j: "", o: "mniej = łapie też cichą mowę; więcej = tylko wyraźne wypowiedzi" },
  { k: "wyprzedzenie", n: "Cięcie przed wypowiedzią", min: 0, max: 0.8, step: 0.05, j: " s", o: "kamera zmienia się chwilę przed pierwszym słowem, jak u montażysty" },
  { k: "max_ujecie", n: "Przebitka po", min: 0, max: 40, step: 1, j: " s", o: "po tylu sekundach jednej osoby wstaw przebitkę (0 = nigdy)" },
  { k: "wstawka", n: "Długość przebitki", min: 1, max: 6, step: 0.5, j: " s" },
];
const MC_PRESETY = {
  spokojny: { min_ujecie: 4, wtracenia: 1.5, przebicia_db: 10, czulosc: 0.4, wyprzedzenie: 0.3, max_ujecie: 25, wstawka: 3 },
  normalny: { min_ujecie: 2.5, wtracenia: 1, przebicia_db: 8, czulosc: 0.35, wyprzedzenie: 0.25, max_ujecie: 15, wstawka: 2.5 },
  dynamiczny: { min_ujecie: 1.5, wtracenia: 0.7, przebicia_db: 8, czulosc: 0.3, wyprzedzenie: 0.2, max_ujecie: 9, wstawka: 2 },
};
$("mcSuwaki").innerHTML = MC_SUWAKI.map((s) => `<div class="w"><label for="mc_${s.k}">${s.n}</label><output id="mc_${s.k}O"></output>
  <input type="range" id="mc_${s.k}" min="${s.min}" max="${s.max}" step="${s.step}" value="${MC_PRESETY.normalny[s.k]}">${s.o ? `<small>${s.o}</small>` : ""}</div>`).join("");
MC_SUWAKI.forEach((s) => { suwak("mc_" + s.k, s.j, 2); $("mc_" + s.k).addEventListener("input", () => ustawSeg("mcPreset", "")); });
segment("mcPreset", (p) => { Object.entries(MC_PRESETY[p] || {}).forEach(([k, v]) => { $("mc_" + k).value = v; $("mc_" + k).dispatchEvent(new Event("input")); }); ustawSeg("mcPreset", p); });
suwak("mcMoc", "%", 0);
$("mcDzwiek").onchange = () => ($("mcDzwiekOpcje").hidden = !$("mcDzwiek").checked);
let mcOsoby = wczytaj("nm-mc-osoby", [{ nazwa: "Prowadzący", kamera: 2, mikrofon: 1 }, { nazwa: "Gość", kamera: 3, mikrofon: 2 }]);

function opcjeSciezek(lista, wybrana, zBrakiem) {
  return (zBrakiem ? '<option value="0">brak</option>' : "") + (lista || []).map((t) =>
    `<option value="${t.nr}" ${+wybrana === t.nr ? "selected" : ""}>${t.kod}${t.pierwszy ? " · " + t.pierwszy.replace(/</g, "").slice(0, 22) : ""}</option>`).join("");
}
function mcRysujOsoby() {
  const i = stan.info || { wideo: [], audio: [] };
  $("mcOsoby").innerHTML = mcOsoby.map((o, n) => `<div class="osoba" data-n="${n}">
    <input type="text" value="${String(o.nazwa).replace(/"/g, "&quot;")}" data-k="nazwa">
    <select data-k="kamera">${opcjeSciezek(i.wideo, o.kamera)}</select>
    <select data-k="mikrofon">${opcjeSciezek(i.audio, o.mikrofon)}</select>
    <button title="Usuń" ${mcOsoby.length <= 2 ? "disabled" : ""}>×</button></div>`).join("");
  $$(".osoba", $("mcOsoby")).forEach((w) => {
    const n = +w.dataset.n;
    $$("[data-k]", w).forEach((el) => (el.onchange = () => { mcOsoby[n][el.dataset.k] = el.dataset.k === "nazwa" ? el.value : +el.value; mcZapamietaj(); }));
    w.querySelector("button").onclick = () => { mcOsoby.splice(n, 1); mcRysujOsoby(); };
  });
}
$("mcDodaj").onclick = () => { if (mcOsoby.length < 4) { mcOsoby.push({ nazwa: "Gość " + mcOsoby.length, kamera: mcOsoby.length + 2, mikrofon: mcOsoby.length + 1 }); mcRysujOsoby(); } };
function mcSciezki() {
  const i = stan.info; if (!i) return;
  const og = wczytaj("nm-mc-ogolna", i.wideo.length >= 3 ? 1 : 0);
  $("mcOgolna").innerHTML = opcjeSciezek(i.wideo, og, true);
  $("mcMikOgolny").innerHTML = opcjeSciezek(i.audio, wczytaj("nm-mc-mikogolny", 0), true);
  mcRysujOsoby();
}
function mcZapamietaj() {
  zapisz("nm-mc-osoby", mcOsoby); zapisz("nm-mc-ogolna", +$("mcOgolna").value || 0); zapisz("nm-mc-mikogolny", +$("mcMikOgolny").value || 0);
  const u = { rozmowa: $("mc_rozmowa").value, wstawka_kat: $("mc_wstawka_kat").value, dzwiek: $("mcDzwiek").checked, moc: $("mcMoc").value, silnik: $("mcSilnik").value, tnij: $("mcTnij").checked, preset: wartoscSeg("mcPreset"), nieuzyte: $("mcNieuzyte").value };
  MC_SUWAKI.forEach((s) => (u[s.k] = +$("mc_" + s.k).value));
  zapisz("nm-mc", u);
}
function mcPrzywroc() {
  const u = wczytaj("nm-mc", null); if (!u) return;
  MC_SUWAKI.forEach((s) => { if (u[s.k] != null) { $("mc_" + s.k).value = u[s.k]; $("mc_" + s.k).dispatchEvent(new Event("input")); } });
  ["rozmowa", "wstawka_kat"].forEach((k) => u[k] && ($("mc_" + k).value = u[k]));
  $("mcDzwiek").checked = u.dzwiek !== false; $("mcMoc").value = u.moc || 80; $("mcMoc").dispatchEvent(new Event("input"));
  $("mcSilnik").value = u.silnik || "elevenlabs"; $("mcTnij").checked = !!u.tnij; ustawSeg("mcPreset", u.preset || "");
  $("mcNieuzyte").value = u.nieuzyte || "wylacz";
  $("mcDzwiekOpcje").hidden = !$("mcDzwiek").checked;
}
function mcUklad() {
  const u = { ogolna: +$("mcOgolna").value || 0, osoby: mcOsoby.map((o) => ({ nazwa: o.nazwa || "Osoba", kamera: +o.kamera, mikrofon: +o.mikrofon })),
    rozmowa: $("mc_rozmowa").value, wstawka_kat: $("mc_wstawka_kat").value, mikrofon_ogolny: +$("mcMikOgolny").value || 0 };
  MC_SUWAKI.forEach((s) => (u[s.k] = +$("mc_" + s.k).value));
  const kam = u.osoby.map((o) => o.kamera), mik = u.osoby.map((o) => o.mikrofon);
  if (new Set(kam).size !== kam.length) throw new Error("Każda osoba musi mieć inną kamerę.");
  if (new Set(mik).size !== mik.length) throw new Error("Każda osoba musi mieć inny mikrofon.");
  if (u.ogolna && kam.includes(u.ogolna)) throw new Error("Plan ogólny nie może być kamerą jednej z osób.");
  if (u.mikrofon_ogolny && mik.includes(u.mikrofon_ogolny)) throw new Error("Mikrofon ogólny nie może być mikrofonem jednej z osób.");
  return u;
}
const KOLORY_KAMER = ["#ff6b2c", "#60a5fa", "#4ade80", "#f472b6"];
function mcPokazUjecia(folder, u) {
  let d; try { d = JSON.parse(fs.readFileSync(path.join(folder, "ujecia.json"), "utf8")); } catch (e) { return; }
  const uj = d.ujecia || [], dl = uj.length ? uj[uj.length - 1][1] : 1;
  $("mcPasek").innerHTML = uj.map(([a, b, k]) => `<i style="width:${((b - a) / dl * 100).toFixed(3)}%;background:${k < 0 ? "#777" : KOLORY_KAMER[k % 4]}" title="${k < 0 ? "Plan ogólny" : u.osoby[k].nazwa} ${a.toFixed(1)}–${b.toFixed(1)} s"></i>`).join("");
  $("mcLegenda").innerHTML = (u.ogolna ? '<span><i style="background:#777"></i>Plan ogólny</span>' : "") + u.osoby.map((o, i) => `<span><i style="background:${KOLORY_KAMER[i % 4]}"></i>${o.nazwa.replace(/</g, "")}</span>`).join("");
  $("mcWynik").hidden = false;
}
$("mcStart").onclick = () => zablokuj(async () => {
  const u = mcUklad();
  const { info, folder, xml } = await przygotuj("multicam");
  const plikU = path.join(folder, "uklad.json");
  fs.writeFileSync(plikU, JSON.stringify(u, null, 1), "utf8");
  // mikrofony tak, jak grają na osi (kanały, Fill Left, głośność, efekty): eksport z Premiere, bez sięgania do oryginałów
  const zOsi = {};
  for (const nr of u.osoby.map((o) => o.mikrofon)) {
    log(`Pobieram z Premiere dźwięk mikrofonu A${nr} (tak, jak gra na osi)…`);
    const p = await eksportAudio(info, folder, nr);
    if (!p) throw new Error(`Premiere nie oddał dźwięku ścieżki A${nr}, więc przerywam (nie biorę dźwięku z oryginalnych plików). Nic na osi nie zmieniłem.`);
    zOsi[nr] = p;
  }
  const plikZ = aaZapiszZOsi(folder, zOsi);
  try {
    log("Słucham mikrofonów i układam ujęcia…");
    const a = await python("multicam.py", ["analizuj", "--xml", xml, "--folder", folder, "--uklad", plikU, "--z-premiere", plikZ]);
    if (!a.ok) throw new Error(a.blad);
    log(`Ujęć: ${a.ujec}, średnio ${a.srednie_ujecie_s} s.`, "o");
    mcPokazUjecia(folder, u);
    const args = ["zastosuj", "--xml", xml, "--folder", folder, "--nieuzyte", $("mcNieuzyte").value, "--z-premiere", plikZ];
    if ($("mcDzwiek").checked) { args.push("--dzwiek", "--moc", $("mcMoc").value, "--silnik", $("mcSilnik").value); log("Czyszczę i wyrównuję dźwięk mikrofonów (kilka minut na godzinę nagrania)…"); }
    var z = await python("multicam.py", args);
    if (!z.ok) throw new Error(z.blad);
  } finally { Object.values(zOsi).forEach(usunPlik); }
  // przełączanie kamer w samym Premiere, na kopii sekwencji: kadrowanie, LUT-y, Lumetri i efekty zostają
  log("Robię kopię sekwencji i przełączam w niej kamery (oryginał zostaje bez zmian)…");
  const d = Object.assign({ id: info.id, nazwa: (info.nazwa || "Podcast") + " - multicam", fps: info.fps }, z.premiere || {});
  const w = await jsx(`nm_multicam_w_premiere(${JSON.stringify(d)})`);
  if (!w.ok) {
    (w.uwagi || []).forEach((x) => log(x, "e"));
    throw new Error(w.blad + ` Wersja z pliku XML (bez części efektów) jest w folderze wyników: ${path.basename(z.xml)}.`);
  }
  log(`Otwarto sekwencję „${w.sekwencja}”: ` + (w.usuniete ? `usunięte nieużyte ujęcia: ${w.usuniete}` : `wyłączone nieużyte ujęcia: ${w.wylaczone} (Shift+E włącza)`) +
    (w.czyste_na.length ? `; czysty dźwięk mikrofonów na ${w.czyste_na.join(", ")}, oryginalne mikrofony wyłączone` : "") + `. Twoja „${w.oryginal}” jest bez zmian.`, "o");
  (w.uwagi || []).forEach((x) => log(x, "e"));
  if ($("mcTnij").checked) {
    log("Cięcie ciszy i wpadek na sekwencji multicam…");
    const info2 = await odswiezInfo();
    if (!info2.ok) throw new Error(info2.blad);
    const f2 = path.join(folder, "ciecie"); fs.mkdirSync(f2, { recursive: true });
    const xml2 = path.join(f2, "sekwencja.xml");
    const e = await jsx(`nm_eksportuj(${q(xml2)})`);
    if (!e.ok) throw new Error(e.blad);
    const audio = await eksportAudio(info2, f2, 0);
    if (!audio) log("Do samego rozpoznania mowy biorę dźwięk z plików nagrań (to nie zmienia dźwięku na osi).");
    const wynik = await tnij(f2, xml2, $("cisza").checked, $("wpadki").value, wyciszone(info2), audio);
    stan.raport = wynik.raport;
    await zastosujCiecie(info2, wynik);
    pokazListe(wynik.lista);
  }
  $("akcje").hidden = false;
});


// ======================= POPRAWA DŹWIĘKU (zaznaczone klipy) =======================
suwak("dzMoc", "%", 0);
$("dzMoc").value = wczytaj("nm-dz-moc", 80); $("dzMoc").dispatchEvent(new Event("input"));
$("dzSilnik").value = wczytaj("nm-dz-silnik", "elevenlabs");
$("dzStart").onclick = () => zablokuj(async () => {
  zapisz("nm-dz-moc", +$("dzMoc").value); zapisz("nm-dz-silnik", $("dzSilnik").value);
  // Punkt startu to oś: dźwięk zaznaczonych klipów tak, jak gra w Premiere (kanały, Fill Left, głośność, efekty).
  // Oryginalne nagrania nie są czytane ani kopiowane; wynik trafia do kopii sekwencji, Twoja zostaje nietknięta.
  const z = await jsx("nm_zaznaczone()");
  if (!z.ok) throw new Error(z.blad);
  const widziane = new Set();
  const klipy = (z.klipy || []).filter((k) => k.tor_a > 0 && !widziane.has(k.tor_a + "|" + k.start) && widziane.add(k.tor_a + "|" + k.start))
    .sort((a, b) => a.start - b.start);
  if (!klipy.length) throw new Error("Zaznacz na osi klipy z mową razem z ich dźwiękiem (kliknij klip; połączony dźwięk zaznacza się sam, z Shiftem kilka) i spróbuj ponownie.");
  const { info, folder } = await przygotuj("dzwiek");
  $("dzPasek").hidden = false; $("dzPasekI").style.width = "0%";
  const zOsi = {};
  for (const nr of [...new Set(klipy.map((k) => k.tor_a))]) {
    log(`Pobieram z Premiere dźwięk ścieżki A${nr} (tak, jak gra na osi)…`);
    const p = await eksportAudio(info, folder, nr);
    if (!p) throw new Error(`Premiere nie oddał dźwięku ścieżki A${nr}, więc przerywam (nie biorę dźwięku z oryginalnych plików). Nic na osi nie zmieniłem.`);
    zOsi[nr] = p;
  }
  const lista = klipy.map((k, i) => ({ id: `A${k.tor_a}_${String(i + 1).padStart(3, "0")}`, wav: zOsi[k.tor_a], od: k.start, do: k.end, tor: k.tor_a }));
  const plikL = path.join(folder, "klipy.json");
  fs.writeFileSync(plikL, JSON.stringify(lista, null, 1), "utf8");
  log(`Czyszczę dźwięk ${lista.length} ${lista.length === 1 ? "klipu" : "klipów"}…`);
  const d = await python("dzwiek.py", ["odcinki", "--lista", plikL, "--folder", folder, "--moc", $("dzMoc").value, "--silnik", $("dzSilnik").value],
    (u, t) => { if (u != null) $("dzPasekI").style.width = Math.round(u * 90) + "%"; if (t) log("… " + t); });
  Object.values(zOsi).forEach(usunPlik);
  if (!d.ok) throw new Error(d.blad);
  (d.uwagi || []).forEach((x) => log(x));
  const poId = {}; d.pliki.forEach((x) => (poId[x.id] = x.plik));
  const doKopii = lista.filter((x) => poId[x.id]).map((x) => ({ tor: x.tor, start: x.od, end: x.do, plik: poId[x.id] }));
  log("Robię kopię sekwencji i kładę w niej czysty dźwięk (oryginał zostaje bez zmian)…");
  const w = await jsx(`nm_dzwiek_w_kopii(${JSON.stringify({ id: info.id, nazwa: (info.nazwa || "Sekwencja") + " - czysty dźwięk", klipy: doKopii })})`);
  if (!w.ok) throw new Error(w.blad + ` Czyste pliki: ${folder}`);
  (w.uwagi || []).forEach((x) => log(x, "e"));
  $("dzPasekI").style.width = "100%";
  stan.folder = folder;
  log(`Gotowe: ${w.wstawione} z ${lista.length} klipów ma czysty dźwięk na ${w.sciezka} w nowej sekwencji „${w.sekwencja}”. Oryginalne klipy dźwięku są tam wyłączone (Shift+E włącza), a Twoja „${w.oryginal}” jest bez zmian.` +
    ($("dzSilnik").value === "elevenlabs" ? ` ElevenLabs: ok. ${(d.minuty || 0).toFixed(1)} min.` : ""), "o");
  $("akcje").hidden = false;
});

// ======================= NAPISY DO SEKWENCJI =======================
// Gotowe style napisów: te same co w Studio (narzedzia/napisy_style.json), podgląd rysuje narzedzia/napisy_podglad.js
let N_STYLE = [], NP = null;
const nStan = { id: wczytaj("nm-napisy-styl", "fiolet"), grupa: wczytaj("nm-napisy-grupa", "Wszystkie") };
function nWczytaj() {
  try { const pp = path.join(SILNIK, "narzedzia", "napisy_podglad.js"); delete NODE_REQ.cache[NODE_REQ.resolve(pp)]; NP = NODE_REQ(pp); } catch (e) { NP = null; }
  // najpierw Twoje: zapisane w Studio (przez aplikację Claude na PC) i zapisane tutaj w panelu
  const moje = ((czytajJson(path.join(SILNIK, "narzedzia", "napisy_style_moje.json")) || {}).style || []).concat(((czytajJson(PLIK_STYLI_PANELU()) || {}).style || []));
  N_STYLE = moje.concat((czytajJson(path.join(SILNIK, "narzedzia", "napisy_style.json")) || {}).style || []);
  if (moje.length && nStan.grupa === "Wszystkie" && !wczytaj("nm-napisy-grupa", null)) nStan.grupa = moje[0].grupa;
}
const PLIK_STYLI_PANELU = () => path.join(SILNIK, "narzedzia", "napisy_style_panel.json");
function nWybrany() { return N_STYLE.find((x) => x.id === nStan.id) || N_STYLE[0] || { id: "fiolet", nazwa: "Fiolet", styl: {} }; }
function nGaleria() {
  if (!N_STYLE.length) nWczytaj();
  const grupy = ["Wszystkie", ...new Set(N_STYLE.map((x) => x.grupa))];
  $("nGrupy").innerHTML = grupy.map((g) => `<button data-g="${g}" aria-pressed="${g === nStan.grupa}">${g} <span style="color:#777">${g === "Wszystkie" ? N_STYLE.length : N_STYLE.filter((x) => x.grupa === g).length}</span></button>`).join("");
  $$("button", $("nGrupy")).forEach((b) => (b.onclick = () => { nStan.grupa = b.dataset.g; zapisz("nm-napisy-grupa", nStan.grupa); nGaleria(); }));
  const lista = N_STYLE.filter((x) => nStan.grupa === "Wszystkie" || x.grupa === nStan.grupa);
  $("nStyle").innerHTML = lista.map((x) => `<div class="karta" role="button" tabindex="0" data-id="${x.id}" aria-pressed="${x.id === nStan.id}" title="${x.nazwa}"><canvas width="180" height="110" style="aspect-ratio:180/110;background:#3a3f47"></canvas><span>${x.nazwa}</span></div>`).join("");
  $$(".karta", $("nStyle")).forEach((k) => {
    const x = N_STYLE.find((y) => y.id === k.dataset.id), c = k.querySelector("canvas");
    zaladujRodzine(x.styl.font || "Montserrat", () => nMiniatura(c, x));
    nMiniatura(c, x);
    k.onclick = () => nUstawStyl(x.id);
  });
}
function nMiniatura(c, x) {
  if (!NP) return;
  const ctx = c.getContext("2d"); ctx.clearRect(0, 0, c.width, c.height);
  const g = ctx.createLinearGradient(0, 0, 0, c.height); g.addColorStop(0, "#56606e"); g.addColorStop(1, "#2a2f36"); ctx.fillStyle = g; ctx.fillRect(0, 0, c.width, c.height);
  const st = Object.assign({}, x.styl, { pozycja_y: 42, rozmiar: Math.min(130, (x.styl.rozmiar || 72)) * 1.55, slow_na_raz: 3, max_linii: 2 });
  try { ctx.save(); ctx.scale(1 / 3, 1 / 3); NP.rysuj(ctx, st, c.width * 3, c.height * 3, ["Tak", "wyglądają", "napisy"], 1); ctx.restore(); } catch (e) {}
}
function nUstawStyl(id, bezKontrolek) {
  nStan.id = id; zapisz("nm-napisy-styl", id);
  const st = NP ? NP.styl(nWybrany().styl) : nWybrany().styl;
  $$(".karta", $("nStyle")).forEach((k) => k.setAttribute("aria-pressed", String(k.dataset.id === id)));
  $("nStylNazwa").textContent = `Styl: ${nWybrany().nazwa}. Możesz zmienić font, kolory, wielkość i miejsce poniżej.`;
  if (bezKontrolek) return;
  $("nFont").value = st.font; wypelnijWarianty($("nWaga"), (st.grubosc || 800) + (st.kursywa ? "i" : ""));
  $("nKolorTekstu").value = String(st.kolor).slice(0, 7);
  $("nKolor").value = st.aktywne_tlo_wl ? st.aktywne_tlo : st.aktywne_kolor;
  [["nRozmiar", st.rozmiar], ["nY", st.pozycja_y], ["nSlow", st.slow_na_raz]].forEach(([k, v]) => { $(k).value = v; $(k).dispatchEvent(new Event("input")); });
  $("nWielkie").checked = st.litery === "wielkie";
}
suwak("nRozmiar", " px", 0); suwak("nY", "%", 0); suwak("nSlow", "", 0);
(() => { const u = wczytaj("nm-napisy", null); if (!u) return;
  ["nFont", "nKolor", "nKolorTekstu", "nRozmiar", "nY", "nSlow", "nJezyk", "nSilnik"].forEach((k) => { if (u[k] != null && $(k)) { $(k).value = u[k]; $(k).dispatchEvent(new Event("input")); } });
  $("nWielkie").checked = u.nWielkie !== false; nStan.wagaZapisana = u.nWaga; })();
function nStylJSON() {
  const baza = Object.assign({}, nWybrany().styl), k = $("nKolor").value, kt = $("nKolorTekstu").value, w = $("nWaga").value || "800";
  const st = Object.assign(baza, { font: $("nFont").value.trim() || baza.font || "Montserrat", grubosc: parseInt(w, 10) || 800, kursywa: /i$/.test(w),
    rozmiar: +$("nRozmiar").value, pozycja_y: +$("nY").value, slow_na_raz: +$("nSlow").value, litery: $("nWielkie").checked ? (baza.litery === "male" ? "normalne" : "wielkie") : (baza.litery === "male" ? "male" : "normalne") });
  // kolor słów: zachowaj przezroczystość ze stylu (np. kontur)
  if (!/^#?[0-9a-f]{6}00$/i.test(String(baza.kolor || ""))) st.kolor = kt;
  if (baza.aktywne_tlo_wl !== false) st.aktywne_tlo = k; else st.aktywne_kolor = k;
  zapisz("nm-napisy", { nFont: $("nFont").value, nWaga: w, nKolor: k, nKolorTekstu: kt, nRozmiar: $("nRozmiar").value, nY: $("nY").value, nSlow: $("nSlow").value, nWielkie: $("nWielkie").checked, nJezyk: $("nJezyk").value, nSilnik: $("nSilnik").value });
  return st;
}
/* ---------- napisy: każdy fragment osobnym klipem, poprawki w panelu ---------- */
const NAP = { proj: null, plik: null, ids: {}, zajete: false, kolejka: {}, timer: 0 };
function nPasek(ulamek, tekst) {
  $("nPasek").hidden = false; $("nPasekT").hidden = false;
  if (ulamek != null) $("nPasekI").style.width = Math.round(Math.max(0, Math.min(1, ulamek)) * 100) + "%";
  if (tekst) $("nPasekT").textContent = tekst + (ulamek != null ? ` (${Math.round(ulamek * 100)}%)` : "");
  else if (ulamek != null) $("nPasekT").textContent = $("nPasekT").textContent.replace(/ \(\d+%\)$/, "") + ` (${Math.round(ulamek * 100)}%)`;
}
function nPasekKoniec(tekst) { $("nPasekI").style.width = "100%"; $("nPasekT").textContent = tekst || ""; setTimeout(() => { $("nPasek").hidden = true; if (!tekst) $("nPasekT").hidden = true; }, 1500); }
function nFonty() { return folderKlienta() && fs.existsSync(path.join(folderKlienta(), "fonty")) ? ["--fonty", path.join(folderKlienta(), "fonty")] : []; }
function nZapiszProj() { if (NAP.plik && NAP.proj) { NAP.proj.ids = NAP.ids; fs.writeFileSync(NAP.plik, JSON.stringify(NAP.proj, null, 1), "utf8"); } }
function nWczytajProj(plik) {
  const d = czytajJson(plik); if (!d || !Array.isArray(d.segmenty)) return false;
  NAP.proj = d; NAP.plik = plik; NAP.ids = d.ids || {};
  zapisz("nm-napisy-proj-" + ((stan.info && stan.info.id) || "x"), plik);
  return true;
}
function nRejestruj() {
  const r = anRejestr();
  Object.entries(NAP.ids).forEach(([seg, id]) => { if (id) r["id:" + id] = { typ: "napis", projekt: NAP.plik, seg: +seg }; });
  fs.mkdirSync(path.dirname(PLIK_NA_OSI()), { recursive: true }); fs.writeFileSync(PLIK_NA_OSI(), JSON.stringify(r, null, 1), "utf8");
}
const tekstSeg = (sg) => (sg.slowa || []).map((w) => w.slowo).join(" ");
function nRysujListe() {
  const d = NAP.proj; $("nEdytor").hidden = !d; if (!d) return;
  const f = $("nSzukaj").value.trim().toLowerCase();
  const segi = d.segmenty.filter((sg) => !f || tekstSeg(sg).toLowerCase().includes(f));
  const zywe = d.segmenty.filter((sg) => !sg.usuniety).length;
  $("nLicznik").textContent = `Napisy na osi: ${zywe}`;
  $("nLista").innerHTML = segi.map((sg) => `<div class="n-wiersz${sg.usuniety ? " usuniety" : ""}" data-seg="${sg.id}">
      <button class="czas" data-a="idz" title="Głowica tutaj">${czasTC(sg.od)}<br>${czasTC(sg.do)}</button>
      <textarea class="tekst" rows="1" spellcheck="true" lang="pl" ${sg.usuniety ? "disabled" : ""}>${tekstSeg(sg).replace(/</g, "&lt;")}</textarea>
      <div class="przyc">${sg.usuniety ? `<span class="uwaga">usunięty</span>` : `<button data-a="w" title="0,1 s wcześniej">◀</button><button data-a="p" title="0,1 s później">▶</button><button data-a="x" title="Usuń z osi">✕</button>`}</div>
      <div class="st" hidden></div></div>`).join("") || '<p class="uwaga">Brak napisów.</p>';
  $$(".n-wiersz", $("nLista")).forEach((w) => {
    const id = +w.dataset.seg, sg = d.segmenty.find((x) => x.id === id), st = w.querySelector(".st");
    const pokazSt = (t) => { st.hidden = !t; st.textContent = t || ""; };
    w.querySelector('[data-a="idz"]').onclick = () => jsx(`nm_idz(${sg.od + 0.05})`);
    const ta = w.querySelector("textarea");
    if (ta) ta.oninput = () => { NAP.kolejka[id] = ta.value; pokazSt("zmiana czeka…"); clearTimeout(NAP.timer); NAP.timer = setTimeout(nWyslijZmiany, 1200); };
    const przes = async (o) => {
      const idK = NAP.ids[id]; if (!idK) return;
      const r = await jsx(`nm_przesun_klip(${q(idK)}, ${o}, ${q(sg.plik || "")})`);
      if (!r.ok) { pokazSt(r.blad); return; }
      nPrzesunSeg(sg, r.start, r.end); nZapiszProj(); w.querySelector(".czas").innerHTML = `${czasTC(sg.od)}<br>${czasTC(sg.do)}`;
    };
    const bw = w.querySelector('[data-a="w"]'), bp = w.querySelector('[data-a="p"]'), bx = w.querySelector('[data-a="x"]');
    if (bw) bw.onclick = () => przes(-0.1);
    if (bp) bp.onclick = () => przes(0.1);
    if (bx) bx.onclick = async () => {
      const idK = NAP.ids[id]; if (idK) { const r = await jsx(`nm_usun_klip(${q(idK)}, ${q(sg.plik || "")})`); if (!r.ok) { pokazSt(r.blad); return; } }
      sg.usuniety = true; nZapiszProj(); nRysujListe();
    };
  });
  nPodswietl();
}
function nPrzesunSeg(sg, od, doo) {
  const prz = od - sg.od;
  if (Math.abs(prz) > 0.0005) sg.slowa = (sg.slowa || []).map((w) => Object.assign({}, w, { start: +(w.start + prz).toFixed(3), koniec: +(w.koniec + prz).toFixed(3) }));
  sg.od = +od.toFixed(3); sg.do = +doo.toFixed(3);
}
/* Przesunięcia, przycięcia i usunięcia zrobione w Premiere wracają do listy. */
async function nZOsi(cicho) {
  if (!NAP.proj || HOST !== "PPRO") return;
  const ids = Object.values(NAP.ids).filter(Boolean); if (!ids.length) return;
  const r = await jsx(`nm_klipy_stan(${JSON.stringify(ids)})`);
  if (!r.ok) { if (!cicho) alertBlad(r.blad); return; }
  let zm = 0;
  NAP.proj.segmenty.forEach((sg) => {
    const idK = NAP.ids[sg.id]; if (!idK || sg.usuniety) return;
    let k = r.klipy[idK];
    if (k && (k.nasz === false || (k.sciezka && sg.plik && path.basename(k.sciezka).toLowerCase() !== path.basename(sg.plik).toLowerCase()))) { NAP.ids[sg.id] = ""; k = null; } // pod tym numerem jest teraz inny klip
    if (!k) { sg.usuniety = true; zm++; return; }
    if (Math.abs(k.start - sg.od) > 0.01 || Math.abs(k.end - sg.do) > 0.01) { nPrzesunSeg(sg, k.start, k.end); zm++; }
  });
  if (zm) { nZapiszProj(); nRysujListe(); }
  if (!cicho) $("nEdStan").textContent = zm ? `Wczytane z osi: ${zm} zmian (przesunięcia, przycięcia, usunięcia).` : "Na osi wszystko zgadza się z listą.";
}
/* Zmiany tekstu: renderuje tylko poprawione napisy i podmienia je na osi w tym samym miejscu. */
async function nWyslijZmiany() {
  if (NAP.zajete) { clearTimeout(NAP.timer); NAP.timer = setTimeout(nWyslijZmiany, 700); return; }
  const zm = Object.entries(NAP.kolejka).map(([id, tekst]) => ({ id: +id, tekst })); NAP.kolejka = {};
  if (!zm.length || !NAP.proj) return;
  NAP.zajete = true;
  try {
    await nZOsi(true);
    zm.forEach((z) => { const sg = NAP.proj.segmenty.find((x) => x.id === z.id); if (sg) { z.od = sg.od; z.do = sg.do; } });
    nZapiszProj();
    const r = await python("napisy.py", ["popraw", "--folder", path.dirname(NAP.plik), "--zmiany", JSON.stringify(zm), ...nFonty()], (u, t) => t && ($("nEdStan").textContent = t + "…"));
    if (!r.ok) throw new Error(r.blad);
    NAP.stare = Object.fromEntries(NAP.proj.segmenty.map((sg) => [sg.id, sg.plik])); // pliki przed poprawką: po nich panel sprawdza, że podmienia swój napis
    nScalZPythona(r.zmienione);
    $("nEdStan").textContent = "Popraw tekst w polu: po chwili napis sam się podmieni na osi.";
    const lista = r.zmienione.filter((x) => NAP.ids[x.id]).map((x) => ({ id: NAP.ids[x.id], p: x.plik, seg: x.id, stary: nStaryPlik(x.id) }));
    if (lista.length) {
      const w = await jsx(`nm_podmien_wiele(${JSON.stringify(lista.map((x) => ({ id: x.id, p: x.p, stary: x.stary })))}, ${q(NAP.kosz())})`);
      if (!w.ok) throw new Error(w.blad);
      lista.forEach((x, i) => { if (w.ids[i]) { OS.stare.add(x.id); NAP.ids[x.seg] = w.ids[i]; } });
      nZapiszProj(); nRejestruj();
    }
    zm.forEach((z) => { const st = document.querySelector(`.n-wiersz[data-seg="${z.id}"] .st`); if (st) { st.hidden = false; st.textContent = "poprawione na osi ✓"; setTimeout(() => (st.hidden = true), 2500); } });
  } catch (e) { alertBlad(e); }
  NAP.zajete = false;
}
/* Python zapisał nowe wersje części napisów: bierzemy z pliku tylko je, resztę (przesunięcia, usunięcia zrobione w międzyczasie) zostawiamy. */
function nScalZPythona(zmienione) {
  const d = czytajJson(NAP.plik); if (!d || !NAP.proj) return;
  const ids = new Set(zmienione.map((x) => +x.id));
  NAP.proj.segmenty = NAP.proj.segmenty.map((sg) => { if (!ids.has(sg.id)) return sg; const n = d.segmenty.find((x) => x.id === sg.id); return n ? Object.assign({}, n, { usuniety: sg.usuniety || n.usuniety }) : sg; });
  NAP.proj.wersja = Math.max(+NAP.proj.wersja || 1, +d.wersja || 1); NAP.proj.styl = d.styl;
  nZapiszProj();
}
const nStaryPlik = (id) => (NAP.stare && NAP.stare[id]) || "";
NAP.kosz = () => "Nada – napisy " + path.basename(path.dirname(NAP.plik || "x"));
function nPodswietl() {
  const st = OS.stan; if (!st || !st.ok || !NAP.proj) return;
  const odw = {}; Object.entries(NAP.ids).forEach(([seg, id]) => (odw[id] = +seg));
  const zazn = new Set((st.zaznaczone || []).map((x) => odw[x.idKlipu]).filter(Boolean));
  let pierwszy = null;
  $$(".n-wiersz", $("nLista")).forEach((w) => { const z = zazn.has(+w.dataset.seg); w.classList.toggle("zazn", z); if (z && !pierwszy) pierwszy = w; });
  if (pierwszy && NAP.ostatnioZazn !== pierwszy.dataset.seg) { NAP.ostatnioZazn = pierwszy.dataset.seg; pierwszy.scrollIntoView({ block: "nearest" }); }
}
async function nZrob() {
  const st = nStylJSON(), tryb = $("nTryb").value;
  const { info, folder, xml } = await przygotuj("napisy");
  const pasek = (u, t) => nPasek(u, t);
  nPasek(0, "Zaczynam…");
  const args = ["--xml", xml, "--folder", folder, "--styl", JSON.stringify(st), "--W", String(info.szer || 1920), "--H", String(info.wys || 1080), "--silnik", $("nSilnik").value, ...nFonty()];
  if ($("nJezyk").value) args.push("--jezyk", $("nJezyk").value);
  // mowa z dźwięku osi tak, jak słychać w Premiere (wyciszone ścieżki i muzyka ustawione po Twojemu)
  nPasek(0.01, "Pobieram z Premiere dźwięk osi…");
  const audio = await eksportAudio(info, folder, 0);
  if (audio) args.push("--audio", audio); else log("Do rozpoznania mowy biorę dźwięk z plików nagrań.");
  if (tryb === "jeden" || tryb === "premiere") {
    const r = await python("napisy.py", ["sekwencja", ...args], pasek); usunPlik(audio);
    if (!r.ok) throw new Error(r.blad);
    stan.folder = folder; stan.raport = r.srt;
    if (tryb === "premiere") {
      const w = await jsx(`nm_napisy_premiere(${q(r.srt)})`);
      if (!w.ok) throw new Error(w.blad);
      nPasekKoniec("Gotowe: napisy Premiere są na nowej ścieżce napisów (tekst poprawiasz w panelu Tekst > Napisy).");
      return;
    }
    const w = await jsx(`nm_wstaw(${q(r.mov)}, 0, ${r.dlugosc_s || 10})`);
    if (!w.ok) throw new Error(w.blad);
    nPasekKoniec(`Gotowe: napisy (${r.liczba_slow} słów) są na ${w.sciezka}.`);
    return;
  }
  const r = await python("napisy.py", ["segmenty", ...args], pasek); usunPlik(audio);
  if (!r.ok) throw new Error(r.blad);
  stan.folder = folder; stan.raport = r.srt;
  nWczytajProj(r.projekt); NAP.ids = {};
  nPasek(0.99, `Kładę ${r.liczba} napisów na osi…`);
  const lista = NAP.proj.segmenty.map((sg) => ({ p: path.join(folder, sg.plik), od: sg.od, do: sg.do }));
  const w = await jsx(`nm_wstaw_napisy(${JSON.stringify(lista)}, ${q(NAP.kosz())})`);
  if (!w.ok) throw new Error(w.blad);
  NAP.proj.segmenty.forEach((sg, i) => (NAP.ids[sg.id] = w.ids[i] || ""));
  nZapiszProj(); nRejestruj();
  if ($("nSrtTez").checked) { const p2 = await jsx(`nm_napisy_premiere(${q(r.srt)})`); if (!p2.ok) log("Ścieżka napisów Premiere: " + p2.blad, "e"); }
  nPasekKoniec(`Gotowe: ${r.liczba} napisów na ${w.sciezka}${w.brak ? ` (${w.brak} nie weszło)` : ""}. Poprawiaj je na liście niżej.`);
  log(`Napisy: ${r.liczba} fragmentów (${r.liczba_slow} słów) na ${w.sciezka}. Plik SRT: ${path.basename(r.srt)}.` + (r.font ? ` Font: ${path.basename(r.font)}.` : ""), "o");
  nRysujListe();
}
$("nStart").onclick = () => zablokuj(nZrob);
$("nZapiszStyl").onclick = () => {
  const d = czytajJson(PLIK_STYLI_PANELU()) || { style: [] };
  const nazwa = `${nWybrany().nazwa.replace(/^Mój: /, "")} · ${$("nFont").value || "font"}`.slice(0, 50);
  d.style.push({ id: "panel-" + Date.now().toString(36), nazwa: "Mój: " + nazwa, grupa: "Moje (panel)", styl: nStylJSON() });
  fs.writeFileSync(PLIK_STYLI_PANELU(), JSON.stringify(d, null, 1), "utf8");
  nWczytaj(); nStan.grupa = "Moje (panel)"; nGaleria(); nUstawStyl(d.style[d.style.length - 1].id, true);
  $("nZapiszStyl").textContent = "★ Zapisany"; setTimeout(() => ($("nZapiszStyl").textContent = "☆ Zapisz jako mój styl"), 2000);
};
$("nZOsi").onclick = () => nZOsi(false);
$("nSzukaj").oninput = () => nRysujListe();
$("nWygladWszystkie").onclick = async () => {
  if (!NAP.proj || NAP.zajete) return;
  NAP.zajete = true; const b = $("nWygladWszystkie"), t = b.textContent; b.disabled = true;
  try {
    await nZOsi(true); nZapiszProj();
    nPasek(0, "Rysuję wszystkie napisy w nowym wyglądzie…");
    const r = await python("napisy.py", ["popraw", "--folder", path.dirname(NAP.plik), "--styl", JSON.stringify(nStylJSON()), "--wszystkie", ...nFonty()], (u, tx) => nPasek(u, tx));
    if (!r.ok) throw new Error(r.blad);
    NAP.stare = Object.fromEntries(NAP.proj.segmenty.map((sg) => [sg.id, sg.plik])); // pliki przed poprawką: po nich panel sprawdza, że podmienia swój napis
    nScalZPythona(r.zmienione);
    const lista = r.zmienione.filter((x) => NAP.ids[x.id]).map((x) => ({ id: NAP.ids[x.id], p: x.plik, seg: x.id, stary: nStaryPlik(x.id) }));
    nPasek(0.97, `Podmieniam ${lista.length} napisów na osi…`);
    const w = await jsx(`nm_podmien_wiele(${JSON.stringify(lista.map((x) => ({ id: x.id, p: x.p, stary: x.stary })))}, ${q(NAP.kosz())})`);
    if (!w.ok) throw new Error(w.blad);
    lista.forEach((x, i) => { if (w.ids[i]) { OS.stare.add(x.id); NAP.ids[x.seg] = w.ids[i]; } });
    nZapiszProj(); nRejestruj();
    nPasekKoniec(`Nowy wygląd na ${lista.length} napisach.`);
  } catch (e) { alertBlad(e); nPasekKoniec(""); }
  NAP.zajete = false; b.disabled = false; b.textContent = t;
};
/* Po otwarciu Napisów: ostatnie napisy tej sekwencji wracają na listę. */
function nPrzywroc() {
  if (NAP.proj) { nRysujListe(); nZOsi(true); return; }
  const p = wczytaj("nm-napisy-proj-" + ((stan.info && stan.info.id) || "x"), null);
  if (p && fs.existsSync(p) && nWczytajProj(p)) { nRysujListe(); nZOsi(true); }
}

// ======================= ASYSTENT AUDIO =======================
const AA_TYPY = [["dialog", "Mowa"], ["muzyka", "Muzyka"], ["efekty", "Efekty"], ["tlo", "Tło"], ["pomin", "Pomiń"]];
const AA_KROKI = [["odszumianie", "Odszumianie"], ["poglos", "Usuwanie pogłosu"], ["buczenie", "Usuwanie buczenia"], ["przester", "Naprawa przesterów"],
  ["deesser", "De-esser (syczenie)"], ["bramka", "Bramka (cisza między słowami)"], ["barwa", "Barwa (EQ, mikrofony)"],
  ["wyrownanie", "Wyrównanie mowy (leveler)"], ["kompresja", "Kompresja mowy"]];
const AA_POZ = [["auto", "Auto"], ["wyl", "Wył."], ["lekko", "Lekko"], ["srednio", "Średnio"], ["mocno", "Mocno"]];
const AA_NAZWY_POZ = ["wył.", "lekko", "średnio", "mocno"];
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
function aaUst() { return wczytaj("nm-aa", {}); }
function aaZapiszUst() {
  const u = { mowa: {}, duck: $("aaDuck").value, rzezba: $("aaRzezba").checked, cel: $("aaCel").value, klej: $("aaKlej").checked, wstaw: $("aaWstaw").value, wycisz: $("aaWycisz").checked, ai: $("aaAI").checked, bezWyc: $("aaBezWyc").checked };
  AA_KROKI.forEach(([k]) => { const el = $("aaM_" + k); if (el) u.mowa[k] = el.value; });
  zapisz("nm-aa", u);
}
(function aaBuduj() {
  const u = aaUst();
  $("aaMowa").innerHTML = AA_KROKI.map(([k, t]) => `<div class="w"><span>${t}</span><span></span><select id="aaM_${k}">${AA_POZ.map(([v, n]) => `<option value="${v}">${n}</option>`).join("")}</select></div>`).join("");
  AA_KROKI.forEach(([k]) => { const el = $("aaM_" + k); el.value = (u.mowa && u.mowa[k]) || "auto"; el.onchange = aaZapiszUst; });
  if (u.duck != null) $("aaDuck").value = u.duck;
  if (u.rzezba != null) $("aaRzezba").checked = u.rzezba;
  if (u.cel && [...$("aaCel").options].some((o) => o.value === u.cel)) $("aaCel").value = u.cel;
  if (u.klej != null) $("aaKlej").checked = u.klej;
  if (u.wstaw) $("aaWstaw").value = u.wstaw;
  if (u.wycisz != null) $("aaWycisz").checked = u.wycisz;
  if (u.bezWyc != null) $("aaBezWyc").checked = u.bezWyc;
  $("aaAI").checked = false; // kredyty: zawsze świadomy wybór, nie zapamiętujemy
  ["aaDuck", "aaRzezba", "aaCel", "aaKlej", "aaWstaw", "aaWycisz", "aaBezWyc"].forEach((id) => $(id).addEventListener("change", aaZapiszUst));
  $("aaAI").addEventListener("change", () => {
    if (!$("aaAI").checked) return;
    const min = ((stan.aa && stan.aa.sciezki) || []).filter((s) => s.typ === "dialog").reduce((a, s) => a + (s.zrodla || []).reduce((b, z) => b + (z.dlugosc_s || 0), 0), 0) / 60;
    log(`Izolacja głosu AI włączona: nagrania mowy pójdą do ElevenLabs i zużyją kredyty ElevenLabs` + (min ? ` (ok. ${Math.ceil(min)} min nagrań)` : "") + `. Odznacz, jeśli nie chcesz wydawać kredytów.`, "e");
  });
})();
function aaDiagnoza(s) {
  if (s.typ !== "dialog" || !s.zrodla || !s.zrodla.length) return "";
  const rek = s.rekomendacja || {};
  const auto = AA_KROKI.filter(([k]) => rek[k] > 0 && !["barwa", "kompresja", "wyrownanie"].includes(k)).map(([k, t]) => `${t.split(" (")[0].toLowerCase()} ${AA_NAZWY_POZ[rek[k]]}`);
  const z = s.zrodla.map((x) => (s.zrodla.length > 1 ? `<b>${esc(x.plik)}</b>: ` : "") + esc(x.opis)).join("<br>");
  return `<div class="aa-diag">Słychać: ${z}${auto.length ? `<br>Auto zrobi: ${esc(auto.join(", "))} + barwa, wyrównanie, kompresja` : "<br>Auto zrobi: barwa, wyrównanie, kompresja (nagranie jest czyste)"}</div>`;
}
function aaRysuj() {
  const l = (stan.aa && stan.aa.sciezki) || [];
  const torPr = (nr) => (((stan.aa && stan.aa.info) || {}).audio || []).find((a) => a.nr === nr);
  const nazwaToru = (s) => { const tr = torPr(s.nr); return tr && tr.nazwa && !/^(Audio|Dźwięk)\s*\d+$/i.test(tr.nazwa) ? tr.nazwa : ""; };
  $("aaSciezki").innerHTML = l.map((s, n) => `<div class="aa-wiersz" data-n="${n}"><b>${s.kod}</b><span title="${esc((nazwaToru(s) ? nazwaToru(s) + ": " : "") + s.nazwa)}">${nazwaToru(s) ? `<strong>${esc(nazwaToru(s))}</strong> · ` : ""}${esc(s.nazwa)}${s.lufs != null ? ` · ${s.lufs} LUFS` : ""}${torPr(s.nr) && torPr(s.nr).wyciszona ? " · wyciszona (M)" : ""}</span>
    <select data-k="typ">${AA_TYPY.map(([k, t]) => `<option value="${k}" ${s.typ === k ? "selected" : ""}>${t}</option>`).join("")}</select>
    <div class="w"><label>Głośniej / ciszej</label><output data-o>${(s.korekta_db || 0) > 0 ? "+" : ""}${s.korekta_db || 0} dB</output><input type="range" min="-12" max="12" step="1" value="${s.korekta_db || 0}" data-k="korekta_db"><small>${s.typ === "pomin" ? esc(s.powod || "") : "rozpoznane: " + ((AA_TYPY.find(([k]) => k === s.typ) || [, s.typ])[1] || "").toLowerCase() + " (" + esc(s.powod) + ")"}</small></div>${aaDiagnoza(s)}</div>`).join("");
  $$(".aa-wiersz", $("aaSciezki")).forEach((w) => {
    const s = stan.aa.sciezki[+w.dataset.n];
    w.querySelector('[data-k="typ"]').onchange = (e) => { s.typ = e.target.value; aaRysuj(); };
    const r = w.querySelector('[data-k="korekta_db"]');
    r.oninput = () => { s.korekta_db = +r.value; w.querySelector("[data-o]").textContent = (s.korekta_db > 0 ? "+" : "") + s.korekta_db + " dB"; };
  });
  $("aaOpcje").hidden = !l.length;
}
/* Dźwięk każdej ścieżki prosto z Premiere (tak, jak gra na osi); gdy eksport się nie uda, asystent czyta pliki. */
async function aaEksportuj(info, folder, numery, zOsi) {
  for (const nr of numery) {
    if (zOsi[nr] && fs.existsSync(zOsi[nr])) continue;
    log(`Pobieram z Premiere dźwięk ścieżki A${nr} (tak, jak gra na osi)…`);
    const p = await eksportAudio(info, folder, nr);
    // Asystent pracuje tylko na dźwięku z osi: bez eksportu z Premiere nie sięga po oryginalne pliki.
    if (!p) throw new Error(`Premiere nie oddał dźwięku ścieżki A${nr}, więc przerywam (nie biorę dźwięku z oryginalnych plików). Nic na osi nie zmieniłem.`);
    zOsi[nr] = p;
  }
  return zOsi;
}
function aaZapiszZOsi(folder, zOsi) {
  const plik = path.join(folder, "dzwiek_z_osi.json");
  fs.writeFileSync(plik, JSON.stringify(zOsi, null, 1), "utf8");
  return plik;
}
$("aaAnaliza").onclick = () => zablokuj(async () => {
  const { info, folder, xml } = await przygotuj("miks");
  const pomin = $("aaBezWyc").checked ? wyciszone(info) : [];
  if (pomin.length) log(`Pomijam wyciszone ścieżki: ${pomin.map((n) => "A" + n).join(", ")} (możesz je włączyć, zmieniając „Pomiń” na rodzaj).`);
  const zOsi = await aaEksportuj(info, folder, ((info.audio || []).filter((x) => x.klipow > 0 && !pomin.includes(x.nr))).map((x) => x.nr), {});
  log("Słucham każdej ścieżki audio i każdego nagrania mowy…");
  const a = await python("audio_asystent.py", ["analizuj", "--xml", xml, "--folder", folder, "--pomin", pomin.join(","), "--z-premiere", aaZapiszZOsi(folder, zOsi)]);
  if (!a.ok) throw new Error(a.blad);
  stan.aa = { info, folder, xml, zOsi, sciezki: a.sciezki.map((s) => Object.assign({ korekta_db: 0 }, s)) };
  aaRysuj();
  log(`Ścieżek: ${a.sciezki.length}. Sprawdź rozpoznanie (możesz zmienić) i kliknij „Zrób miks”.`, "o");
});
$("aaMiks").onclick = () => zablokuj(async () => {
  if (!stan.aa) throw new Error("Najpierw przeanalizuj ścieżki.");
  aaZapiszUst();
  const mowa = {};
  AA_KROKI.forEach(([k]) => (mowa[k] = $("aaM_" + k).value));
  mowa.ai_izolacja = $("aaAI").checked;
  const u = { standard: $("aaCel").value, duck_db: +$("aaDuck").value, miejsce_dla_mowy: $("aaRzezba").checked, klej: $("aaKlej").checked, mowa,
    sciezki: stan.aa.sciezki.map((s) => ({ nr: s.nr, typ: s.typ, korekta_db: s.korekta_db || 0 })) };
  const plikU = path.join(stan.aa.folder, "asystent_uklad.json");
  fs.writeFileSync(plikU, JSON.stringify(u, null, 1), "utf8");
  stan.aa.zOsi = await aaEksportuj(stan.aa.info, stan.aa.folder, stan.aa.sciezki.filter((s) => s.typ !== "pomin").map((s) => s.nr), stan.aa.zOsi || {});
  log("Obrabiam mowę, muzykę i efekty, potem mastering (dłuższe nagrania potrwają kilka minut)…");
  const m = await python("audio_asystent.py", ["miks", "--xml", stan.aa.xml, "--folder", stan.aa.folder, "--uklad", plikU, "--z-premiere", aaZapiszZOsi(stan.aa.folder, stan.aa.zOsi)]);
  if (!m.ok) throw new Error(m.blad);
  Object.values(stan.aa.zOsi || {}).forEach(usunPlik); stan.aa.zOsi = {}; // duże pliki WAV z Premiere nie są już potrzebne
  const wycisz = $("aaWycisz").checked ? m.sciezki : [];
  const szyny = $("aaWstaw").value === "szyny" && m.szyny && Object.keys(m.szyny).length;
  const pliki = szyny ? ["mowa", "muzyka", "efekty", "tlo"].filter((k) => m.szyny[k]).map((k) => m.szyny[k]) : [m.plik];
  // Twoja sekwencja zostaje nietknięta: miks idzie do jej kopii („… - miks AI”), tam też są wyciszenia.
  log("Robię kopię sekwencji i wstawiam do niej miks (oryginał zostaje bez zmian)…");
  const w = await jsx(`nm_miks_w_kopii(${JSON.stringify({ id: stan.aa.info.id, nazwa: (stan.aa.info.nazwa || "Sekwencja") + " - miks AI", pliki, wycisz })})`);
  if (!w.ok) throw new Error(w.blad + ` Pliki miksu: ${stan.aa.folder}`);
  const gdzie = w.sciezki;
  stan.folder = stan.aa.folder;
  stan.raport = path.join(stan.aa.folder, "asystent_raport.txt");
  (m.raport || []).forEach((r) => log(r));
  log((szyny ? `Ścieżki mowa, muzyka, efekty, tło są na ${gdzie.join(", ")}.` : `Miks jest na ${gdzie[0]}.`) +
    ` ${m.standard}: ${m.lufs} LUFS, szczyt ${m.tp} dBTP.` + (wycisz.length ? ` Wyciszone ścieżki: ${wycisz.map((n) => "A" + n).join(", ")}.` : "") +
    ` To wszystko jest w nowej sekwencji „${w.sekwencja}”; Twoja „${w.oryginal}” jest bez zmian.`, "o");
  $("akcje").hidden = false;
});

// ======================= ZADANIA W TLE (Claude) =======================
const NARZEDZIA_CLAUDE = ["Bash(python narzedzia/*)", "Bash(python3 narzedzia/*)", "Bash(node narzedzia/*)", "Bash(ffmpeg *)", "Bash(ffprobe *)",
  "PowerShell(python narzedzia/*)", "PowerShell(ffmpeg *)", "PowerShell(ffprobe *)", "Read", "Write", "Edit", "Glob", "Grep", "mcp__epidemic-sound"];
let zadania = wczytaj("nm-zadania", []);
const zapiszZadania = () => { zadania = zadania.slice(-15); zapisz("nm-zadania", zadania); };

function czytajJson(p) { try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch (e) { return null; } }
function koncowkaPliku(p, bajtow = 96000) {
  try {
    const st = fs.statSync(p), fd = fs.openSync(p, "r"), n = Math.min(bajtow, st.size), b = BUF.alloc(n);
    fs.readSync(fd, b, 0, n, st.size - n); fs.closeSync(fd); return b.toString("utf8");
  } catch (e) { return ""; }
}
function zyje(pid) { try { PROC.kill(pid, 0); return true; } catch (e) { return e.code === "EPERM"; } }

/* Antigravity CLI (Gemini z kontem Google, limity abonamentu AI Pro): szukane raz, w PATH i typowych miejscach. */
let AGY = null;
function sciezkaAgy() {
  if (AGY !== null) return AGY;
  AGY = cfg.agy || "";
  if (!AGY) { try { AGY = String(cp.execSync(PROC.platform === "win32" ? "where agy" : "command -v agy", { windowsHide: true, encoding: "utf8", timeout: 4000 })).split(/\r?\n/)[0].trim(); } catch (e) { AGY = ""; } }
  if (!AGY && PROC.platform === "win32") {
    const dom = PROC.env.USERPROFILE || "", lok = PROC.env.LOCALAPPDATA || "";
    [path.join(lok, "agy", "bin", "agy.exe"), path.join(lok, "agy", "bin", "agy.cmd"), path.join(dom, ".local", "bin", "agy.exe"), path.join(lok, "Programs", "agy", "agy.exe"), path.join(lok, "antigravity-cli", "agy.exe")].some((k) => { try { if (fs.existsSync(k)) { AGY = k; return true; } } catch (e) {} return false; });
  }
  return AGY;
}
const mozgZadan = () => wczytaj("nm-mozg", "claude");
function startClaude(o) {
  const mozg = o.mozg || (o.zadanie ? (o.zadanie.mozg || "claude") : mozgZadan());
  if (mozg === "gemini") return startGemini(o);
  if (!cfg.claude) throw new Error("Nie znalazłem Claude Code na tym komputerze. Zainstaluj go i uruchom ponownie: python narzedzia\\panel_premiere.py --instaluj");
  const plikPostepu = path.join(o.folder, "postep.json"), plikLogu = path.join(o.folder, "claude_log.jsonl");
  const poprzedni = czytajJson(plikPostepu) || {};
  fs.writeFileSync(plikPostepu, JSON.stringify({ etapy: o.etapy, stan: "trwa", etap: null, ulamek: 0, tekst: "Uruchamiam Claude…",
    historia: [], start: Date.now() / 1000, szacunek_s: o.szac, xml: o.wznow ? poprzedni.xml : undefined }, null, 1), "utf8");
  const out = fs.openSync(plikLogu, "a");
  const args = ["-p", "--output-format", "stream-json", "--verbose", "--permission-mode", "acceptEdits", "--allowedTools", ...NARZEDZIA_CLAUDE];
  (o.katalogi || []).forEach((k) => args.push("--add-dir", k));
  if (o.sesja) args.push("--resume", o.sesja);
  const sh = powloka(cfg.claude);
  const p = cp.spawn(sh ? cudzyslow(cfg.claude) : cfg.claude, sh ? args.map(cudzyslow) : args,
    { cwd: SILNIK, detached: true, windowsHide: true, shell: sh, stdio: ["pipe", out, out], env: Object.assign(ENV(), { NM_POSTEP: plikPostepu }) });
  p.stdin.write(o.prompt); p.stdin.end(); p.unref();
  const z = Object.assign(o.zadanie || {}, { id: (o.zadanie && o.zadanie.id) || Date.now().toString(36), typ: o.typ, nazwa: o.nazwa, folder: o.folder, postep: plikPostepu,
    log: plikLogu, pid: p.pid, start: Date.now(), szac: o.szac, stan: "trwa", prompt: o.prompt, katalogi: o.katalogi || [], etapy: o.etapy, mozg: "claude" });
  zapiszZadaniePanelu(z);
  if (!o.zadanie) zadania.push(z);
  zapiszZadania(); odswiezZadania();
  return z;
}
/* To samo zadanie w tle, ale mózgiem jest Gemini (Antigravity CLI). Polecenie idzie w pliku, bo wiersz poleceń Windows nie lubi długich tekstów. */
function flagiAgy() {
  const u = czytajJson(path.join(SILNIK, "narzedzia", "mozg_ustawienia.json")) || {};
  const f = ({ piaskownica: ["--mode", "accept-edits", "--sandbox"] })[u.tryb] || ["--mode", "accept-edits"];
  return u.pelne_uprawnienia ? f.concat("--dangerously-skip-permissions") : f;
}
function startGemini(o) {
  const agy = sciezkaAgy();
  if (!agy) throw new Error("Nie znalazłem Antigravity CLI (Gemini). W PowerShell w folderze silnika: python narzedzia\\mozg.py instaluj, a potem wpisz agy i zaloguj się kontem Google. Albo wybierz mózg Claude na ekranie głównym panelu.");
  const plikPostepu = path.join(o.folder, "postep.json"), plikLogu = path.join(o.folder, "claude_log.jsonl");
  const poprzedni = czytajJson(plikPostepu) || {};
  fs.writeFileSync(plikPostepu, JSON.stringify({ etapy: o.etapy, stan: "trwa", etap: null, ulamek: 0, tekst: "Uruchamiam Gemini…",
    historia: [], start: Date.now() / 1000, szacunek_s: o.szac, xml: o.wznow ? poprzedni.xml : undefined }, null, 1), "utf8");
  const nr = fs.readdirSync(o.folder).filter((n) => /^polecenie_ai_\d+\.md$/.test(n)).length + 1;
  const plikPol = path.join(o.folder, `polecenie_ai_${nr}.md`);
  const prosba = path.relative(SILNIK, path.join(o.folder, "polecenie_gemini.json")).split(path.sep).join("/");
  fs.writeFileSync(plikPol, "WAŻNE: pracujesz w tle i nikt nie kliknie „Zezwól”. W terminalu uruchamiasz TYLKO polecenie `python narzedzia/uruchom.py` (dokładnie tak). " +
    `Każde narzędzie silnika (python narzedzia/X.py, ffmpeg, ffprobe) uruchamiasz tak: zapisz plik ${prosba} z prośbą {"narzedzie": "X.py", "argumenty": ["--opcja", "wartość"]}, potem python narzedzia/uruchom.py. Szczegóły w AGENTS.md.\n\n` +
    o.prompt + "\n\nZasady pracy są w CLAUDE.md w folderze silnika (dotyczą też Ciebie). Etapy raportuj narzędziem postep.py (przez pomocnika), na końcu postep.py z argumentem --gotowe.", "utf8");
  const args = ["-p", `Przeczytaj plik ${path.relative(SILNIK, plikPol).split(path.sep).join("/")} i wykonaj dokładnie to, co jest w nim napisane.`, "--output-format", "stream-json", ...flagiAgy(), "--print-timeout", "4h"];
  (o.katalogi || []).forEach((k) => args.push("--add-dir", k));
  if (o.sesja) args.push("--conversation", o.sesja); else if (o.wznow) args.push("--continue");
  // pomocnik w_tle.py daje Gemini ukrytą konsolę: polecenia, które uruchamia, nie otwierają okien PowerShell
  const py = cfg.python || "python", shp = powloka(py);
  const pargs = [path.join(SILNIK, "narzedzia", "w_tle.py"), "--log", plikLogu, "--", agy, ...args];
  const p = cp.spawn(shp ? cudzyslow(py) : py, shp ? pargs.map(cudzyslow) : pargs,
    { cwd: SILNIK, detached: true, windowsHide: true, shell: shp, stdio: "ignore", env: Object.assign(ENV(), { NM_POSTEP: plikPostepu }) });
  p.unref();
  const z = Object.assign(o.zadanie || {}, { id: (o.zadanie && o.zadanie.id) || Date.now().toString(36), typ: o.typ, nazwa: o.nazwa, folder: o.folder, postep: plikPostepu,
    log: plikLogu, pid: p.pid, start: Date.now(), szac: o.szac, stan: "trwa", prompt: o.prompt, katalogi: o.katalogi || [], etapy: o.etapy, mozg: "gemini" });
  zapiszZadaniePanelu(z);
  if (!o.zadanie) zadania.push(z);
  zapiszZadania(); odswiezZadania();
  return z;
}
/* proces_panelu.json w folderze zadania: Console w Studio widzi zadania z panelu, a gdy wznowi je ze Studio, zapisuje tu nowy numer procesu */
function zapiszZadaniePanelu(z) {
  delete z.okno; z.zgoda = null;
  try { fs.writeFileSync(path.join(z.folder, "proces_panelu.json"), JSON.stringify({ pid: z.pid, mozg: z.mozg, nazwa: z.nazwa, typ: z.typ, start: z.start, kiedy: Date.now(), zrodlo: "panel" }, null, 1), "utf8"); } catch (e) {}
}
/* Gemini w tle nie może kliknąć „Zezwól”: polecenie spoza listy zgód zostaje odrzucone, a zapis pliku potrafi czekać bez końca. Tu to wykrywamy. */
const PLIK_ZGOD_AGY = path.join(PROC.env.USERPROFILE || PROC.env.HOME || "", ".gemini", "antigravity-cli", "settings.json");
function czekaNaZgode(tekst, wiekLoguS) {
  const linie = tekst.split(/\r?\n/).filter(Boolean);
  let odmowy = [], ostatni = null;
  for (const l of linie) {
    let d; try { d = JSON.parse(l); } catch (e) { continue; }
    if (d.event === "init") { odmowy = []; ostatni = null; continue; }
    const su = d.event === "step_update" && d.step_update;
    if (!su) continue;
    const ti = su.tool_info || {}, par = ti.parameters || {}, bl = String((ti.error || {}).message || "");
    if (su.step_type === "tool" && su.state === "ERROR" && /denied permission|permission check failed/i.test(bl)) {
      const m = bl.match(/for mcp "([^"]+)"/) || bl.match(/mcp\(([^)]+)\)/);
      const c = m ? "mcp:" + m[1] : par.CommandLine;
      if (c && !odmowy.includes(c)) odmowy.push(c);
    }
    if (su.step_type === "tool") ostatni = { stan: su.state, narz: su.tool_name || "", co: String(par.CommandLine || par.Path || par.TargetFile || "") };
    else if (su.state === "DONE" || su.state === "ACTIVE") ostatni = null;
  }
  // zapis pliku trwa ułamek sekundy: jeśli wisi ponad minutę, to Gemini czeka na zgodę, której w tle nikt nie da
  const wisi = ostatni && ostatni.stan === "ACTIVE" && /write|replace|edit|delete|move|create/i.test(ostatni.narz) && wiekLoguS > 60 ? "Zapis pliku " + path.basename(ostatni.co) : null;
  return odmowy.length || wisi ? { odmowy, wisi } : null;
}
function dodajZgodyGemini(polecenia) {
  let d = {}; try { d = JSON.parse(fs.readFileSync(PLIK_ZGOD_AGY, "utf8")); } catch (e) {}
  const perm = d.permissions = d.permissions || {}, lista = perm.allow = perm.allow || [];
  // dokładne polecenie (tak zapisuje Antigravity) i wersja z gwiazdką dla tego samego narzędzia z innymi ustawieniami
  const wzor = (czytajJson(path.join(SILNIK, "narzedzia", "mozg_ustawienia.json")) || {}).wzor_zgody || "{} *";
  polecenia.forEach((c) => {
    let r;
    if (c.startsWith("mcp:")) {
      // narzędzie połączenia (np. epidemic-sound/SearchRecordings): zgoda na nie i na wszystkie inne narzędzia tego połączenia
      const [serwer] = c.slice(4).split("/"); r = [`mcp(${c.slice(4)})`];
      try { fs.readdirSync(path.join(path.dirname(PLIK_ZGOD_AGY), "mcp", serwer)).filter((n) => n.endsWith(".json")).forEach((n) => r.push(`mcp(${serwer}/${n.slice(0, -5)})`)); } catch (e) {}
    } else { const t = c.trim().split(/\s+/); r = [`command(${c})`]; if (t.length > 2) r.push(`command(${wzor.replace("{}", t.slice(0, 2).join(" "))})`); }
    r.forEach((x) => { if (!lista.includes(x)) lista.push(x); });
  });
  fs.mkdirSync(path.dirname(PLIK_ZGOD_AGY), { recursive: true });
  fs.writeFileSync(PLIK_ZGOD_AGY, JSON.stringify(d, null, 2), "utf8");
}
function zabij(pid) { if (!pid) return; if (PROC.platform === "win32") { try { cp.execSync(`taskkill /PID ${pid} /T /F`, { windowsHide: true, stdio: "ignore", timeout: 5000 }); } catch (e) {} } else { try { PROC.kill(-pid); } catch (e) { try { PROC.kill(pid); } catch (e2) {} } } }
/* Rozmowa z Gemini w widocznym oknie PowerShell: tam zatwierdzasz zgody (najlepiej „zawsze”), a zadanie idzie dalej. */
function geminiWOknie(z, prompt) {
  const agy = sciezkaAgy(); if (!agy || !z.sesja) throw new Error("Nie mogę otworzyć tej rozmowy z Gemini (brak numeru rozmowy albo Antigravity CLI).");
  const q = (x) => "'" + String(x).replace(/'/g, "''") + "'";
  // skrypt w pliku (z BOM), żeby polskie znaki i cudzysłowy przeszły bez zmian
  const ps1 = path.join(z.folder, "gemini_okno.ps1");
  fs.writeFileSync(ps1, "\ufeff" + [`$env:NM_POSTEP = ${q(z.postep)}`, `Set-Location -LiteralPath ${q(SILNIK)}`,
    `Write-Host 'Gemini: zatwierdzaj tu zgody (najlepiej na zawsze). Po skończeniu zadania możesz zamknąć to okno.' -ForegroundColor Yellow`,
    `& ${q(agy)} --conversation ${q(z.sesja)} -i ${q(prompt)}`].join("\r\n"), "utf8");
  if (PROC.platform === "win32") cp.spawn("cmd.exe", ["/c", "start", "Gemini", "powershell.exe", "-NoExit", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", ps1], { detached: true, windowsHide: false, stdio: "ignore" }).unref();
  else throw new Error("Okno Gemini działa tylko w Windows.");
}
function sesjaZLogu(tekst) { const m = tekst.match(/"(?:session_id|sessionId|conversation_id|conversationId)"\s*:\s*"([^"]+)"/g); return m ? m[m.length - 1].replace(/.*"([^"]+)"$/, "$1") : null; }
function ostatniaCzynnosc(tekst) {
  const linie = tekst.split(/\r?\n/).filter(Boolean).reverse();
  for (const l of linie) {
    let d; try { d = JSON.parse(l); } catch (e) { continue; }
    if (!d.type && d.event === "step_update" && d.step_update) {
      const su = d.step_update, ti = su.tool_info || {}, par = ti.parameters || {};
      if (su.step_type === "tool" && su.state === "ACTIVE") return { tekst: (/read|view|list/.test(su.tool_name || "") ? "Czyta: " : /write|replace/.test(su.tool_name || "") ? "Pisze: " : "Uruchamia: ") + String(par.CommandLine || par.Path || su.tool_name || "").replace(/\s+/g, " ").slice(0, 120) };
      if (su.state === "ERROR") return { tekst: "Błąd: " + String((ti.error || {}).message || "").split("\n")[0].slice(0, 140) };
      continue;
    }
    if (!d.type && d.event && /result|final|done|complete/.test(d.event)) { const w = d[d.event] || d; return { wynik: { result: w.result || w.response || w.text || "Gotowe", is_error: !!(w.error || w.is_error) } }; }
    if (d.type === "result") return { wynik: Object.assign({}, d, { result: d.result != null ? d.result : d.response }) };
    if (!d.type && (d.response || d.result)) return { wynik: { result: d.response || d.result } };
    const tt = String(d.type || "").toLowerCase();
    if (tt && !["assistant", "user", "system"].includes(tt)) {
      if (/tool|command|function/.test(tt)) { const a = d.input || d.args || d.arguments || {}; return { tekst: "Uruchamia: " + String((a && a.command) || d.name || tt).replace(/\s+/g, " ").slice(0, 120) }; }
      const t = [d.text, d.content, typeof d.message === "string" ? d.message : null].find((x) => typeof x === "string" && x.trim());
      if (t) return { tekst: t.trim().replace(/\s+/g, " ").slice(0, 160) };
    }
    if (d.type === "assistant" && d.message && Array.isArray(d.message.content)) {
      for (const c of d.message.content.slice().reverse()) {
        if (c.type === "tool_use") {
          const i = c.input || {};
          const co = i.command ? i.command.replace(/\s+/g, " ").slice(0, 120) : i.file_path ? path.basename(i.file_path) : i.pattern || "";
          return { tekst: (c.name === "Read" ? "Czyta: " : c.name === "Write" || c.name === "Edit" ? "Pisze: " : "Uruchamia: ") + co };
        }
        if (c.type === "text" && c.text.trim()) return { tekst: c.text.trim().replace(/\s+/g, " ").slice(0, 160) };
      }
    }
  }
  return {};
}
function procent(z, d) {
  if (!d) return 0;
  if (d.stan === "gotowe") return 1;
  const etapy = d.etapy || z.etapy || [], suma = etapy.reduce((a, e) => a + e.waga, 0) || 1, i = etapy.findIndex((e) => e.klucz === d.etap);
  const teraz = Date.now() / 1000;
  if (i < 0) return Math.min(0.03, (teraz - (d.start || teraz)) / 40 * 0.03);
  let przed = 0; for (let k = 0; k < i; k++) przed += etapy[k].waga;
  const w = etapy[i].waga, h = (d.historia || []).filter((x) => x.etap === d.etap).pop(), odEtapu = h ? teraz - h.od : 0;
  const oczek = Math.max(20, (z.szac || 600) * w / suma), pelzanie = 0.92 * (1 - Math.exp(-odEtapu / oczek));
  return Math.min(0.99, (przed + w * Math.min(1, Math.max(+d.ulamek || 0, pelzanie))) / suma);
}
const minuty = (s) => s < 60 ? "mniej niż minuta" : s < 3600 ? `ok. ${Math.round(s / 60)} min` : `ok. ${Math.floor(s / 3600)} h ${Math.round(s % 3600 / 60)} min`;
const godzina = (ms) => new Date(ms).toLocaleTimeString("pl-PL", { hour: "2-digit", minute: "2-digit" });

function odswiezZadania() {
  zadania.forEach((z) => {
    const d = czytajJson(z.postep);
    const tekstLogu = koncowkaPliku(z.log);
    z.sesja = sesjaZLogu(tekstLogu) || z.sesja;
    const cz = ostatniaCzynnosc(tekstLogu);
    const zp = czytajJson(path.join(z.folder, "proces_panelu.json"));
    if (zp && zp.pid && zp.pid !== z.pid && zp.kiedy > (z.wznowione || z.start)) { z.pid = zp.pid; z.wznowione = zp.kiedy; z.stan = "trwa"; delete z.okno; z.koniec = null; }
    if (z.mozg === "gemini") { let wiek = 0; try { wiek = (Date.now() - fs.statSync(z.log).mtimeMs) / 1000; } catch (e) {} z.zgoda = z.okno ? null : czekaNaZgode(tekstLogu, wiek); }
    if (z.stan === "trwa") {
      if (d && d.stan === "gotowe") { z.stan = "gotowe"; z.koniec = Date.now(); z.tekst = d.tekst; z.xml = d.xml || []; z.wideo = d.wideo || []; }
      else if (d && d.stan === "blad") { z.stan = "blad"; z.koniec = Date.now(); z.tekst = d.tekst; }
      else if (z.okno) { z.p = procent(z, d); z.tekst = (d && d.tekst) || ""; z.co = "pracuje w oknie PowerShell"; z.etap = d && d.etap; }
      else if (!zyje(z.pid)) {
        z.koniec = Date.now();
        const w = cz.wynik;
        if (z.typ === "aftermovie" && d && d.stan === "trwa") { z.stan = "blad"; z.tekst = z.zgoda ? "Zadanie stanęło, bo zabrakło zgody. Kliknij „Zezwól i kontynuuj”." : `Zadanie skończyło się przed końcem (etap: ${((z.etapy || []).find((e) => e.klucz === d.etap) || {}).nazwa || d.etap || "?"}). Kliknij „Wznów”.`; }
        else if (w && !w.is_error) { z.stan = "gotowe"; z.tekst = String(w.result || "Gotowe").slice(0, 300); z.xml = (d && d.xml) || []; z.wideo = (d && d.wideo) || []; }
        else { z.stan = "blad"; z.tekst = w ? String(w.result || "Claude zakończył z błędem").slice(0, 300) : "Zadanie przerwane (zamknięty Premiere albo komputer?). Kliknij „Wznów”."; }
      } else { z.p = procent(z, d); z.tekst = (d && d.tekst) || ""; z.co = cz.tekst || ""; z.etap = d && d.etap; }
    }
    z.d = d;
  });
  zapiszZadania();
  $$(".lista-zadan").forEach((el) => rysujZadania(el, el.dataset.typ));
}
function rysujZadania(el, typ) {
  const lista = zadania.filter((z) => !typ || z.typ === typ).slice().reverse();
  if (!lista.length) { el.innerHTML = `<p class="uwaga">Brak zadań.</p>`; return; }
  el.innerHTML = lista.map((z) => {
    const p = z.stan === "gotowe" ? 1 : z.stan === "blad" ? 1 : (z.p || 0);
    const minelo = (Date.now() - z.start) / 1000;
    let info = "";
    if (z.stan === "trwa") {
      const calosc = p < 0.05 ? z.szac : (1 - Math.min(1, p * 1.5)) * z.szac + Math.min(1, p * 1.5) * (minelo / Math.max(p, 0.01));
      const zostalo = Math.max(15, calosc - minelo);
      info = `<span>${Math.round(p * 100)}% · zostało ${minuty(zostalo)}</span><span>koniec ok. ${godzina(Date.now() + zostalo * 1000)}</span>`;
    } else info = `<span>${z.stan === "gotowe" ? "Gotowe" : "Przerwane"} o ${godzina(z.koniec || Date.now())}</span><span>trwało ${minuty(((z.koniec || Date.now()) - z.start) / 1000)}</span>`;
    const et = (z.etapy || []).map((e) => { const i = (z.etapy || []).findIndex((x) => x.klucz === z.etap); const k = (z.etapy || []).indexOf(e); return `<span class="${z.stan === "gotowe" || k < i ? "z" : k === i ? "t" : ""}" title="${e.nazwa}"></span>`; }).join("");
    const etapNazwa = ((z.etapy || []).find((e) => e.klucz === z.etap) || {}).nazwa || "";
    const przyciski = [];
    if (z.zgoda && z.zgoda.odmowy.length) przyciski.push(`<button class="maly akc" data-a="zezwol" title="Dopisuje te polecenia do zgód Gemini i każe mu kontynuować">Zezwól i kontynuuj</button>`);
    if (z.zgoda && z.sesja) przyciski.push(`<button class="maly${z.zgoda.odmowy.length ? "" : " akc"}" data-a="okno" title="Ta sama rozmowa w oknie PowerShell: tam zatwierdzasz zgody">Zatwierdź w oknie</button>`);
    if (z.stan === "trwa") przyciski.push(`<button class="maly" data-a="stop">Zatrzymaj</button>`);
    if (z.stan === "gotowe" && (z.xml || []).length) przyciski.push(`<button class="maly akc" data-a="wczytaj">Wczytaj do Premiere</button>`);
    if (z.stan === "gotowe" && z.typ === "animacje") przyciski.push(`<button class="maly akc" data-a="wstaw">${z.tryb === "mowa" ? "Przejrzyj i wstaw" : "Wstaw na oś czasu"}</button>`);
    if (z.stan !== "trwa" && z.sesja) przyciski.push(`<button class="maly" data-a="${z.stan === "blad" ? "wznow" : "popraw"}">${z.stan === "blad" ? "Wznów" : "Popraw…"}</button>`);
    przyciski.push(`<button class="maly" data-a="folder">Folder</button>`);
    if (fs.existsSync(path.join(z.folder, "raport.md"))) przyciski.push(`<button class="maly" data-a="raport">Raport</button>`);
    przyciski.push(`<button class="maly" data-a="usun" title="Usuń z listy (pliki zostają)">×</button>`);
    const opis = (z.stan === "trwa" ? (etapNazwa ? etapNazwa + ": " : "") + (z.tekst || "") : z.tekst || "").replace(/</g, "&lt;");
    return `<div class="zadanie ${z.stan}" data-id="${z.id}">
      <div class="tyt"><b>${String(z.nazwa).replace(/</g, "&lt;")}</b><span class="stan">${{ aftermovie: "Aftermovie", animacje: "Animacje" }[z.typ] || z.typ}</span></div>
      <div class="pasek"><i style="width:${(p * 100).toFixed(1)}%"></i></div>${et ? `<div class="etapy">${et}</div>` : ""}
      <div class="info">${info}</div>
      ${opis ? `<div class="co" title="${opis}">${opis}</div>` : ""}${z.stan === "trwa" && z.co ? `<div class="co" title="${z.co.replace(/"/g, "&quot;").replace(/</g, "&lt;")}">${z.mozg === "gemini" ? "Gemini" : "Claude"}: ${z.co.replace(/</g, "&lt;")}</div>` : ""}
      ${z.zgoda ? `<div class="co zgoda">⚠ Gemini czeka na Twoją zgodę: ${[...z.zgoda.odmowy.map((c) => (c.startsWith("mcp:") ? "połączenie „" + c.slice(4).replace(/</g, "&lt;") + "”" : "uruchomienie „" + c.replace(/</g, "&lt;").slice(0, 90) + "”")), z.zgoda.wisi ? z.zgoda.wisi.replace(/</g, "&lt;") : null].filter(Boolean).join(", ")}</div>` : ""}
      <div class="akcje">${przyciski.join("")}</div></div>`;
  }).join("");
  $$(".zadanie", el).forEach((k) => $$("button[data-a]", k).forEach((b) => (b.onclick = () => akcjaZadania(zadania.find((z) => z.id === k.dataset.id), b.dataset.a))));
}
/* plik o tej nazwie gdzieś w folderze zadania (np. po przeniesieniu do Projekty/ albo Materiały/) */
function znajdzWFolderze(folder, nazwa, glebokosc = 4) {
  try {
    for (const e of fs.readdirSync(folder, { withFileTypes: true })) {
      const p = path.join(folder, e.name);
      if (e.isFile() && e.name === nazwa) return p;
    }
    if (glebokosc > 0) for (const e of fs.readdirSync(folder, { withFileTypes: true })) if (e.isDirectory()) { const w = znajdzWFolderze(path.join(folder, e.name), nazwa, glebokosc - 1); if (w) return w; }
  } catch (e) {}
  return null;
}
async function akcjaZadania(z, a) {
  if (!z) return;
  if (a === "stop") {
    if (PROC.platform === "win32") cp.exec(`taskkill /PID ${z.pid} /T /F`); else { try { PROC.kill(-z.pid); } catch (e) { try { PROC.kill(z.pid); } catch (e2) {} } }
    z.stan = "blad"; z.tekst = "Zatrzymane przez Ciebie."; z.koniec = Date.now();
  } else if (a === "wczytaj") {
    for (let x of z.xml || []) {
      if (!fs.existsSync(x) && z.folder) x = znajdzWFolderze(z.folder, path.basename(x)) || x; // po porządkach timeline leży w Projekty/
      // timeline zrobiony starszą wersją silnika (bez prawdziwych przejść i efektów dźwiękowych): robimy go od nowa z osi montażu
      const osPlik = path.join(path.dirname(path.dirname(x)), path.basename(x, ".xml") + "_os_czasu.json");
      const dd = czytajJson(x.replace(/\.xml$/i, "_dodatki.json"));
      if ((!dd || (+dd.wersja || 1) < 2) && fs.existsSync(osPlik)) {
        try {
          log("Odświeżam timeline: prawdziwe przejścia i efekty dźwiękowe…", "o");
          const r = await python("premiere.py", ["--os", osPlik, "--efekty-auto"]);
          if (!r.ok) log("Nie udało się odświeżyć timeline'u: " + r.blad, "e");
          else log(`Timeline odświeżony: ${r.przejscia_w_xml} przejść w pliku, ${r.przejscia_do_panelu} dynamicznych do położenia, ${r.efekty} efektów dźwiękowych.`, "o");
        } catch (e) { log("Nie udało się odświeżyć timeline'u: " + (e.message || e), "e"); }
      }
      await importuj(x);
    }
  } else if (a === "wstaw") {
    await wstawWynikiAnimacji(z);
  } else if (a === "folder") otworzFolder(z.folder);
  else if (a === "raport") otworz(path.join(z.folder, "raport.md"));
  else if (a === "usun") zadania = zadania.filter((x) => x !== z);
  else if (a === "zezwol") {
    const pol = (z.zgoda || {}).odmowy || [];
    zabij(z.pid); dodajZgodyGemini(pol);
    log(`Gemini: zgoda na ${pol.length} ${pol.length === 1 ? "polecenie" : "polecenia"}, zadanie „${z.nazwa}” idzie dalej`);
    startClaude({ zadanie: z, typ: z.typ, nazwa: z.nazwa, folder: z.folder, etapy: z.etapy, szac: z.szac, katalogi: z.katalogi, sesja: z.sesja, wznow: true,
      prompt: "Masz już zgodę na to, co przed chwilą zostało zablokowane:\n" + pol.map((c) => "- " + (c.startsWith("mcp:") ? "narzędzie połączenia " + c.slice(4) + " (i pozostałe narzędzia tego połączenia)" : c)).join("\n") + "\nUżyj ich jeszcze raz i kontynuuj zadanie od miejsca, w którym przerwałeś (gotowe pliki wykorzystaj). Nie zadawaj pytań; na koniec wywołaj postep.py --gotowe jak w instrukcji." });
  } else if (a === "okno") {
    zabij(z.pid);
    geminiWOknie(z, "Kontynuuj to zadanie od miejsca, w którym przerwałeś (gotowe pliki wykorzystaj). Etapy raportuj przez narzedzia/postep.py, na końcu python narzedzia/postep.py --gotowe.");
    z.okno = true; z.zgoda = null; z.stan = "trwa";
    log("Gemini: rozmowa otwarta w oknie PowerShell. Zatwierdzaj tam zgody (najlepiej „zawsze”), panel dalej pokazuje postęp.");
  }
  else if (a === "wznow" || a === "popraw") {
    let prompt = "Kontynuuj to zadanie od miejsca, w którym przerwałeś (gotowe pliki wykorzystaj). Nadal nie zadawaj pytań; na koniec wywołaj postep.py --gotowe jak w instrukcji.";
    if (a === "popraw") {
      const pole = document.createElement("textarea");
      pole.rows = 3; pole.placeholder = "Co poprawić? np. krótszy wstęp, mocniejsza muzyka, wytnij ujęcie z 0:42";
      const ok = document.createElement("button"); ok.className = "glowny"; ok.textContent = "Wyślij poprawki do Claude'a";
      const karta = document.querySelector(`.zadanie[data-id="${z.id}"]`); if (!karta) return;
      karta.appendChild(pole); karta.appendChild(ok); pole.focus();
      ok.onclick = () => {
        if (!pole.value.trim()) return;
        prompt = "Poprawki od użytkownika do tego, co zrobiłeś: " + pole.value.trim() + "\nZrób je (bez pytań), nadpisz wyniki w tym samym folderze (nowe wersje timeline'ów z dopiskiem _v2, _v3), zaktualizuj raport i na koniec wywołaj postep.py --gotowe z nowymi plikami.";
        startClaude({ zadanie: z, typ: z.typ, nazwa: z.nazwa, folder: z.folder, prompt, etapy: z.etapy, szac: Math.max(240, z.szac * 0.5), katalogi: z.katalogi, sesja: z.sesja });
      };
      return;
    }
    startClaude({ zadanie: z, typ: z.typ, nazwa: z.nazwa, folder: z.folder, prompt, etapy: z.etapy, szac: z.szac, katalogi: z.katalogi, sesja: z.sesja, wznow: true });
  }
  zapiszZadania(); odswiezZadania();
}
setInterval(() => { if (zadania.some((z) => z.stan === "trwa")) odswiezZadania(); }, 2000);

// ======================= AFTERMOVIE =======================
const ETAPY_AM = [
  { klucz: "przygotowanie", nazwa: "Przygotowanie", waga: 4 }, { klucz: "material", nazwa: "Przegląd materiału", waga: 30 },
  { klucz: "muzyka", nazwa: "Muzyka i rytm", waga: 10 }, { klucz: "historia", nazwa: "Historia (lektor / wywiady)", waga: 10 },
  { klucz: "plan", nazwa: "Plan montażu", waga: 12 }, { klucz: "montaz", nazwa: "Montaż", waga: 26 }, { klucz: "kontrola", nazwa: "Kontrola", waga: 8 },
];
suwak("amDlugosc", " s", 0);
segment("amOrient", amSzacuj); segment("amDynamika", amSzacuj);
segment("amNarracja", (v) => {
  $("amLektor").hidden = !/lektor/.test(v); $("amWywiadyInfo").hidden = !/wywiady/.test(v); $("amNapisyBox").hidden = v === "brak"; amSzacuj();
});
["amDlugosc", "amMuzZrodlo"].forEach((id) => $(id).addEventListener("input", amSzacuj));
function amSzacunek() {
  const i = stan.info || { klipy: 10, material_s: 300 }, narr = wartoscSeg("amNarracja") || "brak", orient = wartoscSeg("amOrient") === "oba" ? 2 : 1, M = (i.material_s || 0) / 60;
  return Math.round(150 + (i.klipy || 0) * 10 + M * 20 + (/wywiady/.test(narr) ? M * 35 + 90 : 0) + (/lektor/.test(narr) ? 60 : 0)
    + ($("amMuzZrodlo").value === "epidemic" ? 60 : 20) + orient * (+$("amDlugosc").value * 1.6 + 90));
}
function amSzacuj() { $("amSzac").textContent = stan.info ? `Na osi: ${stan.info.klipy} klipów, ${minuty(stan.info.material_s)} materiału. Szacowany czas pracy: ${minuty(amSzacunek())}.` : ""; }
function amLoga() {
  const f = folderKlienta(), pliki = [];
  if (f) {
    [path.join(f, "logo"), f].forEach((d) => { try { fs.readdirSync(d).filter((n) => /\.(png|svg|jpe?g|webp)$/i.test(n) && (d !== f || /^logo/i.test(n))).forEach((n) => pliki.push(path.join(d, n))); } catch (e) {} });
  }
  $("amLogo").innerHTML = '<option value="">Bez logo</option>' + pliki.map((p) => `<option value="${p.replace(/"/g, "")}">${path.basename(p)}</option>`).join("");
  if (pliki.length) $("amLogo").value = pliki[0];
}
/* foldery z proksy dla plików RAW: zapamiętane w panelu, domyślnie D:\PROXY PREMIER */
function amFolderyProksy() { return $("amProksy").value.split(/\r?\n/).map((x) => x.trim().replace(/^"|"$/g, "")).filter(Boolean); }
$("amProksy").value = wczytaj("nm-proksy", null) != null ? wczytaj("nm-proksy", "") : "D:\\PROXY PREMIER";
$("amProksy").onchange = () => zapisz("nm-proksy", $("amProksy").value);
$("amProksyWybierz").onclick = () => {
  try {
    const r = window.cep && window.cep.fs && window.cep.fs.showOpenDialog(false, true, "Folder z proksy", amFolderyProksy()[0] || "D:\\");
    const p = r && r.data && r.data[0];
    if (p) { const l = amFolderyProksy(); if (!l.includes(p)) l.push(p); $("amProksy").value = l.join("\n"); zapisz("nm-proksy", $("amProksy").value); }
    else if (!r) log("Wpisz ścieżkę folderu z proksy w polu powyżej.");
  } catch (e) { log("Wpisz ścieżkę folderu z proksy w polu powyżej."); }
};
const AM_POLA = ["amTytul", "amBrief", "amDlugosc", "amPrzejscia", "amMuzZrodlo", "amNastroj", "amMuzOpis", "amLektorTekst", "amGlos", "amJezyk", "amNapisy", "amLogoPoz", "amPlansza", "amCta", "amData", "amDzwiekUjec", "amRuch", "amSfx"];
function amZapamietaj() {
  const u = { orient: wartoscSeg("amOrient"), dyn: wartoscSeg("amDynamika"), narr: wartoscSeg("amNarracja") };
  AM_POLA.forEach((k) => (u[k] = $(k).type === "checkbox" ? $(k).checked : $(k).value));
  zapisz("nm-am", u);
}
function amPrzywroc() {
  const u = wczytaj("nm-am", null); if (!u) return;
  AM_POLA.forEach((k) => { if (u[k] == null || ["amTytul", "amBrief", "amLektorTekst"].includes(k)) return; if ($(k).type === "checkbox") $(k).checked = u[k]; else $(k).value = u[k]; });
  u.orient && ustawSeg("amOrient", u.orient); u.dyn && ustawSeg("amDynamika", u.dyn);
  if (u.narr) { ustawSeg("amNarracja", u.narr); $("amLektor").hidden = !/lektor/.test(u.narr); $("amWywiadyInfo").hidden = !/wywiady/.test(u.narr); $("amNapisyBox").hidden = u.narr === "brak"; }
  $("amDlugosc").dispatchEvent(new Event("input"));
}
$("amStart").onclick = async () => {
  $("amStart").disabled = true;
  try {
    amZapamietaj();
    const { info, folder } = await przygotuj("aftermovie", ($("amTytul").value || "").trim() || null);
    const klient = $("klient").value, narr = wartoscSeg("amNarracja"), orient = wartoscSeg("amOrient");
    const zad = {
      zrodlo: "premiere", folder: path.relative(SILNIK, folder).split(path.sep).join("/"), xml: path.join(folder, "sekwencja.xml"),
      tytul: $("amTytul").value || info.nazwa, brief: $("amBrief").value, dlugosc: +$("amDlugosc").value,
      orientacje: orient === "oba" ? ["poziom", "pion"] : [orient], dynamika: wartoscSeg("amDynamika"), przejscia: $("amPrzejscia").value,
      muzyka: { zrodlo: $("amMuzZrodlo").value, nastroj: $("amNastroj").value, opis: $("amMuzOpis").value },
      narracja: { tryb: narr, tekst: $("amLektorTekst").value, glos: $("amGlos").value, jezyk: $("amJezyk").value },
      napisy: narr !== "brak" && $("amNapisy").checked, logo: $("amLogo").value, logo_pozycja: $("amLogoPoz").value,
      plansza: { tekst: $("amPlansza").value, przycisk: $("amCta").value, data_i_miejsce: $("amData").value },
      dzwiek_z_ujec: $("amDzwiekUjec").value, ruch_kamery: $("amRuch").checked, efekty_dzwiekowe: $("amSfx").checked,
      klient: klient ? { nazwa: klient, folder: "klienci/" + klient } : null,
      sekwencja: { nazwa: info.nazwa, fps: info.fps, rozmiar: [info.szer, info.wys] },
    };
    fs.writeFileSync(path.join(folder, "zadanie_panel.json"), JSON.stringify(zad, null, 1), "utf8");
    // proksy: podpięte w Premiere + foldery z ustawień (aftermovie.py czyta proksy.json z folderu zadania)
    const folderyProksy = amFolderyProksy();
    const mapa = {};
    try { const r = await jsx("nm_proksy()"); if (r.ok) r.pliki.forEach((x) => { if (x.proksy) mapa[x.plik] = x.proksy; }); } catch (e) {}
    fs.writeFileSync(path.join(folder, "proksy.json"), JSON.stringify({ foldery: folderyProksy, mapa }, null, 1), "utf8");
    try { fs.writeFileSync(path.join(SILNIK, "narzedzia", "proksy_foldery.json"), JSON.stringify(folderyProksy, null, 1), "utf8"); } catch (e) {}
    const etapy = ETAPY_AM.filter((e) => e.klucz !== "historia" || narr !== "brak");
    // foldery z nagraniami (Claude musi czytać arkusze kadrów zapisane obok nich)
    const katalogi = new Set();
    try {
      const x = fs.readFileSync(path.join(folder, "sekwencja.xml"), "utf8");
      (x.match(/<pathurl>([^<]+)<\/pathurl>/g) || []).forEach((m) => {
        let p = decodeURIComponent(m.replace(/<\/?pathurl>/g, "").replace(/^file:\/\/(localhost)?/, ""));
        if (/^\/[A-Za-z]:/.test(p)) p = p.slice(1);
        katalogi.add(path.dirname(p));
      });
      folderyProksy.forEach((k) => katalogi.add(k));
      Object.values(mapa).forEach((p) => katalogi.add(path.dirname(p)));
    } catch (e) {}
    const prompt = "Przeczytaj plik .claude/skills/aftermovie/SKILL.md i wykonaj go dokładnie dla tego zadania. Zadanie uruchomiono z panelu w Premiere: użytkownika nie ma przy komputerze, nie zadawaj pytań i raportuj etapy przez narzedzia/postep.py.\n\n```json\n"
      + JSON.stringify(zad, null, 1) + "\n```\n";
    startClaude({ typ: "aftermovie", nazwa: zad.tytul, folder, prompt, etapy, szac: amSzacunek(), katalogi: [...katalogi].slice(0, 20) });
  } catch (e) { alertBlad(e); }
  $("amStart").disabled = false;
};
function alertBlad(e) { const el = document.createElement("p"); el.className = "uwaga"; el.style.color = "var(--err)"; el.textContent = "Błąd: " + (e.message || e); document.querySelector(`section[data-v="${stan.widok}"]`).appendChild(el); setTimeout(() => el.remove(), 12000); }

// ======================= OŚ CZASU: cel wstawiania i edycja tego, co już wstawione =======================
const OS = { stan: null, zaznaczoneId: "", timer: 0, pyta: false, stare: new Set() };
/* Animacja albo szablon wstawiony z panelu? Szuka w rejestrze (nazwa, plik, id klipu) i w pliku .nada.json obok pliku. */
function wpisZKlipu(x) {
  if (!x) return null;
  const rej = anRejestr(), sc = String(x.sciezka || "");
  // numer klipu (nodeId) nie jest stały między sesjami Premiere: wpis po numerze bierzemy tylko, gdy zgadza się też plik
  const pi = rej["id:" + x.idKlipu];
  const w = (pi && wpisPasujeDoKlipu(pi, sc, x.nazwa) ? pi : null) || rej[path.basename(sc)] || (/^nada/i.test(String(x.nazwa || "")) ? rej[x.nazwa] : null);
  if (w) return w;
  const obok = sc.replace(/\.(mov|mogrt|mp4)$/i, ".nada.json");
  return obok !== sc && fs.existsSync(obok) ? czytajJson(obok) : null;
}
/* Czy wpis z rejestru (animacja, szablon, napis) to na pewno ten klip na osi: porównuje plik, nie tylko numer klipu. */
function plikWpisu(w) { return w ? (w.typ === "napis" ? "" : String(w.mogrt || w.mov || w.plik || "")) : ""; }
function wpisPasujeDoKlipu(w, sciezka, nazwa) {
  const sc = String(sciezka || "");
  if (!w) return false;
  if (!sc) return /^nada/i.test(String(nazwa || "")) && !!w.mogrt;
  if (/\.(mogrt|aegraphic)$/i.test(sc)) return !!w.mogrt && (String(nazwa || "") === String(w.nazwa || "") || /^nada/i.test(String(nazwa || "")));
  if (!/[\\/]wyniki[\\/]/i.test(sc)) return false; // klip użytkownika (np. nagranie z kamery): nigdy nasz
  if (w.typ === "napis") return !!w.projekt && path.dirname(sc).toLowerCase() === path.dirname(w.projekt).toLowerCase();
  const pw = plikWpisu(w);
  if (!pw) return false;
  const a = path.basename(sc).toLowerCase(), b = path.basename(pw).toLowerCase();
  return a === b || a.replace(/\.[^.]+$/, "") === b.replace(/\.[^.]+$/, "");
}
/* Nad czym wstawić: zaznaczone klipy wideo (nie nasze), a gdy nic nie jest zaznaczone, najwyższy klip pod głowicą. */
function celWstawienia(st) {
  st = st || OS.stan; if (!st || !st.ok) return null;
  const zw = (st.zaznaczone || []).filter((x) => !wpisZKlipu(x));
  if (zw.length) {
    const startK = Math.min(...zw.map((x) => x.start)), endK = Math.max(...zw.map((x) => x.end));
    return { start: startK, end: endK, dl: endK - startK, tor: Math.max(...zw.map((x) => x.tor)), nazwa: zw.length > 1 ? `${zw.length} zaznaczone klipy` : zw[0].nazwa, zrodlo: "zaznaczony" };
  }
  const pg = (st.podGlowica || []).filter((x) => !wpisZKlipu(x));
  if (pg.length) return Object.assign({}, pg[0], { dl: pg[0].end - pg[0].start, zrodlo: "pod głowicą" });
  return null;
}
const czasTC = (t) => { t = Math.max(0, +t || 0); const m = Math.floor(t / 60); return `${m}:${(t - m * 60).toFixed(1).padStart(4, "0").replace(".", ",")}`; };
async function osOdswiez() {
  if (HOST !== "PPRO" || OS.pyta) return OS.stan;
  OS.pyta = true;
  try { OS.stan = await jsx("nm_os_stan()"); } catch (e) { OS.stan = null; }
  OS.pyta = false;
  osPokaz();
  return OS.stan;
}
function osPokaz() {
  const st = OS.stan, cel = celWstawienia(st);
  const opis = (dopasuj, nazwaRzeczy) => !st || !st.ok ? "Otwórz sekwencję na osi czasu."
    : cel ? `Wstawię nad: <b>„${String(cel.nazwa).replace(/</g, "")}”</b> (V${cel.tor + 1}, ${czasTC(cel.start)}–${czasTC(cel.end)}) · ${dopasuj ? `${nazwaRzeczy} dostanie długość klipu: <b>${cel.dl.toFixed(1).replace(".", ",")} s</b>` : "własna długość"}`
    : `Pod głowicą (${czasTC(st.glowica)}) nie ma klipu: wstawię w tym miejscu z własną długością.`;
  if ($("anCel")) $("anCel").innerHTML = opis($("anDopasuj").checked, "animacja");
  if ($("szCel")) $("szCel").innerHTML = opis($("szDopasuj").checked, "szablon");
  // kliknięta na osi animacja albo szablon z panelu: od razu do edycji
  const nasze = st && st.ok ? (st.zaznaczone || []).filter((x) => !OS.stare.has(x.idKlipu)).map((x) => ({ x, w: wpisZKlipu(x) })).filter((y) => y.w) : [];
  const pierwszy = nasze[0];
  OS.zaznaczoneId = pierwszy ? pierwszy.x.idKlipu : "";
  if (!pierwszy) { if (anStan.pomin) anStan.pomin = ""; if (szStan.pomin) szStan.pomin = ""; }
  if (stan.widok === "animacje" && A) {
    if (pierwszy && pierwszy.w.typ !== "szablon" && pierwszy.w.typ !== "napis" && !anStan.zajete && anStan.pomin !== pierwszy.x.idKlipu && (!anStan.edycja || anStan.edycja.idKlipu !== pierwszy.x.idKlipu)) {
      try { anOtworzEdycje(pierwszy.x, pierwszy.w); } catch (e) { console.log(e); }
    } else if (!pierwszy && cel && cel.zrodlo === "zaznaczony" && anStan.edycja && !anStan.zajete) { anStan.edycja = null; anPokazEdycje(); $("anStanEdycji").hidden = true; }
  }
  if (stan.widok === "szablony" && SZ) {
    if (pierwszy && pierwszy.w.typ === "szablon" && !szStan.zajete && szStan.pomin !== pierwszy.x.idKlipu && (!szStan.edycja || szStan.edycja.idKlipu !== pierwszy.x.idKlipu)) {
      try { szOtworzEdycje(pierwszy.x, pierwszy.w); } catch (e) { console.log(e); }
    } else if (!pierwszy && cel && cel.zrodlo === "zaznaczony" && szStan.edycja && !szStan.zajete) { szStan.edycja = null; szPokazEdycje(); }
  }
  if (stan.widok === "napisy") nPodswietl();
  const inny = pierwszy && pierwszy.w.typ !== "napis" && ((stan.widok === "animacje" && pierwszy.w.typ === "szablon") || (stan.widok === "szablony" && pierwszy.w.typ !== "szablon"));
  ["anInny", "szInny"].forEach((id) => { const el = $(id); if (!el) return; el.hidden = !inny; if (inny) el.innerHTML = `Na osi zaznaczony jest ${pierwszy.w.typ === "szablon" ? "szablon" : "animacja"} z panelu. <a href="#" data-do="${pierwszy.w.typ === "szablon" ? "szablony" : "animacje"}">Edytuj ${pierwszy.w.typ === "szablon" ? "w Szablonach" : "w Animacjach"}</a>`; });
}
document.addEventListener("click", (e) => { const a = e.target.closest && e.target.closest("a[data-do]"); if (a) { e.preventDefault(); pokaz(a.dataset.do); setTimeout(osOdswiez, 100); } });
/* Rozciąganie bez After Effects: gdy przeciągniesz koniec animacji na osi, panel przerysowuje ją do nowej długości
   (wejście zostaje, wyjście przesuwa się na nowy koniec). Plik ma 15 s zapasu, więc koniec można wydłużać. */
const ROZ = { poprzednie: {}, zajete: false, licznik: 0 };
async function osRozciaganie() {
  if (HOST !== "PPRO" || ROZ.zajete || anStan.zajete) return;
  if (++ROZ.licznik % 2) return; // co ok. 2 s
  const rej = anRejestr(), teraz = Date.now();
  const nasze = Object.entries(rej).filter(([k, w]) => k.startsWith("id:") && w && w.preset && w.typ !== "napis" && w.typ !== "szablon" && !w.mogrt && teraz - Date.parse(w.kiedy || 0) < 3 * 86400e3).slice(-40);
  if (!nasze.length) return;
  let r; try { r = await jsx(`nm_klipy_stan(${JSON.stringify(nasze.map(([k]) => k.slice(3)))})`); } catch (e) { return; }
  if (!r || !r.ok) return;
  const fps = (stan.info && stan.info.fps) || 25;
  for (const [k, w] of nasze) {
    const id = k.slice(3), kl = r.klipy[id];
    if (!kl || OS.stare.has(id)) continue;
    if (kl.nasz === false || !wpisPasujeDoKlipu(w, kl.sciezka, kl.nazwa)) { delete ROZ.poprzednie[id]; continue; } // pod tym numerem leży teraz inny klip (np. po ponownym otwarciu projektu)
    const dl = kl.end - kl.start;
    if (Math.abs(dl - (+w.czas || 0)) < 1.5 / fps) { delete ROZ.poprzednie[id]; continue; }
    // czekamy, aż przestaniesz ciągnąć (ta sama długość dwa razy z rzędu)
    if (ROZ.poprzednie[id] == null || Math.abs(ROZ.poprzednie[id] - dl) > 0.5 / fps) { ROZ.poprzednie[id] = dl; continue; }
    delete ROZ.poprzednie[id];
    ROZ.zajete = true;
    try {
      if (!A) zaladujBiblioteke();
      if (!A || !A.znajdz(w.preset)) continue;
      const pr = A.znajdz(w.preset), p = Object.assign({}, w.parametry);
      if (pr.kat !== "przejscia") p.czas = Math.max(0.3, dl - (+p.opoznienie || 0));
      const folder = await anFolder();
      const nazwa = `${w.preset}_dl${dl.toFixed(1).replace(".", "-")}_${Date.now().toString(36).slice(-4)}.mov`;
      const wyn = await anRenderuj(w.preset, p, path.join(folder, nazwa));
      const nowy = Object.assign({}, w, { parametry: Object.assign({}, p), mov: wyn.plik, czas: wyn.czas, kiedy: new Date().toISOString() });
      fs.writeFileSync(wyn.plik.replace(/\.mov$/i, ".nada.json"), JSON.stringify(nowy, null, 1), "utf8");
      const z = await jsx(`nm_podmien_animacje(${q(id)}, ${q(wyn.plik)}, 0, ${q(kl.sciezka || plikWpisu(w))})`);
      if (z.ok) {
        OS.stare.add(id);
        if (z.idKlipu) anZapiszRejestr("id:" + z.idKlipu, nowy);
        anZapiszRejestr(path.basename(wyn.plik), nowy);
        if (anStan.edycja && anStan.edycja.idKlipu === id) { anStan.edycja.idKlipu = z.idKlipu || id; anStan.edycja.dl = dl; anStan.wczytuje = true; $("an_czas").max = String(Math.max(15, Math.ceil(p.czas))); $("an_czas").value = p.czas; $("an_czas").dispatchEvent(new Event("input")); anStan.wczytuje = false; }
        log(`Animacja „${pr.nazwa}” dopasowana do nowej długości: ${dl.toFixed(1).replace(".", ",")} s.`, "o");
      }
    } catch (e) { console.log(e); } finally { ROZ.zajete = false; }
    break;
  }
}
setInterval(() => { if (!document.hidden) osRozciaganie(); }, 1000);
// odpytuje oś co ok. 1 s, tylko gdy otwarte są Animacje albo Szablony
setInterval(() => { if (HOST === "PPRO" && ["animacje", "szablony", "napisy"].includes(stan.widok) && !document.hidden) osOdswiez(); }, 1100);

// ======================= ANIMACJE =======================
let A = null;
const anStan = { preset: null, kat: "tekst", t: 0, gra: true, start: performance.now(), raf: 0, moje: [], tlo: null, folder: null };
const PLIK_MOICH = () => path.join(SILNIK, "narzedzia", "animacje", "moje_presety.json");
function zaladujBiblioteke() {
  const plik = path.join(SILNIK, "narzedzia", "animacje", "animacje.js");
  try {
    delete NODE_REQ.cache[NODE_REQ.resolve(plik)];
    A = NODE_REQ(plik);
    window.NMAnim = A; global.NMAnim = A;
    A.ustawFabryke((w, h) => { const c = document.createElement("canvas"); c.width = w; c.height = h; return c; });
    const wl = path.join(SILNIK, "narzedzia", "animacje", "wlasne");
    if (fs.existsSync(wl)) fs.readdirSync(wl).filter((f) => f.endsWith(".js")).sort().forEach((f) => {
      const p = path.join(wl, f);
      try { delete NODE_REQ.cache[NODE_REQ.resolve(p)]; NODE_REQ(p); } catch (e) { console.log("Błąd presetu", f, e); }
    });
  } catch (e) { A = null; console.log(e); }
  anStan.moje = czytajJson(PLIK_MOICH()) || [];
}
function anRozmiar() { const i = stan.info; return i && i.szer ? [i.szer, i.wys] : [1080, 1920]; }
function anMarka() {
  const p = {};
  ["kolor_glowny", "kolor_akcent", "kolor_tekstu", "kolor_tla", "font", "waga"].forEach((k) => (p[k] = $("an_" + k).value));
  p.kursywa = /i$/.test(p.waga); p.waga = parseInt(p.waga, 10) || 800;
  return p;
}
// ustawienia wspólne dla wszystkich animacji (suwaki i listy w „Ruch i układ” oraz „Tekst”)
const AN_LICZBY = ["rozmiar", "czas", "tempo", "wyjscie", "opoznienie", "przesun_x", "przesun_y", "obrot", "krycie", "odstep", "interlinia", "szerokosc", "obrys", "cien_moc"];
const AN_LISTY = ["pozycja", "wyjscie_styl", "wejscie_styl"], AN_KOLORY = ["kolor_obrysu", "kolor_cienia"];
function anParametry() {
  const pr = anStan.preset && A.znajdz(anStan.preset); if (!pr) return {};
  const p = Object.assign({}, pr.przyklad || {}, anStan.pola || {}, anMarka());
  AN_LICZBY.forEach((k) => (p[k] = +$("an_" + k).value));
  AN_KOLORY.forEach((k) => (p[k] = $("an_" + k).value));
  AN_LISTY.forEach((k) => { if ($("an_" + k).value) p[k] = $("an_" + k).value; else delete p[k]; });
  p.wielkie = $("an_wielkie").checked; p.cien = $("an_cien").checked;
  if (anStan.logoImg) p.logo = anStan.logoImg;
  return p;
}
const ETYKIETY_POL = { tekst: "Tekst (*gwiazdki* = wyróżnienie)", tekst2: "Drugi tekst / podpis", lista: "Lista (każda pozycja w nowej linii)", liczba: "Liczba", od: "Licz od", przed: "Przed liczbą", po: "Po liczbie", emoji: "Emoji" };
function anRysujPola() {
  const pr = A.znajdz(anStan.preset); if (!pr) return;
  $("anNazwa").textContent = pr.nazwa;
  const w = Object.assign({}, A.DOMYSLNE, pr.dom || {}, pr.przyklad || {}, anStan.pola || {});
  let h = "";
  (pr.pola || []).forEach((k) => {
    if (k === "xy" || k === "xy2") {
      const [a, b] = k === "xy" ? ["x", "y"] : ["x2", "y2"];
      h += `<div class="siatka2"><div class="w"><label>${k === "xy" ? "Punkt" : "Punkt 2"}: poziomo</label><output id="ap_${a}O"></output><input type="range" min="0" max="1" step="0.01" id="ap_${a}" data-k="${a}" value="${w[a]}"></div>
            <div class="w"><label>pionowo</label><output id="ap_${b}O"></output><input type="range" min="0" max="1" step="0.01" id="ap_${b}" data-k="${b}" value="${w[b]}"></div></div>`;
    } else if (k === "logo") h += `<p class="uwaga">Logo: pierwszy plik z folderu logo klienta${anStan.logoImg ? "" : " (brak, pokazuję nazwę z pola Tekst)"}.</p><div class="w"><span>Tekst zamiast logo</span><span></span><textarea rows="2" class="tekst" data-k="tekst">${String(w.tekst).replace(/</g, "&lt;")}</textarea></div>`;
    else if (k === "lista") h += `<div class="w"><span>${ETYKIETY_POL[k]}</span><span></span><textarea rows="4" data-k="lista">${String(w.lista).replace(/</g, "&lt;")}</textarea></div>`;
    else if (k === "liczba" || k === "od") h += `<div class="w"><span>${ETYKIETY_POL[k]}</span><span></span><input type="number" step="any" data-k="${k}" value="${w[k]}"></div>`;
    else h += `<div class="w"><span>${ETYKIETY_POL[k] || k}</span><span></span><textarea rows="2" class="tekst" data-k="${k}">${String(w[k] == null ? "" : w[k]).replace(/</g, "&lt;")}</textarea></div>`;
  });
  $("anPola").innerHTML = h || '<p class="uwaga">Ten preset nie ma tekstów: ustaw tylko ruch i kolory.</p>';
  $$("[data-k]", $("anPola")).forEach((el) => {
    if (el.type === "range") suwak(el.id, "", 2);
    el.addEventListener("input", () => { anStan.pola = anStan.pola || {}; anStan.pola[el.dataset.k] = el.type === "number" || el.type === "range" ? +el.value : el.value; anRestart(); });
  });
  $("an_czas").value = +(w.czas || pr.czas || 3); $("an_czas").dispatchEvent(new Event("input"));
  $("an_wyjscie").value = w.wyjscie; $("an_wyjscie").dispatchEvent(new Event("input"));
  $("an_pozycja").value = w.pozycja || ""; $("an_wielkie").checked = !!w.wielkie;
}
function anWybierz(id, parametry) {
  anStan.preset = id; anStan.pola = parametry ? Object.assign({}, parametry) : {};
  const D = A.DOMYSLNE, pr0 = A.znajdz(id) || {}, dom = Object.assign({}, D, pr0.dom || {});
  ["rozmiar", "tempo", "opoznienie", "przesun_x", "przesun_y", "obrot", "krycie", "odstep", "interlinia", "szerokosc", "obrys", "cien_moc"].forEach((k) => {
    const v = parametry && parametry[k] != null ? parametry[k] : dom[k]; $("an_" + k).value = v == null ? 0 : v; $("an_" + k).dispatchEvent(new Event("input")); });
  AN_KOLORY.forEach((k) => ($("an_" + k).value = (parametry && parametry[k]) || dom[k] || "#000000"));
  $("an_wejscie_styl").value = (parametry && parametry.wejscie_styl) || "";
  $("an_wyjscie_styl").value = (parametry && parametry.wyjscie_styl) || "zanik"; $("an_cien").checked = !parametry || parametry.cien !== false;
  anRysujPola();
  if (parametry) ["czas", "wyjscie"].forEach((k) => { if (parametry[k] != null) { $("an_" + k).value = parametry[k]; $("an_" + k).dispatchEvent(new Event("input")); } });
  $$(".karta", $("anGaleria")).forEach((k) => k.setAttribute("aria-pressed", String(k.dataset.id === id && !k.dataset.moj === !parametry)));
  zapisz("nm-an-preset", id); anRestart();
}
function anKategorie() {
  if (!A) return;
  const kat = A.KATEGORIE.filter((k) => k.id !== "wlasne" || A.PRESETY.some((p) => p.kat === "wlasne")).concat(anStan.moje.length ? [{ id: "moje", nazwa: "Moje ☆" }] : []);
  $("anKategorie").innerHTML = kat.map((k) => `<button data-k="${k.id}" aria-pressed="${k.id === anStan.kat}">${k.nazwa} <span style="color:#777">${k.id === "moje" ? anStan.moje.length : A.PRESETY.filter((p) => p.kat === k.id).length}</span></button>`).join("");
  $$("button", $("anKategorie")).forEach((b) => (b.onclick = () => { anStan.kat = b.dataset.k; zapisz("nm-an-kat", anStan.kat); anKategorie(); anGaleria(); }));
}
function anMiniatura(c, id, p, t) {
  const ctx = c.getContext("2d"); ctx.clearRect(0, 0, c.width, c.height);
  try { A.rysuj(ctx, id, t, Object.assign({}, p, anMarka()), c.width, c.height); } catch (e) {}
}
function anGaleria() {
  if (!A || !$("anGaleria")) return;
  const [W, H] = anRozmiar(), sk = 200 / Math.max(W, H), w = Math.round(W * sk), h = Math.round(H * sk);
  const lista = anStan.kat === "moje" ? anStan.moje.map((m) => ({ id: m.preset, nazwa: m.nazwa, przyklad: m.parametry, moj: m }))
    : A.PRESETY.filter((p) => p.kat === anStan.kat);
  $("anGaleria").innerHTML = lista.map((p, i) => `<div class="karta" role="button" tabindex="0" title="${p.nazwa.replace(/"/g, "")}" data-i="${i}" data-id="${p.id}" ${p.moj ? 'data-moj="1"' : ""}><canvas width="${w}" height="${h}" style="aspect-ratio:${w}/${h}"></canvas><span>${p.nazwa.replace(/</g, "")}</span></div>`).join("");
  $$(".karta", $("anGaleria")).forEach((k) => {
    const p = lista[+k.dataset.i], c = k.querySelector("canvas"), pr = A.znajdz(p.id); if (!pr) return;
    const T = A.czas(p.id, p.przyklad), stop = pr.pelne ? T * 0.35 : Math.min(T - 0.45, T * 0.6);
    anMiniatura(c, p.id, p.przyklad, stop);
    let raf = 0, t0 = 0;
    k.onmouseenter = () => { t0 = performance.now(); const kl = () => { anMiniatura(c, p.id, p.przyklad, ((performance.now() - t0) / 1000) % (T + 0.3)); raf = requestAnimationFrame(kl); }; kl(); };
    k.onmouseleave = () => { cancelAnimationFrame(raf); anMiniatura(c, p.id, p.przyklad, stop); };
    k.onclick = () => anWybierz(p.id, p.moj ? p.moj.parametry : null);
  });
}
function anFormat() {
  if (!A) return;
  const [W, H] = anRozmiar(), c = $("anPodglad"), sk = Math.min(1, 720 / Math.max(W, H));
  c.width = Math.round(W * sk); c.height = Math.round(H * sk);
  $("anPodgladBox").style.maxWidth = H > W ? "260px" : "100%"; $("anPodgladBox").style.margin = H > W ? "0 auto" : "0";
  if (stan.widok === "animacje") anGaleria();
}
function anRestart() { if (!$("anGraj")) return; anStan.start = performance.now(); anStan.gra = true; $("anGraj").textContent = "❚❚"; }
function anKlatka() {
  if (A && anStan.preset && A.znajdz(anStan.preset)) {
    const p = anParametry(), T = A.czas(anStan.preset, p), c = $("anPodglad");
    if (anStan.gra) anStan.t = ((performance.now() - anStan.start) / 1000) % (T + 0.6);
    $("anCzas").value = Math.round(Math.min(1, anStan.t / T) * 1000);
    const ctx = c.getContext("2d"); ctx.clearRect(0, 0, c.width, c.height);
    try { A.rysuj(ctx, anStan.preset, Math.min(anStan.t, T), p, c.width, c.height); } catch (e) { console.log(e); }
  }
  anStan.raf = requestAnimationFrame(anKlatka);
}
function anStart() {
  if (!A) zaladujBiblioteke();
  if (!A) { $("anGaleria").innerHTML = '<p class="uwaga">Nie mogę wczytać biblioteki animacji z folderu silnika (narzedzia/animacje/animacje.js). Uruchom ponownie instalację panelu.</p>'; return; }
  anKategorie(); anFormat(); anGaleria();
  if (!anStan.preset) { const z = wczytaj("nm-an-preset", ""); anWybierz(A.znajdz(z) ? z : "pop-slowa"); }
  cancelAnimationFrame(anStan.raf); anStan.raf = requestAnimationFrame(anKlatka);
}
function anStop() { cancelAnimationFrame(anStan.raf); }
$("anGraj").onclick = () => { anStan.gra = !anStan.gra; if (anStan.gra) anStan.start = performance.now() - anStan.t * 1000; $("anGraj").textContent = anStan.gra ? "❚❚" : "▶"; };
$("anCzas").oninput = () => { anStan.gra = false; $("anGraj").textContent = "▶"; const T = A.czas(anStan.preset, anParametry()); anStan.t = +$("anCzas").value / 1000 * T; };
["an_rozmiar", "an_czas", "an_tempo", "an_wyjscie", "an_opoznienie"].forEach((id) => suwak(id, id === "an_czas" || id === "an_wyjscie" || id === "an_opoznienie" ? " s" : "×", 2));
["an_przesun_x", "an_przesun_y", "an_odstep", "an_interlinia", "an_szerokosc", "an_krycie", "an_cien_moc", "an_obrys"].forEach((id) => suwak(id, "", 2));
suwak("an_obrot", "°", 0);
[...AN_LICZBY, ...AN_LISTY, ...AN_KOLORY, "wielkie", "cien"].forEach((k) => $("an_" + k).addEventListener("input", anRestart));
$("anRozciagana").checked = false; // bez After Effects: rozciąganie robi sam panel (przerysowuje animację do nowej długości)
if (false) $("anRozciagana").checked = wczytaj("nm-an-rozciagana", true); $("anRozciagana").onchange = () => zapisz("nm-an-rozciagana", $("anRozciagana").checked);
["an_kolor_glowny", "an_kolor_akcent", "an_kolor_tekstu", "an_kolor_tla", "an_font", "an_waga"].forEach((id) => $(id).addEventListener("change", () => { anZaladujFonty(); anGaleria(); anRestart(); }));
$("anKlatka").onclick = async () => {
  const cel = path.join(NODE_REQ("os").tmpdir(), "nm_kadr_" + Date.now() + ".png");
  const r = await jsx(`nm_klatka(${q(cel)})`);
  if (r.ok) { $("anTlo").src = "file:///" + r.plik.replace(/\\/g, "/") + "?" + Date.now(); $("anTlo").hidden = false; }
  else { $("anTlo").hidden = true; $("anMarkaInfo").textContent = "Nie udało się pobrać kadru z Premiere (" + (r.blad || "") + ")."; }
};

// marka klienta
/* Marka klienta wybranego u góry panelu: role kolorów z marka.md, karta z brandbooka, animacje.json. Wszystkie narzędzia biorą ją same. */
function markaKlienta() {
  const f = folderKlienta(), d = {}, r = {};
  let zrodlo = "";
  if (!f) return { f: null, d, role: r, zrodlo };
  const karta = czytajJson(path.join(f, "brandbook", "karta_klienta.json"));
  if (karta) { const pal = karta.paleta || []; if (pal[0]) d.kolor_glowny = pal[0]; if (pal[1]) d.kolor_akcent = pal[1]; if (karta.fonts && karta.fonts.heading) d.font = karta.fonts.heading; if (karta.fonts && karta.fonts.body) d.font_tekstu = karta.fonts.body; zrodlo = "brandbook"; }
  try {
    const md = fs.readFileSync(path.join(f, "marka.md"), "utf8"), m = md.match(/\{[^{}]*"(?:akcent|tlo_ciemne)"[^{}]*\}/);
    if (m) {
      Object.assign(r, JSON.parse(m[0]));
      if (r.akcent) d.kolor_glowny = r.akcent; if (r.podswietlenie_napisow || r.przycisk) d.kolor_akcent = r.podswietlenie_napisow || r.przycisk;
      if (r.tlo_ciemne) d.kolor_tla = r.tlo_ciemne; if (r.tekst_na_ciemnym) d.kolor_tekstu = r.tekst_na_ciemnym;
      zrodlo = "notatka marki";
    }
  } catch (e) {}
  const wl = czytajJson(path.join(f, "animacje.json")); if (wl) { Object.assign(d, wl); zrodlo = zrodlo ? zrodlo + " + animacje.json" : "animacje.json"; }
  return { f, d, role: r, zrodlo: zrodlo || "brak danych marki" };
}
function anMarkaKlienta() {
  const { f, d, zrodlo } = markaKlienta();
  anStan.logoImg = null;
  if (f) {
    let logo = d.logo; if (logo && !path.isAbsolute(logo)) logo = path.join(SILNIK, logo);
    if (!logo) { try { const l = fs.readdirSync(path.join(f, "logo")).filter((n) => /\.(png|jpe?g|webp|svg)$/i.test(n)); if (l.length) logo = path.join(f, "logo", l[0]); } catch (e) {} }
    if (logo && fs.existsSync(logo)) { const img = new Image(); img.onload = () => { anStan.logoImg = img; anRestart(); }; img.src = "file:///" + logo.replace(/\\/g, "/"); }
  }
  const dom = { kolor_glowny: "#ff6b2c", kolor_akcent: "#ffd23f", kolor_tekstu: "#ffffff", kolor_tla: "#141414", font: "Montserrat", waga: 800 };
  const m = Object.assign({}, dom, d);
  Object.entries(m).forEach(([k, v]) => { if ($("an_" + k) && k !== "logo" && k !== "waga") $("an_" + k).value = String(v).toLowerCase().startsWith("#") ? String(v).toLowerCase() : v; });
  wypelnijWarianty($("an_waga"), String(m.waga || 800) + (m.kursywa ? "i" : ""));
  $("anMarkaInfo").textContent = f ? `Kolory i font z marki klienta ${$("klient").value} (${zrodlo}).` : "Wybierz klienta u góry panelu, a kolory, font i logo wczytają się same.";
  $("markaInfo").textContent = f ? `Marka: ${zrodlo}` : "";
  anZaladujFonty(); if (A && stan.widok === "animacje") { anGaleria(); anRestart(); }
}
// ---------- fonty: ok. 1500 rodzin Google z polskimi znakami, warianty pod prawdziwymi nazwami ----------
const WAGI = [[/thin|hairline/i, 100], [/extralight|ultralight/i, 200], [/light/i, 300], [/medium/i, 500], [/semibold|demibold/i, 600], [/extrabold|ultrabold/i, 800], [/black|heavy/i, 900], [/bold/i, 700]];
const NAZWY_WAG = { 100: "Thin", 200: "ExtraLight", 300: "Light", 400: "Regular", 500: "Medium", 600: "SemiBold", 700: "Bold", 800: "ExtraBold", 900: "Black" };
const nazwaWariantu = (w, it) => (it ? (+w === 400 ? "Italic" : `${NAZWY_WAG[w] || w} Italic`) : NAZWY_WAG[w] || String(w));
let FONTY_G = null;
function fontyGoogle() {
  if (!FONTY_G) {
    FONTY_G = czytajJson(path.join(SILNIK, "narzedzia", "fonty_lista.json")) || { polecane: [], rodziny: [] };
    FONTY_G.mapa = new Map(FONTY_G.rodziny.map((r) => [r[0].toLowerCase(), r]));
  }
  return FONTY_G;
}
const klFontu = (n) => String(n || "").toLowerCase().replace(/[\s_-]+/g, "");
/* Pliki fontu na dysku: fonty klienta i wspólny folder fonty/<Nazwa>/ (tam pobiera narzedzia/fonty.py). */
function plikiRodziny(nazwa) {
  const kl = klFontu(nazwa), wyn = [], f = folderKlienta();
  const foldery = [path.join(SILNIK, "fonty", String(nazwa).replace(/\s+/g, ""))]; if (f) foldery.unshift(path.join(f, "fonty"));
  const zbierz = (d, g = 0) => { try { fs.readdirSync(d, { withFileTypes: true }).forEach((e) => { const p = path.join(d, e.name); if (e.isDirectory() && g < 2) zbierz(p, g + 1);
    else if (/\.(ttf|otf|woff2?)$/i.test(e.name)) { const b = klFontu(e.name.replace(/\.\w+$/, "")); if (b.startsWith(kl) && !/^(alternates|sc|display|condensed|mono)/.test(b.slice(kl.length).replace(/^\d.*$/, ""))) {
      const m = e.name.match(/-(\d00)(i?)\.\w+$/); const it = m ? !!m[2] : /italic/i.test(e.name);
      const w = m ? +m[1] : (WAGI.find(([r]) => r.test(e.name.replace(/italic/i, ""))) || [0, 400])[1];
      wyn.push({ p, w, it }); } } }); } catch (e) {} };
  foldery.forEach((d) => zbierz(d));
  return wyn;
}
function wariantyRodziny(nazwa) {
  const g = fontyGoogle().mapa.get(String(nazwa || "").trim().toLowerCase());
  let war = g ? g[2].split(",").map((v) => ({ w: parseInt(v, 10), it: /i$/.test(v) })) : [];
  if (!war.length) { war = plikiRodziny(nazwa).map((x) => ({ w: x.w, it: x.it })); }
  if (!war.length) war = [400, 700].map((w) => ({ w, it: false }));
  const uniq = new Map(); war.forEach((x) => uniq.set(x.w + (x.it ? "i" : ""), x));
  return [...uniq.entries()].sort((a, b) => a[1].w - b[1].w || a[1].it - b[1].it).map(([v, x]) => ({ v, w: x.w, it: x.it }));
}
/* Wypełnia listę wariantów (np. „Montserrat Black”) dla fontu z pola wskazanego w data-font. */
function wypelnijWarianty(sel, chce) {
  const inp = $(sel.dataset.font), nazwa = (inp.value.trim() || inp.placeholder || "Montserrat").trim();
  const g = fontyGoogle().mapa.get(nazwa.toLowerCase()), pelna = g ? g[0] : nazwa;
  const war = wariantyRodziny(nazwa), stara = chce != null ? String(chce) : sel.value;
  sel.innerHTML = (sel.dataset.dom ? '<option value="">Jak w szablonie</option>' : "") + war.map((x) => `<option value="${x.v}">${pelna} ${nazwaWariantu(x.w, x.it)}</option>`).join("");
  if (war.some((x) => x.v === stara) || (sel.dataset.dom && stara === "")) sel.value = stara;
  else if (!sel.dataset.dom) { const cel = parseInt(stara, 10) || 800, it = /i$/.test(stara); const n = war.filter((x) => x.it === it).concat(war).sort((a, b) => Math.abs(a.w - cel) - Math.abs(b.w - cel))[0]; sel.value = n ? n.v : war[0].v; }
}
let fontyDatalist = false;
function wypelnijDatalist() {
  if (fontyDatalist) return; fontyDatalist = true;
  const G = fontyGoogle(), pol = new Set(G.polecane), KAT = { s: "bezszeryfowy", r: "szeryfowy", d: "ozdobny", h: "odręczny", m: "stała szerokość" };
  const klienta = []; const f = folderKlienta();
  $("anFonty").innerHTML = [...klienta, ...G.polecane.map((n) => `<option value="${n}">★ polecany</option>`),
    ...G.rodziny.filter((r) => !pol.has(r[0])).map((r) => `<option value="${r[0]}">${KAT[r[1]] || ""}</option>`)].join("");
}
const fontyZaladowane = new Set(), fontyPobierane = new Map();
function zaladujPlik(nazwa, x) {
  const k = x.p + "|" + nazwa; if (fontyZaladowane.has(k)) return Promise.resolve();
  fontyZaladowane.add(k);
  try { const ff = new FontFace(nazwa, `url("${URL_PLIKU(x.p)}")`, { weight: String(x.w), style: x.it ? "italic" : "normal" }); return ff.load().then((y) => { document.fonts.add(y); }).catch(() => {}); } catch (e) { return Promise.resolve(); }
}
/* Ładuje do podglądu wszystkie pliki rodziny z dysku; brakujący wariant (gdy podany) pobiera z Google Fonts w tle. */
function zaladujRodzine(nazwa, potem, wariant) {
  nazwa = String(nazwa || "").trim(); if (!nazwa) return;
  const pliki = plikiRodziny(nazwa);
  Promise.all(pliki.map((x) => zaladujPlik(nazwa, x))).then(() => potem && pliki.length && potem());
  const g = fontyGoogle().mapa.get(nazwa.toLowerCase());
  if (!g) return;
  const chce = wariant ? [wariant] : (pliki.length ? [] : ["400", "700"].filter((v) => g[2].split(",").includes(v)).concat(g[2].split(",").includes("800") ? ["800"] : []));
  chce.forEach((v) => {
    const w = parseInt(v, 10), it = /i$/.test(v);
    if (pliki.some((x) => x.w === w && x.it === it)) return;
    const klucz = g[0] + v; if (fontyPobierane.has(klucz)) return;
    const info = $("anFontInfo"); if (info) info.textContent = `Pobieram ${g[0]} ${nazwaWariantu(w, it)} z Google Fonts…`;
    const pr = python("fonty.py", ["wariant", "--rodzina", g[0], "--waga", String(w), ...(it ? ["--kursywa"] : [])]).then((r) => {
      if (info) info.textContent = r.ok ? `${r.nazwa}: gotowe. Żeby był też w Premiere i After Effects, zainstaluj go: python narzedzia\\fonty.py instaluj --rodzina "${g[0]}"` : `Nie udało się pobrać fontu (${r.blad || "brak internetu?"}).`;
      if (r.ok) zaladujPlik(nazwa, { p: r.plik, w, it }).then(() => potem && potem());
    });
    fontyPobierane.set(klucz, pr);
  });
}
function anZaladujFonty() {
  wypelnijDatalist();
  zaladujRodzine($("an_font").value, () => { if (A && stan.widok === "animacje") { anGaleria(); anRestart(); } }, $("an_waga").value);
}
function anZaladujFontyNazwa(nazwa, wariant) { zaladujRodzine(nazwa, () => szRestart && szRestart(), wariant); }
// każde pole fontu z listą wariantów: zmiana fontu odświeża warianty
$$("select[data-font]").forEach((sel) => {
  const inp = $(sel.dataset.font);
  const odswiez = () => { wypelnijDatalist(); wypelnijWarianty(sel); sel.dispatchEvent(new Event("change")); };
  inp.addEventListener("change", odswiez);
  inp.addEventListener("input", () => { if (fontyGoogle().mapa.has(inp.value.trim().toLowerCase())) odswiez(); });
  wypelnijWarianty(sel, sel.id === "nWaga" ? nStan.wagaZapisana : undefined);
});
$("anZapiszMarke").onclick = () => {
  const f = folderKlienta(); if (!f) { $("anMarkaInfo").textContent = "Najpierw wybierz klienta u góry panelu."; return; }
  const plik = path.join(f, "animacje.json"), d = Object.assign(czytajJson(plik) || {}, anMarka());
  fs.writeFileSync(plik, JSON.stringify(d, null, 1), "utf8");
  $("anMarkaInfo").textContent = "Zapisane w " + path.relative(SILNIK, plik) + ". Claude i Studio też będą jej używać.";
};
$("anMarkaZKarty").onclick = () => {
  const f = folderKlienta(), karta = f && czytajJson(path.join(f, "brandbook", "karta_klienta.json"));
  if (!karta) { $("anMarkaInfo").textContent = "Ten klient nie ma brandbook/karta_klienta.json (zrób brandbook narzędziem Brandbook w Studio)."; return; }
  const pal = karta.paleta || []; if (pal[0]) $("an_kolor_glowny").value = pal[0].toLowerCase(); if (pal[1]) $("an_kolor_akcent").value = pal[1].toLowerCase();
  if (karta.fonts && karta.fonts.heading) { $("an_font").value = karta.fonts.heading; wypelnijWarianty($("an_waga")); }
  anZaladujFonty(); anGaleria(); anRestart();
};
$("anMoj").onclick = () => {
  if (!anStan.preset) return;
  const p = anParametry(); delete p.logo; ["kolor_glowny", "kolor_akcent", "kolor_tekstu", "kolor_tla", "font", "waga"].forEach((k) => delete p[k]);
  const nazwa = (A.znajdz(anStan.preset).nazwa + ": " + String(p.tekst || "").replace(/\*/g, "")).slice(0, 40);
  anStan.moje.push({ id: Date.now().toString(36), nazwa, preset: anStan.preset, parametry: p });
  fs.writeFileSync(PLIK_MOICH(), JSON.stringify(anStan.moje, null, 1), "utf8");
  anKategorie(); $("anMoj").textContent = "★ Zapisane w „Moje”"; setTimeout(() => ($("anMoj").textContent = "☆ Zapisz te ustawienia jako mój preset"), 2500);
};

// render do MOV (ProRes 4444 z przezroczystością) w panelu
async function anFolder() {
  if (anStan.folder && fs.existsSync(anStan.folder)) return anStan.folder;
  const i = stan.info || (await odswiezInfo());
  anStan.folder = await folderWynikow($("klient").value || (i && i.projekt) || "projekt", "animacje");
  return anStan.folder;
}
/* Zapas na końcu pliku: można przeciągnąć koniec animacji na osi, a panel sam ją przerysuje do nowej długości. */
const AN_ZAPAS_S = 15;
async function anRenderuj(id, p, cel, naPostep) {
  const [W, H] = anRozmiar(), fps = stan.info ? stan.info.fps : 30, T = A.czas(id, p), pr = A.znajdz(id) || {};
  // klatka „w trakcie” (przed wyjściem): nią wypełniony jest zapas, dopóki panel nie przerysuje animacji do nowej długości
  const wyj = pr.pelne ? 0 : Math.min(+p.wyjscie || 0, T * 0.45), tStoi = Math.max(0, T - wyj - 0.05);
  return renderKlatek((ctx, t) => A.rysuj(ctx, id, t, p, W, H), W, H, fps, T, cel, naPostep, null, pr.kat === "przejscia" ? null : { ogon: AN_ZAPAS_S, tStoi });
}
async function renderKlatek(rysujKlatke, W, H, fps, T, cel, naPostep, przedKlatka, zapas) {
  const n = Math.max(1, Math.round(T * fps));
  const c = document.createElement("canvas"); c.width = W; c.height = H;
  const ctx = c.getContext("2d", { willReadFrequently: true });
  // QuickTime Animation (qtrle): przezroczystość jak ProRes 4444, a zapis ok. 25 razy szybszy, więc poprawki szybko widać na osi
  const kodek = /\.mp4$/i.test(cel) ? ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "16", "-preset", "veryfast"] : ["-c:v", "qtrle", "-pix_fmt", "argb"];
  let wejscie2 = [], filtr = [];
  if (zapas && zapas.ogon > 0) {
    if (przedKlatka) await przedKlatka(zapas.tStoi);
    ctx.clearRect(0, 0, W, H); rysujKlatke(ctx, zapas.tStoi);
    const png = cel.replace(/\.(mov|mp4)$/i, "_zapas.png");
    fs.writeFileSync(png, BUF.from(c.toDataURL("image/png").split(",")[1], "base64"));
    wejscie2 = ["-i", png];
    // jedna klatka powielona przez tpad: dużo szybciej niż zapętlanie obrazka
    filtr = ["-filter_complex", `[0:v]format=rgba,setsar=1[a];[1:v]format=rgba,fps=${+fps.toFixed(3)},tpad=stop_mode=clone:stop_duration=${zapas.ogon},setsar=1[b];[a][b]concat=n=2:v=1:a=0${/\.mp4$/i.test(cel) ? ",format=yuv420p" : ""}[v]`, "-map", "[v]"];
  }
  const ff = cp.spawn(cfg.ffmpeg || "ffmpeg", ["-hide_banner", "-loglevel", "error", "-y", "-f", "rawvideo", "-pix_fmt", "rgba", "-s", `${W}x${H}`, "-r", String(+fps.toFixed(3)), "-i", "-",
    ...wejscie2, ...filtr, ...kodek, cel], { windowsHide: true });
  let err = ""; ff.stderr.on("data", (d) => (err += d));
  const koniec = new Promise((ok) => ff.on("close", ok));
  ff.on("error", (e) => (err += String(e)));
  const pisz = (b) => new Promise((ok) => (ff.stdin.write(b) ? ok() : ff.stdin.once("drain", ok)));
  for (let i = 0; i < n; i++) {
    if (przedKlatka) await przedKlatka(i / fps);
    ctx.clearRect(0, 0, W, H); rysujKlatke(ctx, i / fps);
    await pisz(BUF.from(ctx.getImageData(0, 0, W, H).data.buffer));
    if (i % 8 === 0) { naPostep && naPostep(i / n); await czekaj(0); }
  }
  ff.stdin.end();
  const kod = await koniec;
  if (kod !== 0) throw new Error("ffmpeg nie zapisał pliku: " + err.slice(-300) + (/ENOENT/.test(err) ? " (brak ffmpeg w PATH)" : ""));
  return { plik: cel, czas: T };
}
// Animacje wstawione z panelu: ustawienia zapisane obok pliku, żeby dało się je potem edytować z osi
const PLIK_NA_OSI = () => path.join(SYS("panel"), "animacje_na_osi.json");
function anRejestr() { return czytajJson(PLIK_NA_OSI()) || {}; }
function anZapiszRejestr(klucz, wpis) {
  const r = anRejestr(); r[klucz] = wpis;
  fs.mkdirSync(path.dirname(PLIK_NA_OSI()), { recursive: true }); fs.writeFileSync(PLIK_NA_OSI(), JSON.stringify(r, null, 1), "utf8");
}
/* .mogrt z ochroną wejścia i wyjścia: After Effects składa go w tle z gotowego MOV (narzedzia/animacje/ae_mogrt.jsx). */
async function anMogrt(mov, id, p, T, naStan) {
  const [W, H] = anRozmiar(), fps = stan.info ? stan.info.fps : 30;
  const pr = A.znajdz(id), wy = pr.pelne ? 0 : Math.min(+p.wyjscie || 0, T * 0.45);
  const we = Math.min(A.wejscie(id, p), Math.max(0, T - wy - 0.1));
  const mogrt = mov.replace(/\.mov$/i, ".mogrt"), nazwa = `Nada – ${pr.nazwa} ${new Date().toTimeString().slice(0, 8).replace(/:/g, "")}`;
  const builder = path.join(SILNIK, "narzedzia", "animacje", "ae_mogrt.jsx");
  const [, plik] = await aeUruchom((wynik, log) => `$.evalFile(new File(${JSON.stringify(builder)}));\nNM_AE_MOGRT(${JSON.stringify({ plik: mov, mogrt, nazwa, W, H, fps, czas: T, wejscie: we, wyjscie: wy, wynik, log })});\n`, "mogrt", naStan, 240000);
  return { plik: plik || mogrt, nazwa, wejscie: we, wyjscie: wy };
}
async function anZrob(wstaw, naZywo) {
  const b = wstaw ? $("anWstaw") : $("anZapiszPlik"), tekst = b.textContent;
  if (anStan.zajete) { if (naZywo) anStan.ponow = true; return; }
  anStan.zajete = true; b.disabled = true;
  try {
    const p = anParametry(), id = anStan.preset, folder = await anFolder(), pr = A.znajdz(id);
    const edycja = wstaw ? anStan.edycja : null;
    // nowa animacja: nad zaznaczonym klipem albo klipem pod głowicą, z jego długością
    let start = null, cel = null;
    if (wstaw && !edycja && HOST === "PPRO") {
      await osOdswiez(); cel = celWstawienia();
      if (cel && $("anDopasuj").checked) {
        if (pr.kat === "przejscia") start = Math.max(0, cel.end - A.czas(id, p) / 2);
        else { p.czas = Math.max(0.5, cel.dl - (+p.opoznienie || 0)); start = cel.start; }
      }
    }
    if (edycja && edycja.dl && !edycja.mogrt && pr.kat !== "przejscia") p.czas = Math.max(0.5, edycja.dl - (+p.opoznienie || 0));
    const nazwa = `${id}_${String(p.tekst || "").replace(/\*/g, "").replace(/[^\p{L}\p{N}]+/gu, "_").slice(0, 24)}_${Date.now().toString(36).slice(-4)}.mov`.replace(/__+/g, "_");
    const r = await anRenderuj(id, p, path.join(folder, nazwa), (x) => (b.textContent = `${naZywo ? "Odświeżam na osi" : "Renderuję"}… ${Math.round(x * 100)}%`));
    const zapisane = Object.assign({}, p); delete zapisane.logo;
    const wpis = { typ: "animacja", preset: id, parametry: zapisane, mov: r.plik, czas: r.czas, kiedy: new Date().toISOString() };
    fs.writeFileSync(r.plik.replace(/\.mov$/i, ".nada.json"), JSON.stringify(wpis, null, 1), "utf8");
    if (wstaw || edycja) {
      const i = await odswiezInfo();
      let w, plikNaOs = r.plik, info = "";
      const rozciagana = false; // .mogrt przez After Effects wyłączony: animacja jest zwykłym plikiem z zapasem, a panel dopasowuje ją do długości na osi
      if (rozciagana || (edycja && edycja.mogrt)) {
        try {
          b.textContent = "After Effects robi .mogrt…";
          const m = await anMogrt(r.plik, id, p, r.czas, (t) => ($("anStanEdycji").hidden = false, $("anStanEdycji").textContent = t));
          plikNaOs = m.plik; wpis.mogrt = m.plik; wpis.nazwa = m.nazwa;
          info = ` Rozciągana: wejście ${m.wejscie.toFixed(1)} s i wyjście ${m.wyjscie.toFixed(1)} s zostają, środek się wydłuża.`;
        } catch (e) { info = " Wstawiłem zwykły MOV, bo After Effects nie zrobił .mogrt: " + (e.message || e); }
      }
      if (edycja) w = await jsx(`nm_podmien_animacje(${q(edycja.idKlipu)}, ${q(plikNaOs)}, ${wpis.mogrt ? 1 : 0}, ${q(edycja.plik || "")})`);
      else if (HOST === "AEFT") w = await jsx(`nm_ae_importuj(${q(r.plik)})`);
      else {
        const od = start != null ? start : (i.glowica || 0);
        w = wpis.mogrt ? await jsx(`nm_wstaw_mogrt(${q(plikNaOs)}, ${od}, ${r.czas})`) : await jsx(`nm_wstaw(${q(plikNaOs)}, ${od}, ${r.czas})`);
      }
      if (w.ok) {
        anZapiszRejestr(wpis.nazwa || path.basename(plikNaOs), wpis);
        anZapiszRejestr(path.basename(plikNaOs), wpis);
        if (w.nazwa) anZapiszRejestr(w.nazwa, wpis);
        if (w.idKlipu) anZapiszRejestr("id:" + w.idKlipu, wpis);
        if (edycja && w.idKlipu) { OS.stare.add(edycja.idKlipu); edycja.idKlipu = w.idKlipu; OS.zaznaczoneId = w.idKlipu; }
      }
      b.textContent = w.ok ? (edycja ? "Poprawione na osi ✓" : `Wstawione na ${w.sciezka} ✓`) : "Błąd";
      if (w.ok && !edycja && HOST === "PPRO") { $("anStanEdycji").hidden = false; $("anStanEdycji").textContent = (cel && $("anDopasuj").checked ? `Wstawiona nad „${cel.nazwa}”, długość ${r.czas.toFixed(1).replace(".", ",")} s.` : "Wstawiona pod głowicą.") + " Kliknij ją na osi, a wróci tu do poprawek."; }
      if (!w.ok) alertBlad(w.blad); else if (info) { $("anStanEdycji").hidden = false; $("anStanEdycji").textContent = info.trim(); }
    } else { b.textContent = "Zapisane ✓"; otworzFolder(folder); }
  } catch (e) { alertBlad(e); }
  anStan.zajete = false;
  setTimeout(() => { b.disabled = false; if (wstaw) anPokazEdycje(); else b.textContent = tekst; }, naZywo ? 300 : 1800);
  if (anStan.ponow) { anStan.ponow = false; setTimeout(() => anZrob(true, true), 350); }
}
function anPokazEdycje() {
  const e = anStan.edycja;
  if (!anStan.zajete) $("anWstaw").textContent = e ? "Popraw na osi" : "Wstaw nad klipem";
  $("anNowa").hidden = !e;
  if (e) $("anStanEdycji").hidden = false;
  if (e) $("anStanEdycji").innerHTML = `<b>Edytujesz „${e.nazwa.replace(/</g, "")}” z osi.</b> ${$("anNaZywo").checked && !e.mogrt ? "Każda zmiana poprawia ją na osi sama (po chwili)." : "Zmień, co chcesz, i kliknij „Popraw na osi”."} Zostaje w tym samym miejscu i z tą samą długością. <a href="#" id="anAnulujEd">Zakończ edycję</a>`;
  const an = $("anAnulujEd"); if (an) an.onclick = (ev) => { ev.preventDefault(); anStan.edycja = null; anStan.pomin = OS.zaznaczoneId; anPokazEdycje(); };
}
/* Otwiera w panelu animację z osi ze wszystkimi ustawieniami (po zaznaczeniu jej na osi albo przyciskiem). */
function anOtworzEdycje(x, w) {
  if (!A.znajdz(w.preset)) throw new Error("Nie ma już presetu " + w.preset + ".");
  const pr = A.znajdz(w.preset);
  if (anStan.kat !== pr.kat) { anStan.kat = pr.kat; anKategorie(); anGaleria(); }
  const p = Object.assign({}, w.parametry);
  // długość z osi: klip mógł zostać rozciągnięty albo przycięty
  const dl = Math.max(0.3, (x.end - x.start) || p.czas || 3);
  if (!w.mogrt && pr.kat !== "przejscia") p.czas = Math.max(0.5, dl - (+p.opoznienie || 0));
  $("an_czas").max = String(Math.max(15, Math.ceil(p.czas || 0)));
  ["kolor_glowny", "kolor_akcent", "kolor_tekstu", "kolor_tla"].forEach((k) => p[k] && ($("an_" + k).value = p[k]));
  if (p.font) { $("an_font").value = p.font; wypelnijWarianty($("an_waga"), String(p.waga || 800) + (p.kursywa ? "i" : "")); }
  anStan.wczytuje = true;
  anWybierz(w.preset, p);
  anStan.wczytuje = false;
  anStan.edycja = { idKlipu: x.idKlipu, nodeId: x.nodeId, nazwa: pr.nazwa, mogrt: !!w.mogrt, dl, plik: x.sciezka || "" };
  anZaladujFonty(); anPokazEdycje();
}
$("anEdytuj").onclick = async () => {
  try {
    await osOdswiez();
    const k = OS.stan && OS.stan.ok ? (OS.stan.zaznaczone || []).map((x) => ({ x, w: wpisZKlipu(x) })).find((y) => y.w && y.w.typ !== "szablon") : null;
    if (!k) throw new Error("Zaznacz na osi animację, którą wstawiłeś z tego panelu (kliknij ją), i kliknij jeszcze raz.");
    anOtworzEdycje(k.x, k.w);
  } catch (e) { alertBlad(e); }
};
$("anWstaw").onclick = () => anZrob(true);
$("anNowa").onclick = () => { anStan.edycja = null; anStan.pomin = OS.zaznaczoneId; anPokazEdycje(); $("anStanEdycji").hidden = true; anZrob(true); };
$("anZapiszPlik").onclick = () => anZrob(false);
// zmiany w trakcie edycji: po chwili same poprawiają animację na osi
(function () {
  let t = 0;
  const sekcja = document.querySelector('section[data-v="animacje"]');
  const zmiana = (e) => {
    if (!anStan.edycja || anStan.wczytuje || !$("anNaZywo").checked || anStan.edycja.mogrt) return;
    if (e.target.closest && e.target.closest("#anClaudeBox, #anEdytuj, #anWstaw, #anZapiszPlik, #anNaZywo, #anDopasuj, #anRozciagana")) return;
    clearTimeout(t); t = setTimeout(() => anZrob(true, true), 500);
  };
  sekcja.addEventListener("input", zmiana); sekcja.addEventListener("change", zmiana);
  sekcja.addEventListener("click", (e) => { if (e.target.closest && e.target.closest("#anGaleria .karta")) zmiana(e); });
})();

// animacje z opisu (Claude w tle)
const ETAPY_AN = [{ klucz: "przygotowanie", nazwa: "Przygotowanie", waga: 10 }, { klucz: "projekt", nazwa: "Projekt animacji", waga: 35 },
  { klucz: "render", nazwa: "Render", waga: 40 }, { klucz: "kontrola", nazwa: "Kontrola", waga: 15 }];
segment("anTryb", (v) => {
  $("anMowaBox").hidden = v !== "film";
  $("anOpisEtykieta").textContent = v === "film" ? "Co i kiedy pokazać w tym filmie" : "Opisz animację";
  $("anOpis").placeholder = v === "film" ? "np. 0:05 belka: Anna Nowak, CEO; gdy mówi o wzroście sprzedaży licznik +250%; przy „zapisz się” przycisk Obserwuj; na końcu logo" : "np. Tekst „-50%” wpada z góry, odbija się, za nim błysk w kolorze akcentu, na koniec napis „tylko do niedzieli”";
});
$("anClaude").onclick = async () => {
  const opis = $("anOpis").value.trim(); if (!opis) { $("anOpis").focus(); return; }
  $("anClaude").disabled = true;
  try {
    const tryb = wartoscSeg("anTryb"), [W, H] = anRozmiar();
    let folder, xml = null;
    if (tryb === "film") { const r = await przygotuj("animacje"); folder = r.folder; xml = r.xml; }
    else { const i = stan.info || (await odswiezInfo()); folder = await folderWynikow($("klient").value || (i && i.projekt) || "projekt", "animacja " + opis.slice(0, 30)); }
    const zad = { zrodlo: "premiere", tryb, opis, folder: path.relative(SILNIK, folder).split(path.sep).join("/"), format: `${W}x${H}`,
      fps: stan.info ? stan.info.fps : 30, klient: $("klient").value ? { folder: "klienci/" + $("klient").value } : null, marka_z_panelu: anMarka(),
      xml, dopasuj_do_mowy: tryb === "film" && $("anMowa").checked };
    const prompt = "Przeczytaj plik .claude/skills/animacje/SKILL.md i wykonaj go dokładnie dla tego zadania. Uruchomione z panelu w Premiere: nie zadawaj pytań, raportuj etapy przez narzedzia/postep.py. Kolory i font z `marka_z_panelu` mają pierwszeństwo przed marką klienta.\n\n```json\n" + JSON.stringify(zad, null, 1) + "\n```\n";
    const szac = tryb === "film" ? 300 + (zad.dopasuj_do_mowy && stan.info ? stan.info.sekundy * 0.25 : 0) : 200;
    startClaude({ typ: "animacje", nazwa: (tryb === "film" ? "Do filmu: " : "Nowa: ") + opis.slice(0, 40), folder, prompt, etapy: ETAPY_AN, szac });
  } catch (e) { alertBlad(e); }
  $("anClaude").disabled = false;
};
// ======================= ANIMACJE Z MOWY: mózg planuje, panel renderuje i wstawia (wszystko edytowalne) =======================
const ETAPY_AMZ = [{ klucz: "przygotowanie", nazwa: "Przygotowanie", waga: 8 }, { klucz: "mowa", nazwa: "Rozpoznanie mowy", waga: 45 },
  { klucz: "plan", nazwa: "Plan animacji", waga: 35 }, { klucz: "kontrola", nazwa: "Kontrola", waga: 12 }];
const AMZ_NATEZENIE = { malo: { na_minute: 1.5, odstep: 12 }, srednio: { na_minute: 3, odstep: 6 }, duzo: { na_minute: 6, odstep: 3 } };
["amzNaMinute", "amzOdstep"].forEach((id) => suwak(id, id === "amzOdstep" ? " s" : "", 1));
["amzMaks", "amzSzablony", "amzCoIle", "amzPrzejsciaMaks"].forEach((id) => suwak(id, "", 0));
segment("amzNatezenie", (v) => { const n = AMZ_NATEZENIE[v]; if (n) { $("amzNaMinute").value = n.na_minute; $("amzOdstep").value = n.odstep; ["amzNaMinute", "amzOdstep"].forEach((id) => $(id).dispatchEvent(new Event("input"))); } amzZapamietaj(); });
["amzNaMinute", "amzOdstep"].forEach((id) => $(id).addEventListener("input", (e) => { if (e.isTrusted) ustawSeg("amzNatezenie", "wlasne"); }));
const AMZ_POLA = ["amzNaMinute", "amzMaks", "amzOdstep", "amzDlugosc", "amzStyl", "amzJezyk", "amzSzablony", "amzPrzejscia", "amzCoIle", "amzPrzejsciaMaks", "amzMowcy", "amzUwagi", "amzEmoji", "amzZaznaczone"];
function amzZapamietaj() {
  const u = { nat: wartoscSeg("amzNatezenie"), rodzaje: $$("#amzRodzaje input[value]").filter((x) => x.checked).map((x) => x.value), pozycje: $$("#amzPozycje input").filter((x) => x.checked).map((x) => x.value) };
  AMZ_POLA.forEach((k) => (u[k] = $(k).type === "checkbox" ? $(k).checked : $(k).value));
  zapisz("nm-amz", u);
}
(function amzPrzywroc() {
  const u = wczytaj("nm-amz", null); if (!u) return;
  AMZ_POLA.forEach((k) => { if (u[k] == null) return; if ($(k).type === "checkbox") $(k).checked = u[k]; else $(k).value = u[k]; });
  if (u.nat) ustawSeg("amzNatezenie", u.nat);
  if (u.rodzaje) $$("#amzRodzaje input[value]").forEach((x) => (x.checked = u.rodzaje.includes(x.value)));
  if (u.pozycje) $$("#amzPozycje input").forEach((x) => (x.checked = u.pozycje.includes(x.value)));
  AMZ_POLA.forEach((k) => $(k).type === "range" && $(k).dispatchEvent(new Event("input")));
})();
$("amzBox").addEventListener("change", amzZapamietaj);
function amzUstawienia(zakres) {
  const rodzaje = $$("#amzRodzaje input[value]").filter((x) => x.checked).map((x) => x.value);
  return { natezenie: wartoscSeg("amzNatezenie"), na_minute: +$("amzNaMinute").value, maks: +$("amzMaks").value, odstep_s: +$("amzOdstep").value, dlugosc: $("amzDlugosc").value,
    rodzaje, styl: $("amzStyl").value, jezyk: $("amzJezyk").value, emoji: $("amzEmoji").checked, szablony_maks: rodzaje.includes("szablony") ? +$("amzSzablony").value : 0,
    przejscia: rodzaje.includes("przejscia") ? { tryb: $("amzPrzejscia").value, co_ile: +$("amzCoIle").value, maks: +$("amzPrzejsciaMaks").value } : { tryb: "brak" },
    pozycje: $$("#amzPozycje input").filter((x) => x.checked).map((x) => x.value), mowcy: $("amzMowcy").value.trim(), uwagi: $("amzUwagi").value.trim(), zakres: zakres || null };
}
/* lista presetów i szablonów, z których mózg może wybierać (tylko to, co panel umie wyrenderować sam) */
function amzKatalog(pion) {
  zaladujBiblioteke(); if (!SZ) zaladujSzablony();
  const animacje = (A ? A.PRESETY : []).map((p) => ({ id: p.id, nazwa: p.nazwa, kategoria: p.kat, pola: (p.pola || []).filter((k) => !["xy", "xy2", "logo"].includes(k)), czas_s: p.czas, przyklad: p.przyklad || {} }));
  const szablony = pion && SZ ? SZ.SZABLONY.filter((sz) => !(sz.pola || []).some((f) => f.typ !== "tekst")).map((sz) => ({ id: sz.id, nazwa: sz.nazwa, kategoria: sz.kat, czas_s: sz.czas, pola: (sz.pola || []).map((f) => ({ id: f.id, opis: f.etykieta, przyklad: f.dom })) })) : [];
  return { animacje, szablony, uwaga: pion ? "" : "Sekwencja jest pozioma: szablony rolek (pionowe, pełnoekranowe) są wyłączone." };
}
$("amzStart").onclick = async () => {
  $("amzStart").disabled = true;
  try {
    amzZapamietaj();
    let zakres = null;
    if ($("amzZaznaczone").checked) { await osOdswiez(); const c = celWstawienia(); if (!c || c.zrodlo !== "zaznaczony") throw new Error("Zaznacz na osi klipy, w których mają być animacje (albo odznacz „Tylko w zaznaczonym fragmencie”)."); zakres = { od_s: c.start, do_s: c.end }; }
    const { info, folder, xml } = await przygotuj("animacje z mowy");
    const [W, H] = anRozmiar(), ust = amzUstawienia(zakres);
    const kl = await jsx("nm_klipy_osi()");
    fs.writeFileSync(path.join(folder, "ciecia.json"), JSON.stringify(kl.ok ? { klipy: kl.klipy, dlugosc_s: kl.dlugosc } : { klipy: [] }, null, 1), "utf8");
    fs.writeFileSync(path.join(folder, "katalog.json"), JSON.stringify(amzKatalog(H > W), null, 1), "utf8");
    const zad = { zrodlo: "premiere", tryb: "mowa", folder: path.relative(SILNIK, folder).split(path.sep).join("/"), xml, format: `${W}x${H}`, fps: info.fps,
      sekwencja: { nazwa: info.nazwa, sekundy: info.sekundy }, klient: $("klient").value ? { folder: "klienci/" + $("klient").value } : null, marka_z_panelu: anMarka(), ustawienia: ust,
      mowa: { silnik: $("silnik").value || "auto", jezyk: $("jezyk").value || null } };
    fs.writeFileSync(path.join(folder, "zadanie.json"), JSON.stringify(zad, null, 1), "utf8");
    const prompt = "Przeczytaj plik narzedzia/animacje/z_mowy.md i wykonaj go dokładnie dla tego zadania (dane są też w zadanie.json w folderze zadania). Uruchomione z panelu w Premiere: nie zadawaj pytań, raportuj etapy przez narzedzia/postep.py.\n\n```json\n" + JSON.stringify(zad, null, 1) + "\n```\n";
    const z = startClaude({ typ: "animacje", nazwa: "Z mowy: " + info.nazwa, folder, prompt, etapy: ETAPY_AMZ, szac: 180 + (info.sekundy || 120) * 0.35 });
    z.tryb = "mowa"; zapiszZadania(); odswiezZadania();
    log("Animacje z mowy: zadanie w tle. Gdy plan będzie gotowy, kliknij przy zadaniu „Przejrzyj i wstaw”.");
  } catch (e) { alertBlad(e); }
  $("amzStart").disabled = false;
};
const amzCzas = (s) => { s = Math.max(0, +s || 0); const m = Math.floor(s / 60); return `${m}:${(s - m * 60).toFixed(1).padStart(4, "0")}`; };
function amzOpis(x) {
  if (x.rodzaj === "szablon") { const sz = SZ && SZ.znajdz(x.szablon); return "Szablon: " + (sz ? sz.nazwa : x.szablon); }
  const pr = A && A.znajdz(x.preset); return (x.rodzaj === "przejscie" ? "Przejście: " : "") + (pr ? pr.nazwa : x.preset);
}
function amzTekst(x) { const o = x.rodzaj === "szablon" ? x.pola || {} : x.parametry || {}; return Object.entries(o).filter(([k, v]) => typeof v === "string" && k !== "pozycja").map(([k, v]) => v).join(" | "); }
/* przegląd planu: można wyłączyć pozycję albo poprawić tekst, potem „Wstaw zaznaczone” */
function amzPokazPlan(z) {
  zaladujBiblioteke(); if (!SZ) zaladujSzablony();
  const plan = czytajJson(path.join(z.folder, "plan_animacji.json"));
  if (!plan || !Array.isArray(plan.pozycje)) { alertBlad("Nie widzę planu animacji (plan_animacji.json) w folderze zadania."); return; }
  pokaz("animacje"); $("amzBox").open = true;
  const box = $("amzPlan"); box.hidden = false;
  const poz = plan.pozycje.slice().sort((a, b) => a.czas_s - b.czas_s);
  box.innerHTML = `<h3>Plan: ${poz.length} pozycji</h3>${plan.podsumowanie ? `<p class="uwaga">${String(plan.podsumowanie).replace(/</g, "&lt;")}</p>` : ""}` +
    poz.map((x, i) => { const tk = amzTekst(x), pola = x.rodzaj === "szablon" ? x.pola || {} : x.parametry || {}, kl = Object.keys(pola).find((k) => typeof pola[k] === "string" && k !== "pozycja");
      return `<div class="amz-poz" data-i="${i}"><input type="checkbox" checked><div class="gl"><b>${amzCzas(x.czas_s)}</b><span>${amzOpis(x).replace(/</g, "&lt;")}${x.dlugosc_s ? ` · ${(+x.dlugosc_s).toFixed(1).replace(".", ",")} s` : ""}</span></div>
        ${kl ? `<textarea rows="1" data-k="${kl}">${String(pola[kl]).replace(/</g, "&lt;")}</textarea>` : ""}${x.uzasadnienie || x.slowa ? `<small>${String(x.slowa ? "„" + x.slowa + "” · " : "").replace(/</g, "&lt;")}${String(x.uzasadnienie || "").replace(/</g, "&lt;")}</small>` : ""}</div>`; }).join("") +
    `<div class="siatka2"><button class="glowny" id="amzWstaw">Wstaw zaznaczone</button><button class="maly" id="amzZamknij">Zamknij plan</button></div><p class="uwaga" id="amzStan"></p>`;
  $$(".amz-poz input[type=checkbox]", box).forEach((c) => (c.onchange = () => { c.closest(".amz-poz").classList.toggle("wyl", !c.checked); licz(); }));
  const licz = () => { $("amzWstaw").textContent = `Wstaw zaznaczone (${$$(".amz-poz input[type=checkbox]", box).filter((c) => c.checked).length})`; }; licz();
  $("amzZamknij").onclick = () => { box.hidden = true; box.innerHTML = ""; };
  $("amzWstaw").onclick = async () => {
    const wybrane = $$(".amz-poz", box).filter((el) => el.querySelector("input[type=checkbox]").checked).map((el) => {
      const x = JSON.parse(JSON.stringify(poz[+el.dataset.i])), t = el.querySelector("textarea");
      if (t) { if (x.rodzaj === "szablon") (x.pola = x.pola || {})[t.dataset.k] = t.value; else (x.parametry = x.parametry || {})[t.dataset.k] = t.value; }
      return { x, el };
    });
    $("amzWstaw").disabled = true;
    let ok = 0;
    for (let i = 0; i < wybrane.length; i++) {
      const { x, el } = wybrane[i];
      $("amzStan").textContent = `Renderuję i wstawiam ${i + 1} z ${wybrane.length}: ${amzOpis(x)}…`;
      try { await amzWstawJedna(x, z.folder); ok++; el.querySelector("input[type=checkbox]").checked = false; el.classList.add("wyl"); }
      catch (e) { alertBlad(`${amzCzas(x.czas_s)} ${amzOpis(x)}: ${e.message || e}`); }
    }
    $("amzStan").textContent = `Wstawione: ${ok} z ${wybrane.length}. Każdą kliknij na osi, a wróci tu do poprawek.`;
    $("amzWstaw").disabled = false; licz();
  };
}
async function amzWstawJedna(x, folderZad) {
  const folder = path.join(folderZad, "animacje"); fs.mkdirSync(folder, { recursive: true });
  const fps = stan.info ? stan.info.fps : 30;
  if (x.rodzaj === "szablon") {
    const sz = SZ && SZ.znajdz(x.szablon); if (!sz) throw new Error("nie ma takiego szablonu");
    const m = anMarka(), [W, H] = szRozmiar();
    const w = { pola: Object.assign({}, x.pola || {}), zdjecia: {}, plikiZdjec: {}, klipy: {}, ustawieniaZdjec: {},
      kolory: Object.assign({}, sz.kolory || {}, { tl: m.kolor_tla, t: m.kolor_tekstu, a: m.kolor_akcent, g: m.kolor_glowny }),
      fonty: { n: { rodzina: m.font, waga: m.waga, wymus: true }, t: { rodzina: m.font } }, czas: Math.max(1, +x.dlugosc_s || sz.czas), tempo: 1 };
    const plik = path.join(folder, `${sz.id}_${Date.now().toString(36).slice(-5)}.mp4`);
    const r = await renderKlatek((ctx, t) => SZ.rysuj(ctx, sz, t, w, W, H), W, H, fps, SZ.czas(sz, w), plik, null, null, { ogon: AN_ZAPAS_S, tStoi: Math.max(0, SZ.czas(sz, w) - 0.4) });
    const wpis = { typ: "szablon", szablon: sz.id, pola: w.pola, ust: {}, kolory: w.kolory, fonty: w.fonty, czas: w.czas, tempo: 1, pliki: {}, klipy: {}, plik: r.plik, kiedy: new Date().toISOString(), z_mowy: true };
    fs.writeFileSync(r.plik.replace(/\.mp4$/i, ".nada.json"), JSON.stringify(wpis, null, 1), "utf8");
    const wst = await jsx(`nm_wstaw(${q(r.plik)}, ${+x.czas_s || 0}, ${r.czas})`); if (!wst.ok) throw new Error(wst.blad);
    anZapiszRejestr(path.basename(r.plik), wpis); if (wst.nazwa) anZapiszRejestr(wst.nazwa, wpis); if (wst.idKlipu) anZapiszRejestr("id:" + wst.idKlipu, wpis);
    return;
  }
  const pr = A && A.znajdz(x.preset); if (!pr) throw new Error("nie ma takiego presetu: " + x.preset);
  const p = Object.assign({}, A.DOMYSLNE || {}, pr.dom || {}, pr.przyklad || {}, anMarka(), x.parametry || {});
  if (anStan.logoImg) p.logo = anStan.logoImg;
  if (pr.kat !== "przejscia" && x.dlugosc_s) p.czas = Math.max(0.5, +x.dlugosc_s);
  const start = pr.kat === "przejscia" ? Math.max(0, (+x.czas_s || 0) - A.czas(pr.id, p) / 2) : +x.czas_s || 0;
  const nazwa = `${pr.id}_${String(p.tekst || "").replace(/\*/g, "").replace(/[^\p{L}\p{N}]+/gu, "_").slice(0, 24)}_${Date.now().toString(36).slice(-4)}.mov`.replace(/__+/g, "_");
  const r = await anRenderuj(pr.id, p, path.join(folder, nazwa), null);
  const zapisane = Object.assign({}, p); delete zapisane.logo;
  const wpis = { typ: "animacja", preset: pr.id, parametry: zapisane, mov: r.plik, czas: r.czas, kiedy: new Date().toISOString(), z_mowy: true };
  fs.writeFileSync(r.plik.replace(/\.mov$/i, ".nada.json"), JSON.stringify(wpis, null, 1), "utf8");
  const w = await jsx(`nm_wstaw(${q(r.plik)}, ${start}, ${r.czas})`); if (!w.ok) throw new Error(w.blad);
  anZapiszRejestr(path.basename(r.plik), wpis); if (w.nazwa) anZapiszRejestr(w.nazwa, wpis); if (w.idKlipu) anZapiszRejestr("id:" + w.idKlipu, wpis);
}

async function wstawWynikiAnimacji(z) {
  if (z.tryb === "mowa" || fs.existsSync(path.join(z.folder, "plan_animacji.json"))) return amzPokazPlan(z);
  zaladujBiblioteke(); if (stan.widok === "animacje") { anKategorie(); anGaleria(); }
  const wst = czytajJson(path.join(z.folder, "wstawki.json"));
  const i = await odswiezInfo();
  const lista = Array.isArray(wst) && wst.length ? wst : (z.wideo || []).map((p) => ({ plik: p, czas_s: i.glowica || 0 }));
  for (const w of lista) {
    if (w.plik && !fs.existsSync(w.plik) && z.folder) w.plik = znajdzWFolderze(z.folder, path.basename(w.plik)) || w.plik;
    const r = await jsx(`nm_wstaw(${q(w.plik)}, ${Number(w.czas_s) || 0}, 5)`);
    if (!r.ok) { alertBlad(r.blad); break; }
  }
}

// ======================= KOLOR: LUT-y kamer, wyrównanie i klimat w Lumetri =======================
const KOL = { kamery: null, klimaty: null, hdr: null, luty: [], pozycje: {}, plan: null, nowe: [] };
const PLIK_POZYCJI = () => path.join(SILNIK, "narzedzia", "kolor", "luty_pozycje.json");
const kolEsc = (t) => String(t == null ? "" : t).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
async function kolStart() {
  try {
    if (!KOL.kamery) {
      const d = czytajJson(path.join(SILNIK, "narzedzia", "kolor", "kamery.json")) || { kamery: [] }, k = czytajJson(path.join(SILNIK, "narzedzia", "kolor", "klimaty.json")) || { klimaty: [] };
      KOL.kamery = d.kamery; KOL.klimaty = k.klimaty; KOL.hdr = k.hdr;
      $("kolKlimat").innerHTML = KOL.klimaty.map((x) => `<option value="${x.id}">${kolEsc(x.nazwa)}</option>`).join("");
      const u = wczytaj("nm-kolor", {});
      if (u.klimat) $("kolKlimat").value = u.klimat; if (u.sila != null) $("kolSila").value = u.sila; if (u.tryb) $("kolTryb").value = u.tryb; if (u.braw) $("kolBraw").value = u.braw;
      if (u.hdr != null) $("kolHdr").checked = u.hdr; if (u.wyrownaj != null) $("kolWyrownaj").checked = u.wyrownaj;
      suwak("kolSila", "", 2); $("kolSila").dispatchEvent(new Event("input"));
      $("kolHdrOpis").textContent = KOL.hdr ? KOL.hdr.opis + " " + KOL.hdr.eksport_hdr : "";
      kolOpisKlimatu();
    }
    KOL.pozycje = czytajJson(PLIK_POZYCJI()) || {};
    await kolOdswiezLuty();
  } catch (e) { alertBlad(e); }
}
function kolZapamietaj() { zapisz("nm-kolor", { klimat: $("kolKlimat").value, sila: $("kolSila").value, tryb: $("kolTryb").value, braw: $("kolBraw").value, hdr: $("kolHdr").checked, wyrownaj: $("kolWyrownaj").checked }); }
["kolKlimat", "kolSila", "kolTryb", "kolBraw", "kolHdr", "kolWyrownaj"].forEach((id) => $(id).addEventListener("change", () => { kolZapamietaj(); if (id === "kolKlimat") kolOpisKlimatu(); if (id === "kolHdr") $("kolHdrOpis").hidden = !$("kolHdr").checked; }));
function kolOpisKlimatu() { const k = (KOL.klimaty || []).find((x) => x.id === $("kolKlimat").value); $("kolKlimatOpis").textContent = k ? `${k.opis}${k.trend ? " Trend: " + k.trend + "." : ""}` : ""; $("kolHdrOpis").hidden = !$("kolHdr").checked; }
const kolKamera = (id) => (KOL.kamery || []).find((k) => k.id === id);
async function kolOdswiezLuty() {
  const r = await python("kolor.py", ["luty"]);
  KOL.luty = (r && r.luty) || [];
  $("kolLuty").innerHTML = KOL.luty.length ? KOL.luty.map((l) => { const k = kolKamera(l.kamera), pr = k && k.profile.find((p) => p.id === l.profil), poz = KOL.pozycje[l.id];
    return `<div class="amz-poz"><span></span><div class="gl"><b>${kolEsc(l.nazwa)}</b><span>${l.rodzaj === "kreatywny" ? "klimat (Wygląd)" : kolEsc((k ? k.nazwa : "?") + " · " + (pr ? pr.nazwa : l.profil || ""))}</span></div><small>${poz ? "pozycja w Lumetri: " + poz.indeks : "pozycja w Lumetri: nieustalona"} · <a href="#" data-usun-lut="${kolEsc(l.id)}">usuń</a></small></div>`; }).join("")
    : '<p class="uwaga">Nie masz jeszcze LUT-ów. Wgraj LUT-y producentów (np. Sony s3cine to 709, DJI D-Log M to Rec.709, Blackmagic Gen 5 Film to Video) albo swoje.</p>';
  $$("[data-usun-lut]", $("kolLuty")).forEach((a) => (a.onclick = async (e) => { e.preventDefault(); const w = await python("kolor.py", ["usun-lut", "--id", a.dataset.usunLut]); if (!w.ok) alertBlad(w.blad); await kolOdswiezLuty(); }));
  $("kolKalLut").innerHTML = KOL.luty.map((l) => `<option value="${kolEsc(l.id)}">${kolEsc(l.nazwa)}</option>`).join("");
  const l0 = KOL.luty[0]; if (l0 && KOL.pozycje[l0.id]) $("kolKalIdx").value = KOL.pozycje[l0.id].indeks;
}
/* zgadywanie kamery i profilu z nazwy pliku LUT-a */
function kolZgadnij(nazwa) {
  const n = nazwa.toLowerCase().replace(/[_\-.]+/g, " ");
  let kamera = "inna", profil = "log", rodzaj = "techniczny";
  if (/fx30/.test(n)) kamera = "fx30"; else if (/fx3|a7s|a7 ?iv|a7m4|sony|s ?log|s3cine|sgamut/.test(n)) kamera = /fx30/.test(n) ? "fx30" : "fx30";
  if (/fx3\b|a7s|a7 ?iv|a7m4/.test(n)) kamera = "sony-fx3-a7";
  if (/pocket|bmpcc|blackmagic|bmd|gen ?5|braw/.test(n)) kamera = /4k/.test(n) && !/6k/.test(n) ? "bmpcc4k" : /g2/.test(n) ? "bmpcc6kg2" : "bmpcc6kpro";
  if (/dji|d ?log|mavic|mini ?4|air ?3|avata/.test(n)) kamera = /osmo|pocket ?3|action/.test(n) ? "dji-osmo" : "dji-dron";
  if (/iphone|apple ?log/.test(n)) kamera = "iphone";
  if (/gopro|gp ?log/.test(n)) kamera = "gopro";
  const k = kolKamera(kamera) || kolKamera("inna");
  if (/s ?log ?3|slog3|s3cine/.test(n)) profil = /sgamut3(?!cine)|s ?gamut ?3(?! ?cine)/.test(n) && !/cine/.test(n) ? "sgamut3" : "slog3";
  else if (/s ?log ?2/.test(n)) profil = "slog2";
  else if (/d ?log ?m|dlogm/.test(n)) profil = "dlogm";
  else if (/d ?log/.test(n)) profil = "dlog";
  else if (/gen ?5|film/.test(n) && /bmpcc/.test(kamera)) profil = "bmd-film-gen5";
  else if (/apple ?log/.test(n)) profil = "applelog";
  else if (/hlg/.test(n)) profil = "hlg";
  if (!k.profile.some((p) => p.id === profil)) profil = (k.profile.find((p) => p.domyslny) || k.profile[0]).id;
  if (!/709|rec|to |video|lut|log/.test(n) || /look|teal|orange|cinematic|kodak|film emul|moody|vintage/.test(n)) rodzaj = /709|to video/.test(n) ? "techniczny" : "kreatywny";
  return { kamera, profil, rodzaj };
}
function kolOpcjeKamer(wyb) { return (KOL.kamery || []).map((k) => `<option value="${k.id}"${k.id === wyb ? " selected" : ""}>${kolEsc(k.nazwa)}</option>`).join(""); }
function kolOpcjeProfili(kam, wyb) { const k = kolKamera(kam) || kolKamera("inna"); return k.profile.map((p) => `<option value="${p.id}"${p.id === wyb ? " selected" : ""}>${kolEsc(p.nazwa)}</option>`).join(""); }
$("kolWgraj").onclick = () => {
  let pliki = [];
  try { const r = window.cep && window.cep.fs && window.cep.fs.showOpenDialogEx ? window.cep.fs.showOpenDialogEx(true, false, "Wybierz LUT-y (.cube)", "", ["cube", "3dl"]) : window.cep.fs.showOpenDialog(true, false, "Wybierz LUT-y (.cube)", "", ["cube", "3dl"]); pliki = (r && r.data) || []; } catch (e) { alertBlad("Nie mogę otworzyć okna wyboru plików: " + e.message); return; }
  if (!pliki.length) return;
  KOL.nowe = pliki.map((p) => Object.assign({ plik: p }, kolZgadnij(path.basename(p))));
  const box = $("kolNowe");
  box.innerHTML = `<p class="uwaga">Sprawdź, do jakiej kamery i profilu pasuje każdy LUT (zgadłem z nazwy). „Klimat” = LUT kreatywny (lista Wygląd w Lumetri).</p>` + KOL.nowe.map((x, i) => `<div class="amz-poz" data-i="${i}"><span></span><div class="gl"><b>${kolEsc(path.basename(x.plik))}</b></div>
      <div class="siatka2" style="grid-column:2"><select data-k="rodzaj"><option value="techniczny"${x.rodzaj === "techniczny" ? " selected" : ""}>Techniczny (log → Rec.709)</option><option value="kreatywny"${x.rodzaj === "kreatywny" ? " selected" : ""}>Klimat (kreatywny)</option></select>
      <select data-k="kamera">${kolOpcjeKamer(x.kamera)}</select><select data-k="profil">${kolOpcjeProfili(x.kamera, x.profil)}</select></div></div>`).join("") + `<button class="glowny" id="kolDodaj">Dodaj ${KOL.nowe.length} do biblioteki</button>`;
  $$(".amz-poz", box).forEach((el) => {
    const x = KOL.nowe[+el.dataset.i];
    $$("select", el).forEach((sel) => (sel.onchange = () => { x[sel.dataset.k] = sel.value; if (sel.dataset.k === "kamera") { x.profil = (kolKamera(x.kamera).profile.find((p) => p.domyslny) || kolKamera(x.kamera).profile[0]).id; el.querySelector('[data-k="profil"]').innerHTML = kolOpcjeProfili(x.kamera, x.profil); } }));
  });
  $("kolDodaj").onclick = async () => {
    $("kolDodaj").disabled = true;
    for (const x of KOL.nowe) { const r = await python("kolor.py", ["dodaj-lut", "--plik", x.plik, "--kamera", x.kamera, "--profil", x.profil, "--rodzaj", x.rodzaj]); if (!r.ok) alertBlad(r.blad); }
    box.innerHTML = '<p class="uwaga">Dodane. Kliknij „Zainstaluj w Premiere”, zamknij i otwórz Premiere, a potem ustal pozycje LUT-ów.</p>';
    await kolOdswiezLuty();
  };
};
$("kolInstaluj").onclick = async () => { const r = await python("kolor.py", ["instaluj-luty"]); if (!r.ok) return alertBlad(r.blad); log(`LUT-y w Premiere: ${r.zainstalowane.length}. ${r.uwaga}`); $("kolKalInfo").textContent = r.uwaga; };
// ustalanie pozycji LUT-a na liście Lumetri (skrypt nie może wskazać pliku, tylko pozycję)
$("kolKalLut").onchange = () => { const p = KOL.pozycje[$("kolKalLut").value]; if (p) $("kolKalIdx").value = p.indeks; };
const kolKalRodzaj = () => { const l = KOL.luty.find((x) => x.id === $("kolKalLut").value); return l && l.rodzaj === "kreatywny" ? "look" : "lut"; };
async function kolPrzymierz() { const r = await jsx(`nm_lut_probuj(${+$("kolKalIdx").value || 0}, ${q(kolKalRodzaj())})`); $("kolKalInfo").textContent = r.ok ? `Ustawiłem pozycję ${$("kolKalIdx").value} na klipie „${r.klip}”. Sprawdź w Lumetri, który LUT się wybrał.` : "Nie wyszło: " + (r.blad || ""); }
$("kolKalProbuj").onclick = kolPrzymierz;
$("kolKalPlus").onclick = () => { $("kolKalIdx").value = (+$("kolKalIdx").value || 0) + 1; kolPrzymierz(); };
$("kolKalMinus").onclick = () => { $("kolKalIdx").value = Math.max(0, (+$("kolKalIdx").value || 0) - 1); kolPrzymierz(); };
$("kolKalOk").onclick = async () => {
  const id = $("kolKalLut").value; if (!id) return;
  KOL.pozycje[id] = { indeks: +$("kolKalIdx").value || 0, rodzaj: kolKalRodzaj(), kiedy: new Date().toISOString() };
  fs.writeFileSync(PLIK_POZYCJI(), JSON.stringify(KOL.pozycje, null, 1), "utf8");
  $("kolKalInfo").textContent = "Zapamiętane. Następnym razem panel sam wybierze ten LUT."; await kolOdswiezLuty();
};
/* klipy z osi: tylko prawdziwe nagrania (bez animacji i napisów z panelu, bez grafik) */
async function kolKlipy() {
  const r = await jsx("nm_klipy_osi()"); if (!r.ok) throw new Error(r.blad);
  const proksy = { foldery: (wczytaj("nm-proksy", "D:\\PROXY PREMIER") || "").split(/\r?\n/).map((x) => x.trim()).filter(Boolean), mapa: {} };
  try { const p = await jsx("nm_proksy()"); if (p.ok) p.pliki.forEach((x) => { if (x.proksy) proksy.mapa[x.plik] = x.proksy; }); } catch (e) {}
  const klipy = r.klipy.filter((c) => !c.wylaczony && c.sciezka && /\.(braw|r3d|mp4|mov|mxf|m4v|mts|avi|mkv)$/i.test(c.sciezka) && !wpisZKlipu({ nazwa: c.nazwa, sciezka: c.sciezka }) && !/[\\/]wyniki[\\/]/i.test(c.sciezka))
    .map((c) => ({ plik: c.sciezka, start: c.start, end: c.end, tor: c.tor - 1, nazwa: c.nazwa, od: c.od || 0, lumetri: !!c.lumetri }));
  return { klipy, proksy };
}
/* Klatki z osi (kopia sekwencji): każda ścieżka po kolei, inne ścieżki ukryte do czasu zapisania klatek. */
async function kolKadry(klipy, folder, sekwencja) {
  const dir = path.join(folder, "klatki_z_osi");
  try { fs.rmSync(dir, { recursive: true, force: true }); } catch (e) {}
  fs.mkdirSync(dir, { recursive: true });
  const poTorach = {};
  klipy.forEach((c, i) => {
    c.kadry = [0.3, 0.7].map((f, k) => path.join(dir, `k${String(i).padStart(4, "0")}_${k}.png`));
    (poTorach[c.tor] = poTorach[c.tor] || []).push(...c.kadry.map((p, k) => ({ t: c.start + (c.end - c.start) * [0.3, 0.7][k], plik: p })));
  });
  const jest = (p) => fs.existsSync(p) || fs.existsSync(p + ".png");
  let ok = 0;
  try {
    for (const tor of Object.keys(poTorach)) {
      const lista = poTorach[tor];
      const w = await jsx(`nm_klatki_osi(${JSON.stringify({ sekwencja, tor: +tor, lista })})`);
      if (!w.ok) { log("Klatki z osi: " + w.blad, "e"); break; }
      const t0 = Date.now();
      while (Date.now() - t0 < 4000 + lista.length * 1500 && !lista.every((x) => jest(x.plik))) await czekaj(300);
      ok += lista.filter((x) => jest(x.plik)).length;
    }
  } finally { await jsx("nm_klatki_osi_koniec()"); }
  klipy.forEach((c) => { c.kadry = c.kadry.map((p) => (fs.existsSync(p) ? p : fs.existsSync(p + ".png") ? p + ".png" : null)).filter(Boolean); });
  return ok;
}
async function kolPlan(zmierz, gotowe) {
  const { klipy, proksy } = gotowe || await kolKlipy();
  if (!klipy.length) throw new Error("Na osi nie widzę nagrań (pliki wideo z kamer).");
  const folder = path.join(SYS("panel"), "kolor"); fs.mkdirSync(folder, { recursive: true });
  const przyp = Object.assign({}, KOL.przypisania || {});
  const we = { klipy, proksy, klimat: $("kolKlimat").value, sila: +$("kolSila").value, hdr: $("kolHdr").checked, wyrownaj: zmierz && $("kolWyrownaj").checked, wzor: $("kolWzor").value, przypisania: przyp, braw_kamera: $("kolBraw").value };
  fs.writeFileSync(path.join(folder, "wejscie.json"), JSON.stringify(we, null, 1), "utf8");
  const r = await python("kolor.py", ["plan", "--dane", path.join(folder, "wejscie.json"), "--wyjscie", path.join(folder, "plan.json")]);
  if (!r.ok) throw new Error(r.blad);
  KOL.plan = czytajJson(path.join(folder, "plan.json"));
  return KOL.plan;
}
function kolRysujGrupy() {
  const g = (KOL.plan && KOL.plan.grupy) || [];
  $("kolWzor").innerHTML = '<option value="">Kamera z największą liczbą ujęć</option>' + [...new Set(g.map((x) => x.kamera))].map((k) => `<option value="${k}">${kolEsc((kolKamera(k) || {}).nazwa || k)}</option>`).join("");
  $("kolGrupy").innerHTML = g.map((x, i) => { const k = kolKamera(x.kamera) || {}, techn = KOL.luty.filter((l) => l.rodzaj !== "kreatywny"), wyb = (KOL.przypisania || {})[`${x.kamera}|${x.profil}`] !== undefined ? KOL.przypisania[`${x.kamera}|${x.profil}`] : x.lut;
    return `<div class="amz-poz" data-g="${i}"><span></span><div class="gl"><b>${kolEsc(x.kamera_nazwa)}</b><span>${kolEsc(x.profil_nazwa)} · ${x.klipow} ${x.klipow === 1 ? "ujęcie" : "ujęć"}${x.iso.length ? " · ISO " + x.iso.join(", ") : ""}${k.natywne_iso && k.natywne_iso.length ? " (natywne " + k.natywne_iso.join(" / ") + ")" : ""}</span></div>
      <select style="grid-column:2" data-lut><option value="">bez LUT-a</option>${techn.map((l) => `<option value="${kolEsc(l.id)}"${l.id === wyb ? " selected" : ""}>${kolEsc(l.nazwa)}${l.kamera === x.kamera ? "" : " (inna kamera)"}${KOL.pozycje[l.id] ? "" : " · pozycja nieustalona"}</option>`).join("")}</select>
      ${x.uwagi.length ? `<small>⚠ ${kolEsc(x.uwagi.join(" "))}</small>` : ""}${(k.porady || []).length ? `<small>${kolEsc(k.porady[0])}</small>` : ""}</div>`; }).join("");
  $$("[data-g]", $("kolGrupy")).forEach((el) => { const x = g[+el.dataset.g]; el.querySelector("[data-lut]").onchange = (e) => { KOL.przypisania = Object.assign({}, KOL.przypisania || {}, { [`${x.kamera}|${x.profil}`]: e.target.value || null }); }; });
}
$("kolSkanuj").onclick = async () => {
  $("kolSkanuj").disabled = true; $("kolSkanuj").textContent = "Skanuję…";
  try { await kolStart(); await kolPlan(false); kolRysujGrupy(); } catch (e) { alertBlad(e); }
  $("kolSkanuj").disabled = false; $("kolSkanuj").textContent = "Skanuj oś: kamery i profile";
};
$("kolZastosuj").onclick = async () => {
  const b = $("kolZastosuj"); b.disabled = true; b.textContent = "Mierzę i wyrównuję ujęcia…";
  try {
    await kolStart();
    // zawsze kopia sekwencji: pomiar i kolor robimy na niej, oryginał zostaje bez zmian
    const k = await jsx(`nm_kopia_sekwencji("kolor")`); if (!k.ok) throw new Error(k.blad);
    log(`Kolor: pracuję na kopii „${k.nazwa}”, oryginał zostaje bez zmian.`);
    const dane = await kolKlipy();
    if ($("kolWyrownaj").checked && dane.klipy.length) {
      b.textContent = "Biorę klatki z osi…";
      const n = await kolKadry(dane.klipy, path.join(SYS("panel"), "kolor"), k.nazwa);
      log(n ? `Pomiar z ${n} klatek osi (tak, jak wyglądają w Premiere).` : "Premiere nie oddał klatek z osi: mierzę z plików nagrań, w miejscach użytych na osi.", n ? "" : "e");
      b.textContent = "Mierzę i wyrównuję ujęcia…";
    }
    const plan = await kolPlan(true, dane); kolRysujGrupy();
    const tryb = $("kolTryb").value;
    const zLumetri = plan.klipy.filter((c) => c.lumetri).length;
    if (zLumetri) log(`${zLumetri} ujęć ma już Twój Lumetri: dostają nowy Lumetri nad Twoim, bez drugiego LUT-a.`);
    const lumKlimat = plan.lumetri_klimat || {}, kl = plan.klarownosc;
    const suma = (a, b) => { const w = Object.assign({}, a); Object.entries(b || {}).forEach(([k, v]) => { if (typeof v === "number") w[k] = Math.round(((+w[k] || 0) + v) * 100) / 100; }); return w; };
    const lista = [];
    let bezPozycji = 0;
    for (const c of plan.klipy) {
      const poz = c.lut && KOL.pozycje[c.lut]; if (c.lut && !poz) bezPozycji++;
      const tylkoTechniczne = tryb === "mix";
      lista.push({ tor: c.tor, start: c.start, end: c.end, warstwa: tryb === "warstwy", nowy_lumetri: !!c.lumetri,
        parametry: tylkoTechniczne ? Object.assign({}, c.korekta || {}) : suma(lumKlimat, c.korekta), lut_indeks: poz ? poz.indeks : null, klarownosc: tylkoTechniczne ? null : kl });
    }
    if (tryb === "mix") {
      const od = Math.min(...plan.klipy.map((c) => c.start)), doo = Math.max(...plan.klipy.map((c) => c.end));
      lista.push({ tor: 0, start: od, end: doo, warstwa: true, nowy_lumetri: true, parametry: lumKlimat, klarownosc: kl });
    }
    b.textContent = "Nakładam w Premiere…";
    const r = await jsx(`nm_kolor_zastosuj(${JSON.stringify(lista)}, "Nada Kolor")`);
    if (!r.ok) throw new Error(r.blad);
    const ok = r.wyniki.filter((x) => x.ok).length;
    $("kolWynik").innerHTML = `<p class="uwaga"><b>Gotowe: ${ok} z ${r.wyniki.length}.</b> Klimat: ${kolEsc(plan.klimat_nazwa)}${plan.wzor ? ", wzór: " + kolEsc((kolKamera(plan.wzor) || {}).nazwa || plan.wzor) : ""}. Każdą wartość poprawisz w Lumetri.</p>` +
      (bezPozycji ? `<p class="uwaga">⚠ ${bezPozycji} ujęć ma LUT bez ustalonej pozycji w Lumetri: wybierz go tam ręcznie (Wejściowa LUT) albo ustal pozycję w „Moje LUT-y”.</p>` : "") +
      (plan.hdr_uwaga ? `<p class="uwaga">${kolEsc(plan.hdr_uwaga)}</p>` : "") + (r.uwagi && r.uwagi.length ? `<details><summary>Uwagi (${r.uwagi.length})</summary><p class="uwaga">${r.uwagi.map(kolEsc).join("<br>")}</p></details>` : "");
    fs.writeFileSync(path.join(SYS("panel"), "kolor", "ostatnie.json"), JSON.stringify({ lista, wynik: r }, null, 1), "utf8");
  } catch (e) { alertBlad(e); }
  b.disabled = false; b.textContent = "Zastosuj kolor";
};
$("kolDiag").onclick = async () => {
  const r = await jsx("nm_lumetri_parametry()");
  fs.mkdirSync(path.join(SYS("panel")), { recursive: true });
  fs.writeFileSync(path.join(SYS("panel"), "lumetri_parametry.json"), JSON.stringify(r, null, 1), "utf8");
  log(r.ok ? `Zapisane nazwy ${r.parametry.length} parametrów Lumetri z klipu „${r.klip}” (_system/panel/lumetri_parametry.json).` : r.blad);
};

// ======================= SZABLONY ROLEK =======================
let SZ = null;
const szStan = { kat: "edytorskie", id: null, pola: {}, zdjecia: {}, pliki: {}, klipy: {}, ust: {}, miniatury: {}, raf: 0, t0: performance.now(), gra: true, t: 0, moje: [] };
const SZ_FOLDER = () => path.join(SILNIK, "narzedzia", "szablony");
const PLIK_MOICH_SZ = () => path.join(SZ_FOLDER(), "moje_szablony.json");
function zaladujSzablony() {
  const plik = path.join(SZ_FOLDER(), "szablony.js");
  try {
    delete NODE_REQ.cache[NODE_REQ.resolve(plik)];
    SZ = NODE_REQ(plik);
    window.NMSzablony = SZ; global.NMSzablony = SZ;
    SZ.ustawFabryke((w, h) => { const c = document.createElement("canvas"); c.width = w; c.height = h; return c; });
    const wl = path.join(SZ_FOLDER(), "wlasne");
    if (fs.existsSync(wl)) fs.readdirSync(wl).filter((f) => f.endsWith(".js")).sort().forEach((f) => {
      const p = path.join(wl, f); try { delete NODE_REQ.cache[NODE_REQ.resolve(p)]; NODE_REQ(p); } catch (e) { console.log("Błąd szablonu", f, e); }
    });
  } catch (e) { SZ = null; console.log(e); }
  szStan.moje = czytajJson(PLIK_MOICH_SZ()) || [];
}
function wczytajObraz(p) {
  return new Promise((ok, zle) => {
    try {
      const b = fs.readFileSync(p), img = new Image();
      img.onload = () => ok(img); img.onerror = () => zle(new Error("Nie mogę otworzyć obrazu " + path.basename(p)));
      img.src = URL.createObjectURL(new Blob([b]));
    } catch (e) { zle(e); }
  });
}
const SZ_KOLORY = ["tl", "t", "a", "g", "d"];
function szFontZPola(fId, wId, dom) {
  const f = { rodzina: $(fId).value.trim() || dom }, w = $(wId).value;
  if (w) { f.waga = parseInt(w, 10); f.kursywa = /i$/.test(w); f.wymus = true; }
  return f;
}
function szKolory() { const k = {}; SZ_KOLORY.forEach((x) => (k[x] = $("sz_" + x).value)); return k; }
function szUstawKolory(k) { SZ_KOLORY.forEach((x) => { if (k && k[x]) $("sz_" + x).value = String(k[x]).toLowerCase(); }); }
function szWartosci() {
  return { pola: szStan.pola, zdjecia: szStan.zdjecia, plikiZdjec: szStan.pliki, klipy: szStan.klipy, ustawieniaZdjec: szStan.ust, kolory: szKolory(),
    fonty: { n: szFontZPola("sz_fn", "sz_wn", "Oswald"), t: szFontZPola("sz_ft", "sz_wt", "Montserrat") },
    czas: +$("sz_czas").value, tempo: +$("sz_tempo").value };
}
function szKategorie() {
  const kat = SZ.KATEGORIE.filter((k) => SZ.SZABLONY.some((s) => s.kat === k.id)).concat(szStan.moje.length ? [{ id: "moje", nazwa: "Moje ☆" }] : []);
  $("szKategorie").innerHTML = kat.map((k) => `<button data-k="${k.id}" aria-pressed="${k.id === szStan.kat}">${k.nazwa} <span style="color:#777">${k.id === "moje" ? szStan.moje.length : SZ.SZABLONY.filter((s) => s.kat === k.id).length}</span></button>`).join("");
  $$("button", $("szKategorie")).forEach((b) => (b.onclick = () => { szStan.kat = b.dataset.k; zapisz("nm-sz-kat", szStan.kat); szKategorie(); szGaleria(); }));
}
function szMini(c, sz, t, wart) { const x = c.getContext("2d"); x.clearRect(0, 0, c.width, c.height); try { SZ.rysuj(x, sz, t, wart || {}, c.width, c.height); } catch (e) {} }
function szGaleria() {
  const lista = szStan.kat === "moje" ? szStan.moje.map((m) => ({ sz: SZ.znajdz(m.szablon), moj: m })).filter((x) => x.sz) : SZ.SZABLONY.filter((s) => s.kat === szStan.kat).map((sz) => ({ sz }));
  $("szGaleria").innerHTML = lista.map((x, i) => `<div class="karta" role="button" tabindex="0" data-i="${i}" title="${x.sz.nazwa.replace(/"/g, "")}" aria-pressed="${x.sz.id === szStan.id}"><canvas width="108" height="192" style="aspect-ratio:9/16"></canvas><span>${(x.moj ? x.moj.nazwa : x.sz.nazwa).replace(/</g, "")}</span></div>`).join("");
  $$(".karta", $("szGaleria")).forEach((k) => {
    const x = lista[+k.dataset.i], c = k.querySelector("canvas"), T = x.sz.czas, stop = Math.min(T - 0.8, 3.2);
    const wart = x.moj ? { pola: x.moj.pola, kolory: x.moj.kolory, fonty: x.moj.fonty } : {};
    szMini(c, x.sz, stop, wart);
    let raf = 0;
    k.onmouseenter = () => { const t0 = performance.now(); const kl = () => { szMini(c, x.sz, ((performance.now() - t0) / 1000) % (T + 0.3), wart); raf = requestAnimationFrame(kl); }; kl(); };
    k.onmouseleave = () => { cancelAnimationFrame(raf); szMini(c, x.sz, stop, wart); };
    k.onclick = () => szWybierz(x.sz.id, x.moj);
  });
}
function szWybierz(id, moj) {
  const sz = SZ.znajdz(id); if (!sz) return;
  szStan.id = id;
  szStan.pola = moj ? Object.assign({}, moj.pola) : {};
  szStan.ust = moj ? JSON.parse(JSON.stringify(moj.ust || {})) : {};
  // zdjęcia zostają między szablonami, jeśli pole ma tę samą nazwę (z1, z2...): wygodne przy przeglądaniu
  szUstawKolory(moj && moj.kolory ? moj.kolory : sz.kolory);
  if (!moj) szMarkaKlienta(true);
  if (moj && moj.fonty) {
    $("sz_fn").value = moj.fonty.n.rodzina; $("sz_ft").value = moj.fonty.t.rodzina;
    wypelnijWarianty($("sz_wn"), moj.fonty.n.wymus ? moj.fonty.n.waga + (moj.fonty.n.kursywa ? "i" : "") : "");
    wypelnijWarianty($("sz_wt"), moj.fonty.t.wymus ? moj.fonty.t.waga + (moj.fonty.t.kursywa ? "i" : "") : "");
  }
  $("sz_czas").value = moj && moj.czas ? moj.czas : sz.czas; $("sz_czas").dispatchEvent(new Event("input"));
  $("sz_tempo").value = moj && moj.tempo ? moj.tempo : 1; $("sz_tempo").dispatchEvent(new Event("input"));
  if (moj && moj.pliki) Object.entries(moj.pliki).forEach(([pole, p]) => p && fs.existsSync(p) && szUstawZdjecie(pole, p));
  if (moj && moj.klipy) Object.entries(moj.klipy).forEach(([pole, k]) => k && fs.existsSync(k.plik) && szUstawKlip(pole, k));
  $("szNazwa").textContent = sz.nazwa;
  szRysujPola(sz);
  $$(".karta", $("szGaleria")).forEach((k) => k.setAttribute("aria-pressed", String(k.title === sz.nazwa)));
  zapisz("nm-sz-id", id);
  szRestart();
}
function szUsunMedia(pole) {
  const v = szStan.zdjecia[pole];
  if (v && v.tagName === "VIDEO") { try { v.pause(); v.removeAttribute("src"); v.load(); } catch (e) {} }
  delete szStan.zdjecia[pole]; delete szStan.pliki[pole]; delete szStan.miniatury[pole]; delete szStan.klipy[pole];
}
async function szZaznaczoneKlipy() {
  if (HOST !== "PPRO") return [];
  const z = await jsx("nm_zaznaczone()");
  if (!z.ok) return [];
  return (z.klipy || []).filter((k) => k.tor >= 0 && k.sciezka && /\.(mp4|mov|m4v|mxf|avi|mts|webm|braw|r3d|mkv)$/i.test(k.sciezka))
    .sort((a, b) => a.start - b.start || a.tor - b.tor).map((k) => ({ plik: k.sciezka, od: k.od || 0, dl: Math.max(0.1, k.end - k.start), nazwa: k.nazwa, start: k.start, end: k.end, tor: k.tor, idKlipu: k.idKlipu }));
}
/* Klip z osi w miejscu zdjęcia: w podglądzie gra ten sam fragment, w After Effects trafia do osobnej kompozycji. */
function szUstawKlip(pole, klip) {
  szUsunMedia(pole);
  szStan.klipy[pole] = klip;
  const v = document.createElement("video");
  v.muted = true; v.playsInline = true; v.preload = "auto"; v.loop = false;
  const m = () => document.querySelector(`.szfoto[data-pole="${pole}"] .min`);
  v.onloadeddata = () => {
    try { v.currentTime = klip.od || 0; } catch (e) {}
    szStan.zdjecia[pole] = v;
    if (!klip.dl) klip.dl = Math.max(0.1, (v.duration || 5) - (klip.od || 0));
    v.play().catch(() => {});
    setTimeout(() => {
      try { const c = document.createElement("canvas"); c.width = 96; c.height = 96; const x = c.getContext("2d"); const k = Math.max(96 / v.videoWidth, 96 / v.videoHeight); x.drawImage(v, 48 - v.videoWidth * k / 2, 48 - v.videoHeight * k / 2, v.videoWidth * k, v.videoHeight * k); szStan.miniatury[pole] = c.toDataURL(); const el = m(); if (el) { el.style.backgroundImage = `url("${szStan.miniatury[pole]}")`; el.textContent = "▶"; } } catch (e) {}
    }, 400);
    szRestart();
  };
  v.ontimeupdate = () => { if (klip.dl && v.currentTime > (klip.od || 0) + klip.dl) { try { v.currentTime = klip.od || 0; } catch (e) {} } };
  v.onerror = async () => {
    // tego formatu podgląd nie odtworzy (np. RAW): w podglądzie zostaje kadr z Premiere, w After Effects i tak będzie prawdziwy klip
    if (HOST === "PPRO" && klip.start != null) {
      const cel = path.join(NODE_REQ("os").tmpdir(), `nm_kadr_${pole}_${Date.now()}.png`), r = await jsx(`nm_klatka(${q(cel)})`);
      if (r.ok) { try { const img = await wczytajObraz(r.plik); szStan.zdjecia[pole] = img; szStan.miniatury[pole] = img.src; const el = m(); if (el) { el.style.backgroundImage = `url("${img.src}")`; el.textContent = "▶"; } } catch (e) {} }
    }
  };
  v.src = URL_PLIKU(klip.plik);
  const el = m(); if (el) el.textContent = "▶";
  $("szStan").textContent = `Klip „${klip.nazwa}” (${klip.dl ? klip.dl.toFixed(1) + " s" : ""}) jest w polu „${(SZ.znajdz(szStan.id).pola.find((x) => x.id === pole) || {}).etykieta || pole}”.`;
}
/* Ustawia klipy wideo na zadany czas szablonu (render bez After Effects). */
async function szPrzewinKlipy(t) {
  const czeka = [];
  Object.entries(szStan.klipy).forEach(([pole, k]) => {
    const v = szStan.zdjecia[pole];
    if (!v || v.tagName !== "VIDEO") return;
    const cel = (k.od || 0) + Math.min(Math.max(0, t), Math.max(0, (k.dl || 1) - 0.04));
    czeka.push(new Promise((ok) => { const gotowe = () => { v.removeEventListener("seeked", gotowe); ok(); }; v.addEventListener("seeked", gotowe); setTimeout(gotowe, 1500); try { v.currentTime = cel; } catch (e) { ok(); } }));
  });
  await Promise.all(czeka);
}
async function szUstawZdjecie(pole, plik) {
  try {
    const img = await wczytajObraz(plik);
    szUsunMedia(pole);
    szStan.zdjecia[pole] = img; szStan.pliki[pole] = plik; szStan.miniatury[pole] = img.src;
    const m = document.querySelector(`.szfoto[data-pole="${pole}"] .min`); if (m) m.style.backgroundImage = `url("${img.src}")`;
    szRestart();
  } catch (e) { alertBlad(e); }
}
function szRysujPola(sz) {
  const zd = (sz.pola || []).filter((p) => p.typ === "zdjecie"), tx = (sz.pola || []).filter((p) => p.typ !== "zdjecie");
  const us = (pole) => szStan.ust[pole] || (szStan.ust[pole] = {});
  $("szZdjecia").innerHTML = zd.length ? zd.map((p) => `<div class="szfoto" data-pole="${p.id}">
      <div class="min" style="${szStan.miniatury[p.id] ? `background-image:url('${szStan.miniatury[p.id]}')` : ""}">${szStan.klipy[p.id] ? "▶" : ""}</div>
      <div><b>${p.etykieta}</b><div class="akcje">
        <label class="maly" style="display:inline-block">Zdjęcie…<input type="file" accept="image/*,video/*" hidden></label>
        ${HOST === "PPRO" ? '<button class="maly akc" data-a="klip" title="Wstaw w to miejsce klip zaznaczony na osi (film, nie zdjęcie)">Zaznaczony klip</button>' : ""}
        <button class="maly" data-a="usun" title="Wróć do zdjęcia zastępczego">×</button></div></div>
      <details><summary>Kadrowanie i wygląd</summary><div class="blok">
        <div class="w"><label>Powiększenie</label><output data-o="skala"></output><input type="range" data-u="skala" min="0.5" max="3" step="0.05" value="${us(p.id).skala || 1}"></div>
        <div class="siatka2"><div class="w"><label>W lewo / prawo</label><output data-o="x"></output><input type="range" data-u="x" min="-1" max="1" step="0.02" value="${us(p.id).x || 0}"></div>
        <div class="w"><label>W górę / dół</label><output data-o="y"></output><input type="range" data-u="y" min="-1" max="1" step="0.02" value="${us(p.id).y || 0}"></div></div>
        <div class="siatka2"><div class="w"><span>Kolor</span><span></span><select data-u="bw"><option value="">Jak w szablonie</option><option value="tak">Czarno-białe</option><option value="nie">Kolorowe</option></select></div>
        <div class="w"><span>Ruch zdjęcia</span><span></span><select data-u="ruch"><option value="">Jak w szablonie</option><option value="brak">Bez ruchu</option><option value="oddal">Powolne przybliżanie</option></select></div></div>
      </div></details></div>`).join("") : '<p class="uwaga">Ten szablon nie ma zdjęć.</p>';
  $$(".szfoto", $("szZdjecia")).forEach((w) => {
    const pole = w.dataset.pole, u = us(pole);
    w.querySelector('input[type="file"]').onchange = (e) => {
      const f = e.target.files[0]; if (!f || !f.path) return;
      if (/^video\//.test(f.type) || /\.(mp4|mov|m4v|webm|mxf|avi)$/i.test(f.path)) szUstawKlip(pole, { plik: f.path, od: 0, dl: 0, nazwa: path.basename(f.path) });
      else szUstawZdjecie(pole, f.path);
    };
    const kl = w.querySelector('[data-a="klip"]');
    if (kl) kl.onclick = async () => {
      const k = await szZaznaczoneKlipy();
      if (!k.length) { alertBlad("Zaznacz na osi klip wideo (kliknij go) i kliknij jeszcze raz."); return; }
      const zajete = new Set(Object.values(szStan.klipy).map((x) => x.idKlipu));
      szUstawKlip(pole, k.find((x) => !zajete.has(x.idKlipu)) || k[0]);
    };
    w.querySelector('[data-a="usun"]').onclick = () => { szUsunMedia(pole); w.querySelector(".min").style.backgroundImage = ""; w.querySelector(".min").textContent = ""; szRestart(); };
    $$("[data-u]", w).forEach((el) => {
      const k = el.dataset.u, o = w.querySelector(`[data-o="${k}"]`);
      if (el.tagName === "SELECT") el.value = u[k] === true ? "tak" : u[k] === false ? "nie" : (u[k] || "");
      const pokazW = () => o && (o.textContent = (+el.value).toFixed(2));
      pokazW();
      el.oninput = el.onchange = () => {
        if (k === "bw") u.bw = el.value === "tak" ? true : el.value === "nie" ? false : undefined;
        else if (k === "ruch") u.ruch = el.value || undefined;
        else u[k] = +el.value;
        pokazW(); szStan.gra = false; szStan.t = Math.min(SZ.czas(szStan.id, szWartosci()) - 0.6, 3); $("szGraj").textContent = "▶";
      };
    });
  });
  $("szTeksty").innerHTML = tx.map((p) => {
    const v = szStan.pola[p.id] != null ? szStan.pola[p.id] : p.dom;
    return `<div class="w"><span>${p.etykieta}</span><span></span><textarea class="tekst" data-p="${p.id}" rows="${Math.max(2, p.wiersze || 2)}">${String(v).replace(/</g, "&lt;")}</textarea></div>`;
  }).join("") || '<p class="uwaga">Ten szablon nie ma tekstów.</p>';
  $$("[data-p]", $("szTeksty")).forEach((el) => (el.oninput = () => { szStan.pola[el.dataset.p] = el.value; }));
}
function szRestart() { szStan.t0 = performance.now(); szStan.gra = true; $("szGraj").textContent = "❚❚"; }
function szKlatka() {
  if (SZ && szStan.id && SZ.znajdz(szStan.id)) {
    const w = szWartosci(), T = SZ.czas(szStan.id, w), c = $("szPodglad");
    if (szStan.gra) szStan.t = ((performance.now() - szStan.t0) / 1000) % (T + 0.5);
    $("szCzas").value = Math.round(Math.min(1, szStan.t / T) * 1000); $("szCzasO").textContent = Math.min(szStan.t, T).toFixed(1) + " s";
    const ctx = c.getContext("2d"); ctx.clearRect(0, 0, c.width, c.height);
    Object.entries(szStan.klipy).forEach(([pole, k]) => {
      const v = szStan.zdjecia[pole]; if (!v || v.tagName !== "VIDEO" || szStan.renderuje) return;
      const cel = (k.od || 0) + (Math.min(szStan.t, T) % Math.max(0.1, k.dl || T));
      if (szStan.gra) { if (v.paused) v.play().catch(() => {}); if (Math.abs(v.currentTime - cel) > 0.35) { try { v.currentTime = cel; } catch (e) {} } }
      else { if (!v.paused) v.pause(); if (Math.abs(v.currentTime - cel) > 0.05) { try { v.currentTime = cel; } catch (e) {} } }
    });
    try { SZ.rysuj(ctx, szStan.id, Math.min(szStan.t, T), w, c.width, c.height); } catch (e) { console.log(e); }
  }
  szStan.raf = requestAnimationFrame(szKlatka);
}
function szStart() {
  if (!SZ) zaladujSzablony();
  if (!SZ) { $("szGaleria").innerHTML = '<p class="uwaga">Nie mogę wczytać szablonów z folderu silnika (narzedzia/szablony/szablony.js). Uruchom ponownie instalację panelu.</p>'; return; }
  const c = $("szPodglad"); c.width = 360; c.height = 640;
  szKategorie(); szGaleria();
  if (!szStan.id) { const z = wczytaj("nm-sz-id", ""); szWybierz(SZ.znajdz(z) ? z : SZ.SZABLONY[0].id); }
  cancelAnimationFrame(szStan.raf); szStan.raf = requestAnimationFrame(szKlatka);
}
function szStop() { cancelAnimationFrame(szStan.raf); }
$("szGraj").onclick = () => { szStan.gra = !szStan.gra; if (szStan.gra) szStan.t0 = performance.now() - szStan.t * 1000; $("szGraj").textContent = szStan.gra ? "❚❚" : "▶"; };
$("szCzas").oninput = () => { szStan.gra = false; $("szGraj").textContent = "▶"; szStan.t = +$("szCzas").value / 1000 * SZ.czas(szStan.id, szWartosci()); };
suwak("sz_czas", " s", 1); suwak("sz_tempo", "×", 2);
["sz_czas", "sz_tempo"].forEach((id) => $(id).addEventListener("input", szRestart));
SZ_KOLORY.forEach((x) => $("sz_" + x).addEventListener("change", () => szGaleria()));
$("szKoloryDom").onclick = () => { const sz = SZ.znajdz(szStan.id); if (sz) szUstawKolory(sz.kolory); };
/* Kolory i fonty szablonu z marki klienta (akcent, plama, fonty); tło i tekst zostają z szablonu, żeby był czytelny. */
function szMarkaKlienta(cicho) {
  const { f, d } = markaKlienta(); if (!f) { if (!cicho) alertBlad("Wybierz klienta u góry panelu."); return; }
  if (d.kolor_glowny) $("sz_a").value = String(d.kolor_glowny).toLowerCase();
  if (d.kolor_akcent) $("sz_g").value = String(d.kolor_akcent).toLowerCase();
  if (d.font) $("sz_fn").value = d.font;
  if (d.font_tekstu) $("sz_ft").value = d.font_tekstu;
  anZaladujFontyNazwa(d.font); anZaladujFontyNazwa(d.font_tekstu);
}
$("szKoloryMarki").onclick = () => szMarkaKlienta(false);
/* Napisy: font nagłówków i kolor podświetlenia z marki (gdy wybierasz klienta). */
function nMarkaKlienta() {
  const { f, d, role } = markaKlienta(); if (!f) return;
  const pod = role.podswietlenie_napisow || d.kolor_glowny;
  if (pod) $("nKolor").value = String(pod).toLowerCase();
  if (d.font) { $("nFont").value = d.font; $("nFont").dispatchEvent(new Event("change")); }
}
function anZaladujFontyNazwa(nazwa) { if (!nazwa) return; const stary = $("an_font").value; $("an_font").value = nazwa; anZaladujFonty(); $("an_font").value = stary; }
["sz_wn", "sz_wt"].forEach((id) => $(id).addEventListener("change", () => { anZaladujFontyNazwa($(id === "sz_wn" ? "sz_fn" : "sz_ft").value || $(id === "sz_wn" ? "sz_fn" : "sz_ft").placeholder, $(id).value || null); szRestart(); }));

function szRozmiar() { const i = stan.info; return i && i.wys > i.szer ? [i.szer, i.wys] : [1080, 1920]; }
function szPlikiZastepcze(sz, folder) {
  const pliki = Object.assign({}, szStan.pliki);
  fs.mkdirSync(path.join(folder, "zastepcze"), { recursive: true });
  let nr = 0;
  (sz.pola || []).filter((p) => p.typ === "zdjecie").forEach((p) => {
    const i = nr++;
    if (pliki[p.id] || p.logo) return;
    const c = SZ.zastepcze(i, 1080, 1350), cel = path.join(folder, "zastepcze", `zdjecie_${i + 1}.png`);
    const dane = (c.toDataURL ? c.toDataURL("image/png") : "").split(",")[1];
    if (dane) { fs.writeFileSync(cel, BUF.from(dane, "base64")); pliki[p.id] = cel; }
  });
  // logo klienta, jeśli pole logo jest puste
  (sz.pola || []).filter((p) => p.logo && !pliki[p.id]).forEach((p) => {
    const f = folderKlienta(); if (!f) return;
    try { const l = fs.readdirSync(path.join(f, "logo")).filter((n) => /\.(png|jpe?g|webp)$/i.test(n)); if (l.length) pliki[p.id] = path.join(f, "logo", l[0]); } catch (e) {}
  });
  return pliki;
}
function mtime(p) { try { return fs.statSync(p).mtimeMs; } catch (e) { return 0; } }
/* Uruchamia skrypt w After Effects i czeka na plik z wynikiem, który zapisuje ae_buduj.jsx („ok|...” albo „blad|...”). */
async function aeUruchom(tresc, nazwa, naStan, limitMs = 300000) {
  const folderAE = SYS("after-effects"); fs.mkdirSync(folderAE, { recursive: true });
  const skrypt = path.join(folderAE, `_${nazwa}.jsx`), wynikPlik = path.join(folderAE, `_${nazwa}_wynik.txt`);
  try { fs.unlinkSync(wynikPlik); } catch (e) {}
  // After Effects domyślnie nie pozwala skryptom zapisywać plików: wtedy prosimy o jedno kliknięcie w ustawieniach
  const straz = 'var NM_STOP = false; try { if (app.preferences.getPrefAsLong("Main Pref Section", "Pref_SCRIPTING_FILE_NETWORK_SECURITY") === 0) { alert("Nada Studio: w After Effects trzeba raz włączyć jedną opcję, żeby panel mógł przygotować kompozycję.\\n\\nEdycja > Preferencje > Skrypty i wyrażenia > zaznacz „Pozwalaj skryptom zapisywać pliki i korzystać z sieci”.\\n\\nPotem kliknij przycisk w panelu jeszcze raz."); NM_STOP = true; } } catch (eP) {}\nif (!NM_STOP) {\n';
  fs.writeFileSync(skrypt, "﻿" + straz + tresc(wynikPlik, path.join(SYS("panel"), "ae_bledy.txt")) + "\n}\n", "utf8");
  fs.mkdirSync(path.join(SYS("panel")), { recursive: true });
  const w = await jsx(`nm_ae_wyslij(${q(skrypt)})`);
  if (!w.ok) throw new Error(w.blad);
  naStan && naStan("After Effects pracuje… Jeśli był zamknięty, najpierw się uruchamia (to może potrwać minutę).");
  const start = Date.now();
  while (Date.now() - start < limitMs) {
    await czekaj(700);
    let t = null; try { t = fs.readFileSync(wynikPlik, "utf8"); } catch (e) {}
    if (t) {
      if (t.indexOf("ok|") === 0) return t.split("|");
      throw new Error("After Effects zgłosił błąd: " + t.replace(/^blad\|/, "") + " (szczegóły: _system\\panel\\ae_bledy.txt)");
    }
  }
  throw new Error("After Effects nie odpowiedział w " + Math.round(limitMs / 60000) + " min. Zajrzyj do okna AE: może pyta o zapis projektu albo czeka na zgodę na skrypty (Edycja > Preferencje > Skrypty i wyrażenia > „Pozwalaj skryptom zapisywać pliki”).");
}
function szDomyslnyAep(info) {
  let dir = path.join(wynikiKlienta(), "Panel Premiere", "After Effects"), nazwa = zwartyTekst((info && info.projekt) || "projekt");
  try { if (info && info.sciezka_projektu) { dir = path.join(path.dirname(info.sciezka_projektu), "Nada Studio AE"); nazwa = path.basename(info.sciezka_projektu).replace(/\.prproj$/i, ""); } } catch (e) {}
  fs.mkdirSync(dir, { recursive: true });
  return path.join(dir, `${nazwa}_szablony.aep`);
}
async function szDoAE(zastap) {
  const b = zastap ? $("szAE") : $("szNad"), tekst = b.textContent; b.disabled = true;
  try {
    const sz = SZ.znajdz(szStan.id), info = await odswiezInfo();
    if (!info || !info.ok) throw new Error(HOST === "AEFT" ? "Otwórz projekt w After Effects." : "Otwórz sekwencję w Premiere.");
    const pola = (sz.pola || []).filter((p) => p.typ === "zdjecie" && !p.logo);
    // zaznaczone klipy trafiają do wolnych pól zdjęć po kolei (jak w Dynamic Link: klip ląduje w kompozycji)
    let zaz = [];
    if (HOST === "PPRO") {
      zaz = await szZaznaczoneKlipy();
      const uzyte = new Set(Object.values(szStan.klipy).map((k) => k.idKlipu));
      const wolne = pola.filter((p) => !szStan.klipy[p.id] && !szStan.pliki[p.id]);
      zaz.filter((k) => !uzyte.has(k.idKlipu)).forEach((k, i) => { if (wolne[i]) szUstawKlip(wolne[i].id, k); });
      if (zastap && !zaz.length) throw new Error("Zaznacz na osi klip wideo, który ma zastąpić kompozycja (albo użyj „Wstaw nad klipem”).");
      if (zastap && !pola.length) throw new Error("Ten szablon nie ma miejsca na zdjęcie ani klip: użyj „Wstaw nad klipem”.");
    }
    const glowny = zaz[0] || Object.values(szStan.klipy).find((k) => k.tor != null) || null;
    const [W, H] = szRozmiar(), fps = Math.round((info.fps || 25) * 1000) / 1000;
    const folderAE = SYS("after-effects"); fs.mkdirSync(folderAE, { recursive: true });
    const wart = Object.assign(szWartosci(), { plikiZdjec: szPlikiZastepcze(sz, folderAE), klipy: JSON.parse(JSON.stringify(szStan.klipy)) });
    if (zastap && glowny) wart.czas = Math.max(1, glowny.dl);
    const ctx = document.createElement("canvas").getContext("2d");
    const opis = SZ.doAE(ctx, sz, wart, W, H);
    const komp = `${sz.nazwa} ${new Date().toTimeString().slice(0, 8).replace(/:/g, "")}`;
    const builder = path.join(SZ_FOLDER(), "ae_buduj.jsx");
    const log = path.join(SYS("panel"), "ae_bledy.txt");
    if (HOST === "AEFT") {
      b.textContent = "Buduję kompozycję…";
      const r = await jsx(`nm_ae_buduj_tutaj(${q(builder)}, ${q(JSON.stringify(opis))}, ${q(komp)}, ${fps}, ${q(log)})`);
      if (!r.ok) throw new Error(r.blad || "After Effects nie zbudował kompozycji.");
      $("szStan").textContent = `Gotowe: kompozycje „${komp} – edycja” i „${komp}” w folderze Studio Nadamedia – szablony.`;
    } else {
      const aepDom = szDomyslnyAep(info);
      b.textContent = "After Effects buduje…";
      const [, aep, kompNazwa] = await aeUruchom((wynik, logPlik) => `$.evalFile(new File(${JSON.stringify(builder)}));\nNM_AE_BUDUJ(${JSON.stringify(opis)}, ${JSON.stringify({ projekt: aepDom, nazwaKomp: komp, fps, wynik, log: logPlik })});\n`,
        "buduj_szablon", (t) => ($("szStan").textContent = t));
      b.textContent = "Wstawiam do Premiere…";
      let r;
      if (zastap && glowny && glowny.tor >= 0) r = await jsx(`nm_zastap_ae(${q(aep)}, ${q(kompNazwa || komp)}, ${glowny.tor}, ${glowny.start})`);
      else r = await jsx(`nm_import_ae(${q(aep)}, ${q(kompNazwa || komp)}, ${glowny ? glowny.start : (info.glowica || 0)}, ${opis.czas})`);
      if (!r.ok) throw new Error(r.blad);
      jsx("nm_ae_przod()");
      $("szStan").textContent = (r.zastapiono ? `Klip na ${r.sciezka} zastąpiony kompozycją After Effects (Dynamic Link). Dźwięk klipu został na swojej ścieżce.` : `Kompozycja jest na ${r.sciezka} (Dynamic Link).`) +
        ` W After Effects: „Klip – …” (Twój klip), „${komp} – edycja” (zdjęcia, teksty, ruch) i „${komp}” (ta jest w Premiere). Projekt: ${aep}`;
    }
  } catch (e) { alertBlad(e); }
  b.textContent = tekst; b.disabled = false;
}
$("szAE").onclick = () => szDoAE(true);
$("szNad").onclick = () => szDoAE(false);
function zwartyTekst(t) { return String(t).toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/ł/g, "l").replace(/[^a-z0-9]+/g, "").slice(0, 40) || "projekt"; }
/* Szablon renderowany bez After Effects: nad klipem (z jego długością) albo podmiana szablonu z osi, który właśnie edytujesz. */
async function szWstawRender(naZywo) {
  const b = $("szRender"), tekst = b.textContent;
  if (szStan.zajete) { if (naZywo) szStan.ponow = true; return; }
  szStan.zajete = true; b.disabled = true;
  try {
    const sz = SZ.znajdz(szStan.id), w = szWartosci(), [W, H] = szRozmiar(), info = await odswiezInfo(), fps = info && info.fps ? info.fps : 30;
    const edycja = szStan.edycja;
    let start = null, cel = null;
    if (!edycja && HOST === "PPRO") { await osOdswiez(); cel = celWstawienia(); if (cel && $("szDopasuj").checked) { w.czas = Math.max(1, cel.dl); start = cel.start; } }
    if (edycja && edycja.dl) w.czas = Math.max(1, edycja.dl);
    const folder = await anFolder(), plik = path.join(folder, `${sz.id}_${Date.now().toString(36).slice(-5)}.mp4`);
    szStan.renderuje = true;
    Object.values(szStan.zdjecia).forEach((v) => v && v.tagName === "VIDEO" && v.pause());
    let r;
    try { r = await renderKlatek((ctx, t) => SZ.rysuj(ctx, sz, t, w, W, H), W, H, fps, SZ.czas(sz, w), plik, (x) => (b.textContent = `${naZywo ? "Odświeżam na osi" : "Renderuję"}… ${Math.round(x * 100)}%`), Object.keys(szStan.klipy).length ? szPrzewinKlipy : null, { ogon: AN_ZAPAS_S, tStoi: Math.max(0, SZ.czas(sz, w) - 0.4) }); }
    finally { szStan.renderuje = false; }
    // wszystko, czego trzeba, żeby potem otworzyć ten szablon z osi do poprawek
    const wpis = { typ: "szablon", szablon: sz.id, pola: Object.assign({}, szStan.pola), ust: JSON.parse(JSON.stringify(szStan.ust)), kolory: w.kolory, fonty: w.fonty, czas: w.czas, tempo: w.tempo,
      pliki: Object.assign({}, szStan.pliki), klipy: JSON.parse(JSON.stringify(szStan.klipy)), plik: r.plik, kiedy: new Date().toISOString() };
    fs.writeFileSync(r.plik.replace(/\.mp4$/i, ".nada.json"), JSON.stringify(wpis, null, 1), "utf8");
    let wst;
    if (HOST === "AEFT") wst = await jsx(`nm_ae_importuj(${q(r.plik)})`);
    else if (edycja) wst = await jsx(`nm_podmien_animacje(${q(edycja.idKlipu)}, ${q(r.plik)}, 0, ${q(edycja.plik || "")})`);
    else wst = await jsx(`nm_wstaw(${q(r.plik)}, ${start != null ? start : (info.glowica || 0)}, ${r.czas})`);
    if (!wst.ok) throw new Error(wst.blad);
    anZapiszRejestr(path.basename(r.plik), wpis);
    if (wst.nazwa) anZapiszRejestr(wst.nazwa, wpis);
    if (wst.idKlipu) anZapiszRejestr("id:" + wst.idKlipu, wpis);
    if (edycja && wst.idKlipu) { OS.stare.add(edycja.idKlipu); edycja.idKlipu = wst.idKlipu; OS.zaznaczoneId = wst.idKlipu; }
    b.textContent = edycja ? "Poprawione na osi ✓" : "Wstawione ✓";
    if (!edycja) $("szStan").textContent = (cel && $("szDopasuj").checked ? `Szablon jest nad „${cel.nazwa}” na ${wst.sciezka}, długość ${r.czas.toFixed(1).replace(".", ",")} s.` : `Szablon jest na ${wst.sciezka}.`) + " Kliknij go na osi, a wróci tu do poprawek.";
  } catch (e) { alertBlad(e); }
  szStan.zajete = false;
  setTimeout(() => { b.disabled = false; szPokazEdycje(); if (!szStan.edycja) b.textContent = tekst.includes("✓") || tekst.includes("…") ? "Wstaw nad klipem (bez After Effects)" : tekst; }, naZywo ? 300 : 1800);
  if (szStan.ponow) { szStan.ponow = false; setTimeout(() => szWstawRender(true), 350); }
}
$("szRender").onclick = () => szWstawRender(false);
$("szNowa").onclick = () => { szStan.edycja = null; szStan.pomin = OS.zaznaczoneId; szPokazEdycje(); szWstawRender(false); };
function szPokazEdycje() {
  const e = szStan.edycja;
  if (!szStan.zajete) $("szRender").textContent = e ? "Popraw na osi" : (HOST === "AEFT" ? "Renderuj i wstaw do kompozycji" : "Wstaw nad klipem (bez After Effects)");
  $("szNowa").hidden = !e; $("szStanEdycji").hidden = !e;
  if (e) $("szStanEdycji").innerHTML = `<b>Edytujesz „${e.nazwa.replace(/</g, "")}” z osi.</b> ${$("szNaZywo").checked ? "Każda zmiana poprawia go na osi sama (po chwili)." : "Zmień, co chcesz, i kliknij „Popraw na osi”."} Zostaje w tym samym miejscu i z tą samą długością. <a href="#" id="szAnulujEd">Zakończ edycję</a>`;
  const an = $("szAnulujEd"); if (an) an.onclick = (ev) => { ev.preventDefault(); szStan.edycja = null; szStan.pomin = OS.zaznaczoneId; szPokazEdycje(); };
}
function szOtworzEdycje(x, w) {
  const sz = SZ.znajdz(w.szablon); if (!sz) throw new Error("Nie ma już szablonu " + w.szablon + ".");
  if (szStan.kat !== sz.kat) { szStan.kat = sz.kat; szKategorie(); szGaleria(); }
  const dl = Math.max(1, (x.end - x.start) || w.czas || sz.czas);
  szStan.wczytuje = true;
  szWybierz(sz.id, Object.assign({}, w, { czas: dl }));
  $("sz_czas").max = String(Math.max(20, Math.ceil(dl))); $("sz_czas").value = dl; $("sz_czas").dispatchEvent(new Event("input"));
  szStan.wczytuje = false;
  szStan.edycja = { idKlipu: x.idKlipu, nazwa: sz.nazwa, dl, plik: x.sciezka || "" };
  szPokazEdycje();
}
// zmiany w trakcie edycji szablonu z osi: po chwili same go poprawiają
(function () {
  let t = 0;
  const sekcja = document.querySelector('section[data-v="szablony"]');
  const zmiana = (e) => {
    if (!szStan.edycja || szStan.wczytuje || !$("szNaZywo").checked) return;
    if (e.target.closest && e.target.closest("#szRender, #szNowa, #szAE, #szNad, #szMoj, #szNaZywo, #szDopasuj, #szGraj, #szCzas")) return;
    clearTimeout(t); t = setTimeout(() => szWstawRender(true), 1800);
  };
  sekcja.addEventListener("input", zmiana); sekcja.addEventListener("change", zmiana);
  sekcja.addEventListener("click", (e) => { if (e.target.closest && e.target.closest("#szGaleria .karta, .szfoto button")) zmiana(e); });
})();
// zapamiętane wybory
["anDopasuj", "anNaZywo", "szDopasuj", "szNaZywo"].forEach((id) => { $(id).checked = wczytaj("nm-" + id, true); $(id).addEventListener("change", () => { zapisz("nm-" + id, $(id).checked); osPokaz(); anPokazEdycje(); szPokazEdycje(); }); });
$("szMoj").onclick = () => {
  const sz = SZ.znajdz(szStan.id); if (!sz) return;
  const w = szWartosci(), pierwszy = (sz.pola || []).find((p) => p.typ !== "zdjecie");
  const nazwa = (sz.nazwa + ": " + String(pierwszy ? (szStan.pola[pierwszy.id] || pierwszy.dom) : "").replace(/\n/g, " ")).slice(0, 44);
  szStan.moje.push({ id: Date.now().toString(36), nazwa, szablon: sz.id, pola: Object.assign({}, szStan.pola), ust: szStan.ust, kolory: w.kolory, fonty: w.fonty, czas: w.czas, tempo: w.tempo, pliki: Object.assign({}, szStan.pliki), klipy: JSON.parse(JSON.stringify(szStan.klipy)) });
  fs.writeFileSync(PLIK_MOICH_SZ(), JSON.stringify(szStan.moje, null, 1), "utf8");
  szKategorie(); $("szMoj").textContent = "★ Zapisane w „Moje”"; setTimeout(() => ($("szMoj").textContent = "☆ Zapisz jako mój"), 2500);
};
szStan.kat = wczytaj("nm-sz-kat", "edytorskie");

// mózg zadań w tle: Claude albo Gemini (zapamiętany wybór)
$("mozgZadan").value = mozgZadan();
$("mozgZadan").onchange = () => { zapisz("nm-mozg", $("mozgZadan").value); if ($("mozgZadan").value === "gemini" && !sciezkaAgy()) alertBlad("Nie widzę Antigravity CLI (Gemini) na tym komputerze. W PowerShell w folderze silnika wpisz: python narzedzia\\mozg.py instaluj"); };
// pisownia: przełącznik na ekranie głównym
if (window.NMPisownia) { $("pisAuto").checked = NMPisownia.auto(); $("pisAuto").onchange = () => NMPisownia.ustawAuto($("pisAuto").checked); }
// ---------- start ----------
if (SILNIK) CEPI.evalScript(`try { $.evalFile(${q(path.join(SILNIK, "premiere", "host", "host.jsx").replace(/\\/g, "/"))}); "ok" } catch (e) { "blad: " + e }`, (w) => { if (String(w).indexOf("blad") === 0) log("Skrypt Premiere: " + w, "e"); });
przywroc(); mcPrzywroc(); amPrzywroc();
$("mcOgolna").onchange = mcZapamietaj;
["mc_rozmowa", "mc_wstawka_kat", "mcSilnik", "mcTnij", "mcDzwiek", "mcMikOgolny", "mcNieuzyte"].forEach((id) => $(id).addEventListener("change", mcZapamietaj));
wypelnijKlientow(); amLoga(); anMarkaKlienta();
anStan.kat = wczytaj("nm-an-kat", "tekst");
$("odswiez").onclick = () => { odswiezInfo(); wypelnijKlientow(); };
odswiezInfo().then(() => { mcRysujOsoby(); });
odswiezZadania();
if (HOST === "AEFT") {
  // w After Effects: tylko szablony i animacje
  $$('.kafel[data-idz="ciecie"], .kafel[data-idz="multicam"], .kafel[data-idz="aftermovie"], .kafel[data-idz="tekst"], .kafel[data-idz="dzwiek"], .kafel[data-idz="napisy"], .kafel[data-idz="audio"]').forEach((k) => (k.hidden = true));
  $("szAE").textContent = "Zbuduj w tym projekcie After Effects"; $("szNad").hidden = true;
  $("szRender").textContent = "Renderuj i wstaw do kompozycji";
}
// ======================= STOCK: wyszukiwarka Magnific (+ linki Envato) =======================
const ST = { frazy: [], wyniki: [], strona: 1, ujecia: [], zajete: false, pobrane: wczytaj("nm-stock-pobrane", {}) };
const stEsc = (t) => String(t == null ? "" : t).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const stFolderBaza = () => $("stFolder").value.trim() || path.join(SILNIK, "stock");
const stFolderDnia = () => path.join(stFolderBaza(), new Date().toISOString().slice(0, 10));
function stStart() {
  const u = wczytaj("nm-stock", {});
  if (u.typ) $("stTyp").value = u.typ; if (u.orient) $("stOrient").value = u.orient;
  if (u.tlumacz != null) $("stTlumacz").checked = u.tlumacz; if (u.bezAi != null) $("stBezAi").checked = u.bezAi;
  $("stFolder").value = u.folder || path.join(SILNIK, "stock");
  stLicznik();
}
function stZapamietaj() { zapisz("nm-stock", { typ: $("stTyp").value, orient: $("stOrient").value, tlumacz: $("stTlumacz").checked, bezAi: $("stBezAi").checked, folder: $("stFolder").value.trim() }); }
["stTyp", "stOrient", "stTlumacz", "stBezAi", "stFolder"].forEach((id) => $(id).addEventListener("change", stZapamietaj));
async function stLicznik(n) {
  if (n == null) { try { const r = await python("stock.py", ["licznik"]); n = r.ok ? r.pobrane_dzis : null; } catch (e) {} }
  if (n != null) $("stLicznik").textContent = `Dziś pobrane z Magnific: ${n} z 100`;
}
const stStan = (t, blad) => { $("stStan").textContent = t || ""; $("stStan").style.color = blad ? "var(--err)" : ""; };
function stRysujFrazy() {
  $("stFrazyBox").hidden = !ST.frazy.length;
  $("stFrazy").innerHTML = ST.frazy.map((f, i) => `<button data-i="${i}" aria-pressed="${f.on}">${stEsc(f.t)}</button>`).join("");
  $$("button", $("stFrazy")).forEach((b) => (b.onclick = () => { const f = ST.frazy[+b.dataset.i]; f.on = !f.on; b.setAttribute("aria-pressed", String(f.on)); }));
  const typ = $("stTyp").value, akt = ST.frazy.filter((f) => f.on).slice(0, 6);
  $("stEnvato").innerHTML = akt.length ? `<span class="uwaga">Envato:</span>` + akt.map((f) => `<button data-url="${stEsc(stEnvatoUrl(f.t, typ))}" title="Otwiera wyszukiwanie na stronie Envato Elements; pobierasz sam">${stEsc(f.t)} ↗</button>`).join("") : "";
  $$("button[data-url]", $("stEnvato")).forEach((b) => (b.onclick = () => stOtworzUrl(b.dataset.url)));
}
const stEnvatoUrl = (f, typ) => `https://elements.envato.com/${typ === "wideo" ? "stock-video" : "photos"}/${encodeURIComponent(f.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""))}`;
function stOtworzUrl(u) {
  try { if (window.cep && window.cep.util && window.cep.util.openURLInDefaultBrowser) { window.cep.util.openURLInDefaultBrowser(u); return; } } catch (e) {}
  cp.exec(PROC.platform === "win32" ? `start "" "${u}"` : `open "${u}"`);
}
function stRysujUjecia() {
  $("stUjecia").hidden = !ST.ujecia.length;
  $("stUjecia").innerHTML = ST.ujecia.map((u) => `<div class="st-ujecie"><div class="min" style="background-image:url('${stEsc(pathToFileURL(u.miniatura))}')"></div><div>
    <p><b>${u.nr}.</b> ${stEsc(u.opis_pl || path.basename(u.plik))}</p><div class="st-frazy">${(u.frazy || []).map((f) => `<button data-f="${stEsc(f)}">${stEsc(f)}</button>`).join("")}</div></div></div>`).join("");
  $$("button[data-f]", $("stUjecia")).forEach((b) => (b.onclick = () => { stDodajFraze(b.dataset.f, true); stSzukajTeraz(true); }));
}
const pathToFileURL = (p) => "file:///" + String(p).replace(/\\/g, "/").replace(/^\/+/, "").split("/").map(encodeURIComponent).join("/").replace(/^([A-Za-z])%3A/, "$1:");
function stDodajFraze(t, on) {
  t = String(t || "").trim(); if (!t) return;
  const f = ST.frazy.find((x) => x.t.toLowerCase() === t.toLowerCase());
  if (f) f.on = on || f.on; else ST.frazy.push({ t, on: on !== false });
  stRysujFrazy();
}
function stKarta(x) {
  const pob = ST.pobrane[x.id], pion = x.typ === "wideo" && /vertical|pion/i.test(String(x.orientacja || ""));
  const znacz = [x.dlugosc ? String(x.dlugosc).replace(/^00:/, "") : "", x.jakosc || "", x.premium ? "Premium" : "", x.ai ? "AI" : ""].filter(Boolean);
  return `<div class="st-karta${pob ? " pobrana" : ""}${pion ? " pion" : ""}" data-id="${stEsc(x.id)}">
    <div class="ekran" style="background-image:url('${stEsc(x.miniatura || "")}')" data-podglad="${stEsc(x.podglad || "")}" title="${stEsc(x.nazwa || "")}"><div class="znacz">${znacz.map((z) => `<i>${stEsc(z)}</i>`).join("")}</div></div>
    <div class="opis">${stEsc(x.nazwa || x.fraza)}</div>
    <div class="akcje"><button class="maly${pob ? "" : " akc"}" data-a="pobierz">${pob ? "W projekcie ✓" : "Pobierz"}</button>${x.strona ? `<a href="#" data-a="strona" title="Otwórz na stronie Magnific">↗</a>` : ""}</div></div>`;
}
function stRysujGalerie(dopisz) {
  const g = $("stGaleria");
  if (!dopisz) g.innerHTML = "";
  const nowe = dopisz ? ST.wyniki.slice(-dopisz) : ST.wyniki;
  g.insertAdjacentHTML("beforeend", nowe.map(stKarta).join(""));
  $$(".st-karta", g).forEach((k) => {
    if (k.dataset.gotowa) return; k.dataset.gotowa = "1";
    const x = ST.wyniki.find((w) => String(w.id) === k.dataset.id), ek = k.querySelector(".ekran");
    ek.onmouseenter = () => {
      if (!ek.dataset.podglad || ek.querySelector("video")) return;
      const v = document.createElement("video");
      v.muted = true; v.loop = true; v.playsInline = true; v.autoplay = true; v.preload = "auto"; v.src = ek.dataset.podglad;
      v.onerror = () => v.remove();
      ek.appendChild(v); v.play().catch(() => {});
    };
    ek.onmouseleave = () => { const v = ek.querySelector("video"); if (v) { v.pause(); v.removeAttribute("src"); v.load(); v.remove(); } };
    ek.onclick = () => { if (x && x.strona) stOtworzUrl(x.strona); };
    const a = k.querySelector('[data-a="strona"]'); if (a) a.onclick = (e) => { e.preventDefault(); stOtworzUrl(x.strona); };
    k.querySelector('[data-a="pobierz"]').onclick = () => stPobierz(x, k);
  });
  $("stWiecej").hidden = !ST.wyniki.length;
}
async function stPobierz(x, k) {
  const b = k.querySelector('[data-a="pobierz"]');
  if (ST.pobrane[x.id] && fs.existsSync(ST.pobrane[x.id])) { await stDoProjektu(ST.pobrane[x.id], b); return; }
  b.disabled = true; b.textContent = "Pobieram…";
  try {
    const r = await python("stock.py", ["pobierz", "--id", String(x.id), "--typ", x.typ, "--folder", stFolderDnia(), "--nazwa", x.fraza || x.nazwa || "stock"]);
    if (!r.ok) throw new Error(r.blad);
    ST.pobrane[x.id] = r.plik; zapisz("nm-stock-pobrane", ST.pobrane); stLicznik(r.pobrane_dzis);
    k.classList.add("pobrana");
    await stDoProjektu(r.plik, b);
  } catch (e) { b.textContent = "Pobierz"; b.disabled = false; stStan("Pobieranie: " + (e.message || e), true); }
}
async function stDoProjektu(plik, b) {
  if (HOST !== "PPRO") { b.textContent = "Pobrane ✓"; b.disabled = false; otworzFolder(path.dirname(plik)); return; }
  const w = await jsx(`nm_import_do_kosza(${JSON.stringify([plik])}, ${q("Nada – stock")})`);
  b.disabled = false; b.classList.remove("akc");
  b.textContent = w.ok ? "W projekcie ✓" : "Pobrane (import: błąd)";
  if (!w.ok) stStan(w.blad, true); else stStan(`${path.basename(plik)} jest w koszu „Nada – stock”.`);
}
async function stSzukajTeraz(odNowa) {
  const akt = ST.frazy.filter((f) => f.on).map((f) => f.t).slice(0, 6);
  if (!akt.length) { stStan("Wpisz, czego szukasz, albo włącz którąś frazę.", true); return; }
  if (odNowa) { ST.strona = 1; ST.wyniki = []; }
  stStan(`Szukam w Magnific: ${akt.join(", ")}…`);
  const args = ["szukaj", "--frazy", JSON.stringify(akt), "--typ", $("stTyp").value, "--orientacja", $("stOrient").value, "--strona", String(ST.strona), "--ile", "12"];
  if (!$("stBezAi").checked) args.push("--z-ai");
  const r = await python("stock.py", args);
  if (!r.ok) { stStan(r.blad, true); return; }
  const znane = new Set(ST.wyniki.map((w) => String(w.id)));
  const nowe = r.wyniki.filter((w) => !znane.has(String(w.id)));
  ST.wyniki.push(...nowe);
  stRysujFrazy();
  stRysujGalerie(odNowa ? 0 : nowe.length);
  stLicznik(r.pobrane_dzis);
  stStan(ST.wyniki.length ? `Wyniki: ${ST.wyniki.length}. Najedź na kafelek, żeby obejrzeć.${(r.bledy || []).length ? " Uwaga: " + r.bledy[0] : ""}` : "Nic nie znalazłem. Zmień frazy albo orientację.", !ST.wyniki.length);
  if (!nowe.length && !odNowa) $("stWiecej").hidden = true;
}
async function stZablokuj(fn) {
  if (ST.zajete) return; ST.zajete = true;
  const przyciski = ["stSzukaj", "stZOsi", "stZPliku", "stPonownie", "stWiecej"].map($);
  przyciski.forEach((b) => (b.disabled = true));
  try { await fn(); } catch (e) { stStan(e.message || String(e), true); }
  przyciski.forEach((b) => (b.disabled = false)); ST.zajete = false;
}
$("stSzukaj").onclick = () => stZablokuj(async () => {
  const opis = $("stOpis").value.trim();
  if (opis) {
    ST.ujecia = []; stRysujUjecia();
    if ($("stTlumacz").checked) {
      stStan("Dobieram frazy…");
      const r = await python("stock.py", ["frazy", "--opis", opis]);
      ST.frazy = (r.ok ? r.frazy : [opis]).map((t) => ({ t, on: true }));
      if (r.uwaga) stStan(r.uwaga);
    } else ST.frazy = [{ t: opis, on: true }];
    stRysujFrazy();
  }
  await stSzukajTeraz(true);
});
$("stPonownie").onclick = () => stZablokuj(() => stSzukajTeraz(true));
$("stWiecej").onclick = () => stZablokuj(async () => { ST.strona++; await stSzukajTeraz(false); });
$("stNowaFraza").addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); stDodajFraze($("stNowaFraza").value, true); $("stNowaFraza").value = ""; } });
function stPoAnalizie(r) {
  if (!r.ok) throw new Error(r.blad);
  ST.ujecia = r.ujecia || [];
  ST.frazy = [];
  (r.wspolne || []).forEach((f) => stDodajFraze(f, true));
  ST.ujecia.forEach((u) => (u.frazy || []).forEach((f, i) => stDodajFraze(f, i === 0)));
  if (ST.frazy.filter((f) => f.on).length > 6) ST.frazy.forEach((f, i) => (f.on = f.on && i < 6));
  stRysujUjecia(); stRysujFrazy();
  const uw = [r.uwaga, ...(r.pominiete || [])].filter(Boolean);
  if (uw.length) stStan(uw.join(" "));
  return ST.frazy.some((f) => f.on);
}
$("stZOsi").onclick = () => stZablokuj(async () => {
  if (HOST !== "PPRO") throw new Error("To działa w Premiere: zaznacz klipy na osi czasu.");
  const st = await jsx("nm_os_stan()");
  const zazn = ((st && st.zaznaczone) || []).filter((x) => x.sciezka);
  if (!zazn.length) throw new Error("Zaznacz na osi czasu jeden albo kilka klipów wideo.");
  let proksy = {};
  try { const p = await jsx("nm_proksy()"); if (p.ok) p.pliki.forEach((x) => { if (x.proksy) proksy[String(x.plik).toLowerCase()] = x.proksy; }); } catch (e) {}
  const klipy = zazn.slice(0, 12).map((x) => ({ plik: x.sciezka, od: x.od || 0, do: (x.od || 0) + (x.end - x.start), proksy: proksy[String(x.sciezka).toLowerCase()] || "" }));
  stStan(`Oglądam ${klipy.length} ${klipy.length === 1 ? "ujęcie" : "ujęć"} i opisuję je…`);
  const r = await python("stock.py", ["z-klipow", "--klipy", JSON.stringify(klipy), "--folder", path.join(SYS("stock"), "analiza", String(Date.now()))]);
  if (stPoAnalizie(r)) await stSzukajTeraz(true);
});
$("stZPliku").onclick = () => stZablokuj(async () => {
  let pliki = [];
  try { const o = window.cep.fs.showOpenDialogEx ? window.cep.fs.showOpenDialogEx(true, false, "Ujęcia, zdjęcia albo gotowy film", "", ["mp4", "mov", "mxf", "m4v", "avi", "mkv", "webm", "jpg", "jpeg", "png", "webp", "braw"]) : window.cep.fs.showOpenDialog(true, false, "Ujęcia, zdjęcia albo gotowy film", "", ["mp4", "mov", "jpg", "png"]); pliki = (o && o.data) || []; } catch (e) { throw new Error("Nie mogę otworzyć okna wyboru plików: " + e.message); }
  if (!pliki.length) return;
  stStan(pliki.length === 1 ? "Oglądam plik (gotowy film rozbijam na ujęcia)…" : `Oglądam ${pliki.length} plików…`);
  const r = await python("stock.py", ["z-plikow", "--pliki", JSON.stringify(pliki.slice(0, 12)), "--folder", path.join(SYS("stock"), "analiza", String(Date.now()))]);
  if (stPoAnalizie(r)) await stSzukajTeraz(true);
});
$("stFolderWybierz").onclick = () => {
  try { const o = window.cep.fs.showOpenDialogEx ? window.cep.fs.showOpenDialogEx(false, true, "Folder na pobrane ze stocka", stFolderBaza()) : window.cep.fs.showOpenDialog(false, true, "Folder na pobrane ze stocka", stFolderBaza()); const f = o && o.data && o.data[0]; if (f) { $("stFolder").value = f; stZapamietaj(); } } catch (e) { alertBlad(e); }
};
$("stFolderOtworz").onclick = () => { fs.mkdirSync(stFolderBaza(), { recursive: true }); otworzFolder(stFolderBaza()); };

const widokStartowy = wczytaj("nm-widok", "dom");
pokaz(HOST === "AEFT" && !["dom", "szablony", "animacje"].includes(widokStartowy) ? "dom" : widokStartowy);
if (!SILNIK) log("Brak konfiguracji panelu. W folderze silnika uruchom: python narzedzia\\panel_premiere.py --instaluj", "e");
})();

// pola tekstu rosną razem z treścią (Enter = nowa linia)
(function () {
  const dopasuj = (t) => { t.style.height = "auto"; t.style.height = Math.max(52, t.scrollHeight + 2) + "px"; };
  document.addEventListener("input", (e) => { if (e.target && e.target.tagName === "TEXTAREA") dopasuj(e.target); });
  new MutationObserver(() => document.querySelectorAll("textarea.tekst").forEach((t) => { if (!t.dataset.rosnie) { t.dataset.rosnie = "1"; requestAnimationFrame(() => dopasuj(t)); } })).observe(document.body, { childList: true, subtree: true });
})();

// układ narzędzi: podgląd z lewej (przyklejony), ustawienia z prawej, główne przyciski zawsze na dole widoku
(function () {
  const $ = (id) => document.getElementById(id);
  function uklad(edytorId, lewe, opcje, dol) {
    const ed = $(edytorId); if (!ed || ed.dataset.uklad) return;
    ed.dataset.uklad = "1";
    const u = document.createElement("div"); u.className = "uklad2";
    const l = document.createElement("div"); l.className = "lewa";
    const p = document.createElement("div"); p.className = "prawa";
    const op = document.createElement("div"); op.className = "opcje";
    const d = document.createElement("div"); d.className = "dol-akcje";
    // „+id” = element nadrzędny (etykieta albo rząd przycisków) wokół elementu o tym id; bez :has(), którego stary Chromium w Adobe nie zna
    const znajdz = (x) => { if (x[0] === "+") { const e = $(x.slice(1)); return e ? e.closest("label, .siatka2") : null; } return ed.querySelector(x); };
    const tylkoDzieci = (l) => l.map(znajdz).filter((e) => e && e.parentElement === ed);
    const elLewe = tylkoDzieci(lewe), elOpcje = tylkoDzieci(opcje), elDol = tylkoDzieci(dol);
    Array.from(ed.children).forEach((c) => { if (!elLewe.includes(c) && !elOpcje.includes(c) && !elDol.includes(c)) p.appendChild(c); });
    elLewe.forEach((c) => l.appendChild(c));
    elOpcje.forEach((c) => op.appendChild(c));
    elDol.forEach((c) => d.appendChild(c));
    if (elOpcje.length) p.appendChild(op);
    u.appendChild(l); u.appendChild(p); u.appendChild(d); ed.appendChild(u);
  }
  uklad("anEdytor", ["#anPodgladBox", ".odtw", "#anCel", "#anInny", "#anStanEdycji"], ["+anDopasuj", "+anNaZywo", "+anRozciagana"],
    ["+anWstaw", "#anNowa", "#anEdytuj", "#anMoj"]);
  uklad("szEdytor", ["#szPodgladBox", ".odtw", "#szCel", "#szInny", "#szStanEdycji", "#szStan"], ["+szDopasuj", "+szNaZywo"],
    ["#szAE", "+szNad", "#szNowa", "#szMoj"]);
  // galerie jako pasek do przewijania w bok; „Pokaż wszystkie” rozwija siatkę
  ["anGaleria", "szGaleria", "nStyle"].forEach((id) => {
    const g = $(id); if (!g) return;
    const roz = (() => { try { return JSON.parse(localStorage.getItem("nm-galeria-" + id)) === true; } catch (e) { return false; } })();
    g.classList.toggle("pasmo", !roz);
    const b = document.createElement("button"); b.type = "button"; b.className = "galeria-przel";
    const napis = () => (b.textContent = g.classList.contains("pasmo") ? "▦ Pokaż wszystkie" : "▤ Zwiń do paska");
    b.onclick = () => { g.classList.toggle("pasmo"); napis(); try { localStorage.setItem("nm-galeria-" + id, JSON.stringify(!g.classList.contains("pasmo"))); } catch (e) {} };
    napis(); g.after(b);
  });
  // długie opisy opcji jako podpowiedź po najechaniu (ⓘ), żeby nie zajmowały miejsca
  const podpowiedzi = () => document.querySelectorAll(".ch small").forEach((sm) => { const l = sm.closest(".ch"); if (l && !l.title) l.title = sm.textContent.trim(); });
  podpowiedzi(); new MutationObserver(podpowiedzi).observe(document.body, { childList: true, subtree: true });
})();
