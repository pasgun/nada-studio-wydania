"""Układ folderów użytkownika: wszystko jednego klienta w jednym miejscu (od wersji 19.63).

  C:\\Studio\\                         folder danych, obok folderu programu (studio-rolek)
    Klienci\\
      01 Instytut Edukacji Finansowej\\  numer = kolejność dodania klienta
        Filmy\\
          01 <Tytuł zadania>\\           gotowe pliki na wierzchu (np. „Rolka 1.mp4”), Premiere\\, Assety\\
        Grafika\\
          01 <Tytuł zadania>\\           gotowe grafiki na wierzchu, Photoshop\\, Assety\\
        Assety\\                         Brandbook\\, Logo\\, Fonty\\, Makiety\\, Referencje\\Wideo|Grafiki\\, Panel Premiere\\
                                         (+ ukryte notatki AI: marka.md, styl, oceny, karta klienta)
      00 Bez klienta\\
    Biblioteka\\                         Muzyka\\ (z Efekty\\), Envato\\, Stock\\

Stare adresy w programie działają dalej, bo są połączeniami folderów (junction w Windows, bez uprawnień administratora):
  klienci/<slug>        -> Klienci\\NN Nazwa\\Assety
  nagrania/<nazwa>      -> ...\\Filmy\\NN Tytuł\\Assety\\Nagrania
  materialy/<nazwa>     -> ...\\Grafika\\NN Tytuł\\Assety\\Zdjęcia
  zlecenia/<nazwa>, napisy/<nazwa> -> ...\\NN Tytuł\\Assety\\Pliki   (gotowe wyniki narzędzi idą na wierzch zadania)
  muzyka, envato, stock, stock_reczny -> Biblioteka\\...
Dzięki temu narzędzia, skille i panele mogą pisać klienci/<folder>/marka.md albo nagrania/<nazwa> jak wcześniej.

Ustawienia: _system/uklad.json. Bez niego (przed przeniesieniem starych plików) wszystko działa po staremu.

  python narzedzia/uklad.py stan
  python narzedzia/uklad.py plan            co i dokąd zostanie przeniesione (nic nie rusza)
  python narzedzia/uklad.py przenies        przenosi (niczego nie kasuje; dziennik w _system/uklad_dziennik.json)
"""
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

KATALOG = Path(__file__).resolve().parent.parent
PLIK = KATALOG / "_system" / "uklad.json"
DZIENNIK = KATALOG / "_system" / "uklad_dziennik.json"
ZAKAZANE = '<>:"/\\|?*'

FILMY, GRAFIKA, ASSETY = "Filmy", "Grafika", "Assety"
PREMIERE, PHOTOSHOP, AFTER = "Premiere", "Photoshop", "After Effects"
BEZ_KLIENTA = "00 Bez klienta"
# rodzaje zadań ze Studio, które są grafiką (reszta: Filmy)
RODZAJE_GRAFIKI = {"grafika", "grafiki", "miniatury", "miniatura", "formaty", "brandbook", "karuzela", "kompozycja"}
# podfoldery w Assety klienta (nazwy widoczne dla użytkownika; Windows nie rozróżnia wielkości liter, więc stare
# odwołania klienci/<slug>/brandbook, logo, fonty, makiety, referencje/wideo trafiają w te same foldery)
ASSETY_KLIENTA = ["Brandbook", "Logo", "Fonty", "Referencje/Wideo", "Referencje/Grafiki"]
# wejście zadania, które wrzuca użytkownik (stare adresy programu -> podfolder Assety zadania)
WEJSCIA = {"nagrania": "Nagrania", "materialy": "Zdjęcia", "zlecenia": "Pliki", "napisy": "Pliki"}
BIBLIOTEKA = {"muzyka": "Muzyka", "envato": "Envato", "stock": "Stock", "stock_reczny": "Stock/Z innych serwisów"}
# notatki AI w Assety klienta: zostają, ale ukryte (użytkownik ich nie potrzebuje)
NOTATKI = re.compile(r"(marka|styl(_wideo|_grafiki)?|oceny|muzyka|notatka_klienta)\.md$|(klient|karta_klienta|animacje)\.json$|^CZYTAJ\.txt$|^logo\.png$", re.I)


# ---------- ustawienia ----------
def ustawienia():
    try:
        d = json.loads(PLIK.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def zapisz_ustawienia(d):
    PLIK.parent.mkdir(parents=True, exist_ok=True)
    tmp = PLIK.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    os.replace(tmp, PLIK)


def wlaczony():
    """Czy nowy układ działa (po przeniesieniu starych plików)."""
    u = ustawienia()
    return bool(u.get("wlaczony") and u.get("dane"))


def domyslne_dane():
    """Folder danych: obok folderu programu (C:\\Studio\\studio-rolek -> C:\\Studio), gdy to osobny folder na Studio;
    gdy program leży np. w Dokumentach, dane idą do „<program> - pliki” obok, żeby nie zaśmiecać Dokumentów."""
    rodzic = KATALOG.parent
    inne = [x for x in rodzic.iterdir() if x.name not in (KATALOG.name, "Klienci", "Biblioteka") and not x.name.startswith(".")] if rodzic.exists() else []
    if not inne or rodzic.name.lower() in ("studio", "nada studio", "nada"):
        return rodzic
    return rodzic / f"{KATALOG.name} - pliki"


def dane():
    u = ustawienia()
    return Path(u["dane"]) if u.get("dane") else domyslne_dane()


def klienci_root():
    return dane() / "Klienci"


def biblioteka_root():
    return dane() / "Biblioteka"


# ---------- nazwy i numery ----------
def czysta_nazwa(t, dl=70):
    t = "".join("-" if c in ZAKAZANE or ord(c) < 32 else c for c in str(t or "")).strip().strip(".")
    t = re.sub(r"\s+", " ", t)
    return t[:dl].rstrip(" .") or "bez nazwy"


def numer(nazwa):
    m = re.match(r"(\d{2,3}) ", str(nazwa))
    return int(m.group(1)) if m else None


def nastepny_numer(folder, od=1):
    nr = [numer(x.name) for x in folder.iterdir() if x.is_dir()] if folder.exists() else []
    nr = [n for n in nr if n is not None and n >= od]
    return (max(nr) + 1) if nr else od


def kategoria(rodzaj):
    return GRAFIKA if str(rodzaj or "").lower() in RODZAJE_GRAFIKI else FILMY


# ---------- połączenia folderów ----------
def cel_polaczenia(p):
    """Dokąd naprawdę prowadzi folder (dla połączenia: folder docelowy), albo None, gdy to zwykły folder."""
    p = Path(p)
    try:
        if not os.path.lexists(p):
            return None
        rp = Path(os.path.realpath(p))
        rr = Path(os.path.realpath(p.parent)) / p.name
        return None if os.path.normcase(str(rp)) == os.path.normcase(str(rr)) else rp
    except OSError:
        return None


def polacz(link, cel):
    """Tworzy połączenie folderu link -> cel (Windows: junction, bez administratora; inne systemy: dowiązanie)."""
    link, cel = Path(link), Path(cel)
    cel.mkdir(parents=True, exist_ok=True)
    link.parent.mkdir(parents=True, exist_ok=True)
    if os.path.lexists(link):
        c = cel_polaczenia(link)
        if c and os.path.normcase(str(c)) == os.path.normcase(str(Path(os.path.realpath(cel)))):
            return link
        raise FileExistsError(f"W miejscu połączenia jest już folder: {link}")
    if sys.platform.startswith("win"):
        try:
            import _winapi
            _winapi.CreateJunction(str(cel), str(link))
        except Exception:
            r = subprocess.run(["cmd", "/c", "mklink", "/J", str(link), str(cel)], capture_output=True, text=True, creationflags=0x08000000)
            if r.returncode != 0:
                raise OSError("Nie udało się połączyć folderów: " + (r.stderr or r.stdout))
    else:
        os.symlink(str(cel), str(link), target_is_directory=True)
    return link


def usun_polaczenie(link):
    """Usuwa samo połączenie (folder docelowy i pliki zostają)."""
    link = Path(link)
    if not cel_polaczenia(link):
        raise ValueError(f"To nie jest połączenie folderu: {link}")
    if os.path.islink(link):
        os.unlink(link)
    else:
        os.rmdir(link)  # junction w Windows: usuwa tylko połączenie


def ukryj(p):
    if sys.platform.startswith("win"):
        try:
            import ctypes
            a = ctypes.windll.kernel32.GetFileAttributesW(str(p))
            if a != -1:
                ctypes.windll.kernel32.SetFileAttributesW(str(p), a | 0x02)
        except Exception:
            pass


def ukryj_notatki(assety):
    """Notatki AI w Assety klienta (marka.md, styl, oceny, karta) i foldery robocze z „_” na początku: ukryte w Eksploratorze."""
    try:
        for x in Path(assety).iterdir():
            if (x.is_file() and NOTATKI.search(x.name)) or x.name.startswith("_"):
                ukryj(x)
        ref = Path(assety) / "Referencje"
        for x in ref.rglob("_*") if ref.exists() else []:
            ukryj(x)
    except Exception:
        pass


# ---------- klienci ----------
def _baza(nazwa):
    try:
        return json.loads((KATALOG / "_system" / "baza" / nazwa).read_text(encoding="utf-8"))
    except Exception:
        return {}


def klienci_studia():
    """Klienci z bazy Studio: slug -> {nazwa, utworzono}."""
    out = {}
    d = _baza("clients.json")
    for v in (d.values() if isinstance(d, dict) else d if isinstance(d, list) else []):
        if not isinstance(v, dict) or not v.get("name"):
            continue
        slug = v.get("slug") or slugify(v["name"])
        out[slug] = {"nazwa": v["name"], "utworzono": v.get("createdAt") or 0}
    return out


def slugify(t):
    import unicodedata
    t = unicodedata.normalize("NFD", str(t or "").replace("ł", "l").replace("Ł", "L")).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "-", t).strip("-")


def nazwa_klienta(slug, podana=""):
    """Ładna nazwa klienta: z bazy Studio, z klient.json, z podanej albo z nazwy folderu („stalowy-dom” -> „Stalowy Dom”)."""
    ks = klienci_studia().get(slug)
    if ks:
        return ks["nazwa"]
    for p in (KATALOG / "klienci" / slug / "klient.json",):
        try:
            n = json.loads(p.read_text(encoding="utf-8")).get("nazwa")
            if n:
                return n
        except Exception:
            pass
    if podana and not re.fullmatch(r"[a-z0-9\-_]+", podana):
        return podana
    s = [x for x in re.split(r"[-_\s]+", slug or "") if x]
    return " ".join(w.upper() if len(w) <= 3 and len(s) == 1 else w[:1].upper() + w[1:] for w in s) or "Bez nazwy"


def slug_z_folderu(klient_folder):
    return str(klient_folder or "").replace("\\", "/").strip("/").split("/")[-1] if klient_folder else ""


def folder_klienta(slug="", nazwa="", utworz=True):
    """Klienci\\NN Nazwa (fizyczny folder klienta). Pusty slug = 00 Bez klienta."""
    root = klienci_root()
    if not slug:
        k = root / BEZ_KLIENTA
        if utworz:
            for p in (FILMY, GRAFIKA, ASSETY):
                (k / p).mkdir(parents=True, exist_ok=True)
        return k
    u = ustawienia()
    mapa = u.setdefault("klienci", {})
    if mapa.get(slug) and (root / mapa[slug]).is_dir():
        k = root / mapa[slug]
    else:
        # może już jest (np. utworzony na innym komputerze albo ręcznie): po połączeniu klienci/<slug> albo po nazwie
        k = None
        c = cel_polaczenia(KATALOG / "klienci" / slug)
        if c and c.name.lower() == ASSETY.lower() and c.parent.parent == Path(os.path.realpath(root)):
            k = root / c.parent.name
        if k is None:
            n = czysta_nazwa(nazwa_klienta(slug, nazwa), 60)
            for x in root.iterdir() if root.exists() else []:
                if x.is_dir() and re.sub(r"^\d{2,3} ", "", x.name).lower() == n.lower():
                    k = x
                    break
        if k is None:
            if not utworz:
                return None
            root.mkdir(parents=True, exist_ok=True)
            k = root / f"{nastepny_numer(root):02d} {czysta_nazwa(nazwa_klienta(slug, nazwa), 60)}"
        mapa[slug] = k.name
        if utworz:
            zapisz_ustawienia(u)
    if utworz:
        for p in (FILMY, GRAFIKA, ASSETY):
            (k / p).mkdir(parents=True, exist_ok=True)
        link = KATALOG / "klienci" / slug
        if not os.path.lexists(link):
            polacz(link, k / ASSETY)
    return k


def assety_klienta(slug, nazwa=""):
    k = folder_klienta(slug, nazwa)
    return k / ASSETY


# ---------- zadania ----------
def _info(folder):
    for p in (Path(folder) / ASSETY / "_info.json", Path(folder) / "Materiały" / "_info.json"):
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
    return {}


def zapisz_info(folder, inf):
    p = Path(folder) / ASSETY / "_info.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(inf, ensure_ascii=False, indent=1), encoding="utf-8")
    ukryj(p)


def zadanie_ze_studia(zid):
    """Zadanie z bazy Studio po krótkim numerze (ostatnie 4 znaki id, jak w Studio)."""
    zid = str(zid or "").strip().upper()
    if not zid:
        return {}
    d = _baza("tasks.json")
    for k, v in (d.items() if isinstance(d, dict) else []):
        if isinstance(v, dict) and str(k)[-4:].upper() == zid:
            return dict(v, _id=k)
    return {}


def rodzaj_zadania(zid="", tytul="", podany=""):
    if podany:
        return podany
    t = zadanie_ze_studia(zid)
    if t.get("type"):
        return t["type"]
    return "grafika" if re.search(r"grafik|miniatur|post|baner|karuzel|plakat|ulotk", str(tytul or ""), re.I) else "rolka"


def folder_zadania(slug="", nazwa_kl="", tytul="", zid="", rodzaj="", utworz=True, podfolder=None):
    """Klienci\\NN Klient\\Filmy|Grafika\\NN Tytuł. To samo zadanie (ten sam numer ze Studio) wraca do swojego folderu.
    podfolder (np. „Panel Premiere”): rzeczy z panelu, w Assety klienta, bez numeru."""
    k = folder_klienta(slug, nazwa_kl, utworz=utworz)
    if k is None:
        return None
    zid = str(zid or "").strip()
    baza_nazwy = czysta_nazwa(tytul or "Zadanie " + time.strftime("%d.%m.%Y"))
    if podfolder:
        kat = k / ASSETY / podfolder
        if zid and kat.exists():
            for d in kat.iterdir():
                if d.is_dir() and _info(d).get("zadanie_id") == zid:
                    return d
        p, n = kat / baza_nazwy, 2
        while p.exists() and any(p.iterdir()):
            p = kat / f"{baza_nazwy} ({n})"
            n += 1
        if utworz:
            p.mkdir(parents=True, exist_ok=True)
            if zid and not _info(p):
                zapisz_info(p, {"utworzono": time.strftime("%Y-%m-%d %H:%M"), "tytul": tytul, "klient": k.name, "zadanie_id": zid})
        return p
    rodzaj = rodzaj_zadania(zid, tytul, rodzaj)
    u = ustawienia()
    zad = u.get("zadania", {})
    if zid and zad.get(zid):
        p = dane() / zad[zid]
        if p.is_dir():
            return p
    kat = k / kategoria(rodzaj)
    wolny = None
    if kat.exists():
        for d in sorted(kat.iterdir()):
            if not d.is_dir():
                continue
            inf = _info(d)
            if zid and inf.get("zadanie_id") == zid:
                return _zapamietaj(zid, d)
            # folder założony w Studio przed startem zadania (np. „Nagrania do tego zadania”): przejmujemy go
            if zid and not inf.get("zadanie_id") and inf.get("rezerwacja") and re.sub(r"^\d{2,3} ", "", d.name) == baza_nazwy and wolny is None:
                wolny = d
    t = zadanie_ze_studia(zid)
    for pole, rodz in (("nagraniaFolder", "nagrania"), ("materialyFolder", "materialy")):
        c = cel_polaczenia(KATALOG / rodz / t[pole]) if t.get(pole) else None
        if c and c.parent.name == ASSETY and c.parent.parent.parent == kat.resolve():
            wolny = wolny or c.parent.parent
    if wolny is not None:
        inf = _info(wolny)
        inf["zadanie_id"] = zid
        inf.pop("rezerwacja", None)
        zapisz_info(wolny, inf)
        return _zapamietaj(zid, wolny)
    if not utworz:
        return None
    kat.mkdir(parents=True, exist_ok=True)
    p = kat / f"{nastepny_numer(kat):02d} {baza_nazwy}"
    (p / ASSETY).mkdir(parents=True, exist_ok=True)
    inf = {"utworzono": time.strftime("%Y-%m-%d %H:%M"), "tytul": tytul, "klient": k.name, "rodzaj": rodzaj}
    if zid:
        inf["zadanie_id"] = zid
    else:
        inf["rezerwacja"] = True
    zapisz_info(p, inf)
    ukryj_notatki(k / ASSETY)
    return _zapamietaj(zid, p) if zid else p


def _zapamietaj(zid, p):
    if zid:
        u = ustawienia()
        try:
            rel = Path(p).relative_to(dane()).as_posix()
        except ValueError:
            return p
        if u.setdefault("zadania", {}).get(zid) != rel:
            u["zadania"][zid] = rel
            zapisz_ustawienia(u)
    return p


def folder_wejscia(rodz, nazwa, slug="", nazwa_kl="", tytul="", zid="", rodzaj=""):
    """Folder na pliki użytkownika do zadania (rodz: nagrania, materialy, zlecenia, napisy): fizycznie w Assety zadania,
    a w programie pod starym adresem <rodz>/<nazwa> (połączenie). Zwraca stary adres (Path w programie)."""
    link = KATALOG / rodz / nazwa
    if os.path.lexists(link):
        return link
    if not rodzaj:
        rodzaj = "grafika" if rodz == "materialy" else ""
    if not slug:
        slug = _slug_z_nazwy(nazwa)
    p = folder_zadania(slug, nazwa_kl, tytul or _tytul_z_nazwy(nazwa), zid, rodzaj)
    cel = p / ASSETY / WEJSCIA[rodz]
    polacz(link, cel)
    return link


def _slug_z_nazwy(nazwa):
    """„bogmat_rolka46_121126” -> „bogmat” (gdy taki klient jest); inaczej bez klienta."""
    from wspolne import slug_zwarty
    pierwszy = str(nazwa or "").split("_")[0]
    for slug in list(klienci_studia()) + [x.name for x in (KATALOG / "klienci").iterdir()] if (KATALOG / "klienci").exists() else klienci_studia():
        if slug_zwarty(slug) == pierwszy or slug_zwarty(nazwa_klienta(slug)) == pierwszy:
            return slug
    return ""


def _tytul_z_nazwy(nazwa):
    cz = str(nazwa or "").split("_")
    if len(cz) >= 3 and re.fullmatch(r"\d{6}", cz[-1]):
        return " ".join(cz[1:-1]) + f" {cz[-1][0:2]}.{cz[-1][2:4]}"
    return str(nazwa or "zadanie").replace("_", " ")


def biblioteka(rodz):
    """Biblioteka\\Muzyka itd. pod starym adresem programu (muzyka/, envato/, stock/, stock_reczny/)."""
    link = KATALOG / rodz
    cel = biblioteka_root() / BIBLIOTEKA[rodz]
    if not os.path.lexists(link):
        polacz(link, cel)
    return link


# ---------- ścieżki dla Studio i panelu ----------
def w_danych(p):
    """Czy ścieżka leży w folderze danych (Klienci albo Biblioteka)."""
    try:
        rp = Path(os.path.realpath(p))
        for r in (klienci_root(), biblioteka_root()):
            rr = Path(os.path.realpath(r))
            if rp == rr or rr in rp.parents:
                return True
    except Exception:
        pass
    return False


def zadanie_z_folderu(p):
    """Folder zadania (Klienci\\NN\\Filmy|Grafika\\NN Tytuł), w którym leży plik albo folder; None, gdy to nie zadanie."""
    try:
        rp = Path(os.path.realpath(p))
        rel = rp.relative_to(Path(os.path.realpath(klienci_root())))
    except (ValueError, OSError):
        return None
    cz = rel.parts
    if len(cz) >= 3 and cz[1] in (FILMY, GRAFIKA):
        return klienci_root() / cz[0] / cz[1] / cz[2]
    return None


def folder_gotowe(baza):
    """Gdzie narzędzie ma zapisać gotowe pliki: na wierzchu zadania, gdy pliki wejściowe leżą w Assety zadania
    (nowy układ), inaczej jak dawniej <baza>/gotowe."""
    baza = Path(baza)
    if wlaczony():
        z = zadanie_z_folderu(baza)
        if z is not None:
            try:
                rel = Path(os.path.realpath(baza)).relative_to(Path(os.path.realpath(z)))
                if rel.parts and rel.parts[0] == ASSETY:
                    return z
            except ValueError:
                pass
    return baza / "gotowe"


def stan():
    u = ustawienia()
    return {"wlaczony": wlaczony(), "dane": str(dane()), "klienci": u.get("klienci", {}), "zadan": len(u.get("zadania", {}))}


def main():
    import argparse
    from wspolne import wynik
    ap = argparse.ArgumentParser(description="Układ folderów: Klienci, Biblioteka i stare adresy programu")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("stan")
    sub.add_parser("plan")
    p = sub.add_parser("przenies"); p.add_argument("--dane", default="")
    a = ap.parse_args()
    if a.cmd == "stan":
        wynik(**stan())
    else:
        import uklad_przenies
        if a.cmd == "plan":
            wynik(**uklad_przenies.plan())
        else:
            wynik(**uklad_przenies.przenies(a.dane or None))


if __name__ == "__main__":
    main()
