"use strict";
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const N = window.nada;

function stan(t, klasa) { const s = $("stan"); s.hidden = !t; s.className = "stan " + (klasa || ""); s.textContent = t || ""; }
N.naPostep((t) => stan(t + "…"));

document.querySelectorAll("nav button").forEach((b) => (b.onclick = () => {
  document.querySelectorAll("nav button").forEach((x) => x.classList.toggle("wybrana", x === b));
  document.querySelectorAll("main > section").forEach((s) => (s.hidden = s.id !== "zak-" + b.dataset.zak));
  stan("");
}));

async function zajety(przycisk, f) {
  document.querySelectorAll("button").forEach((b) => (b.disabled = true));
  try { await f(); } finally { document.querySelectorAll("button").forEach((b) => (b.disabled = false)); }
}

async function odswiezStan() {
  const s = await N.stan();
  $("projekt").textContent = s.dv && s.dv.projekt ? s.dv.projekt + (s.dv.os ? " · " + s.dv.os : "") : s.dv && s.dv.blad ? s.dv.blad : "";
  if (!s.silnik) stan("Panel nie zna silnika Nada Studio. Zainstaluj panel ponownie w apce (Ustawienia apki > Panele).", "zle");
}

async function rysujWyniki() {
  const w = await N.wyniki();
  const l = (w && w.osie) || [];
  $("lista").innerHTML = l.length ? l.map((o, i) => `<div class="poz" data-i="${i}"><b title="${esc(o.plik)}">${esc(o.tytul)}</b>${o.nowa ? '<span class="nowa">NOWA</span>' : "<span></span>"}<small>${esc(new Date(o.kiedy * 1000).toLocaleString("pl-PL", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }))}</small></div>`).join("")
    : '<div class="pusto">Brak osi z ostatnich 30 dni. Zadania z Nada Studio pojawią się tu, gdy się skończą.</div>';
  $("lista").querySelectorAll(".poz").forEach((el) => (el.onclick = () => zajety(null, async () => {
    const o = l[Number(el.dataset.i)];
    stan("Wczytuję „" + o.tytul + "”…");
    const r = await N.wczytaj(o.plik, o.tytul.split(" / ").slice(-2).join(" - "));
    stan(r.ok ? "Wczytano oś: " + r.nazwa : r.blad, r.ok ? "ok" : "zle");
    rysujWyniki();
  })));
  if (w && w.ok === false) stan(w.blad, "zle");
}

$("odswiez").onclick = () => rysujWyniki();
$("wskazWynik").onclick = async () => {
  const p = await N.wskaz();
  if (!p) return;
  zajety(null, async () => { const r = await N.wczytaj(p); stan(r.ok ? "Wczytano oś: " + r.nazwa : r.blad, r.ok ? "ok" : "zle"); });
};

async function tnij(plik) {
  stan("Eksportuję oś i analizuję mowę (to potrwa: kilka minut na godzinę materiału)…");
  const r = await N.tnij({ plik, wpadki: $("wpadki").value, jezyk: $("jezyk").value, bezCiszy: $("bezCiszy").checked });
  if (!r.ok) return stan(r.blad || "Nie wyszło.", "zle");
  const w = r.wynik || {};
  stan(`Gotowe: nowa oś „${(r.os && r.os.nazwa) || ""}”.\nByło ${w.bylo_s ?? "?"} s, jest ${w.jest_s ?? "?"} s, cięć: ${w.ciec ?? "?"}, markerów: ${w.markerow ?? "?"}.` + (r.napisy ? "\nNapisy SRT są w Media Pool." : "") + (w.uwagi && w.uwagi.length ? "\nUwagi: " + w.uwagi.join("; ") : ""), "ok");
}
$("tnij").onclick = () => zajety(null, () => tnij(null));
$("tnijPlik").onclick = async () => { const p = await N.wskaz(); if (p) zajety(null, () => tnij(p)); };
$("napisy").onclick = () => zajety(null, async () => {
  stan("Eksportuję oś i rozpoznaję mowę…");
  const r = await N.napisy({ jezyk: $("jezykN").value });
  stan(r.ok ? "Gotowe: napisy SRT są w Media Pool.\n" + (r.srt || "") : r.blad, r.ok ? "ok" : "zle");
});

odswiezStan();
rysujWyniki();
