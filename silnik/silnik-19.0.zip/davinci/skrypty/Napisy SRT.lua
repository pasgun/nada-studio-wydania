-- Nada Studio: napisy SRT do otwartej osi (rozpoznawanie mowy silnikiem). Plik trafia do Media Pool.
local sciezka = debug.getinfo(1, "S").source:sub(2):match("^(.*)[/\\]")
local N = dofile(sciezka .. "/nada_wspolne.lib")
local plik, nazwa = N.eksportuj()
print("Nada Studio: rozpoznaję mowę w „" .. nazwa .. "”…")
local srt
for _, l in ipairs(N.silnik("davinci_most.py", { "napisy", "--xml", plik })) do srt = l:match("^SRT\t(.+)$") or srt end
if srt then N.importuj_pliki({ srt }); print("Gotowe: napisy SRT są w Media Pool (" .. srt .. ").") else print("Napisy nie wyszły.") end
