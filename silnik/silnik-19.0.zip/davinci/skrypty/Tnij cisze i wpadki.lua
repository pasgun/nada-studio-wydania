-- Nada Studio: cięcie ciszy i wpadek w otwartej osi. Powstaje nowa oś (oryginał zostaje) i napisy SRT w Media Pool.
-- Trwa kilka minut na godzinę materiału; w tym czasie DaVinci nie reaguje.
local sciezka = debug.getinfo(1, "S").source:sub(2):match("^(.*)[/\\]")
local N = dofile(sciezka .. "/nada_wspolne.lib")
local plik, nazwa = N.eksportuj()
print("Nada Studio: analizuję „" .. nazwa .. "”…")
local xml, srt
for _, l in ipairs(N.silnik("davinci_most.py", { "tnij", "--xml", plik })) do
  xml = l:match("^XML\t(.+)$") or xml
  srt = l:match("^SRT\t(.+)$") or srt
end
if not xml then print("Cięcie nie wyszło. Szczegóły zobaczysz w panelu Nada Studio (wersja Studio) albo w apce.") return end
local tl = N.importuj_os(xml, nazwa .. " (cięcie)")
print(tl and ("Gotowe: nowa oś „" .. nazwa .. " (cięcie)”.") or ("Nie udało się wczytać " .. xml .. ": zaimportuj ją ręcznie (Plik > Import > Timeline)."))
if srt then N.importuj_pliki({ srt }); print("Napisy SRT są w Media Pool.") end
