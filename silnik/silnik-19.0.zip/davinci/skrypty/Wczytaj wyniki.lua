-- Nada Studio: wczytuje do otwartego projektu nowe osie czasu z zadań (rolki, aftermovie, cięcia).
local sciezka = debug.getinfo(1, "S").source:sub(2):match("^(.*)[/\\]")
local N = dofile(sciezka .. "/nada_wspolne.lib")
local nowe, wszystkie = {}, 0
for _, l in ipairs(N.silnik("davinci_most.py", { "wyniki" })) do
  local p = N.pola(l)
  if p[1] == "OS" then
    wszystkie = wszystkie + 1
    if p[5] == "NOWA" then table.insert(nowe, { plik = p[2], tytul = p[3] }) end
  end
end
if #nowe == 0 then
  print("Nada Studio: brak nowych osi do wczytania (" .. wszystkie .. " już wczytanych z ostatnich 30 dni).")
else
  for i, o in ipairs(nowe) do
    if i > 5 then print("…i " .. (#nowe - 5) .. " kolejnych: uruchom skrypt jeszcze raz."); break end
    local tl = N.importuj_os(o.plik, o.tytul:gsub(" / ", " - "))
    print((tl and "Wczytano: " or "Nie udało się wczytać: ") .. o.tytul)
  end
end
