"""Mały lokalny serwer MCP „studio-rolek” dla aplikacji Claude na komputerze.

Dzięki niemu strona Studio Nadamedia, otwarta w aplikacji Claude na tym komputerze, może:
- pokazać limity Claude (5 h i tydzień, godziny odnowienia) i średnie zużycie na rodzaj zadania (narzedzia/limity.py),
- sprawdzić, które klucze API są wpisane (tylko TAK/NIE, nigdy same klucze),
- otworzyć plik kluczy (.env) w Notatniku, żebyś wkleił klucz,
- zapisać style napisów ze Studio do silnika (panel Premiere pokazuje je w galerii),
- uruchomić polecenie silnika ze Studio (przycisk „Wykonaj”) w Claude Code w tle, pokazać przebieg i przekazać Twoją odpowiedź.
Nie czyta innych plików i niczego nie wysyła.

  python narzedzia/mcp_studio.py --instaluj     (raz: dopisuje serwer do ustawień aplikacji Claude; potem zrestartuj aplikację)
  python narzedzia/mcp_studio.py --odinstaluj
"""
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

KATALOG = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(Path(__file__).resolve().parent))
import sciezki  # noqa: E402,F401  programy z apki Nada Studio w PATH
NAZWA = "studio-rolek"
KLUCZE = [
    ("ELEVENLABS_API_KEY", "ElevenLabs", "lektor, rozpoznawanie mowy, czysty dźwięk, dubbing", "elevenlabs.io → Developers → API Keys"),
    ("GEMINI_API_KEY", "Gemini", "obrazy AI", "aistudio.google.com → Get API key"),
    ("MAGNIFIC_API_KEY", "Magnific (Freepik)", "stock zdjęć i ujęć wideo", "magnific.com → organizacja → API keys"),
    ("HIGGSFIELD_API_KEY", "Higgsfield", "wideo AI (drogie, opcjonalnie)", "open.higgsfield.ai → API keys"),
    ("EPIDEMIC_SOUND_MCP_API_KEY", "Epidemic Sound", "muzyka i efekty (połączenie dla Claude Code i Gemini)", "epidemicsound.com/account/api-keys (Konto → API keys, nie Developer Portal)"),
]

NARZEDZIA = [
    {"name": "limity", "description": "Limity planu Claude (okno 5-godzinne i tygodniowe, procent zużycia, godzina odnowienia) i średnie zużycie limitu tygodniowego na rodzaj zadania.",
     "inputSchema": {"type": "object", "properties": {}}, "annotations": {"readOnlyHint": True}},
    {"name": "klucze_stan", "description": "Które klucze API silnika są wpisane w pliku .env (tylko tak/nie, bez wartości). test=true: dodatkowo sprawdza w usługach, czy klucze działają (wynik zapamiętany na kilka godzin; swiezy=true wymusza nowe sprawdzenie).",
     "inputSchema": {"type": "object", "properties": {"test": {"type": "boolean"}, "swiezy": {"type": "boolean"}}}, "annotations": {"readOnlyHint": True}},
    {"name": "otworz_klucze", "description": "Otwiera plik kluczy API (.env) silnika w edytorze tekstu na tym komputerze.",
     "inputSchema": {"type": "object", "properties": {}}},
    {"name": "wykonaj", "description": "Uruchamia w tle Claude Code w folderze silnika z poleceniem ze Studio (np. /rolka {...}). Tylko polecenia silnika (/rolka, /grafika, /napisy...). Zwraca id zlecenia.",
     "inputSchema": {"type": "object", "properties": {"polecenie": {"type": "string"}, "nazwa": {"type": "string"}, "mozg": {"type": "string", "enum": ["claude", "gemini"]}}, "required": ["polecenie"]}},
    {"name": "zlecenia_stan", "description": "Zlecenia uruchomione ze Studio i zadania z panelu Premiere (Claude i Gemini): stan (trwa, czeka na odpowiedź albo zgodę, gotowe, błąd), ostatnia czynność i wynik.",
     "inputSchema": {"type": "object", "properties": {}}, "annotations": {"readOnlyHint": True}},
    {"name": "zlecenie_log", "description": "Przebieg jednego zlecenia: wiadomości Claude, kroki i odpowiedzi użytkownika. id=\"wyniki\" (z klient, projekt, zadanie_id): pliki, które powstały w zadaniu ze Studio. id=\"podglad\" (z sciezka, rodzaj miniatura|obraz|wideo, czesc): podgląd jednego pliku wyników kawałkami.",
     "inputSchema": {"type": "object", "properties": {"id": {"type": "string"}, "klient": {"type": "string"}, "projekt": {"type": "string"}, "zadanie_id": {"type": "string"},
                                                     "sciezka": {"type": "string"}, "rodzaj": {"type": "string", "enum": ["miniatura", "obraz", "wideo"]}, "czesc": {"type": "integer"}}, "required": ["id"]},
     "annotations": {"readOnlyHint": True}},
    {"name": "zlecenie_odpowiedz", "description": "Odpowiedź użytkownika dla zlecenia, które czeka (albo dopisanie poprawki do skończonego): wznawia tę samą rozmowę. zgoda=zezwol daje Gemini zgodę na odrzucone polecenia, zgoda=okno otwiera rozmowę w oknie PowerShell.",
     "inputSchema": {"type": "object", "properties": {"id": {"type": "string"}, "tekst": {"type": "string"}, "zgoda": {"type": "string", "enum": ["zezwol", "okno"]}}, "required": ["id", "tekst"]}},
    {"name": "zlecenie_zatrzymaj", "description": "Zatrzymuje trwające zlecenie. ukryj=true usuwa je też z listy w Studio (pliki zostają na dysku).",
     "inputSchema": {"type": "object", "properties": {"id": {"type": "string"}, "ukryj": {"type": "boolean"}}, "required": ["id"]}},
    {"name": "zapisz_style_napisow", "description": "Zapisuje style napisów zapisane w Studio do silnika (narzedzia/napisy_style_moje.json), żeby panel Premiere pokazał je w galerii.",
     "inputSchema": {"type": "object", "properties": {"style": {"type": "array", "items": {"type": "object", "properties": {"nazwa": {"type": "string"}, "styl": {"type": "object"}}}}}, "required": ["style"]}},
]


def _sys(nazwa):
    """Pliki silnika w _system/<nazwa> (stary wyniki/_<nazwa> przenosi się sam przy pierwszym użyciu)."""
    try:
        sys.path.insert(0, str(KATALOG / "narzedzia"))
        import porzadek
        return porzadek.system(nazwa)
    except Exception:
        p = KATALOG / "_system" / nazwa
        p.mkdir(parents=True, exist_ok=True)
        return p


TEST_KLUCZY = _sys("studio") / "klucze_test.json"


def _test_klucza(zmienna, wartosci):
    """Lekkie zapytanie do usługi (nic nie kosztuje). Zwraca stan: dziala / odrzucony / blad_sieci / nieznany, bez wartości klucza."""
    import requests
    k = wartosci.get(zmienna, "")
    try:
        if zmienna == "ELEVENLABS_API_KEY":
            r = requests.get("https://api.elevenlabs.io/v1/user/subscription", headers={"xi-api-key": k}, timeout=20)
            if r.ok:
                d = r.json()
                uzyte, limit = d.get("character_count") or 0, d.get("character_limit") or 0
                return {"stan": "dziala", "info": f"znaki: {uzyte:,} z {limit:,}".replace(",", " ") if limit else None,
                        "zuzycie": round(uzyte / limit, 3) if limit else None, "odnowienie": d.get("next_character_count_reset_unix")}
        elif zmienna == "GEMINI_API_KEY":
            r = requests.get("https://generativelanguage.googleapis.com/v1beta/models", headers={"x-goog-api-key": k}, params={"pageSize": 1}, timeout=20)
        elif zmienna == "MAGNIFIC_API_KEY":
            host = os.environ.get("FREEPIK_HOST", "https://api.magnific.com").rstrip("/")
            r = requests.get(f"{host}/v1/videos", params={"term": "office"}, headers={"x-magnific-api-key": k, "x-freepik-api-key": k}, timeout=20)
            if r.status_code == 400:
                return {"stan": "dziala"}
        elif zmienna == "HIGGSFIELD_API_KEY":
            kk = k or (wartosci.get("HIGGSFIELD_KEY_ID", "") + ":" + wartosci.get("HIGGSFIELD_KEY_SECRET", ""))
            r = requests.get("https://api.higgsfield.ai/requests/00000000-0000-0000-0000-000000000000/status", headers={"Authorization": f"Key {kk}"}, timeout=20)
            return {"stan": "odrzucony" if r.status_code in (401, 403) else "dziala"}
        elif zmienna == "EPIDEMIC_SOUND_MCP_API_KEY":
            r = requests.post("https://www.epidemicsound.com/a/mcp-service/mcp", timeout=20,
                              headers={"Authorization": f"Bearer {k}", "Content-Type": "application/json", "Accept": "application/json, text/event-stream"},
                              json={"jsonrpc": "2.0", "id": 1, "method": "initialize",
                                    "params": {"protocolVersion": "2025-06-18", "capabilities": {}, "clientInfo": {"name": "nada-studio", "version": "1"}}})
        else:
            return {"stan": "nieznany"}
        if r.ok:
            return {"stan": "dziala"}
        if r.status_code in (401, 403):
            return {"stan": "odrzucony", "info": f"kod błędu {r.status_code}"}
        if r.status_code == 429:
            return {"stan": "dziala", "info": "usługa prosi o chwilę przerwy (za dużo zapytań)"}
        if r.status_code == 402:
            return {"stan": "odrzucony", "info": "brak środków albo nieopłacony plan (402)"}
        return {"stan": "nieznany", "info": f"odpowiedź {r.status_code}"}
    except Exception as e:
        return {"stan": "blad_sieci", "info": e.__class__.__name__}


def klucze_stan(test=False, swiezy=False):
    if test:
        try:
            stare = json.loads(TEST_KLUCZY.read_text(encoding="utf-8"))
        except Exception:
            stare = {}
        if swiezy or time.time() - stare.get("kiedy", 0) > 6 * 3600:
            w = _wartosci_env()
            wyniki = {}
            for zm, *_ in KLUCZE:
                if w.get(zm) or (zm == "HIGGSFIELD_API_KEY" and w.get("HIGGSFIELD_KEY_ID")):
                    wyniki[zm] = _test_klucza(zm, w)
            stare = {"kiedy": time.time(), "wyniki": wyniki}
            TEST_KLUCZY.parent.mkdir(parents=True, exist_ok=True)
            TEST_KLUCZY.write_text(json.dumps(stare, ensure_ascii=False, indent=1), encoding="utf-8")
        d = klucze_stan()
        for k in d["klucze"]:
            k.update(stare.get("wyniki", {}).get(k["zmienna"]) or {})
        d["sprawdzono"] = stare.get("kiedy")
        return d
    env = KATALOG / ".env"
    wpisane = set()
    if env.exists():
        for linia in env.read_text(encoding="utf-8", errors="replace").splitlines():
            linia = linia.strip()
            if linia and not linia.startswith("#") and "=" in linia:
                k, v = linia.split("=", 1)
                if v.strip():
                    wpisane.add(k.strip())
    return {"plik_istnieje": env.exists(), "klucze": [{"zmienna": k, "usluga": n, "do_czego": d, "skad": s, "wpisany": k in wpisane} for k, n, d, s in KLUCZE]}


def _wartosci_env():
    """Wartości z .env tylko do sprawdzenia w usługach; nigdy nie są zwracane ani zapisywane."""
    w = {}
    env = KATALOG / ".env"
    if env.exists():
        for linia in env.read_text(encoding="utf-8", errors="replace").splitlines():
            linia = linia.strip()
            if linia and not linia.startswith("#") and "=" in linia:
                k, v = linia.split("=", 1)
                w[k.strip()] = v.strip().strip('"').strip("'")
    return w


def zapisz_style_napisow(style):
    """Tylko nazwa i styl (słownik prostych wartości), najwyżej 200 stylów: nic innego nie trafia na dysk."""
    czyste = []
    for i, x in enumerate((style or [])[:200]):
        if not isinstance(x, dict) or not isinstance(x.get("styl"), dict):
            continue
        st = {k: v for k, v in x["styl"].items() if isinstance(k, str) and len(k) < 40 and isinstance(v, (str, int, float, bool, list)) and len(str(v)) < 200}
        czyste.append({"id": f"studio-{i + 1}", "nazwa": str(x.get("nazwa") or f"Mój styl {i + 1}")[:60], "grupa": "Moje (Studio)", "styl": st})
    plik = KATALOG / "narzedzia" / "napisy_style_moje.json"
    plik.write_text(json.dumps({"opis": "Style napisów zapisane w Studio (nadpisywane przy każdej zmianie w Studio).", "style": czyste}, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"zapisano": len(czyste), "plik": str(plik)}


# ---------- zlecenia ze Studio („Wykonaj”): Claude Code w tle, bez kopiowania poleceń ----------
ZLECENIA = _sys("studio")
POLECENIA = {"rolka", "grafika", "aftermovie", "napisy", "ciecie", "transkrypcja", "pion", "miniatury", "dzwiek", "tlumaczenie",
             "formaty", "brandbook", "multicam", "animacje", "jak-wzor"}
NARZEDZIA_CLAUDE = ["Bash(python narzedzia/*)", "Bash(python3 narzedzia/*)", "Bash(node narzedzia/*)", "Bash(ffmpeg *)", "Bash(ffprobe *)",
                    "PowerShell(python narzedzia/*)", "PowerShell(ffmpeg *)", "PowerShell(ffprobe *)", "Read", "Write", "Edit", "Glob", "Grep",
                    "mcp__magnific", "mcp__epidemic-sound", "mcp__artlist"]
PREAMBULA = ("Zadanie uruchomione przyciskiem „Wykonaj” w Studio. Użytkownik czyta Twoje odpowiedzi w zakładce Claude w Studio i może odpisać. "
             "Gdy potrzebujesz jego decyzji, zgody albo informacji (np. plan przed wydawaniem pieniędzy), napisz pytanie na końcu odpowiedzi "
             "i zakończ ją znacznikiem [CZEKAM]. Gdy wszystko jest skończone, zakończ znacznikiem [GOTOWE]. Etapy raportuj przez narzedzia/postep.py.\n\n")


def sciezka_agy():
    """Antigravity CLI (Gemini z logowaniem kontem Google: zużywa limity abonamentu Google AI Pro, bez kluczy API)."""
    w = os.environ.get("NM_AGY") or shutil.which("agy") or ""
    if not w and sys.platform.startswith("win"):
        for k in (Path(os.environ.get("LOCALAPPDATA", "")) / "agy" / "bin" / "agy.exe", Path(os.environ.get("LOCALAPPDATA", "")) / "agy" / "bin" / "agy.cmd",
                  Path.home() / ".local" / "bin" / "agy.exe", Path(os.environ.get("LOCALAPPDATA", "")) / "Programs" / "agy" / "agy.exe",
                  Path(os.environ.get("LOCALAPPDATA", "")) / "antigravity-cli" / "agy.exe", Path.home() / ".antigravity" / "bin" / "agy.exe"):
            if k.exists():
                w = str(k)
                break
    return w


def ustawienia_mozgu():
    try:
        return json.loads((KATALOG / "narzedzia" / "mozg_ustawienia.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


# tryb pracy Gemini w tle (ustawiany po teście: python narzedzia/mozg.py tryb ...)
TRYBY_AGY = {"accept-edits": ["--mode", "accept-edits"], "piaskownica": ["--mode", "accept-edits", "--sandbox"]}  # tryb auto nie jest dostępny na koncie


def flagi_agy():
    u = ustawienia_mozgu()
    f = list(TRYBY_AGY.get(u.get("tryb"), TRYBY_AGY["accept-edits"]))
    if u.get("pelne_uprawnienia"):
        f.append("--dangerously-skip-permissions")
    return f


def sciezka_claude():
    w = os.environ.get("NM_CLAUDE") or shutil.which("claude") or ""
    if not w and sys.platform.startswith("win"):
        for k in (Path.home() / ".local" / "bin" / "claude.exe", Path(os.environ.get("APPDATA", "")) / "npm" / "claude.cmd"):
            if k.exists():
                w = str(k)
                break
    if not w:
        raise ValueError("Nie znalazłem Claude Code na tym komputerze (polecenie claude). Zainstaluj go i otwórz aplikację Claude ponownie.")
    return w


def _log_plik(kat):
    """Zlecenia ze Studio piszą log.jsonl, zadania z panelu Premiere claude_log.jsonl.
    (Starsze zlecenia ze Studio mają claude_log.jsonl, bo log powstawał przed stan.json: czytamy ten, który jest.)"""
    a, b = Path(kat) / "log.jsonl", Path(kat) / "claude_log.jsonl"
    if a.exists() and b.exists():
        return a if a.stat().st_mtime >= b.stat().st_mtime else b
    if a.exists() or b.exists():
        return a if a.exists() else b
    try:
        ze_studio = Path(kat).resolve().parent == ZLECENIA.resolve()
    except Exception:
        ze_studio = False
    return a if ze_studio or (Path(kat) / "stan.json").exists() else b


def _uruchom_claude(kat, tekst, sesja=None, mozg="claude"):
    log = _log_plik(kat)
    with open(log, "a", encoding="utf-8") as f:
        f.write(json.dumps({"type": "nada_start", "kiedy": time.time(), "tekst": tekst[:4000], "mozg": mozg}, ensure_ascii=False) + "\n")
    if mozg == "gemini":
        agy = sciezka_agy()
        if not agy:
            raise ValueError("Nie znalazłem Antigravity CLI (agy). Zainstaluj go i zaloguj się kontem Google: python narzedzia\\mozg.py instaluj")
        # polecenie w pliku: długi tekst z JSON-em nie przejdzie bezpiecznie przez wiersz poleceń Windows
        nr = len(list(kat.glob("polecenie_*.md"))) + 1
        plik = kat / f"polecenie_{nr}.md"
        prosba = (kat / "polecenie_gemini.json").relative_to(KATALOG).as_posix()
        plik.write_text("WAŻNE: pracujesz w tle i nikt nie kliknie „Zezwól”. W terminalu uruchamiasz TYLKO polecenie `python narzedzia/uruchom.py` (dokładnie tak). "
                        f"Każde narzędzie silnika (python narzedzia/X.py, ffmpeg, ffprobe) uruchamiasz tak: zapisz plik {prosba} z prośbą "
                        '{"narzedzie": "X.py", "argumenty": ["--opcja", "wartość"]}, potem python narzedzia/uruchom.py. Szczegóły w AGENTS.md.\n\n' + tekst, encoding="utf-8")
        rel = plik.relative_to(KATALOG).as_posix()
        args = [agy, "-p", f"Przeczytaj plik {rel} i wykonaj dokładnie to, co jest w nim napisane. Zasady pracy są w CLAUDE.md (dotyczą też Ciebie).",
                "--output-format", "stream-json", *flagi_agy(), "--print-timeout", "4h"]
        if sesja:
            args += ["--conversation", sesja] if sesja != "ostatnia" else ["--continue"]
        tekst = ""
    else:
        args = [sciezka_claude(), "-p", "--output-format", "stream-json", "--verbose", "--permission-mode", "acceptEdits", "--allowedTools", *NARZEDZIA_CLAUDE]
        if sesja:
            args += ["--resume", sesja]
    if args[0].lower().endswith((".cmd", ".bat")):
        args = ["cmd", "/c", *args]
    flagi = 0
    if sys.platform.startswith("win"):
        # ukryta konsola (CREATE_NO_WINDOW, bez DETACHED): program i polecenia, które sam uruchamia, nie otwierają okien; osobna grupa procesów
        flagi = 0x00000200 | 0x08000000
    wyj = open(log, "ab")
    p = subprocess.Popen(args, cwd=str(KATALOG), stdin=subprocess.PIPE, stdout=wyj, stderr=wyj, creationflags=flagi,
                         env=dict(os.environ, PYTHONIOENCODING="utf-8", NM_POSTEP=str(kat / "postep.json")))
    if tekst:
        p.stdin.write(tekst.encode("utf-8"))
    p.stdin.close()
    return p.pid


def zyje(pid):
    if not pid:
        return False
    try:
        if sys.platform.startswith("win"):
            r = subprocess.run(["tasklist", "/FI", f"PID eq {int(pid)}", "/NH", "/FO", "CSV"], capture_output=True, text=True, timeout=5, creationflags=0x08000000)
            return f'"{int(pid)}"' in r.stdout
        os.kill(int(pid), 0)
        try:
            w = os.waitpid(int(pid), os.WNOHANG)
            return w == (0, 0)
        except ChildProcessError:
            return True
    except Exception:
        return False


def _stan_plik(kat):
    try:
        return json.loads((kat / "stan.json").read_text(encoding="utf-8"))
    except Exception:
        pass
    # zadanie z panelu Premiere (aftermovie, animacje z opisu...)
    if not (kat / "claude_log.jsonl").exists():
        return {}
    try:
        zp = json.loads((kat / "proces_panelu.json").read_text(encoding="utf-8"))
    except Exception:
        try:
            zp = json.loads((kat / "zadanie_panel.json").read_text(encoding="utf-8"))  # starsze zadania
            zp = {"nazwa": zp.get("tytul") or zp.get("nazwa"), "mozg": zp.get("mozg"), "pid": zp.get("pid"), "start": zp.get("start"), "typ": zp.get("typ")}
        except Exception:
            zp = {}
    try:
        pocz = (kat / "claude_log.jsonl").read_text(encoding="utf-8", errors="replace")[:3000]
    except Exception:
        pocz = ""
    mozg = zp.get("mozg") or ("gemini" if '"event"' in pocz else "claude")
    start = (zp.get("start") or 0) / 1000 or (kat / "claude_log.jsonl").stat().st_ctime
    return {"id": _panel_id(kat), "nazwa": zp.get("nazwa") or kat.name, "rodzaj": zp.get("typ") or "panel", "start": start,
            "pid": zp.get("pid"), "mozg": mozg, "panel": True, "przerwane": zp.get("przerwane"), "okno": zp.get("okno")}


def _zapisz_stan(kat, st):
    if not st.get("panel"):
        (kat / "stan.json").write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")
        return
    try:
        zp = json.loads((kat / "proces_panelu.json").read_text(encoding="utf-8"))
    except Exception:
        zp = {"nazwa": st.get("nazwa"), "typ": st.get("rodzaj"), "mozg": st.get("mozg"), "start": int(st.get("start", 0) * 1000)}
    zp.update(pid=st.get("pid"), kiedy=int(time.time() * 1000), przerwane=st.get("przerwane"), okno=st.get("okno"))
    (kat / "proces_panelu.json").write_text(json.dumps(zp, ensure_ascii=False, indent=1), encoding="utf-8")


def plik_zgod_agy():
    return Path.home() / ".gemini" / "antigravity-cli" / "settings.json"


def _zgoda(kat):
    """Gemini w tle nie może kliknąć „Zezwól”: odrzucone polecenia i zapis pliku, który wisi (czeka na zgodę)."""
    log = _log_plik(kat)
    try:
        linie = log.read_text(encoding="utf-8", errors="replace").splitlines()
        wiek = time.time() - log.stat().st_mtime
    except Exception:
        return None
    odmowy, ostatni = [], None
    for l in linie:
        try:
            d = json.loads(l)
        except Exception:
            continue
        if not isinstance(d, dict):
            continue
        if d.get("event") == "init":
            odmowy, ostatni = [], None
            continue
        su = d.get("step_update") if d.get("event") == "step_update" else None
        if not isinstance(su, dict):
            continue
        ti = su.get("tool_info") or {}
        par = ti.get("parameters") or {}
        bl = str((ti.get("error") or {}).get("message") or "")
        if su.get("step_type") == "tool" and su.get("state") == "ERROR" and ("denied permission" in bl or "permission check failed" in bl):
            import re as _re
            m = _re.search(r'for mcp "([^"]+)"', bl) or _re.search(r"mcp\(([^)]+)\)", bl)
            c = ("mcp:" + m.group(1)) if m else par.get("CommandLine")
            if c and c not in odmowy:
                odmowy.append(c)
        if su.get("step_type") == "tool":
            ostatni = (su.get("state"), su.get("tool_name") or "", str(par.get("CommandLine") or par.get("Path") or par.get("TargetFile") or ""))
        elif su.get("state") in ("DONE", "ACTIVE"):
            ostatni = None
    import re
    wisi = None
    if ostatni and ostatni[0] == "ACTIVE" and re.search(r"write|replace|edit|delete|move|create", ostatni[1], re.I) and wiek > 60:
        wisi = "zapis pliku " + re.split(r"[\\/]", ostatni[2])[-1]
    return {"odmowy": odmowy, "wisi": wisi} if odmowy or wisi else None


def dodaj_zgody_agy(polecenia):
    p = plik_zgod_agy()
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        d = {}
    lista = d.setdefault("permissions", {}).setdefault("allow", [])
    wzor = ustawienia_mozgu().get("wzor_zgody") or "{} *"
    for c in polecenia:
        t = c.split()
        if c.startswith("mcp:"):
            # narzędzie połączenia: zgoda na nie i na wszystkie narzędzia tego połączenia, które zna Antigravity
            serwer = c[4:].split("/")[0]
            reguly = [f"mcp({c[4:]})"] + [f"mcp({serwer}/{x.stem})" for x in sorted((p.parent / "mcp" / serwer).glob("*.json"))]
        else:
            reguly = [f"command({c})"] + ([f"command({wzor.format(' '.join(t[:2]))})"] if len(t) > 2 else [])
        for r in reguly:
            if r not in lista:
                lista.append(r)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")


def _zabij(pid):
    if not pid:
        return
    try:
        if sys.platform.startswith("win"):
            subprocess.run(["taskkill", "/PID", str(pid), "/T", "/F"], capture_output=True, creationflags=0x08000000)
        else:
            os.kill(int(pid), 15)
    except Exception:
        pass


def _gemini_w_oknie(kat, sesja, prompt):
    """Ta sama rozmowa z Gemini w widocznym oknie PowerShell: tam zatwierdzasz zgody (najlepiej „zawsze”)."""
    agy = sciezka_agy()
    if not agy or not sesja or sesja == "ostatnia":
        raise ValueError("Nie mogę otworzyć tej rozmowy z Gemini w oknie (brak numeru rozmowy).")
    if not sys.platform.startswith("win"):
        raise ValueError("Okno Gemini działa tylko w Windows.")
    q = lambda x: "'" + str(x).replace("'", "''") + "'"
    ps1 = kat / "gemini_okno.ps1"
    ps1.write_text("\ufeff" + "\r\n".join([
        f"$env:NM_POSTEP = {q(kat / 'postep.json')}", f"Set-Location -LiteralPath {q(KATALOG)}",
        "Write-Host 'Gemini: zatwierdzaj tu zgody (najlepiej na zawsze). Po skończeniu zadania możesz zamknąć to okno.' -ForegroundColor Yellow",
        f"& {q(agy)} --conversation {q(sesja)} -i {q(prompt)}"]), encoding="utf-8")
    subprocess.Popen(["cmd", "/c", "start", "Gemini", "powershell.exe", "-NoExit", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(ps1)],
                     cwd=str(KATALOG), creationflags=0x00000008 | 0x00000200)


def wykonaj(polecenie, nazwa=None, mozg="claude"):
    mozg = "gemini" if mozg == "gemini" else "claude"
    polecenie = str(polecenie or "").strip()
    import re
    m = re.match(r"^/([a-z-]+)\s", polecenie + " ")
    if not m or m.group(1) not in POLECENIA:
        raise ValueError("Wykonuję tylko polecenia silnika ze Studio (/rolka, /grafika, /napisy...).")
    skill = KATALOG / ".claude" / "skills" / m.group(1) / "SKILL.md"
    tekst = PREAMBULA + (f"Przeczytaj plik .claude/skills/{m.group(1)}/SKILL.md i wykonaj go dokładnie dla tego zadania:\n\n{polecenie}" if skill.exists() else polecenie)
    zid = time.strftime("%y%m%d-%H%M%S") + "-" + m.group(1)
    kat = ZLECENIA / zid
    kat.mkdir(parents=True, exist_ok=True)
    pid = _uruchom_claude(kat, tekst, None, mozg)
    mz = re.search(r'"id"\s*:\s*"([^"]+)"', polecenie)
    stan = {"id": zid, "nazwa": (nazwa or m.group(1))[:120], "polecenie": polecenie[:20000], "rodzaj": m.group(1), "start": time.time(), "pid": pid, "mozg": mozg,
            "zadanie_id": mz.group(1) if mz else None}
    (kat / "stan.json").write_text(json.dumps(stan, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"id": zid, "nazwa": stan["nazwa"]}


def _czytaj_log(kat):
    wpisy, sesja, wynik_ost, ostatnio, start_ost, koszt = [], None, None, "", 0, 0.0
    try:
        linie = _log_plik(kat).read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        linie = []
    for l in linie:
        try:
            d = json.loads(l)
        except Exception:
            if l.strip():
                wpisy.append({"kto": "krok", "tekst": l.strip()[:300]})
            continue
        if not isinstance(d, dict):
            continue
        for k in ("session_id", "sessionId", "conversation_id", "conversationId"):
            if isinstance(d.get(k), str) and d[k]:
                sesja = d[k]
        t = d.get("type")
        if t is None and isinstance(d.get("event"), str):
            # Antigravity CLI: {"event": "step_update", "step_update": {...}}
            ev = d["event"]
            wew = d.get(ev) if isinstance(d.get(ev), dict) else {}
            for k in ("conversation_id", "conversationId"):
                if isinstance(wew.get(k), str) and wew[k]:
                    sesja = wew[k]
            if ev == "step_update":
                ti = wew.get("tool_info") or {}
                par = ti.get("parameters") or {}
                nazwa = wew.get("tool_name") or ti.get("name") or ""
                if wew.get("step_type") == "tool" and wew.get("state") == "ACTIVE":
                    co = par.get("CommandLine") or par.get("Path") or par.get("Url") or par.get("Query") or ""
                    opis = ("Czyta: " if "read" in nazwa or "view" in nazwa or "list" in nazwa else "Pisze: " if "write" in nazwa or "replace" in nazwa else "Uruchamia: ") + str(co or nazwa).replace("\n", " ")[:140]
                    wpisy.append({"kto": "krok", "tekst": opis})
                    ostatnio = opis
                elif wew.get("state") == "ERROR":
                    bl = (ti.get("error") or {}).get("message") or wew.get("error") or "błąd"
                    opis = f"Błąd w {nazwa or 'kroku'}: " + str(bl).split("\n")[0][:200]
                    wpisy.append({"kto": "krok", "tekst": opis})
                    ostatnio = opis
                tekst = next((wew[k] for k in ("text", "response", "content", "message") if isinstance(wew.get(k), str) and wew[k].strip()), "")
                if tekst and wew.get("step_type") in ("agent_response", "response", "message"):
                    wpisy.append({"kto": "claude", "tekst": tekst.strip()})
                    ostatnio = tekst.strip().replace("\n", " ")[:160]
                continue
            t = ev
            d = dict(wew, **{k: v for k, v in d.items() if k != ev})
        if t not in ("nada_start", "assistant", "result", "system", "user") and t is not None or (t is None and ("response" in d or "result" in d)):
            # inny format (Antigravity CLI): wyciągamy tekst, kroki i wynik z tego, co jest
            tt = str(t or "").lower()
            tekst = next((d[k] for k in ("text", "content", "message", "delta") if isinstance(d.get(k), str) and d[k].strip()), "")
            if not tekst and isinstance(d.get("message"), dict):
                tekst = next((d["message"][k] for k in ("text", "content") if isinstance(d["message"].get(k), str)), "")
            if "tool" in tt or "command" in tt or "function" in tt:
                nazwa = d.get("name") or d.get("tool") or (d.get("tool_call") or {}).get("name") or tt
                arg = d.get("input") or d.get("args") or d.get("arguments") or {}
                co = arg.get("command") if isinstance(arg, dict) else arg
                opis = f"Uruchamia: {str(co or nazwa)[:140]}".replace("\n", " ")
                if "result" not in tt and "output" not in tt:
                    wpisy.append({"kto": "krok", "tekst": opis}); ostatnio = opis
            elif tt in ("result", "final", "done", "complete", "completed", "response", "end") or (t is None and ("response" in d or "result" in d)):
                wyn_tekst = d.get("result") if isinstance(d.get("result"), str) else d.get("response") if isinstance(d.get("response"), str) else tekst
                wynik_ost = {"type": "result", "subtype": "error" if d.get("is_error") or d.get("error") else "success", "result": wyn_tekst or ""}
                if wyn_tekst and not (wpisy and wpisy[-1]["kto"] == "claude" and wpisy[-1]["tekst"] == wyn_tekst.strip()):
                    wpisy.append({"kto": "claude", "tekst": wyn_tekst.strip()})
            elif tekst and ("assistant" in tt or "model" in tt or "agent" in tt or "message" in tt or "text" in tt):
                if wpisy and wpisy[-1]["kto"] == "claude" and "delta" in tt:
                    wpisy[-1]["tekst"] += tekst
                else:
                    wpisy.append({"kto": "claude", "tekst": tekst.strip()})
                ostatnio = tekst.strip().replace("\n", " ")[:160]
            elif "error" in tt:
                wpisy.append({"kto": "krok", "tekst": "Błąd: " + str(tekst or d.get("error") or "")[:300]})
            continue
        if t == "nada_start":
            start_ost, wynik_ost = len(wpisy) + 1, None
            tx = d.get("tekst", "")
            if tx.startswith(PREAMBULA[:30]) and "\n\n" in tx:
                tx = tx.split("\n\n", 1)[1]
            elif tx.startswith("Odpowiedź użytkownika do tego zlecenia") and "\n\n" in tx:
                tx = tx.split("\n\n", 1)[1].split("\n\nPamiętaj:", 1)[0]
            wpisy.append({"kto": "ty", "tekst": tx, "kiedy": d.get("kiedy")})
        elif t == "assistant":
            for c in (d.get("message") or {}).get("content") or []:
                if c.get("type") == "text" and c.get("text", "").strip():
                    wpisy.append({"kto": "claude", "tekst": c["text"].strip()})
                    ostatnio = c["text"].strip().replace("\n", " ")[:160]
                elif c.get("type") == "tool_use":
                    i = c.get("input") or {}
                    co = i.get("command") or i.get("file_path") or i.get("pattern") or i.get("description") or ""
                    nazwa = c.get("name", "")
                    opis = ("Czyta: " if nazwa == "Read" else "Pisze: " if nazwa in ("Write", "Edit") else "Uruchamia: ") + str(co).replace("\n", " ")[:140]
                    wpisy.append({"kto": "krok", "tekst": opis})
                    ostatnio = opis
        elif t == "result":
            if not isinstance(d.get("result"), str) and isinstance(d.get("response"), str):
                d = dict(d, result=d["response"])
                if d["result"].strip() and not (wpisy and wpisy[-1]["kto"] == "claude" and wpisy[-1]["tekst"] == d["result"].strip()):
                    wpisy.append({"kto": "claude", "tekst": d["result"].strip()})
            wynik_ost = d
            koszt += float(d.get("total_cost_usd") or 0)
    return wpisy, sesja, wynik_ost, ostatnio, koszt


ZAWIESZONE_PO = 24 * 3600
_OPISY = {}   # pamięć opisów skończonych zleceń (żeby lista wszystkich zleceń nie czytała co chwilę wszystkich logów)


def _podpis(kat):
    out = []
    for n in ("log.jsonl", "claude_log.jsonl", "postep.json", "stan.json", "proces_panelu.json"):
        try:
            out.append((kat / n).stat().st_mtime)
        except OSError:
            out.append(0)
    return tuple(out)


def _opis(kat):
    """Opis zlecenia do listy w Console; skończone (gotowe, zawieszone, stary błąd) brane z pamięci, dopóki pliki się nie zmienią."""
    pod = _podpis(kat)
    pam = _OPISY.get(str(kat))
    if pam and pam[0] == pod:
        return pam[1]
    o = _opis_licz(kat)
    if o and (o["stan"] in ("gotowe", "zawieszone", "przerwane") or (o["stan"] == "blad" and time.time() - (o.get("zmiana") or 0) > 3600)):
        _OPISY[str(kat)] = (pod, o)
    else:
        _OPISY.pop(str(kat), None)
    return o


def _opis_licz(kat):
    st = _stan_plik(kat)
    if not st:
        return None
    wpisy, sesja, wyn, ostatnio, koszt = _czytaj_log(kat)
    try:
        zmiana = _log_plik(kat).stat().st_mtime
    except Exception:
        zmiana = st.get("start", 0)
    postep = {}
    try:
        postep = json.loads((kat / "postep.json").read_text(encoding="utf-8"))
    except Exception:
        pass
    pid = st.get("pid")
    # długi krok (np. analiza setek klipów) nie pisze nic do logu, ale odświeża postęp: to też znak, że praca trwa
    swiezy_postep = time.time() - float(postep.get("aktualizacja") or 0) < 10 * 60 and postep.get("stan") not in ("gotowe", "blad")
    zywy = (zyje(pid) if pid else (st.get("panel") and time.time() - zmiana < 10 * 60)) or bool(st.get("panel") and swiezy_postep)
    if st.get("przerwane"):
        stan = "przerwane"
    elif st.get("panel") and postep.get("stan") in ("gotowe", "blad"):
        stan = postep["stan"]
        if wyn is None:
            wyn = {"type": "result", "subtype": "success", "result": postep.get("tekst") or ""}
    elif st.get("okno") and postep.get("stan") not in ("gotowe", "blad"):
        stan = "trwa"
        ostatnio = "Gemini pracuje w oknie PowerShell (tam zatwierdzasz zgody)"
    elif wyn is None:
        if (time.time() - zmiana < 45 * 60 or swiezy_postep) and zywy:
            stan = "trwa"
        else:
            # proces się skończył, a format nie dał osobnego wyniku: ostatnia wiadomość jest wynikiem
            ost = next((w["tekst"] for w in reversed(wpisy) if w["kto"] == "claude"), "")
            if ost:
                wyn = {"type": "result", "subtype": "success", "result": ost}
                stan = "czeka" if "[CZEKAM]" in ost or ("[GOTOWE]" not in ost and ost.rstrip().endswith("?")) else "gotowe"
            else:
                stan = "blad" if time.time() - zmiana < 45 * 60 else "przerwane"
    elif wyn.get("is_error") or wyn.get("subtype") not in (None, "success"):
        stan = "blad"
    else:
        txt = str(wyn.get("result") or "")
        stan = "czeka" if "[CZEKAM]" in txt or ("[GOTOWE]" not in txt and txt.rstrip().endswith("?")) else "gotowe"
    if st.get("panel") and stan == "gotowe" and postep.get("stan") == "trwa" and st.get("rodzaj") in ("aftermovie", "panel"):
        # zadanie z panelu kończy się wywołaniem postep.py --gotowe; bez tego skończyło się przed końcem
        stan = "blad"
        ostatnio = f"Zadanie skończyło się przed końcem (etap: {postep.get('etap') or '?'}). Wznów je w panelu albo tutaj."
    tekst_wyn = str((wyn or {}).get("result") or "").replace("[CZEKAM]", "").replace("[GOTOWE]", "").strip()
    zgoda = _zgoda(kat) if st.get("mozg") == "gemini" and not st.get("okno") else None
    ostatnia = max(zmiana or 0, float(postep.get("aktualizacja") or 0))
    if zgoda and (stan == "trwa" or (stan == "blad" and time.time() - zmiana < 86400)):
        # w tle nikt nie kliknie „Zezwól”: zgłaszamy jak pytanie, żeby zakładka Terminal pokazała powiadomienie
        stan = "czeka"
        ostatnio = "Gemini czeka na Twoją zgodę: " + ", ".join([(f"połączenie „{c[4:]}”" if c.startswith("mcp:") else f"uruchomienie „{c[:80]}”") for c in zgoda["odmowy"]] + ([zgoda["wisi"]] if zgoda["wisi"] else []))
    if stan == "czeka" and time.time() - ostatnia > ZAWIESZONE_PO:
        # czeka na odpowiedź albo zgodę od ponad doby: nikt już na nie nie odpowie, pokazujemy osobno jako zawieszone
        stan = "zawieszone"
        ostatnio = f"Zawieszone: czeka na odpowiedź od {time.strftime('%d.%m %H:%M', time.localtime(ostatnia))}. Odpisz, żeby dokończyć, albo usuń z listy. " + (ostatnio or "")
    elif stan == "trwa" and not zywy and time.time() - ostatnia > ZAWIESZONE_PO:
        stan = "zawieszone"
        ostatnio = f"Zawieszone: brak postępu od {time.strftime('%d.%m %H:%M', time.localtime(ostatnia))}. " + (ostatnio or "")
    return {"id": st["id"], "nazwa": st.get("nazwa"), "rodzaj": st.get("rodzaj"), "mozg": st.get("mozg", "claude"), "start": st.get("start"), "zmiana": zmiana, "stan": stan,
            "zrodlo": "panel" if st.get("panel") else "studio", "zgoda": zgoda,
            "ostatnio": ostatnio.replace("[CZEKAM]", "").replace("[GOTOWE]", "").strip(), "wynik": tekst_wyn[:1500], "sesja": sesja, "koszt_usd": round(koszt, 3),
            "etap": postep.get("tekst") or postep.get("etap"), "ulamek": postep.get("ulamek")}


def mozgi():
    try:
        claude = bool(sciezka_claude())
    except Exception:
        claude = False
    return {"claude": claude, "gemini": bool(sciezka_agy())}


UKRYTE = ZLECENIA / "ukryte.json"


def _ukryte():
    try:
        return set(json.loads(UKRYTE.read_text(encoding="utf-8")))
    except Exception:
        return set()


def _panel_id(kat):
    """Numer zadania z panelu: ścieżka folderu względem wyniki/ (ukośniki jako „~~”, bo numer nie może ich mieć)."""
    try:
        rel = Path(kat).resolve().relative_to((KATALOG / "wyniki").resolve()).as_posix()
    except ValueError:
        rel = Path(kat).name
    return "panel~" + rel.replace("/", "~~")


def _foldery_panelu():
    """Foldery zadań z panelu: stary układ wyniki/<folder>, nowy wyniki/<Klient>/<zadanie> i wyniki/<Klient>/Panel Premiere/<zadanie>."""
    w = KATALOG / "wyniki"
    if not w.exists():
        return []
    out = []
    for pat in ("*/claude_log.jsonl", "*/*/claude_log.jsonl", "*/*/*/claude_log.jsonl"):
        for f in w.glob(pat):
            if not any(c.startswith("_") for c in f.relative_to(w).parts[:-1]):
                out.append(f.parent)
    return out


def zlecenia_stan():
    """Wszystkie zlecenia ze Studio i zadania z panelu (bez ukrytych przez użytkownika), najnowsze pierwsze.
    Stany: trwa, czeka (na odpowiedź albo zgodę), zawieszone (czeka dłużej niż dobę), gotowe, blad, przerwane."""
    ukr = _ukryte()
    katalogi = [k for k in ZLECENIA.iterdir() if k.is_dir() and not k.name.startswith("_") and k.name not in ukr] if ZLECENIA.exists() else []
    teraz, panel = time.time(), []
    for k in _foldery_panelu():
        try:
            m = (k / "claude_log.jsonl").stat().st_mtime
            if teraz - m < 120 * 86400 and _panel_id(k) not in ukr:
                panel.append(k)
        except Exception:
            pass
    lista = [o for o in (_opis(k) for k in katalogi + panel) if o]
    lista.sort(key=lambda o: o.get("zmiana") or 0, reverse=True)
    licz = {}
    for o in lista:
        licz[o["stan"]] = licz.get(o["stan"], 0) + 1
    return {"zlecenia": lista[:200], "razem": len(lista), "stany": licz, "mozgi": mozgi()}


def _katalog(zid):
    zid = str(zid or "")
    if not zid or "/" in zid or "\\" in zid or ".." in zid:
        raise ValueError("Nie ma takiego zlecenia.")
    if zid.startswith("panel~"):
        rel = zid[6:].replace("~~", "/")
        kat = KATALOG / "wyniki" / rel
        if rel and not rel.startswith("_") and (kat / "claude_log.jsonl").exists():
            return kat
        raise ValueError("Nie ma takiego zadania z panelu.")
    if not (ZLECENIA / zid / "stan.json").exists():
        raise ValueError("Nie ma takiego zlecenia.")
    return ZLECENIA / zid


def zlecenie_log(zid):
    kat = _katalog(zid)
    wpisy = _czytaj_log(kat)[0]
    for w in wpisy:
        w["tekst"] = str(w["tekst"]).replace("[CZEKAM]", "").replace("[GOTOWE]", "").strip()[:6000]
    return dict(_opis(kat), wpisy=wpisy[-250:])


def zlecenie_odpowiedz(zid, tekst, zgoda=None):
    """zgoda="zezwol": dopisuje odrzucone polecenia do zgód Gemini i każe mu kontynuować; zgoda="okno": ta sama rozmowa w widocznym oknie PowerShell."""
    kat = _katalog(zid)
    o = _opis(kat)
    if o["stan"] == "trwa":
        raise ValueError("Zlecenie jeszcze trwa: odpowiedz, gdy się skończy albo zapyta.")
    st = _stan_plik(kat)
    mozg = st.get("mozg", "claude")
    sesja = o.get("sesja") or ("ostatnia" if mozg == "gemini" else None)
    if not sesja:
        raise ValueError("Nie mogę wznowić tej rozmowy (brak numeru sesji). Uruchom zlecenie jeszcze raz.")
    st.pop("przerwane", None)
    st.pop("okno", None)
    tekst = str(tekst or "").strip()[:8000]
    panel = st.get("panel")
    dalej = ("Kontynuuj to zadanie od miejsca, w którym przerwałeś (gotowe pliki wykorzystaj). " +
             ("Nie zadawaj pytań; etapy raportuj przez narzedzia/postep.py, na końcu python narzedzia/postep.py --gotowe." if panel else
              "Pytanie kończ znacznikiem [CZEKAM], koniec pracy znacznikiem [GOTOWE]."))
    if mozg == "gemini" and zid and zgoda in ("zezwol", "okno"):
        _zabij(st.get("pid"))
        zg = o.get("zgoda") or {"odmowy": [], "wisi": None}
        if zgoda == "okno":
            _gemini_w_oknie(kat, sesja, (tekst + "\n\n" if tekst else "") + dalej)
            st["okno"] = True
            _zapisz_stan(kat, st)
            return {"id": zid, "okno": True}
        if not zg["odmowy"]:
            raise ValueError("Nie wiem, na co dać zgodę (Gemini czeka przy zapisie pliku). Kliknij „Zatwierdź w oknie”.")
        dodaj_zgody_agy(zg["odmowy"])
        tekst = ("Masz już zgodę na to, co przed chwilą zostało zablokowane:\n" + "\n".join("- " + (("narzędzie połączenia " + c[4:] + " (i pozostałe narzędzia tego połączenia)") if c.startswith("mcp:") else c) for c in zg["odmowy"]) +
                 "\nUżyj ich jeszcze raz. " + (tekst + "\n" if tekst else "") + dalej)
    elif mozg == "gemini":
        _zabij(st.get("pid") if o["stan"] == "czeka" and o.get("zgoda") else None)
        tekst = "Odpowiedź użytkownika do tego zlecenia (ciąg dalszy tej samej rozmowy):\n\n" + tekst + "\n\n" + dalej
    elif panel:
        tekst = tekst + "\n\n" + dalej
    st["pid"] = _uruchom_claude(kat, tekst, sesja, mozg)
    _zapisz_stan(kat, st)
    return {"id": zid, "wznowiono": True}


def zlecenie_zatrzymaj(zid, ukryj=False):
    kat = _katalog(zid)
    st = _stan_plik(kat)
    if st.get("pid") and zyje(st.get("pid")):
        _zabij(st.get("pid"))
        st["przerwane"] = True
        _zapisz_stan(kat, st)
    if ukryj:
        # tylko znika z listy w Studio; pliki zadania zostają na dysku
        u = _ukryte() | {str(zid)}
        UKRYTE.parent.mkdir(parents=True, exist_ok=True)
        UKRYTE.write_text(json.dumps(sorted(u), ensure_ascii=False, indent=1), encoding="utf-8")
        return {"id": zid, "usunieto_z_listy": True}
    return {"id": zid, "zatrzymano": True}


# ---------- Wyniki zadań ze Studio: lista plików i podglądy (miniatury, obrazy, wideo w niskiej jakości) ----------
WIDEO_R = {".mp4", ".mov", ".webm", ".m4v", ".mkv"}
OBRAZ_R = {".png", ".jpg", ".jpeg", ".webp"}
INNE_R = {".psd", ".pdf", ".srt", ".xml", ".mp3", ".wav", ".txt", ".md", ".aep", ".prproj", ".mogrt"}
POMIN_KATALOGI = {"klatki", "kontrola", "arkusze", "_analiza", "_robocze", "_proksy", "_napisy", "_cache", "tmp"}
PODGLADY = ZLECENIA / "_podglady"
KAWALEK = 384 * 1024


def _zwarty(t, n):
    import re
    import unicodedata
    t = str(t or "").replace("ł", "l").replace("Ł", "L")
    t = unicodedata.normalize("NFD", t)
    t = "".join(c for c in t if not unicodedata.combining(c)).lower()
    return re.sub(r"[^a-z0-9]", "", t)[:n]


def _gotowe_rel(kat):
    """Gotowe pliki zadania (to, co było zlecone), a nie materiały robocze:
    gotowe.json w folderze zadania ({"pliki": [ścieżki względne]}) albo reguły: film z montażu (obok leży <nazwa>_os_czasu.json),
    pliki w podfolderze gotowe/, grafiki z folderu grafiki/ i pliki Photoshopa z photoshop/."""
    if (kat / "Materiały").is_dir():
        # folder po porządkach: gotowe leżą na wierzchu
        ukryte = {"postep.json", "proces_panelu.json", "claude_log.jsonl", "zadanie_panel.json", "sekwencja.xml", "proksy.json", "polecenie_gemini.json"}
        return {x.name for x in kat.iterdir() if x.is_file() and x.name not in ukryte and not x.name.startswith(".")}
    man = kat / "gotowe.json"
    if man.exists():
        try:
            d = json.loads(man.read_text(encoding="utf-8-sig"))
            lista = d.get("pliki", d) if isinstance(d, dict) else d
            wyn = set()
            for p in lista or []:
                q = (kat / str(p)).resolve() if not Path(str(p)).is_absolute() else Path(str(p)).resolve()
                try:
                    wyn.add(q.relative_to(kat.resolve()).as_posix())
                except ValueError:
                    pass
            if wyn:
                return wyn
        except Exception:
            pass
    wyn = set()
    for x in kat.rglob("*"):
        try:
            rel = x.relative_to(kat)
        except ValueError:
            continue
        if len(rel.parts) > 5 or not x.is_file() or any(cz.startswith("_") for cz in rel.parts[:-1]):
            continue
        e, czesci = x.suffix.lower(), [c.lower() for c in rel.parts[:-1]]
        if e in WIDEO_R and (x.with_name(x.stem + "_os_czasu.json").exists()):
            wyn.add(rel.as_posix())
        elif "gotowe" in czesci and (e in WIDEO_R or e in OBRAZ_R or e in INNE_R):
            wyn.add(rel.as_posix())
        elif czesci and czesci[-1] == "grafiki" and e in OBRAZ_R:
            wyn.add(rel.as_posix())
        elif czesci and czesci[-1] == "photoshop" and e in (".psd", ".psb"):
            wyn.add(rel.as_posix())
    return wyn


def _pliki_wynikow(kat):
    gotowe = _gotowe_rel(kat)
    pliki, robocze = [], 0
    for x in sorted(kat.rglob("*")):
        rel = x.relative_to(kat)
        jest_gotowy = rel.as_posix() in gotowe
        if not jest_gotowy:
            if robocze >= 300:
                continue
            if any(cz.startswith("_") or cz.lower() in POMIN_KATALOGI for cz in rel.parts[:-1]) or len(rel.parts) > 4:
                continue
            if not x.is_file() or x.name.startswith((".", "_")) or "arkusz" in x.name.lower():
                continue
        e = x.suffix.lower()
        typ = "wideo" if e in WIDEO_R else "obraz" if e in OBRAZ_R else "plik" if e in INNE_R or jest_gotowy else None
        if not typ or (not jest_gotowy and (x.name.lower() in ("czytaj.txt", "zadanie.json", "gotowe.json", "sekwencja.xml", "postep.json", "claude_log.jsonl") or x.name.startswith("polecenie"))):
            continue
        if not jest_gotowy:
            robocze += 1
        st = x.stat()
        pliki.append({"sciezka": x.relative_to(KATALOG).as_posix(), "nazwa": x.name, "podfolder": rel.parent.as_posix() if len(rel.parts) > 1 else "",
                      "typ": typ, "rozmiar": st.st_size, "zmiana": st.st_mtime, "gotowe": jest_gotowy})
    kol = {"wideo": 0, "obraz": 1, "plik": 2}
    pliki.sort(key=lambda p: (not p["gotowe"], kol[p["typ"]], p["podfolder"], p["nazwa"]))
    return pliki


def wyniki_zadania(klient="", projekt="", zadanie_id=""):
    """Foldery wyników jednego zadania ze Studio: po nazwie (wspolne.py: <klient>_<projekt>_<DDMMRR>) i po ścieżkach z przebiegu jego zleceń."""
    import re
    kandydaci = {}
    pre = f"{_zwarty(klient, 30) or 'klient'}_{_zwarty(projekt, 40) or 'projekt'}_"
    for baza in ("wyniki", "zlecenia"):
        b = KATALOG / baza
        if b.exists() and projekt:
            for k in b.iterdir():
                if k.is_dir() and k.name.startswith(pre):
                    kandydaci[k] = "nazwa"
    # nowy układ: wyniki/<Klient>/<Tytuł zadania> (numer zadania w Materiały/_info.json)
    try:
        sys.path.insert(0, str(KATALOG / "narzedzia"))
        import porzadek
        wyn = KATALOG / "wyniki"
        kl = wyn / porzadek.nazwa_klienta(klient)
        tyt = porzadek.czysta_nazwa(projekt) if projekt else ""
        for kd in [kl] + [d for d in wyn.iterdir() if d.is_dir() and not d.name.startswith("_") and d != kl] if wyn.exists() else []:
            if not kd.is_dir():
                continue
            for d in kd.iterdir():
                if not d.is_dir():
                    continue
                inf = porzadek._info(d)
                if zadanie_id and inf.get("zadanie_id") == zadanie_id:
                    kandydaci[d] = "numer"
                elif kd == kl and tyt and (d.name == tyt or d.name.startswith(tyt + " (")) and (not zadanie_id or not inf.get("zadanie_id")):
                    kandydaci.setdefault(d, "nazwa")
    except Exception:
        pass
    if zadanie_id and ZLECENIA.exists():
        for k in ZLECENIA.iterdir():
            st = _stan_plik(k) if k.is_dir() else {}
            if st.get("zadanie_id") == zadanie_id or f'"id": "{zadanie_id}"' in str(st.get("polecenie", "")):
                try:
                    tekst = _log_plik(k).read_text(encoding="utf-8", errors="replace")
                except Exception:
                    tekst = ""
                for baza, nazwa in re.findall(r"(wyniki|zlecenia)[\\/]+([A-Za-z0-9_\-]{6,80})", tekst):
                    d = KATALOG / baza / nazwa
                    if not nazwa.startswith("_") and d.is_dir() and not (d / "Materiały").exists() and any(x.is_file() for x in d.iterdir()):
                        kandydaci.setdefault(d, "zlecenie")
                for k1, k2 in re.findall(r"wyniki(?:\\\\|[\\/])+([^\\/\"\n]{1,70})(?:\\\\|[\\/])+([^\\/\"\n]{1,80})", tekst):
                    d = KATALOG / "wyniki" / k1 / k2
                    if not k1.startswith("_") and (d / "Materiały").is_dir():
                        kandydaci.setdefault(d, "zlecenie")
    foldery = []
    for k, skad in kandydaci.items():
        pl = _pliki_wynikow(k)
        foldery.append({"folder": k.relative_to(KATALOG).as_posix(), "nazwa": k.name, "skad": skad, "zmiana": k.stat().st_mtime, "pliki": pl})
    foldery.sort(key=lambda f: f["zmiana"], reverse=True)
    return {"foldery": foldery[:12]}


def _bezpieczna(sciezka):
    p = (KATALOG / str(sciezka or "")).resolve()
    for baza in ("wyniki", "zlecenia"):
        try:
            p.relative_to((KATALOG / baza).resolve())
            if p.is_file():
                return p
        except ValueError:
            pass
    raise ValueError("Ten plik nie należy do wyników silnika.")


def _ffmpeg():
    return shutil.which("ffmpeg") or "ffmpeg"


def podglad_pliku(sciezka, rodzaj="miniatura", czesc=0):
    """Podgląd pliku wyników: miniatura (JPG 480 px), obraz (JPG do 1600 px) albo wideo (MP4 niskiej jakości), w kawałkach base64."""
    import base64
    import hashlib
    zr = _bezpieczna(sciezka)
    rodzaj = rodzaj if rodzaj in ("miniatura", "obraz", "wideo") else "miniatura"
    st = zr.stat()
    klucz = hashlib.sha1(f"{zr}|{st.st_mtime}|{st.st_size}|{rodzaj}".encode("utf-8")).hexdigest()[:20]
    wideo = zr.suffix.lower() in WIDEO_R
    cel = PODGLADY / (klucz + (".mp4" if rodzaj == "wideo" else ".jpg"))
    if not cel.exists():
        PODGLADY.mkdir(parents=True, exist_ok=True)
        tmp = cel.with_suffix(".tmp" + cel.suffix)
        fl = 0x08000000 if sys.platform.startswith("win") else 0
        if rodzaj == "wideo":
            if not wideo:
                raise ValueError("To nie jest film.")
            dl = 0.0
            try:
                r = subprocess.run([shutil.which("ffprobe") or "ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(zr)],
                                   capture_output=True, text=True, timeout=30, creationflags=fl)
                dl = float(r.stdout.strip() or 0)
            except Exception:
                pass
            wys = 540 if dl <= 90 else 360
            cmd = [_ffmpeg(), "-y", "-v", "error", "-i", str(zr), "-vf", f"scale=-2:'min({wys},ih)'", "-c:v", "libx264", "-preset", "veryfast", "-crf", "30",
                   "-maxrate", "1500k", "-bufsize", "3000k", "-pix_fmt", "yuv420p", "-c:a", "aac", "-b:a", "96k", "-ac", "2", "-movflags", "+faststart", str(tmp)]
        else:
            szer = 480 if rodzaj == "miniatura" else 1600
            wej = ["-ss", "1", "-i", str(zr)] if wideo else ["-i", str(zr)]
            cmd = [_ffmpeg(), "-y", "-v", "error", *wej, "-frames:v", "1", "-vf", f"scale='min({szer},iw)':-2", "-q:v", "4", str(tmp)]
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=900, creationflags=fl)
        if (r.returncode != 0 or not tmp.exists()) and wideo and rodzaj != "wideo":
            cmd[cmd.index("-ss") + 1] = "0"
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=120, creationflags=fl)
        if r.returncode != 0 or not tmp.exists():
            raise ValueError("Nie udało się zrobić podglądu: " + (r.stderr or "")[-300:])
        tmp.replace(cel)
    dane = cel.read_bytes()
    n = max(1, -(-len(dane) // KAWALEK))
    czesc = max(0, min(int(czesc or 0), n - 1))
    return {"sciezka": sciezka, "rodzaj": rodzaj, "typ": "video/mp4" if rodzaj == "wideo" else "image/jpeg", "rozmiar": len(dane), "czesci": n, "czesc": czesc,
            "dane": base64.b64encode(dane[czesc * KAWALEK:(czesc + 1) * KAWALEK]).decode("ascii")}


def wywolaj(nazwa, argumenty=None):
    argumenty = argumenty or {}
    if nazwa == "wykonaj":
        return wykonaj(argumenty.get("polecenie"), argumenty.get("nazwa"), argumenty.get("mozg") or "claude")
    if nazwa == "zlecenia_stan":
        return zlecenia_stan()
    if nazwa == "zlecenie_log":
        if argumenty.get("id") == "wyniki":
            return wyniki_zadania(argumenty.get("klient"), argumenty.get("projekt"), argumenty.get("zadanie_id"))
        if argumenty.get("id") == "podglad":
            return podglad_pliku(argumenty.get("sciezka"), argumenty.get("rodzaj") or "miniatura", argumenty.get("czesc") or 0)
        return zlecenie_log(argumenty.get("id"))
    if nazwa == "zlecenie_odpowiedz":
        return zlecenie_odpowiedz(argumenty.get("id"), argumenty.get("tekst"), argumenty.get("zgoda"))
    if nazwa == "zlecenie_zatrzymaj":
        return zlecenie_zatrzymaj(argumenty.get("id"), bool(argumenty.get("ukryj")))
    if nazwa == "zapisz_style_napisow":
        return zapisz_style_napisow(argumenty.get("style"))
    if nazwa == "limity":
        import limity
        return limity.podsumowanie()
    if nazwa == "klucze_stan":
        return klucze_stan(bool(argumenty.get("test")), bool(argumenty.get("swiezy")))
    if nazwa == "otworz_klucze":
        import foldery
        foldery.otworz_klucze()
        return {"otwarto": True, "uwaga": "Wklej klucze po znaku = i zapisz plik (Ctrl+S)."}
    raise ValueError("Nieznane narzędzie: " + nazwa)


def serwer():
    # Windows domyślnie pisze w kodowaniu cp1250 i wysypuje się na znakach spoza niego; aplikacja Claude czeka na UTF-8
    sys.stdin.reconfigure(encoding="utf-8", errors="replace")
    sys.stdout.reconfigure(encoding="utf-8", errors="replace", newline="\n")
    for linia in sys.stdin:
        linia = linia.strip()
        if not linia:
            continue
        try:
            m = json.loads(linia)
        except Exception:
            continue
        mid, metoda = m.get("id"), m.get("method")
        if mid is None:  # powiadomienia (np. notifications/initialized)
            continue
        try:
            if metoda == "initialize":
                wyn = {"protocolVersion": (m.get("params") or {}).get("protocolVersion", "2025-06-18"), "capabilities": {"tools": {}},
                       "serverInfo": {"name": NAZWA, "version": "1.0.0"}}
            elif metoda == "tools/list":
                wyn = {"tools": NARZEDZIA}
            elif metoda == "tools/call":
                par = m.get("params") or {}
                dane = wywolaj(par.get("name"), par.get("arguments"))
                wyn = {"content": [{"type": "text", "text": json.dumps(dane, ensure_ascii=False)}], "structuredContent": dane, "isError": False}
            elif metoda == "ping":
                wyn = {}
            else:
                raise ValueError("Nieobsługiwana metoda " + str(metoda))
            odp = {"jsonrpc": "2.0", "id": mid, "result": wyn}
        except Exception as e:
            odp = {"jsonrpc": "2.0", "id": mid, "error": {"code": -32000, "message": str(e)}}
        sys.stdout.write(json.dumps(odp, ensure_ascii=False) + "\n")
        sys.stdout.flush()


def plik_ustawien():
    if sys.platform.startswith("win"):
        return Path(os.environ["APPDATA"]) / "Claude" / "claude_desktop_config.json"
    if sys.platform == "darwin":
        return Path.home() / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json"
    return Path.home() / ".config" / "Claude" / "claude_desktop_config.json"


def instaluj(usun=False):
    p = plik_ustawien()
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        d = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    except Exception:
        print(json.dumps({"ok": False, "blad": f"Nie umiem odczytać {p}. Popraw albo usuń ten plik i spróbuj ponownie."}, ensure_ascii=False))
        return 1
    if p.exists():
        shutil.copy(p, p.with_suffix(".json.kopia"))
    serwery = d.setdefault("mcpServers", {})
    if usun:
        serwery.pop(NAZWA, None)
    else:
        py = Path(sys.executable)
        if py.name.lower() == "pythonw.exe":
            py = py.with_name("python.exe")
        serwery[NAZWA] = {"command": str(py), "args": [str(Path(__file__).resolve())]}
    p.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"ok": True, "plik": str(p), "dalej": "Zamknij i otwórz aplikację Claude. Potem otwórz Studio w aplikacji: pasek limitów i ustawienia kluczy zaczną działać."}, ensure_ascii=False, indent=1))
    return 0


if __name__ == "__main__":
    if "--instaluj" in sys.argv:
        sys.exit(instaluj())
    if "--odinstaluj" in sys.argv:
        sys.exit(instaluj(usun=True))
    serwer()
