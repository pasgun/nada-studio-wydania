"use strict";
const { contextBridge, ipcRenderer } = require("electron");
contextBridge.exposeInMainWorld("nada", {
  stan: () => ipcRenderer.invoke("stan"),
  jezyk: () => ipcRenderer.invoke("jezyk"),
  wyniki: () => ipcRenderer.invoke("wyniki"),
  wczytaj: (plik, nazwa) => ipcRenderer.invoke("wczytaj", plik, nazwa),
  tnij: (opcje) => ipcRenderer.invoke("tnij", opcje),
  napisy: (opcje) => ipcRenderer.invoke("napisy", opcje),
  wskaz: () => ipcRenderer.invoke("wskaz"),
  otworz: (p) => ipcRenderer.invoke("otworz", p),
  naPostep: (f) => ipcRenderer.on("postep", (e, t) => f(t)),
});
