/* Nada Studio: wtyczka Workflow Integration dla DaVinci Resolve Studio.
 * Działa jak mała apka wewnątrz DaVinci: okno panelu + dostęp do projektu przez WorkflowIntegration.node
 * (moduł z przykładów DaVinci, kopiowany przez instalator) + uruchamianie silnika Nada Studio (Python). */
"use strict";
const { app, BrowserWindow, ipcMain, dialog, shell } = require("electron");
const path = require("path");
const fs = require("fs");
const { spawn } = require("child_process");

const PLUGIN_ID = "pl.nadamedia.studio.davinci";
let WI = null, resolve = null, okno = null;

let cfg = {};
try { cfg = JSON.parse(fs.readFileSync(path.join(__dirname, "config.json"), "utf8")); } catch (e) {}

async function dawinczi() {
  if (resolve) return resolve;
  if (!WI) {
    try { WI = require("./WorkflowIntegration.node"); } catch (e) { throw new Error("Brak modułu WorkflowIntegration.node (zainstaluj panel ponownie w apce Nada Studio)."); }
  }
  const ok = await WI.Initialize(PLUGIN_ID);
  if (!ok) throw new Error("DaVinci nie pozwolił połączyć się z projektem (Workflow Integration działa w wersji Studio).");
  resolve = await WI.GetResolve();
  if (!resolve) throw new Error("Nie mam dostępu do DaVinci Resolve.");
  return resolve;
}

async function projekt() {
  const r = await dawinczi();
  const pm = await r.GetProjectManager();
  const p = await pm.GetCurrentProject();
  if (!p) throw new Error("Otwórz projekt w DaVinci.");
  return { r, p, mp: await p.GetMediaPool() };
}

function env() {
  const e = Object.assign({}, process.env, { PYTHONIOENCODING: "utf-8", PYTHONUTF8: "1" });
  const k = Object.keys(e).find((x) => x.toUpperCase() === "PATH") || "PATH";
  e[k] = (cfg.sciezki || []).concat([e[k] || ""]).join(path.delimiter);
  delete e.ELECTRON_RUN_AS_NODE;
  return e;
}

/* narzędzie silnika: zwraca JSON z ostatniego obiektu na wyjściu; postęp (POSTEP: ...) leci do okna */
function silnik(skrypt, args) {
  return new Promise((ok) => {
    if (!cfg.silnik || !cfg.python) return ok({ ok: false, blad: "Panel nie zna silnika. Zainstaluj go ponownie w apce Nada Studio (Ustawienia apki > Panele)." });
    const p = spawn(cfg.python, [path.join(cfg.silnik, "narzedzia", skrypt), ...args], { cwd: cfg.silnik, env: env(), windowsHide: true });
    let out = "", err = "";
    p.stdout.setEncoding("utf8"); p.stderr.setEncoding("utf8");
    p.stdout.on("data", (d) => (out += d));
    p.stderr.on("data", (d) => {
      err += d;
      for (const l of String(d).split(/\r?\n/)) if (l.startsWith("POSTEP: ") && okno) okno.webContents.send("postep", l.slice(8));
    });
    p.on("error", (e) => ok({ ok: false, blad: String(e) }));
    p.on("close", () => {
      const t = out.trim();
      try { ok(JSON.parse(t.slice(t.indexOf("{\n") >= 0 ? t.indexOf("{\n") : t.indexOf("{")))); } catch (e) { ok({ ok: false, blad: (err || t).slice(-800) }); }
    });
  });
}

/* ---------- działania na projekcie ---------- */
async function eksportujOs() {
  const { r, p } = await projekt();
  const tl = await p.GetCurrentTimeline();
  if (!tl) throw new Error("Otwórz oś czasu (timeline), którą chcesz przerobić.");
  const nazwa = await tl.GetName();
  const f = await silnik("davinci_most.py", ["folder", "--nazwa", nazwa]);
  if (!f.folder) throw new Error(f.blad || "Nie mam folderu roboczego.");
  const plik = path.join(f.folder, (nazwa || "os").replace(/[<>:"/\\|?*]/g, "-") + ".xml");
  const typ = r.EXPORT_FCP_7_XML !== undefined ? r.EXPORT_FCP_7_XML : await r.EXPORT_FCP_7_XML;
  const pod = r.EXPORT_NONE !== undefined ? r.EXPORT_NONE : await r.EXPORT_NONE;
  const ok = await tl.Export(plik, typ, pod);
  if (!ok || !fs.existsSync(plik)) throw new Error("DaVinci nie wyeksportował osi do XML. Zrób to ręcznie: Plik > Export > Timeline… > FCP 7 XML, i wskaż plik w panelu.");
  return { plik, nazwa };
}

async function importujOs(plik, nazwa) {
  const { p, mp } = await projekt();
  const tl = await mp.ImportTimelineFromFile(plik, { timelineName: nazwa || path.basename(plik, ".xml"), importSourceClips: true });
  if (!tl) throw new Error("DaVinci nie wczytał osi z pliku " + path.basename(plik) + ". Spróbuj ręcznie: Plik > Import > Timeline…");
  try { await p.SetCurrentTimeline(tl); } catch (e) {}
  await silnik("davinci_most.py", ["wczytane", "--plik", plik]);
  return { ok: true, nazwa: await tl.GetName() };
}

async function importujPliki(pliki) {
  const { mp } = await projekt();
  const w = await mp.ImportMedia(pliki.filter((x) => x && fs.existsSync(x)));
  return { ok: !!w, ile: w ? w.length || pliki.length : 0 };
}

function jezyk() { try { return fs.readFileSync(path.join(cfg.silnik || "", "_system", "jezyk.txt"), "utf8").trim() === "en" ? "en" : "pl"; } catch (e) { return cfg.jezyk === "en" ? "en" : "pl"; } }

/* ---------- IPC z okna panelu ---------- */
function obsluga() {
  const h = (k, f) => ipcMain.handle(k, async (e, ...a) => { try { return await f(...a); } catch (err) { return { ok: false, blad: err.message || String(err) }; } });
  h("stan", async () => {
    let dv = null;
    try { const { p } = await projekt(); const tl = await p.GetCurrentTimeline(); dv = { projekt: await p.GetName(), os: tl ? await tl.GetName() : null }; } catch (e) { dv = { blad: e.message }; }
    return { ok: true, silnik: cfg.silnik || null, dv };
  });
  h("jezyk", () => jezyk());
  h("wyniki", () => silnik("davinci_most.py", ["wyniki"]));
  h("wczytaj", (plik, nazwa) => importujOs(plik, nazwa));
  h("tnij", async (opcje) => {
    const os = opcje.plik ? { plik: opcje.plik, nazwa: path.basename(opcje.plik, ".xml") } : await eksportujOs();
    const args = ["tnij", "--xml", os.plik, "--wpadki", opcje.wpadki || "wytnij"].concat(opcje.jezyk ? ["--jezyk", opcje.jezyk] : []).concat(opcje.bezCiszy ? ["--bez-ciszy"] : []);
    const w = await silnik("davinci_most.py", args);
    if (w.ok === false) return w;
    const out = { ok: true, wynik: w.wynik_ciecia, folder: w.folder };
    if (w.xml) out.os = await importujOs(w.xml, os.nazwa + (jezyk() === "en" ? " (cut)" : " (cięcie)"));
    if (w.srt) out.napisy = await importujPliki([w.srt]);
    return out;
  });
  h("napisy", async (opcje) => {
    const os = opcje.plik ? { plik: opcje.plik } : await eksportujOs();
    const w = await silnik("davinci_most.py", ["napisy", "--xml", os.plik].concat(opcje.jezyk ? ["--jezyk", opcje.jezyk] : []));
    if (w.ok === false) return w;
    return { ok: true, srt: w.srt, napisy: w.srt ? await importujPliki([w.srt]) : null };
  });
  h("wskaz", async () => {
    const r = await dialog.showOpenDialog(okno, { filters: [{ name: "Oś czasu (XML)", extensions: ["xml", "fcpxml"] }], properties: ["openFile"] });
    return r.canceled ? null : r.filePaths[0];
  });
  h("otworz", (p) => shell.openPath(p));
}

app.whenReady().then(() => {
  obsluga();
  okno = new BrowserWindow({ width: 420, height: 720, minWidth: 340, title: "Nada Studio", backgroundColor: "#0e0e0d", useContentSize: true,
    webPreferences: { preload: path.join(__dirname, "preload.js"), contextIsolation: true, nodeIntegration: false } });
  okno.on("close", () => app.quit());
  okno.setMenuBarVisibility(false);
  okno.loadFile(path.join(__dirname, "index.html"));
});
app.on("window-all-closed", () => app.quit());
