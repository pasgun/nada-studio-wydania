"use strict";
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const N = window.nada;

/* wersja angielska: gdy w apce Nada Studio wybrany jest angielski (_system/jezyk.txt w silniku) */
let EN = null;
const SLOWNIK = {
  "Wyniki": "Results", "Cięcie": "Cut", "Napisy": "Captions",
  "Osie czasu z zadań Nada Studio (rolki, aftermovie, cięcia). Kliknij, żeby wczytać do otwartego projektu.": "Timelines from Nada Studio tasks (reels, aftermovies, cuts). Click to load one into the open project.",
  "Odśwież": "Refresh", "Wczytaj plik XML…": "Load XML file…",
  "Cięcie ciszy i wpadek w otwartej osi czasu (jak w panelu Premiere). Oryginał zostaje, powstaje nowa oś z cięciami i markerami, a napisy SRT trafiają do Media Pool.": "Cuts silences and flubs in the open timeline (like the Premiere panel). The original stays; a new timeline with cuts and markers is created, and SRT captions go to the Media Pool.",
  "Wpadki": "Flubs", "wytnij": "cut", "tylko oznacz markerem": "only mark with a marker", "pomiń (sama cisza)": "skip (silence only)",
  "Język": "Language", "wykryj sam": "auto-detect", "polski": "Polish", "angielski": "English", "niemiecki": "German", "szwedzki": "Swedish",
  "nie tnij ciszy (tylko wpadki)": "don't cut silences (flubs only)", "Tnij otwartą oś": "Cut the open timeline", "…albo wskaż plik XML": "…or choose an XML file",
  "Napisy SRT do otwartej osi (rozpoznawanie mowy silnikiem Nada Studio). Plik trafi do Media Pool: przeciągnij go na ścieżkę napisów.": "SRT captions for the open timeline (speech recognition by the Nada Studio engine). The file goes to the Media Pool: drag it onto a subtitle track.",
  "Zrób napisy": "Make captions", "NOWA": "NEW",
  "Brak osi z ostatnich 30 dni. Zadania z Nada Studio pojawią się tu, gdy się skończą.": "No timelines from the last 30 days. Nada Studio tasks appear here when they finish.",
  "Panel nie zna silnika Nada Studio. Zainstaluj panel ponownie w apce (Ustawienia apki > Panele).": "The panel doesn't know where the Nada Studio engine is. Reinstall the panel in the app (App settings > Panels).",
  "Panel nie zna silnika. Zainstaluj go ponownie w apce Nada Studio (Ustawienia apki > Panele).": "The panel doesn't know where the engine is. Reinstall it in the Nada Studio app (App settings > Panels).",
  "Eksportuję oś i analizuję mowę (to potrwa: kilka minut na godzinę materiału)…": "Exporting the timeline and analysing speech (takes a few minutes per hour of footage)…",
  "Eksportuję oś i rozpoznaję mowę…": "Exporting the timeline and recognising speech…", "Nie wyszło.": "It didn't work.",
  "Otwórz projekt w DaVinci.": "Open a project in DaVinci.",
  "Otwórz oś czasu (timeline), którą chcesz przerobić.": "Open the timeline you want to process.",
  "Nie mam dostępu do DaVinci Resolve.": "No access to DaVinci Resolve.",
  "Brak modułu WorkflowIntegration.node (zainstaluj panel ponownie w apce Nada Studio).": "The WorkflowIntegration.node module is missing (reinstall the panel in the Nada Studio app).",
  "DaVinci nie pozwolił połączyć się z projektem (Workflow Integration działa w wersji Studio).": "DaVinci didn't allow connecting to the project (Workflow Integration works in the Studio version).",
  "DaVinci nie wyeksportował osi do XML. Zrób to ręcznie: Plik > Export > Timeline… > FCP 7 XML, i wskaż plik w panelu.": "DaVinci didn't export the timeline to XML. Do it manually: File > Export > Timeline… > FCP 7 XML, and choose the file in the panel.",
};
const POCZATKI = [["Wczytuję „", "Loading “"], ["Wczytano oś: ", "Timeline loaded: "], ["Gotowe: napisy SRT są w Media Pool.", "Done: SRT captions are in the Media Pool."], ["Gotowe: nowa oś „", "Done: new timeline “"],
  ["\nByło ", "\nWas "], [" s, jest ", " s, now "], [" s, cięć: ", " s, cuts: "], [", markerów: ", ", markers: "], ["\nNapisy SRT są w Media Pool.", "\nSRT captions are in the Media Pool."], ["\nUwagi: ", "\nNotes: "], ["”…", "”…"], ["”.", "”."],
  ["DaVinci nie wczytał osi z pliku ", "DaVinci didn't load the timeline from "], [". Spróbuj ręcznie: Plik > Import > Timeline…", ". Try manually: File > Import > Timeline…"]];
function tr(t) {
  if (!EN || !t) return t;
  const r = t.trim();
  if (SLOWNIK[r]) return t.replace(r, SLOWNIK[r]);
  let w = t;
  for (const [pl, en] of POCZATKI) w = w.split(pl).join(en);
  return w;
}
function przetlumaczStrone() {
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let n;
  while ((n = w.nextNode())) { const r = n.nodeValue.trim(); if (r && SLOWNIK[r]) n.nodeValue = n.nodeValue.replace(r, SLOWNIK[r]); }
}
N.jezyk().then((j) => { if (j !== "en") return; EN = true; document.documentElement.lang = "en"; przetlumaczStrone(); new MutationObserver(() => { const l = $("lista"); if (l) przetlumaczStrone(); }).observe($("lista"), { childList: true, subtree: true }); }).catch(() => {});

function stan(t, klasa) { const s = $("stan"); t = tr(t); s.hidden = !t; s.className = "stan " + (klasa || ""); s.textContent = t || ""; }
N.naPostep((t) => stan(t + "…"));

document.querySelectorAll("nav button").forEach((b) => (b.onclick = () => {
  document.querySelectorAll("nav button").forEach((x) => x.classList.toggle("wybrana", x === b));
  document.querySelectorAll("main > section").forEach((s) => (s.hidden = s.id !== "zak-" + b.dataset.zak));
  stan("");
}));

async function zajety(przycisk, f) {
  document.querySelectorAll("button").forEach((b) => (b.disabled = true));
  try { await f(); } finally { document.querySelectorAll("button").forEach((b) => (b.disabled = false)); }
}

async function odswiezStan() {
  const s = await N.stan();
  $("projekt").textContent = s.dv && s.dv.projekt ? s.dv.projekt + (s.dv.os ? " · " + s.dv.os : "") : s.dv && s.dv.blad ? s.dv.blad : "";
  if (!s.silnik) stan("Panel nie zna silnika Nada Studio. Zainstaluj panel ponownie w apce (Ustawienia apki > Panele).", "zle");
}

async function rysujWyniki() {
  const w = await N.wyniki();
  const l = (w && w.osie) || [];
  $("lista").innerHTML = l.length ? l.map((o, i) => `<div class="poz" data-i="${i}"><b title="${esc(o.plik)}">${esc(o.tytul)}</b>${o.nowa ? '<span class="nowa">NOWA</span>' : "<span></span>"}<small>${esc(new Date(o.kiedy * 1000).toLocaleString(EN ? "en-GB" : "pl-PL", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }))}</small></div>`).join("")
    : '<div class="pusto">Brak osi z ostatnich 30 dni. Zadania z Nada Studio pojawią się tu, gdy się skończą.</div>';
  $("lista").querySelectorAll(".poz").forEach((el) => (el.onclick = () => zajety(null, async () => {
    const o = l[Number(el.dataset.i)];
    stan("Wczytuję „" + o.tytul + "”…");
    const r = await N.wczytaj(o.plik, o.tytul.split(" / ").slice(-2).join(" - "));
    stan(r.ok ? "Wczytano oś: " + r.nazwa : r.blad, r.ok ? "ok" : "zle");
    rysujWyniki();
  })));
  if (w && w.ok === false) stan(w.blad, "zle");
}

$("odswiez").onclick = () => rysujWyniki();
$("wskazWynik").onclick = async () => {
  const p = await N.wskaz();
  if (!p) return;
  zajety(null, async () => { const r = await N.wczytaj(p); stan(r.ok ? "Wczytano oś: " + r.nazwa : r.blad, r.ok ? "ok" : "zle"); });
};

async function tnij(plik) {
  stan("Eksportuję oś i analizuję mowę (to potrwa: kilka minut na godzinę materiału)…");
  const r = await N.tnij({ plik, wpadki: $("wpadki").value, jezyk: $("jezyk").value, bezCiszy: $("bezCiszy").checked });
  if (!r.ok) return stan(r.blad || "Nie wyszło.", "zle");
  const w = r.wynik || {};
  stan(`Gotowe: nowa oś „${(r.os && r.os.nazwa) || ""}”.\nByło ${w.bylo_s ?? "?"} s, jest ${w.jest_s ?? "?"} s, cięć: ${w.ciec ?? "?"}, markerów: ${w.markerow ?? "?"}.` + (r.napisy ? "\nNapisy SRT są w Media Pool." : "") + (w.uwagi && w.uwagi.length ? "\nUwagi: " + w.uwagi.join("; ") : ""), "ok");
}
$("tnij").onclick = () => zajety(null, () => tnij(null));
$("tnijPlik").onclick = async () => { const p = await N.wskaz(); if (p) zajety(null, () => tnij(p)); };
$("napisy").onclick = () => zajety(null, async () => {
  stan("Eksportuję oś i rozpoznaję mowę…");
  const r = await N.napisy({ jezyk: $("jezykN").value });
  stan(r.ok ? "Gotowe: napisy SRT są w Media Pool.\n" + (r.srt || "") : r.blad, r.ok ? "ok" : "zle");
});

odswiezStan();
rysujWyniki();
