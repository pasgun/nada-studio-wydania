"""Poprawa dźwięku mowy z nagrań (w stylu Adobe Podcast Enhance).

Dwa etapy:
1. Oczyszczenie mowy przez AI: ElevenLabs Voice Isolator (usuwa szum, pogłos, tło). Zużywa kredyty ElevenLabs.
2. Obróbka studyjna w ffmpeg (za darmo): filtr dolnoprzepustowy, korekcja, de-esser, kompresja, głośność -16 LUFS.

Plik wynikowy ma dokładnie tę samą długość co nagranie, więc w montażu podstawiasz go jako dźwięk sceny:
  "dzwiek": true, "dzwiek_z": {"plik": "<wynik>", "start": <ten sam start co sceny>}

Użycie:
  python narzedzia/dzwiek.py popraw --plik nagrania/sesja/C0001.MP4 [--silnik elevenlabs|ffmpeg] [--sila 1.0]
  python narzedzia/dzwiek.py folder --folder nagrania/sesja [--silnik ...]
  python narzedzia/dzwiek.py premiere --plik X [--moc 80] [--silnik ...] [--kopia folder_backup]   (panel Premiere)
  python narzedzia/dzwiek.py hurtem --folder zlecenia/<nazwa> [--moc 80] [--silnik elevenlabs|ffmpeg]
      (narzędzie „Poprawa dźwięku”: każdy plik z folderu dostaje czysty dźwięk; wideo wraca jako MP4 z nowym
       dźwiękiem i nietkniętym obrazem, audio jako WAV; wyniki w <folder>/gotowe/.
       --moc 0–100 działa jak suwak „Strength” w Adobe Podcast: ile oczyszczonego głosu, a ile oryginału)
Wynik: nagrania/sesja/_analiza/<nazwa>_czysty.wav (raz zrobiony jest używany ponownie; --od-nowa liczy od nowa).
"""
import argparse
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, klucz, wynik  # noqa: E402

ROZSZ = {".mp4", ".mov", ".mxf", ".m4v", ".mkv", ".avi", ".mts", ".webm", ".wav", ".mp3", ".m4a", ".aac", ".flac"}


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


def ff(args, opis):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *map(str, args)],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        blad(f"{opis}: {r.stderr[-800:]}")


def dlugosc(plik):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(plik)],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    try:
        return float(r.stdout.strip())
    except ValueError:
        return 0.0


def izolacja_elevenlabs(wej_audio, wyj):
    """Długie nagrania wysyłamy kawałkami po 15 minut i sklejamy (limit wielkości pliku w ElevenLabs)."""
    dl = dlugosc(wej_audio)
    if dl > 15 * 60:
        tmp = Path(tempfile.mkdtemp())
        czesci = []
        for k, od in enumerate(range(0, int(dl) + 1, 15 * 60)):
            cz = tmp / f"c{k:03d}.mp3"
            ff(["-ss", od, "-t", 15 * 60, "-i", wej_audio, "-c:a", "libmp3lame", "-b:a", "192k", cz], "dzielenie nagrania")
            wy = tmp / f"w{k:03d}.audio"
            izolacja_elevenlabs(cz, wy)
            czesci.append(wy)
        lista = tmp / "lista.txt"
        lista.write_text("".join(f"file '{c.as_posix()}'\n" for c in czesci), encoding="utf-8")
        ff(["-f", "concat", "-safe", "0", "-i", lista, "-c:a", "pcm_s16le", wyj.with_suffix(".wav")], "sklejanie kawałków")
        wyj.with_suffix(".wav").replace(wyj)
        return
    import requests
    with open(wej_audio, "rb") as f:
        r = requests.post("https://api.elevenlabs.io/v1/audio-isolation", headers={"xi-api-key": klucz("ELEVENLABS_API_KEY")},
                          files={"audio": (Path(wej_audio).name, f, "audio/mpeg")}, timeout=1800)
    if r.status_code >= 400:
        blad(f"ElevenLabs Voice Isolator HTTP {r.status_code}: {r.text[:400]}")
    wyj.write_bytes(r.content)


def lancuch_studyjny(sila, odszumianie):
    """Obróbka jak w studiu lektorskim. sila 0.5–1.5 skaluje korekcję i kompresję."""
    s = max(0.3, min(1.5, sila))
    etapy = ["highpass=f=80", "lowpass=f=16000"]
    if odszumianie:
        etapy.append(f"afftdn=nr={int(10 * s)}:nf=-35")
    etapy += [
        f"equalizer=f=250:t=q:w=1.0:g={-2 * s:.1f}",        # mniej buczenia i „pudła”
        f"equalizer=f=3500:t=q:w=1.2:g={2.5 * s:.1f}",      # czytelność
        f"equalizer=f=10000:t=h:w=0.7:g={1.5 * s:.1f}",     # powietrze
        "deesser=i=0.4",
        f"acompressor=threshold=-21dB:ratio={2 + s:.1f}:attack=8:release=160:makeup=2",
        "loudnorm=I=-16:TP=-1.5:LRA=7",
    ]
    return ",".join(etapy)


def popraw(plik, silnik="elevenlabs", sila=1.0, od_nowa=False):
    plik = sciezka(plik)
    folder = plik.parent / "_analiza"
    folder.mkdir(exist_ok=True)
    cel = folder / f"{plik.stem}_czysty.wav"
    if cel.exists() and not od_nowa:
        return cel, "z poprzedniej analizy"
    dl = dlugosc(plik)
    if dl <= 0:
        blad(f"Nie mogę odczytać długości {plik.name}")
    tmp = Path(tempfile.mkdtemp())
    surowy = tmp / "surowy.mp3"
    ff(["-i", plik, "-vn", "-ac", "1", "-ar", "44100", "-b:a", "192k", surowy], "wyciąganie dźwięku")
    zrodlo = surowy
    if silnik == "elevenlabs":
        czysty = tmp / "izolowany.audio"
        izolacja_elevenlabs(surowy, czysty)
        zrodlo = czysty
    # obróbka + dokładnie ta sama długość co nagranie (żeby zgadzał się z obrazem i napisami)
    ff(["-i", zrodlo, "-af", f"{lancuch_studyjny(sila, silnik == 'ffmpeg')},aresample=48000,asetpts=N/SR/TB,apad=whole_dur={dl:.3f},atrim=0:{dl:.3f}",
        "-ac", "2", "-ar", "48000", "-c:a", "pcm_s16le", cel], "obróbka dźwięku")
    for f in tmp.iterdir():
        f.unlink()
    tmp.rmdir()
    return cel, silnik


ROZSZ_WIDEO = {".mp4", ".mov", ".mxf", ".m4v", ".mkv", ".avi", ".mts", ".webm"}


def mieszaj(x, czysty, m, dl):
    """Oczyszczony głos + odrobina oryginału (wyrównanego głośnością), jak suwak „Strength” w Adobe Podcast."""
    if m >= 0.999:
        return czysty
    mieszany = czysty.parent / f"{x.stem}_moc{int(m * 100)}.wav"
    ff(["-i", czysty, "-i", x, "-filter_complex",
        f"[1:a]aformat=sample_rates=48000:channel_layouts=stereo,highpass=f=80,loudnorm=I=-16:TP=-1.5,aresample=48000,asetpts=N/SR/TB,apad=whole_dur={dl:.3f},atrim=0:{dl:.3f}[o];"
        f"[0:a]aformat=sample_rates=48000:channel_layouts=stereo[c];[c][o]amix=inputs=2:weights='{m:.2f} {1 - m:.2f}':normalize=0,alimiter=limit=0.95[a]",
        "-map", "[a]", "-c:a", "pcm_s16le", "-ar", 48000, mieszany], "mieszanie z oryginałem")
    return mieszany


def dla_premiere(plik, moc=80, silnik="elevenlabs", kopia_do=None, od_nowa=False):
    """Panel w Premiere: kopia oryginału do folderu backup, czysty dźwięk, nowy plik obok oryginału
    (wideo: ten sam obraz bez przeliczania + nowy dźwięk). Premiere podmienia potem plik w klipie, więc klip zostaje na miejscu."""
    import shutil
    from wspolne import postep
    x = sciezka(plik)
    if not x.exists():
        blad(f"Nie widzę pliku {x}")
    kopia = None
    if kopia_do:
        d = Path(kopia_do)
        d.mkdir(parents=True, exist_ok=True)
        kopia = d / x.name
        if not kopia.exists():
            postep(f"Kopia zapasowa: {x.name}")
            shutil.copy2(x, kopia)
    postep(f"Czyszczę dźwięk: {x.name}")
    czysty, s_ = popraw(x, silnik, 1.0, od_nowa)
    dl = dlugosc(x)
    m = max(0, min(100, moc)) / 100
    mieszany = mieszaj(x, czysty, m, dl)
    wideo = x.suffix.lower() in ROZSZ_WIDEO
    rozsz = (".mp4" if x.suffix.lower() in (".mp4", ".m4v") else ".mov") if wideo else ".wav"
    cel = x.with_name(f"{x.stem}_czysty{rozsz}")
    n = 2
    while cel.exists() and not od_nowa:
        cel = x.with_name(f"{x.stem}_czysty_{n}{rozsz}")
        n += 1
    postep(f"Zapisuję: {cel.name}")
    if wideo:
        audio = ["-c:a", "aac", "-b:a", "320k"] if rozsz == ".mp4" else ["-c:a", "pcm_s16le"]
        ff(["-i", x, "-i", mieszany, "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", *audio, "-shortest", cel], f"składanie {x.name}")
    else:
        ff(["-i", mieszany, "-c:a", "pcm_s16le", "-ar", 48000, cel], "zapis WAV")
    wynik(plik=str(cel), zrodlo=str(x), kopia=str(kopia) if kopia else None, silnik=s_, minuty=round(dl / 60, 2), moc=int(m * 100))


def hurtem(folder, moc=80, silnik="elevenlabs", od_nowa=False):
    """Narzędzie „Poprawa dźwięku”: czysty głos dla wszystkich plików z folderu, z suwakiem mocy jak w Adobe Podcast."""
    from wspolne import postep
    folder = sciezka(folder)
    pliki = sorted(x for x in folder.iterdir() if x.is_file() and x.suffix.lower() in ROZSZ)
    if not pliki:
        blad(f"W {folder} nie ma plików wideo ani audio.")
    gotowe = folder / "gotowe"
    gotowe.mkdir(exist_ok=True)
    m = max(0, min(100, moc)) / 100
    wyniki, minuty = [], 0.0
    for i, x in enumerate(pliki, 1):
        postep(f"Poprawiam dźwięk {i}/{len(pliki)}: {x.name}")
        czysty, s_ = popraw(x, silnik, 1.0, od_nowa)
        dl = dlugosc(x)
        minuty += dl / 60
        mieszany = mieszaj(x, czysty, m, dl)
        if x.suffix.lower() in ROZSZ_WIDEO:
            cel = gotowe / f"{x.stem}_czysty.mp4"
            ff(["-i", x, "-i", mieszany, "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac", "-b:a", "256k",
                "-shortest", "-movflags", "+faststart", cel], f"składanie {x.name}")
        else:
            cel = gotowe / f"{x.stem}_czysty.wav"
            ff(["-i", mieszany, "-c:a", "pcm_s16le", "-ar", 48000, cel], "zapis WAV")
        wyniki.append({"zrodlo": x.name, "wynik": str(cel), "silnik": s_})
    wynik(pliki=wyniki, folder=str(gotowe), minuty=round(minuty, 1), moc=int(m * 100),
          koszt="kredyty ElevenLabs za " + f"{minuty:.1f} min" if silnik == "elevenlabs" else "za darmo (ffmpeg)")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Poprawa dźwięku mowy")
    sub = p.add_subparsers(dest="tryb", required=True)
    a1 = sub.add_parser("popraw"); a1.add_argument("--plik", required=True)
    a2 = sub.add_parser("folder"); a2.add_argument("--folder", required=True)
    a4 = sub.add_parser("premiere"); a4.add_argument("--plik", required=True); a4.add_argument("--moc", type=int, default=80)
    a4.add_argument("--silnik", default="elevenlabs", choices=["elevenlabs", "ffmpeg"]); a4.add_argument("--kopia"); a4.add_argument("--od-nowa", action="store_true")
    a3 = sub.add_parser("hurtem"); a3.add_argument("--folder", required=True); a3.add_argument("--moc", type=int, default=80)
    a3.add_argument("--silnik", default="elevenlabs", choices=["elevenlabs", "ffmpeg"]); a3.add_argument("--od-nowa", action="store_true")
    for a_ in (a1, a2):
        a_.add_argument("--silnik", default="elevenlabs", choices=["elevenlabs", "ffmpeg"])
        a_.add_argument("--sila", type=float, default=1.0)
        a_.add_argument("--od-nowa", action="store_true")
    a = p.parse_args()
    if a.tryb == "premiere":
        dla_premiere(a.plik, a.moc, a.silnik, a.kopia, a.od_nowa)
    elif a.tryb == "hurtem":
        hurtem(a.folder, a.moc, a.silnik, a.od_nowa)
    elif a.tryb == "popraw":
        c, s_ = popraw(a.plik, a.silnik, a.sila, a.od_nowa)
        wynik(plik=str(c), silnik=s_, minuty=round(dlugosc(c) / 60, 2))
    else:
        f = sciezka(a.folder)
        if (f / "_proksy").exists():
            f = f / "_proksy"
        pliki = sorted(x for x in f.iterdir() if x.suffix.lower() in ROZSZ)
        wyniki = []
        for x in pliki:
            c, s_ = popraw(x, a.silnik, a.sila, a.od_nowa)
            wyniki.append({"zrodlo": x.name, "plik": str(c), "silnik": s_})
        wynik(pliki=wyniki, minuty_lacznie=round(sum(dlugosc(w["plik"]) for w in wyniki) / 60, 2))
