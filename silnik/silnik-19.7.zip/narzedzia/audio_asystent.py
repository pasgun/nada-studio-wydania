"""Asystent audio (jak „AI Audio Assistant” w DaVinci Resolve): rozpoznaje, które ścieżki to mowa, muzyka i efekty,
wyrównuje ich głośności, ścisza muzykę pod mową (ducking) i robi gotowy miks w docelowej głośności (np. -14 LUFS do social).

  python narzedzia/audio_asystent.py analizuj --xml sekwencja.xml --folder wyniki/<...>
      -> rozpoznane ścieżki A1..An: rodzaj (dialog / muzyka / efekty), pewność, głośność, ile czasu gra
  python narzedzia/audio_asystent.py miks --xml sekwencja.xml --folder wyniki/<...> --uklad uklad.json
      uklad.json: {"cel_lufs": -14, "duck_db": 10, "sciezki": [{"nr": 1, "typ": "dialog", "korekta_db": 0}, ...]}
      -> <folder>/miks_ai_<n>.wav (48 kHz stereo) do położenia na nowej ścieżce; oryginały panel tylko wycisza.

Nic nie wysyła do internetu i nie zużywa kredytów: wszystko liczy ffmpeg na tym komputerze.
"""
import argparse
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, postep, wynik  # noqa: E402
import ciecie  # noqa: E402

PODPOWIEDZI = {
    "muzyka": ("music", "muzyka", "song", "track", "beat", "epidemic", "artlist", "envato", "bgm", "podklad", "podkład", "instrumental"),
    "efekty": ("sfx", "whoosh", "swoosh", "hit", "impact", "riser", "efekt", "fx", "click", "klik", "boom", "transition", "przejscie"),
    "dialog": ("mic", "mikrofon", "voice", "lektor", "vo_", "wywiad", "rozmowa", "zoom", "rode", "lav", "dialog", "host", "gosc", "gość"),
}
DOCELOWE = {"dialog": -20.0, "muzyka": -24.0, "efekty": -26.0}


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


def ff(args, opis):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *map(str, args)], capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        blad(f"{opis}: {r.stderr[-800:]}")


def lufs(plik):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(plik), "-af", "ebur128=framelog=quiet", "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    m = re.findall(r"I:\s+(-?[\d.]+) LUFS", r.stderr)
    v = float(m[-1]) if m else -70.0
    return v if v > -69 else None


def numery_sciezek(seq):
    audio = seq.find("media/audio")
    if audio is None:
        return []
    w = []
    for nr, tr in enumerate(audio.findall("track"), 1):
        kl = [c for c in tr.findall("clipitem") if (c.findtext("enabled") or "TRUE").upper() != "FALSE"]
        if kl and (tr.findtext("enabled") or "TRUE").upper() != "FALSE":
            w.append((nr, " ".join((c.findtext("name") or "") for c in kl[:8])))
    return w


def cechy(wav, dl):
    """Pokrycie (ile czasu coś gra) i „mowność”: mowa ma rytm sylab 2–8 razy na sekundę, muzyka jest równiejsza."""
    import wave
    import numpy as np
    with wave.open(str(wav)) as w:
        sr = w.getframerate()
        d = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768
    n = int(sr * 0.05)
    k = len(d) // n
    if k < 20:
        return 0.0, 0.0, 0
    env = np.sqrt((d[:k * n].reshape(k, n) ** 2).mean(axis=1) + 1e-10)
    db = 20 * np.log10(env + 1e-9)
    akt = db > -45
    pokrycie = float(akt.sum()) / max(1, int(dl / 0.05))
    # odcinki aktywności (do rozpoznania krótkich efektów)
    zmiany = np.diff(akt.astype(int))
    odcinki = int((zmiany == 1).sum() + (1 if akt[0] else 0))
    if akt.sum() < 40:
        return pokrycie, 0.0, odcinki
    e = env[akt]
    e = (e - e.mean()) / (e.std() + 1e-9)
    widmo = np.abs(np.fft.rfft(e)) ** 2
    f = np.fft.rfftfreq(len(e), d=0.05)
    pasmo = widmo[(f >= 2) & (f <= 8)].sum()
    calosc = widmo[(f >= 0.3) & (f <= 10)].sum() + 1e-9
    # mowa ma też częste krótkie przerwy między frazami
    przerwy = float((~akt[akt.argmax():]).mean()) if akt.any() else 0.0
    mownosc = float(pasmo / calosc) * 0.75 + min(przerwy, 0.5) * 0.5
    return pokrycie, mownosc, odcinki


def zgadnij(nazwy, pokrycie, mownosc, odcinki, dl):
    n = nazwy.lower()
    for typ, slowa in PODPOWIEDZI.items():
        if any(s in n for s in slowa):
            return typ, 0.85, "nazwa pliku"
    if pokrycie < 0.2 and odcinki > 0 and pokrycie * dl / max(1, odcinki) < 4:
        return "efekty", 0.6, "krótkie, rzadkie dźwięki"
    if mownosc >= 0.42:
        return "dialog", min(0.95, 0.5 + mownosc), "rytm mowy"
    if pokrycie > 0.5:
        return "muzyka", 0.65, "gra równo i długo"
    return "dialog", 0.45, "niepewne"


def analizuj(xml, folder):
    folder = sciezka(folder)
    folder.mkdir(parents=True, exist_ok=True)
    tree, root, seq, defs, fps = ciecie.zaladuj(xml)
    dl = ciecie.liczba(seq, "duration") / fps
    lista = numery_sciezek(seq)
    if not lista:
        blad("W tej sekwencji nie ma klipów audio.")
    wyn = []
    for i, (nr, nazwy) in enumerate(lista, 1):
        postep(f"Słucham ścieżki A{nr} ({i}/{len(lista)})")
        wav = folder / f"A{nr}_analiza.wav"
        try:
            ciecie.miks(seq, defs, wav, dl, sciezki={nr})
        except SystemExit:
            wyn.append({"nr": nr, "kod": f"A{nr}", "nazwa": nazwy[:60], "typ": "pomin", "pewnosc": 0, "powod": "brak plików na dysku"})
            continue
        pokrycie, mownosc, odcinki = cechy(wav, dl)
        typ, pewnosc, powod = zgadnij(nazwy, pokrycie, mownosc, odcinki, dl)
        wyn.append({"nr": nr, "kod": f"A{nr}", "nazwa": nazwy[:60], "typ": typ, "pewnosc": round(pewnosc, 2), "powod": powod,
                    "pokrycie_proc": round(pokrycie * 100), "lufs": lufs(wav)})
    (folder / "asystent_analiza.json").write_text(json.dumps({"sciezki": wyn, "dlugosc_s": dl}, ensure_ascii=False, indent=1), encoding="utf-8")
    wynik(sciezki=wyn, dlugosc_s=round(dl, 2))


def miks_stereo(seq, defs, cel, dl, nr):
    """Ścieżka A<nr> sekwencji jako stereo 48 kHz, w czasie osi."""
    seg = ciecie.scal(ciecie.segmenty_audio(seq, defs, sciezki={nr}))
    seg = [s for s in seg if Path(s[0]).exists()]
    if not seg:
        return False
    tmp = Path(tempfile.mkdtemp())
    czesci = []
    for k0 in range(0, len(seg), 30):
        grupa = seg[k0:k0 + 30]
        args, filtry = [], []
        for k, (p, src, tl, d, kan) in enumerate(grupa):
            args += ["-ss", f"{src:.3f}", "-t", f"{d:.3f}", "-i", p]
            wybor = f"pan=mono|c0=c{kan - 1}," if kan and ciecie.kanaly(p) >= kan and ciecie.kanaly(p) > 1 else ""
            filtry.append(f"[{k}:a]{wybor}aformat=sample_rates=48000:channel_layouts=stereo,adelay={int(round(tl * 1000))}:all=1[a{k}]")
        filtry.append("".join(f"[a{k}]" for k in range(len(grupa))) + f"amix=inputs={len(grupa)}:normalize=0:duration=longest,apad,atrim=0:{dl:.3f}[m]")
        cz = tmp / f"c{k0:04d}.wav"
        ff([*args, "-filter_complex", ";".join(filtry), "-map", "[m]", "-ar", 48000, "-c:a", "pcm_s16le", cz], f"ścieżka A{nr}")
        czesci.append(cz)
    if len(czesci) == 1:
        czesci[0].replace(cel)
    else:
        args = sum((["-i", c] for c in czesci), [])
        ff([*args, "-filter_complex", "".join(f"[{k}:a]" for k in range(len(czesci))) + f"amix=inputs={len(czesci)}:normalize=0:duration=longest[m]",
            "-map", "[m]", "-ar", 48000, "-c:a", "pcm_s16le", cel], f"ścieżka A{nr}")
    return True


def miks(xml, folder, uklad):
    folder = sciezka(folder)
    u = json.loads(sciezka(uklad).read_text(encoding="utf-8")) if isinstance(uklad, (str, Path)) else uklad
    cel_lufs = float(u.get("cel_lufs", -14))
    duck = max(0.0, float(u.get("duck_db", 10)))
    tree, root, seq, defs, fps = ciecie.zaladuj(xml)
    dl = ciecie.liczba(seq, "duration") / fps
    tmp = Path(tempfile.mkdtemp())
    szyny = {"dialog": [], "muzyka": [], "efekty": []}
    for s in u.get("sciezki", []):
        typ = s.get("typ")
        if typ not in szyny:
            continue
        nr = int(s["nr"])
        postep(f"Przygotowuję A{nr} ({typ})")
        surowy = tmp / f"A{nr}.wav"
        if not miks_stereo(seq, defs, surowy, dl, nr):
            continue
        zm = lufs(surowy)
        if zm is None:
            continue
        zysk = DOCELOWE[typ] - zm + float(s.get("korekta_db", 0))
        filtr = f"volume={zysk:.2f}dB"
        if typ == "dialog":
            filtr = "highpass=f=70," + filtr + ",acompressor=threshold=-24dB:ratio=3:attack=10:release=200:makeup=1"
        gotowy = tmp / f"A{nr}_g.wav"
        ff(["-i", surowy, "-af", filtr, "-ar", 48000, "-c:a", "pcm_s16le", gotowy], f"poziom A{nr}")
        szyny[typ].append(gotowy)
    if not any(szyny.values()):
        blad("Żadna ścieżka nie została wybrana do miksu (albo brak plików na dysku).")

    def zbierz(lista, nazwa):
        if not lista:
            return None
        c = tmp / f"{nazwa}.wav"
        if len(lista) == 1:
            return lista[0]
        args = sum((["-i", x] for x in lista), [])
        ff([*args, "-filter_complex", "".join(f"[{k}:a]" for k in range(len(lista))) + f"amix=inputs={len(lista)}:normalize=0:duration=longest[m]",
            "-map", "[m]", "-ar", 48000, "-c:a", "pcm_s16le", c], f"szyna {nazwa}")
        return c
    postep("Składam szyny i ściszam muzykę pod mową")
    dial, muz, ef = zbierz(szyny["dialog"], "dialog"), zbierz(szyny["muzyka"], "muzyka"), zbierz(szyny["efekty"], "efekty")
    wej, filtry, wyjscia = [], [], []
    if dial:
        wej += ["-i", dial]
        filtry.append("[0:a]asplit=2[d][sc]" if muz and duck > 0 else "[0:a]anull[d]")
        wyjscia.append("[d]")
    if muz:
        i = len(wej) // 2
        wej += ["-i", muz]
        if dial and duck > 0:
            # ducking: kompresor sterowany mową (sidechain); ratio dobrane tak, żeby muzyka zjechała mniej więcej o duck_db
            ratio = min(20, 1 + duck / 3)
            filtry.append(f"[{i}:a][sc]sidechaincompress=threshold=0.02:ratio={ratio:.1f}:attack=40:release=600:makeup=1[m]")
        else:
            filtry.append(f"[{i}:a]anull[m]")
        wyjscia.append("[m]")
    if ef:
        i = len(wej) // 2
        wej += ["-i", ef]
        filtry.append(f"[{i}:a]anull[e]")
        wyjscia.append("[e]")
    filtry.append("".join(wyjscia) + f"amix=inputs={len(wyjscia)}:normalize=0:duration=longest,atrim=0:{dl:.3f}[x]")
    surowy = tmp / "miks_surowy.wav"
    ff([*wej, "-filter_complex", ";".join(filtry), "-map", "[x]", "-ar", 48000, "-c:a", "pcm_s16le", surowy], "miks")
    postep(f"Ustawiam głośność końcową {cel_lufs:g} LUFS")
    zm = lufs(surowy) or cel_lufs
    nr = 1
    while (folder / f"miks_ai_{nr}.wav").exists():
        nr += 1
    cel = folder / f"miks_ai_{nr}.wav"
    ff(["-i", surowy, "-af", f"volume={cel_lufs - zm:.2f}dB,alimiter=limit=0.891:level=false", "-ar", 48000, "-c:a", "pcm_s16le", cel], "głośność końcowa")
    koncowe = lufs(cel)
    for x in tmp.iterdir():
        x.unlink()
    tmp.rmdir()
    wynik(plik=str(cel), lufs=koncowe, cel_lufs=cel_lufs, dialog=len(szyny["dialog"]), muzyka=len(szyny["muzyka"]), efekty=len(szyny["efekty"]),
          sciezki=[int(s["nr"]) for s in u.get("sciezki", []) if s.get("typ") in szyny])


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Asystent audio: miks mowy, muzyki i efektów")
    sub = p.add_subparsers(dest="tryb", required=True)
    a1 = sub.add_parser("analizuj"); a1.add_argument("--xml", required=True); a1.add_argument("--folder", required=True)
    a2 = sub.add_parser("miks"); a2.add_argument("--xml", required=True); a2.add_argument("--folder", required=True); a2.add_argument("--uklad", required=True)
    a = p.parse_args()
    if a.tryb == "analizuj":
        analizuj(a.xml, a.folder)
    else:
        miks(a.xml, a.folder, a.uklad)
