"""Kolor: rozpoznawanie kamer i profili, biblioteka LUT-ów, pomiary do wyrównania kolorów i plan korekcji dla panelu Premiere.

  python narzedzia/kolor.py kamery                                   dane kamer (natywne ISO, profile, porady) i klimaty
  python narzedzia/kolor.py wykryj --lista klipy.json                kamera, profil i ISO każdego pliku (metadane, plik XML Sony, SRT DJI, nazwa)
  python narzedzia/kolor.py luty                                     moje LUT-y z przypisaniem do kamer
  python narzedzia/kolor.py dodaj-lut --plik X.cube --kamera fx30 --profil slog3 [--rodzaj techniczny|kreatywny] [--nazwa ...]
  python narzedzia/kolor.py usun-lut --id <id>                       (kopia znika z biblioteki; Twój oryginalny plik zostaje)
  python narzedzia/kolor.py instaluj-luty                            kopiuje LUT-y do folderów Premiere (Lumetri: Wejściowa LUT / Wygląd)
  python narzedzia/kolor.py plan --dane wejscie.json --wyjscie plan.json
       wejscie: {"klipy": [{"plik", "start", "end", "tor"}], "klimat": "kinowy", "sila": 1.0, "hdr": false,
                 "wyrownaj": true, "wzor": "<id kamery albo pusty>", "przypisania": {"<kamera>|<profil>": "<id LUT-a>"}, "proksy": {...}}

Panel sam nakłada wynik na oś (Lumetri na klipach albo na warstwach korekcyjnych, zawsze edytowalne).
Pomiary robi na proksy (pliki RAW) i po nałożeniu LUT-a kamery, żeby porównywać obraz już w Rec.709.
"""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, wynik  # noqa: E402

KAT = Path(__file__).resolve().parent / "kolor"
PLIK_LUTOW = KAT / "luty.json"
FOLDER_LUTOW = KAT / "luty"
FL = 0x08000000 if sys.platform.startswith("win") else 0


def kamery():
    return json.loads((KAT / "kamery.json").read_text(encoding="utf-8"))


def klimaty():
    return json.loads((KAT / "klimaty.json").read_text(encoding="utf-8"))


def luty():
    try:
        return json.loads(PLIK_LUTOW.read_text(encoding="utf-8"))
    except Exception:
        return {"luty": []}


def zapisz_luty(d):
    KAT.mkdir(parents=True, exist_ok=True)
    PLIK_LUTOW.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")


def ffprobe(plik):
    try:
        r = subprocess.run(["ffprobe", "-v", "error", "-show_format", "-show_streams", "-of", "json", str(plik)],
                           capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=40, creationflags=FL)
        return json.loads(r.stdout or "{}")
    except Exception:
        return {}


def _sony_xml(p):
    """Plik XML zapisywany przez Sony obok filmu (C0001M01.XML): model, krzywa (gamma), przestrzeń barw, ISO."""
    for kand in (p.with_name(p.stem + "M01.XML"), p.with_name(p.stem + "M01.xml"), p.with_suffix(".XML"), p.with_suffix(".xml")):
        if kand.exists():
            t = kand.read_text(encoding="utf-8", errors="replace")
            d = {"plik": kand.name}
            m = re.search(r'modelName="([^"]+)"', t)
            if m:
                d["model"] = m.group(1)
            for nazwa, klucz in (("CaptureGammaEquation", "gamma"), ("CaptureColorPrimaries", "gamut"), ("ISOSensitivity", "iso"), ("ExposureIndexOfPhotoMeter", "ei")):
                m = re.search(r'name="%s"\s+value="([^"]+)"' % nazwa, t)
                if m:
                    d[klucz] = m.group(1)
            return d
    return None


def _dji_srt(p):
    """Plik .SRT z drona DJI obok filmu: ISO i tryb koloru (np. color_md: dlog_m)."""
    for kand in (p.with_suffix(".SRT"), p.with_suffix(".srt")):
        if kand.exists():
            t = kand.read_text(encoding="utf-8", errors="replace")[:20000]
            d = {"plik": kand.name}
            m = re.search(r"\[iso\s*:\s*(\d+)\]", t, re.I)
            if m:
                d["iso"] = m.group(1)
            m = re.search(r"\[color_md\s*:\s*([\w-]+)\]", t, re.I)
            if m:
                d["kolor"] = m.group(1)
            return d
    return None


def wykryj_plik(plik, domyslna_braw=None):
    p = Path(plik)
    baza = kamery()["kamery"]
    w = {"plik": str(p), "kamera": None, "profil": None, "iso": None, "zrodlo": [], "pewnosc": "niska"}
    tagi, strumien = {}, {}
    if p.suffix.lower() != ".braw" and p.exists():
        d = ffprobe(p)
        tagi = {k.lower(): str(v) for k, v in ((d.get("format") or {}).get("tags") or {}).items()}
        strumien = next((s for s in d.get("streams", []) if s.get("codec_type") == "video"), {}) or {}
        for k, v in (strumien.get("tags") or {}).items():
            tagi.setdefault(k.lower(), str(v))
    tekst_tagow = " ".join(tagi.values())
    sony = _sony_xml(p) if p.exists() else None
    dji = _dji_srt(p) if p.exists() else None

    def pasuje(k):
        r = k.get("rozpoznanie") or {}
        if p.suffix.lower() in r.get("rozszerzenia", []):
            return "rozszerzenie"
        for m in r.get("modele", []):
            if m.lower() in tekst_tagow.lower() or (sony and m.lower() == str(sony.get("model", "")).lower()):
                return "metadane"
        for wz in r.get("nazwy_plikow", []):
            if re.search(wz, p.name):
                return "nazwa"
        return None

    trafienia = [(k, pasuje(k)) for k in baza]
    trafienia = [(k, z) for k, z in trafienia if z]
    kolej = {"metadane": 0, "rozszerzenie": 1, "nazwa": 2}
    trafienia.sort(key=lambda x: kolej[x[1]])
    if p.suffix.lower() == ".braw":
        k = next((x for x in baza if x["id"] == domyslna_braw), None) or next(x for x in baza if x["id"] == "bmpcc6kpro")
        w.update(kamera=k["id"], profil="bmd-film-gen5", pewnosc="średnia")
        w["zrodlo"].append("plik BRAW (Blackmagic); model z ustawień panelu" if domyslna_braw else "plik BRAW (Blackmagic); model przyjęty: Pocket 6K Pro")
    elif sony:
        k = next((x for x in baza if any(m.lower() == str(sony.get("model", "")).lower() for m in (x.get("rozpoznanie") or {}).get("modele", []))), None) \
            or next(x for x in baza if x["id"] == "fx30")
        g = str(sony.get("gamma", "")).lower()
        prof = "slog3" if "s-log3" in g and "cine" in str(sony.get("gamut", "")).lower() + g else "sgamut3" if "s-log3" in g else "slog2" if "s-log2" in g else "hlg" if "hlg" in g else "rec709"
        w.update(kamera=k["id"], profil=prof, pewnosc="wysoka")
        if sony.get("iso"):
            w["iso"] = int(re.sub(r"\D", "", sony["iso"]) or 0) or None
        w["zrodlo"].append(f"plik Sony {sony['plik']} ({sony.get('model', '?')}, {sony.get('gamma', '?')})")
    elif dji or re.match(r"^DJI_", p.name):
        osmo = bool(re.search(r"osmo|pocket", tekst_tagow, re.I))
        k = next(x for x in baza if x["id"] == ("dji-osmo" if osmo else "dji-dron"))
        tryb = str((dji or {}).get("kolor", "")).lower()
        prof = "dlogm" if "log_m" in tryb or "dlogm" in tryb or "d-log m" in tekst_tagow.lower() else "dlog" if "log" in tryb else "hlg" if "hlg" in tryb else ("normal" if tryb else k["profile"][0]["id"])
        w.update(kamera=k["id"], profil=prof, pewnosc="wysoka" if dji else "średnia")
        if dji and dji.get("iso"):
            w["iso"] = int(dji["iso"])
        w["zrodlo"].append(f"plik DJI {dji['plik']} (tryb {tryb or '?'})" if dji else "nazwa pliku DJI_ (brak pliku .SRT: profil przyjęty)")
    elif trafienia:
        k, z = trafienia[0]
        w.update(kamera=k["id"], profil=next((pr["id"] for pr in k["profile"] if pr.get("domyslny")), k["profile"][0]["id"]), pewnosc="średnia" if z == "metadane" else "niska")
        w["zrodlo"].append(f"{z}: {k['nazwa']}")
    else:
        w.update(kamera="inna", profil="rec709")
        w["zrodlo"].append("nie rozpoznano: przyjęto Rec.709")
    trc = str(strumien.get("color_transfer", ""))
    if trc in ("arib-std-b67",):
        w["profil"] = "hlg" if any(pr["id"] == "hlg" for pr in next(x for x in baza if x["id"] == w["kamera"])["profile"]) else w["profil"]
        w["zrodlo"].append("obraz w HLG (HDR)")
    elif trc == "smpte2084":
        w["zrodlo"].append("obraz w PQ (HDR)")
    if strumien:
        w["rozdzielczosc"] = f"{strumien.get('width')}x{strumien.get('height')}"
        w["bity"] = 10 if "10" in str(strumien.get("pix_fmt", "")) else 8
    k = next(x for x in baza if x["id"] == w["kamera"])
    w["kamera_nazwa"] = k["nazwa"]
    pr = next((x for x in k["profile"] if x["id"] == w["profil"]), k["profile"][0])
    w["profil_nazwa"] = pr["nazwa"]
    uw = []
    if w["iso"] and k.get("natywne_iso"):
        if w["iso"] not in k["natywne_iso"]:
            najbl = min(k["natywne_iso"], key=lambda x: abs(x - w["iso"]))
            uw.append(f"ISO {w['iso']} nie jest natywne (natywne: {', '.join(map(str, k['natywne_iso']))}): możliwy większy szum albo mniej zakresu; najbliższe natywne {najbl}.")
        if k.get("min_iso_log") and w["iso"] < k["min_iso_log"] and "log" in w["profil"]:
            uw.append(f"ISO poniżej {k['min_iso_log']} w logu: mniej zakresu w światłach.")
    w["uwagi"] = uw
    return w


# ---------- biblioteka LUT-ów ----------
def dodaj_lut(plik, kamera, profil, rodzaj="techniczny", nazwa=None):
    src = Path(plik)
    if not src.exists() or src.suffix.lower() not in (".cube", ".3dl"):
        blad("Podaj plik LUT .cube (albo .3dl).")
    if not any(k["id"] == kamera for k in kamery()["kamery"]) and rodzaj == "techniczny":
        blad(f"Nie znam kamery {kamera}. Lista: python narzedzia/kolor.py kamery")
    FOLDER_LUTOW.mkdir(parents=True, exist_ok=True)
    h = hashlib.sha1(src.read_bytes()).hexdigest()[:8]
    lid = re.sub(r"[^a-z0-9]+", "-", (nazwa or src.stem).lower()).strip("-")[:40] + "-" + h
    cel = FOLDER_LUTOW / (lid + src.suffix.lower())
    shutil.copyfile(src, cel)
    d = luty()
    d["luty"] = [x for x in d["luty"] if x["id"] != lid]
    d["luty"].append({"id": lid, "nazwa": nazwa or src.stem, "plik": str(cel.relative_to(KATALOG_SILNIKA)).replace("\\", "/"), "oryginal": str(src),
                      "kamera": kamera or None, "profil": profil or None, "rodzaj": rodzaj, "w_premiere": f"Nada - {nazwa or src.stem}{src.suffix.lower()}"})
    zapisz_luty(d)
    return d["luty"][-1]


def foldery_premiere():
    """Foldery LUT-ów Lumetri dla bieżącego użytkownika (Premiere skanuje je przy starcie)."""
    if sys.platform.startswith("win"):
        b = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming")) / "Adobe" / "Common" / "LUTs"
    else:
        b = Path.home() / "Library" / "Application Support" / "Adobe" / "Common" / "LUTs"
    return {"techniczny": b / "Technical", "kreatywny": b / "Creative"}


def instaluj_luty():
    f = foldery_premiere()
    zrobione = []
    for x in luty()["luty"]:
        cel = f["kreatywny" if x["rodzaj"] == "kreatywny" else "techniczny"]
        cel.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(KATALOG_SILNIKA / x["plik"], cel / x["w_premiere"])
        zrobione.append(str(cel / x["w_premiere"]))
    return {"zainstalowane": zrobione, "foldery": {k: str(v) for k, v in f.items()},
            "uwaga": "Zamknij i otwórz Premiere, żeby Lumetri zobaczył nowe LUT-y (lista: Wejściowa LUT i Wygląd). Potem w panelu: Kolor > Ustal pozycje LUT-ów."}


# ---------- pomiary do wyrównania ----------
def _proksy_dla(plik, proksy):
    try:
        import aftermovie
        aftermovie.PROKSY.update(mapa={}, foldery=[], indeks=None)
        if proksy:
            n = lambda x: re.sub(r"[\\/]+", "/", str(x)).lower()
            aftermovie.PROKSY["mapa"] = {n(k): v for k, v in (proksy.get("mapa") or {}).items()}
            aftermovie.PROKSY["foldery"] = [f for f in proksy.get("foldery") or [] if Path(f).is_dir()]
            aftermovie.PROKSY["norm"] = n
        return aftermovie.do_analizy(plik)
    except Exception:
        return Path(plik) if Path(plik).suffix.lower() != ".braw" else None


def zmierz(plik, lut=None, od=0.0, do=None):
    """Średnia jasność i proporcje kolorów w średnich tonach (po LUT-cie, jeśli jest), z 3 klatek."""
    import numpy as np
    dl = (do - od) if do else 4.0
    momenty = [od + dl * f for f in (0.2, 0.5, 0.8)]
    wyniki = []
    for t in momenty:
        vf = "scale=160:-2"
        if lut:
            vf = f"lut3d='{str(lut).replace(chr(92), '/').replace(':', chr(92) + ':')}'," + vf
        try:
            r = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{max(0, t):.2f}", "-i", str(plik), "-frames:v", "1", "-vf", vf, "-f", "rawvideo", "-pix_fmt", "rgb24", "-"],
                               capture_output=True, timeout=60, creationflags=FL)
            if r.returncode != 0 or not r.stdout:
                continue
            a = np.frombuffer(r.stdout, dtype=np.uint8).astype(np.float32) / 255.0
            a = a.reshape(-1, 3)
            y = 0.2126 * a[:, 0] + 0.7152 * a[:, 1] + 0.0722 * a[:, 2]
            srod = a[(y > 0.15) & (y < 0.85)]
            if len(srod) < 50:
                srod = a
            wyniki.append({"y": float(np.median(y)), "r": float(srod[:, 0].mean()), "g": float(srod[:, 1].mean()), "b": float(srod[:, 2].mean()),
                           "jasne": float((y > 0.95).mean()), "ciemne": float((y < 0.03).mean())})
        except Exception:
            continue
    if not wyniki:
        return None
    return {k: round(sum(w[k] for w in wyniki) / len(wyniki), 4) for k in wyniki[0]}


def plan(dane):
    baza = {k["id"]: k for k in kamery()["kamery"]}
    kl = {k["id"]: k for k in klimaty()["klimaty"]}
    lt = {x["id"]: x for x in luty()["luty"]}
    przyp = dane.get("przypisania") or {}
    klipy = dane.get("klipy") or []
    pomiary = []
    for c in klipy:
        w = wykryj_plik(c["plik"], dane.get("braw_kamera"))
        c.update(wykrycie=w)
        lut_id = przyp.get(f"{w['kamera']}|{w['profil']}")
        if lut_id is None:
            lut_id = next((x["id"] for x in lt.values() if x.get("kamera") == w["kamera"] and x.get("profil") == w["profil"] and x["rodzaj"] == "techniczny"), None)
        c["lut"] = lut_id
        if dane.get("wyrownaj", True):
            zr = _proksy_dla(c["plik"], dane.get("proksy"))
            lut_plik = KATALOG_SILNIKA / lt[lut_id]["plik"] if lut_id and lut_id in lt else None
            c["pomiar"] = zmierz(zr, lut_plik, float(c.get("od") or 0), float(c.get("od") or 0) + float(c["end"]) - float(c["start"])) if zr and Path(zr).exists() else None
            if c["pomiar"]:
                pomiary.append(c)
    # wzór: wybrana kamera albo najczęstsza; cel = mediana jej klipów
    korekty = {}
    if pomiary:
        from statistics import median
        ile = {}
        for c in pomiary:
            ile[c["wykrycie"]["kamera"]] = ile.get(c["wykrycie"]["kamera"], 0) + 1
        wzor = dane.get("wzor") or max(ile, key=ile.get)
        ref = [c["pomiar"] for c in pomiary if c["wykrycie"]["kamera"] == wzor] or [c["pomiar"] for c in pomiary]
        cel_y = median(x["y"] for x in ref)
        cel_rb = median((x["r"] - x["b"]) for x in ref)
        cel_g = median((x["g"] - (x["r"] + x["b"]) / 2) for x in ref)
        import math
        for c in pomiary:
            m = c["pomiar"]
            # ekspozycja w stopniach (obraz w Rec.709 ma gammę ok. 2,4, więc różnicę liczymy po linearyzacji), ostrożnie i z limitem
            ev = math.log2(max(cel_y, 0.01) ** 2.4 / max(m["y"], 0.01) ** 2.4) * 0.6
            temp = (cel_rb - (m["r"] - m["b"])) * 160
            tint = -(cel_g - (m["g"] - (m["r"] + m["b"]) / 2)) * 200
            korekty[id(c)] = {"ekspozycja": round(max(-1.5, min(1.5, ev)), 2), "temperatura": round(max(-35, min(35, temp))), "odcien": round(max(-30, min(30, tint)))}
        dane["wzor_uzyty"] = wzor
    look = kl.get(dane.get("klimat") or "naturalny", kl["naturalny"])
    sila = float(dane.get("sila", 1.0))
    lum = {}
    for k, v in (look.get("lumetri") or {}).items():
        if isinstance(v, (int, float)):
            lum[k] = round(100 + (v - 100) * sila) if k == "nasycenie" else round(v * sila, 2)
        else:
            lum[k] = v
    hdr = klimaty()["hdr"] if dane.get("hdr") else None
    if hdr:
        for k, v in hdr["lumetri"].items():
            lum[k] = round(lum.get(k, 100 if k == "nasycenie" else 0) + (v - 100 if k == "nasycenie" else v))
    wynik_klipy = []
    for c in klipy:
        w = c["wykrycie"]
        k = baza.get(w["kamera"], {})
        wynik_klipy.append({"tor": c.get("tor"), "start": c.get("start"), "end": c.get("end"), "nazwa": c.get("nazwa") or Path(c["plik"]).name, "plik": c["plik"],
                            "kamera": w["kamera"], "kamera_nazwa": w["kamera_nazwa"], "profil": w["profil"], "profil_nazwa": w["profil_nazwa"], "iso": w["iso"],
                            "natywne_iso": k.get("natywne_iso"), "uwagi": w["uwagi"], "zrodlo": w["zrodlo"], "pewnosc": w["pewnosc"],
                            "lut": c.get("lut"), "lut_premiere": lt[c["lut"]]["w_premiere"] if c.get("lut") in lt else None,
                            "korekta": korekty.get(id(c), {}), "pomiar": c.get("pomiar")})
    grupy = {}
    for c in wynik_klipy:
        g = grupy.setdefault(f"{c['kamera']}|{c['profil']}", {"kamera": c["kamera"], "kamera_nazwa": c["kamera_nazwa"], "profil": c["profil"], "profil_nazwa": c["profil_nazwa"],
                                                            "klipow": 0, "lut": c["lut"], "iso": set(), "uwagi": set()})
        g["klipow"] += 1
        if c["iso"]:
            g["iso"].add(c["iso"])
        g["uwagi"].update(c["uwagi"])
    for g in grupy.values():
        g["iso"], g["uwagi"] = sorted(g["iso"]), sorted(g["uwagi"])
    return {"klipy": wynik_klipy, "grupy": list(grupy.values()), "klimat": look["id"], "klimat_nazwa": look["nazwa"], "lumetri_klimat": lum,
            "klarownosc": hdr["klarownosc"] if hdr else None, "hdr_uwaga": hdr["eksport_hdr"] if hdr else None, "wzor": dane.get("wzor_uzyty")}


if __name__ == "__main__":
    a = argparse.ArgumentParser(description="Kolor: kamery, LUT-y, wyrównanie i plan korekcji")
    s = a.add_subparsers(dest="tryb", required=True)
    s.add_parser("kamery")
    w = s.add_parser("wykryj"); w.add_argument("--lista", required=True); w.add_argument("--braw-kamera")
    s.add_parser("luty")
    d = s.add_parser("dodaj-lut"); d.add_argument("--plik", required=True); d.add_argument("--kamera", default=None); d.add_argument("--profil", default=None)
    d.add_argument("--rodzaj", default="techniczny", choices=["techniczny", "kreatywny"]); d.add_argument("--nazwa")
    u = s.add_parser("usun-lut"); u.add_argument("--id", required=True)
    s.add_parser("instaluj-luty")
    p = s.add_parser("plan"); p.add_argument("--dane", required=True); p.add_argument("--wyjscie", required=True)
    x = a.parse_args()
    if x.tryb == "kamery":
        wynik(**kamery(), klimaty=klimaty())
    elif x.tryb == "wykryj":
        lista = json.loads(Path(x.lista).read_text(encoding="utf-8"))
        wynik(pliki=[wykryj_plik(p if isinstance(p, str) else p["plik"], x.braw_kamera) for p in lista])
    elif x.tryb == "luty":
        wynik(**luty(), foldery_premiere={k: str(v) for k, v in foldery_premiere().items()})
    elif x.tryb == "dodaj-lut":
        wynik(lut=dodaj_lut(x.plik, x.kamera, x.profil, x.rodzaj, x.nazwa))
    elif x.tryb == "usun-lut":
        dd = luty()
        stary = next((l for l in dd["luty"] if l["id"] == x.id), None)
        if not stary:
            blad("Nie ma takiego LUT-a.")
        dd["luty"] = [l for l in dd["luty"] if l["id"] != x.id]
        zapisz_luty(dd)
        try:
            (KATALOG_SILNIKA / stary["plik"]).unlink()
        except Exception:
            pass
        wynik(usunieto=x.id)
    elif x.tryb == "instaluj-luty":
        wynik(**instaluj_luty())
    elif x.tryb == "plan":
        dane = json.loads(Path(x.dane).read_text(encoding="utf-8"))
        wyn = plan(dane)
        Path(x.wyjscie).write_text(json.dumps(wyn, ensure_ascii=False, indent=1), encoding="utf-8")
        wynik(plik=x.wyjscie, klipow=len(wyn["klipy"]), grupy=wyn["grupy"], wzor=wyn["wzor"])
