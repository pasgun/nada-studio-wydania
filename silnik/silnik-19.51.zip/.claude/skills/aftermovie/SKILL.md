---
name: aftermovie
description: Robi aftermovie z nagrań użytkownika (wydarzenie, impreza, konferencja), cięte w rytm muzyki, w pionie i/lub poziomie, z timeline'em do Premiere Pro. Uruchamiane poleceniem /aftermovie z danymi zadania w JSON albo z panelu w Premiere (zadanie z "zrodlo": "premiere").
disable-model-invocation: true
---

Zrób aftermovie według tego zadania:

$ARGUMENTS

Zasady ogólne są w `CLAUDE.md` (sekcje „Własne nagrania”, „Muzyka i efekty”, „Ruch kamery i przejścia”, „Eksport do Premiere”, „Marka i brandbook”).

## 0. Skąd przyszło zadanie

- **Ze Studio** (`/aftermovie {json}` z polami `zadanie` i `klient`): po każdym kroku jedno krótkie zdanie, co jest zrobione. Przy `plan_przed_startem: true` pokaż plan i poczekaj na „ok”.
- **Z panelu w Premiere** (`"zrodlo": "premiere"`): użytkownika NIE MA przy komputerze. Nie zadawaj pytań i na nic nie czekaj: gdy czegoś brakuje albo coś jest niejasne, wybierz rozsądnie sam i zapisz to w raporcie. Na początku każdego etapu wywołaj `python narzedzia/postep.py --etap <klucz> --tekst "<co robisz, krótko po polsku>"` (klucze niżej). Panel rysuje z tego pasek postępu i szacowany czas. Gdy coś uniemożliwia dokończenie (np. brak plików), wywołaj `python narzedzia/postep.py --blad "<co i jak naprawić>"` i zakończ.
- **Z panelu w DaVinci** (`"zrodlo": "premiere"`, `"program": "davinci"`): wszystko jak z panelu Premiere (bez pytań, etapy przez `postep.py`), a `sekwencja.xml` to oś wyeksportowana z DaVinci (FCP 7 XML). Gotowy timeline XML z `Projekty/` użytkownik wczyta w panelu DaVinci (zakładka Wyniki); przejścia są tam tylko markerami.

Etapy (klucze dla postep.py): `przygotowanie`, `material`, `muzyka`, `historia` (tylko gdy jest narracja), `plan`, `montaz`, `kontrola`. Na końcu `--gotowe`.

## 1. Przygotowanie (`przygotowanie`)

Ze Studio:
- Odczytaj `zadanie` (brief, `dlugosc` w sekundach, `orientacje`: `pion` i/lub `poziom`, `nagrania_folder`, `serwisy`, `premiere`, `przejscia`) i `klient`.
- Załóż folder wyników: `python narzedzia/wspolne.py --klient "<klient.skrot albo klient.nazwa>" --projekt "<zadanie.tytul>"` (np. `wyniki/emeraldmedia_seriaief10_211026`), zapisz w nim `zadanie.json`. Wznowienie po przerwie: używaj gotowych plików.
- Brak `nagrania_folder` albo pusty folder: zatrzymaj się i poproś o nagrania.

Z panelu: folder wyników jest w `folder` (już założony, jest w nim `sekwencja.xml` wyeksportowana z Premiere i `postep.json`); zapisz w nim `zadanie.json`. Klient jest w `klient` (może być pusty: wtedy bez marki, neutralna plansza).

Wspólne:
- Styl: jeśli klient ma `styl_wideo.md` (albo starszy `styl.md`), trzymaj się go; jeśli ma filmy w `referencje/wideo/` bez notatki, najpierw ją zrób.
- Marka: `python narzedzia/marka.py sprawdz --folder <klient.folder>` i postępuj według „Marka i brandbook”. Kolory planszy końcowej bierzesz z `marka.md`. Logo: z panelu dostajesz konkretny plik w `logo` (puste = bez logo w filmie, tylko ewentualnie na planszy według `marka.md`); ze Studio wybierz wariant z `marka.md`, pasujący do tła.

## 2. Przegląd materiału (`material`)

- Ze Studio: `python narzedzia/analiza.py folder --folder <nagrania_folder> --mowa nie` (z `--mowa auto`, gdy brief mówi o przemowach albo wywiadach).
- Z panelu: `python narzedzia/aftermovie.py material --xml <folder>/sekwencja.xml --folder <folder> --mowa <nie albo auto, gdy narracja.tryb zawiera "wywiady">`. Dostajesz `material_premiere.json`: ścieżki klipów na dysku, `zakresy` (fragmenty, które użytkownik zostawił na osi: wybieraj ujęcia TYLKO z nich), arkusze kadrów, transkrypcje, oraz `muzyka_z_osi` (pliki audio bez obrazu leżące na osi).
- RAW (BRAW, R3D) analizuję przez proksy: podpięte w Premiere, z podfolderu `_proksy/` obok oryginałów albo z folderów z proksy ustawionych w panelu (`proksy.json` w folderze zadania). Gdy klip w `material_premiere.json` ma pole `proksy`, w planie montażu jako plik sceny podaj właśnie je (ffmpeg nie czyta RAW); eksport do Premiere sam wskaże oryginał. Gdy proksy nie ma, komunikat narzędzia mówi, co zrobić.

Obejrzyj wszystkie arkusze kadrów (Read). Spisz w `material.md` najlepsze fragmenty: plik, od–do (s), co widać, kategoria (ogólny plan miejsca, ludzie i emocje, detal, akcja, scena/występ, finał), ocena 1–3. Odrzucaj ujęcia nieostre, z przypadkowymi osobami na pierwszym planie, z logo konkurencji, ciemne.

## 3. Muzyka i rytm (`muzyka`)

Źródło muzyki (`muzyka.zrodlo` z panelu albo `serwisy` ze Studio):
- `timeline`: pierwszy plik z `muzyka_z_osi` (jeśli pusto, przejdź na `epidemic`).
- `plik`: `muzyka.plik`.
- `epidemic`: szukaj i pobierz sam przez Epidemic Sound; nastrój z `muzyka.nastroj` i `muzyka.opis` (albo z briefu). Dla aftermovie zwykle energetyczna, bez wokalu albo z krótkim wokalem. Gdy jest lektor albo wywiady: koniecznie instrumentalna.
- `artlist` (tylko ze Studio): 3 propozycje, użytkownik pobiera do `muzyka/`.
- `folder`: najlepiej pasujący plik z `muzyka/`.

Zapisz utwór jako `<folder>/muzyka.mp3` (ffmpeg, jeśli to inny format) i uruchom `python narzedzia/bity.py --plik <folder>/muzyka.mp3`: tempo, bity, takty, energia taktów, „drop”. Jeśli utwór jest dłuższy niż film, wybierz fragment (`muzyka.start`) tak, żeby film kończył się na końcu frazy, a najmocniejsza część trafiła na środek–koniec. Czasy bitów przeliczasz wtedy względem `start`.

## 4. Historia: lektor albo wywiady (`historia`, tylko gdy `narracja.tryb` nie jest `brak`)

- `lektor`: tekst z `narracja.tekst`; jeśli pusty, napisz go sam z briefu i materiału (krótkie zdania, 2–2,5 słowa na sekundę filmu, bez frazesów; język z `narracja.jezyk`, domyślnie polski). Zapisz `<folder>/lektor.txt` i `python narzedzia/lektor.py --tekst-plik <folder>/lektor.txt --voice <narracja.glos albo voice_id z karty klienta> --wyjscie <folder>`. Brak ID głosu: `python narzedzia/lektor.py --glosy` i wybierz pasujący (z panelu: sam, zapisz wybór w raporcie).
- `wywiady`: z transkrypcji (`mowa.slowa_plik` klipów) wybierz wypowiedzi i ułóż z nich historię: mocne otwarcie (hak), kontekst (co to za wydarzenie), emocje i wrażenia, puenta na koniec. Tnij na granicach zdań, bez „yyy” i powtórzeń; miejsca cięcia bierz z `python narzedzia/granice.py frazy --plik <klip>` (`ciecie_od`/`ciecie_do`, mierzone w dźwięku, bo czasy słów ucinają końcówki), a pauz krótszych niż 1 s w środku wypowiedzi nie wycinaj. Łącznie wypowiedzi zajmują 40–60% długości filmu; między nimi przerwy na same ujęcia i muzykę. Zapisz scenariusz w `historia.md` (kolejność, plik, od–do, tekst).
- `lektor+wywiady`: wypowiedzi jak wyżej, lektor tylko spina je krótkimi zdaniami (otwarcie i zakończenie).

## 5. Plan montażu (`plan`)

Długość: `dlugosc` (s). Dynamika (`dynamika` z panelu, ze Studio z briefu):
- `spokojna`: ujęcia po 1–2 takty, mało przejść, dłuższe ujęcia ogólne,
- `srednia`: ujęcia po 2–4 bity, w szczycie co 2 bity,
- `dynamiczna`: od „drop” cięcia co 1 bit, krótkie serie detali, więcej przejść.

Przejścia (`przejscia`):
- `ciecia`: same cięcia,
- `subtelne`: `przenikanie`, `fade`, `czern`, i to tylko przy zmianie części,
- `dynamiczne`: `whip-*`, `flash`, `zoom-in`, `smuga-*` w szczycie, 1 przejście na 4–8 cięć,
- `mieszane`: subtelne we wstępie i zakończeniu, dynamiczne w szczycie.

Struktura (dopasuj do energii taktów):
1. Wstęp (niska energia): 2–4 ujęcia ogólne, miejsce, przygotowania.
2. Rozkręcenie: ludzie, detale.
3. Szczyt od „drop”: najmocniejsze ujęcia (akcja, emocje, scena).
4. Zakończenie: 2–3 dłuższe ujęcia, wyciszenie, plansza końcowa na ostatnie 2–3 s (`plansza`: tekst, przycisk, data i miejsce; puste pola pomiń; kolory z marki).

Każde cięcie MUSI wypadać na bicie: czas sceny = różnica między kolejnymi bitami, na które tniesz. Przy wywiadach albo lektorze cięcia obrazu nadal na bitach, a mowa leci pod ujęciami (`dzwiek_z` w scenie z ujęciem przebitkowym; patrz opis w `narzedzia/montaz.py`), muzyka ściszona pod mową (`glosnosc` 0.2–0.3), głośniej w przerwach. Nie powtarzaj ujęć, unikaj dwóch podobnych planów pod rząd.

Dźwięk z ujęć (`dzwiek_z_ujec`): `brak`; `momenty` (domyślnie: tylko pojedyncze mocne chwile, oklaski, okrzyk, `"dzwiek": true`, `"glosnosc": 0.5`); `tlo` (cichy dźwięk ujęć pod muzyką przez cały film, `"glosnosc": 0.25`).
Ruch kamery (`ruch_kamery`, domyślnie tak) tylko na statycznych ujęciach.
Napisy (`napisy`): tylko gdy jest mowa (lektor albo wywiady) i `napisy` nie jest `false`; styl z karty klienta (`klient.napisy`), inaczej domyślny.

Pokaż plan jako tabelę (nr, od–do na osi filmu, plik, fragment, kategoria, przejście) i podsumowanie (liczba ujęć, kategorie). Z panelu tylko zapisz ją w `plan.md`.

## 6. Montaż (`montaz`)

Dla każdej orientacji osobny plan:
- pion: `"format": [1080, 1920]`, plik `aftermovie_pion.mp4`
- poziom: `"format": [1920, 1080]`, plik `aftermovie_poziom.mp4`

`plan_<orientacja>.json`: `"dopasuj_do_lektora": false`, sceny z `start` i `czas` w sekundach (dokładnie z bitów), `ruch`, przejścia, `muzyka` z `glosnosc` 0.9–1.0 i `start` (pod mową ściszona), `lektor` i `slowa`, gdy jest lektor, `plansza_koncowa`, `logo` (z panelu: plik z `logo`, pozycja z `logo_pozycja`; `tylko_plansza` = logo tylko na planszy), `"premiere": true` (z panelu zawsze), `"efekty_auto": true` (whoosh i błysk przy dynamicznych przejściach; `false` tylko gdy zadanie ma `efekty_dzwiekowe: false`). Bez napisów (`"napisy": false`), chyba że wyżej wynika inaczej.

`python narzedzia/montaz.py zloz --plan <folder>/plan_<orientacja>.json`

## 7. Kontrola (`kontrola`)

`python narzedzia/montaz.py klatki --plik <plik> --ile 8` i obejrzyj kadry. W pionie sprawdź, czy przycięcie poziomych ujęć nie ucina ludzi (jeśli tak, wybierz inny fragment albo inne ujęcie). Maksymalnie 2 poprawki.

## 8. Raport

Zapisz `<folder>/raport.md` i pokaż go:
- ścieżki plików, długość, tempo muzyki, liczba ujęć, utwór (tytuł, autor, serwis)
- decyzje podjęte samodzielnie (z panelu: wszystko, czego nie było w zadaniu)
- folder `premiere/` dla każdej orientacji: przenikania i czerń są w XML prawdziwymi przejściami, dynamiczne (whip, zoom) położy panel przy wczytaniu; ile efektów dźwiękowych doszło; offline klipy: prawy klik > Połącz multimedia
- koszty (Epidemic/Artlist, ElevenLabs: lektor, transkrypcja)

Z panelu na koniec: `python narzedzia/postep.py --gotowe --xml <folder>/premiere/<plik>.xml [--xml ... drugiej orientacji] --wideo <mp4> --tekst "<1 zdanie podsumowania>"`. Panel wczyta te timeline'y do projektu.
Ze Studio: `/usage`, `/clear` przed kolejnym zadaniem, wgranie pliku w Studio.
