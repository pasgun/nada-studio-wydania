"""Analiza nagrań: arkusze kadrów, miejsca cięć i transkrypcja mowy z czasem słów.

Claude nie ogląda wideo w ruchu. To narzędzie robi mu z każdego klipu:
- arkusz kadrów (siatka klatek co N sekund, z czasem na każdej klatce) do obejrzenia przez Read,
- listę cięć ujęć (zmian sceny),
- transkrypcję mowy ze słowami i czasem (ElevenLabs albo lokalny Whisper).

Użycie:
  python narzedzia/analiza.py folder --folder nagrania/2026-10-20_sesja [--mowa auto|elevenlabs|lokalnie|nie]
  python narzedzia/analiza.py klip --plik nagrania/sesja/C0001.MP4 [--mowa ...]
  python narzedzia/analiza.py referencje --folder klienci/marka/referencje

Wyniki trafiają do podfolderu _analiza obok nagrań. Pliki RAW (np. BRAW) analizujemy przez proksy
z podfolderu _proksy (MP4 o tych samych nazwach); eksport do Premiere i tak wskazuje na oryginały. Raz zrobiona analiza jest używana ponownie
(nie liczy się drugi raz), chyba że dodasz --od-nowa.

Transkrypcja --mowa auto: klipy do 10 minut przez ElevenLabs (kredyty planu), dłuższe lokalnie przez Whisper
z Subtitle Edit albo faster-whisper, jeśli są; inaczej też przez ElevenLabs (szczegóły w narzedzia/mowa.py).
"""
import argparse
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, klucz, wynik  # noqa: E402

ROZSZ_WIDEO = {".mp4", ".mov", ".mxf", ".m4v", ".mkv", ".avi", ".mts", ".webm"}
LIMIT_ELEVENLABS_S = 600


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


def uruchom(args):
    return subprocess.run(args, capture_output=True, text=True, encoding="utf-8", errors="replace")


def info(plik):
    r = uruchom(["ffprobe", "-v", "error", "-print_format", "json", "-show_format", "-show_streams", str(plik)])
    if r.returncode != 0:
        blad(f"Nie mogę odczytać pliku {plik.name}: {r.stderr[-300:]}")
    d = json.loads(r.stdout)
    v = next((s for s in d["streams"] if s.get("codec_type") == "video"), {})
    a = next((s for s in d["streams"] if s.get("codec_type") == "audio"), None)
    fps = v.get("avg_frame_rate", "0/1")
    try:
        n, m = fps.split("/")
        fps = round(float(n) / float(m), 2) if float(m) else 0
    except ValueError:
        fps = 0
    w, h = v.get("width", 0), v.get("height", 0)
    obrot = 0
    for sd in v.get("side_data_list", []) or []:
        if "rotation" in sd:
            obrot = int(sd["rotation"])
    if abs(obrot) == 90:
        w, h = h, w
    return {"plik": str(plik), "dlugosc_s": round(float(d["format"].get("duration", 0)), 2), "szerokosc": w, "wysokosc": h,
            "pion": h > w, "fps": fps, "dzwiek": a is not None}


def ciecia(plik, prog=0.3):
    r = uruchom(["ffmpeg", "-hide_banner", "-i", str(plik), "-vf", f"scale=320:-2,select='gt(scene,{prog})',showinfo", "-an", "-f", "null", "-"])
    czasy = [round(float(t), 2) for t in re.findall(r"pts_time:([0-9.]+)", r.stderr)]
    return czasy


def arkusze(plik, folder, dlugosc, co=None, na_arkusz=24):
    """Siatka klatek z podpisanym czasem. Domyślnie klatka co 1 s (dłuższe klipy rzadziej)."""
    from PIL import Image, ImageDraw, ImageFont

    if co is None:
        co = 1.0 if dlugosc <= 60 else 2.0 if dlugosc <= 300 else 5.0
    czasy = [round(t, 2) for t in [i * co for i in range(int(dlugosc / co) + 1)] if t < dlugosc - 0.05] or [0.0]
    tmp = Path(tempfile.mkdtemp())
    uruchom(["ffmpeg", "-hide_banner", "-loglevel", "error", "-i", str(plik), "-vf", f"fps=1/{co},scale=-2:240", "-q:v", "4",
             str(tmp / "k_%05d.jpg")])
    klatki = sorted(tmp.glob("k_*.jpg"))
    if not klatki:
        return []
    try:
        font = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", 18)
    except Exception:
        try:
            font = ImageFont.truetype("DejaVuSans-Bold.ttf", 18)
        except Exception:
            font = ImageFont.load_default()
    wyniki = []
    for nr in range(math.ceil(len(klatki) / na_arkusz)):
        paczka = klatki[nr * na_arkusz:(nr + 1) * na_arkusz]
        with Image.open(paczka[0]) as pierwsza:
            kw, kh = pierwsza.size
        kol = 6 if kw <= kh else 4
        wierszy = math.ceil(len(paczka) / kol)
        arkusz = Image.new("RGB", (kol * kw, wierszy * kh), (20, 20, 20))
        d = ImageDraw.Draw(arkusz)
        for i, k in enumerate(paczka):
            x, y = (i % kol) * kw, (i // kol) * kh
            with Image.open(k) as im:
                arkusz.paste(im.convert("RGB"), (x, y))
            t = (nr * na_arkusz + i) * co
            etykieta = f"{int(t // 60)}:{t % 60:04.1f}"
            d.rectangle([x, y, x + 78, y + 24], fill=(0, 0, 0))
            d.text((x + 5, y + 2), etykieta, font=font, fill=(255, 220, 0))
        cel = folder / f"{plik.stem}_arkusz{nr + 1}.jpg"
        arkusz.save(cel, quality=82)
        wyniki.append({"plik": str(cel), "od_s": round(nr * na_arkusz * co, 1),
                       "do_s": round(min(dlugosc, (nr + 1) * na_arkusz * co), 1), "klatka_co_s": co})
    shutil.rmtree(tmp, ignore_errors=True)
    return wyniki


def audio_do_transkrypcji(plik):
    cel = Path(tempfile.mkdtemp()) / "mowa.mp3"
    r = uruchom(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(plik), "-vn", "-ac", "1", "-ar", "16000", "-b:a", "64k", str(cel)])
    if r.returncode != 0 or not cel.exists():
        return None
    return cel


def transkrypcja_elevenlabs(audio, jezyk):
    import requests
    with open(audio, "rb") as f:
        dane = {"model_id": "scribe_v2", "timestamps_granularity": "word", "tag_audio_events": "false"}
        if jezyk:
            dane["language_code"] = jezyk
        r = requests.post("https://api.elevenlabs.io/v1/speech-to-text", headers={"xi-api-key": klucz("ELEVENLABS_API_KEY")},
                          data=dane, files={"file": ("mowa.mp3", f, "audio/mpeg")}, timeout=900)
    if r.status_code >= 400:
        blad(f"ElevenLabs transkrypcja HTTP {r.status_code}: {r.text[:400]}")
    d = r.json()
    slowa = [{"slowo": w["text"].strip(), "start": round(w["start"], 3), "koniec": round(w["end"], 3)}
             for w in d.get("words", []) if w.get("type") == "word" and w.get("text", "").strip()]
    return {"silnik": "elevenlabs", "jezyk": d.get("language_code"), "tekst": d.get("text", ""), "slowa": slowa}


def whisper_dostepny():
    try:
        import faster_whisper  # noqa: F401
        return True
    except ImportError:
        return False


def transkrypcja_lokalna(audio, jezyk):
    # biblioteki CUDA z pakietów pip (nvidia-cublas-cu12, nvidia-cudnn-cu12) muszą być widoczne na Windows
    try:
        import site
        for sp in site.getsitepackages() + [site.getusersitepackages()]:
            for bib in Path(sp).glob("nvidia/*/bin"):
                os.add_dll_directory(str(bib))
                os.environ["PATH"] = str(bib) + os.pathsep + os.environ.get("PATH", "")
    except Exception:
        pass
    from faster_whisper import WhisperModel
    model_nazwa = os.environ.get("WHISPER_MODEL", "large-v3")
    try:
        model = WhisperModel(model_nazwa, device="cuda", compute_type="float16")
        urzadzenie = "karta graficzna"
    except Exception:
        model = WhisperModel("medium", device="cpu", compute_type="int8")
        urzadzenie = "procesor (wolniej; karta graficzna niedostępna)"
    segmenty, inf = model.transcribe(str(audio), language=jezyk or None, word_timestamps=True, vad_filter=True)
    slowa, tekst = [], []
    for s in segmenty:
        tekst.append(s.text.strip())
        for w in s.words or []:
            if w.word.strip():
                slowa.append({"slowo": w.word.strip(), "start": round(w.start, 3), "koniec": round(w.end, 3)})
    return {"silnik": f"whisper lokalnie ({urzadzenie})", "jezyk": inf.language, "tekst": " ".join(tekst), "slowa": slowa}


def frazy(slowa, pauza=0.6):
    """Łączy słowa w wypowiedzi (frazy) do czytania i do wycinania fragmentów."""
    wyn, biez = [], []
    for i, s in enumerate(slowa):
        biez.append(s)
        koniec = s["slowo"][-1:] in ".!?" or (i + 1 < len(slowa) and slowa[i + 1]["start"] - s["koniec"] > pauza)
        if koniec or i == len(slowa) - 1:
            wyn.append({"od": biez[0]["start"], "do": biez[-1]["koniec"], "tekst": " ".join(x["slowo"] for x in biez)})
            biez = []
    return wyn


def analizuj(plik, mowa="auto", jezyk=None, od_nowa=False):
    plik = sciezka(plik)
    folder = plik.parent / "_analiza"
    folder.mkdir(exist_ok=True)
    cel = folder / f"{plik.stem}.json"
    if cel.exists() and not od_nowa:
        return json.loads(cel.read_text(encoding="utf-8"))
    inf = info(plik)
    wynik_klipu = {**inf, "ciecia_s": ciecia(plik), "arkusze": arkusze(plik, folder, inf["dlugosc_s"])}
    if inf["dzwiek"] and mowa != "nie":
        import mowa as mowa_mod
        t = mowa_mod.transkrybuj(plik, jezyk, mowa)
        if t:
            slowa_plik = folder / f"{plik.stem}_slowa.json"
            slowa_plik.write_text(json.dumps(t["slowa"], ensure_ascii=False, indent=1), encoding="utf-8")
            wynik_klipu["mowa"] = {"silnik": t["silnik"], "jezyk": t["jezyk"], "liczba_slow": len(t["slowa"]),
                                   "slowa_plik": str(slowa_plik), "frazy": frazy(t["slowa"])}
            # granice z prawdziwego dźwięku: bezpieczne miejsca cięcia (ciecie_od/ciecie_do), bloki ciągłej mowy i pauzy ≥ 1 s
            try:
                import granice
                g = granice.granice(plik, t["slowa"])
                if g and g["frazy"]:
                    wynik_klipu["mowa"].update(frazy=g["frazy"], bloki=g["bloki"], pauzy=g["pauzy"],
                                               ciecie="Tnij tylko w ciecie_od/ciecie_do; frazy z laczyc_z_nastepna=true zostaw w jednej scenie (pauza < 1 s)")
            except Exception:
                pass
    cel.write_text(json.dumps(wynik_klipu, ensure_ascii=False, indent=1), encoding="utf-8")
    return wynik_klipu


SUROWE = {".braw", ".r3d", ".ari", ".crm"}


def pliki_wideo(folder):
    """Klipy do analizy. Jeśli jest podfolder _proksy (np. dla BRAW), bierzemy pliki stamtąd."""
    folder = sciezka(folder)
    if not folder.exists():
        blad(f"Nie ma folderu {folder}")
    proksy = folder / "_proksy"
    if proksy.exists() and any(p.suffix.lower() in ROZSZ_WIDEO for p in proksy.iterdir()):
        folder = proksy
    pliki = sorted(p for p in folder.iterdir() if p.suffix.lower() in ROZSZ_WIDEO)
    surowe = sorted(p.name for p in folder.iterdir() if p.suffix.lower() in SUROWE)
    if surowe and folder.name != "_proksy":
        bez = [n for n in surowe if not any(Path(n).stem == p.stem for p in pliki)]
        if bez:
            blad(f"Pliki RAW ({', '.join(bez[:5])}{'…' if len(bez) > 5 else ''}) trzeba najpierw przekonwertować na proksy "
                 f"(MP4 o tych samych nazwach) do podfolderu {folder / '_proksy'}. Instrukcja: DaVinci Resolve > Deliver > "
                 f"Individual clips, H.264, nazwa pliku jak źródło.")
    return pliki


def skrot(k):
    """Krótkie podsumowanie klipu do wypisania (pełne dane są w pliku JSON)."""
    s = {"plik": Path(k["plik"]).name, "dlugosc_s": k["dlugosc_s"], "pion": k["pion"], "dzwiek": k["dzwiek"],
         "liczba_ciec": len(k["ciecia_s"]), "arkusze": [a["plik"] for a in k["arkusze"]]}
    if k.get("mowa"):
        s["mowa"] = f'{k["mowa"]["liczba_slow"]} słów, {k["mowa"]["silnik"]}'
        s["poczatek_wypowiedzi"] = " / ".join(f["tekst"] for f in k["mowa"]["frazy"][:3])[:200]
    return s


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Analiza nagrań i referencji")
    sub = p.add_subparsers(dest="tryb", required=True)
    for nazwa in ("folder", "referencje"):
        x = sub.add_parser(nazwa); x.add_argument("--folder", required=True)
        x.add_argument("--mowa", default="auto", choices=["auto", "elevenlabs", "subtitle-edit", "lokalnie", "nie"])
        x.add_argument("--jezyk", default=None, help="np. pl; puste = wykryj"); x.add_argument("--od-nowa", action="store_true")
    k = sub.add_parser("klip"); k.add_argument("--plik", required=True)
    k.add_argument("--mowa", default="auto", choices=["auto", "elevenlabs", "subtitle-edit", "lokalnie", "nie"])
    k.add_argument("--jezyk", default=None); k.add_argument("--od-nowa", action="store_true")
    a = p.parse_args()

    if a.tryb == "klip":
        w = analizuj(a.plik, a.mowa, a.jezyk, a.od_nowa)
        wynik(klip=skrot(w), pelne_dane=str(sciezka(a.plik).parent / "_analiza" / f"{sciezka(a.plik).stem}.json"))
    else:
        pliki = pliki_wideo(a.folder)
        if not pliki:
            blad(f"W folderze {a.folder} nie ma plików wideo ({', '.join(sorted(ROZSZ_WIDEO))}).")
        klipy = [analizuj(f, a.mowa, a.jezyk, a.od_nowa) for f in pliki]
        dane = {"klipy": [skrot(k) for k in klipy], "folder_analizy": str(sciezka(a.folder) / "_analiza")}
        if a.tryb == "referencje":
            staty = []
            for k in klipy:
                n = len(k["ciecia_s"]) + 1
                st = {"plik": Path(k["plik"]).name, "dlugosc_s": k["dlugosc_s"], "liczba_ujec": n,
                      "srednia_dlugosc_ujecia_s": round(k["dlugosc_s"] / n, 2)}
                if k.get("mowa") and k["dlugosc_s"]:
                    st["slow_na_sekunde"] = round(k["mowa"]["liczba_slow"] / k["dlugosc_s"], 2)
                    st["tekst"] = " ".join(f["tekst"] for f in k["mowa"]["frazy"])[:600]
                staty.append(st)
            dane["statystyki"] = staty
        wynik(**dane)
