"""Granice mowy z prawdziwego dźwięku: gdzie naprawdę kończy się i zaczyna wypowiedź, gdzie bezpiecznie ciąć.

Rozpoznawanie mowy (Whisper, ElevenLabs) podaje czasy słów z dokładnością ok. 0,1–0,3 s, a ciche końcówki
(„ś”, „ć”, „sz”, wydech) często ucina. To narzędzie mierzy głośność nagrania co 10 ms i na tej podstawie:
- wyznacza bloki ciągłej mowy (przerwy krótsze niż --min-pauza, domyślnie 1 s, NIE są przerwą do cięcia),
- dla każdej frazy podaje bezpieczne miejsca cięcia `ciecie_od` / `ciecie_do` (z zapasem na końcówki słów),
- sprawdza gotowy plan montażu: czy któraś scena nie ucina słowa albo nie wycina zbyt krótkiej pauzy.

  python narzedzia/granice.py frazy --plik nagranie.mp4 [--slowa _analiza/nagranie_slowa.json] [--min-pauza 1.0]
  python narzedzia/granice.py sprawdz --plan wyniki/<...>/plan.json [--min-pauza 1.0]

Wynik `frazy`: {"bloki": [{od, do, ciecie_od, ciecie_do, tekst}], "frazy": [{od, do, ciecie_od, ciecie_do, tekst, pauza_po,
laczyc_z_nastepna}], "pauzy": [{od, do, dl}]}. Czasy w sekundach pliku. `laczyc_z_nastepna: true` = przerwa po frazie
krótsza niż --min-pauza: jeśli bierzesz obie frazy, zostaw je w JEDNEJ scenie (albo tnij sam obraz, a dźwięk niech leci dalej).
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, wynik  # noqa: E402

KROK = 0.01            # 10 ms na pomiar
ZAPAS_PRZED = 0.10     # tyle zostaje przed pierwszym dźwiękiem frazy
ZAPAS_PO = 0.22        # tyle zostaje po ostatnim dźwięku frazy (końcówki słów i wydech)
MIN_PAUZA = 1.0        # przerw krótszych nie tniemy
ROZSZ_OBRAZ = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tif", ".tiff", ".gif"}


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


_CACHE = {}


def obwiednia(plik):
    """Głośność (dB) co 10 ms, mono 16 kHz. Zwraca (lista dB, próg ciszy, poziom mowy) albo None, gdy pliku nie da się odczytać."""
    import numpy as np
    plik = Path(plik)
    klucz = (str(plik), plik.stat().st_mtime if plik.exists() else 0)
    if klucz in _CACHE:
        return _CACHE[klucz]
    try:
        r = subprocess.run(["ffmpeg", "-v", "error", "-i", str(plik), "-vn", "-ac", "1", "-ar", "16000", "-f", "s16le", "-"],
                           capture_output=True, timeout=600)
    except Exception:
        return None
    a = np.frombuffer(r.stdout, dtype=np.int16).astype(np.float32) / 32768.0
    if a.size < 1600:
        return None
    n = int(16000 * KROK)
    ile = a.size // n
    ramki = a[: ile * n].reshape(ile, n)
    db = 20 * np.log10(np.sqrt((ramki ** 2).mean(axis=1)) + 1e-6)
    tlo = float(np.percentile(db, 10))
    mowa = float(np.percentile(db, 90))
    # próg ciszy blisko szumu tła: ciche końcówki słów („ś”, „ć”, wydech) mają liczyć się jeszcze jako mowa
    prog = tlo + max(5.0, min(12.0, (mowa - tlo) * 0.22))
    _CACHE[klucz] = (db, prog, mowa)
    return _CACHE[klucz]


def _glosno(db, prog):
    import numpy as np
    g = db > prog
    # wygładzenie: pojedyncze ciche ramki w środku mowy (zwarcie „p”, „t”) nie przerywają mowy
    if g.size > 4:
        g = np.convolve(g.astype(float), np.ones(5) / 5, mode="same") > 0.35
    return g


def _progi(db, prog, mowa):
    """Dwa progi: „słowo” (wyraźna mowa, bez oddechów) i „ogon” (ciche końcówki słów, tuż przy szumie tła)."""
    return max(prog, mowa - 24.0), prog


def bloki_mowy(db, prog, min_pauza=MIN_PAUZA, mowa=None):
    """Ciągłe kawałki mowy [(od, do)] z przerwami krótszymi niż min_pauza sklejonymi w jeden kawałek
    (oddech między zdaniami nie jest mową, ciche końcówki słów są)."""
    p_slowa, _ = _progi(db, prog, mowa if mowa is not None else prog + 30)
    g = _glosno(db, p_slowa)
    kawalki, start = [], None
    for i, x in enumerate(g):
        if x and start is None:
            start = i
        elif not x and start is not None:
            kawalki.append([start * KROK, i * KROK])
            start = None
    if start is not None:
        kawalki.append([start * KROK, len(g) * KROK])
    kawalki = [k for k in kawalki if k[1] - k[0] >= 0.06]  # trzaski i stuknięcia
    wyn = []
    for k in kawalki:
        if wyn and k[0] - wyn[-1][1] < min_pauza:
            wyn[-1][1] = k[1]
        else:
            wyn.append(k)
    dl = len(db) * KROK
    out = []
    for a, b in wyn:
        a = _ogon_wstecz(db, prog, a, 0.08)
        b = _ogon(db, prog, b, 0.2, dl)
        out.append((round(a, 3), round(b, 3)))
    return out


def _ogon(db, prog, t, max_s, dl):
    """Od końca wyraźnej mowy w t: ciche końcówki słowa trwają, dopóki dźwięk jest nad szumem tła (najwyżej max_s)."""
    i, kon = int(t / KROK), min(len(db), int((t + max_s) / KROK))
    while i < kon and db[i] > prog:
        i += 1
    return min(i * KROK, dl)


def _ogon_wstecz(db, prog, t, max_s):
    i, pocz = int(t / KROK) - 1, max(0, int((t - max_s) / KROK))
    while i > pocz and db[i] > prog:
        i -= 1
    return max(0.0, (i + 1) * KROK)


def koniec_dzwieku(db, prog, t, do_max, mowa=None):
    """Prawdziwy koniec mowy po czasie t: ostatnia wyraźna mowa (przed 0,12 s ciszy) + cicha końcówka słowa; najdalej do do_max."""
    p_slowa, _ = _progi(db, prog, mowa if mowa is not None else prog + 30)
    g = _glosno(db, p_slowa)
    i, kon = max(0, int(t / KROK)), min(len(g), int(do_max / KROK))
    ostatnia, bez = None, 0
    while i < kon:
        if g[i]:
            ostatnia, bez = i, 0
        else:
            bez += 1
            if bez >= 12:
                break
        i += 1
    if ostatnia is None:
        return min(t, do_max)
    return min(_ogon(db, prog, (ostatnia + 1) * KROK, 0.2, do_max), do_max)


def poczatek_dzwieku(db, prog, t, od_min, mowa=None):
    """Prawdziwy początek mowy przed czasem t (pierwsza wyraźna mowa po 0,1 s ciszy, z cichym nagłosem); najdalej od od_min."""
    p_slowa, _ = _progi(db, prog, mowa if mowa is not None else prog + 30)
    g = _glosno(db, p_slowa)
    i, pocz = min(len(g) - 1, int(t / KROK)), max(0, int(od_min / KROK))
    pierwsza, bez = None, 0
    while i >= pocz:
        if g[i]:
            pierwsza, bez = i, 0
        else:
            bez += 1
            if bez >= 10:
                break
        i -= 1
    if pierwsza is None:
        return max(t, od_min)
    return max(_ogon_wstecz(db, prog, pierwsza * KROK, 0.08), od_min)


def najcichsze(db, a, b):
    """Najcichsze miejsce między a i b (tam tniemy, gdy przerwa jest krótka)."""
    import numpy as np
    i, j = max(0, int(a / KROK)), min(len(db), int(b / KROK))
    if j - i < 2:
        return (a + b) / 2
    kaw = np.convolve(db[i:j], np.ones(3) / 3, mode="same")
    return (i + int(np.argmin(kaw))) * KROK


def frazy_ze_slow(slowa, pauza=0.6):
    wyn, biez = [], []
    for i, s in enumerate(slowa):
        biez.append(s)
        koniec = str(s.get("slowo", ""))[-1:] in ".!?" or (i + 1 < len(slowa) and slowa[i + 1]["start"] - s["koniec"] > pauza)
        if koniec or i == len(slowa) - 1:
            wyn.append({"od": biez[0]["start"], "do": biez[-1]["koniec"], "tekst": " ".join(x["slowo"] for x in biez)})
            biez = []
    return wyn


def granice(plik, slowa=None, min_pauza=MIN_PAUZA):
    ob = obwiednia(plik)
    if not ob:
        return None
    db, prog, mowa = ob
    dl = len(db) * KROK
    bl = bloki_mowy(db, prog, min_pauza, mowa)
    bloki = []
    for k, (a, b) in enumerate(bl):
        poprz = bl[k - 1][1] if k else 0.0
        nast = bl[k + 1][0] if k + 1 < len(bl) else dl
        bloki.append({"od": a, "do": b, "ciecie_od": round(max(poprz + (a - poprz) / 2, a - ZAPAS_PRZED, 0.0), 3),
                      "ciecie_do": round(min(b + ZAPAS_PO, b + (nast - b) / 2, dl), 3)})
    pauzy = [{"od": round(bl[k][1], 3), "do": round(bl[k + 1][0], 3), "dl": round(bl[k + 1][0] - bl[k][1], 2)} for k in range(len(bl) - 1)]
    frazy = []
    if slowa:
        fr = frazy_ze_slow(slowa)
        for k, f in enumerate(fr):
            nast = fr[k + 1]["od"] if k + 1 < len(fr) else dl
            poprz = fr[k - 1]["do"] if k else 0.0
            # prawdziwy koniec: dźwięk po ostatnim słowie trwa często dłużej, niż podaje rozpoznawanie mowy
            kon = koniec_dzwieku(db, prog, max(f["do"] - 0.15, 0), min(nast + 0.1, dl), mowa)
            pocz = poczatek_dzwieku(db, prog, f["od"] + 0.15, max(poprz - 0.1, 0), mowa)
            frazy.append({**f, "_kon": kon, "_pocz": pocz})
        for k, f in enumerate(frazy):
            nast = frazy[k + 1]["_pocz"] if k + 1 < len(frazy) else dl
            poprz = frazy[k - 1]["_kon"] if k else 0.0
            przerwa = nast - f["_kon"]
            f["pauza_po"] = round(max(0.0, przerwa), 2)
            f["laczyc_z_nastepna"] = k + 1 < len(frazy) and przerwa < min_pauza
            # długa przerwa: koniec dźwięku + zapas; krótka: najcichsze miejsce między frazami (nigdy przed końcem dźwięku)
            if przerwa >= 2 * ZAPAS_PO:
                f["ciecie_do"] = round(min(f["_kon"] + ZAPAS_PO, dl), 3)
            elif przerwa > 0.02:
                f["ciecie_do"] = round(max(najcichsze(db, f["_kon"], nast), f["_kon"] + przerwa * 0.3), 3)
            else:
                f["ciecie_do"] = round(f["_kon"], 3)
            pp = f["_pocz"] - poprz
            if pp >= 2 * ZAPAS_PRZED:
                f["ciecie_od"] = round(max(f["_pocz"] - ZAPAS_PRZED, 0.0), 3)
            elif pp > 0.02:
                f["ciecie_od"] = round(min(najcichsze(db, poprz, f["_pocz"]), f["_pocz"] - pp * 0.3), 3)
            else:
                f["ciecie_od"] = round(f["_pocz"], 3)
        for f in frazy:
            f["do_dzwiek"] = round(f.pop("_kon"), 3)
            f["od_dzwiek"] = round(f.pop("_pocz"), 3)
        for b in bloki:
            b["tekst"] = " ".join(f["tekst"] for f in frazy if f["od"] < b["do"] and f["do"] > b["od"])
    return {"bloki": bloki, "frazy": frazy, "pauzy": pauzy, "prog_ciszy_db": round(prog, 1), "dlugosc_s": round(dl, 2), "min_pauza": min_pauza}


# ---------- kontrola planu montażu ----------
def _slowa_dla(plik):
    """Plik słów z analizy dla nagrania albo jego czystej wersji (…_czysty.wav w _analiza)."""
    p = Path(plik)
    kand = []
    if p.parent.name == "_analiza":
        kand.append(p.with_name(p.stem.replace("_czysty", "") + "_slowa.json"))
    kand.append(p.parent / "_analiza" / f"{p.stem}_slowa.json")
    for k in kand:
        if k.exists():
            try:
                return json.loads(k.read_text(encoding="utf-8"))
            except Exception:
                pass
    return None


def sprawdz_sceny(sceny, czasy=None, min_pauza=MIN_PAUZA):
    """Uwagi do scen z mową: ucięty koniec albo początek słowa, wycięta za krótka pauza. Niczego nie zmienia."""
    uwagi, poprz = [], None

    def zrodlo(k):
        s = sceny[k] if 0 <= k < len(sceny) else None
        if not s or not s.get("dzwiek"):
            return None
        z = s.get("dzwiek_z") or {}
        c = float((czasy[k] if czasy else None) or s.get("czas") or 0)
        st_ = float(z.get("start", s.get("start", 0)))
        return str(sciezka(z.get("plik") or s.get("plik", ""))), st_, st_ + c
    for i, s in enumerate(sceny):
        czas = float((czasy[i] if czasy else None) or s.get("czas") or 0)
        if not s.get("dzwiek") or czas <= 0:
            poprz = None
            continue
        z = s.get("dzwiek_z") or {}
        plik = sciezka(z.get("plik") or s.get("plik", ""))
        if not plik.exists() or plik.suffix.lower() in ROZSZ_OBRAZ:
            poprz = None
            continue
        st = float(z.get("start", s.get("start", 0)))
        ob = obwiednia(plik)
        if not ob:
            poprz = None
            continue
        db, prog, mowa = ob
        dl = len(db) * KROK
        kon = st + czas
        slowa = _slowa_dla(plik) or []
        p_slowa, _ = _progi(db, prog, mowa)
        g_cicho, g_slowo = _glosno(db, prog), _glosno(db, p_slowa)

        def slowo_przy(t):
            for w in slowa:
                if w["start"] - 0.05 <= t <= w["koniec"] + 0.25:
                    return w["slowo"]
            return None

        def udzial(g, a, b):
            i, j = max(0, int(a / KROK)), min(len(g), int(b / KROK))
            return float(g[i:j].mean()) if j > i else 0.0
        # dźwięk leci dalej w następnej scenie (cięcie samego obrazu): to nie jest cięcie mowy
        nast_z, poprz_z = zrodlo(i + 1), zrodlo(i - 1)
        ciagiem_dalej = bool(nast_z and nast_z[0] == str(plik) and abs(nast_z[1] - (st + czas)) < 0.02)
        ciagiem_wczesniej = bool(poprz_z and poprz_z[0] == str(plik) and abs(poprz_z[2] - st) < 0.02)
        # koniec sceny: słowo trwa albo jego cicha końcówka jeszcze brzmi, a scena już się skończyła
        # koniec sceny: mowa (z cichą końcówką) musi wybrzmieć przed ostatnimi 0,06 s, bo tam montaż wycisza dźwięk sceny
        if not ciagiem_dalej and kon < dl - 0.05 and udzial(g_slowo, kon - 0.35, kon + 0.05) > 0.05:
            prawdziwy = koniec_dzwieku(db, prog, kon - 0.3, min(kon + 1.0, dl), mowa)
            if prawdziwy > kon - 0.06:
                uwagi.append({"scena": i + 1, "co": "ucina_koniec", "slowo": slowo_przy(min(prawdziwy, kon) - 0.05),
                              "brakuje_s": round(prawdziwy - kon + 0.06, 2),
                              "opis": f"scena {i + 1} ucina albo wycisza końcówkę mowy" + (f" (słowo „{slowo_przy(min(prawdziwy, kon) - 0.05)}”)" if slowo_przy(min(prawdziwy, kon) - 0.05) else ""),
                              "proponowany_czas": round(min(prawdziwy + 0.15, dl) - st, 3)})
        # początek sceny: mowa nie może zaczynać się w pierwszych 0,04 s (tam dźwięk dopiero się podgłaśnia)
        if not ciagiem_wczesniej and st > 0.05 and udzial(g_slowo, st - 0.05, st + 0.3) > 0.05:
            prawdziwy = poczatek_dzwieku(db, prog, st + 0.25, max(st - 1.0, 0), mowa)
            if prawdziwy < st + 0.04:
                uwagi.append({"scena": i + 1, "co": "ucina_poczatek", "slowo": slowo_przy(st + 0.05), "brakuje_s": round(st + 0.04 - prawdziwy, 2),
                              "opis": f"scena {i + 1} ucina początek mowy" + (f" (słowo „{slowo_przy(st + 0.05)}”)" if slowo_przy(st + 0.05) else ""),
                              "proponowany_start": round(max(prawdziwy - 0.08, 0), 3)})
        # wycięta krótka pauza między dwiema scenami z tego samego nagrania
        if poprz and poprz[0] == str(plik):
            luka = st - poprz[1]
            if 0.02 < luka < min_pauza:
                uwagi.append({"scena": i + 1, "co": "krotka_pauza", "dl": round(luka, 2),
                              "opis": f"między sceną {i} a {i + 1} wycięta pauza {luka:.2f} s (krótsza niż {min_pauza:g} s): mowa brzmi szarpano; "
                                      f"zostaw dźwięk ciągiem (scena {i + 1} od {poprz[1]:.2f} s) albo tnij sam obraz"})
        poprz = (str(plik), kon)
    return uwagi


def sprawdz_plan(plan, min_pauza=MIN_PAUZA):
    p = json.loads(sciezka(plan).read_text(encoding="utf-8"))
    return sprawdz_sceny(p.get("sceny") or [], None, min_pauza)


if __name__ == "__main__":
    a = argparse.ArgumentParser(description="Granice mowy i bezpieczne miejsca cięcia")
    sub = a.add_subparsers(dest="tryb", required=True)
    f = sub.add_parser("frazy"); f.add_argument("--plik", required=True); f.add_argument("--slowa"); f.add_argument("--min-pauza", type=float, default=MIN_PAUZA)
    s = sub.add_parser("sprawdz"); s.add_argument("--plan", required=True); s.add_argument("--min-pauza", type=float, default=MIN_PAUZA)
    x = a.parse_args()
    if x.tryb == "frazy":
        pl = sciezka(x.plik)
        sl = json.loads(sciezka(x.slowa).read_text(encoding="utf-8")) if x.slowa else _slowa_dla(pl)
        g = granice(pl, sl, x.min_pauza)
        if not g:
            blad(f"Nie da się odczytać dźwięku z {pl}")
        wynik(**g)
    else:
        u = sprawdz_plan(x.plan, x.min_pauza)
        wynik(uwagi=u, liczba=len(u), wskazowka="Popraw sceny według proponowany_czas / proponowany_start i złóż rolkę jeszcze raz." if u else "Cięcia mowy są czyste.")
