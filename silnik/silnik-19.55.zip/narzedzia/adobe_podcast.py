"""Adobe Podcast „Enhance Speech” na koncie użytkownika, przez przeglądarkę (Adobe nie ma publicznego API).

Użycie:
  python narzedzia/adobe_podcast.py zaloguj        okno przeglądarki z podcast.adobe.com: logujesz się raz swoim kontem Adobe
                                                   (hasło wpisujesz Ty, w oknie Adobe; silnik go nie widzi i nie zapisuje)
  python narzedzia/adobe_podcast.py test           sprawdza bez okna, czy jesteś zalogowany i czy strona wygląda jak zwykle
  python narzedzia/adobe_podcast.py popraw --pliki '["C:/.../a.wav"]' --folder <folder wyników>
                                                   wysyła pliki do Enhance Speech i pobiera wyniki: <folder>/<nazwa>_adobe.<rozsz>
  python narzedzia/adobe_podcast.py stan           ostatni wynik (to samo widzi Studio)

Przeglądarka: Google Chrome albo Microsoft Edge z komputera, z osobnym profilem w _system/adobe_podcast/profil
(logowanie zostaje między zadaniami; Twoja zwykła przeglądarka i jej konta nie są ruszane). Ustawienia Enhance
(siła, tło, muzyka) są takie, jak masz zapisane na koncie Adobe.
Stan dla Studio: _system/adobe_podcast/stan.json (Studio pokazuje powiadomienie, gdy coś przestało działać);
przy błędzie zrzut ekranu blad.png i strona.html obok. Słowa na przyciskach i czasy: narzedzia/adobe_podcast.json
(gdy Adobe zmieni stronę, zwykle wystarczy poprawka tam).
"""
import argparse
import importlib
import json
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, wynik  # noqa: E402

FOLDER = KATALOG_SILNIKA / "_system" / "adobe_podcast"
PROFIL = FOLDER / "profil"
STAN = FOLDER / "stan.json"
USTAWIENIA = Path(__file__).resolve().parent / "adobe_podcast.json"


class Blad(Exception):
    def __init__(self, tekst, rodzaj="inne"):
        super().__init__(tekst)
        self.rodzaj = rodzaj


def ustawienia():
    try:
        cfg = json.loads(USTAWIENIA.read_text(encoding="utf-8"))
    except Exception:
        cfg = {"adres": "https://podcast.adobe.com/enhance"}
    import os
    if os.environ.get("NADA_ADOBE_ADRES"):  # tylko do testów na stronie próbnej
        cfg["adres"] = os.environ["NADA_ADOBE_ADRES"]
    return cfg


def zapisz_stan(**d):
    FOLDER.mkdir(parents=True, exist_ok=True)
    stary = {}
    try:
        stary = json.loads(STAN.read_text(encoding="utf-8"))
    except Exception:
        pass
    d["kiedy"] = time.time()
    if d.get("ok"):
        d.setdefault("blad", None)
        d["ostatnio_ok"] = d["kiedy"]
    else:
        d["ostatnio_ok"] = stary.get("ostatnio_ok")
    STAN.write_text(json.dumps({**stary, **d}, ensure_ascii=False, indent=1), encoding="utf-8")


def wczytaj_stan():
    try:
        d = json.loads(STAN.read_text(encoding="utf-8"))
    except Exception:
        d = {}
    d["profil"] = PROFIL.exists() and any(PROFIL.iterdir())
    return d


def postep(t):
    print(f"[adobe podcast] {t}", file=sys.stderr, flush=True)


def wymagaj_playwright():
    try:
        importlib.import_module("playwright.sync_api")
        return
    except ImportError:
        pass
    postep("Instaluję bibliotekę do sterowania przeglądarką (playwright, tylko za pierwszym razem)")
    r = subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", "playwright"], capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        raise Blad(f"Nie udało się zainstalować biblioteki playwright: {r.stderr[-400:]}. Uruchom ręcznie: python -m pip install playwright", "instalacja")
    importlib.invalidate_caches()


def otworz(p, widoczne, poza_ekranem=False):
    """Chrome albo Edge z komputera, osobny profil (logowanie zostaje). Zwraca (kontekst, nazwa przeglądarki).
    poza_ekranem: zwykłe okno, ale ustawione poza ekranem (Adobe czasem nie wpuszcza przeglądarki bez okna)."""
    PROFIL.mkdir(parents=True, exist_ok=True)
    args = ["--disable-blink-features=AutomationControlled", "--no-first-run", "--no-default-browser-check"]
    if poza_ekranem:
        args.append("--window-position=-32000,-32000")
    ostatni = None
    import os
    kanaly = [None] if os.environ.get("NADA_PRZEGLADARKA") == "chromium" else ["chrome", "msedge", None]
    for kanal in kanaly:
        try:
            opcje = {"channel": kanal} if kanal else {}
            ctx = p.chromium.launch_persistent_context(str(PROFIL), headless=not widoczne, accept_downloads=True,
                                                       viewport={"width": 1400, "height": 900}, args=args, **opcje)
            return ctx, kanal or "chromium"
        except Exception as e:  # brak tej przeglądarki albo profil zajęty przez otwarte okno logowania
            ostatni = e
            if "user data directory is already in use" in str(e).lower() or "processsingleton" in str(e).lower():
                raise Blad("Okno Adobe Podcast z logowaniem jest jeszcze otwarte. Zamknij je i spróbuj ponownie.", "zajete")
    raise Blad(f"Nie mogę uruchomić Chrome ani Edge: {str(ostatni)[:300]}", "przegladarka")


def strona_gotowa(page, cfg, czekaj=None):
    """Czeka, aż strona Enhance pokaże miejsce na plik albo prośbę o logowanie. Zwraca "tak" / "nie" (logowanie) / "nie_wiem"."""
    zal = re.compile(cfg.get("zaloguj_wzorzec") or r"^\s*(sign in|log in)\s*$", re.I)
    koniec = time.time() + (czekaj or float(cfg.get("czas_gotowosci_s", 45)))
    while time.time() < koniec:
        url = page.url.lower()
        if any(h in url for h in cfg.get("logowanie_hosty", [])):
            return "nie"
        try:
            jest_plik = page.locator("input[type=file]").count() > 0
            przycisk_logowania = page.get_by_role("button", name=zal).or_(page.get_by_role("link", name=zal))
            loguj = any(przycisk_logowania.nth(i).is_visible() for i in range(min(przycisk_logowania.count(), 5)))
        except Exception:
            jest_plik, loguj = False, False
        if jest_plik and not loguj:
            return "tak"
        if loguj and not jest_plik:
            # chwila na doczytanie sesji (strona najpierw pokazuje „Sign in”, potem konto)
            if time.time() > koniec - max(5.0, float(cfg.get("czas_gotowosci_s", 45)) * 0.6):
                return "nie"
        time.sleep(1.5)
    return "nie_wiem"


def zrzut(page):
    out = {}
    try:
        page.screenshot(path=str(FOLDER / "blad.png"), full_page=True)
        out["zrzut"] = str(FOLDER / "blad.png")
    except Exception:
        pass
    try:
        (FOLDER / "strona.html").write_text(page.content()[:3_000_000], encoding="utf-8")
    except Exception:
        pass
    return out


def tekst_strony(page):
    try:
        return page.locator("body").inner_text(timeout=5000).lower()
    except Exception:
        return ""


def dlugosc_min(plik):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(plik)],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    try:
        return float(r.stdout.strip()) / 60
    except ValueError:
        return 5.0


JS_W_WIERSZU = """(el, nazwa) => {
  // czy przycisk stoi przy nazwie naszego pliku (idzie w górę drzewa, także przez komponenty z cieniem)
  let x = el;
  for (let i = 0; i < 12 && x; i++) {
    const t = (x.innerText || x.textContent || "");
    if (t.includes(nazwa)) return true;
    x = x.parentElement || (x.getRootNode && x.getRootNode().host) || null;
  }
  return false;
}"""


def jeden_plik(page, cfg, plik, folder):
    """Wysyła jeden plik i pobiera wynik. Zwraca ścieżkę pobranego pliku."""
    page.goto(cfg["adres"], wait_until="domcontentloaded", timeout=60000)
    g = strona_gotowa(page, cfg)
    if g == "nie":
        raise Blad("Adobe Podcast: nie jesteś zalogowany albo sesja wygasła. W Studio: Ustawienia > Adobe Podcast > Zaloguj.", "logowanie")
    if g != "tak":
        raise Blad("Adobe Podcast zmienił stronę: nie widzę miejsca na wgranie pliku.", "strona")
    przed = tekst_strony(page)
    page.locator("input[type=file]").first.set_input_files(str(plik))
    postep(f"Wysłane: {plik.name}, czekam na wynik")
    nazwa = plik.stem
    pob = re.compile(cfg.get("pobierz_wzorzec") or "download", re.I)
    zle = re.compile(cfg.get("blad_wzorzec") or "something went wrong", re.I)
    limit = float(cfg.get("czas_min_s", 300)) + dlugosc_min(plik) * float(cfg.get("czas_na_minute_s", 150))
    koniec = time.time() + limit
    while time.time() < koniec:
        time.sleep(3)
        teraz = tekst_strony(page)
        nowe = [m.group(0) for m in zle.finditer(teraz)]
        if nowe and not all(n in przed for n in nowe):
            raise Blad(f"Adobe Podcast odpowiedział: „{nowe[0]}”.", "adobe")
        kand = page.get_by_role("button", name=pob).or_(page.get_by_role("link", name=pob))
        widoczne = []
        for i in range(min(kand.count(), 20)):
            k = kand.nth(i)
            try:
                if k.is_visible() and k.is_enabled():
                    widoczne.append(k)
            except Exception:
                pass
        if not widoczne:
            continue
        nasze = []
        for k in widoczne:
            try:
                if k.evaluate(JS_W_WIERSZU, nazwa):
                    nasze.append(k)
            except Exception:
                pass
        cel = nasze[0] if nasze else (widoczne[0] if len(widoczne) == 1 else None)
        if cel is None:
            continue  # kilka plików na liście, a przy naszym jeszcze nie ma przycisku
        try:
            with page.expect_download(timeout=8000) as dl:
                cel.click()
            d = dl.value
        except Exception:
            # przycisk otwiera menu (np. wybór formatu): pierwsza pozycja z „WAV” albo „Download”
            menu = re.compile(cfg.get("pobierz_menu_wzorzec") or "wav|download", re.I)
            poz = page.get_by_role("menuitem", name=menu).or_(page.get_by_role("option", name=menu))
            if not poz.count():
                continue
            with page.expect_download(timeout=60000) as dl:
                poz.first.click()
            d = dl.value
        rozsz = Path(d.suggested_filename or "").suffix or ".wav"
        wyj = Path(folder) / f"{nazwa}_adobe{rozsz}"
        d.save_as(str(wyj))
        if not wyj.exists() or wyj.stat().st_size < 1000:
            raise Blad("Adobe Podcast oddał pusty plik.", "adobe")
        return wyj
    raise Blad(f"Adobe Podcast nie skończył w {int(limit // 60)} min (albo przycisk pobierania wygląda inaczej niż zwykle).", "czas")


def popraw(pliki, folder, widoczne=None):
    """Wysyła pliki po kolei w jednej przeglądarce. Zwraca listę {"zrodlo", "plik"}; przy błędzie zapisuje stan i rzuca Blad."""
    cfg = ustawienia()
    widoczne = cfg.get("widoczne", False) if widoczne is None else widoczne
    pliki = [Path(x) for x in pliki]
    for x in pliki:
        if not x.exists():
            raise Blad(f"Nie ma pliku {x}", "plik")
    Path(folder).mkdir(parents=True, exist_ok=True)
    wymagaj_playwright()
    from playwright.sync_api import sync_playwright
    wyniki, page, kanal = [], None, None
    with sync_playwright() as p:
        try:
            ctx, kanal = otworz(p, widoczne)
        except Blad as e:
            zapisz_stan(ok=False, co="popraw", blad=str(e), rodzaj=e.rodzaj)
            raise
        try:
            page = ctx.pages[0] if ctx.pages else ctx.new_page()
            for i, x in enumerate(pliki):
                postep(f"Plik {i + 1}/{len(pliki)}: {x.name}")
                try:
                    wyniki.append({"zrodlo": str(x), "plik": str(jeden_plik(page, cfg, x, folder))})
                except Blad as e:
                    if e.rodzaj == "logowanie" and not widoczne:
                        # bez okna Adobe czasem nie wpuszcza: ta sama próba w zwykłym oknie (poza ekranem)
                        ctx.close()
                        ctx, kanal = otworz(p, True, poza_ekranem=True)
                        page = ctx.pages[0] if ctx.pages else ctx.new_page()
                        widoczne = True
                        wyniki.append({"zrodlo": str(x), "plik": str(jeden_plik(page, cfg, x, folder))})
                    else:
                        raise
        except Blad as e:
            dod = zrzut(page) if page else {}
            zapisz_stan(ok=False, co="popraw", blad=str(e), rodzaj=e.rodzaj, przegladarka=kanal,
                        zalogowany=False if e.rodzaj == "logowanie" else None, **dod)
            raise
        except Exception as e:
            dod = zrzut(page) if page else {}
            zapisz_stan(ok=False, co="popraw", blad=f"Automat Adobe Podcast się zatrzymał: {str(e)[:300]}", rodzaj="strona", przegladarka=kanal, **dod)
            raise Blad(f"Automat Adobe Podcast się zatrzymał (Adobe mógł zmienić stronę): {str(e)[:300]}", "strona")
        finally:
            try:
                ctx.close()
            except Exception:
                pass
    zapisz_stan(ok=True, co="popraw", zalogowany=True, przegladarka=kanal, pliki=len(wyniki), rodzaj=None, zrzut=None)
    return wyniki


def zaloguj():
    """Okno przeglądarki z Adobe Podcast: czeka (do 15 min), aż użytkownik się zaloguje albo zamknie okno."""
    cfg = ustawienia()
    wymagaj_playwright()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        ctx, kanal = otworz(p, True)
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.goto(cfg["adres"], wait_until="domcontentloaded", timeout=60000)
        zapisz_stan(ok=False, co="zaloguj", blad="Czekam na logowanie w oknie Adobe Podcast…", rodzaj="logowanie_trwa", przegladarka=kanal)
        koniec, wynik_ = time.time() + 900, "nie_wiem"
        while time.time() < koniec:
            try:
                if page.is_closed() or not ctx.pages:
                    break
                p_ = ctx.pages[-1]
                wynik_ = strona_gotowa(p_, cfg, czekaj=4)
                if wynik_ == "tak":
                    time.sleep(3)  # niech Adobe zapisze sesję w profilu
                    break
            except Exception:
                break
            time.sleep(2)
        try:
            ctx.close()
        except Exception:
            pass
    if wynik_ == "tak":
        zapisz_stan(ok=True, co="zaloguj", zalogowany=True, przegladarka=kanal, rodzaj=None, zrzut=None)
        return {"zalogowany": True, "przegladarka": kanal}
    zapisz_stan(ok=False, co="zaloguj", zalogowany=False, przegladarka=kanal, rodzaj="logowanie",
                blad="Logowanie do Adobe Podcast nie zostało dokończone. Kliknij „Zaloguj” jeszcze raz.")
    return {"zalogowany": False, "przegladarka": kanal}


def test():
    cfg = ustawienia()
    wymagaj_playwright()
    from playwright.sync_api import sync_playwright
    with sync_playwright() as p:
        ctx, kanal = otworz(p, bool(cfg.get("widoczne")))
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        try:
            page.goto(cfg["adres"], wait_until="domcontentloaded", timeout=60000)
            g = strona_gotowa(page, cfg)
            if g == "tak":
                zapisz_stan(ok=True, co="test", zalogowany=True, przegladarka=kanal, rodzaj=None, zrzut=None)
                return {"zalogowany": True, "strona": "jak zwykle"}
            dod = zrzut(page)
            if g == "nie":
                zapisz_stan(ok=False, co="test", zalogowany=False, rodzaj="logowanie", przegladarka=kanal,
                            blad="Adobe Podcast: nie jesteś zalogowany. W Studio: Ustawienia > Adobe Podcast > Zaloguj.", **dod)
                return {"zalogowany": False}
            zapisz_stan(ok=False, co="test", zalogowany=None, rodzaj="strona", przegladarka=kanal,
                        blad="Adobe Podcast zmienił stronę: nie widzę miejsca na wgranie pliku.", **dod)
            return {"zalogowany": None, "strona": "inna niż zwykle"}
        finally:
            ctx.close()


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Adobe Podcast Enhance Speech przez przeglądarkę")
    sub = ap.add_subparsers(dest="tryb", required=True)
    sub.add_parser("zaloguj")
    sub.add_parser("test")
    sub.add_parser("stan")
    a = sub.add_parser("popraw")
    a.add_argument("--pliki", required=True, help='lista JSON albo jedna ścieżka')
    a.add_argument("--folder", required=True)
    a.add_argument("--widoczne", action="store_true", help="pokaż okno przeglądarki")
    a_ = ap.parse_args()
    try:
        if a_.tryb == "stan":
            wynik(**wczytaj_stan())
        elif a_.tryb == "zaloguj":
            wynik(**zaloguj())
        elif a_.tryb == "test":
            wynik(**test())
        else:
            try:
                lista = json.loads(a_.pliki)
            except ValueError:
                lista = [a_.pliki]
            pl = [Path(x) if Path(x).is_absolute() else KATALOG_SILNIKA / x for x in lista]
            wynik(pliki=popraw(pl, Path(a_.folder) if Path(a_.folder).is_absolute() else KATALOG_SILNIKA / a_.folder,
                               True if a_.widoczne else None))
    except Blad as e:
        if a_.tryb != "popraw":
            zapisz_stan(ok=False, co=a_.tryb, blad=str(e), rodzaj=e.rodzaj)
        blad(str(e))
