﻿/* Studio Nadamedia: część panelu działająca wewnątrz Premiere (ExtendScript).
   Czyta aktywną sekwencję, zapisuje ją jako XML, importuje gotowe wyniki jako NOWE sekwencje i przesuwa głowicę.
   Narzędzia, które tną, wyłączają albo podmieniają dźwięk (cięcie, multicam, poprawa dźwięku, asystent audio, kolor), pracują
   zawsze na KOPII sekwencji. W otwartej sekwencji panel tylko dokłada rzeczy na wolnych ścieżkach (animacje, napisy, szablony). */

function nm_tekst(s) {
    s = String(s);
    var w = "";
    for (var i = 0; i < s.length; i++) {
        var c = s.charAt(i), k = s.charCodeAt(i);
        if (c === "\\") w += "\\\\";
        else if (c === "\"") w += "\\\"";
        else if (c === "\n") w += "\\n";
        else if (c === "\r") w += "\\r";
        else if (c === "\t") w += "\\t";
        else if (k < 32) w += " ";
        else w += c;
    }
    return "\"" + w + "\"";
}

function nm_json(v) {
    if (v === null || v === undefined) return "null";
    if (typeof v === "boolean") return v ? "true" : "false";
    if (typeof v === "number") return isFinite(v) ? String(v) : "null";
    if (typeof v === "string") return nm_tekst(v);
    if (v instanceof Array) {
        var a = [];
        for (var i = 0; i < v.length; i++) a.push(nm_json(v[i]));
        return "[" + a.join(",") + "]";
    }
    var o = [];
    for (var k in v) if (v.hasOwnProperty(k)) o.push(nm_tekst(k) + ":" + nm_json(v[k]));
    return "{" + o.join(",") + "}";
}

var NM_TICKI = 254016000000;

function nm_sekundy(t) {
    try { return Number(t.seconds); } catch (e) { return 0; }
}

function nm_sciezki(lista, prefiks) {
    var w = [];
    for (var i = 0; i < lista.numTracks; i++) {
        var tr = lista[i], pierwszy = "", n = 0, wyc = false;
        try { n = tr.clips.numItems; if (n) pierwszy = tr.clips[0].name; } catch (e) {}
        try { wyc = !!tr.isMuted(); } catch (eM) {}
        w.push({ nr: i + 1, kod: prefiks + (i + 1), nazwa: tr.name, klipow: n, pierwszy: pierwszy, wyciszona: wyc });
    }
    return w;
}

function nm_info() {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Otwórz sekwencję na osi czasu." });
        var fps = 25;
        try { fps = 1 / s.getSettings().videoFrameRate.seconds; } catch (e1) {}
        var proj = String(app.project.name || "projekt").replace(/\.prproj$/i, "");
        var klipy = 0, material = 0;
        for (var i = 0; i < s.videoTracks.numTracks; i++) {
            var tr = s.videoTracks[i];
            for (var j = 0; j < tr.clips.numItems; j++) { klipy++; material += nm_sekundy(tr.clips[j].end) - nm_sekundy(tr.clips[j].start); }
        }
        var glowica = 0;
        try { glowica = nm_sekundy(s.getPlayerPosition()); } catch (e2) {}
        return nm_json({ ok: true, nazwa: s.name, id: s.sequenceID, projekt: proj, sciezka_projektu: app.project.path,
            fps: fps, sekundy: Number(s.end) / NM_TICKI, szer: s.frameSizeHorizontal, wys: s.frameSizeVertical,
            klipy: klipy, material_s: material, glowica: glowica,
            wideo: nm_sciezki(s.videoTracks, "V"), audio: nm_sciezki(s.audioTracks, "A") });
    } catch (e) {
        return nm_json({ ok: false, blad: String(e) });
    }
}

function nm_kosz(nazwa) {
    nazwa = nazwa || "Studio Nadamedia";
    var root = app.project.rootItem;
    for (var i = 0; i < root.children.numItems; i++) {
        var c = root.children[i];
        if (c.name === nazwa && c.type === ProjectItemType.BIN) return c;
    }
    return root.createBin(nazwa);
}

/* Zaznaczone klipy na osi (do poprawy dźwięku, szablonów). */
function nm_zaznaczone() {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Otwórz sekwencję na osi czasu." });
        var sel = s.getSelection(), w = [];
        for (var i = 0; i < sel.length; i++) {
            var c = sel[i], pi = null, sc = "";
            try { pi = c.projectItem; sc = pi ? pi.getMediaPath() : ""; } catch (e1) {}
            var tor = -1, torA = 0;
            try { tor = nm_tor_klipu(s, c); } catch (e3) {}
            if (String(c.mediaType) === "Audio") try {
                for (var ta = 0; ta < s.audioTracks.numTracks && !torA; ta++) for (var tj = 0; tj < s.audioTracks[ta].clips.numItems; tj++) {
                    var ka = s.audioTracks[ta].clips[tj];
                    if ((c.nodeId && ka.nodeId === c.nodeId) || (ka.name === c.name && nm_sekundy(ka.start) === nm_sekundy(c.start) && nm_sekundy(ka.end) === nm_sekundy(c.end))) { torA = ta + 1; break; }
                }
            } catch (e5) {}
            var od = 0;
            try { od = nm_sekundy(c.inPoint); } catch (e4) {}
            w.push({ nazwa: c.name, typ: String(c.mediaType), start: nm_sekundy(c.start), end: nm_sekundy(c.end), od: od, tor: tor, tor_a: torA,
                sciezka: sc, nodeId: pi ? pi.nodeId : "", idKlipu: c.nodeId || "" });
        }
        var proj = "";
        try { proj = app.project.path; } catch (e2) {}
        return nm_json({ ok: true, klipy: w, projekt: proj });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}

/* Stan osi dla panelu (odpytywany co ~1 s): głowica, zaznaczone klipy wideo i klipy wideo pod głowicą (od najwyższej ścieżki). */
function nm_os_stan() {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "brak_sekwencji" });
        var gl = 0;
        try { gl = nm_sekundy(s.getPlayerPosition()); } catch (e1) {}
        var opis = function (c, tor) {
            var sc = "";
            try { sc = c.projectItem ? c.projectItem.getMediaPath() : ""; } catch (e2) {}
            var od = 0;
            try { od = nm_sekundy(c.inPoint); } catch (e3) {}
            return { nazwa: c.name, start: nm_sekundy(c.start), end: nm_sekundy(c.end), od: od, tor: tor, sciezka: sc, idKlipu: c.nodeId || "", nodeId: c.projectItem ? c.projectItem.nodeId : "" };
        };
        var zazn = [], pod = [];
        for (var i = s.videoTracks.numTracks - 1; i >= 0; i--) {
            var tr = s.videoTracks[i];
            for (var j = 0; j < tr.clips.numItems; j++) {
                var c = tr.clips[j], st = nm_sekundy(c.start), en = nm_sekundy(c.end), z = false;
                try { z = c.isSelected(); } catch (e4) {}
                if (z) zazn.push(opis(c, i));
                if (st <= gl + 0.0001 && en > gl + 0.0001) pod.push(opis(c, i));
            }
        }
        return nm_json({ ok: true, glowica: gl, zaznaczone: zazn, podGlowica: pod, sekwencja: s.sequenceID });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}

/* Wszystkie klipy wideo aktywnej sekwencji (miejsca cięć dla „Animacji z mowy”). */
function nm_klipy_osi() {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Otwórz sekwencję na osi czasu." });
        var w = [];
        for (var i = 0; i < s.videoTracks.numTracks; i++) {
            var tr = s.videoTracks[i];
            for (var j = 0; j < tr.clips.numItems; j++) {
                var c = tr.clips[j], sc = "", od = 0, lum = false, wyl = false;
                try { sc = c.projectItem ? c.projectItem.getMediaPath() : ""; } catch (e1) {}
                try { od = nm_sekundy(c.inPoint); } catch (e2) {}
                try { lum = !!nm_lumetri_komponent(c); } catch (e3) {}
                try { wyl = !!c.disabled; } catch (e4) {}
                w.push({ tor: i + 1, nazwa: c.name, start: nm_sekundy(c.start), end: nm_sekundy(c.end), sciezka: sc, od: od, lumetri: lum, wylaczony: wyl });
            }
        }
        return nm_json({ ok: true, klipy: w, dlugosc: nm_sekundy(s.end) });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}

/* ======================= KOLOR: Lumetri na klipach albo na warstwach korekcyjnych =======================
   ExtendScript nie umie wskazać pliku LUT: Lumetri przyjmuje tylko POZYCJĘ na liście LUT-ów (ustalaną w panelu: „Ustal pozycje LUT-ów”).
   Suwaki (ekspozycja, kontrast, temperatura...) ustawiamy po nazwach parametrów, po polsku albo po angielsku. */
var NM_LUM = {
    temperatura: ["Temperature", "Temperatura"], odcien: ["Tint", "Odcień", "Zabarwienie"], ekspozycja: ["Exposure", "Ekspozycja"],
    kontrast: ["Contrast", "Kontrast"], swiatla: ["Highlights", "Światła", "Jasne obszary"], cienie: ["Shadows", "Cienie"],
    biele: ["Whites", "Biele", "Białe"], czernie: ["Blacks", "Czernie", "Czarne"], nasycenie: ["Saturation", "Nasycenie"],
    wyblakly_film: ["Faded Film", "Wyblakły film", "Wyblakła klisza"], wyostrzenie: ["Sharpen", "Wyostrz", "Wyostrzanie"],
    jaskrawosc: ["Vibrance", "Jaskrawość", "Dynamika"],
    lut_wejscie: ["Input LUT", "Wejściowa LUT", "Wejściowa tabela LUT", "LUT wejściowy"], look: ["Look", "Wygląd"],
    cienie_odcien: ["Shadow Tint", "Odcień cieni", "Zabarwienie cieni"], swiatla_odcien: ["Highlight Tint", "Odcień świateł", "Zabarwienie świateł"],
    winieta: ["Amount", "Ilość", "Wartość", "Stopień"]
};
var NM_ODCIENIE = { teal: [255, 60, 140, 150], orange: [255, 230, 150, 90], niebieski: [255, 80, 110, 190], cieply: [255, 220, 170, 110], zielony: [255, 110, 170, 110] };
function nm_qe_czas(t) { try { if (t && t.secs !== undefined) return Number(t.secs); } catch (e) {} try { return Number(t.seconds); } catch (e2) {} return NaN; }
function nm_lumetri_efekt() {
    var nazwy = ["Lumetri Color", "Kolor Lumetri", "Lumetri"];
    for (var i = 0; i < nazwy.length; i++) { try { var e = qe.project.getVideoEffectByName(nazwy[i]); if (e) return e; } catch (x) {} }
    return null;
}
function nm_efekt_qe(nazwy) { for (var i = 0; i < nazwy.length; i++) { try { var e = qe.project.getVideoEffectByName(nazwy[i]); if (e) return e; } catch (x) {} } return null; }
function nm_qe_klip(tor, start) {
    var qs = qe.project.getActiveSequence(), qt = qs.getVideoTrackAt(tor);
    for (var j = 0; j < qt.numItems; j++) {
        var it = qt.getItemAt(j);
        try { if (it.type === "Empty") continue; } catch (e) {}
        if (Math.abs(nm_qe_czas(it.start) - start) < 0.03) return it;
    }
    return null;
}
function nm_klip_na(s, tor, start) {
    var tr = s.videoTracks[tor];
    for (var j = 0; j < tr.clips.numItems; j++) if (Math.abs(nm_sekundy(tr.clips[j].start) - start) < 0.03) return tr.clips[j];
    return null;
}
function nm_lumetri_komponent(ti) {
    var w = null;
    for (var i = 0; i < ti.components.numItems; i++) { var c = ti.components[i]; if (c.matchName === "AE.ADBE Lumetri" || /lumetri/i.test(c.displayName)) w = c; }
    return w;
}
function nm_ustaw_lumetri(komp, par, uzyte, log) {
    var props = komp.properties, zrobione = 0;
    for (var klucz in par) {
        if (!par.hasOwnProperty(klucz) || !NM_LUM[klucz]) continue;
        var v = par[klucz], nazwy = NM_LUM[klucz], ok = false;
        for (var i = 0; i < props.numItems && !ok; i++) {
            var p = props[i], dn = String(p.displayName);
            for (var n = 0; n < nazwy.length; n++) {
                if (dn === nazwy[n] && !uzyte[i]) {
                    try {
                        if (klucz === "cienie_odcien" || klucz === "swiatla_odcien") { var c = NM_ODCIENIE[v]; if (c) { p.setColorValue(c[0], c[1], c[2], c[3], true); ok = true; } }
                        else { p.setValue(Number(v), true); ok = true; }
                        if (ok) { uzyte[i] = 1; zrobione++; }
                    } catch (e) { log.push(klucz + ": " + e); }
                    break;
                }
            }
        }
        if (!ok && (klucz === "cienie_odcien" || klucz === "swiatla_odcien")) {
            // nowsze Premiere nie nazywają kół odcieni (Shadow/Highlight Tint), a pole bez nazwy to dane binarne: nie ruszamy go
            log.push("Premiere nie pozwala skryptom ustawić kół odcieni cieni i świateł (Lumetri > Creative > Shadow/Highlight Tint): jeśli chcesz mocniejszy klimat, ustaw je ręcznie");
            continue;
        }
        if (!ok) log.push("nie znalazłem parametru " + klucz);
    }
    return zrobione;
}
/* Nazwy parametrów Lumetri na klipie (do sprawdzenia, jak nazywa je Twoja wersja Premiere). */
function nm_lumetri_parametry() {
    try {
        var s = app.project.activeSequence; if (!s) return nm_json({ ok: false, blad: "Brak sekwencji." });
        for (var t = 0; t < s.videoTracks.numTracks; t++) for (var j = 0; j < s.videoTracks[t].clips.numItems; j++) {
            var ti = s.videoTracks[t].clips[j], k = nm_lumetri_komponent(ti);
            if (k) { var w = []; for (var i = 0; i < k.properties.numItems; i++) { var v = null; try { v = k.properties[i].getValue(); } catch (e) {} w.push({ i: i, nazwa: String(k.properties[i].displayName), wartosc: typeof v === "number" || typeof v === "boolean" ? v : String(v) }); }
                return nm_json({ ok: true, klip: ti.name, parametry: w }); }
        }
        return nm_json({ ok: false, blad: "Żaden klip w sekwencji nie ma jeszcze efektu Lumetri." });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}
/* Kopia aktywnej sekwencji (oryginał zostaje bez zmian); otwiera kopię. */
function nm_kopia_sekwencji(dopisek) {
    try {
        var s = app.project.activeSequence; if (!s) return nm_json({ ok: false, blad: "Otwórz sekwencję." });
        var stare = {}, i;
        for (i = 0; i < app.project.sequences.numSequences; i++) stare[app.project.sequences[i].sequenceID] = 1;
        s.clone();
        for (i = 0; i < app.project.sequences.numSequences; i++) {
            var n = app.project.sequences[i];
            if (!stare[n.sequenceID]) { try { n.name = s.name + " " + dopisek; } catch (e1) {} app.project.openSequence(n.sequenceID); return nm_json({ ok: true, nazwa: n.name }); }
        }
        return nm_json({ ok: false, blad: "Premiere nie zrobił kopii sekwencji." });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}
function nm_szukaj_nazwy(el, nazwa) {
    if (el.name === nazwa && el.type !== ProjectItemType.BIN) return el;
    if (el.children) for (var i = 0; i < el.children.numItems; i++) { var w = nm_szukaj_nazwy(el.children[i], nazwa); if (w) return w; }
    return null;
}
/* lista = [{tor (0 = V1), start, end, parametry {...}, lut_indeks, look_indeks, klarownosc {wartosc, promien, prog}, warstwa: true/false}]
   warstwa: kładzie element „Nada Kolor” (warstwę korekcyjną z projektu) na wolnej ścieżce nad klipem i tam daje efekty. */
function nm_kolor_zastosuj(lista, nazwaWarstwy) {
    try {
        var s = app.project.activeSequence; if (!s) return nm_json({ ok: false, blad: "Otwórz sekwencję." });
        app.enableQE();
        var lum = nm_lumetri_efekt();
        if (!lum) return nm_json({ ok: false, blad: "Nie znalazłem efektu Lumetri Color w Premiere (QE)." });
        var warstwa = null, wyniki = [], log = [];
        for (var i = 0; i < lista.length; i++) {
            var x = lista[i], ti = null, qi = null, tor = x.tor, st = x.start;
            if (x.warstwa) {
                if (!warstwa) warstwa = nm_szukaj_nazwy(app.project.rootItem, nazwaWarstwy || "Nada Kolor");
                if (!warstwa) return nm_json({ ok: false, blad: "W projekcie nie ma warstwy korekcyjnej „" + (nazwaWarstwy || "Nada Kolor") + "”. Zrób ją: Plik > Nowy > Warstwa korekcyjna, i nazwij dokładnie „" + (nazwaWarstwy || "Nada Kolor") + "”." });
                var pol = nm_poloz(warstwa, x.start, x.end - x.start);
                if (!pol.ok) { log.push(pol.blad); continue; }
                tor = Number(String(pol.sciezka).replace("V", "")) - 1;
                var nw = nm_klip_na(s, tor, st);
                // warstwa korekcyjna ma zwykle domyślną długość: wydłużamy ją do końca klipu
                if (nw && nm_sekundy(nw.end) < x.end - 0.02) { try { var kk = new Time(); kk.seconds = x.end; nw.end = kk; } catch (eW) { log.push("długość warstwy: " + eW); } }
            }
            ti = nm_klip_na(s, tor, st); qi = nm_qe_klip(tor, st);
            if (!ti || !qi) { log.push("nie znalazłem klipu na V" + (tor + 1) + " w " + st + " s"); wyniki.push({ ok: false }); continue; }
            var komp = x.nowy_lumetri ? null : nm_lumetri_komponent(ti);
            if (!komp) { qi.addVideoEffect(lum); komp = nm_lumetri_komponent(ti); }
            if (!komp) { log.push("Lumetri nie dodał się do " + ti.name); wyniki.push({ ok: false }); continue; }
            var uzyte = {}, ust = nm_ustaw_lumetri(komp, x.parametry || {}, uzyte, log);
            if (x.lut_indeks !== undefined && x.lut_indeks !== null) { var p1 = {}; p1.lut_wejscie = x.lut_indeks; ust += nm_ustaw_lumetri(komp, p1, uzyte, log); }
            if (x.look_indeks !== undefined && x.look_indeks !== null) { var p2 = {}; p2.look = x.look_indeks; ust += nm_ustaw_lumetri(komp, p2, uzyte, log); }
            if (x.klarownosc) {
                var um = nm_efekt_qe(["Unsharp Mask", "Maska wyostrzająca", "Maska wyostrzania"]);
                if (um) {
                    qi.addVideoEffect(um);
                    // dodany efekt szukamy po nazwie (od końca listy), a nie „ostatni na liście”
                    var ku = ti.components[ti.components.numItems - 1];
                    for (var kc = ti.components.numItems - 1; kc >= 0; kc--) { var kcn = String(ti.components[kc].displayName) + " " + String(ti.components[kc].matchName); if (/unsharp|wyostrz/i.test(kcn)) { ku = ti.components[kc]; break; } }
                    // parametry Unsharp Mask po nazwach: w nowszym Premiere na początku listy są pola maski, więc numery się przesuwają
                    var umN = { wartosc: ["Amount", "Ilość", "Wartość"], promien: ["Radius", "Promień"], prog: ["Threshold", "Próg"] }, umU = 0;
                    for (var uk in umN) {
                        if (!umN.hasOwnProperty(uk)) continue;
                        for (var ui = 0; ui < ku.properties.numItems; ui++) {
                            var udn = String(ku.properties[ui].displayName), traf = false;
                            for (var un = 0; un < umN[uk].length; un++) if (udn === umN[uk][un]) traf = true;
                            if (traf) { try { ku.properties[ui].setValue(Number(x.klarownosc[uk] || 0), true); umU++; } catch (eu) { log.push("klarowność (" + udn + "): " + eu); } break; }
                        }
                    }
                    if (!umU) { var umL = []; for (var uz = 0; uz < ku.properties.numItems && uz < 12; uz++) umL.push(String(ku.properties[uz].displayName)); log.push("klarowność: nie znalazłem parametrów efektu Unsharp Mask (efekt: " + ku.displayName + ", pola: " + umL.join(", ") + ")"); }
                } else log.push("brak efektu Unsharp Mask");
            }
            wyniki.push({ ok: true, klip: ti.name, tor: tor + 1, parametrow: ust, idKlipu: ti.nodeId || "" });
        }
        return nm_json({ ok: true, wyniki: wyniki, uwagi: log.slice(0, 40) });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}
/* Ustalanie pozycji LUT-ów: ustawia pozycję `indeks` na liście Wejściowa LUT (albo Wygląd) w Lumetri pierwszego zaznaczonego klipu. */
function nm_lut_probuj(indeks, rodzaj) {
    try {
        var s = app.project.activeSequence; if (!s) return nm_json({ ok: false, blad: "Otwórz sekwencję." });
        app.enableQE();
        for (var t = 0; t < s.videoTracks.numTracks; t++) for (var j = 0; j < s.videoTracks[t].clips.numItems; j++) {
            var ti = s.videoTracks[t].clips[j]; var z = false; try { z = ti.isSelected(); } catch (e0) {}
            if (!z) continue;
            var komp = nm_lumetri_komponent(ti);
            if (!komp) { var qi = nm_qe_klip(t, nm_sekundy(ti.start)), lum = nm_lumetri_efekt(); if (qi && lum) qi.addVideoEffect(lum); komp = nm_lumetri_komponent(ti); }
            if (!komp) return nm_json({ ok: false, blad: "Nie udało się dodać Lumetri do zaznaczonego klipu." });
            var p = {}; p[rodzaj === "look" ? "look" : "lut_wejscie"] = Number(indeks);
            var log = [], n = nm_ustaw_lumetri(komp, p, {}, log);
            return nm_json({ ok: n > 0, klip: ti.name, blad: log.join("; ") });
        }
        return nm_json({ ok: false, blad: "Zaznacz na osi jeden klip (do próby; potem możesz usunąć z niego Lumetri)." });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}

/* Ustawia długość elementu projektu (punkt wyjścia) przed położeniem go na osi. Bez tego Premiere kładzie cały plik
   (animacje mają 15 s zapasu na końcu) i nadpisuje to, co leży dalej na tej samej ścieżce, nawet jeśli potem klip skrócimy. */
function nm_przytnij_element(el, dl) {
    dl = Number(dl);
    if (!el || !(dl > 0) || typeof el.setOutPoint !== "function") return false;
    var ok = function () { try { return Math.abs(Number(el.getOutPoint(4).seconds) - dl) < 0.05; } catch (e) { return false; } };
    try { el.setInPoint(0, 4); el.setOutPoint(dl, 4); if (ok()) return true; } catch (e1) {}
    try { var a = new Time(); a.seconds = 0; var b = new Time(); b.seconds = dl; el.setInPoint(a, 4); el.setOutPoint(b, 4); if (ok()) return true; } catch (e2) {}
    try { el.setInPoint("0", 4); el.setOutPoint(String(Math.round(dl * NM_TICKI)), 4); if (ok()) return true; } catch (e3) {}
    return false;
}
/* Czy na ścieżce coś leży w przedziale [od, do). */
function nm_tor_zajety(tr, od, doo, pomin) {
    for (var j = 0; j < tr.clips.numItems; j++) { var c = tr.clips[j]; if (c === pomin) continue; if (nm_sekundy(c.start) < doo - 0.001 && nm_sekundy(c.end) > od + 0.001) return true; }
    return false;
}

/* Napisy z panelu: każdy fragment osobnym klipem na jednej wolnej ścieżce nad całym obrazem.
   lista = [{p: plik, od: sekundy, do: sekundy}]; zwraca idKlipu każdego fragmentu (w tej samej kolejności). */
function nm_wstaw_napisy(lista, nazwaKosza) {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Brak aktywnej sekwencji." });
        if (!lista.length) return nm_json({ ok: false, blad: "Brak napisów do wstawienia." });
        var od = lista[0].od, doo = lista[lista.length - 1]["do"], najwyzsza = -1;
        for (var i = 0; i < s.videoTracks.numTracks; i++) {
            var tr = s.videoTracks[i];
            for (var j = 0; j < tr.clips.numItems; j++) {
                var c = tr.clips[j];
                if (nm_sekundy(c.start) < doo && nm_sekundy(c.end) > od) najwyzsza = i;
            }
        }
        var cel = najwyzsza + 1;
        if (cel >= s.videoTracks.numTracks) {
            try { app.enableQE(); qe.project.getActiveSequence().addTracks(1, s.videoTracks.numTracks, 0); } catch (eq) {}
            if (cel >= s.videoTracks.numTracks) return nm_json({ ok: false, blad: "Brak wolnej ścieżki wideo nad filmem: dodaj pustą ścieżkę (prawy klik na nagłówku ścieżek > Dodaj ścieżkę) i spróbuj ponownie." });
        }
        var kosz = nm_kosz(nazwaKosza || "Nada – napisy"), pliki = [];
        for (var k = 0; k < lista.length; k++) pliki.push(lista[k].p);
        app.project.importFiles(pliki, true, kosz, false);
        var mapa = {};
        for (var m = 0; m < kosz.children.numItems; m++) mapa[kosz.children[m].name] = kosz.children[m];
        var tor = s.videoTracks[cel], ids = [], brak = 0;
        for (var n = 0; n < lista.length; n++) {
            var nazwa = String(lista[n].p).replace(/^.*[\\\/]/, ""), el = mapa[nazwa];
            if (!el) { ids.push(""); brak++; continue; }
            var t = new Time(); t.seconds = Number(lista[n].od);
            nm_przytnij_element(el, Number(lista[n]["do"]) - Number(lista[n].od));
            tor.overwriteClip(el, t);
            var nowy = nm_klip_od(tor, t);
            if (nowy) { try { var kon = new Time(); kon.seconds = Number(lista[n]["do"]); if (Math.abs(nm_sekundy(nowy.end) - kon.seconds) > 0.02) nowy.end = kon; } catch (eK) {} }
            ids.push(nowy ? (nowy.nodeId || "") : "");
        }
        return nm_json({ ok: true, sciezka: "V" + (cel + 1), ids: ids, brak: brak });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}

/* Czy klip na osi to nasz plik (wstawiony z panelu)? Panel nigdy nie usuwa, nie przesuwa ani nie podmienia klipów użytkownika.
   Numery klipów (nodeId) w Premiere nie są stałe między sesjami: po ponownym otwarciu projektu stary numer może trafić na zwykły klip. */
function nm_sciezka_klipu(c) { var p = ""; try { p = c.projectItem ? String(c.projectItem.getMediaPath() || "") : ""; } catch (e) {} return p; }
function nm_nasz(c, oczekiwany) {
    if (!c) return false;
    var p = nm_sciezka_klipu(c), plik = p.replace(/^.*[\\\/]/, "").toLowerCase();
    if (oczekiwany) {
        var o = String(oczekiwany).replace(/^.*[\\\/]/, "").toLowerCase();
        if (p && plik !== o && plik.replace(/\.[^.]+$/, "") !== o.replace(/\.[^.]+$/, "")) return false;
    }
    if (!p) return /^nada/i.test(String(c.name || "")) || /\.mogrt$/i.test(String(oczekiwany || ""));
    return /[\\\/]wyniki[\\\/]/i.test(p) || /\.(mogrt|aegraphic)$/i.test(p) || (/\.aep$/i.test(p) && /^nada/i.test(String(c.name || "")));
}
var NM_NIE_NASZ = "Ten klip nie jest animacją ani napisem z panelu (to Twój materiał), więc panel go nie ruszył.";

/* Podmienia wiele klipów naraz (np. nowy wygląd wszystkich napisów): ten sam tor, początek i koniec. lista = [{id, p}]. */
function nm_podmien_wiele(lista, nazwaKosza) {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Brak aktywnej sekwencji." });
        var miejsca = [], pliki = [];
        for (var i = 0; i < lista.length; i++) {
            var c = nm_znajdz_klip(s, lista[i].id);
            if (!c || !nm_nasz(c, lista[i].stary)) { miejsca.push(null); continue; }
            var tor = -1;
            for (var t = 0; t < s.videoTracks.numTracks && tor < 0; t++) for (var j = 0; j < s.videoTracks[t].clips.numItems; j++) if (s.videoTracks[t].clips[j].nodeId === lista[i].id) { tor = t; break; }
            miejsca.push({ tor: tor, start: c.start, end: c.end });
            c.remove(false, false);
            pliki.push(lista[i].p);
        }
        var kosz = nm_kosz(nazwaKosza || "Nada – napisy");
        if (pliki.length) app.project.importFiles(pliki, true, kosz, false);
        var mapa = {};
        for (var m = 0; m < kosz.children.numItems; m++) mapa[kosz.children[m].name] = kosz.children[m];
        var ids = [];
        for (var n = 0; n < lista.length; n++) {
            var mj = miejsca[n], el = mapa[String(lista[n].p).replace(/^.*[\\\/]/, "")];
            if (!mj || !el) { ids.push(""); continue; }
            nm_przytnij_element(el, nm_sekundy(mj.end) - nm_sekundy(mj.start));
            s.videoTracks[mj.tor].overwriteClip(el, mj.start);
            var nowy = nm_klip_od(s.videoTracks[mj.tor], mj.start);
            if (nowy) { try { nowy.end = mj.end; } catch (eK) {} }
            ids.push(nowy ? (nowy.nodeId || "") : "");
        }
        return nm_json({ ok: true, ids: ids });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}

/* Gdzie teraz są klipy o podanych id (po przesunięciu albo przycięciu na osi); null = usunięty z osi. */
function nm_klipy_stan(ids) {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Brak aktywnej sekwencji." });
        var szukane = {}, w = {};
        for (var i = 0; i < ids.length; i++) { szukane[ids[i]] = true; w[ids[i]] = null; }
        for (var t = 0; t < s.videoTracks.numTracks; t++) {
            var tr = s.videoTracks[t];
            for (var j = 0; j < tr.clips.numItems; j++) {
                var c = tr.clips[j];
                if (c.nodeId && szukane[c.nodeId]) {
                    // pocięty żyletką: tuż obok leży kawałek tego samego pliku (to nie jest wydłużenie ani skrócenie animacji)
                    var sc = nm_sciezka_klipu(c), pociety = false;
                    for (var k = 0; k < tr.clips.numItems; k++) {
                        if (k === j) continue;
                        var d = tr.clips[k];
                        if ((Math.abs(nm_sekundy(d.start) - nm_sekundy(c.end)) < 0.02 || Math.abs(nm_sekundy(d.end) - nm_sekundy(c.start)) < 0.02) && nm_sciezka_klipu(d) === sc) { pociety = true; break; }
                    }
                    w[c.nodeId] = { start: nm_sekundy(c.start), end: nm_sekundy(c.end), tor: t, sciezka: sc, nazwa: String(c.name || ''), nasz: nm_nasz(c), pociety: pociety, od: nm_sekundy(c.inPoint) };
                }
            }
        }
        return nm_json({ ok: true, klipy: w });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}
function nm_znajdz_klip(s, id) {
    for (var t = 0; t < s.videoTracks.numTracks; t++) {
        var tr = s.videoTracks[t];
        for (var j = 0; j < tr.clips.numItems; j++) if (tr.clips[j].nodeId === id) return tr.clips[j];
    }
    return null;
}
/* Usuwa z osi klip wstawiony z panelu (np. napis). */
function nm_usun_klip(id, oczekiwany) {
    try {
        var s = app.project.activeSequence, c = s ? nm_znajdz_klip(s, id) : null;
        if (!c) return nm_json({ ok: true, juz: true });
        if (!nm_nasz(c, oczekiwany)) return nm_json({ ok: false, nie_nasz: true, blad: NM_NIE_NASZ });
        c.remove(false, false);
        return nm_json({ ok: true });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}
/* Przesuwa klip z panelu o podaną liczbę sekund (ujemna = wcześniej). */
function nm_przesun_klip(id, sekundy, oczekiwany) {
    try {
        var s = app.project.activeSequence, c = s ? nm_znajdz_klip(s, id) : null;
        if (!c) return nm_json({ ok: false, blad: "Nie widzę tego klipu na osi." });
        if (!nm_nasz(c, oczekiwany)) return nm_json({ ok: false, nie_nasz: true, blad: NM_NIE_NASZ });
        var t = new Time(); t.seconds = Number(sekundy);
        c.move(t);
        return nm_json({ ok: true, start: nm_sekundy(c.start), end: nm_sekundy(c.end) });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}
/* Plik SRT jako prawdziwe napisy Premiere (ścieżka napisów: tekst i czasy poprawiasz w panelu Tekst > Napisy). */
function nm_napisy_premiere(srt) {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Brak aktywnej sekwencji." });
        var kosz = nm_kosz("Nada – napisy");
        app.project.importFiles([srt], true, kosz, false);
        var el = nm_znajdz_element(kosz, String(srt).replace(/^.*[\\\/]/, ""));
        if (!el) return nm_json({ ok: false, blad: "Premiere nie zaimportował pliku SRT." });
        if (typeof s.createCaptionTrack !== "function") return nm_json({ ok: false, blad: "Ta wersja Premiere nie umie dodać napisów ze skryptu. Przeciągnij plik SRT z kosza „Nada – napisy” na oś." });
        var t = new Time(); t.seconds = 0;
        var ok = s.createCaptionTrack(el, t.seconds, Sequence.CAPTION_FORMAT_SUBTITLE);
        return nm_json({ ok: true, wynik: !!ok });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}

/* Numer ścieżki wideo (od 0), na której leży klip z osi; -1 = klip audio albo nie znaleziony. */
function nm_tor_klipu(s, c) {
    for (var i = 0; i < s.videoTracks.numTracks; i++) {
        var tr = s.videoTracks[i];
        for (var j = 0; j < tr.clips.numItems; j++) {
            var k = tr.clips[j];
            if ((c.nodeId && k.nodeId === c.nodeId) || (k.name === c.name && nm_sekundy(k.start) === nm_sekundy(c.start))) return i;
        }
    }
    return -1;
}

/* Jak „Zastąp kompozycją After Effects”: kompozycja z projektu AE ląduje w miejscu klipu (ta sama ścieżka, ten sam start).
   Dźwięk klipu zostaje na swojej ścieżce, bo kompozycja nie ma dźwięku. */
function nm_zastap_ae(aep, komp, tor, start) {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Brak aktywnej sekwencji." });
        var kosz = nm_kosz("Nada Studio – After Effects");
        app.project.importAEComps(aep, [komp], kosz);
        var el = nm_znajdz_element(kosz, komp);
        if (!el) for (var i = kosz.children.numItems - 1; i >= 0; i--) if (String(kosz.children[i].name).indexOf(komp) >= 0) { el = kosz.children[i]; break; }
        if (!el) return nm_json({ ok: false, blad: "After Effects zapisał projekt, ale Premiere nie zaimportował kompozycji. Plik > Importuj > " + aep });
        if (tor < 0 || tor >= s.videoTracks.numTracks) return nm_json(nm_poloz(el, start, 5));
        var t = new Time();
        t.seconds = Number(start) || 0;
        // tylko obraz: Premiere kładzie kompozycję razem z jej (cichym) dźwiękiem i nadpisuje nim dźwięk klipu.
        // Na czas wstawiania ścieżki audio są zablokowane, a dźwięk kompozycji, jeśli mimo to trafi na oś, usuwamy.
        var at = s.audioTracks, zamki = [], i2;
        for (i2 = 0; i2 < at.numTracks; i2++) { var z = false; try { z = !!at[i2].isLocked(); } catch (eL) {} zamki.push(z); }
        var mozna = true;
        for (i2 = 0; i2 < at.numTracks; i2++) { try { at[i2].setLocked(1); } catch (eS) { mozna = false; } }
        var nowyId = el.nodeId, usunieteA = 0;
        try { s.videoTracks[tor].overwriteClip(el, t); }
        finally { for (i2 = 0; i2 < zamki.length && i2 < at.numTracks; i2++) { try { at[i2].setLocked(zamki[i2] ? 1 : 0); } catch (eR) {} } }
        for (i2 = 0; i2 < s.audioTracks.numTracks; i2++) {
            var ta = s.audioTracks[i2];
            for (var j2 = ta.clips.numItems - 1; j2 >= 0; j2--) {
                var ca = ta.clips[j2], pi = null;
                try { pi = ca.projectItem; } catch (eP) {}
                if (pi && pi.nodeId === nowyId) { try { ca.remove(false, false); usunieteA++; } catch (eU) {} }
            }
        }
        return nm_json({ ok: true, sciezka: "V" + (tor + 1), od: start, zastapiono: true, dzwiek_nietkniety: mozna, usuniete_audio: usunieteA });
    } catch (e) {
        return nm_json({ ok: false, blad: String(e) });
    }
}

/* Szablon ruchomej grafiki (.mogrt) na wolnej ścieżce nad filmem; rozciągasz go jak zwykły klip, wejście i wyjście zostają stałe. */
function nm_wstaw_mogrt(plik, sekundy, dlugosc) {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Brak aktywnej sekwencji." });
        var od = Number(sekundy) || 0, dl = Number(dlugosc) || 3, najwyzsza = -1;
        for (var i = 0; i < s.videoTracks.numTracks; i++) {
            var tr = s.videoTracks[i];
            for (var j = 0; j < tr.clips.numItems; j++) {
                var c = tr.clips[j];
                if (nm_sekundy(c.start) < od + dl && nm_sekundy(c.end) > od) najwyzsza = i;
            }
        }
        var cel = najwyzsza + 1;
        if (cel >= s.videoTracks.numTracks) {
            try { app.enableQE(); qe.project.getActiveSequence().addTracks(1, s.videoTracks.numTracks, 0); } catch (eq) {}
            if (cel >= s.videoTracks.numTracks) return nm_json({ ok: false, blad: "Brak wolnej ścieżki wideo nad filmem: dodaj pustą ścieżkę i spróbuj ponownie." });
        }
        var ticki = String(Math.round(od * NM_TICKI));
        var ti = s.importMGT(plik, ticki, cel, 0);
        if (!ti) return nm_json({ ok: false, blad: "Premiere nie przyjął pliku .mogrt: " + plik });
        try { var kon = new Time(); kon.seconds = od + dl; ti.end = kon; } catch (eK) {}
        return nm_json({ ok: true, sciezka: "V" + (cel + 1), nazwa: ti.name, idKlipu: ti.nodeId || "" });
    } catch (e) {
        return nm_json({ ok: false, blad: String(e) });
    }
}

/* Podmienia animację na osi (np. po edycji w panelu): ten sam tor, ten sam początek i ta sama długość. */
function nm_podmien_animacje(idKlipu, plik, czyMogrt, oczekiwany) {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Brak aktywnej sekwencji." });
        var klip = null, tor = -1;
        for (var i = 0; i < s.videoTracks.numTracks && !klip; i++) {
            var tr = s.videoTracks[i];
            for (var j = 0; j < tr.clips.numItems; j++) if (tr.clips[j].nodeId === idKlipu) { klip = tr.clips[j]; tor = i; break; }
        }
        if (!klip) return nm_json({ ok: false, blad: "Nie widzę już tej animacji na osi. Zaznacz ją jeszcze raz i kliknij „Edytuj zaznaczoną na osi”." });
        if (!nm_nasz(klip, oczekiwany)) return nm_json({ ok: false, nie_nasz: true, blad: NM_NIE_NASZ });
        var start = klip.start, koniec = klip.end, bylZazn = false;
        try { bylZazn = !!klip.isSelected(); } catch (eS0) {}
        try { klip.remove(false, false); } catch (eR) { return nm_json({ ok: false, blad: "Premiere nie pozwolił usunąć starej wersji: " + eR }); }
        var nowy = null;
        if (czyMogrt) nowy = s.importMGT(plik, String(start.ticks), tor, 0);
        else {
            var kosz = nm_kosz();
            app.project.importFiles([plik], true, kosz, false);
            var el = nm_znajdz_element(kosz, plik.replace(/^.*[\\\/]/, ""));
            if (el) {
                var dlA = nm_sekundy(koniec) - nm_sekundy(start);
                if (!nm_przytnij_element(el, dlA)) {
                    // Premiere nie dał ustawić długości: kładziemy tylko tam, gdzie cały plik nic nie nadpisze
                    var dlP = dlA + 16; try { dlP = Math.max(dlA, Number(el.getOutPoint(4).seconds) - Number(el.getInPoint(4).seconds)); } catch (eD) {}
                    if (nm_tor_zajety(s.videoTracks[tor], nm_sekundy(start), nm_sekundy(start) + dlP)) {
                        var r0 = nm_poloz(el, nm_sekundy(start), dlA);
                        if (!r0.ok) return nm_json(r0);
                        if (bylZazn && r0.idKlipu) nm_zaznacz_id(s, r0.idKlipu);
                        return nm_json({ ok: true, sciezka: r0.sciezka, nazwa: r0.nazwa, idKlipu: r0.idKlipu, inna_sciezka: true, zaznaczona: bylZazn });
                    }
                }
                s.videoTracks[tor].overwriteClip(el, start); nowy = nm_klip_od(s.videoTracks[tor], start);
            }
        }
        if (!nowy) return nm_json({ ok: false, blad: "Nowa wersja nie trafiła na oś: " + plik });
        try { nowy.end = koniec; } catch (eK) {}
        // nowa wersja zostaje zaznaczona, jeśli stara była: edycja w panelu trwa tylko dla zaznaczonej animacji
        if (bylZazn) { try { nowy.setSelected(true, true); } catch (eZ) {} }
        return nm_json({ ok: true, sciezka: "V" + (tor + 1), nazwa: nowy.name, idKlipu: nowy.nodeId || "", zaznaczona: bylZazn });
    } catch (e) {
        return nm_json({ ok: false, blad: String(e) });
    }
}
function nm_zaznacz_id(s, id) {
    for (var i = 0; i < s.videoTracks.numTracks; i++) for (var j = 0; j < s.videoTracks[i].clips.numItems; j++) {
        var c = s.videoTracks[i].clips[j];
        if (c.nodeId === id) { try { c.setSelected(true, true); } catch (e) {} return true; }
    }
    return false;
}
function nm_klip_od(tr, start) {
    for (var j = 0; j < tr.clips.numItems; j++) if (Math.abs(tr.clips[j].start.seconds - start.seconds) < 0.01) return tr.clips[j];
    return null;
}

function nm_szukaj_id(el, id) {
    if (el.nodeId === id) return el;
    if (el.children) for (var i = 0; i < el.children.numItems; i++) { var w = nm_szukaj_id(el.children[i], id); if (w) return w; }
    return null;
}

/* Podmienia plik w elemencie projektu (klipy na osi zostają na miejscu); kopię oryginału wrzuca do kosza Backup. */
function nm_podmien_media(nodeId, nowa, kopia) {
    try {
        var el = nm_szukaj_id(app.project.rootItem, nodeId);
        if (!el) return nm_json({ ok: false, blad: "Nie znalazłem tego klipu w projekcie." });
        if (kopia) { try { app.project.importFiles([kopia], true, nm_kosz("Backup"), false); } catch (e1) {} }
        if (el.canChangeMediaPath && !el.canChangeMediaPath()) return nm_json({ ok: false, blad: "Premiere nie pozwala podmienić pliku w tym klipie (np. zagnieżdżona sekwencja)." });
        var ok = el.changeMediaPath(nowa, true);
        return nm_json({ ok: !!ok, blad: ok ? null : "Premiere nie podmienił pliku. Nowy plik: " + nowa });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}

/* Stare wstawianie na aktywną sekwencję (nieużywane przez asystenta audio: on wstawia do kopii, nm_miks_w_kopii).
   Nie dodaje ścieżek przez wewnętrzne funkcje Premiere. */
function nm_wstaw_audio(sciezka, sekundy, wycisz) {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Brak aktywnej sekwencji." });
        var kosz = nm_kosz(), plik = new File(sciezka);
        app.project.importFiles([sciezka], true, kosz, false);
        var el = nm_znajdz_element(kosz, plik.displayName || plik.name);
        if (!el) return nm_json({ ok: false, blad: "Zaimportowano, ale nie widzę pliku w koszu Studio Nadamedia." });
        var cel = -1;
        for (var i = 0; i < s.audioTracks.numTracks; i++) if (s.audioTracks[i].clips.numItems === 0) { cel = i; break; }
        if (cel < 0) return nm_json({ ok: false, blad: "Brak pustej ścieżki audio: dodaj jedną (prawy klik na nagłówku ścieżek > Dodaj ścieżkę) i spróbuj ponownie. Plik jest w koszu Studio Nadamedia." });
        var t = new Time(); t.seconds = Number(sekundy) || 0;
        s.audioTracks[cel].overwriteClip(el, t);
        var lista = wycisz || [];
        for (var k = 0; k < lista.length; k++) { try { s.audioTracks[lista[k] - 1].setMute(1); } catch (em) {} }
        return nm_json({ ok: true, sciezka: "A" + (cel + 1) });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}

function nm_ae_przod() {
    try { BridgeTalk.bringToFront(BridgeTalk.getSpecifier("aftereffects")); } catch (e) {}
    return nm_json({ ok: true });
}

function nm_znajdz_element(kosz, nazwa) {
    for (var i = kosz.children.numItems - 1; i >= 0; i--) {
        if (kosz.children[i].name === nazwa) return kosz.children[i];
    }
    return null;
}

/* Kładzie element projektu na osi czasu w danej sekundzie, na pierwszej wolnej ścieżce wideo nad wszystkim,
   co leży w tym miejscu. Gdy brak wolnej ścieżki, dodaje nową. Niczego nie nadpisuje. */
function nm_poloz(el, sekundy, dlugosc) {
    var s = app.project.activeSequence;
    if (!s) return { ok: false, blad: "Brak aktywnej sekwencji." };
    var od = Number(sekundy), dl = Number(dlugosc) || 3, najwyzsza = -1;
    // długość pliku na osi = dl; gdy Premiere nie da jej ustawić, ścieżka musi być wolna na całą długość pliku
    var okno = dl;
    if (!(Number(dlugosc) > 0 && nm_przytnij_element(el, dl))) { try { okno = Math.max(dl, Number(el.getOutPoint(4).seconds) - Number(el.getInPoint(4).seconds)); } catch (eO) { okno = dl + 16; } }
    for (var i = 0; i < s.videoTracks.numTracks; i++) {
        var tr = s.videoTracks[i];
        for (var j = 0; j < tr.clips.numItems; j++) {
            var c = tr.clips[j];
            if (nm_sekundy(c.start) < od + dl && nm_sekundy(c.end) > od) najwyzsza = i;
        }
    }
    var cel = najwyzsza + 1;
    while (cel < s.videoTracks.numTracks && nm_tor_zajety(s.videoTracks[cel], od, od + okno)) cel++;
    if (cel >= s.videoTracks.numTracks) {
        try { app.enableQE(); qe.project.getActiveSequence().addTracks(1, s.videoTracks.numTracks, 0); } catch (eq) {}
        if (cel >= s.videoTracks.numTracks) return { ok: false, blad: "Brak wolnej ścieżki wideo nad filmem: dodaj pustą ścieżkę (prawy klik na nagłówku ścieżek > Dodaj ścieżkę) i spróbuj ponownie. Element jest w koszu Studio Nadamedia." };
    }
    var t = new Time();
    t.seconds = od;
    s.videoTracks[cel].overwriteClip(el, t);
    var nowy = nm_klip_od(s.videoTracks[cel], t), id = "";
    // długość jak klip pod spodem (gdy plik jest dłuższy albo równy)
    if (nowy) { try { if (Number(dlugosc) > 0 && nm_sekundy(nowy.end) - od > Number(dlugosc) + 0.02) { var k = new Time(); k.seconds = od + Number(dlugosc); nowy.end = k; } } catch (eK) {} id = nowy.nodeId || ""; }
    return { ok: true, sciezka: "V" + (cel + 1), od: od, idKlipu: id, nazwa: nowy ? nowy.name : "" };
}

/* Wstawia plik (np. animację .mov) pod głowicą na wolnej ścieżce nad filmem. */
function nm_wstaw(sciezka, sekundy, dlugosc) {
    try {
        if (!app.project.activeSequence) return nm_json({ ok: false, blad: "Brak aktywnej sekwencji." });
        var kosz = nm_kosz();
        var plik = new File(sciezka);
        app.project.importFiles([sciezka], true, kosz, false);
        var el = nm_znajdz_element(kosz, plik.displayName || plik.name);
        if (!el) return nm_json({ ok: false, blad: "Zaimportowano, ale nie widzę pliku w koszu Studio Nadamedia." });
        return nm_json(nm_poloz(el, sekundy, dlugosc));
    } catch (e) {
        return nm_json({ ok: false, blad: String(e) });
    }
}

/* Wysyła skrypt do After Effects (uruchamia AE, jeśli jest zamknięte). */
function nm_ae_wyslij(skrypt) {
    try {
        var cel = BridgeTalk.getSpecifier("aftereffects");
        if (!cel) return nm_json({ ok: false, blad: "Nie widzę After Effects na tym komputerze." });
        if (!BridgeTalk.isRunning(cel)) BridgeTalk.launch(cel);
        var bt = new BridgeTalk();
        bt.target = cel;
        bt.body = "$.evalFile(new File(" + nm_tekst(skrypt) + "));";
        bt.send();
        return nm_json({ ok: true, cel: cel });
    } catch (e) {
        return nm_json({ ok: false, blad: String(e) });
    }
}

/* Dynamic Link: kompozycja z projektu After Effects trafia do Premiere i pod głowicę. */
function nm_import_ae(aep, komp, sekundy, dlugosc) {
    try {
        if (!app.project.activeSequence) return nm_json({ ok: false, blad: "Brak aktywnej sekwencji." });
        var kosz = nm_kosz();
        app.project.importAEComps(aep, [komp], kosz);
        var el = nm_znajdz_element(kosz, komp);
        if (!el) {
            // Premiere czasem dopisuje nazwę projektu: szukamy po początku nazwy
            for (var i = kosz.children.numItems - 1; i >= 0; i--) if (String(kosz.children[i].name).indexOf(komp) >= 0) { el = kosz.children[i]; break; }
        }
        if (!el) return nm_json({ ok: false, blad: "After Effects zapisał projekt, ale Premiere nie zaimportował kompozycji. Plik > Importuj > " + aep });
        return nm_json(nm_poloz(el, sekundy, dlugosc));
    } catch (e) {
        return nm_json({ ok: false, blad: String(e) });
    }
}

/* --- funkcje dla panelu otwartego w After Effects --- */
function nm_ae_info() {
    try {
        var c = app.project.activeItem;
        var komp = (c && c instanceof CompItem) ? { nazwa: c.name, szer: c.width, wys: c.height, fps: c.frameRate, czas: c.time } : null;
        return nm_json({ ok: true, ae: true, projekt: app.project.file ? app.project.file.name.replace(/\.aep$/i, "") : "projekt", komp: komp });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}
function nm_ae_buduj_tutaj(builder, opisJson, nazwa, fps, log) {
    try {
        $.evalFile(new File(builder));
        var w = NM_AE_BUDUJ(eval("(" + opisJson + ")"), { projekt: null, nazwaKomp: nazwa, fps: fps, log: log || null, wynik: null });
        return nm_json({ ok: w.indexOf("ok|") === 0, wynik: w, blad: w.indexOf("ok|") === 0 ? null : w });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}
function nm_ae_importuj(plik) {
    try {
        var it = app.project.importFile(new ImportOptions(new File(plik)));
        var c = app.project.activeItem;
        if (c && c instanceof CompItem) { var l = c.layers.add(it); l.startTime = c.time; }
        return nm_json({ ok: true });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}

/* Pliki i ich proksy podpięte w Premiere (Utwórz proksy / Dołącz proksy) dla klipów wideo aktywnej sekwencji. */
function nm_proksy() {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Brak aktywnej sekwencji." });
        var w = [], byly = {};
        for (var t = 0; t < s.videoTracks.numTracks; t++) {
            var tr = s.videoTracks[t];
            for (var i = 0; i < tr.clips.numItems; i++) {
                var pi = null, m = "", px = "";
                try { pi = tr.clips[i].projectItem; } catch (e1) {}
                if (!pi) continue;
                try { m = pi.getMediaPath(); } catch (e2) {}
                if (!m || byly[m]) continue;
                byly[m] = 1;
                try { if (pi.hasProxy()) px = pi.getProxyPath(); } catch (e3) {}
                w.push({ plik: m, proksy: px || null });
            }
        }
        return nm_json({ ok: true, pliki: w });
    } catch (e) {
        return nm_json({ ok: false, blad: String(e) });
    }
}

function nm_eksportuj(sciezka) {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Brak aktywnej sekwencji." });
        var ok = s.exportAsFinalCutProXML(sciezka, 1);
        var f = new File(sciezka);
        if (!f.exists) return nm_json({ ok: false, blad: "Premiere nie zapisał XML sekwencji (" + ok + ")." });
        return nm_json({ ok: true, plik: sciezka });
    } catch (e) {
        return nm_json({ ok: false, blad: String(e) });
    }
}

function nm_importuj(sciezka, nazwa) {
    try {
        var przed = {};
        for (var i = 0; i < app.project.sequences.numSequences; i++) przed[app.project.sequences[i].sequenceID] = true;
        app.project.importFiles([sciezka], true, app.project.getInsertionBin(), false);
        var znaleziona = null;
        for (var j = app.project.sequences.numSequences - 1; j >= 0; j--) {
            var q = app.project.sequences[j];
            if (!przed[q.sequenceID] && (q.name === nazwa || !znaleziona)) {
                znaleziona = q;
                if (q.name === nazwa) break;
            }
        }
        if (!znaleziona) return nm_json({ ok: false, blad: "Import się wykonał, ale nie widzę nowej sekwencji. Poszukaj jej w panelu Projekt." });
        app.project.openSequence(znaleziona.sequenceID);
        return nm_json({ ok: true, nazwa: znaleziona.name, id: znaleziona.sequenceID });
    } catch (e) {
        return nm_json({ ok: false, blad: String(e) });
    }
}

function nm_idz(sekundy) {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false });
        s.setPlayerPosition(String(Math.round(sekundy * NM_TICKI)));
        return nm_json({ ok: true });
    } catch (e) {
        return nm_json({ ok: false, blad: String(e) });
    }
}

/* Kadr spod głowicy jako PNG (do tła podglądu animacji). Używa nieoficjalnego QE, więc gdy się nie uda, zwraca błąd. */
function nm_klatka(sciezka) {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Brak sekwencji." });
        app.enableQE();
        var q = qe.project.getActiveSequence();
        var tc = s.getPlayerPosition().getFormatted(s.getSettings().videoFrameRate, s.getSettings().videoDisplayFormat);
        q.exportFramePNG(tc, sciezka);
        var f = new File(sciezka), f2 = new File(sciezka + ".png");
        if (f.exists) return nm_json({ ok: true, plik: sciezka });
        if (f2.exists) return nm_json({ ok: true, plik: sciezka + ".png" });
        return nm_json({ ok: false, blad: "Premiere nie zapisał kadru." });
    } catch (e) {
        return nm_json({ ok: false, blad: String(e) });
    }
}

/* Po imporcie timeline'u z silnika (aftermovie, rolka): dynamiczne przejścia Premiere w miejscach z pliku _dodatki.json
   (Push, Cross Zoom, Iris Round; plik XML ich nie przenosi) oraz sprawdzenie muzyki i efektów dźwiękowych:
   gdy Premiere nie wczytał ich z XML, kładzie je sam na wolnych ścieżkach audio. Działa na aktywnej sekwencji. */
function nm_ustaw_zakres(el, od, doo) {
    od = Number(od) || 0; doo = Number(doo);
    if (!el || !(doo > od) || typeof el.setOutPoint !== "function") return false;
    var ok = function () { try { return Math.abs(Number(el.getOutPoint(4).seconds) - doo) < 0.05 && Math.abs(Number(el.getInPoint(4).seconds) - od) < 0.05; } catch (e) { return false; } };
    try { el.setInPoint(od, 4); el.setOutPoint(doo, 4); if (ok()) return true; } catch (e1) {}
    try { var a = new Time(); a.seconds = od; var b = new Time(); b.seconds = doo; el.setInPoint(a, 4); el.setOutPoint(b, 4); if (ok()) return true; } catch (e2) {}
    try { el.setInPoint(String(Math.round(od * NM_TICKI)), 4); el.setOutPoint(String(Math.round(doo * NM_TICKI)), 4); if (ok()) return true; } catch (e3) {}
    return false;
}
function nm_liczba_przejsc(tr) { try { return tr.transitions ? tr.transitions.numItems : -1; } catch (e) { return -1; } }
function nm_tc(s, sekundy) {
    try { var t = new Time(); t.seconds = sekundy; var ust = s.getSettings(); return t.getFormatted(ust.videoFrameRate, ust.videoDisplayFormat); } catch (e) {}
    var fps = 25; try { fps = 1 / Number(s.getSettings().videoFrameRate.seconds); } catch (e2) {}
    var kl = Math.max(1, Math.round(sekundy * fps)), ff = kl % Math.round(fps), ss = Math.floor(kl / Math.round(fps));
    return "00:00:" + (ss < 10 ? "0" : "") + ss + ":" + (ff < 10 ? "0" : "") + ff;
}
function nm_dodatki_sekwencji(dane) {
    try {
        var s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Brak aktywnej sekwencji." });
        var d = typeof dane === "string" ? eval("(" + dane + ")") : dane, w = { ok: true, przejscia: 0, przejscia_brak: [], muzyka: "", efekty_dodane: 0, uwagi: [] };
        var fps = Number(d.fps) || 25;
        // --- przejścia ---
        var lista = d.przejscia || [];
        if (lista.length) {
            app.enableQE();
            var qs = qe.project.getActiveSequence(), qt = qs.getVideoTrackAt(0), tr0 = s.videoTracks[0];
            var zapas = { "Push": ["Push", "Wypchnięcie", "Slide"], "Cross Zoom": ["Cross Zoom", "Powiększenie krzyżowe"], "Iris Round": ["Iris Round", "Przesłona okrągła"],
                "Cross Dissolve": ["Cross Dissolve", "Przenikanie krzyżowe"], "Dip to Black": ["Dip to Black", "Przejście przez czerń"], "Dip to White": ["Dip to White", "Przejście przez biel"] };
            for (var i = 0; i < lista.length; i++) {
                var p = lista[i], nazwy = (zapas[p.premiere] || [p.premiere]).concat(["Cross Dissolve"]), tr = null;
                for (var n = 0; n < nazwy.length && !tr; n++) { try { tr = qe.project.getVideoTransitionByName(nazwy[n]); } catch (eT) {} }
                if (!tr) { w.przejscia_brak.push(p.czas_s); continue; }
                var it = null;
                for (var j = 0; j < qt.numItems; j++) {
                    var x = qt.getItemAt(j);
                    try { if (x.type === "Empty") continue; } catch (eE) {}
                    if (Math.abs(nm_qe_czas(x.end) - Number(p.czas_s)) < 0.6 / fps) { it = x; break; }
                }
                if (!it) { w.przejscia_brak.push(p.czas_s); continue; }
                var przed = nm_liczba_przejsc(tr0), tc = nm_tc(s, Math.max(0.12, Number(p.dlugosc_s) || 0.3)), dodane = false;
                var proby = [
                    function () { it.addTransition(tr, false, tc, "00:00:00:00", 0.5, false, true); },
                    function () { it.addTransition(tr, false, tc); },
                    function () { it.addTransition(tr, false); },
                    function () { it.addTransition(tr); }
                ];
                for (var k = 0; k < proby.length && !dodane; k++) {
                    try { proby[k](); } catch (eA) { continue; }
                    var po = nm_liczba_przejsc(tr0);
                    dodane = przed < 0 || po > przed;
                }
                if (dodane) w.przejscia++; else w.przejscia_brak.push(p.czas_s);
            }
        }
        // --- muzyka i efekty: czy Premiere je wczytał ---
        var nazwyAudio = {};
        for (var a = 0; a < s.audioTracks.numTracks; a++) {
            var at = s.audioTracks[a];
            for (var c = 0; c < at.clips.numItems; c++) nazwyAudio[String(at.clips[c].name).toLowerCase()] = true;
        }
        var poloz = function (plik, od, wPliku, dl) {
            var kosz = nm_kosz("Nada – dźwięk"), f = new File(plik);
            if (!f.exists) return "brak pliku";
            app.project.importFiles([plik], true, kosz, false);
            var el = nm_znajdz_element(kosz, f.displayName || String(plik).replace(/^.*[\\\/]/, ""));
            if (!el) return "nie zaimportował";
            var przyciete = dl > 0 ? nm_ustaw_zakres(el, wPliku || 0, (wPliku || 0) + dl) : false;
            var okno = przyciete ? dl : (dl || 1) + 600;
            var cel = -1;
            for (var t = 0; t < s.audioTracks.numTracks && cel < 0; t++) {
                var zajety = false, trA = s.audioTracks[t];
                for (var c2 = 0; c2 < trA.clips.numItems; c2++) { var k2 = trA.clips[c2]; if (nm_sekundy(k2.start) < od + okno - 0.001 && nm_sekundy(k2.end) > od + 0.001) { zajety = true; break; } }
                if (!zajety) cel = t;
            }
            if (cel < 0) { try { app.enableQE(); qe.project.getActiveSequence().addTracks(0, 0, 1, 1, s.audioTracks.numTracks); } catch (eq) {} if (s.audioTracks.numTracks > 0) { var ost = s.audioTracks[s.audioTracks.numTracks - 1]; if (ost.clips.numItems === 0) cel = s.audioTracks.numTracks - 1; } }
            if (cel < 0) return "brak wolnej ścieżki audio";
            var tt = new Time(); tt.seconds = od;
            s.audioTracks[cel].overwriteClip(el, tt);
            return "A" + (cel + 1);
        };
        if (d.muzyka && d.muzyka.plik) {
            var nm = String(d.muzyka.plik).replace(/^.*[\\\/]/, "").toLowerCase();
            if (nazwyAudio[nm]) w.muzyka = "jest";
            else { var r1 = poloz(d.muzyka.plik, Number(d.muzyka.od_s) || 0, Number(d.muzyka.w_pliku_s) || 0, Number(d.muzyka.dlugosc_s) || 0); w.muzyka = /^A\d/.test(r1) ? "dodana na " + r1 : "nie udało się: " + r1; }
        }
        var ef = d.efekty || [], efJest = false;
        for (var e0 = 0; e0 < ef.length; e0++) if (nazwyAudio[String(ef[e0].plik).replace(/^.*[\\\/]/, "").toLowerCase()]) efJest = true;
        if (efJest) ef = []; // Premiere wczytał efekty z XML
        for (var e = 0; e < ef.length; e++) {
            var ne = String(ef[e].plik).replace(/^.*[\\\/]/, "").toLowerCase();
            var r2 = poloz(ef[e].plik, Number(ef[e].od_s) || 0, 0, 0);
            if (/^A\d/.test(r2)) w.efekty_dodane++; else w.uwagi.push(ne + ": " + r2);
        }
        return nm_json(w);
    } catch (e0) { return nm_json({ ok: false, blad: String(e0) }); }
}

/* Pliki (np. pobrane ze stocka) do kosza w projekcie, bez kładzenia na oś. */
function nm_import_do_kosza(pliki, nazwaKosza) {
    try {
        if (!app.project) return nm_json({ ok: false, blad: "Brak otwartego projektu." });
        var kosz = nm_kosz(nazwaKosza || "Nada – stock");
        var ok = app.project.importFiles(pliki, true, kosz, false);
        return nm_json({ ok: ok !== false, kosz: kosz.name });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}

/* ===== Cięcie ciszy i wpadek w samym Premiere =====
   Kopia sekwencji (oryginał bez zmian), żyletka na odblokowanych ścieżkach w granicach wycinanych fragmentów,
   usunięcie kawałków ze środka i dosunięcie reszty. Klipy zostają te same, więc zostają efekty (Lumetri, Transform,
   zoomy z klatkami kluczowymi), ustawienia kanałów audio (np. tylko lewy kanał) i głośności.
   Zablokowane ścieżki (kłódka) zostają nietknięte.
   d = {id, nazwa, ciecia: [[od, do] s oryginału], fps, markery: [{t, do, nazwa, opis}], grupy: [[{typ, tor, start, end}]], zablokowane: ["V1"]} */
function nm_tnij_w_premiere(d) {
    var uwagi = [], etap = "kopia sekwencji", kopia = null, zmieniono = false;
    try {
        if (typeof d === "string") d = eval("(" + d + ")");
        var i, j, k, orig = null;
        for (i = 0; i < app.project.sequences.numSequences; i++) if (app.project.sequences[i].sequenceID === d.id) orig = app.project.sequences[i];
        if (!orig) orig = app.project.activeSequence;
        if (!orig) return nm_json({ ok: false, zmieniono: false, blad: "Nie widzę sekwencji, która była analizowana." });
        var stare = {};
        for (i = 0; i < app.project.sequences.numSequences; i++) stare[app.project.sequences[i].sequenceID] = 1;
        orig.clone();
        for (i = 0; i < app.project.sequences.numSequences; i++) if (!stare[app.project.sequences[i].sequenceID]) kopia = app.project.sequences[i];
        if (!kopia) return nm_json({ ok: false, zmieniono: false, blad: "Premiere nie zrobił kopii sekwencji." });
        try { kopia.name = d.nazwa || (orig.name + " - cięcie"); } catch (eN) {}
        app.project.openSequence(kopia.sequenceID);
        var s = app.project.activeSequence;
        if (!s || s.sequenceID !== kopia.sequenceID) return nm_json({ ok: false, zmieniono: false, blad: "Nie udało się otworzyć kopii sekwencji." });
        app.enableQE();
        var qs = qe.project.getActiveSequence();
        var fps = Number(d.fps) || 25, pol = 0.5 / fps;
        var C = d.ciecia || [];
        C.sort(function (a, b) { return a[0] - b[0]; });
        var przes = function (x) { var w = 0; for (var q = 0; q < C.length; q++) { if (C[q][1] <= x + pol) w += C[q][1] - C[q][0]; else break; } return w; };
        var mapa = function (x) { for (var q = 0; q < C.length; q++) if (x > C[q][0] + pol && x < C[q][1] - pol) return C[q][0] - przes(C[q][0]); return x - przes(x); };
        var zab = {};
        for (i = 0; i < (d.zablokowane || []).length; i++) zab[d.zablokowane[i]] = 1;
        var tory = [];
        var dodajTory = function (lista, typ, lit) {
            for (var t = 0; t < lista.numTracks; t++) {
                var lock = !!zab[lit + (t + 1)];
                try { if (lista[t].isLocked && lista[t].isLocked()) lock = true; } catch (eL) {}
                if (!lock) tory.push({ typ: typ, i: t, kod: lit + (t + 1) });
            }
        };
        dodajTory(s.videoTracks, "video", "V");
        dodajTory(s.audioTracks, "audio", "A");
        var dom = function (t) { return t.typ === "video" ? s.videoTracks[t.i] : s.audioTracks[t.i]; };
        var qet = function (t) { return t.typ === "video" ? qs.getVideoTrackAt(t.i) : qs.getAudioTrackAt(t.i); };
        var naprzeciw = function (tr, x) { for (var q = 0; q < tr.clips.numItems; q++) { var c = tr.clips[q], a = nm_sekundy(c.start), b = nm_sekundy(c.end); if (a < x - pol && b > x + pol) return c; } return null; };
        var zp = 0;
        try { zp = Number(s.zeroPoint) / NM_TICKI || 0; } catch (eZ) {}
        var trybTc = -1; // 0 = czas od początku sekwencji, 1 = z jej czasem startowym (np. 01:00:00:00)
        // 1) żyletka
        etap = "żyletka";
        var granice = [];
        for (i = 0; i < C.length; i++) { granice.push(C[i][0]); granice.push(C[i][1]); }
        var nieciete = 0;
        for (k = 0; k < tory.length; k++) {
            var tr = dom(tory[k]), qt = qet(tory[k]);
            for (j = 0; j < granice.length; j++) {
                var x = granice[j];
                if (!naprzeciw(tr, x)) continue;
                var proby = trybTc >= 0 ? [trybTc] : (zp > 0 ? [0, 1] : [0]);
                for (var p = 0; p < proby.length; p++) {
                    try { qt.razor(nm_tc(s, x + (proby[p] ? zp : 0) + 0.25 / fps)); } catch (eR) {}
                    if (!naprzeciw(tr, x)) { trybTc = proby[p]; zmieniono = true; break; }
                }
                if (naprzeciw(tr, x)) nieciete++;
            }
        }
        if (nieciete) uwagi.push("Żyletka nie przecięła klipu w " + nieciete + " miejscach (np. przejście albo klip, którego Premiere nie tnie): tam zostały pełne klipy.");
        // 2) usunięcie kawałków w wycinanych miejscach
        etap = "usuwanie";
        var usuniete = 0;
        for (k = 0; k < tory.length; k++) {
            var tr2 = dom(tory[k]);
            for (j = tr2.clips.numItems - 1; j >= 0; j--) {
                var c2 = tr2.clips[j]; if (!c2) continue;
                var a2 = nm_sekundy(c2.start), b2 = nm_sekundy(c2.end);
                for (var q2 = 0; q2 < C.length; q2++) {
                    if (a2 >= C[q2][0] - pol && b2 <= C[q2][1] + pol) { try { c2.remove(false, false); usuniete++; zmieniono = true; } catch (eD) { uwagi.push("Nie usunąłem kawałka na " + tory[k].kod + ": " + eD); } break; }
                }
            }
        }
        // 3) dosunięcie: każdy klip raz, od najwcześniejszego (wtedy nic na siebie nie nachodzi)
        etap = "dosuwanie";
        var plan = [];
        for (k = 0; k < tory.length; k++) {
            var tr3 = dom(tory[k]);
            for (j = 0; j < tr3.clips.numItems; j++) {
                var st3 = nm_sekundy(tr3.clips[j].start), sh = przes(st3), id3 = "";
                try { id3 = tr3.clips[j].nodeId || ""; } catch (eId) {}
                if (sh > pol) plan.push({ k: k, start: st3, cel: st3 - sh, sh: sh, id: id3 });
            }
        }
        plan.sort(function (a, b) { return a.start - b.start; });
        var przesuniete = 0, bledy = 0;
        var klipNa = function (tr, x) { for (var q = 0; q < tr.clips.numItems; q++) if (Math.abs(nm_sekundy(tr.clips[q].start) - x) < pol) return tr.clips[q]; return null; };
        var klipId = function (tr, id) { if (!id) return null; for (var q = 0; q < tr.clips.numItems; q++) { try { if (tr.clips[q].nodeId === id) return tr.clips[q]; } catch (eQ) {} } return null; };
        for (i = 0; i < plan.length; i++) {
            var pl = plan[i], tr4 = dom(tory[pl.k]);
            var c4 = klipId(tr4, pl.id);
            if (c4) {
                if (Math.abs(nm_sekundy(c4.start) - pl.cel) < pol) { przesuniete++; continue; } // przesunął się razem z połączonym klipem
                if (Math.abs(nm_sekundy(c4.start) - pl.start) >= pol) { bledy++; continue; }
            } else {
                if (klipNa(tr4, pl.cel) && !klipNa(tr4, pl.start)) { przesuniete++; continue; }
                c4 = klipNa(tr4, pl.start);
            }
            if (!c4) { bledy++; continue; }
            var o = new Time();
            try { o.ticks = String(-Math.round(pl.sh * NM_TICKI)); } catch (eT) { o.seconds = -pl.sh; }
            try { c4.move(o); zmieniono = true; } catch (eM) { bledy++; continue; }
            if (Math.abs(nm_sekundy(c4.start) - pl.cel) < pol || klipNa(tr4, pl.cel)) przesuniete++; else bledy++;
        }
        if (bledy) uwagi.push("Nie przesunąłem " + bledy + " klipów: sprawdź oś w miejscach cięć.");
        // 4) markery: stare przesunięte razem z cięciami, nowe przy wpadkach
        etap = "markery";
        try {
            var ms = [], m = s.markers.getFirstMarker();
            while (m) { ms.push(m); m = s.markers.getNextMarker(m); }
            for (i = 0; i < ms.length; i++) {
                var t0 = nm_sekundy(ms[i].start), t1 = nm_sekundy(ms[i].end);
                var n0 = mapa(t0);
                if (Math.abs(n0 - t0) > pol) {
                    var tn = new Time(); tn.seconds = n0;
                    var te = new Time(); te.seconds = Math.max(n0, mapa(t1));
                    try { ms[i].start = tn; ms[i].end = te; } catch (eMs) {}
                }
            }
            for (i = 0; i < (d.markery || []).length; i++) {
                var mk = d.markery[i], nm = s.markers.createMarker(Number(mk.t));
                try { nm.name = mk.nazwa || ""; nm.comments = mk.opis || ""; if (mk["do"] && mk["do"] > mk.t) { var tk = new Time(); tk.seconds = Number(mk["do"]); nm.end = tk; } } catch (eMk) {}
            }
        } catch (eM2) { uwagi.push("Markery: " + eM2); }
        // 5) obraz z dźwiękiem znowu połączony (żyletka w Premiere rozłącza klipy)
        etap = "łączenie";
        var polaczone = 0;
        try {
            var odznacz = function () { var lists = [s.videoTracks, s.audioTracks]; for (var l = 0; l < 2; l++) for (var t = 0; t < lists[l].numTracks; t++) for (var q = 0; q < lists[l][t].clips.numItems; q++) { try { if (lists[l][t].clips[q].isSelected()) lists[l][t].clips[q].setSelected(false, false); } catch (eS) {} } };
            var tor = function (g) { return g.typ === "video" ? s.videoTracks[g.tor - 1] : s.audioTracks[g.tor - 1]; };
            var grupy = d.grupy || [];
            for (i = 0; i < grupy.length; i++) {
                var g = grupy[i], g0 = g[0], trg = tor(g0);
                if (!trg) continue;
                var od0 = mapa(g0.start) - pol, do0 = mapa(g0.end) + pol;
                for (j = 0; j < trg.clips.numItems; j++) {
                    var cg = trg.clips[j], sa = nm_sekundy(cg.start), sb = nm_sekundy(cg.end);
                    if (sa < od0 || sb > do0) continue;
                    var para = [cg];
                    for (k = 1; k < g.length; k++) {
                        var trk = tor(g[k]); if (!trk) continue;
                        for (var q3 = 0; q3 < trk.clips.numItems; q3++) { var ck = trk.clips[q3]; if (Math.abs(nm_sekundy(ck.start) - sa) < pol && Math.abs(nm_sekundy(ck.end) - sb) < pol) { para.push(ck); break; } }
                    }
                    if (para.length < 2) continue;
                    odznacz();
                    for (k = 0; k < para.length; k++) para[k].setSelected(true, false);
                    s.linkSelection();
                    polaczone++;
                }
            }
            odznacz();
        } catch (eLk) { uwagi.push("Obraz i dźwięk po cięciu nie są połączone w pary (Premiere nie pozwolił): przesuwaj je razem albo połącz ręcznie (Ctrl+L)."); }
        return nm_json({ ok: true, nazwa: s.name, id: s.sequenceID, usuniete: usuniete, przesuniete: przesuniete, polaczone: polaczone, uwagi: uwagi,
            tory: tory.length, koniec_s: Number(s.end) / NM_TICKI });
    } catch (e) {
        if (kopia && zmieniono) { try { kopia.name = kopia.name + " (NIEDOKOŃCZONE)"; } catch (eN2) {} }
        return nm_json({ ok: false, zmieniono: zmieniono, blad: "Cięcie w Premiere (" + etap + "): " + e, uwagi: uwagi });
    }
}

/* ===== Dźwięk z osi dokładnie tak, jak gra w Premiere =====
   (wybór kanałów, Fill Left, głośność klipów i ścieżek, efekty audio, zagnieżdżone sekwencje).
   Eksport przez Premiere presetem WAV: d = {id, plik, preset, solo: numer ścieżki A (od 1) albo 0 = cały miks jak słychać}.
   Przy solo pozostałe ścieżki są na chwilę wyciszane, potem wszystko wraca do stanu sprzed eksportu. */
function nm_folder_premiere() {
    try { return nm_json({ ok: true, sciezka: String(app.path || "") }); } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}
function nm_eksport_audio(d) {
    var s = null, stan = [], i;
    try {
        if (typeof d === "string") d = eval("(" + d + ")");
        for (i = 0; i < app.project.sequences.numSequences; i++) if (app.project.sequences[i].sequenceID === d.id) s = app.project.sequences[i];
        if (!s) s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Nie widzę sekwencji." });
        var at = s.audioTracks;
        for (i = 0; i < at.numTracks; i++) { var m = 0; try { m = at[i].isMuted() ? 1 : 0; } catch (eM) {} stan.push(m); }
        var solo = Number(d.solo) || 0;
        if (solo) {
            if (solo > at.numTracks) return nm_json({ ok: false, blad: "Nie ma ścieżki A" + solo + "." });
            for (i = 0; i < at.numTracks; i++) { try { at[i].setMute(i === solo - 1 ? 0 : 1); } catch (eS) {} }
        }
        var f = new File(d.plik); if (f.exists) f.remove();
        var w = s.exportAsMediaDirect(d.plik, d.preset, 0);
        var wynik = new File(d.plik).exists;
        if (!wynik) {
            var alt = new File(String(d.plik).replace(/\.wav$/i, "") + ".wav");
            wynik = alt.exists;
        }
        return nm_json({ ok: !!wynik, plik: d.plik, odp: String(w), blad: wynik ? "" : "Premiere nie zapisał dźwięku (" + w + ")." });
    } catch (e) {
        return nm_json({ ok: false, blad: String(e) });
    } finally {
        try { if (s && stan.length) for (i = 0; i < stan.length; i++) s.audioTracks[i].setMute(stan[i]); } catch (eR) {}
    }
}

/* ===== Praca na KOPII sekwencji (asystent audio, multicam, poprawa dźwięku) =====
   Zasada: oryginalna sekwencja zostaje nietknięta. Każde narzędzie, które coś zmienia na osi, robi kopię
   (Premiere „Duplikuj”), otwiera ją i tylko w niej tnie, wyłącza, wstawia i wycisza.
   Po każdym kroku sprawdzamy, czy w kopii nie ubyło klipów; jeśli tak, przerywamy i kopia dostaje „(NIEDOKOŃCZONE)”. */
function nm_liczba_klipow(s) {
    var o = { v: [], a: [] }, i;
    for (i = 0; i < s.videoTracks.numTracks; i++) o.v.push(s.videoTracks[i].clips.numItems);
    for (i = 0; i < s.audioTracks.numTracks; i++) o.a.push(s.audioTracks[i].clips.numItems);
    return o;
}
function nm_ubylo(przed, po) {
    var b = [], i;
    for (i = 0; i < przed.v.length; i++) if ((po.v[i] || 0) < przed.v[i]) b.push("V" + (i + 1));
    for (i = 0; i < przed.a.length; i++) if ((po.a[i] || 0) < przed.a[i]) b.push("A" + (i + 1));
    return b;
}
function nm_element_z_pliku(kosz, sciezka) {
    var cel = String(new File(sciezka).fsName).toLowerCase(), i;
    for (i = kosz.children.numItems - 1; i >= 0; i--) {
        var c = kosz.children[i], m = "";
        try { m = String(new File(c.getMediaPath()).fsName).toLowerCase(); } catch (e) {}
        if (m && m === cel) return c;
    }
    return null;
}
/* Robi kopię sekwencji o id i ją otwiera. Zwraca {orig, kopia, s}; rzuca błąd z opisem (oryginał nietknięty). */
function nm_zrob_kopie(id, nazwa) {
    var i, orig = null, kopia = null;
    for (i = 0; i < app.project.sequences.numSequences; i++) if (app.project.sequences[i].sequenceID === id) orig = app.project.sequences[i];
    if (!orig) throw new Error("nie widzę sekwencji, która była analizowana");
    var stare = {};
    for (i = 0; i < app.project.sequences.numSequences; i++) stare[app.project.sequences[i].sequenceID] = 1;
    orig.clone();
    for (i = 0; i < app.project.sequences.numSequences; i++) if (!stare[app.project.sequences[i].sequenceID]) kopia = app.project.sequences[i];
    if (!kopia) throw new Error("Premiere nie zrobił kopii sekwencji");
    try { kopia.name = nazwa || (orig.name + " - Nada"); } catch (eN) {}
    app.project.openSequence(kopia.sequenceID);
    var s = app.project.activeSequence;
    if (!s || s.sequenceID !== kopia.sequenceID) throw new Error("nie udało się otworzyć kopii sekwencji");
    return { orig: orig, kopia: kopia, s: s };
}
/* Pusta ścieżka audio na końcu kopii (wewnętrzna funkcja Premiere QE, tylko gdy QE na pewno widzi kopię). */
function nm_nowa_sciezka_audio(s) {
    app.enableQE();
    var qs = qe.project.getActiveSequence();
    if (!qs || String(qs.name) !== String(s.name)) throw new Error("Premiere nie przełączył się na kopię, więc nie dodaję ścieżki");
    var ile = s.audioTracks.numTracks;
    qs.addTracks(0, 0, 1, 1, ile, 0, 0);
    if (s.audioTracks.numTracks !== ile + 1 || s.audioTracks[ile].clips.numItems !== 0) throw new Error("nie udało się dodać pustej ścieżki audio");
    return ile;
}
/* Pierwsza ścieżka audio, na której wszystkie przedziały [[od, do]] są wolne (pomija ścieżki z listy pomin). */
function nm_wolna_sciezka_audio(s, zakresy, pomin) {
    for (var i = 0; i < s.audioTracks.numTracks; i++) {
        if (pomin && pomin[i]) continue;
        var tr = s.audioTracks[i], wolna = true;
        try { if (tr.isLocked && tr.isLocked()) continue; } catch (eL) {}
        for (var k = 0; k < zakresy.length && wolna; k++) if (nm_tor_zajety(tr, zakresy[k][0], zakresy[k][1])) wolna = false;
        if (wolna) return i;
    }
    return -1;
}
/* Odłącza obraz od dźwięku dla podanych klipów (tylko w kopii), żeby wyłączenie jednego nie wyłączało drugiego. */
function nm_odlacz(s, klipy) {
    if (!klipy.length) return 0;
    var lists = [s.videoTracks, s.audioTracks], l, t, q;
    var odznacz = function () { for (l = 0; l < 2; l++) for (t = 0; t < lists[l].numTracks; t++) for (q = 0; q < lists[l][t].clips.numItems; q++) { try { if (lists[l][t].clips[q].isSelected()) lists[l][t].clips[q].setSelected(false, false); } catch (e) {} } };
    try {
        odznacz();
        for (q = 0; q < klipy.length; q++) { try { klipy[q].setSelected(true, false); } catch (e1) {} }
        s.unlinkSelection();
        odznacz();
        return klipy.length;
    } catch (e2) { try { odznacz(); } catch (e3) {} return 0; }
}
function nm_niedokonczone(kopia) { try { if (kopia) kopia.name = String(kopia.name) + " (NIEDOKOŃCZONE)"; } catch (e) {} }

/* Miks z asystenta audio. d = {id, nazwa, pliki: [WAV], wycisz: [numery A od 1]} */
function nm_miks_w_kopii(d) {
    var k0 = null, etap = "kopia sekwencji";
    try {
        if (typeof d === "string") d = eval("(" + d + ")");
        k0 = nm_zrob_kopie(d.id, d.nazwa);
        var s = k0.s, przed = nm_liczba_klipow(s), wstawione = [], i, k;
        etap = "import plików";
        var kosz = nm_kosz();
        app.project.importFiles(d.pliki, true, kosz, false);
        for (k = 0; k < d.pliki.length; k++) {
            etap = "wstawianie " + (k + 1);
            var el = nm_element_z_pliku(kosz, d.pliki[k]);
            if (!el) throw new Error("zaimportowano, ale nie widzę pliku w koszu Studio Nadamedia: " + d.pliki[k]);
            var cel = -1;
            for (i = 0; i < s.audioTracks.numTracks; i++) if (s.audioTracks[i].clips.numItems === 0) { cel = i; break; }
            if (cel < 0) { cel = nm_nowa_sciezka_audio(s); przed.a.push(0); }
            var t = new Time(); t.seconds = 0;
            s.audioTracks[cel].overwriteClip(el, t);
            var po = nm_liczba_klipow(s), ub = nm_ubylo(przed, po);
            if (ub.length) throw new Error("po wstawieniu ubyło klipów na " + ub.join(", ") + " (to tylko kopia)");
            przed = po;
            wstawione.push("A" + (cel + 1));
        }
        etap = "wyciszanie";
        var lista = d.wycisz || [];
        for (k = 0; k < lista.length; k++) { try { s.audioTracks[lista[k] - 1].setMute(1); } catch (em) {} }
        return nm_json({ ok: true, sekwencja: String(k0.kopia.name), oryginal: String(k0.orig.name), sciezki: wstawione });
    } catch (e) {
        if (k0) nm_niedokonczone(k0.kopia);
        return nm_json({ ok: false, blad: "Wstawianie miksu do kopii sekwencji (" + etap + "): " + e + ". Twoja oryginalna sekwencja jest nietknięta." });
    }
}

/* Multicam w samym Premiere: kopia sekwencji, ścieżki kamer przecięte żyletką w miejscach przełączeń,
   nieaktywne kawałki WYŁĄCZONE (albo usunięte przy d.usun), więc kadrowanie, LUT-y, Lumetri i inne efekty zostają.
   d = {id, nazwa, fps, punkty: [s], kamery: {"2": [[od, do], ...]}, wszystkie_kamery: [2, 3], usun, mikrofony: [1, 2], czyste: [WAV]} */
function nm_multicam_w_premiere(d) {
    var k0 = null, etap = "kopia sekwencji", uwagi = [];
    try {
        if (typeof d === "string") d = eval("(" + d + ")");
        k0 = nm_zrob_kopie(d.id, d.nazwa);
        var s = k0.s, i, j, k;
        app.enableQE();
        var qs = qe.project.getActiveSequence();
        if (!qs || String(qs.name) !== String(s.name)) throw new Error("Premiere nie przełączył się na kopię");
        var fps = Number(d.fps) || 25, pol = 0.5 / fps;
        var zp = 0;
        try { zp = Number(s.zeroPoint) / NM_TICKI || 0; } catch (eZ) {}
        var naprzeciw = function (tr, x) { for (var q = 0; q < tr.clips.numItems; q++) { var c = tr.clips[q], a = nm_sekundy(c.start), b = nm_sekundy(c.end); if (a < x - pol && b > x + pol) return c; } return null; };
        var trybTc = -1, nieciete = 0, wylaczone = 0, usuniete = 0;
        var kamery = d.wszystkie_kamery || [];
        // 0) obraz kamer odłączony od dźwięku (w kopii): przełączanie obrazu nie może wyłączać ani ciąć dźwięku z kamery
        etap = "odłączanie obrazu od dźwięku";
        var doOdl = [];
        for (k = 0; k < kamery.length; k++) { var tk = s.videoTracks[Number(kamery[k]) - 1]; if (tk) for (j = 0; j < tk.clips.numItems; j++) doOdl.push(tk.clips[j]); }
        nm_odlacz(s, doOdl);
        var stanA = [];
        for (i = 0; i < s.audioTracks.numTracks; i++) for (j = 0; j < s.audioTracks[i].clips.numItems; j++) { var ca0 = s.audioTracks[i].clips[j]; stanA.push([ca0, !!ca0.disabled]); }
        // 1) żyletka tylko na ścieżkach kamer
        etap = "żyletka";
        for (k = 0; k < kamery.length; k++) {
            var nr = Number(kamery[k]), tr = s.videoTracks[nr - 1];
            if (!tr) { uwagi.push("Nie ma ścieżki V" + nr + "."); continue; }
            try { if (tr.isLocked && tr.isLocked()) { uwagi.push("V" + nr + " jest zablokowana (kłódka): zostawiam ją bez zmian."); continue; } } catch (eL) {}
            var qt = qs.getVideoTrackAt(nr - 1);
            for (j = 0; j < (d.punkty || []).length; j++) {
                var x = Number(d.punkty[j]);
                if (!naprzeciw(tr, x)) continue;
                var proby = trybTc >= 0 ? [trybTc] : (zp > 0 ? [0, 1] : [0]);
                for (var p = 0; p < proby.length; p++) {
                    try { qt.razor(nm_tc(s, x + (proby[p] ? zp : 0) + 0.25 / fps)); } catch (eR) {}
                    if (!naprzeciw(tr, x)) { trybTc = proby[p]; break; }
                }
                if (naprzeciw(tr, x)) nieciete++;
            }
        }
        if (nieciete) uwagi.push("Żyletka nie przecięła klipu w " + nieciete + " miejscach: tam zostały pełne klipy.");
        // 2) nieaktywne kawałki: wyłączone albo usunięte
        etap = "wyłączanie ujęć";
        for (k = 0; k < kamery.length; k++) {
            var nr2 = Number(kamery[k]), tr2 = s.videoTracks[nr2 - 1];
            if (!tr2) continue;
            try { if (tr2.isLocked && tr2.isLocked()) continue; } catch (eL2) {}
            var akt = (d.kamery || {})[String(nr2)] || [];
            for (j = tr2.clips.numItems - 1; j >= 0; j--) {
                var c = tr2.clips[j], sr = (nm_sekundy(c.start) + nm_sekundy(c.end)) / 2, aktywny = false;
                for (var q = 0; q < akt.length; q++) if (sr >= akt[q][0] && sr < akt[q][1]) { aktywny = true; break; }
                if (aktywny) continue;
                if (d.usun) { try { c.remove(false, false); usuniete++; } catch (eD) { uwagi.push("Nie usunąłem kawałka na V" + nr2 + ": " + eD); } }
                else { try { c.disabled = true; wylaczone++; } catch (eW) { uwagi.push("Premiere nie pozwolił wyłączyć klipu na V" + nr2 + ": " + eW); } }
            }
        }
        // dźwięk zostaje taki, jaki był (gdyby Premiere mimo odłączenia wyłączył też dźwięk z kamery, włączamy go z powrotem)
        var przywrocone = 0;
        for (i = 0; i < stanA.length; i++) { try { if (!!stanA[i][0].disabled !== stanA[i][1]) { stanA[i][0].disabled = stanA[i][1]; przywrocone++; } } catch (eP) {} }
        if (przywrocone) uwagi.push("Dźwięk " + przywrocone + " klipów wyłączył się razem z obrazem: włączyłem go z powrotem.");
        // 3) czysty dźwięk mikrofonów (gdy był): oryginalne klipy mikrofonów wyłączone, czyste pliki na nowych ścieżkach
        var gdzie = [];
        if (d.czyste && d.czyste.length) {
            etap = "czysty dźwięk";
            var mik = d.mikrofony || [], mikKlipy = [], stanW = [];
            for (k = 0; k < mik.length; k++) { var ta = s.audioTracks[Number(mik[k]) - 1]; if (ta) for (j = 0; j < ta.clips.numItems; j++) mikKlipy.push(ta.clips[j]); }
            for (i = 0; i < s.videoTracks.numTracks; i++) for (j = 0; j < s.videoTracks[i].clips.numItems; j++) { var cw = s.videoTracks[i].clips[j]; stanW.push([cw, !!cw.disabled]); }
            nm_odlacz(s, mikKlipy); // wyłączenie mikrofonu nie może wyłączyć obrazu kamery
            for (k = 0; k < mikKlipy.length; k++) { try { mikKlipy[k].disabled = true; } catch (eA) {} }
            for (i = 0; i < stanW.length; i++) { try { if (!!stanW[i][0].disabled !== stanW[i][1]) stanW[i][0].disabled = stanW[i][1]; } catch (eW2) {} }
            var przed = nm_liczba_klipow(s), kosz = nm_kosz();
            app.project.importFiles(d.czyste, true, kosz, false);
            for (k = 0; k < d.czyste.length; k++) {
                var el = nm_element_z_pliku(kosz, d.czyste[k]);
                if (!el) { uwagi.push("Nie widzę w koszu pliku " + d.czyste[k]); continue; }
                var cel = -1;
                for (i = 0; i < s.audioTracks.numTracks; i++) if (s.audioTracks[i].clips.numItems === 0) { cel = i; break; }
                if (cel < 0) { cel = nm_nowa_sciezka_audio(s); przed.a.push(0); }
                var t0 = new Time(); t0.seconds = 0;
                s.audioTracks[cel].overwriteClip(el, t0);
                var po = nm_liczba_klipow(s), ub = nm_ubylo(przed, po);
                if (ub.length) throw new Error("po wstawieniu dźwięku ubyło klipów na " + ub.join(", "));
                przed = po; gdzie.push("A" + (cel + 1));
            }
        }
        return nm_json({ ok: true, sekwencja: String(k0.kopia.name), oryginal: String(k0.orig.name), id: k0.kopia.sequenceID,
            wylaczone: wylaczone, usuniete: usuniete, czyste_na: gdzie, uwagi: uwagi });
    } catch (e) {
        if (k0) nm_niedokonczone(k0.kopia);
        return nm_json({ ok: false, blad: "Multicam w Premiere (" + etap + "): " + e + ". Twoja oryginalna sekwencja jest nietknięta.", uwagi: uwagi });
    }
}

/* Poprawa dźwięku zaznaczonych klipów: w kopii sekwencji oryginalne klipy audio są wyłączone,
   a czyste wersje (z dźwięku osi) leżą dokładnie w tym samym miejscu na wolnej ścieżce audio.
   d = {id, nazwa, klipy: [{tor: numer A od 1, start, end, plik}]} */
function nm_dzwiek_w_kopii(d) {
    var k0 = null, etap = "kopia sekwencji", uwagi = [];
    try {
        if (typeof d === "string") d = eval("(" + d + ")");
        k0 = nm_zrob_kopie(d.id, d.nazwa);
        var s = k0.s, i, j, k, pol = 0.02;
        // obraz zostaje taki, jaki był (gdyby wyłączenie dźwięku pociągnęło połączony obraz, włączamy go z powrotem)
        var stanV = [];
        for (i = 0; i < s.videoTracks.numTracks; i++) for (j = 0; j < s.videoTracks[i].clips.numItems; j++) { var cv = s.videoTracks[i].clips[j]; stanV.push([cv, !!cv.disabled]); }
        etap = "wyłączanie oryginałów";
        var tory = {}, zakresy = [], cele = [];
        for (k = 0; k < d.klipy.length; k++) {
            var x = d.klipy[k], tr = s.audioTracks[Number(x.tor) - 1], znal = null;
            zakresy.push([Number(x.start), Number(x.end)]);
            tory[Number(x.tor) - 1] = 1;
            if (!tr) { uwagi.push("Nie ma ścieżki A" + x.tor + "."); continue; }
            for (j = 0; j < tr.clips.numItems; j++) {
                var c = tr.clips[j];
                if (Math.abs(nm_sekundy(c.start) - x.start) < pol && Math.abs(nm_sekundy(c.end) - x.end) < pol) { znal = c; break; }
            }
            if (znal) cele.push(znal); else uwagi.push("Nie znalazłem w kopii klipu na A" + x.tor + " w " + Math.round(x.start * 10) / 10 + " s.");
        }
        nm_odlacz(s, cele); // w kopii: wyłączenie dźwięku nie może wyłączyć obrazu
        for (k = 0; k < cele.length; k++) { try { cele[k].disabled = true; } catch (eW) { uwagi.push("Nie wyłączyłem oryginalnego dźwięku: " + eW); } }
        var zmienione = 0;
        for (i = 0; i < stanV.length; i++) { try { if (!!stanV[i][0].disabled !== stanV[i][1]) { stanV[i][0].disabled = stanV[i][1]; zmienione++; } } catch (eV) {} }
        if (zmienione) {
            var nadal = 0;
            for (k = 0; k < cele.length; k++) { try { if (!cele[k].disabled) nadal++; } catch (eC) {} }
            if (nadal) uwagi.push("Premiere wyłącza obraz razem z dźwiękiem, więc oryginalny dźwięk " + nadal + " klipów zostawiłem włączony: wycisz go ręcznie (zaznacz dźwięk, Alt+klik, Shift+E).");
        }
        etap = "wstawianie";
        var cel = nm_wolna_sciezka_audio(s, zakresy, tory);
        var przed = nm_liczba_klipow(s);
        if (cel < 0) { cel = nm_nowa_sciezka_audio(s); przed.a.push(0); }
        var kosz = nm_kosz(), pliki = [];
        for (k = 0; k < d.klipy.length; k++) pliki.push(d.klipy[k].plik);
        app.project.importFiles(pliki, true, kosz, false);
        var wstawione = 0;
        for (k = 0; k < d.klipy.length; k++) {
            var el = nm_element_z_pliku(kosz, d.klipy[k].plik);
            if (!el) { uwagi.push("Nie widzę w koszu pliku " + d.klipy[k].plik); continue; }
            var t = new Time(); t.seconds = Number(d.klipy[k].start);
            s.audioTracks[cel].overwriteClip(el, t);
            var po = nm_liczba_klipow(s), ub = nm_ubylo(przed, po);
            if (ub.length) throw new Error("po wstawieniu ubyło klipów na " + ub.join(", "));
            przed = po; wstawione++;
        }
        return nm_json({ ok: true, sekwencja: String(k0.kopia.name), oryginal: String(k0.orig.name), sciezka: "A" + (cel + 1), wstawione: wstawione, uwagi: uwagi });
    } catch (e) {
        if (k0) nm_niedokonczone(k0.kopia);
        return nm_json({ ok: false, blad: "Poprawa dźwięku w kopii sekwencji (" + etap + "): " + e + ". Twoja oryginalna sekwencja jest nietknięta.", uwagi: uwagi });
    }
}

/* Klatki z osi tak, jak wyglądają w Premiere (kadrowanie, LUT-y, Lumetri klipu), do pomiaru koloru.
   Działa tylko na kopii sekwencji (nazwa musi się zgadzać z d.sekwencja). Panel woła to po kolei dla każdej ścieżki:
   pozostałe ścieżki wideo są ukryte, dopóki klatki się nie zapiszą; nm_klatki_osi_koniec przywraca widoczność.
   d = {sekwencja, tor (0 = V1), lista: [{t: sekundy, plik: .png}]} */
var NM_KL_STAN = null;
function nm_klatki_osi(d) {
    try {
        if (typeof d === "string") d = eval("(" + d + ")");
        var s = app.project.activeSequence, i;
        if (!s || String(s.name) !== String(d.sekwencja)) return nm_json({ ok: false, blad: "Otwarta jest inna sekwencja niż kopia do koloru." });
        app.enableQE();
        var qs = qe.project.getActiveSequence();
        if (!qs || String(qs.name) !== String(s.name)) return nm_json({ ok: false, blad: "Premiere nie przełączył się na kopię." });
        var vt = s.videoTracks;
        if (!NM_KL_STAN || NM_KL_STAN.id !== s.sequenceID) {
            NM_KL_STAN = { id: s.sequenceID, m: [] };
            for (i = 0; i < vt.numTracks; i++) { var m = 0; try { m = vt[i].isMuted() ? 1 : 0; } catch (eM) {} NM_KL_STAN.m.push(m); }
        }
        for (i = 0; i < vt.numTracks; i++) { try { vt[i].setMute(i === Number(d.tor) ? 0 : 1); } catch (eS) {} }
        var zp = 0;
        try { zp = Number(s.zeroPoint) / NM_TICKI || 0; } catch (eZ) {}
        var zlecone = 0;
        for (var k = 0; k < d.lista.length; k++) {
            try { qs.exportFramePNG(nm_tc(s, Number(d.lista[k].t) + zp), d.lista[k].plik); zlecone++; } catch (eE) {}
        }
        return nm_json({ ok: true, zlecone: zlecone });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}
function nm_klatki_osi_koniec() {
    try {
        var s = app.project.activeSequence;
        if (s && NM_KL_STAN && NM_KL_STAN.id === s.sequenceID) for (var i = 0; i < NM_KL_STAN.m.length; i++) { try { s.videoTracks[i].setMute(NM_KL_STAN.m[i]); } catch (e1) {} }
        NM_KL_STAN = null;
        return nm_json({ ok: true });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}

/* Poprawa dźwięku na osi: czyste pliki (dokładnie długości klipów) na wolnej ścieżce audio w tych samych miejscach,
   oryginalne ścieżki dźwięku tylko wyciszone (M). Nic nie jest wyłączane ani usuwane; nie powstaje nowa sekwencja.
   d = {id, klipy: [{tor: numer A od 1, start, end, plik}]} */
function nm_dzwiek_na_osi(d) {
    try {
        if (typeof d === "string") d = eval("(" + d + ")");
        var s = app.project.activeSequence, i, k;
        if (!s) return nm_json({ ok: false, blad: "Otwórz sekwencję." });
        if (d.id && s.sequenceID !== d.id) return nm_json({ ok: false, blad: "Otwarta jest inna sekwencja niż ta, z której były klipy: otwórz ją i kliknij jeszcze raz." });
        var zakresy = [], tory = {};
        for (k = 0; k < d.klipy.length; k++) { zakresy.push([Number(d.klipy[k].start), Number(d.klipy[k].end)]); tory[Number(d.klipy[k].tor) - 1] = 1; }
        var cel = nm_wolna_sciezka_audio(s, zakresy, tory);
        if (cel < 0) return nm_json({ ok: false, brak_sciezki: true, blad: "Nie ma wolnej ścieżki audio w miejscach tych klipów. Dodaj jedną pustą ścieżkę audio (prawy klik na nagłówku ścieżek > Dodaj ścieżkę) i kliknij jeszcze raz." });
        var przed = nm_liczba_klipow(s), kosz = nm_kosz("Nada – czysty dźwięk"), pliki = [];
        for (k = 0; k < d.klipy.length; k++) pliki.push(d.klipy[k].plik);
        app.project.importFiles(pliki, true, kosz, false);
        var wstawione = 0, uwagi = [];
        for (k = 0; k < d.klipy.length; k++) {
            var el = nm_element_z_pliku(kosz, d.klipy[k].plik);
            if (!el) { uwagi.push("Nie widzę w koszu pliku " + d.klipy[k].plik); continue; }
            var t = new Time(); t.seconds = Number(d.klipy[k].start);
            s.audioTracks[cel].overwriteClip(el, t);
            var po = nm_liczba_klipow(s), ub = nm_ubylo(przed, po);
            if (ub.length) return nm_json({ ok: false, blad: "Po wstawieniu ubyło klipów na " + ub.join(", ") + ": cofnij Ctrl+Z.", wstawione: wstawione });
            przed = po; wstawione++;
        }
        var wyc = [];
        for (var tr in tory) if (tory.hasOwnProperty(tr)) { try { s.audioTracks[Number(tr)].setMute(1); wyc.push("A" + (Number(tr) + 1)); } catch (eM) {} }
        return nm_json({ ok: true, sciezka: "A" + (cel + 1), wstawione: wstawione, wyciszone: wyc, uwagi: uwagi });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}

/* ===== Gotowy projekt Premiere (.prproj) z rolki zrobionej przez silnik =====
   d = plik *_dodatki.json (wersja 3): xml, nazwa, fps, wideo[], audio[], ruch[], przejscia[], srt, prproj.
   Tworzy nowy projekt w podanym miejscu, importuje sekwencję z XML, dokłada wszystko, czego Premiere nie wczytał z XML
   (zwykle dźwięk, muzyka, efekty), kładzie przejścia, ruch kamery na zdjęciach i napisy, ustawia głośności i zapisuje projekt.
   Projekt użytkownika, który był otwarty, zostaje otwarty i nietknięty. */
function nm_nazwa_pliku(p) { return String(p).replace(/^.*[\\\/]/, ""); }
function nm_komponent(ti, nazwy) {
    try {
        for (var i = 0; i < ti.components.numItems; i++) {
            var c = ti.components[i], dn = String(c.displayName || ""), mn = String(c.matchName || "");
            for (var j = 0; j < nazwy.length; j++) if (dn === nazwy[j] || mn === nazwy[j]) return c;
        }
    } catch (e) {}
    return null;
}
function nm_wlasciwosc(komp, nazwy, indeks) {
    if (!komp) return null;
    try {
        for (var i = 0; i < komp.properties.numItems; i++) {
            var p = komp.properties[i], dn = String(p.displayName || "");
            for (var j = 0; j < nazwy.length; j++) if (dn === nazwy[j]) return p;
        }
        if (indeks !== undefined && indeks < komp.properties.numItems) return komp.properties[indeks];
    } catch (e) {}
    return null;
}
function nm_klip_w_torze(tr, nazwa, od, tol) {
    try {
        for (var i = 0; i < tr.clips.numItems; i++) {
            var c = tr.clips[i];
            if (String(c.name) === nazwa && Math.abs(nm_sekundy(c.start) - od) < tol) return c;
        }
    } catch (e) {}
    return null;
}
function nm_ustaw_glosnosc(ti, g) {
    // poziom w Premiere: wartość = wzmocnienie × 10^(-15/20) (0 dB = 0,1778)
    if (!ti || !(g > 0) || Math.abs(g - 1) < 0.01) return true;
    var p = nm_wlasciwosc(nm_komponent(ti, ["Volume", "Głośność", "Glosnosc", "ADBE Volume"]), ["Level", "Poziom"], 1);
    if (!p) return false;
    try { p.setValue(g * 0.17782794, true); return true; } catch (e) { return false; }
}
function nm_ustaw_skale(ti, skala) {
    if (!ti || !(skala > 0) || Math.abs(skala - 100) < 0.01) return true;
    var p = nm_wlasciwosc(nm_komponent(ti, NM_MOTION), ["Scale", "Skala"], 1);
    if (!p) return false;
    try { p.setValue(skala, true); return true; } catch (e) { return false; }
}
/* Kadr oryginalnego nagrania z montażu: Scale i Position (Position jako ułamek ekranu, 0.5 = środek).
   Zwraca "" gdy kadr stoi (sprawdzone odczytem z Premiere), inaczej powód po polsku. */
var NM_MOTION = ["Motion", "Ruch", "AE.ADBE Motion", "ADBE Motion"];
function nm_motion_parametry(ti) {
    var m = nm_komponent(ti, NM_MOTION);
    if (!m) return null;
    return { m: m, s: nm_wlasciwosc(m, ["Scale", "Skala"], 1), p: nm_wlasciwosc(m, ["Position", "Pozycja", "Położenie"], 0) };
}
function nm_ustaw_kadr(ti, skala, poz) {
    if (!ti) return "nie znalazłem klipu na osi";
    var mp = nm_motion_parametry(ti);
    if (!mp) {
        var n = [];
        try { for (var i = 0; i < ti.components.numItems; i++) n.push(ti.components[i].displayName + "/" + ti.components[i].matchName); } catch (e) {}
        return "klip nie ma efektu Motion (efekty: " + (n.join(", ") || "brak") + ")";
    }
    if (!mp.s) return "brak parametru Scale w Motion";
    // klip z ruchem kamery (klatki kluczowe skali z kroku 7) ma już kadr w kluczach
    try { if (mp.s.isTimeVarying && mp.s.isTimeVarying()) return ""; } catch (eT) {}
    var sk = Number(skala) > 0 ? Number(skala) : 100, x = poz && poz.length > 1 ? Number(poz[0]) : null, y = poz && poz.length > 1 ? Number(poz[1]) : null;
    for (var proba = 0; proba < 2; proba++) {
        try { mp.s.setValue(sk, true); } catch (e1) { return "Premiere odrzucił skalę: " + e1; }
        if (x !== null && mp.p) { try { mp.p.setValue([x, y], true); } catch (e2) { return "Premiere odrzucił pozycję: " + e2; } }
        var vs = NaN, vp = null;
        try { vs = Number(mp.s.getValue()); } catch (e3) {}
        try { vp = mp.p ? mp.p.getValue() : null; } catch (e4) {}
        var okS = !(Math.abs(vs - sk) > 0.05), okP = x === null || !vp || (Math.abs(Number(vp[0]) - x) < 0.002 && Math.abs(Number(vp[1]) - y) < 0.002);
        if (okS && okP) return "";
        // drugi raz na świeżo pobranym efekcie (czasem pierwszy odczyt po imporcie XML jest nieaktualny)
        mp = nm_motion_parametry(ti) || mp;
        if (proba === 1) return "Premiere nie przyjął wartości (jest skala " + vs + ", pozycja " + (vp ? vp[0] + ";" + vp[1] : "?") + ")";
    }
    return "";
}
/* efekt Mastering na klipie dźwięku (QE dokłada efekt, DOM ustawia parametry presetu); zwraca "" albo powód */
function nm_mastering_klipu(s, nrToru, od, nazwa, preset, tol) {
    var nazwaEf = preset.efekt || "Mastering";
    try {
        app.enableQE();
        var qs = qe.project.getActiveSequence(), qt = qs.getAudioTrackAt(nrToru), it = null;
        for (var j = 0; j < qt.numItems; j++) {
            var x = qt.getItemAt(j);
            try { if (x.type === "Empty") continue; } catch (e0) {}
            if (Math.abs(nm_qe_czas(x.start) - od) < Math.max(tol, 0.05)) { it = x; break; }
        }
        if (!it) return "nie znalazłem klipu muzyki na ścieżce A" + (nrToru + 1);
        var tr = s.audioTracks[nrToru], ti = nm_klip_w_torze(tr, nazwa, od, Math.max(tol, 0.05));
        if (!ti) return "nie znalazłem klipu muzyki w sekwencji";
        var jest = null;
        try { for (var k0 = 0; k0 < ti.components.numItems; k0++) if (String(ti.components[k0].displayName) === nazwaEf) jest = ti.components[k0]; } catch (e1) {}
        if (!jest) {
            var ef = null;
            try { ef = qe.project.getAudioEffectByName(nazwaEf); } catch (e2) {}
            if (!ef) return "Premiere nie ma efektu " + nazwaEf;
            it.addAudioEffect(ef);
            try { for (var k1 = 0; k1 < ti.components.numItems; k1++) if (String(ti.components[k1].displayName) === nazwaEf) jest = ti.components[k1]; } catch (e3) {}
            if (!jest) return "efekt " + nazwaEf + " nie pojawił się na klipie";
        }
        var brak = [];
        for (var n in preset.parametry) {
            if (!preset.parametry.hasOwnProperty(n)) continue;
            var p = nm_wlasciwosc(jest, [n]);
            if (!p) { brak.push(n); continue; }
            try { p.setValue(Number(preset.parametry[n]), true); } catch (e4) { brak.push(n); }
        }
        return brak.length ? "efekt jest, ale bez ustawień: " + brak.join(", ") : "";
    } catch (e) { return String(e); }
}
/* czy Motion klipu jest nietknięty (skala 100, środek, bez klatek kluczowych): tylko takie klipy wolno poprawić same */
function nm_motion_domyslny(ti) {
    var mp = nm_motion_parametry(ti);
    if (!mp || !mp.s) return false;
    try {
        if ((mp.s.isTimeVarying && mp.s.isTimeVarying()) || (mp.p && mp.p.isTimeVarying && mp.p.isTimeVarying())) return false;
        var vs = Number(mp.s.getValue()), vp = mp.p ? mp.p.getValue() : [0.5, 0.5];
        return Math.abs(vs - 100) < 0.01 && Math.abs(Number(vp[0]) - 0.5) < 0.001 && Math.abs(Number(vp[1]) - 0.5) < 0.001;
    } catch (e) { return false; }
}
/* klip w torze: po nazwie i początku, a gdy nazwa się nie zgadza (np. Premiere dopisał coś do nazwy), po samym początku */
function nm_klip_kadru(tr, nazwa, od, tol) {
    var k = nm_klip_w_torze(tr, nazwa, od, tol);
    if (k) return k;
    try {
        for (var i = 0; i < tr.clips.numItems; i++) {
            var c = tr.clips[i], pi = null;
            if (Math.abs(nm_sekundy(c.start) - od) >= tol) continue;
            try { pi = c.projectItem; } catch (e) {}
            var sciezka = ""; try { sciezka = pi ? String(pi.getMediaPath()) : ""; } catch (e2) {}
            if (!sciezka || nm_nazwa_pliku(sciezka).toLowerCase() === String(nazwa).toLowerCase() || String(c.name).toLowerCase().indexOf(String(nazwa).toLowerCase().replace(/\.[^.]+$/, "")) === 0) return c;
        }
    } catch (e3) {}
    return null;
}
/* kadry wszystkich oryginalnych nagrań z opisu osi (dodatki.json); tylkoDomyslne: nie ruszaj klipów, które ktoś już przestawił */
function nm_kadry_sekwencji(s, wid, fps, tylkoDomyslne) {
    var tol = 1.5 / (Number(fps) || 25), w = { ok: 0, pominiete: 0, bledy: [], log: [] };
    for (var a = 0; a < (wid || []).length; a++) {
        var e = wid[a];
        if (!e || !e.pozycja) continue;
        var nr = (Number(e.tor) || 1) - 1, nazwa = nm_nazwa_pliku(e.plik), od = Number(e.od_s) || 0;
        var tr = nr < s.videoTracks.numTracks ? s.videoTracks[nr] : null;
        var ti = tr ? nm_klip_kadru(tr, nazwa, od, tol) : null;
        if (ti && tylkoDomyslne && !nm_motion_domyslny(ti)) { w.pominiete++; w.log.push(nazwa + " @" + od + ": pominięty (kadr już zmieniony)"); continue; }
        var pw = nm_ustaw_kadr(ti, e.skala, e.pozycja);
        if (pw) { w.bledy.push(nazwa + " od " + od.toFixed(2) + " s: " + pw); w.log.push(nazwa + " @" + od + ": " + pw); }
        else { w.ok++; w.log.push(nazwa + " @" + od + ": skala " + e.skala + ", pozycja " + e.pozycja.join(";") + " OK"); }
    }
    return w;
}
/* panel: popraw kadry w sekwencji projektu, w której kadr z montażu nie wszedł (tylko klipy z nietkniętym Motion) */
function nm_napraw_kadry(dane) {
    try {
        var d = typeof dane === "string" ? eval("(" + dane + ")") : dane, s = null;
        for (var i = 0; i < app.project.sequences.numSequences; i++) if (String(app.project.sequences[i].name) === String(d.nazwa)) { s = app.project.sequences[i]; break; }
        if (!s) s = app.project.activeSequence;
        if (!s) return nm_json({ ok: false, blad: "Nie ma sekwencji " + d.nazwa });
        var w = nm_kadry_sekwencji(s, d.wideo, d.fps, true);
        if (w.ok) { try { app.project.save(); } catch (e) {} }
        w.sekwencja = s.name;
        return nm_json({ ok: true, kadry: w.ok, pominiete: w.pominiete, bledy: w.bledy, log: w.log, sekwencja: s.name });
    } catch (e) { return nm_json({ ok: false, blad: String(e) }); }
}
function nm_ruch_kamery(ti, ruch, skala, poz) {
    // przybliz/oddal: skala o 8%; pan-*: przesunięcie o 3% kadru przy lekkim powiększeniu; klatki kluczowe na początku i końcu klipu
    var motion = nm_komponent(ti, NM_MOTION);
    var pS = nm_wlasciwosc(motion, ["Scale", "Skala"], 1), pP = nm_wlasciwosc(motion, ["Position", "Pozycja"], 0);
    if (!pS || !pP) return false;
    var b = skala > 0 ? skala : 100, t0 = nm_sekundy(ti.inPoint), t1 = nm_sekundy(ti.outPoint) - 0.001;
    var px = poz && poz.length > 1 ? Number(poz[0]) : 0.5, py = poz && poz.length > 1 ? Number(poz[1]) : 0.5;
    var kl = function (p, v0, v1) { p.setTimeVarying(true); p.addKey(t0); p.addKey(t1); p.setValueAtKey(t0, v0, true); p.setValueAtKey(t1, v1, true); };
    try {
        if (ruch === "przybliz") kl(pS, b, b * 1.08);
        else if (ruch === "oddal") kl(pS, b * 1.08, b);
        else {
            var d = { "pan-prawo": [-0.03, 0], "pan-lewo": [0.03, 0], "pan-gora": [0, 0.03], "pan-dol": [0, -0.03] }[ruch];
            if (!d) return false;
            pS.setValue(b * 1.08, true);
            kl(pP, [px - d[0], py - d[1]], [px + d[0], py + d[1]]);
        }
        return true;
    } catch (e) { return false; }
}
function nm_dodaj_tory(s, wideo, audio) {
    try {
        app.enableQE();
        var q = qe.project.getActiveSequence();
        if (wideo > 0) q.addTracks(wideo, s.videoTracks.numTracks, 0);
        if (audio > 0) q.addTracks(0, 0, audio, 1, s.audioTracks.numTracks);
    } catch (e) {}
}
function nm_zbuduj_projekt(dane) {
    var w = { ok: false, dolozone_wideo: 0, dolozone_audio: 0, glosnosci: 0, ruch: 0, napisy: "", przejscia: "", uwagi: [] };
    try {
        var d = typeof dane === "string" ? eval("(" + dane + ")") : dane;
        var fps = Number(d.fps) || 25, tol = 1.5 / fps;
        var cel = new File(d.prproj);
        if (cel.exists) {
            app.openDocument(cel.fsName, true, true, true);
            return nm_json({ ok: true, otwarty: true, prproj: cel.fsName });
        }
        // 1. nowy projekt (poprzedni zostaje otwarty obok)
        if (!app.newProject(cel.fsName)) return nm_json({ ok: false, blad: "Premiere nie utworzył nowego projektu w " + cel.fsName });
        var jest = function () { try { return new File(app.project.path).fsName.toLowerCase() === cel.fsName.toLowerCase(); } catch (e) { return false; } };
        if (!jest()) { try { app.openDocument(cel.fsName, true, true, true); } catch (eO) {} }
        if (!jest()) return nm_json({ ok: false, blad: "Nowy projekt powstał, ale Premiere nie zrobił go aktywnym. Otwórz go ręcznie: " + cel.fsName });
        // 2. sekwencja z XML (obraz, cięcia, nakładki)
        var kosz = nm_kosz(d.nazwa || "Rolka");
        var przed = {};
        for (var i = 0; i < app.project.sequences.numSequences; i++) przed[app.project.sequences[i].sequenceID] = true;
        app.project.importFiles([d.xml], true, kosz, false);
        var s = null;
        for (var j = app.project.sequences.numSequences - 1; j >= 0; j--) if (!przed[app.project.sequences[j].sequenceID]) { s = app.project.sequences[j]; break; }
        if (!s) return nm_json({ ok: false, blad: "Premiere nie wczytał sekwencji z pliku XML." });
        app.project.openSequence(s.sequenceID);
        s = app.project.activeSequence;
        try { s.name = d.nazwa || s.name; } catch (eN) {}
        // 3. elementy projektu (każdy plik raz) do kładzenia brakujących klipów
        var materialy = nm_kosz("Materiały"), elementy = {};
        var element = function (plik) {
            if (elementy[plik]) return elementy[plik];
            var f = new File(plik);
            if (!f.exists) return null;
            app.project.importFiles([f.fsName], true, materialy, false);
            var el = nm_znajdz_element(materialy, nm_nazwa_pliku(plik));
            if (el) elementy[plik] = el;
            return el;
        };
        var poloz = function (tory, nrToru, k, czyAudio) {
            var nazwa = nm_nazwa_pliku(k.plik);
            if (nrToru < tory.numTracks) {
                var juz = nm_klip_w_torze(tory[nrToru], nazwa, Number(k.od_s), tol);
                if (juz) return { klip: juz, nowy: false };
            }
            var el = element(k.plik);
            if (!el) { w.uwagi.push("Nie ma pliku: " + nazwa); return null; }
            while (tory.numTracks <= nrToru) {
                var n0 = tory.numTracks;
                nm_dodaj_tory(s, czyAudio ? 0 : 1, czyAudio ? 1 : 0);
                if (tory.numTracks === n0) { w.uwagi.push("Nie udało się dodać ścieżki dla " + nazwa); return null; }
            }
            var od = Number(k.od_s) || 0, wP = Number(k.w_pliku_s) || 0, dl = Number(k.dlugosc_s) || 0;
            if (dl > 0 && !k.obraz) nm_ustaw_zakres(el, wP, wP + dl);
            var t = new Time(); t.seconds = od;
            tory[nrToru].overwriteClip(el, t);
            try { if (el.clearInPoint) el.clearInPoint(); if (el.clearOutPoint) el.clearOutPoint(); } catch (eC) {}
            var nowy = nm_klip_w_torze(tory[nrToru], nazwa, od, tol);
            if (nowy && dl > 0 && k.obraz) { try { var e2 = new Time(); e2.seconds = od + dl; nowy.end = e2; } catch (eE) {} }
            return nowy ? { klip: nowy, nowy: true } : null;
        };
        // 4. obraz: ujęcia, logo, animacje
        var wid = d.wideo || [];
        for (var a = 0; a < wid.length; a++) {
            var r = poloz(s.videoTracks, (Number(wid[a].tor) || 1) - 1, wid[a], false);
            if (r && r.nowy) w.dolozone_wideo++;
            // oryginalne nagranie z kadrem z montażu: skala i pozycja zawsze (także na klipie z XML), żeby kadr był do poprawienia w Effect Controls
            // oryginalne nagrania z kadrem dostają skalę i pozycję w osobnym kroku na końcu (z kontrolą odczytem)
            if (r && r.nowy && !wid[a].pozycja) nm_ustaw_skale(r.klip, Number(wid[a].skala));
        }
        // 5. dźwięk: mowa, lektor, muzyka, efekty (z głośnością)
        var aud = d.audio || [];
        for (var b = 0; b < aud.length; b++) {
            var r2 = poloz(s.audioTracks, (Number(aud[b].tor) || 1) - 1, aud[b], true);
            // głośność zawsze (także na klipach z XML), bo import XML nie zawsze ją przenosi
            if (r2) { if (r2.nowy) w.dolozone_audio++; if (Math.abs(Number(aud[b].glosnosc) - 1) >= 0.01 && nm_ustaw_glosnosc(r2.klip, Number(aud[b].glosnosc))) w.glosnosci++; }
        }
        // 5b. muzyka pod mową: efekt Mastering z presetem „Make Room for Vocals” (parametry z d.mastering)
        if (d.muzyka && d.muzyka.pod_mowa && d.mastering && d.mastering.parametry) {
            var mPlik = nm_nazwa_pliku(d.muzyka.plik), zrobione = 0, bledyM = [];
            for (var b2 = 0; b2 < aud.length; b2++) {
                if (nm_nazwa_pliku(aud[b2].plik) !== mPlik) continue;
                var pm = nm_mastering_klipu(s, (Number(aud[b2].tor) || 1) - 1, Number(aud[b2].od_s) || 0, mPlik, d.mastering, tol);
                if (pm) bledyM.push(pm); else zrobione++;
            }
            w.mastering = zrobione;
            if (bledyM.length) w.uwagi.push("Mastering na muzyce: " + bledyM.join(" | ") + " (nałóż go ręcznie: Effects > Audio Effects > Special > Mastering, preset „Make Room for Vocals”).");
        }
        // 6. przejścia (wbudowane przejścia Premiere w miejscach cięć)
        if ((d.przejscia || []).length) {
            var pr = eval("(" + nm_dodatki_sekwencji({ fps: fps, przejscia: d.przejscia }) + ")");
            w.przejscia = pr.ok ? (pr.przejscia + " z " + d.przejscia.length) : ("nie udało się: " + pr.blad);
        }
        // 7. ruch kamery na zdjęciach (klatki kluczowe zamiast markerów)
        var ru = d.ruch || [];
        for (var c = 0; c < ru.length; c++) {
            var v1 = s.videoTracks[0], kl = null;
            for (var x = 0; x < v1.clips.numItems; x++) if (Math.abs(nm_sekundy(v1.clips[x].start) - Number(ru[c].od_s)) < tol) { kl = v1.clips[x]; break; }
            var sk = 100;
            for (var y = 0; y < wid.length; y++) if (Number(wid[y].tor) === 1 && Math.abs(Number(wid[y].od_s) - Number(ru[c].od_s)) < tol) sk = Number(wid[y].skala) || 100;
            if (kl && nm_ruch_kamery(kl, ru[c].ruch, sk, ru[c].pozycja)) w.ruch++;
        }
        // 8. napisy: w stylu z narzędzia (każdy fragment osobnym przezroczystym klipem nad obrazem),
        //    a gdy rolka nie ma zapisanego stylu, zwykła ścieżka napisów z pliku SRT
        var zrobioneNapisy = false;
        if (d.napisy_lista && d.napisy_lista.length) {
            var ns = eval("(" + nm_wstaw_napisy(d.napisy_lista, d.napisy_kosz || "Nada – napisy") + ")");
            if (ns.ok) {
                zrobioneNapisy = true;
                w.napisy_ids = ns.ids;
                w.napisy = (d.napisy_lista.length - (ns.brak || 0)) + " fragmentów w Twoim stylu na " + ns.sciezka;
                if (ns.brak) w.uwagi.push("Nie weszło " + ns.brak + " fragmentów napisów.");
            } else w.uwagi.push("Napisy w stylu: " + ns.blad);
        }
        if (!zrobioneNapisy && d.srt && new File(d.srt).exists) {
            var np = eval("(" + nm_napisy_premiere(d.srt) + ")");
            w.napisy = np.ok ? "dodane" : np.blad;
        }
        // 8b. kadr oryginalnych nagrań z montażu (Scale i Position w Motion), sprawdzony odczytem z Premiere
        var kd = nm_kadry_sekwencji(s, wid, fps, false);
        w.kadry = kd.ok; w.kadr_log = kd.log;
        if (kd.bledy.length) w.uwagi.push("Kadr z montażu nie wszedł w " + kd.bledy.length + " klipach: " + kd.bledy.join(" | "));
        // 9. zapis
        app.project.save();
        w.ok = true; w.prproj = cel.fsName; w.sekwencja = s.name; w.sekwencja_id = s.sequenceID;
        return nm_json(w);
    } catch (e) {
        w.blad = String(e) + (e.line ? " (linia " + e.line + ")" : "");
        try { app.project.save(); } catch (e2) {}
        return nm_json(w);
    }
}
