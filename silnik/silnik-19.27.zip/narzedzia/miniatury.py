"""Miniatury YouTube: najlepsze kadry z filmu jako tła.

  python narzedzia/miniatury.py klatki --plik zlecenia/<nazwa>/film.mp4 [--ile 12]
     -> <folder>/gotowe/klatki/kNN_<czas>.png (pełna rozdzielczość) i klatki_arkusz.jpg (wszystkie z numerami)
        dla każdej klatki: ostrość, czy jest twarz i po której stronie (żeby tekst postawić po drugiej)

Potem miniatury składa grafika.py (format yt-1280x720), z wybraną klatką jako tłem; plik PSD powstaje sam.
"""
import argparse
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, postep, wynik  # noqa: E402


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


def klatki(plik, ile=12):
    try:
        import cv2
    except ImportError:
        blad('Brak OpenCV: python -m pip install "opencv-python-headless<5"')
    from PIL import Image, ImageDraw
    plik = sciezka(plik)
    cap = cv2.VideoCapture(str(plik))
    fps = cap.get(cv2.CAP_PROP_FPS) or 25
    n = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    if n <= 0:
        blad(f"Nie mogę odczytać {plik.name}")
    twarze = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    kandydaci = []
    probek = min(120, max(ile * 4, 30))
    postep(f"Przeglądam {probek} kadrów")
    for k in range(probek):
        idx = int((k + 0.5) * n / probek)
        cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
        ok, kl = cap.read()
        if not ok:
            continue
        szary = cv2.cvtColor(kl, cv2.COLOR_BGR2GRAY)
        male = cv2.resize(szary, (640, int(640 * szary.shape[0] / szary.shape[1])))
        ostrosc = cv2.Laplacian(male, cv2.CV_64F).var()
        jasnosc = male.mean()
        tw = twarze.detectMultiScale(cv2.equalizeHist(male), 1.15, 5, minSize=(40, 40))
        twarz = None
        if len(tw):
            x, y, w, h = max(tw, key=lambda f: f[2] * f[3])
            twarz = {"strona": "lewo" if x + w / 2 < 213 else "prawo" if x + w / 2 > 427 else "srodek", "wielkosc": round(w / 640, 2)}
        punkty = ostrosc * (1.6 if twarz else 1.0) * (0.5 if jasnosc < 40 or jasnosc > 220 else 1.0)
        kandydaci.append((punkty, idx, kl, twarz, round(ostrosc)))
    cap.release()
    # najlepsze, ale rozrzucone po filmie (nie 10 kadrów z tej samej sekundy)
    kandydaci.sort(key=lambda x: -x[0])
    wybrane = []
    for c in kandydaci:
        if all(abs(c[1] - w[1]) > n / (ile * 2.5) for w in wybrane):
            wybrane.append(c)
        if len(wybrane) >= ile:
            break
    wybrane.sort(key=lambda x: x[1])
    folder = plik.parent / "gotowe" / "klatki"
    folder.mkdir(parents=True, exist_ok=True)
    wyn, miniatury = [], []
    for i, (pkt, idx, kl, twarz, ostr) in enumerate(wybrane, 1):
        t = idx / fps
        cel = folder / f"k{i:02d}_{int(t // 60):02d}m{int(t % 60):02d}s.png"
        cv2.imwrite(str(cel), kl)
        wyn.append({"nr": i, "plik": str(cel), "czas_s": round(t, 1), "ostrosc": ostr, "twarz": twarz})
        im = Image.open(cel).convert("RGB")
        im.thumbnail((360, 203))
        ImageDraw.Draw(im).text((8, 6), str(i), fill=(255, 220, 0))
        miniatury.append(im)
    kol = 4
    rz = (len(miniatury) + kol - 1) // kol
    ark = Image.new("RGB", (kol * 370 + 10, rz * 213 + 10), (30, 30, 30))
    for i, im in enumerate(miniatury):
        ark.paste(im, (10 + (i % kol) * 370, 10 + (i // kol) * 213))
    arkusz = plik.parent / "gotowe" / "klatki_arkusz.jpg"
    ark.save(arkusz, quality=85)
    wynik(arkusz=str(arkusz), klatki=wyn)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Klatki na miniatury YouTube")
    sub = p.add_subparsers(dest="tryb", required=True)
    k = sub.add_parser("klatki"); k.add_argument("--plik", required=True); k.add_argument("--ile", type=int, default=12)
    a = p.parse_args()
    klatki(a.plik, a.ile)
