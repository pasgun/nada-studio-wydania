"""Inne „mózgi” (asystenci AI w terminalu) poza Claude Code i Gemini (Antigravity).

Mózg to program, który w tle czyta polecenie zadania, sam uruchamia narzędzia silnika (python narzedzia/...),
czyta i zapisuje pliki i ogląda obrazy (kadry, referencje). Lista mózgów użytkownika jest w _system/mozgi.json
(dodaje się je w apce: Ustawienia apki > Logowanie > Inny mózg). Przy każdym jest wynik testu: czy podoła.

  python narzedzia/mozgi_inne.py katalog                 gotowe ustawienia znanych programów
  python narzedzia/mozgi_inne.py lista                   mózgi użytkownika (z wynikiem testu)
  python narzedzia/mozgi_inne.py dodaj --dane '<json>'   dodaje albo zmienia mózg (id, nazwa, program, argumenty)
  python narzedzia/mozgi_inne.py usun --id X
  python narzedzia/mozgi_inne.py znajdz --program codex  czy program jest na komputerze
  python narzedzia/mozgi_inne.py test --id X             test, czy mózg podoła zadaniom silnika (do kilku minut)
  python narzedzia/mozgi_inne.py krok --folder F         krok testu (uruchamia go sam testowany mózg)

W argumentach mózgu {instrukcja} zastępuje krótkie polecenie „przeczytaj plik X i wykonaj go”, a {plik} samą
ścieżkę pliku z poleceniem (względem folderu silnika).
"""
import argparse
import json
import os
import random
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import sciezki  # noqa: E402,F401  (programy zainstalowane przez apkę w PATH)

KATALOG = Path(__file__).resolve().parent.parent
PLIK = KATALOG / "_system" / "mozgi.json"
WIN = sys.platform.startswith("win")

# Gotowe ustawienia znanych programów. Polecenia z dokumentacji producentów (stan: październik 2026);
# gdy producent coś zmieni, test to pokaże, a argumenty da się poprawić w apce.
KATALOG_MOZGOW = [
    {"id": "codex", "nazwa": "Codex (OpenAI)", "program": "codex",
     "argumenty": ["exec", "--skip-git-repo-check", "--sandbox", "workspace-write", "-c", "sandbox_workspace_write.network_access=true", "--json", "{instrukcja}"],
     "instaluj": "npm install -g @openai/codex", "zaloguj": "codex login",
     "konto": "konto ChatGPT (Plus, Pro, Business) albo klucz OpenAI", "strona": "https://developers.openai.com/codex/cli"},
    {"id": "copilot", "nazwa": "GitHub Copilot CLI", "program": "copilot",
     "argumenty": ["-p", "{instrukcja}", "-s", "--allow-all-tools", "--no-ask-user"],
     "instaluj": "npm install -g @github/copilot", "zaloguj": "copilot",
     "konto": "konto GitHub z planem Copilot (w programie wpisz /login)", "strona": "https://docs.github.com/copilot/how-tos/copilot-cli"},
    {"id": "gemini-cli", "nazwa": "Gemini CLI (Google)", "program": "gemini",
     "argumenty": ["-p", "{instrukcja}", "--yolo"],
     "instaluj": "npm install -g @google/gemini-cli", "zaloguj": "gemini",
     "konto": "konto Google albo klucz Gemini API (płatny)", "strona": "https://github.com/google-gemini/gemini-cli"},
    {"id": "qwen", "nazwa": "Qwen Code", "program": "qwen",
     "argumenty": ["-p", "{instrukcja}", "--yolo"],
     "instaluj": "npm install -g @qwen-code/qwen-code", "zaloguj": "qwen",
     "konto": "konto Qwen albo klucz API zgodny z OpenAI", "strona": "https://github.com/QwenLM/qwen-code"},
    {"id": "opencode", "nazwa": "OpenCode (także modele lokalne, np. Ollama)", "program": "opencode",
     "argumenty": ["run", "{instrukcja}"],
     "instaluj": "npm install -g opencode-ai", "zaloguj": "opencode auth login",
     "konto": "dowolny dostawca (OpenAI, Anthropic, Google, lokalny Ollama)", "strona": "https://opencode.ai/docs/"},
]

INSTRUKCJA = "Read the file {plik} and do exactly what it says. Work rules for this folder are in AGENTS.md and CLAUDE.md."


def wynik(**d):
    print(json.dumps(dict({"ok": True}, **d), ensure_ascii=False, indent=1))
    sys.exit(0)


def blad(t):
    print(json.dumps({"ok": False, "blad": t}, ensure_ascii=False))
    sys.exit(1)


def wczytaj():
    try:
        d = json.loads(PLIK.read_text(encoding="utf-8"))
        return d if isinstance(d, list) else []
    except Exception:
        return []


def zapisz(lista):
    PLIK.parent.mkdir(parents=True, exist_ok=True)
    PLIK.write_text(json.dumps(lista, ensure_ascii=False, indent=1), encoding="utf-8")


def mozg(mid):
    return next((m for m in wczytaj() if m.get("id") == mid), None)


def znajdz(program):
    if not program:
        return ""
    if os.path.isabs(program) and os.path.exists(program):
        return program
    w = shutil.which(program) or ""
    if not w and WIN:
        for k in (Path(os.environ.get("APPDATA", "")) / "npm", Path.home() / ".local" / "bin"):
            for roz in (".cmd", ".exe", ".bat", ""):
                if (k / (program + roz)).exists():
                    return str(k / (program + roz))
    return w


def argumenty(m, plik_rel):
    """Pełne polecenie do uruchomienia mózgu dla pliku z poleceniem (ścieżka względem folderu silnika)."""
    prog = znajdz(m.get("program", ""))
    if not prog:
        raise ValueError(f"Nie znalazłem programu „{m.get('program')}” ({m.get('nazwa')}). Zainstaluj go w apce: Ustawienia apki > Logowanie > Inny mózg.")
    instr = INSTRUKCJA.format(plik=plik_rel)
    args = [prog] + [str(a).replace("{instrukcja}", instr).replace("{plik}", plik_rel) for a in (m.get("argumenty") or ["{instrukcja}"])]
    if args[0].lower().endswith((".cmd", ".bat")):
        args = ["cmd", "/c", *args]
    return args


def plik_polecenia(kat, tekst):
    """Polecenie w pliku: długi tekst z JSON-em nie przejdzie bezpiecznie przez wiersz poleceń Windows."""
    nr = len(list(Path(kat).glob("polecenie_*.md"))) + 1
    p = Path(kat) / f"polecenie_{nr}.md"
    p.write_text("Pracujesz w tle: nikt nie kliknie „Zezwól” i nie odpowie w trakcie. Polecenia uruchamiasz sam w folderze silnika "
                 "(python narzedzia/<narzędzie>.py, ffmpeg, ffprobe). Zasady: AGENTS.md i CLAUDE.md.\n\n" + tekst, encoding="utf-8")
    return p.relative_to(KATALOG).as_posix()


# ---------- test: czy mózg podoła ----------

KOLORY = [("czerwony", (200, 30, 30)), ("niebieski", (30, 60, 200)), ("zielony", (30, 150, 60)), ("fioletowy", (120, 40, 160))]
SLOWA = ["klaps", "statyw", "kadr", "gimbal", "proksy", "plansza", "montaż", "napisy"]


def przygotuj(folder):
    from PIL import Image, ImageDraw, ImageFont
    folder.mkdir(parents=True, exist_ok=True)
    slowo = random.choice(SLOWA)
    liczba = str(random.randint(1000, 9999))
    kolor, rgb = random.choice(KOLORY)
    (folder / "zagadka.txt").write_text(f"Słowo testowe to: {slowo}\n", encoding="utf-8")
    im = Image.new("RGB", (900, 500), rgb)
    d = ImageDraw.Draw(im)
    font = None
    for f in ("arialbd.ttf", "Arial Bold.ttf", "DejaVuSans-Bold.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"):
        try:
            font = ImageFont.truetype(f, 260)
            break
        except Exception:
            pass
    font = font or ImageFont.load_default()
    b = d.textbbox((0, 0), liczba, font=font)
    d.text(((900 - (b[2] - b[0])) / 2 - b[0], (500 - (b[3] - b[1])) / 2 - b[1]), liczba, fill=(255, 255, 255), font=font)
    im.save(folder / "obraz.png")
    return {"slowo": slowo, "liczba": liczba, "kolor": kolor}


def polecenie_testu(rel):
    return f"""To jest test dla apki Nada Studio: sprawdza, czy umiesz pracować w tym folderze. Zrób po kolei, bez pytania:
1. Uruchom w terminalu (w folderze silnika) polecenie: python narzedzia/mozgi_inne.py krok --folder {rel}
2. Przeczytaj plik {rel}/zagadka.txt.
3. Obejrzyj obraz {rel}/obraz.png (jest na nim liczba na kolorowym tle).
4. Zapisz plik {rel}/odpowiedz.json z treścią JSON: {{"slowo": "<słowo testowe z zagadka.txt>", "liczba": "<liczba z obrazu>", "kolor": "<kolor tła obrazu, po polsku>", "zdanie": "<jedno zdanie po polsku: czym zajmuje się montażysta>"}}
5. Napisz jednym zdaniem po polsku, co zrobiłeś, i zakończ odpowiedź znacznikiem [GOTOWE].
Nie czytaj pliku .env ani innych plików z kluczami."""


def krok(folder):
    f = (KATALOG / folder) if not Path(folder).is_absolute() else Path(folder)
    net = False
    try:
        import requests
        r = requests.get("https://www.google.com/generate_204", timeout=15)
        net = r.status_code in (200, 204)
    except Exception:
        net = False
    (f / "krok.json").write_text(json.dumps({"kiedy": time.time(), "internet": net}), encoding="utf-8")
    wynik(zapisano=True, internet=net)


OPISY = {
    "uruchamia": ("Program się uruchamia i odpowiada w tle", "Program nie ruszył albo nic nie odpowiedział. Sprawdź, czy jest zainstalowany i zalogowany (przyciski obok), i czy argumenty są dobre."),
    "polecenia": ("Sam uruchamia narzędzia silnika", "Nie uruchomił polecenia w terminalu. Bez tego nie zrobi żadnego zadania (wszystko robią narzędzia python narzedzia/...). Zwykle brakuje zgody na polecenia w tle: popraw argumenty."),
    "internet": ("Narzędzia mają internet", "Narzędzia uruchomione przez ten mózg nie mają internetu (program pracuje w zamkniętej „piaskownicy”). Stock, lektor i obrazy AI nie zadziałają."),
    "pliki": ("Czyta pliki", "Nie przeczytał pliku (podał złe słowo albo żadne)."),
    "zapis": ("Zapisuje pliki", "Nie zapisał pliku z odpowiedzią. Bez tego nie zrobi planów montażu ani notatek."),
    "obrazy": ("Widzi obrazy", "Nie odczytał liczby z obrazu: ten model nie widzi obrazów albo widzi słabo. Nie sprawdzi kadrów, referencji ani grafik."),
    "polski": ("Pisze po polsku", "Nie napisał zdania po polsku. Odpowiedzi w Console mogą być po angielsku."),
    "zasady": ("Trzyma się zasad (znacznik [GOTOWE])", "Nie zakończył odpowiedzi znacznikiem [GOTOWE], o który prosiło polecenie. Może gorzej trzymać się instrukcji w długich zadaniach."),
}


def test(mid, limit_s=420):
    m = mozg(mid)
    if not m:
        blad(f"Nie ma mózgu „{mid}”. Dodaj go najpierw.")
    folder = KATALOG / "_system" / "mozgi" / f"test_{mid}"
    if folder.exists():
        shutil.rmtree(folder, ignore_errors=True)
    ocz = przygotuj(folder)
    rel = folder.relative_to(KATALOG).as_posix()
    (folder / "polecenie_1.md").write_text(polecenie_testu(rel), encoding="utf-8")
    try:
        args = argumenty(m, rel + "/polecenie_1.md")
    except ValueError as e:
        blad(str(e))
    start = time.time()
    flagi = 0x08000000 if WIN else 0
    try:
        r = subprocess.run(args, cwd=str(KATALOG), capture_output=True, timeout=limit_s, stdin=subprocess.DEVNULL, creationflags=flagi,
                           env=dict(os.environ, PYTHONIOENCODING="utf-8"))
        out = (r.stdout or b"").decode("utf-8", "replace") + "\n" + (r.stderr or b"").decode("utf-8", "replace")
        kod, za_dlugo = r.returncode, False
    except subprocess.TimeoutExpired as e:
        out = ((e.stdout or b"").decode("utf-8", "replace") if isinstance(e.stdout, bytes) else str(e.stdout or "")) + "\n(przekroczony czas)"
        kod, za_dlugo = -1, True
    except Exception as e:
        out, kod, za_dlugo = str(e), -1, False
    czas = round(time.time() - start)
    (folder / "wyjscie.txt").write_text(out, encoding="utf-8")
    try:
        krokj = json.loads((folder / "krok.json").read_text(encoding="utf-8"))
    except Exception:
        krokj = None
    try:
        odp = json.loads((folder / "odpowiedz.json").read_text(encoding="utf-8-sig"))
    except Exception:
        odp = None
    odp = odp if isinstance(odp, dict) else {}
    norm = lambda s: str(s or "").strip().lower()
    zdanie = str(odp.get("zdanie") or "")
    w = {
        "uruchamia": bool(out.strip()) and not za_dlugo and kod != 127,
        "polecenia": krokj is not None,
        "internet": bool(krokj and krokj.get("internet")),
        "pliki": norm(odp.get("slowo")) == norm(ocz["slowo"]),
        "zapis": bool(odp),
        "obrazy": "".join(ch for ch in str(odp.get("liczba") or "") if ch.isdigit()) == ocz["liczba"],
        "polski": any(c in zdanie for c in "ąćęłńóśźż") or any(x in zdanie.lower().split() for x in ("jest", "się", "i", "w", "na", "montażysta")),
        "zasady": "[GOTOWE]" in out,
    }
    if za_dlugo:
        w["uruchamia"] = bool(krokj or odp)
    wazne = ["polecenia", "pliki", "zapis"]
    if all(w[k] for k in wazne) and w["obrazy"] and w["internet"]:
        ocena = "podola"
        werdykt = "Podoła: umie wszystko, czego potrzebują zadania silnika."
    elif all(w[k] for k in wazne):
        ocena = "czesciowo"
        werdykt = "Podoła częściowo: zrobi część zadań, ale ma braki (niżej)."
    else:
        ocena = "nie"
        werdykt = "Nie podoła: bez tych umiejętności nie zrobi zadań silnika."
    if za_dlugo:
        werdykt += f" Test trwał ponad {limit_s // 60} minut, więc zadania będą bardzo wolne."
    lista = [{"co": k, "ok": v, "opis": OPISY[k][0] if v else OPISY[k][1]} for k, v in w.items()]
    stan = {"kiedy": int(time.time()), "ocena": ocena, "werdykt": werdykt, "czas_s": czas, "wyniki": {k: v for k, v in w.items()}}
    lst = wczytaj()
    for x in lst:
        if x.get("id") == mid:
            x["test"] = stan
    zapisz(lst)
    wynik(id=mid, ocena=ocena, werdykt=werdykt, czas_s=czas, sprawdzenia=lista, wyjscie=out[-1500:])


def main():
    ap = argparse.ArgumentParser(description="Inne mózgi silnika (asystenci AI w terminalu)")
    s = ap.add_subparsers(dest="cmd", required=True)
    s.add_parser("katalog"); s.add_parser("lista")
    d = s.add_parser("dodaj"); d.add_argument("--dane", required=True)
    u = s.add_parser("usun"); u.add_argument("--id", required=True)
    z = s.add_parser("znajdz"); z.add_argument("--program", required=True)
    t = s.add_parser("test"); t.add_argument("--id", required=True); t.add_argument("--limit", type=int, default=420)
    k = s.add_parser("krok"); k.add_argument("--folder", required=True)
    a = ap.parse_args()
    if a.cmd == "katalog":
        wynik(katalog=[dict(x, jest=bool(znajdz(x["program"]))) for x in KATALOG_MOZGOW])
    elif a.cmd == "lista":
        wynik(mozgi=[dict(x, jest=bool(znajdz(x.get("program")))) for x in wczytaj()])
    elif a.cmd == "dodaj":
        try:
            n = json.loads(a.dane)
        except Exception:
            blad("Złe dane mózgu (JSON).")
        if not n.get("id") or n["id"] in ("claude", "gemini") or not n.get("program"):
            blad("Mózg musi mieć nazwę i program (np. codex).")
        n = {k: n[k] for k in ("id", "nazwa", "program", "argumenty", "instaluj", "zaloguj", "konto", "strona") if k in n}
        if not isinstance(n.get("argumenty"), list) or not any("{instrukcja}" in str(x) or "{plik}" in str(x) for x in n["argumenty"]):
            blad("Argumenty muszą zawierać {instrukcja} albo {plik} (tam trafia polecenie zadania).")
        lst = [x for x in wczytaj() if x.get("id") != n["id"]]
        stary = mozg(n["id"]) or {}
        if stary.get("program") == n.get("program") and stary.get("argumenty") == n.get("argumenty") and stary.get("test"):
            n["test"] = stary["test"]
        lst.append(n)
        zapisz(lst)
        wynik(mozg=n)
    elif a.cmd == "usun":
        zapisz([x for x in wczytaj() if x.get("id") != a.id])
        wynik(usunieto=a.id)
    elif a.cmd == "znajdz":
        p = znajdz(a.program)
        wynik(jest=bool(p), sciezka=p)
    elif a.cmd == "test":
        test(a.id, a.limit)
    elif a.cmd == "krok":
        krok(a.folder)


if __name__ == "__main__":
    main()
