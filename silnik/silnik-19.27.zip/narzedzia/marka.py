"""Notatka marki klienta (marka.md): czy jest aktualna i z czego ją napisać.

  python narzedzia/marka.py sprawdz --folder klienci/marka

Wypisuje pliki z brandbook/ i referencji, liczbę stron PDF-ów oraz to, czy marka.md trzeba napisać
albo odświeżyć (nie ma jej albo w brandbook/ lub referencjach są nowsze pliki).
Samą notatkę pisze Claude (zasady w CLAUDE.md, sekcja „Marka i brandbook”).
"""
import argparse
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, wynik  # noqa: E402

OBRAZY = {".png", ".jpg", ".jpeg", ".webp", ".svg", ".gif"}
WIDEO = {".mp4", ".mov", ".m4v", ".webm"}


def strony_pdf(p):
    """Liczba stron PDF bez dodatkowych bibliotek (wystarcza do planowania czytania po kawałku)."""
    try:
        import pypdf  # noqa: F401
        return len(pypdf.PdfReader(str(p)).pages)
    except Exception:
        pass
    try:
        dane = p.read_bytes()
        n = len(re.findall(rb"/Type\s*/Page[^s]", dane))
        return n or None
    except Exception:
        return None


def sprawdz(folder):
    folder = Path(folder)
    folder = folder if folder.is_absolute() else KATALOG_SILNIKA / folder
    if not folder.exists():
        blad(f"Nie ma folderu klienta {folder}. Utwórz go przyciskiem „Utwórz folder klienta” w Studio.")
    marka = folder / "marka.md"
    zrodla = []
    for pod in ("brandbook", "logo", "referencje/grafiki", "referencje/wideo"):
        f = folder / pod
        if not f.exists():
            continue
        for p in sorted(f.rglob("*")):
            if not p.is_file() or p.name == "CZYTAJ.txt" or "_analiza" in p.parts or "_strony" in p.parts:
                continue
            e = p.suffix.lower()
            rodzaj = "pdf" if e == ".pdf" else "obraz" if e in OBRAZY else "wideo" if e in WIDEO else "inny"
            wpis = {"plik": str(p.relative_to(KATALOG_SILNIKA)).replace("\\", "/"), "rodzaj": rodzaj, "folder": pod,
                    "zmieniony": p.stat().st_mtime}
            if rodzaj == "pdf":
                wpis["stron"] = strony_pdf(p)
            zrodla.append(wpis)
    logo = [str(p.relative_to(KATALOG_SILNIKA)).replace("\\", "/") for p in sorted(list(folder.glob("logo*.*")) + list((folder / "logo").glob("*.*")))
            if p.suffix.lower() in OBRAZY]
    najnowszy = max((z["zmieniony"] for z in zrodla), default=0)
    if not marka.exists():
        stan = "brak" if zrodla else "brak_zrodel"
    else:
        stan = "nieaktualna" if najnowszy > marka.stat().st_mtime else "aktualna"
    for z in zrodla:
        z.pop("zmieniony")
    rada = {
        "brak": "Napisz marka.md z brandbooka i przykładów (CLAUDE.md, „Marka i brandbook”).",
        "nieaktualna": "Doszły nowe pliki: przeczytaj je i zaktualizuj marka.md.",
        "aktualna": "Używaj marka.md.",
        "brak_zrodel": "Brak brandbooka i przykładów: użyj palety, fontów i uwag z karty klienta w zadaniu.",
    }[stan]
    wynik(notatka=str(marka), stan=stan, rada=rada, zrodla=zrodla, logo=logo)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Notatka marki klienta")
    sub = p.add_subparsers(dest="tryb", required=True)
    s = sub.add_parser("sprawdz"); s.add_argument("--folder", required=True)
    a = p.parse_args()
    sprawdz(a.folder)
