"""Transkrypcja z kodami czasowymi: wywiady, podcasty, reportaże.

  python narzedzia/transkrypcja.py --folder transkrypcje/2026-10-21_wywiad [--jezyk pl] [--silnik auto]
         [--mowcy] [--nazwy "1=Jan Kowalski,2=Anna"] [--tc-start 10:00:00:00] [--fps 25]
  python narzedzia/transkrypcja.py --plik nagranie.mp4 ...

Dla każdego pliku (wideo albo audio) w folderze zapisuje w podfolderze gotowe/:
  <nazwa>_transkrypcja.txt   akapity z kodem czasowym i mówcą: [00:01:23:12] Jan: ...
  <nazwa>.srt                napisy (do Premiere, DaVinci, YouTube)
  <nazwa>_slowa.json         każde słowo z czasem (do dalszej pracy, np. napisów)
--tc-start: kod czasowy początku nagrania z kamery (żeby czasy zgadzały się z timecode w montażówce).
--nazwy: imiona mówców zamiast „Mówca 1”. Można je też poprawić później w pliku txt (Znajdź i zamień).
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, postep, wynik  # noqa: E402
import mowa  # noqa: E402

ROZSZ = {".mp4", ".mov", ".mxf", ".m4v", ".mkv", ".avi", ".mts", ".webm", ".wav", ".mp3", ".m4a", ".aac", ".flac", ".ogg"}


def tc_na_s(tc, fps):
    if not tc:
        return 0.0
    cz = [float(x) for x in tc.replace(";", ":").split(":")]
    while len(cz) < 4:
        cz.append(0)
    h, m, s, k = cz[:4]
    return h * 3600 + m * 60 + s + (k / fps if fps else 0)


def srt(zd, plik, max_znakow=42):
    def ts(x):
        h, r = divmod(max(0.0, x), 3600)
        m, r = divmod(r, 60)
        s = int(r)
        return f"{int(h):02d}:{int(m):02d}:{s:02d},{int(round((r - s) * 1000)):03d}"
    bloki = []
    for z in zd:
        # długie zdania dzielimy na kawałki po ~2 linie
        kaw, biez = [], []
        for w in z["slowa"]:
            if biez and len(" ".join(x["slowo"] for x in biez + [w])) > max_znakow * 2:
                kaw.append(biez)
                biez = []
            biez.append(w)
        if biez:
            kaw.append(biez)
        for k in kaw:
            tekst = " ".join(x["slowo"] for x in k)
            if len(tekst) > max_znakow:
                slowa = tekst.split()
                pol = len(slowa) // 2
                tekst = " ".join(slowa[:pol]) + "\n" + " ".join(slowa[pol:])
            bloki.append((k[0]["start"], k[-1]["koniec"], tekst))
    Path(plik).write_text("\n".join(f"{i + 1}\n{ts(a)} --> {ts(max(b, a + 0.5))}\n{t}\n" for i, (a, b, t) in enumerate(bloki)), encoding="utf-8")


def akapity(zd, max_s=45):
    """Zdania -> akapity: nowy akapit przy zmianie mówcy albo co ~45 s."""
    wyn = []
    for z in zd:
        if wyn and wyn[-1]["mowca"] == z["mowca"] and z["do"] - wyn[-1]["od"] < max_s:
            wyn[-1]["tekst"] += " " + z["tekst"]
            wyn[-1]["do"] = z["do"]
        else:
            wyn.append({"od": z["od"], "do": z["do"], "mowca": z["mowca"], "tekst": z["tekst"]})
    return wyn


def jeden(plik, jezyk, silnik, mowcy, nazwy, tc_start, fps, wyj):
    t = mowa.transkrybuj(plik, jezyk, silnik, mowcy=mowcy, zdarzenia=True)
    zd = mowa.zdania(t["slowa"])
    mowcy_w = sorted({z["mowca"] for z in zd if z["mowca"]})
    linie = [f"Transkrypcja: {plik.name}", f"Długość: {mowa.kod_czasowy(t['dlugosc_s'])} · silnik: {t['silnik']} · język: {t['jezyk'] or '?'}", ""]
    for a in akapity(zd):
        kto = ""
        if a["mowca"]:
            kto = (nazwy.get(a["mowca"]) or f"Mówca {a['mowca']}") + ": "
        linie.append(f"[{mowa.kod_czasowy(a['od'], fps, tc_start)}] {kto}{a['tekst']}")
        linie.append("")
    if t["zdarzenia"]:
        linie.append("Zdarzenia dźwiękowe:")
        linie += [f"[{mowa.kod_czasowy(z['start'], fps, tc_start)}] {z['opis']}" for z in t["zdarzenia"]]
    wyj.mkdir(parents=True, exist_ok=True)
    txt = wyj / f"{plik.stem}_transkrypcja.txt"
    txt.write_text("\n".join(linie) + "\n", encoding="utf-8")
    srt(zd, wyj / f"{plik.stem}.srt")
    mowa.zapisz_slowa(t["slowa"], wyj / f"{plik.stem}_slowa.json")
    return {"plik": plik.name, "txt": str(txt), "srt": str(wyj / f"{plik.stem}.srt"), "minuty": t["minuty"],
            "silnik": t["silnik"], "mowcy": [nazwy.get(m) or f"Mówca {m}" for m in mowcy_w], "zdarzen": len(t["zdarzenia"])}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Transkrypcja z kodami czasowymi")
    p.add_argument("--folder"); p.add_argument("--plik"); p.add_argument("--jezyk", default=None)
    p.add_argument("--silnik", default="auto", choices=["auto", "elevenlabs", "subtitle-edit", "lokalnie"])
    p.add_argument("--mowcy", action="store_true"); p.add_argument("--nazwy", default="")
    p.add_argument("--tc-start", default=""); p.add_argument("--fps", type=float, default=0)
    a = p.parse_args()
    nazwy = dict(x.split("=", 1) for x in a.nazwy.split(",") if "=" in x)
    pliki = []
    if a.plik:
        pliki = [Path(a.plik) if Path(a.plik).is_absolute() else KATALOG_SILNIKA / a.plik]
        wyj = pliki[0].parent / "gotowe"
    elif a.folder:
        f = Path(a.folder) if Path(a.folder).is_absolute() else KATALOG_SILNIKA / a.folder
        if not f.exists():
            blad(f"Nie ma folderu {f}")
        pliki = sorted(x for x in f.iterdir() if x.suffix.lower() in ROZSZ)
        wyj = f / "gotowe"
    if not pliki:
        blad("Brak plików wideo ani audio do transkrypcji.")
    fps = a.fps or None
    tc = tc_na_s(a.tc_start, fps or 25)
    wyn = []
    for i, pl in enumerate(pliki, 1):
        postep(f"Transkrypcja {i}/{len(pliki)}: {pl.name}")
        wyn.append(jeden(pl, a.jezyk, a.silnik, a.mowcy, nazwy, tc, fps, wyj))
    wynik(pliki=wyn, folder=str(wyj), minuty_lacznie=round(sum(x["minuty"] for x in wyn), 1))
