"""Higgsfield API: obraz (Soul 2) i wideo z obrazu (Kling 2.6 Pro).

Użycie:
  python narzedzia/higgsfield.py obraz --prompt "..." --wyjscie wyniki/X/sceny/s1.png
  python narzedzia/higgsfield.py wideo --prompt "ruch kamery..." --obraz wyniki/X/sceny/s1.png --wyjscie wyniki/X/sceny/s1.mp4
  python narzedzia/higgsfield.py scena --prompt-obrazu "..." --prompt-ruchu "..." --wyjscie wyniki/X/sceny/s1.mp4
     (scena = obraz + animacja w jednym kroku)

Klucz w .env: HIGGSFIELD_API_KEY (open.higgsfield.ai -> API keys), albo HIGGSFIELD_KEY_ID + HIGGSFIELD_KEY_SECRET.
Płatność: osobne saldo API w dolarach (min. doładowanie 5 $), Kling 2.6 ok. 0,07 $ za sekundę wideo.
"""
import argparse
import mimetypes
import uuid
from pathlib import Path

import requests

from wspolne import blad, czekaj, higgsfield_dane, pobierz, wynik, zapytanie

API = "https://api.higgsfield.ai"
MODEL_OBRAZ = "/higgsfield-ai/soul/v2/standard"
MODEL_WIDEO = "/kling-video/v2.6/pro/image-to-video"
STANY_KONCOWE = {"completed", "failed", "nsfw", "canceled"}


def naglowki(json_ct=True):
    h = {"Authorization": f"Key {higgsfield_dane()}"}
    if json_ct:
        h["Content-Type"] = "application/json"
    return h


def zlec(model, body):
    h = naglowki()
    h["Idempotency-Key"] = str(uuid.uuid4())
    r = zapytanie("POST", API + model, naglowki=h, json_body=body)
    dane = r.json()
    status_url = dane.get("status_url") or f"{API}/requests/{dane.get('request_id')}/status"

    def sprawdz():
        s = zapytanie("GET", status_url, naglowki=naglowki()).json()
        return s.get("status") in STANY_KONCOWE, s

    wynik_zl = czekaj(sprawdz, co_ile=5, limit_s=1200, opis="Higgsfield")
    if wynik_zl.get("status") != "completed":
        blad(f"Higgsfield zakończył ze statusem '{wynik_zl.get('status')}'. "
             + ("Prompt odrzucony przez filtr treści, zmień opis." if wynik_zl.get("status") == "nsfw" else str(wynik_zl)[:400]))
    return wynik_zl


def wyslij_plik(sciezka):
    """Wgrywa lokalny obraz do Higgsfield i zwraca publiczny URL."""
    sciezka = Path(sciezka)
    typ = mimetypes.guess_type(sciezka.name)[0] or "image/jpeg"
    up = zapytanie("POST", f"{API}/files/generate-upload-url", naglowki=naglowki(), json_body={"content_type": typ}).json()
    h = dict(up.get("upload_headers") or {})
    h.setdefault("Content-Type", typ)
    with open(sciezka, "rb") as f:
        r = requests.put(up["upload_url"], data=f, headers=h, timeout=300)
    if r.status_code >= 400:
        blad(f"Wgrywanie obrazu do Higgsfield nie powiodło się ({r.status_code}): {r.text[:300]}")
    return up["public_url"]


def obraz(prompt, wyjscie, proporcje="9:16"):
    w = zlec(MODEL_OBRAZ, {"prompt": prompt, "aspect_ratio": proporcje, "resolution": "1080p"})
    url = (w.get("images") or [{}])[0].get("url")
    if not url:
        blad(f"Higgsfield nie zwrócił obrazu: {str(w)[:300]}")
    pobierz(url, wyjscie)
    return url


def wideo(prompt, wyjscie, obraz_url=None, obraz_plik=None, dlugosc=5, proporcje="9:16"):
    if obraz_plik and not obraz_url:
        obraz_url = wyslij_plik(obraz_plik)
    if not obraz_url:
        blad("Wideo potrzebuje obrazu startowego: --obraz (plik) albo --obraz-url")
    w = zlec(MODEL_WIDEO, {"prompt": prompt, "image_url": obraz_url, "duration": 10 if dlugosc > 5 else 5,
                           "aspect_ratio": proporcje, "sound": "off"})
    url = (w.get("video") or {}).get("url") or ((w.get("videos") or [{}])[0].get("url"))
    if not url:
        blad(f"Higgsfield nie zwrócił wideo: {str(w)[:300]}")
    pobierz(url, wyjscie)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Higgsfield: obrazy i wideo AI")
    sub = p.add_subparsers(dest="tryb", required=True)
    o = sub.add_parser("obraz"); o.add_argument("--prompt", required=True); o.add_argument("--wyjscie", required=True); o.add_argument("--proporcje", default="9:16")
    v = sub.add_parser("wideo"); v.add_argument("--prompt", required=True); v.add_argument("--wyjscie", required=True)
    v.add_argument("--obraz"); v.add_argument("--obraz-url"); v.add_argument("--dlugosc", type=int, default=5); v.add_argument("--proporcje", default="9:16")
    s = sub.add_parser("scena"); s.add_argument("--prompt-obrazu", required=True); s.add_argument("--prompt-ruchu", required=True)
    s.add_argument("--wyjscie", required=True); s.add_argument("--dlugosc", type=int, default=5)
    a = p.parse_args()

    if a.tryb == "obraz":
        url = obraz(a.prompt, a.wyjscie, a.proporcje)
        wynik(plik=a.wyjscie, url=url)
    elif a.tryb == "wideo":
        wideo(a.prompt, a.wyjscie, obraz_url=a.obraz_url, obraz_plik=a.obraz, dlugosc=a.dlugosc, proporcje=a.proporcje)
        wynik(plik=a.wyjscie, koszt_orientacyjny_usd=round(0.07 * (10 if a.dlugosc > 5 else 5), 2))
    else:
        klatka = str(Path(a.wyjscie).with_suffix(".png"))
        url = obraz(a.prompt_obrazu, klatka)
        wideo(a.prompt_ruchu, a.wyjscie, obraz_url=url, dlugosc=a.dlugosc)
        wynik(plik=a.wyjscie, klatka=klatka, koszt_orientacyjny_usd=round(0.07 * (10 if a.dlugosc > 5 else 5), 2))
