"""Pobiera plik z adresu (np. wynik generowania z Magnific przez MCP) do folderu zadania.

Użycie:
  python narzedzia/pobierz.py --url "https://..." --wyjscie wyniki/X/sceny/s1.mp4
"""
import argparse

from wspolne import pobierz, wynik

if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Pobieranie pliku z adresu")
    p.add_argument("--url", required=True)
    p.add_argument("--wyjscie", required=True)
    a = p.parse_args()
    pobierz(a.url, a.wyjscie)
    wynik(plik=a.wyjscie)
