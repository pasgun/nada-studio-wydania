"""Magnific (dawny Freepik) przez REST API: stock (zdjęcia i ujęcia wideo) oraz obrazy AI (Mystic).

Użycie:
  python narzedzia/freepik.py szukaj --fraza "woman phone cafe" --typ wideo [--ile 12] [--podglady wyniki/X/podglady]
  python narzedzia/freepik.py szukaj --fraza "stock market chart" --typ zdjecia [--ile 12] [--podglady ...]
  python narzedzia/freepik.py pobierz --id 12345 --typ wideo --wyjscie wyniki/X/sceny/s2.mp4
  python narzedzia/freepik.py obraz --prompt "..." --wyjscie wyniki/X/sceny/s1.jpg     (Mystic, z kredytów)

Klucz w .env: MAGNIFIC_API_KEY (albo stara nazwa FREEPIK_API_KEY)
  magnific.com/user/organization/api-keys (logujesz się kontem administratora organizacji).
W planach Premium, Premium+ i Pro pobieranie ze stocka przez API nie zużywa kredytów,
ale jest limit 100 pobrań dziennie. Linki do pobrania wygasają po ok. 30 minutach.
"""
import argparse
import os
import zipfile
from pathlib import Path

import requests

from wspolne import blad, czekaj, pobierz, wczytaj_env, wynik, zapytanie

wczytaj_env()
HOST = os.environ.get("FREEPIK_HOST", "https://api.magnific.com").rstrip("/")
PROPORCJE = {"9:16": "social_story_9_16", "4:5": "social_post_4_5", "1:1": "square_1_1", "16:9": "widescreen_16_9"}
ROZSZ_MEDIA = {".mp4", ".mov", ".m4v", ".webm", ".jpg", ".jpeg", ".png", ".webp"}


def klucz_magnific():
    k = (os.environ.get("MAGNIFIC_API_KEY") or os.environ.get("FREEPIK_API_KEY") or "").strip()
    if not k:
        blad("Brak klucza Magnific w .env. Wpisz MAGNIFIC_API_KEY=... (magnific.com/user/organization/api-keys).")
    return k


def naglowki():
    k = klucz_magnific()
    return {"x-magnific-api-key": k, "x-freepik-api-key": k, "Content-Type": "application/json", "Accept-Language": "en-US"}


def obraz(prompt, wyjscie, proporcje, styl):
    body = {"prompt": prompt, "resolution": "2k", "aspect_ratio": PROPORCJE.get(proporcje, proporcje), "model": styl}
    r = zapytanie("POST", f"{HOST}/v1/ai/mystic", naglowki=naglowki(), json_body=body).json()
    dane = r.get("data", r)
    task = dane.get("task_id") or dane.get("id")
    if not task:
        blad(f"Magnific nie zwrócił task_id: {str(r)[:300]}")

    def sprawdz():
        s = zapytanie("GET", f"{HOST}/v1/ai/mystic/{task}", naglowki=naglowki()).json()
        d = s.get("data", s)
        return d.get("status") in ("COMPLETED", "FAILED"), d

    d = czekaj(sprawdz, co_ile=3, limit_s=600, opis="Magnific Mystic")
    if d.get("status") != "COMPLETED":
        blad(f"Magnific: generowanie nieudane ({str(d)[:300]})")
    gen = d.get("generated") or []
    url = gen[0] if gen and isinstance(gen[0], str) else (gen[0].get("url") if gen else None)
    if not url:
        blad(f"Magnific nie zwrócił adresu obrazu: {str(d)[:300]}")
    pobierz(url, wyjscie)
    wynik(plik=wyjscie)


def pierwszy_url(x):
    """Wyciąga pierwszy adres obrazka z pola miniatur (lista, słownik albo tekst)."""
    if isinstance(x, str) and x.startswith("http"):
        return x
    if isinstance(x, dict):
        for k in ("url", "source", "large", "medium", "small"):
            u = pierwszy_url(x.get(k))
            if u:
                return u
        for v in x.values():
            u = pierwszy_url(v)
            if u:
                return u
    if isinstance(x, list):
        for v in x:
            u = pierwszy_url(v)
            if u:
                return u
    return None


def szukaj(fraza, typ, ile, podglady, bez_ai):
    if typ == "wideo":
        url = f"{HOST}/v1/videos"
        params = None
        # filtr orientacji to lista; różne serwery przyjmują ją różnie, więc próbujemy po kolei (ostatnia próba bez filtra)
        for wariant in ({"filters[orientation][]": "vertical"}, {"filters[orientation][0]": "vertical"}, {}):
            p = {"term": fraza, "order": "relevance", **wariant}
            if bez_ai:
                p["filters[ai-generated][excluded]"] = "true"
            try:
                t = requests.get(url, headers=naglowki(), params=p, timeout=60)
            except requests.RequestException:
                params = p
                break
            if t.status_code == 400 and ("orientation" in t.text or "filters" in t.text):
                continue
            params = p
            break
        params = params or {"term": fraza, "order": "relevance"}
    else:
        url = f"{HOST}/v1/resources"
        params = {"term": fraza, "limit": ile, "order": "relevance",
                  "filters[content_type][photo]": 1, "filters[orientation][portrait]": 1}
        if bez_ai:
            params["filters[ai-generated][excluded]"] = 1
    r = zapytanie("GET", url, naglowki=naglowki(), params=params).json()
    wyniki = []
    for el in (r.get("data") or [])[:ile]:
        if typ == "wideo":
            miniatura = pierwszy_url(el.get("thumbnails")) or pierwszy_url(el.get("previews"))
            poz = {"id": el.get("id"), "nazwa": el.get("name"), "dlugosc": el.get("duration"),
                   "jakosc": el.get("quality"), "premium": el.get("premium"), "miniatura": miniatura}
        else:
            miniatura = pierwszy_url(el.get("image"))
            poz = {"id": el.get("id"), "nazwa": el.get("title"), "premium": any(l.get("type") == "premium" for l in el.get("licenses") or []),
                   "miniatura": miniatura}
        if podglady and miniatura:
            cel = Path(podglady) / f"{typ}_{poz['id']}.jpg"
            try:
                odp = requests.get(miniatura, timeout=60)
                if odp.ok:
                    cel.parent.mkdir(parents=True, exist_ok=True)
                    cel.write_bytes(odp.content)
                    poz["podglad_plik"] = str(cel)
            except requests.RequestException:
                pass
        wyniki.append(poz)
    if not wyniki:
        blad(f"Brak wyników dla „{fraza}”. Spróbuj innej frazy po angielsku.")
    wynik(fraza=fraza, typ=typ, wyniki=wyniki)


def rozpakuj_jesli_zip(plik, wyjscie):
    """Niektóre pozycje stocka przychodzą jako .zip; wyciągamy z nich największy plik wideo lub obraz."""
    if not zipfile.is_zipfile(plik):
        return plik
    with zipfile.ZipFile(plik) as z:
        kandydaci = [i for i in z.infolist() if Path(i.filename).suffix.lower() in ROZSZ_MEDIA]
        if not kandydaci:
            blad(f"Paczka {plik.name} nie zawiera wideo ani zdjęcia. Zawartość: {[i.filename for i in z.infolist()][:10]}")
        najw = max(kandydaci, key=lambda i: i.file_size)
        cel = Path(wyjscie).with_suffix(Path(najw.filename).suffix.lower())
        with z.open(najw) as zr, open(cel, "wb") as f:
            f.write(zr.read())
    plik.unlink()
    return cel


def pobierz_stock(id_, typ, wyjscie, rozmiar):
    if typ == "wideo":
        sciezka, params = f"{HOST}/v1/videos/{id_}/download", None
    else:
        sciezka, params = f"{HOST}/v1/resources/{id_}/download", {"image_size": rozmiar}
    r = zapytanie("GET", sciezka, naglowki=naglowki(), params=params).json()
    d = r.get("data", r)
    if isinstance(d, list):
        d = d[0] if d else {}
    url = d.get("url") or d.get("signed_url")
    if not url:
        blad(f"Magnific nie zwrócił linku do pobrania: {str(r)[:300]}")
    nazwa = d.get("filename") or ""
    wyj = Path(wyjscie)
    roboczy = wyj.with_suffix(Path(nazwa).suffix.lower() or wyj.suffix)
    pobierz(url, roboczy)
    koncowy = rozpakuj_jesli_zip(roboczy, wyj)
    wynik(plik=str(koncowy), nazwa_oryginalna=nazwa)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Magnific: stock i obrazy AI")
    sub = p.add_subparsers(dest="tryb", required=True)
    o = sub.add_parser("obraz"); o.add_argument("--prompt", required=True); o.add_argument("--wyjscie", required=True)
    o.add_argument("--proporcje", default="9:16"); o.add_argument("--styl", default="realism")
    s = sub.add_parser("szukaj"); s.add_argument("--fraza", required=True); s.add_argument("--typ", default="wideo", choices=["zdjecia", "wideo"])
    s.add_argument("--ile", type=int, default=12); s.add_argument("--podglady", help="folder na miniatury do obejrzenia")
    s.add_argument("--z-ai", action="store_true", help="dopuść materiały wygenerowane przez AI (domyślnie wykluczone)")
    d = sub.add_parser("pobierz"); d.add_argument("--id", required=True); d.add_argument("--typ", default="wideo", choices=["zdjecia", "wideo"])
    d.add_argument("--wyjscie", required=True); d.add_argument("--rozmiar", default="2000px", help="zdjęcia: small, medium, large, original albo np. 2000px")
    a = p.parse_args()
    if a.tryb == "obraz":
        obraz(a.prompt, a.wyjscie, a.proporcje, a.styl)
    elif a.tryb == "szukaj":
        szukaj(a.fraza, a.typ, a.ile, a.podglady, not a.z_ai)
    else:
        pobierz_stock(a.id, a.typ, a.wyjscie, a.rozmiar)
