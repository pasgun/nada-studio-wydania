"""Rolka „jak wzór”: rozbiór gotowej rolki (Twojej albo cudzej) na przepis do odtworzenia z Twoich materiałów.

  python narzedzia/wzor.py analizuj --plik wzor.mp4 --folder wyniki/<...>/wzor [--mowa nie|auto]

Co robi (za darmo, lokalnie):
- ujęcia: miejsca cięć, długość każdego ujęcia, średnie tempo montażu,
- arkusze kadrów: początek, środek i koniec każdego ujęcia (Claude ogląda je przez Read: kadrowanie, napisy, przejścia, grafiki),
- dźwięk: tempo muzyki i bity (bity.py), ile cięć trafia w bit, gdzie są głośne uderzenia (miejsca na efekty dźwiękowe),
- mowa (opcjonalnie): czy jest lektor albo gadająca głowa i co mówi.
Wynik: <folder>/wzor.json (+ arkusze PNG). Przepis i montaż robi Claude według skilla /jak-wzor.
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, postep, wynik  # noqa: E402


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


def info(plik):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=codec_type,width,height,r_frame_rate", "-of", "json", str(plik)],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    d = json.loads(r.stdout or "{}")
    v = next((s for s in d.get("streams", []) if s.get("codec_type") == "video"), {})
    a = any(s.get("codec_type") == "audio" for s in d.get("streams", []))
    n, m = (v.get("r_frame_rate") or "30/1").split("/")
    return {"dlugosc_s": float(d.get("format", {}).get("duration", 0)), "szer": v.get("width"), "wys": v.get("height"),
            "fps": round(float(n) / float(m or 1), 3), "dzwiek": a}


def ciecia(plik, prog=0.28):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-i", str(plik), "-vf", f"select='gt(scene,{prog})',showinfo", "-an", "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    t = []
    for linia in r.stderr.splitlines():
        if "pts_time:" in linia:
            try:
                t.append(round(float(linia.split("pts_time:")[1].split()[0]), 3))
            except ValueError:
                pass
    # bardzo bliskie „cięcia” (błyski, szybkie przejścia) liczymy jako jedno
    wyn = []
    for x in t:
        if not wyn or x - wyn[-1] > 0.15:
            wyn.append(x)
    return wyn


def arkusz(plik, czasy, cel, kol=6, szer=300):
    """Siatka kadrów z podpisem czasu (ffmpeg, bez dodatkowych bibliotek poza Pillow)."""
    from PIL import Image, ImageDraw
    import tempfile
    kadry = []
    with tempfile.TemporaryDirectory() as tmp:
        for i, t in enumerate(czasy):
            p = Path(tmp) / f"k{i}.jpg"
            subprocess.run(["ffmpeg", "-v", "error", "-y", "-ss", f"{max(0, t):.3f}", "-i", str(plik), "-frames:v", "1", "-vf", f"scale={szer}:-2", str(p)],
                           capture_output=True)
            if p.exists():
                im = Image.open(p).convert("RGB"); im.load(); kadry.append((t, im))
    if not kadry:
        return None
    w, h = kadry[0][1].size
    wiersze = (len(kadry) + kol - 1) // kol
    ark = Image.new("RGB", (kol * w, wiersze * (h + 22)), (20, 20, 20))
    d = ImageDraw.Draw(ark)
    for i, (t, im) in enumerate(kadry):
        x, y = (i % kol) * w, (i // kol) * (h + 22)
        ark.paste(im.resize((w, h)), (x, y))
        d.text((x + 6, y + h + 4), f"{t:.2f} s", fill=(230, 230, 230))
    ark.save(cel, quality=88)
    return str(cel)


def uderzenia(wav, dl):
    """Głośne, krótkie uderzenia w dźwięku (kandydaci na efekty: whoosh, hit, klik)."""
    import numpy as np
    import wave
    with wave.open(str(wav)) as w:
        sr = w.getframerate()
        x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768
    krok = int(sr * 0.02)
    k = len(x) // krok
    if k < 10:
        return []
    e = np.sqrt((x[:k * krok].reshape(k, krok) ** 2).mean(axis=1) + 1e-9)
    db = 20 * np.log10(e)
    tlo = np.convolve(db, np.ones(50) / 50, mode="same")
    kandydaci = np.where((db - tlo) > 9)[0]
    wyn = []
    for i in kandydaci:
        t = round(i * 0.02, 2)
        if not wyn or t - wyn[-1] > 0.3:
            wyn.append(t)
    return wyn[:60]


def analizuj(plik, folder, mowa="nie"):
    plik, folder = sciezka(plik), sciezka(folder)
    if not plik.exists():
        blad(f"Nie ma pliku {plik}")
    folder.mkdir(parents=True, exist_ok=True)
    inf = info(plik)
    dl = inf["dlugosc_s"]
    postep("Szukam cięć ujęć", 0.1)
    ct = [c for c in ciecia(plik) if 0.1 < c < dl - 0.1]
    granice = [0.0] + ct + [dl]
    ujecia = [{"nr": i + 1, "od": round(a, 2), "do": round(b, 2), "dl": round(b - a, 2)} for i, (a, b) in enumerate(zip(granice, granice[1:]))]
    postep("Robię arkusze kadrów", 0.35)
    czasy = []
    for u in ujecia:
        czasy += [u["od"] + 0.08, (u["od"] + u["do"]) / 2] + ([u["do"] - 0.08] if u["dl"] > 1.2 else [])
    arkusze = []
    for i in range(0, len(czasy), 36):
        a = arkusz(plik, czasy[i:i + 36], folder / f"arkusz_{i // 36 + 1:02d}.jpg")
        if a:
            arkusze.append(a)
    wynik_d = {"plik": str(plik), **inf, "ujec": len(ujecia), "srednie_ujecie_s": round(dl / max(1, len(ujecia)), 2),
               "najkrotsze_s": min((u["dl"] for u in ujecia), default=0), "najdluzsze_s": max((u["dl"] for u in ujecia), default=0),
               "ujecia": ujecia, "arkusze": arkusze}
    if inf["dzwiek"]:
        postep("Słucham muzyki: tempo i bity", 0.6)
        wav = folder / "dzwiek.wav"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(plik), "-ac", "1", "-ar", "22050", str(wav)], capture_output=True)
        mp3 = folder / "dzwiek_wzoru.mp3"
        subprocess.run(["ffmpeg", "-v", "error", "-y", "-i", str(plik), "-vn", "-b:a", "192k", str(mp3)], capture_output=True)
        r = subprocess.run([sys.executable, str(Path(__file__).resolve().parent / "bity.py"), "--plik", str(mp3)], capture_output=True, text=True, encoding="utf-8", errors="replace")
        try:
            b = json.loads(r.stdout[r.stdout.index("{"):])
        except Exception:
            b = {}
        if b.get("ok"):
            try:
                pelne = json.loads(Path(b["plik_bitow"]).read_text(encoding="utf-8"))
            except Exception:
                pelne = {}
            bity = pelne.get("bity") or []
            trafione = sum(1 for c in ct if any(abs(c - x) < 0.09 for x in bity))
            wynik_d["muzyka"] = {"tempo_bpm": b.get("bpm"), "drop_s": b.get("drop"), "bitow": len(bity),
                                 "ciecia_w_bit_proc": round(100 * trafione / max(1, len(ct))), "plik_bitow": b.get("plik_bitow")}
        wynik_d["uderzenia_s"] = uderzenia(wav, dl)
        if mowa != "nie":
            postep("Sprawdzam, czy ktoś mówi", 0.8)
            try:
                import mowa as mowa_mod
                t = mowa_mod.transkrybuj(wav, None, mowa)
                if t and t.get("slowa"):
                    (folder / "mowa_slowa.json").write_text(json.dumps(t["slowa"], ensure_ascii=False), encoding="utf-8")
                    wynik_d["mowa"] = {"slow": len(t["slowa"]), "tekst": " ".join(s["slowo"] for s in t["slowa"])[:1500]}
            except SystemExit:
                wynik_d["mowa"] = {"uwaga": "nie udało się rozpoznać mowy"}
        wav.unlink(missing_ok=True)
    (folder / "wzor.json").write_text(json.dumps(wynik_d, ensure_ascii=False, indent=1), encoding="utf-8")
    postep("Rozbiór gotowy", 1)
    skrot = {k: v for k, v in wynik_d.items() if k != "ujecia"}
    skrot["dlugosci_ujec"] = [u["dl"] for u in ujecia]
    wynik(**skrot, plik_json=str(folder / "wzor.json"),
          rada="Obejrzyj arkusze (Read): po 2–3 kadry na ujęcie, w kolejności. Zapisz przepis (przepis.md) według skilla jak-wzor.")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Rozbiór rolki-wzoru")
    sub = p.add_subparsers(dest="tryb", required=True)
    a = sub.add_parser("analizuj")
    a.add_argument("--plik", required=True); a.add_argument("--folder", required=True)
    a.add_argument("--mowa", default="nie", choices=["nie", "auto", "elevenlabs", "subtitle-edit", "lokalnie"])
    x = p.parse_args()
    analizuj(x.plik, x.folder, x.mowa)
