"""Prowadzący do miniatur i grafik: przegląd zdjęć i wycinanie osoby z tła (bez Photoshopa).

  python narzedzia/osoba.py arkusz --folder materialy/<zadanie> [--wyjscie <folder zadania>/osoba]
      arkusz kontaktowy wszystkich zdjęć z numerami (JPG, PNG, WEBP, HEIC, RAW: NEF, CR2, CR3, ARW, RAF, DNG, ORF, RW2):
      obejrzyj go (Read) i wybierz zdjęcia z pasującą miną; wynik: arkusz_1.jpg, arkusz_2.jpg... i lista plików z numerami
  python narzedzia/osoba.py wytnij --plik materialy/<zadanie>/GPU_5930.NEF --wyjscie <folder zadania>/osoba/01.png [--model ...]
      osoba wycięta z tła jako PNG z przezroczystością, przycięty do sylwetki (do "osoba" w seria.json narzędzia grafika.py)
  python narzedzia/osoba.py wytnij --pliki '["a.NEF","b.jpg"]' --folder-wyjscia <folder zadania>/osoba   (kilka naraz)

Wycinanie robi lokalnie biblioteka rembg (za darmo, bez kredytów), domyślnie najdokładniejszym modelem BiRefNet
(włosy, broda, okulary; za pierwszym razem pobiera ok. 220 MB, potrzebuje ok. 7 GB wolnej pamięci RAM; gdy jej brak,
sam bierze lżejszy model). Krawędzie zostają miękkie, poświata starego tła na włosach jest usuwana. Obok PNG zapisuje
.json z położeniem twarzy i stroną, w którą patrzy prowadzący (grafika.py kadruje po nim miniatury).
Wymaga: python -m pip install rembg onnxruntime rawpy (narzędzie doinstaluje je samo, gdy ich brak).
"""
import argparse
import importlib
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import blad, postep, wynik  # noqa: E402
from montaz import sciezka  # noqa: E402

RAW = {".nef", ".cr2", ".cr3", ".arw", ".raf", ".dng", ".orf", ".rw2", ".nrw", ".srw", ".pef"}
OBRAZY = {".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff", ".bmp", ".heic"} | RAW
PAKIETY = {"rembg": "rembg", "onnxruntime": "onnxruntime", "rawpy": "rawpy"}


def wymagaj(*nazwy):
    """Doinstalowuje brakujące biblioteki (raz), bo zadania w tle nie mogą same uruchamiać pip."""
    brak = []
    for n in nazwy:
        try:
            importlib.import_module(n)
        except ImportError:
            brak.append(PAKIETY.get(n, n))
    if not brak:
        return
    postep(f"Instaluję potrzebne biblioteki: {', '.join(brak)} (tylko za pierwszym razem)")
    r = subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", *brak], capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        blad(f"Nie udało się zainstalować {', '.join(brak)}: {r.stderr[-500:]}. Uruchom ręcznie: python -m pip install {' '.join(brak)}")
    importlib.invalidate_caches()


def wczytaj(plik, max_bok=2400, szybko=False):
    """Zdjęcie jako obraz RGB; RAW przez rawpy (szybko=True: wbudowany podgląd JPEG z aparatu, do arkusza)."""
    from PIL import Image, ImageOps
    p = sciezka(plik)
    if not p.exists():
        blad(f"Nie widzę pliku {p}")
    if p.suffix.lower() in RAW:
        wymagaj("rawpy")
        import io
        import rawpy
        with rawpy.imread(str(p)) as raw:
            img = None
            if szybko:
                try:
                    th = raw.extract_thumb()
                    if th.format == rawpy.ThumbFormat.JPEG:
                        img = ImageOps.exif_transpose(Image.open(io.BytesIO(th.data))).convert("RGB")
                except Exception:
                    img = None
            if img is None:
                rgb = raw.postprocess(use_camera_wb=True, no_auto_bright=False, output_bps=8, half_size=max_bok <= 2000)
                img = Image.fromarray(rgb)
    else:
        if p.suffix.lower() == ".heic":
            try:
                import pillow_heif
                pillow_heif.register_heif_opener()
            except ImportError:
                blad("Zdjęcia HEIC wymagają biblioteki pillow-heif: python -m pip install pillow-heif")
        img = ImageOps.exif_transpose(Image.open(p)).convert("RGB")
    img.thumbnail((max_bok, max_bok))
    return img


def lista_zdjec(folder):
    f = sciezka(folder)
    if not f.is_dir():
        blad(f"Nie ma folderu {f}")
    return sorted(x for x in f.rglob("*") if x.is_file() and x.suffix.lower() in OBRAZY and not x.name.startswith("."))


def arkusz(folder, wyjscie=None, na_arkusz=24):
    from PIL import Image, ImageDraw, ImageFont
    pliki = lista_zdjec(folder)
    if not pliki:
        blad(f"W {folder} nie ma zdjęć.")
    wyj = sciezka(wyjscie) if wyjscie else sciezka(folder) / "_arkusze"
    wyj.mkdir(parents=True, exist_ok=True)
    kol, mini = 6, 300
    try:
        font = ImageFont.truetype("arial.ttf", 22)
    except Exception:
        font = ImageFont.load_default()
    arkusze, numery = [], []
    for s in range(0, len(pliki), na_arkusz):
        cz = pliki[s:s + na_arkusz]
        rzedy = (len(cz) + kol - 1) // kol
        ark = Image.new("RGB", (kol * (mini + 8) + 8, rzedy * (mini + 8) + 8), (25, 25, 25))
        d = ImageDraw.Draw(ark)
        for i, p in enumerate(cz):
            nr = s + i + 1
            postep(f"Arkusz zdjęć: {nr}/{len(pliki)}", nr / len(pliki))
            try:
                im = wczytaj(p, 700, szybko=True)
            except SystemExit:
                raise
            except Exception:
                continue
            im.thumbnail((mini, mini))
            x, y = 8 + (i % kol) * (mini + 8), 8 + (i // kol) * (mini + 8)
            ark.paste(im, (x + (mini - im.width) // 2, y + (mini - im.height) // 2))
            d.rectangle([x, y, x + 46, y + 30], fill=(0, 0, 0))
            d.text((x + 6, y + 3), str(nr), fill=(255, 220, 0), font=font)
            numery.append({"nr": nr, "plik": str(p)})
        cel = wyj / f"arkusz_{len(arkusze) + 1}.jpg"
        ark.save(cel, quality=85)
        arkusze.append(str(cel))
    (wyj / "zdjecia.json").write_text(json.dumps(numery, ensure_ascii=False, indent=1), encoding="utf-8")
    wynik(arkusze=arkusze, zdjec=len(numery), lista=str(wyj / "zdjecia.json"),
          uwaga="Obejrzyj arkusze (Read) i wybierz numery zdjęć; potem osoba.py wytnij z plikami z listy.")


_SESJA = {}
MODELE = {
    "birefnet-general-lite": "najdokładniejszy: włosy, broda, okulary (ok. 220 MB, potrzebuje ok. 7 GB wolnej pamięci RAM)",
    "birefnet-portrait": "bardzo dokładny do portretów (ok. 1 GB, potrzebuje ponad 12 GB wolnej pamięci RAM)",
    "isnet-general-use": "szybki, słabszy na włosach (ok. 170 MB)",
    "u2net_human_seg": "tylko ludzie, najprostszy",
}
ZAPAS = "isnet-general-use"
MODEL_TWARZY = Path(__file__).resolve().parent / "modele" / "twarze_yunet.onnx"


def pamiec_gb():
    """(cała, wolna) pamięć RAM w GB albo (None, None), gdy nie da się sprawdzić."""
    try:
        if sys.platform == "win32":
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong)] + [
                    (n, ctypes.c_ulonglong) for n in ("tot", "wol", "tp", "wp", "tv", "wv", "we")]
            m = MS()
            m.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return m.tot / 2 ** 30, m.wol / 2 ** 30
        info = {l.split(":")[0]: int(l.split()[1]) for l in Path("/proc/meminfo").read_text().splitlines() if ":" in l}
        return info["MemTotal"] / 2 ** 20, info.get("MemAvailable", info["MemFree"]) / 2 ** 20
    except Exception:
        return None, None


def wybierz_model(model):
    """auto: najdokładniejszy model, gdy starczy pamięci, inaczej szybszy."""
    if model and model != "auto":
        return model
    _, wolna = pamiec_gb()
    return "birefnet-general-lite" if wolna is None or wolna >= 7 else ZAPAS


def sesja(model):
    wymagaj("rembg", "onnxruntime")
    if model not in _SESJA:
        import onnxruntime as ort
        from rembg import new_session
        o = ort.SessionOptions()
        if model.startswith("birefnet"):
            # bez tych ustawień BiRefNet zajmuje ponad 8 GB pamięci; tak mieści się w ok. 6 GB
            o.enable_cpu_mem_arena = False
            o.enable_mem_pattern = False
            o.graph_optimization_level = ort.GraphOptimizationLevel.ORT_DISABLE_ALL
        postep(f"Wczytuję model wycinania {model} (za pierwszym razem pobiera się z internetu)")
        _SESJA[model] = new_session(model, sess_opts=o)
    return _SESJA[model]


def popraw_maske(a):
    """Maska z modelu bez śmieci: zostaje sylwetka (i jej większe kawałki), drobne plamy tła znikają,
    miękkie krawędzie włosów zostają (bez twardego progowania, które robiło schodki)."""
    import cv2
    import numpy as np
    tw = (a > 127).astype(np.uint8)
    n, lab, st, _ = cv2.connectedComponentsWithStats(tw, connectivity=8)
    if n > 2:
        pola = st[1:, cv2.CC_STAT_AREA]
        zostaw = np.isin(lab, 1 + np.flatnonzero(pola >= pola.max() * 0.04)).astype(np.uint8)
    else:
        zostaw = tw
    r = max(3, int(max(a.shape) * 0.006))
    strefa = cv2.dilate(zostaw, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * r + 1, 2 * r + 1)))
    a = np.where(strefa > 0, a, 0).astype(np.uint8)
    a[a < 6] = 0
    return a


def kolor_krawedzi(rgb, a):
    """Usuwa poświatę starego tła z półprzezroczystych krawędzi (włosy), żeby na nowym tle nie było obwódki."""
    import numpy as np
    try:
        from pymatting import estimate_foreground_ml
        F = estimate_foreground_ml(rgb / 255.0, a / 255.0)
        return (F * 255).clip(0, 255).astype(np.uint8)
    except Exception:
        return rgb


def znajdz_twarz(img, a):
    """Twarz na zdjęciu (YuNet z OpenCV): ramka, oczy, nos i strona, w którą zwrócona jest głowa."""
    import cv2
    import numpy as np
    if not MODEL_TWARZY.exists() or not hasattr(cv2, "FaceDetectorYN"):
        return None
    s = min(1.0, 1280 / max(img.size))
    sm = np.array(img.resize((max(1, int(img.width * s)), max(1, int(img.height * s)))))
    try:
        det = cv2.FaceDetectorYN.create(str(MODEL_TWARZY), "", (sm.shape[1], sm.shape[0]), 0.6)
        _, tw = det.detect(cv2.cvtColor(sm, cv2.COLOR_RGB2BGR))
    except Exception:
        return None
    if tw is None:
        return None
    najl = None
    for f in tw:
        x, y, w, h = (f[:4] / s).tolist()
        cx, cy = int(min(max(x + w / 2, 0), a.shape[1] - 1)), int(min(max(y + h / 2, 0), a.shape[0] - 1))
        if a[cy, cx] < 128:
            continue  # twarz w tle (np. na ekranie), nie na wyciętej osobie
        if najl is None or w * h > najl[2] * najl[3]:
            najl = (x, y, w, h, f)
    if not najl:
        return None
    x, y, w, h, f = najl
    pkt = (f[4:14] / s).reshape(5, 2)
    oko_p, oko_l, nos = pkt[0], pkt[1], pkt[2]
    rozstaw = abs(oko_l[0] - oko_p[0]) or 1
    skret = (nos[0] - (oko_p[0] + oko_l[0]) / 2) / rozstaw
    strona = "prawo" if skret > 0.12 else "lewo" if skret < -0.12 else "prosto"
    return {"ramka": [x, y, w, h], "oczy_y": float((oko_p[1] + oko_l[1]) / 2), "patrzy": strona, "pewnosc": round(float(f[-1]), 2)}


def wytnij_jeden(plik, cel, model):
    import numpy as np
    from PIL import Image
    from rembg import remove
    img = wczytaj(plik, 3000)
    m = remove(img, session=sesja(model), only_mask=True)
    a = popraw_maske(np.array(m.convert("L")))
    rgb = kolor_krawedzi(np.array(img), a)
    out = Image.fromarray(np.dstack([rgb, a]), "RGBA")
    box = Image.fromarray(((a > 24) * 255).astype(np.uint8)).getbbox()
    if not box:
        blad(f"Nie znalazłem osoby na zdjęciu {Path(plik).name}")
    tw = znajdz_twarz(img, a)
    out = out.crop(box)
    cel = sciezka(cel)
    cel.parent.mkdir(parents=True, exist_ok=True)
    out.save(cel)
    dane = {"plik": str(cel), "zrodlo": str(plik), "szer": out.width, "wys": out.height, "model": model,
            "uciete": [k for k, v in (("dol", box[3] >= img.height - 2), ("gora", box[1] <= 1), ("lewo", box[0] <= 1),
                                      ("prawo", box[2] >= img.width - 2)) if v]}
    if tw:
        x, y, w, h = tw["ramka"]
        dane["twarz"] = {"x": round(x - box[0]), "y": round(y - box[1]), "szer": round(w), "wys": round(h),
                         "oczy_y": round(tw["oczy_y"] - box[1]), "patrzy": tw["patrzy"], "pewnosc": tw["pewnosc"]}
        # czubek głowy: najwyższy punkt sylwetki nad twarzą
        kol = a[:, int(max(x, 0)):int(min(x + w, a.shape[1]))]
        rzedy = np.flatnonzero((kol > 128).any(axis=1))
        dane["twarz"]["glowa_gora"] = int((rzedy[0] if len(rzedy) else y) - box[1])
    Path(cel).with_suffix(".json").write_text(json.dumps(dane, ensure_ascii=False, indent=1), encoding="utf-8")
    return dane


def wytnij(pliki, wyjscia, model, dziecko=False):
    model = wybierz_model(model)
    wyniki, uwagi = {}, []
    if model.startswith("birefnet") and not dziecko:
        # dokładny model w osobnym procesie: gdy zabraknie pamięci, system zamknie tylko jego, a resztę zrobi lżejszy model
        zad = json.dumps([[str(p), str(c)] for p, c in zip(pliki, wyjscia)], ensure_ascii=False)
        r = subprocess.run([sys.executable, str(Path(__file__).resolve()), "wytnij", "--zadania", zad, "--model", model, "--dziecko"],
                           stdout=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")
        try:
            for o in json.loads(r.stdout[r.stdout.index("{"):]).get("osoby", []):
                wyniki[o["zrodlo"]] = o
        except Exception:
            pass
        if len(wyniki) < len(pliki):
            uwagi.append(f"Model {model} nie dał rady (zwykle za mało wolnej pamięci RAM), "
                         f"{len(pliki) - len(wyniki)} zdjęć wyciąłem modelem {ZAPAS} (gorsze włosy). "
                         "Zamknij inne programy i wytnij je jeszcze raz.")
            model = ZAPAS
        else:
            pliki = []
    for i, (p, c) in enumerate(zip(pliki, wyjscia), 1):
        if str(p) in wyniki:
            continue
        postep(f"Wycinam osobę {i}/{len(pliki)}: {Path(p).name} ({model})", (i - 1) / len(pliki))
        wyniki[str(p)] = wytnij_jeden(p, c, model)
    osoby = list(wyniki.values())
    dane = dict(osoby=osoby, uwaga='W seria.json przy grafice: "osoba": {"plik": "<png>", "strona": "prawo"}. Obok każdego PNG '
                'leży .json z położeniem twarzy (grafika.py sam kadruje wtedy po głowie) i "patrzy": gdy prowadzący patrzy '
                'w stronę krawędzi kadru zamiast na tekst, ustaw "odbij": true. Obejrzyj każde wycięcie (Read) na pełnym podglądzie.')
    if uwagi:
        dane["uwagi"] = uwagi
    wynik(**dane)


if __name__ == "__main__":
    a = argparse.ArgumentParser(description="Prowadzący: arkusz zdjęć i wycinanie osoby z tła")
    s = a.add_subparsers(dest="tryb", required=True)
    k = s.add_parser("arkusz"); k.add_argument("--folder", required=True); k.add_argument("--wyjscie")
    w = s.add_parser("wytnij"); w.add_argument("--plik"); w.add_argument("--wyjscie"); w.add_argument("--pliki"); w.add_argument("--folder-wyjscia")
    w.add_argument("--zadania", help=argparse.SUPPRESS); w.add_argument("--dziecko", action="store_true", help=argparse.SUPPRESS)
    w.add_argument("--model", default="auto", help="auto (domyślnie: najdokładniejszy, na jaki starczy pamięci); " +
                   "; ".join(f"{k}: {v}" for k, v in MODELE.items()))
    x = a.parse_args()
    if x.tryb == "arkusz":
        arkusz(x.folder, x.wyjscie)
    else:
        if x.zadania:
            z = json.loads(x.zadania)
            wytnij([p for p, _ in z], [c for _, c in z], x.model, dziecko=x.dziecko)
        elif x.pliki:
            lista = json.loads(x.pliki)
            fw = sciezka(x.folder_wyjscia or "osoba")
            wytnij(lista, [fw / f"{i:02d}_{Path(p).stem}.png" for i, p in enumerate(lista, 1)], x.model)
        elif x.plik and x.wyjscie:
            wytnij([x.plik], [x.wyjscie], x.model)
        else:
            blad("Podaj --plik i --wyjscie albo --pliki i --folder-wyjscia.")
