"""Jedna grafika na wszystkie rozmiary (+ plik Photoshopa z artboardami).

  python narzedzia/formaty.py --plik zlecenia/<nazwa>/grafika.psd --formaty post-4x5,story-9x16,link-1200x628
         [--korekty korekty.json] [--tlumaczenia teksty_en.json --sufiks en] [--fonty klienci/<klient>/fonty]
  python narzedzia/formaty.py --plik zlecenia/<nazwa>/grafika.png --formaty ...      (płaski obraz)

PSD (najlepiej): każda warstwa najwyższego poziomu (grupa = jedna całość) trafia na swoje miejsce w nowym formacie:
tło jest kadrowane, a elementy przy krawędziach zostają przy tych krawędziach (logo w rogu zostaje w rogu),
pozostałe zachowują położenie względem środka. Teksty z warstw tekstowych są rysowane od nowa fontem z pliku
(jeśli font jest w fonty/ klienta albo w systemie), więc są ostre w każdym rozmiarze i w PSD zostają edytowalne.
Płaski PNG/JPG: grafika w całości na rozmytym tle z niej samej (bez ucinania treści).

korekty.json (gdy coś trzeba poprawić po obejrzeniu podglądu; wartości względem nowego formatu 0–1):
  {"story-9x16": {"Nagłówek": {"x": 0.08, "y": 0.62, "skala": 1.15}, "Tło": {"fokus_x": 0.4}}}
tlumaczenia.json: {"Nazwa warstwy albo oryginalny tekst": "przetłumaczony tekst"} -> wersja z dopiskiem _<sufiks>.
Wynik: <folder>/gotowe/<nazwa>_<format>.png, podglad.jpg i photoshop/seria.psd (jeden rząd, wszystkie rozmiary).
"""
import argparse
import json
import os
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, postep, wynik  # noqa: E402
import fonty  # noqa: E402
import grafika  # noqa: E402


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


_FONTY_PS = None


def font_po_nazwie_ps(nazwa, folder_klienta=None):
    """Plik fontu po nazwie z Photoshopa (np. Montserrat-ExtraBold): fonty klienta, wspólne, systemowe."""
    global _FONTY_PS
    if _FONTY_PS is None:
        _FONTY_PS = {}
        foldery = [Path(folder_klienta)] if folder_klienta else []
        foldery += [fonty.WSPOLNE_FONTY, Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts",
                    Path(os.environ.get("LOCALAPPDATA", "")) / "Microsoft" / "Windows" / "Fonts", Path("/usr/share/fonts")]
        for f in foldery:
            if not f.exists():
                continue
            for p in list(f.rglob("*.ttf")) + list(f.rglob("*.otf")):
                try:
                    _FONTY_PS.setdefault(fonty.nazwa_postscript(p).lower(), str(p))
                except Exception:
                    pass
    return _FONTY_PS.get((nazwa or "").lower())


def warstwy_psd(plik, folder_fontow):
    from psd_tools import PSDImage
    psd = PSDImage.open(plik)
    korzen = psd
    artboardy = [l for l in psd if l.kind == "artboard"]
    if artboardy:
        korzen = artboardy[0]
    x0, y0 = (korzen.bbox[0], korzen.bbox[1]) if artboardy else (0, 0)
    W0, H0 = (korzen.width, korzen.height) if artboardy else psd.size
    wyn = []
    for l in korzen:
        if not l.is_visible():
            continue
        img = l.composite()
        if img is None:
            continue
        bx0, by0, bx1, by1 = l.bbox
        el = {"nazwa": l.name, "img": img.convert("RGBA"), "x": bx0 - x0, "y": by0 - y0, "w": bx1 - bx0, "h": by1 - by0,
              "krycie": l.opacity / 255}
        if l.kind == "type":
            try:
                ss = l.engine_dict["StyleRun"]["RunArray"][0]["StyleSheet"]["StyleSheetData"]
                fs = l.resource_dict["FontSet"]
                kol = ss.get("FillColor", {}).get("Values", [1, 1, 1, 1])
                sr = l.engine_dict["StyleRun"]
                runs = []
                for dl, run in zip(sr["RunLengthArray"], sr["RunArray"]):
                    v = run["StyleSheet"]["StyleSheetData"].get("FillColor", {}).get("Values", kol)
                    runs.append((int(dl), [int(round(x * 255)) for x in v[1:4]]))
                el["tekst"] = {"tekst": l.text.replace("\r", "\n"), "font_ps": str(fs[int(ss.get("Font", 0))]["Name"]).strip("'\""),
                               "rozmiar": float(ss.get("FontSize", 24)) * float(l.transform[3] if l.transform else 1),
                               "kolor": [int(round(v * 255)) for v in kol[1:4]], "runs": runs,
                               "srodek": int(l.engine_dict["ParagraphRun"]["RunArray"][0]["ParagraphSheet"]["Properties"].get("Justification", 0)) == 2}
                el["tekst"]["plik_fontu"] = font_po_nazwie_ps(el["tekst"]["font_ps"], folder_fontow)
            except Exception:
                pass
        wyn.append(el)
    if not wyn:
        blad("W PSD nie ma widocznych warstw.")
    # tło: najniższa warstwa, która przykrywa prawie cały kadr
    for el in wyn:
        if el["w"] * el["h"] >= 0.85 * W0 * H0:
            el["tlo"] = True
            break
    return W0, H0, wyn


def kolory_znakow(t, tekst):
    """Kolor każdego znaku (fragmenty w innym kolorze, np. wyróżnione słowo). Po tłumaczeniu: kolor dominujący."""
    runs = t.get("runs") or []
    if tekst != t["tekst"] or not runs:
        if runs:
            dom = max(runs, key=lambda r: r[0])[1]
            return [tuple(dom)] * len(tekst)
        return [tuple(t["kolor"])] * len(tekst)
    wyn = []
    for dl, kol in runs:
        wyn += [tuple(kol)] * dl
    return (wyn + [tuple(t["kolor"])] * len(tekst))[:len(tekst)]


def rysuj_tekst(t, rozmiar, nowy_tekst=None):
    from PIL import Image, ImageDraw, ImageFont
    f = ImageFont.truetype(t["plik_fontu"], max(6, int(rozmiar)))
    tekst = (nowy_tekst or t["tekst"]).replace("\r", "\n")
    kolory = kolory_znakow(t, tekst)
    linie = tekst.split("\n")
    asc, desc = f.getmetrics()
    lh = int(rozmiar * 1.15)
    szer = max(int(f.getlength(l)) for l in linie) + 4
    img = Image.new("RGBA", (szer, lh * (len(linie) - 1) + asc + desc + 4), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    poz = 0
    for k, l in enumerate(linie):
        x = (szer - f.getlength(l)) / 2 if t.get("srodek") else 0
        # znaki po kolei, w kawałkach tego samego koloru
        i = 0
        while i < len(l):
            j = i
            while j < len(l) and kolory[poz + j] == kolory[poz + i]:
                j += 1
            kawalek = l[i:j]
            d.text((x + f.getlength(l[:i]), k * lh), kawalek, font=f, fill=kolory[poz + i] + (255,))
            i = j
        poz += len(l) + 1
    return img, asc, lh


def scal_runs(kolory):
    wyn = []
    for k in kolory:
        if wyn and wyn[-1]["kolor"] == list(k):
            wyn[-1]["dl"] += 1
        else:
            wyn.append({"dl": 1, "kolor": list(k)})
    return wyn


def ulozenie(el, W0, H0, W, H, kor):
    """Skala i pozycja elementu w nowym formacie (kotwica przy krawędzi albo względem środka)."""
    pas_poz, pas_pion = el["w"] >= 0.9 * W0, el["h"] >= 0.9 * H0
    if pas_poz or pas_pion:  # przyciemnienia, pasy, ramki: rozciągamy na nowy format
        sx = W / W0 if pas_poz else min(W / W0, H / H0)
        sy = H / H0 if pas_pion else min(W / W0, H / H0)
        if pas_poz and not pas_pion:
            sy = max(sy, H / H0)
        return (sx, sy), int(el["x"] * W / W0), int(el["y"] * H / H0)
    s = min(W / W0, H / H0) * float(kor.get("skala", 1))
    w, h = el["w"] * s, el["h"] * s
    if w > W * 0.94:
        s *= W * 0.94 / w
        w, h = el["w"] * s, el["h"] * s
    l, r = el["x"] / W0, (W0 - el["x"] - el["w"]) / W0
    t, b = el["y"] / H0, (H0 - el["y"] - el["h"]) / H0
    m = min(W, H) / min(W0, H0)
    if l < 0.12 and l <= r:
        x = el["x"] * m
    elif r < 0.12:
        x = W - w - (W0 - el["x"] - el["w"]) * m
    else:
        x = (el["x"] + el["w"] / 2) / W0 * W - w / 2
    if t < 0.12 and t <= b:
        y = el["y"] * m
    elif b < 0.12:
        y = H - h - (H0 - el["y"] - el["h"]) * m
    else:
        y = (el["y"] + el["h"] / 2) / H0 * H - h / 2
    if "x" in kor:
        x = float(kor["x"]) * W
    if "y" in kor:
        y = float(kor["y"]) * H
    x = min(max(x, 0), max(0, W - w))
    y = min(max(y, 0), max(0, H - h))
    return (s, s), int(x), int(y)


def grupy(warstwy, W0, H0):
    """Elementy, które na siebie zachodzą (np. przycisk i jego tekst), przesuwamy razem jako jedną grupę.
    Tło i pasy na całą szerokość/wysokość (przyciemnienia) są zawsze osobno."""
    pas = lambda w: w["w"] >= 0.9 * W0 or w["h"] >= 0.9 * H0  # noqa: E731
    el = [i for i, w in enumerate(warstwy) if not w.get("tlo")]
    rodzic = {i: i for i in el}

    def r(i):
        while rodzic[i] != i:
            i = rodzic[i]
        return i
    for a in el:
        for b in el:
            A, B = warstwy[a], warstwy[b]
            if a < b and not pas(A) and not pas(B) and A["x"] < B["x"] + B["w"] and B["x"] < A["x"] + A["w"] \
                    and A["y"] < B["y"] + B["h"] and B["y"] < A["y"] + A["h"]:
                rodzic[r(b)] = r(a)
    wyn = {}
    for i in el:
        wyn.setdefault(r(i), []).append(i)
    return list(wyn.values())


def format_psd(W0, H0, warstwy, fmt, korekty, tlum, folder_tmp):
    from PIL import Image
    W, H = grafika.FORMATY[fmt]
    kor_f = korekty.get(fmt, {})
    plotno = Image.new("RGBA", (W, H), (0, 0, 0, 255))
    opis = []
    folder_tmp.mkdir(parents=True, exist_ok=True)
    # pozycje grup: każda grupa ma wspólną skalę i przesunięcie
    poz = {}
    for g in grupy(warstwy, W0, H0):
        gx0 = min(warstwy[i]["x"] for i in g)
        gy0 = min(warstwy[i]["y"] for i in g)
        gx1 = max(warstwy[i]["x"] + warstwy[i]["w"] for i in g)
        gy1 = max(warstwy[i]["y"] + warstwy[i]["h"] for i in g)
        kor = kor_f.get(warstwy[g[0]]["nazwa"], {})
        (sx, sy), x, y = ulozenie({"x": gx0, "y": gy0, "w": gx1 - gx0, "h": gy1 - gy0}, W0, H0, W, H, kor)
        for i in g:
            poz[i] = ((sx, sy), x + int((warstwy[i]["x"] - gx0) * sx), y + int((warstwy[i]["y"] - gy0) * sy))
    for i, el in enumerate(warstwy):
        kor = kor_f.get(el["nazwa"], {})
        if el.get("tlo"):
            img = grafika.cover(el["img"], W, H, float(kor.get("fokus_x", 0.5)), float(kor.get("fokus_y", 0.5)))
            x, y, meta = 0, 0, None
        else:
            (sx, sy), x, y = poz[i]
            s = min(sx, sy)
            t = el.get("tekst")
            nowy = tlum.get(el["nazwa"]) or (tlum.get(t["tekst"]) if t else None)
            meta = None
            if t and t.get("plik_fontu"):
                img, asc, lh = rysuj_tekst(t, t["rozmiar"] * s, nowy)
                meta = {"tekst": (nowy or t["tekst"]).replace("\r", "\n"), "font": t["font_ps"], "rozmiar": int(t["rozmiar"] * s),
                        "interlinia": lh, "x": x + (img.width / 2 if t.get("srodek") else 0), "y": y + asc,
                        "wyrownanie": "center" if t.get("srodek") else "left",
                        "runs": scal_runs(kolory_znakow(t, (nowy or t["tekst"]).replace("\r", "\n")))}
            else:
                img = el["img"].resize((max(1, int(el["w"] * sx)), max(1, int(el["h"] * sy))), Image.LANCZOS)
            if el["krycie"] < 1:
                a = img.getchannel("A").point(lambda v: int(v * el["krycie"]))
                img = img.copy()
                img.putalpha(a)
        plotno.alpha_composite(img, (max(0, x), max(0, y)))
        p = folder_tmp / f"w{i:02d}.png"
        img.save(p, compress_level=1)
        opis.append({"nazwa": el["nazwa"], "plik": str(p), "x": x, "y": y, "krycie": 1.0, "tekst": meta})
    return plotno, opis


def plaski(plik, fmt, folder_tmp):
    from PIL import Image, ImageFilter, ImageEnhance
    W, H = grafika.FORMATY[fmt]
    src = Image.open(plik).convert("RGBA")
    tlo = grafika.cover(src.convert("RGB"), W, H).filter(ImageFilter.GaussianBlur(min(W, H) * 0.04))
    tlo = ImageEnhance.Brightness(tlo).enhance(0.7).convert("RGBA")
    s = min(W * 0.92 / src.width, H * 0.92 / src.height)
    fg = src.resize((int(src.width * s), int(src.height * s)), Image.LANCZOS)
    x, y = (W - fg.width) // 2, (H - fg.height) // 2
    plotno = tlo.copy()
    plotno.alpha_composite(fg, (x, y))
    folder_tmp.mkdir(parents=True, exist_ok=True)
    tlo.save(folder_tmp / "w00.png", compress_level=1)
    fg.save(folder_tmp / "w01.png", compress_level=1)
    return plotno, [{"nazwa": "Tło (rozmyte)", "plik": str(folder_tmp / "w00.png"), "x": 0, "y": 0, "krycie": 1.0, "tekst": None},
                    {"nazwa": "Grafika", "plik": str(folder_tmp / "w01.png"), "x": x, "y": y, "krycie": 1.0, "tekst": None}]


def main(plik, formaty, korekty, tlum, sufiks, folder_fontow):
    plik = sciezka(plik)
    grafika.dodaj_wlasne(formaty)
    zle = [f for f in formaty if f not in grafika.FORMATY]
    if zle:
        blad(f"Nieznane formaty: {', '.join(zle)}. Dostępne: {', '.join(grafika.FORMATY)}")
    wyj = plik.parent / "gotowe"
    wyj.mkdir(exist_ok=True)
    nazwa = plik.stem + (f"_{sufiks}" if sufiks else "")
    psd = plik.suffix.lower() in (".psd", ".psb")
    if psd:
        W0, H0, warstwy = warstwy_psd(plik, folder_fontow)
        bez_fontu = sorted({el["tekst"]["font_ps"] for el in warstwy if el.get("tekst") and not el["tekst"].get("plik_fontu")})
    pliki, opisy = [], []
    for f in formaty:
        postep(f"Format {f}")
        tmp = wyj / "_psd" / f"01_{f}"
        plotno, opis = format_psd(W0, H0, warstwy, f, korekty, tlum, tmp) if psd else plaski(plik, f, tmp)
        cel = wyj / f"{nazwa}_{grafika.SKROTY[f]}.png"
        plotno.convert("RGB").save(cel)
        pliki.append(str(cel))
        opisy.append(opis)
    podglad = wyj / f"{nazwa}_podglad.jpg"
    grafika.arkusz_podgladu([pliki], formaty, podglad)
    psd_plik, uwaga = grafika.zloz_psd(formaty, [nazwa], [opisy], [pliki], wyj)
    dane = {"pliki": pliki, "podglad": str(podglad), "photoshop": psd_plik, "warstwy": [el["nazwa"] for el in warstwy] if psd else None}
    if psd and bez_fontu:
        dane["uwaga_fonty"] = (f"Brak plików fontów: {', '.join(bez_fontu)}. Te teksty są przeskalowanym obrazem (mogą być mniej ostre) "
                               "i nie da się ich przetłumaczyć. Wrzuć fonty do fonty/ klienta i uruchom ponownie.")
    if uwaga:
        dane["uwaga_photoshop"] = uwaga
    wynik(**dane)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Jedna grafika na wszystkie rozmiary")
    p.add_argument("--plik", required=True); p.add_argument("--formaty", required=True)
    p.add_argument("--korekty"); p.add_argument("--tlumaczenia"); p.add_argument("--sufiks", default="")
    p.add_argument("--fonty")
    a = p.parse_args()
    kor = json.loads(sciezka(a.korekty).read_text(encoding="utf-8")) if a.korekty else {}
    tl = json.loads(sciezka(a.tlumaczenia).read_text(encoding="utf-8")) if a.tlumaczenia else {}
    main(a.plik, [f.strip() for f in re.split(r"[,\s]+", a.formaty) if f.strip()], kor, tl, a.sufiks, sciezka(a.fonty) if a.fonty else None)
