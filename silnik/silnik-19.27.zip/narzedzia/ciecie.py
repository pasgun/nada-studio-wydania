"""Cięcie ciszy i wpadek w sekwencji z Premiere (albo DaVinci Resolve), jak AutoCut.

Pracuje na sekwencji zapisanej jako Final Cut Pro XML (panel w Premiere robi to sam; ręcznie: Plik > Eksportuj >
Final Cut Pro XML). Oryginał zostaje nietknięty: powstaje NOWA sekwencja z cięciami na wszystkich ścieżkach naraz
(multicam, osobny dźwięk, grafiki, zagnieżdżone sekwencje, także wyłączone ścieżki) i z markerami przy wpadkach.
Zablokowane ścieżki (kłódka w Premiere) zostają bez cięć, w oryginalnej długości.

  1) python narzedzia/ciecie.py analizuj --xml sekwencja.xml --folder wyniki/<...> [--jezyk pl] [--silnik auto]
        [--audio miks.wav] [--min-pauza 0.6] [--zostaw 0.25] [--prog-ciszy -38]
     -> miks.wav (dźwięk całej sekwencji), slowa.json (mowa, mówcy), cisze.json, wpadki_auto.json,
        zdania.txt (ponumerowane zdania do sprawdzenia przez Claude'a)
  2) (opcjonalnie) Claude czyta zdania.txt + wpadki_auto.json i zapisuje wpadki.json (prompt: narzedzia/prompty/wpadki.md)
  3) python narzedzia/ciecie.py zastosuj --xml sekwencja.xml --folder wyniki/<...> [--wpadki wytnij|oznacz|pomin] [--bez-ciszy]
     -> <sekwencja>_ciecie.xml (do importu), raport.txt, transkrypcja.txt i napisy.srt nowej sekwencji

Wpadka (wpadki.json): {"od": s, "do": s, "typ": "powtorka|pomylka|przerwanie|wejscie|pauza|komentarz|halas|wtracenie|inne",
                       "opis": "...", "akcja": "wytnij|oznacz"}   (czasy w sekundach ORYGINALNEJ sekwencji)
"""
import argparse
import copy
import difflib
import json
import re
import subprocess
import sys
import tempfile
import unicodedata
import xml.etree.ElementTree as ET
from pathlib import Path
from urllib.parse import unquote, urlparse

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, postep, wynik  # noqa: E402

ELEMENTY = ("clipitem", "generatoritem")
DEFINICJE = ("file", "sequence", "multiclip")


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


# ---------- XML sekwencji ----------
def liczba(el, tag, dom=0):
    x = el.find(tag)
    try:
        return int(float(x.text)) if x is not None and x.text not in (None, "") else dom
    except ValueError:
        return dom


def fps_z(el):
    r = el.find("rate")
    if r is None:
        return 25.0
    tb = liczba(r, "timebase", 25)
    ntsc = (r.findtext("ntsc") or "").strip().upper() == "TRUE"
    return tb * 1000 / 1001 if ntsc else float(tb)


def glowna_sekwencja(root):
    s = root.find("sequence")
    if s is None:
        s = root.find(".//project/children/sequence")
    if s is None:
        s = root.find(".//sequence")
    if s is None:
        blad("W pliku XML nie ma sekwencji.")
    return s


def definicje(root):
    """Pełne definicje plików i zagnieżdżonych sekwencji (Premiere opisuje je raz, potem tylko odwołuje się po id)."""
    wyn = {}
    for el in root.iter():
        if el.tag in DEFINICJE and el.get("id") and len(el):
            wyn.setdefault((el.tag, el.get("id")), el)
    return wyn


def plik_z_url(url):
    if not url:
        return None
    u = urlparse(url)
    p = unquote(u.path if u.scheme == "file" else url)
    if re.match(r"^/[A-Za-z]:", p):  # /C:/... -> C:/...
        p = p[1:]
    return p


def zaladuj(xml):
    tree = ET.parse(sciezka(xml))
    root = tree.getroot()
    seq = glowna_sekwencja(root)
    return tree, root, seq, definicje(root), fps_z(seq)


def mapa_sciezek_audio(seq):
    """Numer ścieżki XML (od 1) -> numer ścieżki audio w Premiere (od 1). Premiere zapisuje ścieżkę stereo (i 5.1)
    jako kilka ścieżek XML, po jednej na kanał (currentExplodedTrackIndex 0, 1, ...), więc A3 w Premiere może być
    ścieżkami 5 i 6 w pliku. DaVinci i inne programy: jedna ścieżka XML = jedna ścieżka."""
    audio = seq.find("media/audio")
    wyn, nr = {}, 0
    for i, tr in enumerate(audio.findall("track") if audio is not None else [], 1):
        ex = tr.get("currentExplodedTrackIndex")
        if nr == 0 or ex is None or ex == "0":
            nr += 1
        wyn[i] = nr
    return wyn


# ---------- dźwięk sekwencji (do rozpoznania mowy) ----------
def segmenty_audio(seq, defs, od=None, do=None, przes=0.0, glebokosc=0, sciezki=None):
    """Fragmenty plików audio, które grają w sekwencji: (plik, start_w_pliku_s, start_na_osi_s, dlugosc_s, kanal).
    sciezki: numery ścieżek audio głównej sekwencji tak jak w Premiere (od 1), np. {2} = tylko mikrofon na A2
    (ścieżka stereo to w pliku XML dwie ścieżki, liczą się razem). kanal: który kanał pliku
    (np. rejestrator z dwoma mikrofonami w jednym pliku stereo), None = całość."""
    fps = fps_z(seq)
    wyn = []
    audio = seq.find("media/audio")
    if audio is None or glebokosc > 3:
        return wyn
    mapa = mapa_sciezek_audio(seq) if glebokosc == 0 else {}
    for nr_sc, tr in enumerate(audio.findall("track"), 1):
        if sciezki is not None and glebokosc == 0 and mapa.get(nr_sc, nr_sc) not in sciezki:
            continue
        if (tr.findtext("enabled") or "TRUE").upper() == "FALSE":
            continue
        for c in tr.findall("clipitem"):
            if (c.findtext("enabled") or "TRUE").upper() == "FALSE":
                continue
            s, e, i = liczba(c, "start", -1), liczba(c, "end", -1), liczba(c, "in", 0)
            if s < 0 or e < 0:
                continue
            cfps = fps_z(c) if c.find("rate") is not None else fps
            s_s, e_s, i_s = s / fps, e / fps, i / cfps
            if od is not None:  # fragment zagnieżdżonej sekwencji widoczny w nadrzędnej
                a, b = max(s_s, od), min(e_s, do)
                if b <= a:
                    continue
                i_s += a - s_s
                s_s, e_s = a, b
            f = c.find("file")
            if f is not None:
                fdef = defs.get(("file", f.get("id")), f)
                p = plik_z_url(fdef.findtext("pathurl"))
                kan = c.findtext("sourcetrack/trackindex")
                if p:
                    wyn.append((p, i_s, s_s - (od or 0) + przes, e_s - s_s, int(kan) if kan and kan.isdigit() else None))
                continue
            zag = c.find("sequence")
            if zag is not None:
                zag = defs.get(("sequence", zag.get("id")), zag)
            else:
                mc = c.find("multiclip")
                if mc is not None:  # multicam: dźwięk z pierwszego ujęcia, które go ma
                    mc = defs.get(("multiclip", mc.get("id")), mc)
                    for kat in mc.findall("clip"):
                        if kat.find("media/audio/track/clipitem") is not None:
                            zag = kat
                            break
                        wew = kat.find(".//sequence")
                        if wew is not None:
                            zag = defs.get(("sequence", wew.get("id")), wew)
                            break
            if zag is not None:
                wyn += segmenty_audio(zag, defs, i_s, i_s + (e_s - s_s), s_s - (od or 0) + przes, glebokosc + 1)
    return wyn


def zlacz_kanaly(seg):
    """Połówki jednej ścieżki stereo z Premiere (ten sam plik i miejsce, kanały 1 i 2) -> jeden fragment z całym plikiem
    (stereo zostaje stereo). Gdy obie połówki biorą ten sam kanał (np. dźwięk tylko z lewego kanału na obu
    słuchawkach), zostaje jeden fragment z tym kanałem, a nie dwa takie same."""
    grupy = {}
    for s in seg:
        grupy.setdefault((s[0], round(s[1], 3), round(s[2], 3), round(s[3], 3)), []).append(s)
    wyn = []
    for lista in grupy.values():
        kanaly = [s[4] for s in lista]
        if len(lista) == 1:
            wyn.append(lista[0])
        elif len(set(kanaly)) == 1:
            wyn.append(lista[0])
        elif None in kanaly:
            wyn.append(next(s for s in lista if s[4] is None))
        else:
            p0, src, tl, d, _ = lista[0]
            wyn.append((p0, src, tl, d, None))
    return wyn


def scal(seg):
    """Łączy kawałki, które są ciągłym fragmentem tego samego pliku (np. cięcia multicamu)."""
    seg = sorted(seg, key=lambda x: (x[0], str(x[4]), x[2]))
    wyn = []
    for s in seg:
        if wyn and wyn[-1][0] == s[0] and wyn[-1][4] == s[4] and abs(wyn[-1][2] + wyn[-1][3] - s[2]) < 0.02 and abs(wyn[-1][1] + wyn[-1][3] - s[1]) < 0.02:
            p = wyn[-1]
            wyn[-1] = (p[0], p[1], p[2], p[3] + s[3], p[4])
        else:
            wyn.append(s)
    return wyn


def ff(args, opis):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *map(str, args)], capture_output=True,
                       text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        blad(f"{opis}: {r.stderr[-800:]}")


_KANALY = {}


def kanaly(plik):
    if plik not in _KANALY:
        r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "a:0", "-show_entries", "stream=channels", "-of", "csv=p=0", plik],
                           capture_output=True, text=True, encoding="utf-8", errors="replace")
        try:
            _KANALY[plik] = int(r.stdout.strip().split(",")[0])
        except ValueError:
            _KANALY[plik] = 1
    return _KANALY[plik]


def miks(seq, defs, cel, dlugosc_s, sciezki=None, sr=16000):
    seg = scal(zlacz_kanaly(segmenty_audio(seq, defs, sciezki=sciezki)))
    brak = sorted({s[0] for s in seg if not Path(s[0]).exists()})
    seg = [s for s in seg if Path(s[0]).exists()]
    if not seg:
        blad("Nie znalazłem plików dźwięku tej sekwencji" + (f" (brak na dysku: {', '.join(brak[:3])})" if brak else "") +
             ". Wyeksportuj dźwięk ręcznie (Plik > Eksportuj > Multimedia, Waveform Audio) i podaj go w --audio.")
    tmp = Path(tempfile.mkdtemp())
    czesci = []
    for nr in range(0, len(seg), 30):  # partiami, żeby polecenie ffmpeg nie było za długie
        grupa = seg[nr:nr + 30]
        args, filtry = [], []
        for k, (p, src, tl, dl, kan) in enumerate(grupa):
            args += ["-ss", f"{src:.3f}", "-t", f"{dl:.3f}", "-i", p]
            ms = int(round(tl * 1000))
            wybor = f"pan=mono|c0=c{kan - 1}," if kan and kanaly(p) >= kan and kanaly(p) > 1 else ""
            filtry.append(f"[{k}:a]{wybor}aformat=sample_rates={sr}:channel_layouts=mono,adelay={ms}:all=1[a{k}]")
        filtry.append("".join(f"[a{k}]" for k in range(len(grupa))) + f"amix=inputs={len(grupa)}:normalize=0:duration=longest,apad,atrim=0:{dlugosc_s:.3f}[m]")
        cz = tmp / f"cz{nr:04d}.wav"
        ff([*args, "-filter_complex", ";".join(filtry), "-map", "[m]", "-ac", "1", "-ar", sr, cz], "miks dźwięku sekwencji")
        czesci.append(cz)
    if len(czesci) == 1:
        Path(czesci[0]).replace(cel)
    else:
        args = sum((["-i", c] for c in czesci), [])
        ff([*args, "-filter_complex", "".join(f"[{k}:a]" for k in range(len(czesci))) + f"amix=inputs={len(czesci)}:normalize=0:duration=longest[m]",
            "-map", "[m]", "-ac", "1", "-ar", sr, cel], "miks dźwięku sekwencji")
    for x in Path(tmp).glob("*"):
        x.unlink()
    return {"plikow": len({s[0] for s in seg}), "fragmentow": len(seg), "brak_na_dysku": brak}


# ---------- cisze ----------
def cisze_ffmpeg(audio, prog_db, min_s):
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(audio), "-af", f"silencedetect=noise={prog_db}dB:d={min_s}", "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    wyn, start = [], None
    for linia in r.stderr.splitlines():
        m = re.search(r"silence_start: (-?[\d.]+)", linia)
        if m:
            start = max(0.0, float(m.group(1)))
        m = re.search(r"silence_end: ([\d.]+)", linia)
        if m and start is not None:
            wyn.append((start, float(m.group(1))))
            start = None
    if start is not None:
        wyn.append((start, 1e9))
    return wyn


def przetnij(a, b):
    """Część wspólna dwóch list przedziałów."""
    wyn, i, j = [], 0, 0
    while i < len(a) and j < len(b):
        lo, hi = max(a[i][0], b[j][0]), min(a[i][1], b[j][1])
        if hi > lo:
            wyn.append((lo, hi))
        if a[i][1] < b[j][1]:
            i += 1
        else:
            j += 1
    return wyn


def scal_przedzialy(p, przerwa=0.0):
    wyn = []
    for a, b in sorted(p):
        if wyn and a <= wyn[-1][1] + przerwa:
            wyn[-1] = (wyn[-1][0], max(wyn[-1][1], b))
        else:
            wyn.append((a, b))
    return wyn


def znajdz_cisze(slowa, zdarzenia, audio, dl, min_pauza, zostaw, prog_db, krawedzie=True):
    """Przerwy w mowie dłuższe niż min_pauza, skracane do „zostaw” sekund; tylko tam, gdzie naprawdę jest cicho
    (śmiech, oklaski i inne dźwięki bez słów zostają)."""
    zapas = zostaw / 2
    luki = []
    if slowa:
        if krawedzie and slowa[0]["start"] > zapas + 0.05:
            luki.append((0.0, slowa[0]["start"] - zapas))
        for p, n in zip(slowa, slowa[1:]):
            if n["start"] - p["koniec"] >= min_pauza:
                luki.append((p["koniec"] + zapas, n["start"] - zapas))
        if krawedzie and dl - slowa[-1]["koniec"] > zapas + 0.05:
            luki.append((slowa[-1]["koniec"] + zapas, dl))
    cicho = cisze_ffmpeg(audio, prog_db, max(0.15, min(min_pauza, 0.3))) if audio else [(0, 1e9)]
    wyn = przetnij(sorted(luki), cicho)
    zd = [(z["start"] - 0.2, z["koniec"] + 0.2) for z in zdarzenia or []]
    wyn = [(a, b) for a, b in wyn if not any(a < zb and b > za for za, zb in zd)]
    return [(round(a, 3), round(b, 3)) for a, b in wyn if b - a >= 0.08]


# ---------- wpadki (reguły; Claude może je potem poprawić) ----------
def bez_ogonkow(t):
    return unicodedata.normalize("NFD", t.lower().replace("ł", "l")).encode("ascii", "ignore").decode()


WYZWALACZE = [
    (r"\b(wytni|wytnie|wytniemy|wytnijcie|do wyciecia|to sie wytnie|wyciac)", "komentarz", "Mówi, że coś do wycięcia"),
    (r"\b(jeszcze raz|od nowa|od poczatku|powtorze|powtorzmy|powtorzymy|zaczne jeszcze|nagram jeszcze|nagrajmy)", "powtorka", "Zapowiedź powtórki"),
    (r"\b(pomylil|pomylilam|pomylka|przejezyczy|zle powiedzial|nie tak|sorki|sorry|sory|przepraszam)", "pomylka", "Pomyłka / przeprosiny"),
    (r"\b(kurwa|kurde|cholera|pierdol|ja pierdziele|jprdl)", "pomylka", "Przekleństwo (pewnie wpadka)"),
    (r"\b(stop|ciach|cut|pauza|przerwa|chwila moment|poczekaj|poczekajcie|sekunde)\b", "komentarz", "Komentarz do nagrania"),
]
WYPELNIACZE = {"yyy", "yy", "eee", "ee", "mmm", "mm", "hmm", "eem", "yhm", "uhm", "um", "uh", "eh"}


def heurystyki(zd, zdarzenia, slowa):
    wyn = []
    for k, z in enumerate(zd):
        t = bez_ogonkow(z["tekst"])
        for wzor, typ, opis in WYZWALACZE:
            if re.search(wzor, t):
                od = z["od"]
                # „to się wytnie / jeszcze raz”: zwykle do wycięcia jest też poprzednie zdanie tego samego mówcy
                if typ in ("komentarz", "powtorka") and k > 0 and zd[k - 1]["mowca"] == z["mowca"] and z["od"] - zd[k - 1]["do"] < 4:
                    od = zd[k - 1]["od"]
                wyn.append({"od": od, "do": z["do"], "typ": typ, "opis": f"{opis}: „{z['tekst'][:80]}”", "akcja": "wytnij", "zrodlo": "reguły"})
                break
    # powtórzone zdanie albo falstart: kolejne zdanie tego samego mówcy zaczyna się tak samo
    for k in range(len(zd) - 1):
        for j in (k + 1, k + 2):
            if j >= len(zd) or zd[j]["mowca"] != zd[k]["mowca"] or zd[j]["od"] - zd[k]["do"] > 8:
                continue
            a, b = bez_ogonkow(zd[k]["tekst"]).split(), bez_ogonkow(zd[j]["tekst"]).split()
            if len(a) < 3 or len(b) < 3:
                continue
            pocz = difflib.SequenceMatcher(None, a[:6], b[:6]).ratio()
            cale = difflib.SequenceMatcher(None, a, b[:len(a) + 2]).ratio()
            if pocz >= 0.8 or cale >= 0.65:
                wyn.append({"od": zd[k]["od"], "do": zd[j]["od"] - 0.05, "typ": "powtorka",
                            "opis": f"Powtórzone zdanie, zostaje późniejsza wersja: „{zd[k]['tekst'][:70]}”", "akcja": "wytnij", "zrodlo": "reguły"})
                break
    # wtrącenia typu „yyy”
    for w in slowa:
        if bez_ogonkow(w["slowo"]).strip(".,!?…") in WYPELNIACZE and w["koniec"] - w["start"] > 0.15:
            wyn.append({"od": w["start"], "do": w["koniec"], "typ": "wtracenie", "opis": f"„{w['slowo']}”", "akcja": "wytnij", "zrodlo": "reguły"})
    # przerwanie: inny mówca wchodzi, zanim pierwszy skończył zdanie
    for p, n in zip(zd, zd[1:]):
        if p["mowca"] and n["mowca"] and p["mowca"] != n["mowca"] and p["tekst"][-1:] not in ".!?…" and n["od"] - p["do"] < 0.25:
            wyn.append({"od": max(p["od"], p["do"] - 1.5), "do": n["od"] + 1.5, "typ": "przerwanie",
                        "opis": f"Mówca {n['mowca']} wchodzi w słowo mówcy {p['mowca']}", "akcja": "oznacz", "zrodlo": "reguły"})
    for z in zdarzenia or []:
        wyn.append({"od": z["start"], "do": z["koniec"], "typ": "halas", "opis": f"Dźwięk: {z['opis']}", "akcja": "oznacz", "zrodlo": "reguły"})
    return sorted(wyn, key=lambda x: x["od"])


def tc(s):
    h, r = divmod(max(0.0, s), 3600)
    m, r = divmod(r, 60)
    return f"{int(h):02d}:{int(m):02d}:{r:04.1f}"


def analizuj(xml, folder, jezyk=None, silnik="auto", audio=None, min_pauza=0.6, zostaw=0.25, prog_db=-38, od_nowa=False, pomin=None):
    """pomin: numery ścieżek audio (od 1) do pominięcia, np. wyciszone w Premiere (przycisk M nie trafia do pliku XML)."""
    import mowa
    folder = sciezka(folder)
    folder.mkdir(parents=True, exist_ok=True)
    tree, root, seq, defs, fps = zaladuj(xml)
    dl = liczba(seq, "duration") / fps
    mix = folder / "miks.wav"
    info_miksu = {}
    pomin = sorted({int(x) for x in (pomin or [])})
    wszystkie = sorted(set(mapa_sciezek_audio(seq).values()))
    uzyte = [n for n in wszystkie if n not in pomin]
    if pomin and not uzyte:
        blad("Wszystkie ścieżki audio są wyciszone: odcisz ścieżkę z mową albo wyłącz „Pomijaj wyciszone ścieżki”.")
    plik_sc = folder / "miks_sciezki.json"
    klucz = {"pomin": pomin, "zrodlo": "premiere" if audio else "pliki"}
    poprzednie = json.loads(plik_sc.read_text(encoding="utf-8")) if plik_sc.exists() else None
    if isinstance(poprzednie, list):
        poprzednie = {"pomin": poprzednie, "zrodlo": "pliki"}
    if (poprzednie is None and mix.exists() and (pomin or audio)) or (poprzednie is not None and poprzednie != klucz):
        od_nowa = True  # inny dźwięk niż przy poprzedniej analizie (ścieżki albo źródło): mowa od nowa
    if audio:
        # dźwięk wyeksportowany przez Premiere: dokładnie to, co słychać na osi (kanały, głośności, efekty, wyciszenia)
        ff(["-i", sciezka(audio), "-ac", 1, "-ar", 16000, mix], "przygotowanie dźwięku")
        info_miksu = {"zrodlo": "premiere"}
    elif not mix.exists() or od_nowa:
        postep("Składam dźwięk całej sekwencji")
        info_miksu = miks(seq, defs, mix, dl, sciezki=set(uzyte) if pomin else None)
        info_miksu["pominiete_sciezki"] = [f"A{n}" for n in pomin]
    plik_sc.write_text(json.dumps(klucz), encoding="utf-8")
    plik_slow = folder / "slowa.json"
    if plik_slow.exists() and not od_nowa:
        dane = json.loads(plik_slow.read_text(encoding="utf-8"))
    else:
        t = mowa.transkrybuj(mix, jezyk, silnik, mowcy=True, zdarzenia=True)
        dane = {"silnik": t["silnik"], "jezyk": t["jezyk"], "slowa": t["slowa"], "zdarzenia": t["zdarzenia"]}
        plik_slow.write_text(json.dumps(dane, ensure_ascii=False, indent=0), encoding="utf-8")
    slowa = dane["slowa"]
    postep("Szukam ciszy i wpadek")
    cisze = znajdz_cisze(slowa, dane.get("zdarzenia"), mix, dl, min_pauza, zostaw, prog_db)
    (folder / "cisze.json").write_text(json.dumps(cisze), encoding="utf-8")
    zd = mowa.zdania(slowa)
    auto = heurystyki(zd, dane.get("zdarzenia"), slowa)
    (folder / "wpadki_auto.json").write_text(json.dumps(auto, ensure_ascii=False, indent=1), encoding="utf-8")
    linie = [f"Sekwencja: {seq.findtext('name')} · długość {tc(dl)} · słów {len(slowa)}", ""]
    for k, z in enumerate(zd, 1):
        linie.append(f"#{k} [{z['od']:.2f}-{z['do']:.2f} | {tc(z['od'])}] M{z['mowca'] or '?'}: {z['tekst']}")
    if dane.get("zdarzenia"):
        linie += ["", "Zdarzenia dźwiękowe:"] + [f"[{z['start']:.2f}-{z['koniec']:.2f}] {z['opis']}" for z in dane["zdarzenia"]]
    (folder / "zdania.txt").write_text("\n".join(linie) + "\n", encoding="utf-8")
    usunieto = sum(b - a for a, b in cisze)
    wynik(folder=str(folder), sekwencja=seq.findtext("name"), dlugosc_s=round(dl, 1), silnik=dane["silnik"], slow=len(slowa),
          zdan=len(zd), cisz=len(cisze), cisza_do_wyciecia_s=round(usunieto, 1), wpadek_z_regul=len(auto),
          zdania=str(folder / "zdania.txt"), miks=info_miksu)


# ---------- nowa sekwencja ----------
class Mapa:
    """Przelicza czas oryginalnej sekwencji na czas po wycięciu (w klatkach)."""

    def __init__(self, usun):
        self.usun = usun  # posortowane, rozłączne (a, b) w klatkach

    def __call__(self, t):
        przes = 0
        for a, b in self.usun:
            if t >= b:
                przes += b - a
            elif t > a:
                return a - przes
            else:
                break
        return t - przes

    def zostaje(self, s, e):
        """Fragmenty [s, e), które zostają."""
        wyn, x = [], s
        for a, b in self.usun:
            if b <= x or a >= e:
                continue
            if a > x:
                wyn.append((x, a))
            x = max(x, b)
        if x < e:
            wyn.append((x, e))
        return wyn


TICKI_NA_SEKUNDE = 254016000000  # jednostka czasu Premiere (pproTicks)


def ticki_na_klatke(el):
    r = el.find("rate")
    tb = liczba(r, "timebase", 25) if r is not None else 25
    ntsc = r is not None and (r.findtext("ntsc") or "").strip().upper() == "TRUE"
    return TICKI_NA_SEKUNDE * (1001 if ntsc else 1000) // (max(1, tb) * 1000)


def ustaw(el, tag, wartosc):
    x = el.find(tag)
    if x is None:
        x = ET.SubElement(el, tag)
    stara = liczba(el, tag, 0)
    x.text = str(int(wartosc))
    # Premiere przy imporcie wierzy dokładnym polom pproTicksIn/Out bardziej niż in/out:
    # bez ich poprawienia każdy kawałek klipu startowałby z miejsca oryginału (rozjazd obrazu i dźwięku)
    if tag in ("in", "out"):
        t = el.find("pproTicksIn" if tag == "in" else "pproTicksOut")
        if t is not None:
            try:
                st = int(float(t.text))
            except (TypeError, ValueError):
                st = None
            tpf = ticki_na_klatke(el)
            # przesunięcie o tyle klatek, o ile zmieniło się in/out (zostaje ewentualna część klatki z Premiere)
            t.text = str(st + (int(wartosc) - stara) * tpf if st is not None else int(wartosc) * tpf)


def zablokowana(track):
    return (track.findtext("locked") or "").strip().upper() == "TRUE"


def nazwa_sciezki(typ, nr):
    return ("V" if typ == "video" else "A") + str(nr)


def rozwiaz_przejscia(track, uwagi):
    """Usuwa przejścia, ustawiając cięcie w ich środku (Premiere zapisuje -1 przy klipach pod przejściem)."""
    dzieci = list(track)
    for k, el in enumerate(dzieci):
        if el.tag != "transitionitem":
            continue
        ts, te = liczba(el, "start"), liczba(el, "end")
        mid = (ts + te) // 2
        poprz = next((d for d in reversed(dzieci[:k]) if d.tag in ELEMENTY), None)
        nast = next((d for d in dzieci[k + 1:] if d.tag in ELEMENTY), None)
        if poprz is not None and liczba(poprz, "end", -1) == -1:
            s, i = liczba(poprz, "start"), liczba(poprz, "in")
            koniec = mid if nast is not None else te
            ustaw(poprz, "end", koniec)
            ustaw(poprz, "out", i + (koniec - s))
        if nast is not None and liczba(nast, "start", -1) == -1:
            poczatek = mid if poprz is not None else ts
            ustaw(nast, "start", poczatek)
            ustaw(nast, "in", liczba(nast, "in") + (poczatek - ts))
        track.remove(el)
        uwagi.add("Przejścia (np. przenikania) usunąłem w nowej sekwencji; cięcia są w ich środku.")


def tnij_sekwencje(seq, mapa, uwagi):
    nowe = {}  # stary id -> [(nowy id, nowy start)]
    for typ in ("video", "audio"):
        m = seq.find(f"media/{typ}")
        if m is None:
            continue
        mapa_a = mapa_sciezek_audio(seq) if typ == "audio" else {}
        for nr, track in enumerate(m.findall("track"), 1):
            if zablokowana(track):
                # zablokowana ścieżka zostaje jak w oryginale (użytkownik skraca ją sam)
                if any(el.tag in ELEMENTY for el in track):
                    uwagi.add(f"Ścieżka {nazwa_sciezki(typ, mapa_a.get(nr, nr))} jest zablokowana: zostawiłem ją bez cięć, w oryginalnej długości (skróć ją ręcznie).")
                continue
            rozwiaz_przejscia(track, uwagi)
            ostatni = None
            for el in list(track):
                if el.tag not in ELEMENTY:
                    continue
                s, e, i = liczba(el, "start", -1), liczba(el, "end", -1), liczba(el, "in", 0)
                idx = list(track).index(el)
                track.remove(el)
                if s < 0 or e < 0:
                    continue
                kawalki = mapa.zostaje(s, e)
                stary = el.get("id") or f"x{id(el)}"
                for k, (ps, pe) in enumerate(kawalki):
                    ns = mapa(ps)
                    # okruch krótszy niż 3 klatki (np. cięcie tuż przed zmianą kamery) doklejamy do poprzedniego klipu
                    if pe - ps < 3 and ostatni is not None and liczba(ostatni, "end", -1) == ns:
                        ustaw(ostatni, "end", ns + (pe - ps))
                        ustaw(ostatni, "out", liczba(ostatni, "out", 0) + (pe - ps))
                        continue
                    c = copy.deepcopy(el)
                    nid = stary if k == 0 else f"{stary}-c{k}"
                    c.set("id", nid)
                    ustaw(c, "start", ns)
                    ustaw(c, "end", ns + (pe - ps))
                    ustaw(c, "in", i + (ps - s))
                    ustaw(c, "out", i + (ps - s) + (pe - ps))
                    track.insert(idx, c)
                    idx += 1
                    ostatni = c
                    nowe.setdefault(stary, []).append((nid, ns, c))
    return nowe


def popraw_linki(seq, nowe):
    indeksy = {}
    zabl = set()
    for typ in ("video", "audio"):
        m = seq.find(f"media/{typ}")
        for track in (m.findall("track") if m is not None else []):
            if zablokowana(track):
                zabl.update(el.get("id") for el in track if el.tag in ELEMENTY)
    for typ in ("video", "audio"):
        m = seq.find(f"media/{typ}")
        for track in (m.findall("track") if m is not None else []):
            if zablokowana(track):
                for el in track:
                    for link in el.findall("link") if el.tag in ELEMENTY else []:
                        if link.findtext("linkclipref") not in zabl:
                            el.remove(link)
    for typ in ("video", "audio"):
        m = seq.find(f"media/{typ}")
        if m is None:
            continue
        for ti, track in enumerate(m.findall("track"), 1):
            k = 0
            for el in track:
                if el.tag in ELEMENTY:
                    k += 1
                    indeksy[el.get("id")] = (ti, k)
    for stary, kawalki in nowe.items():
        for nid, ns, el in kawalki:
            for link in el.findall("link"):
                cel = link.findtext("linkclipref")
                para = next((x for x in nowe.get(cel, []) if abs(x[1] - ns) <= 1), None)
                if para is None:
                    el.remove(link)
                    continue
                link.find("linkclipref").text = para[0]
                if para[0] in indeksy:
                    ti, ki = indeksy[para[0]]
                    for tag, w in (("trackindex", ti), ("clipindex", ki)):
                        if link.find(tag) is not None:
                            link.find(tag).text = str(w)


def napraw_definicje(root, defs):
    """Pierwsze wystąpienie pliku/sekwencji w dokumencie musi mieć pełną definicję, kolejne tylko odwołanie."""
    widziane = set()

    def odwiedz(el):
        for d in list(el):
            klucz = (d.tag, d.get("id"))
            if d.tag in DEFINICJE and d.get("id") and klucz in defs and d is not glowna:
                if klucz not in widziane:
                    widziane.add(klucz)
                    if not len(d):
                        pelna = defs[klucz]
                        for x in pelna:
                            d.append(copy.deepcopy(x))
                else:
                    for x in list(d):
                        d.remove(x)
                    continue
            odwiedz(d)
    glowna = glowna_sekwencja(root)
    odwiedz(root)


def dodaj_marker(seq, nazwa, opis, od, do=None):
    m = ET.SubElement(seq, "marker")
    ET.SubElement(m, "comment").text = opis
    ET.SubElement(m, "name").text = nazwa
    ET.SubElement(m, "in").text = str(int(od))
    ET.SubElement(m, "out").text = str(int(do)) if do is not None and do > od else "-1"


NAZWY_TYPOW = {"powtorka": "POWTÓRKA", "pomylka": "POMYŁKA", "przerwanie": "PRZERWANIE", "wejscie": "KTOŚ WCHODZI",
               "pauza": "DŁUGA PAUZA", "komentarz": "KOMENTARZ", "halas": "DŹWIĘK", "wtracenie": "YYY", "inne": "UWAGA"}


def grupy_polaczen(seq, fps):
    """Połączone klipy (obraz + dźwięk jednego ujęcia) z oryginalnej sekwencji, do ponownego połączenia po cięciu
    w Premiere (żyletka rozłącza klipy). -> lista grup [{"typ": "video|audio", "tor": 1.., "start": s, "end": s}]"""
    klipy, rodzic = {}, {}
    mapa = mapa_sciezek_audio(seq)
    for typ in ("video", "audio"):
        m = seq.find(f"media/{typ}")
        if m is None:
            continue
        for nr_xml, tr in enumerate(m.findall("track"), 1):
            nr = mapa.get(nr_xml, nr_xml) if typ == "audio" else nr_xml
            if zablokowana(tr):
                continue
            for el in tr:
                if el.tag not in ELEMENTY or not el.get("id"):
                    continue
                s, e = liczba(el, "start", -1), liczba(el, "end", -1)
                if s < 0 or e < 0:
                    continue
                klipy[el.get("id")] = {"typ": typ, "tor": nr, "start": round(s / fps, 4), "end": round(e / fps, 4), "linki": [l.findtext("linkclipref") for l in el.findall("link")]}

    def korzen(x):
        while rodzic.get(x, x) != x:
            x = rodzic[x]
        return x
    for i, k in klipy.items():
        for j in k["linki"]:
            if j in klipy and j != i:
                a, b = korzen(i), korzen(j)
                if a != b:
                    rodzic[b] = a
    grupy = {}
    for i in klipy:
        grupy.setdefault(korzen(i), []).append(i)
    wyn = []
    for g in grupy.values():
        # kanały jednej ścieżki stereo to w Premiere jeden klip: jeden wpis na ścieżkę
        czl, byly = [], set()
        for i in g:
            k = klipy[i]
            klucz = (k["typ"], k["tor"], k["start"], k["end"])
            if klucz not in byly:
                byly.add(klucz)
                czl.append({x: k[x] for x in ("typ", "tor", "start", "end")})
        if len(czl) > 1:
            wyn.append(czl)
    return wyn


def zablokowane_sciezki(seq):
    w = []
    mapa = mapa_sciezek_audio(seq)
    for typ, lit in (("video", "V"), ("audio", "A")):
        m = seq.find(f"media/{typ}")
        for nr, tr in enumerate(m.findall("track") if m is not None else [], 1):
            kod = f"{lit}{mapa.get(nr, nr) if typ == 'audio' else nr}"
            if zablokowana(tr) and kod not in w:
                w.append(kod)
    return w


def zastosuj(xml, folder, tryb_wpadek="wytnij", cisza=True, nazwa_wyniku=None):
    import mowa
    folder = sciezka(folder)
    tree, root, seq, defs, fps = zaladuj(xml)
    defs = {k: copy.deepcopy(v) for k, v in defs.items()}
    dl_kl = liczba(seq, "duration")
    cisze = json.loads((folder / "cisze.json").read_text(encoding="utf-8")) if cisza and (folder / "cisze.json").exists() else []
    plik_wpadek = folder / "wpadki.json" if (folder / "wpadki.json").exists() else folder / "wpadki_auto.json"
    wpadki = json.loads(plik_wpadek.read_text(encoding="utf-8")) if plik_wpadek.exists() and tryb_wpadek != "pomin" else []
    do_wyciecia = [(a, b) for a, b in cisze]
    oznacz = []
    for w in wpadki:
        if tryb_wpadek == "wytnij" and w.get("akcja", "wytnij") == "wytnij":
            do_wyciecia.append((float(w["od"]), float(w["do"])))
        else:
            oznacz.append(w)
    kl = lambda s: int(round(s * fps))  # noqa: E731
    usun = [(kl(a), kl(b)) for a, b in scal_przedzialy(do_wyciecia, 0.2)]
    usun = [(max(0, a), min(dl_kl, b)) for a, b in usun if b - a >= 2]
    mapa = Mapa(usun)
    uwagi = set()
    grupy = grupy_polaczen(seq, fps)
    zablokowane = zablokowane_sciezki(seq)
    nowe = tnij_sekwencje(seq, mapa, uwagi)
    popraw_linki(seq, nowe)
    napraw_definicje(root, defs)
    nowa_dl = mapa(dl_kl)
    ustaw(seq, "duration", nowa_dl)
    stara_nazwa = seq.findtext("name") or "Sekwencja"
    nowa_nazwa = nazwa_wyniku or f"{stara_nazwa} - cięcie"
    seq.find("name").text = nowa_nazwa
    u = seq.find("uuid")
    if u is not None:
        seq.remove(u)
    for m in seq.findall("marker"):  # stare markery przesuwamy razem z cięciami
        ustaw(m, "in", mapa(liczba(m, "in")))
        if liczba(m, "out", -1) >= 0:
            ustaw(m, "out", mapa(liczba(m, "out")))
    raport = [f"Sekwencja: {stara_nazwa} -> {nowa_nazwa}",
              f"Było {tc(dl_kl / fps)}, jest {tc(nowa_dl / fps)} (wycięto {tc((dl_kl - nowa_dl) / fps)}, {len(usun)} cięć).", ""]
    wpisy, markery = [], []
    for w in wpadki:
        t0 = mapa(kl(float(w["od"])))
        if w in oznacz:
            t1 = mapa(kl(float(w["do"])))
            dodaj_marker(seq, NAZWY_TYPOW.get(w.get("typ"), "UWAGA"), w.get("opis", ""), t0, t1)
            markery.append({"t": t0 / fps, "do": t1 / fps, "nazwa": NAZWY_TYPOW.get(w.get("typ"), "UWAGA"), "opis": w.get("opis", "")})
            wpisy.append((t0, f"[{tc(t0 / fps)}] ZAZNACZONE  {NAZWY_TYPOW.get(w.get('typ'), 'UWAGA')}: {w.get('opis', '')}  (oryginał {tc(float(w['od']))})"))
        else:
            dodaj_marker(seq, "WYCIĘTO: " + NAZWY_TYPOW.get(w.get("typ"), "UWAGA"), w.get("opis", ""), t0)
            markery.append({"t": t0 / fps, "do": None, "nazwa": "WYCIĘTO: " + NAZWY_TYPOW.get(w.get("typ"), "UWAGA"), "opis": w.get("opis", "")})
            wpisy.append((t0, f"[{tc(t0 / fps)}] WYCIĘTE     {NAZWY_TYPOW.get(w.get('typ'), 'UWAGA')}: {w.get('opis', '')}  (oryginał {tc(float(w['od']))}-{tc(float(w['do']))})"))
    raport += ["Wpadki (czasy w NOWEJ sekwencji):"] + [x[1] for x in sorted(wpisy)] if wpisy else ["Wpadek nie znaleziono."]
    raport += ["", f"Cisze skrócone: {len(cisze)} (łącznie {sum(b - a for a, b in cisze):.1f} s)."]
    raport += [f"Uwaga: {x}" for x in sorted(uwagi)]
    nazwa_pliku = re.sub(r"[^\w\-. ]+", "_", nowa_nazwa).strip() or "ciecie"
    cel = folder / f"{nazwa_pliku}.xml"
    ET.indent(tree, space=" ")
    tree.write(cel, encoding="UTF-8", xml_declaration=True)
    tekst = cel.read_text(encoding="utf-8")
    if "<!DOCTYPE" not in tekst:
        tekst = tekst.replace("?>", "?>\n<!DOCTYPE xmeml>", 1)
        cel.write_text(tekst, encoding="utf-8")
    (folder / "raport.txt").write_text("\n".join(raport) + "\n", encoding="utf-8")
    # transkrypcja i napisy nowej sekwencji
    sl_plik = folder / "slowa.json"
    if sl_plik.exists():
        slowa = json.loads(sl_plik.read_text(encoding="utf-8"))["slowa"]
        zostaja = []
        for w in slowa:
            a, b = kl(w["start"]), kl(w["koniec"])
            if mapa.zostaje(a, b):
                zostaja.append({**w, "start": mapa(a) / fps, "koniec": mapa(b) / fps})
        zd = mowa.zdania(zostaja)
        (folder / "transkrypcja.txt").write_text("\n".join(f"[{mowa.kod_czasowy(z['od'], fps)}] M{z['mowca'] or '?'}: {z['tekst']}" for z in zd) + "\n", encoding="utf-8")
        import transkrypcja
        transkrypcja.srt(zd, folder / "napisy.srt")
    wynik(xml=str(cel), nazwa=nowa_nazwa, raport=str(folder / "raport.txt"), bylo_s=round(dl_kl / fps, 1), jest_s=round(nowa_dl / fps, 1),
          ciec=len(usun), markerow=len(wpisy), uwagi=sorted(uwagi),
          # do cięcia w samym Premiere (zostają efekty, Lumetri, klatki kluczowe, ustawienia kanałów):
          # zakresy do usunięcia w sekundach ORYGINAŁU, markery w czasie NOWEJ sekwencji
          ciecia=[[round(a / fps, 6), round(b / fps, 6)] for a, b in usun], fps=fps, markery=markery,
          grupy=grupy, zablokowane=zablokowane,
          lista=[{"t": round(t / fps, 2), "opis": o} for t, o in sorted(wpisy)])


def tekst(folder, nazwy=""):
    """Transkrypcja całej (nieciętej) sekwencji z kodami czasowymi, z rozpoznania zrobionego przez „analizuj”."""
    import mowa
    import transkrypcja
    folder = sciezka(folder)
    dane = json.loads((folder / "slowa.json").read_text(encoding="utf-8"))
    tree, root, seq, defs, fps = zaladuj(folder / "sekwencja.xml") if (folder / "sekwencja.xml").exists() else (None, None, None, None, 25.0)
    imiona = dict(x.strip().split("=", 1) for x in nazwy.split(",") if "=" in x)
    zd = mowa.zdania(dane["slowa"])
    linie = []
    for a in transkrypcja.akapity(zd):
        kto = (imiona.get(a["mowca"]) or f"Mówca {a['mowca']}") + ": " if a["mowca"] else ""
        linie += [f"[{mowa.kod_czasowy(a['od'], fps)}] {kto}{a['tekst']}", ""]
    txt = folder / "transkrypcja_sekwencji.txt"
    txt.write_text("\n".join(linie), encoding="utf-8")
    srt = folder / "transkrypcja_sekwencji.srt"
    transkrypcja.srt(zd, srt)
    wynik(txt=str(txt), srt=str(srt), akapitow=len(linie) // 2)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Cięcie ciszy i wpadek")
    sub = p.add_subparsers(dest="tryb", required=True)
    a1 = sub.add_parser("analizuj")
    a1.add_argument("--xml", required=True); a1.add_argument("--folder", required=True); a1.add_argument("--jezyk", default=None)
    a1.add_argument("--silnik", default="auto", choices=["auto", "elevenlabs", "subtitle-edit", "lokalnie"])
    a1.add_argument("--audio"); a1.add_argument("--min-pauza", type=float, default=0.6); a1.add_argument("--zostaw", type=float, default=0.25)
    a1.add_argument("--prog-ciszy", type=float, default=-38); a1.add_argument("--od-nowa", action="store_true")
    a1.add_argument("--pomin", default="", help="numery ścieżek audio do pominięcia, np. 5,6 (wyciszone w Premiere)")
    a2 = sub.add_parser("zastosuj")
    a2.add_argument("--xml", required=True); a2.add_argument("--folder", required=True)
    a2.add_argument("--wpadki", default="wytnij", choices=["wytnij", "oznacz", "pomin"]); a2.add_argument("--bez-ciszy", action="store_true")
    a2.add_argument("--nazwa")
    a3 = sub.add_parser("tekst"); a3.add_argument("--folder", required=True); a3.add_argument("--nazwy", default="")
    a = p.parse_args()
    if a.tryb == "tekst":
        tekst(a.folder, a.nazwy)
    elif a.tryb == "analizuj":
        analizuj(a.xml, a.folder, a.jezyk or None, a.silnik, a.audio, a.min_pauza, a.zostaw, a.prog_ciszy, a.od_nowa,
                 [int(x) for x in a.pomin.replace("A", "").split(",") if x.strip().isdigit()])
    else:
        zastosuj(a.xml, a.folder, a.wpadki, not a.bez_ciszy, a.nazwa)
