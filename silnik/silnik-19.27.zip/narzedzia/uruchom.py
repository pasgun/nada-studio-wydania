"""Pomocnik dla Gemini (Antigravity CLI) w tle.

Antigravity pozwala w tle tylko na polecenia zapisane w zgodach słowo w słowo, a narzędzia silnika za każdym razem
dostają inne ustawienia. Dlatego Gemini nie uruchamia ich sam: zapisuje prośbę w pliku i wywołuje zawsze to samo
polecenie (na nie ma jedną stałą zgodę):

    python narzedzia/uruchom.py

Plik prośby (JSON) leży w folderze zadania jako polecenie_gemini.json (folder wskazuje zmienna NM_POSTEP),
a gdy jej nie ma, w _system/gemini/polecenie_gemini.json:

    {"narzedzie": "postep.py", "argumenty": ["--etap", "material", "--tekst", "Przeglądam ujęcia"]}
    albo kilka po kolei: {"polecenia": [{"narzedzie": "ffprobe", "argumenty": ["-version"]}, ...]}

Wolno uruchomić tylko narzędzia z folderu narzedzia (*.py, bez mozg.py, mcp_studio.py i panel_premiere.py) oraz ffmpeg i ffprobe. Nic innego.
Polecenie idzie bez wiersza poleceń (każdy argument osobno), więc nie da się do niego niczego dokleić.
"""
import json
import os
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import sciezki  # noqa: E402,F401  programy z apki Nada Studio w PATH

NARZEDZIA = Path(__file__).resolve().parent
SILNIK = NARZEDZIA.parent
PROGRAMY = {"ffmpeg", "ffprobe"}
# tych narzędzi Gemini nie uruchamia: ustawiają zgody, połączenia i instalację (to robi tylko użytkownik)
ZABLOKOWANE = {"uruchom.py", "mozg.py", "mcp_studio.py", "panel_premiere.py"}


def plik_prosby():
    kandydaci = []
    if os.environ.get("NM_POSTEP"):
        kandydaci.append(Path(os.environ["NM_POSTEP"]).parent / "polecenie_gemini.json")
    kandydaci.append(SILNIK / "_system" / "gemini" / "polecenie_gemini.json")
    kandydaci.append(SILNIK / "wyniki" / "_gemini" / "polecenie_gemini.json")  # stare miejsce
    for k in kandydaci:
        if k.exists():
            return k
    return None


def sprawdz(p):
    if not isinstance(p, dict):
        raise ValueError("każde polecenie to obiekt {\"narzedzie\": ..., \"argumenty\": [...]}")
    n = str(p.get("narzedzie") or "").strip()
    arg = p.get("argumenty", [])
    if isinstance(arg, str):
        raise ValueError("argumenty podaj jako listę, każdy osobno, np. [\"--etap\", \"material\"]")
    if not isinstance(arg, list) or not all(isinstance(a, (str, int, float)) for a in arg):
        raise ValueError("argumenty muszą być listą tekstów")
    arg = [str(a) for a in arg]
    nazwa = n.replace("\\", "/").split("/")[-1]
    if n.replace("\\", "/") not in (nazwa, "narzedzia/" + nazwa):
        raise ValueError(f"narzędzie podaj samą nazwą pliku z folderu narzedzia (np. postep.py), nie ścieżką: {n}")
    if nazwa in PROGRAMY or nazwa.lower() in ("ffmpeg.exe", "ffprobe.exe"):
        return [nazwa.lower().replace(".exe", "")] + arg
    if nazwa in ZABLOKOWANE:
        raise ValueError(f"{nazwa} uruchamia tylko użytkownik (zgody, połączenia, instalacja)")
    if not nazwa.endswith(".py") or not (NARZEDZIA / nazwa).is_file():
        raise ValueError(f"nie ma takiego narzędzia silnika: {n} (wolno: narzędzia z folderu narzedzia, ffmpeg, ffprobe)")
    return [sys.executable, str(NARZEDZIA / nazwa)] + arg


def main():
    plik = plik_prosby()
    if not plik:
        print(json.dumps({"ok": False, "blad": "Brak pliku prośby polecenie_gemini.json (w folderze zadania albo w _system/gemini/)."}, ensure_ascii=False))
        return 2
    try:
        d = json.loads(plik.read_text(encoding="utf-8-sig"))
        lista = d["polecenia"] if isinstance(d, dict) and "polecenia" in d else [d]
        polecenia = [sprawdz(p) for p in lista]
    except Exception as e:
        print(json.dumps({"ok": False, "blad": f"Zła prośba w {plik.name}: {e}"}, ensure_ascii=False))
        return 2
    # prośba zużyta: przenosimy ją, żeby nie wykonać jej drugi raz przez pomyłkę
    try:
        plik.replace(plik.with_name(f"polecenie_gemini_{time.strftime('%H%M%S')}.wykonane.json"))
    except Exception:
        pass
    kod = 0
    for i, cmd in enumerate(polecenia, 1):
        opis = " ".join(Path(c).name if j < 2 and c.endswith((".py", ".exe")) else c for j, c in enumerate(cmd))
        print(f"[uruchom {i}/{len(polecenia)}] {opis}", flush=True)
        try:
            r = subprocess.run(cmd, cwd=str(SILNIK), env=dict(os.environ, PYTHONIOENCODING="utf-8"))
            kod = r.returncode
        except FileNotFoundError:
            print(f"[uruchom] nie znalazłem programu {cmd[0]}", flush=True)
            kod = 127
        print(f"[uruchom {i}/{len(polecenia)}] kod wyjścia: {kod}", flush=True)
        if kod != 0:
            break
    return kod


if __name__ == "__main__":
    sys.exit(main())
