"""Rozpoznawanie mowy: słowa z czasem, mówcy i zdarzenia dźwiękowe. Wspólne dla analizy nagrań, napisów,
transkrypcji i cięcia wpadek.

Silniki (wybór „auto”):
- elevenlabs: ElevenLabs Scribe, rozpoznaje mówców i zdarzenia (śmiech, drzwi, telefon); kredyty ElevenLabs
- subtitle-edit: Whisper zainstalowany razem z Subtitle Edit (Purfview Faster-Whisper albo whisper.cpp); za darmo, lokalnie
- lokalnie: faster-whisper z Pythona (python -m pip install faster-whisper); za darmo, lokalnie
Auto: gdy potrzebni mówcy albo nagranie ma do 10 minut -> ElevenLabs (jeśli jest klucz); dłuższe -> Whisper lokalnie.

  python narzedzia/mowa.py --plik nagranie.mp4 [--jezyk pl] [--silnik auto] [--mowcy] [--wyjscie slowa.json]
  python narzedzia/mowa.py --silniki       (pokazuje, które silniki są dostępne na tym komputerze)

Format słowa: {"slowo": "Cześć,", "start": 0.12, "koniec": 0.48, "mowca": "1"}; zdarzenie: {"opis": "śmiech", "start": .., "koniec": ..}
"""
import argparse
import glob
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, postep, wczytaj_env, wynik  # noqa: E402

LIMIT_ELEVENLABS_S = 600


def audio_mono(plik, cel=None, wav=False):
    """Mono 16 kHz do rozpoznawania (mp3 dla ElevenLabs, wav dla Whispera)."""
    cel = Path(cel) if cel else Path(tempfile.mkdtemp()) / ("mowa.wav" if wav else "mowa.mp3")
    args = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(plik), "-vn", "-ac", "1", "-ar", "16000"]
    args += (["-c:a", "pcm_s16le"] if wav else ["-b:a", "64k"]) + [str(cel)]
    r = subprocess.run(args, capture_output=True, text=True, encoding="utf-8", errors="replace")
    return cel if r.returncode == 0 and cel.exists() else None


def dlugosc(plik):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(plik)],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    try:
        return float(r.stdout.strip())
    except ValueError:
        return 0.0


# ---------- silniki ----------
def ma_klucz_elevenlabs():
    wczytaj_env()
    return bool(os.environ.get("ELEVENLABS_API_KEY", "").strip())


def elevenlabs(audio, jezyk=None, mowcy=False, zdarzenia=False):
    import requests
    wczytaj_env()
    dane = {"model_id": "scribe_v2", "timestamps_granularity": "word", "tag_audio_events": "true" if zdarzenia else "false",
            "diarize": "true" if mowcy else "false"}
    if jezyk:
        dane["language_code"] = jezyk
    with open(audio, "rb") as f:
        r = requests.post("https://api.elevenlabs.io/v1/speech-to-text", headers={"xi-api-key": os.environ.get("ELEVENLABS_API_KEY", "")},
                          data=dane, files={"file": (Path(audio).name, f, "audio/mpeg")}, timeout=3600)
    if r.status_code >= 400:
        blad(f"ElevenLabs rozpoznawanie mowy HTTP {r.status_code}: {r.text[:400]}")
    d = r.json()
    slowa, zd = [], []
    mapa = {}
    for w in d.get("words", []):
        t = (w.get("text") or "").strip()
        if not t:
            continue
        if w.get("type") == "audio_event":
            zd.append({"opis": t.strip("()[] "), "start": round(w["start"], 3), "koniec": round(w["end"], 3)})
            continue
        if w.get("type") != "word":
            continue
        s = {"slowo": t, "start": round(w["start"], 3), "koniec": round(w["end"], 3)}
        if w.get("speaker_id"):
            mapa.setdefault(w["speaker_id"], str(len(mapa) + 1))
            s["mowca"] = mapa[w["speaker_id"]]
        slowa.append(s)
    return {"silnik": "elevenlabs", "jezyk": d.get("language_code"), "slowa": slowa, "zdarzenia": zd}


def whisper_subtitle_edit():
    """Szuka Whispera zainstalowanego przez Subtitle Edit. Zwraca (rodzaj, exe, folder_modeli) albo None."""
    korzenie = [os.environ.get("APPDATA", ""), os.environ.get("LOCALAPPDATA", ""), os.environ.get("ProgramFiles", ""),
                os.environ.get("ProgramFiles(x86)", ""), str(Path.home())]
    for k in [x for x in korzenie if x]:
        for baza in glob.glob(os.path.join(k, "Subtitle Edit*", "Whisper")) + glob.glob(os.path.join(k, "*", "Subtitle Edit*", "Whisper")):
            for wzor in ("**/faster-whisper-xxl.exe", "**/whisper-faster.exe", "**/faster-whisper.exe"):
                for exe in glob.glob(os.path.join(baza, wzor), recursive=True):
                    return ("faster", exe, str(Path(exe).parent / "_models"))
            for exe in glob.glob(os.path.join(baza, "**", "whisper-cli.exe"), recursive=True) + glob.glob(os.path.join(baza, "**", "main.exe"), recursive=True):
                modele = sorted(glob.glob(os.path.join(Path(exe).parent, "**", "ggml-*.bin"), recursive=True), key=os.path.getsize)
                if modele:
                    return ("cpp", exe, modele[-1])
    return None


def subtitle_edit(audio_wav, jezyk=None):
    se = whisper_subtitle_edit()
    if not se:
        return None
    rodzaj, exe, modele = se
    wyj = Path(tempfile.mkdtemp())
    if rodzaj == "faster":
        dostepne = sorted(p.name.replace("faster-whisper-", "") for p in Path(modele).glob("*") if p.is_dir()) if Path(modele).exists() else []
        model = next((m for m in ("large-v3", "large-v3-turbo", "large-v2", "medium", "small") if m in dostepne), dostepne[-1] if dostepne else "large-v2")
        args = [exe, str(audio_wav), "--model", model, "--output_format", "json", "--output_dir", str(wyj), "--word_timestamps", "True"]
        if Path(modele).exists():
            args += ["--model_dir", modele]
        if jezyk:
            args += ["--language", jezyk]
        postep(f"Whisper z Subtitle Edit ({model}) rozpoznaje mowę, to może potrwać")
        r = subprocess.run(args, capture_output=True, text=True, encoding="utf-8", errors="replace")
        pliki = list(wyj.glob("*.json"))
        if r.returncode != 0 or not pliki:
            postep("Whisper z Subtitle Edit nie zadziałał: " + (r.stderr or r.stdout)[-300:])
            return None
        d = json.loads(pliki[0].read_text(encoding="utf-8"))
        slowa = []
        for seg in d.get("segments", []):
            for w in seg.get("words") or []:
                t = (w.get("word") or "").strip()
                if t:
                    slowa.append({"slowo": t, "start": round(float(w["start"]), 3), "koniec": round(float(w["end"]), 3)})
        return {"silnik": f"Whisper z Subtitle Edit ({model})", "jezyk": d.get("language") or jezyk, "slowa": slowa, "zdarzenia": []}
    # whisper.cpp: -ml 1 = jedno słowo na wpis
    args = [exe, "-m", modele, "-f", str(audio_wav), "-oj", "-ml", "1", "-of", str(wyj / "wynik")]
    if jezyk:
        args += ["-l", jezyk]
    postep("whisper.cpp z Subtitle Edit rozpoznaje mowę, to może potrwać")
    r = subprocess.run(args, capture_output=True, text=True, encoding="utf-8", errors="replace")
    plik = wyj / "wynik.json"
    if r.returncode != 0 or not plik.exists():
        postep("whisper.cpp nie zadziałał: " + (r.stderr or r.stdout)[-300:])
        return None
    d = json.loads(plik.read_text(encoding="utf-8", errors="replace"))
    slowa = []
    for wpis in d.get("transcription", []):
        t = (wpis.get("text") or "").strip()
        o = wpis.get("offsets") or {}
        if t:
            slowa.append({"slowo": t, "start": round(o.get("from", 0) / 1000, 3), "koniec": round(o.get("to", 0) / 1000, 3)})
    return {"silnik": "whisper.cpp z Subtitle Edit", "jezyk": jezyk, "slowa": slowa, "zdarzenia": []}


def faster_whisper_dostepny():
    try:
        import faster_whisper  # noqa: F401
        return True
    except ImportError:
        return False


def faster_whisper(audio, jezyk=None):
    try:
        import site
        for sp in site.getsitepackages() + [site.getusersitepackages()]:
            for bib in Path(sp).glob("nvidia/*/bin"):
                os.add_dll_directory(str(bib))
                os.environ["PATH"] = str(bib) + os.pathsep + os.environ.get("PATH", "")
    except Exception:
        pass
    from faster_whisper import WhisperModel
    try:
        model = WhisperModel(os.environ.get("WHISPER_MODEL", "large-v3"), device="cuda", compute_type="float16")
        gdzie = "karta graficzna"
    except Exception:
        model = WhisperModel("medium", device="cpu", compute_type="int8")
        gdzie = "procesor"
    segmenty, inf = model.transcribe(str(audio), language=jezyk or None, word_timestamps=True, vad_filter=True)
    slowa = []
    for s in segmenty:
        for w in s.words or []:
            if w.word.strip():
                slowa.append({"slowo": w.word.strip(), "start": round(w.start, 3), "koniec": round(w.end, 3)})
    return {"silnik": f"faster-whisper lokalnie ({gdzie})", "jezyk": inf.language, "slowa": slowa, "zdarzenia": []}


def silniki():
    se = whisper_subtitle_edit()
    return {"elevenlabs": ma_klucz_elevenlabs(), "subtitle-edit": se[1] if se else None, "lokalnie": faster_whisper_dostepny()}


def transkrybuj(plik, jezyk=None, silnik="auto", mowcy=False, zdarzenia=False):
    """Główna funkcja: plik audio lub wideo -> słowa z czasem (i mówcy/zdarzenia, gdy ElevenLabs)."""
    plik = Path(plik)
    dl = dlugosc(plik)
    if silnik == "auto":
        if ma_klucz_elevenlabs() and (mowcy or zdarzenia or dl <= LIMIT_ELEVENLABS_S):
            silnik = "elevenlabs"
        elif whisper_subtitle_edit():
            silnik = "subtitle-edit"
        elif faster_whisper_dostepny():
            silnik = "lokalnie"
        elif ma_klucz_elevenlabs():
            silnik = "elevenlabs"
        else:
            blad("Brak silnika rozpoznawania mowy: dodaj ELEVENLABS_API_KEY do .env albo zainstaluj Whisper (Subtitle Edit lub faster-whisper).")
    wyn = None
    if silnik == "subtitle-edit":
        wav = audio_mono(plik, wav=True)
        wyn = subtitle_edit(wav, jezyk) if wav else None
        if not wyn and faster_whisper_dostepny():
            silnik = "lokalnie"
        elif not wyn and ma_klucz_elevenlabs():
            silnik = "elevenlabs"
        elif not wyn:
            blad("Whisper z Subtitle Edit nie zadziałał, a innego silnika brak.")
    if wyn is None and silnik == "lokalnie":
        wav = audio_mono(plik, wav=True)
        postep("Whisper lokalnie rozpoznaje mowę, to może potrwać")
        wyn = faster_whisper(wav, jezyk)
    if wyn is None:
        postep(f"ElevenLabs rozpoznaje mowę ({dl / 60:.1f} min)")
        mp3 = audio_mono(plik)
        if not mp3:
            blad(f"Nie udało się wyciągnąć dźwięku z {plik.name}")
        wyn = elevenlabs(mp3, jezyk, mowcy, zdarzenia)
    wyn["dlugosc_s"] = round(dl, 2)
    wyn["minuty"] = round(dl / 60, 2)
    return wyn


# ---------- zdania i kody czasowe ----------
def zdania(slowa, pauza=0.8):
    """Słowa -> zdania (koniec po kropce/pytajniku, zmianie mówcy albo pauzie)."""
    wyn, biez = [], []
    for i, w in enumerate(slowa):
        if biez and (w.get("mowca") != biez[-1].get("mowca") or w["start"] - biez[-1]["koniec"] > pauza):
            wyn.append(biez)
            biez = []
        biez.append(w)
        if w["slowo"][-1:] in ".!?…":
            wyn.append(biez)
            biez = []
    if biez:
        wyn.append(biez)
    return [{"od": z[0]["start"], "do": z[-1]["koniec"], "mowca": z[0].get("mowca"), "tekst": " ".join(x["slowo"] for x in z),
             "slowa": z} for z in wyn]


def kod_czasowy(s, fps=None, start_tc=0.0):
    s = max(0.0, s + start_tc)
    h, r = divmod(s, 3600)
    m, r = divmod(r, 60)
    if fps:
        sek = int(r)
        kl = int(round((r - sek) * fps))
        if kl >= round(fps):
            sek, kl = sek + 1, 0
        return f"{int(h):02d}:{int(m):02d}:{sek:02d}:{kl:02d}"
    return f"{int(h):02d}:{int(m):02d}:{int(r):02d}"


def zapisz_slowa(slowa, plik):
    linie = [json.dumps(w, ensure_ascii=False) for w in slowa]
    Path(plik).write_text("[\n" + ",\n".join(linie) + "\n]\n", encoding="utf-8")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Rozpoznawanie mowy")
    p.add_argument("--plik"); p.add_argument("--jezyk", default=None)
    p.add_argument("--silnik", default="auto", choices=["auto", "elevenlabs", "subtitle-edit", "lokalnie"])
    p.add_argument("--mowcy", action="store_true"); p.add_argument("--zdarzenia", action="store_true")
    p.add_argument("--wyjscie"); p.add_argument("--silniki", action="store_true")
    a = p.parse_args()
    if a.silniki:
        wynik(**silniki())
    else:
        if not a.plik:
            blad("Podaj --plik")
        pl = Path(a.plik)
        pl = pl if pl.is_absolute() else KATALOG_SILNIKA / pl
        w = transkrybuj(pl, a.jezyk, a.silnik, a.mowcy, a.zdarzenia)
        cel = Path(a.wyjscie) if a.wyjscie else pl.with_name(pl.stem + "_slowa.json")
        zapisz_slowa(w["slowa"], cel)
        wynik(silnik=w["silnik"], jezyk=w["jezyk"], slow=len(w["slowa"]), zdarzen=len(w["zdarzenia"]), plik=str(cel), minuty=w["minuty"])
