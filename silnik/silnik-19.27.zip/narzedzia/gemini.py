"""Gemini (Nano Banana): obrazy AI.

Domyślnie przez Antigravity CLI (agy) z limitów abonamentu Google AI Pro, bez płatnego API (narzedzia/obraz_agy.py).
Płatne API z klucza Google AI Studio tylko, gdy narzedzia/obrazy_ustawienia.json ma {"silnik": "api"}.

Użycie:
  python narzedzia/gemini.py obraz --prompt "..." --wyjscie wyniki/X/sceny/s1.png [--proporcje 9:16] [--model ...]
  python narzedzia/gemini.py modele      (lista modeli obrazowych dostępnych dla Twojego klucza)
  python narzedzia/gemini.py grafika --plan nb.json   (cała grafika z Nano Banana w każdym formacie + arkusz podglądu)

obraz: --obrazy logo.png zdjecie.jpg = obrazy wejściowe (logo, zdjęcie produktu, wzór stylu), które model ma użyć;
       --px 1200x628 = przytnij i przeskaluj wynik dokładnie do tych pikseli (dowolny format z grafika.py).

Plan dla „grafika” (JSON):
  {"folder": "wyniki/X", "formaty": ["post-4x5", "story-9x16"], "model": "(opcjonalnie)",
   "wspolne": "opis stylu marki: kolory #.., font, nastrój (po angielsku)", "obrazy": ["klienci/x/logo/logo_biale.png"],
   "logo": "klienci/x/logo/logo_biale.png", "logo_miejsce": "prawy-dol",   (prawdziwe logo naklejane po wygenerowaniu; miejsca: lewy-gora, prawy-gora, lewy-dol, prawy-dol, srodek-dol)
   "grafiki": [{"nazwa": "promo1", "prompt": "co jest na grafice i jaki tekst (po angielsku, tekst w cudzysłowie po polsku)",
                "obrazy": ["materialy/x/foto1.jpg"]}]}
  -> <folder>/<nazwa>_<format>.png, <folder>/podglad_serii.jpg
  Przy grafice "od_nowa": true (albo lista formatów) = zrób od nowa tylko te; --brakujace = tylko brakujące obrazy.
  Styl ze Studio (zadanie.styl w zadanie.json obok) narzędzie stosuje samo: przy "referencje"/"tylko_referencje" dokłada
  obrazy z klienci/<folder>/referencje/grafiki i każe kopiować ich wygląd; "bez_logo" wyłącza logo.
  Przez Antigravity robi kilka obrazów naraz ("rownolegle" w narzedzia/obrazy_ustawienia.json, domyślnie 2).
  Gdy model odda zły kształt, obraz nie jest przycinany (ucięłoby tekst), tylko wpasowany z rozmytym tłem (lista "z_tlem").

Klucz w .env: GEMINI_API_KEY (aistudio.google.com -> Get API key).
Opcjonalnie GEMINI_MODEL, domyślnie gemini-nano-banana-2.1.
Abonament Gemini nie obejmuje API. Google AI Pro daje jednak co miesiąc kredyty Google Cloud
(przez Google Developer Program), które można przypisać do płatności za API.
"""
import argparse
import base64
import os

from wspolne import blad, klucz, wczytaj_env, wynik, zapytanie

API = "https://generativelanguage.googleapis.com/v1beta"
MODEL_DOMYSLNY = "gemini-nano-banana-2.1"
ZAPASOWY_GENERATE = "gemini-2.5-flash-image"


def znajdz_obraz(dane):
    """Szuka w odpowiedzi pierwszego obrazu zapisanego jako base64 (różne wersje API mają różne pola)."""
    if isinstance(dane, dict):
        for k in ("output_image", "inlineData", "inline_data", "image"):
            v = dane.get(k)
            if isinstance(v, dict) and isinstance(v.get("data"), str) and len(v["data"]) > 100:
                return v["data"], v.get("mime_type") or v.get("mimeType")
        if isinstance(dane.get("data"), str) and len(dane["data"]) > 1000 and "image" in str(dane.get("mime_type", dane.get("mimeType", "image"))):
            return dane["data"], dane.get("mime_type") or dane.get("mimeType")
        for v in dane.values():
            w = znajdz_obraz(v)
            if w:
                return w
    elif isinstance(dane, list):
        for v in dane:
            w = znajdz_obraz(v)
            if w:
                return w
    return None


def przez_interactions(prompt, model, proporcje, rozmiar):
    body = {"model": model, "input": prompt,
            "response_format": {"type": "image", "mime_type": "image/png", "aspect_ratio": proporcje, "image_size": rozmiar}}
    import requests
    r = requests.post(f"{API}/interactions", headers={"x-goog-api-key": klucz("GEMINI_API_KEY"), "Content-Type": "application/json"},
                      json=body, timeout=300)
    return r


def czesci_obrazow(obrazy):
    """Obrazy wejściowe jako części zapytania (base64), zmniejszone do 1600 px, żeby zapytanie nie było za duże."""
    import io
    from PIL import Image
    czesci = []
    for p in obrazy or []:
        if not p or not os.path.exists(p):
            blad(f"Nie ma pliku obrazu wejściowego: {p}")
        im = Image.open(p)
        im.thumbnail((1600, 1600))
        b = io.BytesIO()
        przezr = im.mode in ("RGBA", "LA", "P")
        (im.convert("RGBA") if przezr else im.convert("RGB")).save(b, "PNG" if przezr else "JPEG", quality=92)
        czesci.append({"inline_data": {"mime_type": "image/png" if przezr else "image/jpeg", "data": base64.b64encode(b.getvalue()).decode()}})
    return czesci


def przez_generate(prompt, model, proporcje, obrazy=None):
    body = {"contents": [{"parts": [*czesci_obrazow(obrazy), {"text": prompt}]}],
            "generationConfig": {"responseModalities": ["IMAGE"], "imageConfig": {"aspectRatio": proporcje}}}
    r = zapytanie("POST", f"{API}/models/{model}:generateContent",
                  naglowki={"x-goog-api-key": klucz("GEMINI_API_KEY"), "Content-Type": "application/json"}, json_body=body, timeout=300)
    return r.json()


PROPORCJE = {"1:1": 1, "2:3": 2 / 3, "3:2": 1.5, "3:4": 0.75, "4:3": 4 / 3, "4:5": 0.8, "5:4": 1.25, "9:16": 9 / 16, "16:9": 16 / 9, "21:9": 21 / 9}


def najblizsze_proporcje(w, h):
    r = w / h
    return min(PROPORCJE, key=lambda k: abs(PROPORCJE[k] - r) / PROPORCJE[k])


def dopasuj_px(plik, W, H, tolerancja=0.12):
    """Dopasowuje obraz dokładnie do W×H pikseli. Gdy kształt prawie się zgadza: przycięcie od środka.
    Gdy model oddał inny kształt (np. kwadrat zamiast pionu): NIE przycina (ucięłoby tekst), tylko wpasowuje cały obraz
    i wypełnia brzegi rozmytym, przyciemnionym tłem z tego samego obrazu. Zwraca "przyciete" albo "z_tlem"."""
    from PIL import Image, ImageFilter, ImageEnhance
    im = Image.open(plik).convert("RGB")
    r_ob, r_cel = im.width / im.height, W / H
    if abs(r_ob - r_cel) / r_cel <= tolerancja:
        s = max(W / im.width, H / im.height)
        im = im.resize((max(W, round(im.width * s)), max(H, round(im.height * s))), Image.LANCZOS)
        x, y = (im.width - W) // 2, (im.height - H) // 2
        im.crop((x, y, x + W, y + H)).save(plik)
        return "przyciete"
    s = max(W / im.width, H / im.height)
    tlo = im.resize((max(W, round(im.width * s)), max(H, round(im.height * s))), Image.LANCZOS)
    x, y = (tlo.width - W) // 2, (tlo.height - H) // 2
    tlo = tlo.crop((x, y, x + W, y + H)).filter(ImageFilter.GaussianBlur(max(W, H) / 40))
    tlo = ImageEnhance.Brightness(tlo).enhance(0.55)
    s = min(W / im.width, H / im.height)
    przod = im.resize((max(1, round(im.width * s)), max(1, round(im.height * s))), Image.LANCZOS)
    tlo.paste(przod, ((W - przod.width) // 2, (H - przod.height) // 2))
    tlo.save(plik)
    return "z_tlem"


def obraz(prompt, wyjscie, proporcje, model, rozmiar, obrazy=None, px=None, cicho=False):
    if px:
        proporcje = najblizsze_proporcje(*px)
    import obraz_agy
    if obraz_agy.silnik() == "agy":
        # domyślnie: Nano Banana przez Antigravity, z limitów abonamentu Google AI Pro (bez płatnego API)
        w = obraz_agy.generuj(prompt, wyjscie, proporcje, obrazy)
        if not w.get("plik"):
            blad("Nano Banana przez Antigravity: " + (w.get("blad") or "brak obrazu")
                 + " Sprawdź: python narzedzia\\obraz_agy.py test. Płatne API włączysz w narzedzia\\obrazy_ustawienia.json: {\"silnik\": \"api\"}.")
        if px:
            dopasuj_px(wyjscie, *px)
        if cicho:
            return {"plik": wyjscie, "proporcje": proporcje}
        wynik(plik=wyjscie, silnik="antigravity (abonament Google AI Pro)", proporcje=proporcje, px=f"{px[0]}x{px[1]}" if px else None)
        return
    dane, r = None, None
    if obrazy:
        # z obrazami wejściowymi (logo, zdjęcie): klasyczne generateContent, które je na pewno przyjmuje
        dane = przez_generate(prompt, model if "nano-banana" not in model else ZAPASOWY_GENERATE, proporcje, obrazy)
    else:
        r = przez_interactions(prompt, model, proporcje, rozmiar)
    if r is None:
        pass
    elif r.status_code < 400:
        dane = r.json()
    elif r.status_code in (400, 404):
        # starsze konta lub modele: klasyczne generateContent
        dane = przez_generate(prompt, model if "nano-banana" not in model else ZAPASOWY_GENERATE, proporcje)
    elif r.status_code == 429:
        blad("Gemini: limit zapytań lub brak środków na koncie API (429). Sprawdź płatności w AI Studio.")
    else:
        blad(f"Gemini HTTP {r.status_code}: {r.text[:500]}")
    w = znajdz_obraz(dane)
    if not w:
        blad(f"Gemini nie zwrócił obrazu (możliwe odrzucenie przez filtr treści). Odpowiedź: {str(dane)[:400]}")
    data, mime = w
    os.makedirs(os.path.dirname(os.path.abspath(wyjscie)), exist_ok=True)
    with open(wyjscie, "wb") as f:
        f.write(base64.b64decode(data))
    if px:
        dopasuj_px(wyjscie, *px)
    if cicho:
        return {"plik": wyjscie, "proporcje": proporcje}
    wynik(plik=wyjscie, model=model, typ=mime, proporcje=proporcje, px=f"{px[0]}x{px[1]}" if px else None)


def naklej_logo(plik, logo, miejsce="prawy-dol"):
    """Prawdziwe logo klienta na gotowej grafice: wysokość 10–16% krótszego boku (najwyżej ćwierć szerokości), margines 5%."""
    from PIL import Image
    if not os.path.exists(logo):
        blad(f"Nie ma pliku logo: {logo}")
    im = Image.open(plik).convert("RGBA")
    lg = Image.open(logo).convert("RGBA")
    bok = min(im.width, im.height)
    s = min(bok * (0.1 if lg.width > lg.height * 2 else 0.16) / max(1, lg.height), im.width * 0.24 / max(1, lg.width))
    lg = lg.resize((max(1, round(lg.width * s)), max(1, round(lg.height * s))), Image.LANCZOS)
    m = round(bok * 0.05)
    x = m if "lewy" in miejsce else (im.width - lg.width) // 2 if "srodek" in miejsce else im.width - lg.width - m
    y = m if "gora" in miejsce else im.height - lg.height - m
    im.alpha_composite(lg, (x, y))
    im.convert("RGB").save(plik)


def _zadanie_obok(folder):
    """zadanie.json zadania (w folderze grafik, wyżej albo w Materiały/): stąd styl ze Studio."""
    import json
    from pathlib import Path
    f = Path(folder).resolve()
    for d in [f, *list(f.parents)[:3]]:
        for k in (d / "zadanie.json", d / "Materiały" / "zadanie.json", d / "zadanie_panel.json"):
            if k.exists():
                try:
                    return json.loads(k.read_text(encoding="utf-8-sig"))
                except Exception:
                    pass
    return {}


def _styl_z_zadania(plan, folder):
    """Styl ze Studio („Styl tego zadania”) wymuszony w kodzie, niezależnie od tego, co mózg wpisał w nb.json:
    przy referencjach dokłada obrazy z klienci/<folder>/referencje/grafiki i każe kopiować ich wygląd."""
    from pathlib import Path
    from wspolne import KATALOG_SILNIKA
    zad = _zadanie_obok(folder)
    z = zad.get("zadanie", zad) if isinstance(zad, dict) else {}
    styl = plan.get("styl") or z.get("styl") or {}
    if not isinstance(styl, dict):
        styl = {}
    zrodlo, opis = styl.get("zrodlo") or "marka", (styl.get("opis") or "").strip()
    kl = (zad.get("klient") or {}) if isinstance(zad, dict) else {}
    refy = []
    if zrodlo in ("referencje", "tylko_referencje") and kl.get("folder"):
        rf = KATALOG_SILNIKA / kl["folder"] / "referencje" / "grafiki"
        if rf.exists():
            refy = sorted([str(p) for p in rf.iterdir() if p.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp")])[:4]
    glowa = ""
    if opis:
        glowa += f"STYLE REQUIRED BY THE USER (most important, overrides everything else): {opis}\n"
    if zrodlo == "tylko_referencje":
        glowa += ("STYLE: copy the look of the attached reference images as closely as possible: layout, typography (serif or sans, "
                  "weights, sizes, colors of text), backgrounds, boxes, frames, hand-drawn circles or markers, colors and their level "
                  "of polish or kitsch. Do NOT apply any other brand colors, fonts or 'premium' look. Do not make it cleaner or more "
                  "elegant than the references. The references define only the look; the text and subject come from this prompt.\n")
    elif zrodlo == "referencje":
        glowa += ("STYLE: follow the look of the attached reference images (layout, typography, backgrounds, colors, level of polish); "
                  "brand details below only where the references do not decide.\n")
    elif zrodlo == "opis" and not opis:
        pass
    wspolne = plan.get("wspolne", "")
    if zrodlo in ("tylko_referencje", "opis") and wspolne:
        wspolne = "Content and layout notes (ignore any colors, fonts or style words in these notes): " + wspolne
    return {"glowa": glowa, "wspolne": wspolne, "refy": refy, "zrodlo": zrodlo, "bez_logo": bool(styl.get("bez_logo"))}


def grafika(plan_plik, brakujace=False):
    """Cała seria grafik z Nano Banana: każda grafika w każdym formacie, z logo i zdjęciami jako obrazami wejściowymi.
    Przez Antigravity kilka obrazów naraz (ustawienie "rownolegle" w obrazy_ustawienia.json, domyślnie 2).
    Nieudany obraz: jedna ponowna próba; zamiast cudzego obrazu zostaje brak na liście "brakuje".
    "od_nowa": true albo lista formatów przy grafice = zrób tylko te od nowa (reszta istniejących zostaje);
    --brakujace = zrób tylko obrazy, których jeszcze nie ma."""
    import json
    import threading
    import time as _t
    from concurrent.futures import ThreadPoolExecutor
    from wspolne import postep
    import grafika as gr
    import obraz_agy
    plan = json.loads(open(plan_plik, encoding="utf-8").read())
    folder = plan.get("folder") or os.path.dirname(os.path.abspath(plan_plik))
    if not os.path.isabs(folder):
        from wspolne import KATALOG_SILNIKA
        folder = os.path.join(str(KATALOG_SILNIKA), folder)
    os.makedirs(folder, exist_ok=True)
    formaty = gr.dodaj_wlasne(plan.get("formaty") or ["post-4x5"])
    model = plan.get("model") or os.environ.get("GEMINI_MODEL", MODEL_DOMYSLNY)
    grafiki = plan.get("grafiki") or []
    if not grafiki:
        blad("Plan nie ma listy „grafiki”.")
    for f in formaty:
        if f not in gr.FORMATY:
            blad(f"Nieznany format {f}. Dostępne: {', '.join(gr.FORMATY)} albo wlasny-SZERxWYS")
    st = _styl_z_zadania(plan, folder)
    logo = None if (st["bez_logo"] or plan.get("logo") is False) else plan.get("logo")
    wybrane = any(g.get("od_nowa") for g in grafiki)
    zadania = []
    for g in grafiki:
        for f in formaty:
            cel = os.path.join(folder, f"{g.get('nazwa', 'grafika')}_{gr.SKROTY.get(f, f)}.png")
            on = g.get("od_nowa")
            if os.path.exists(cel) and ((wybrane and not (on is True or (isinstance(on, list) and f in on))) or brakujace):
                continue
            zadania.append((g, f, cel))
    agy = obraz_agy.silnik() == "agy"
    ile_naraz = max(1, min(4, int(obraz_agy.ustawienia().get("rownolegle", 2)))) if agy else 1
    zamek, licz = threading.Lock(), {"n": 0, "stop": False}
    wyniki, brakuje, z_tlem = [], [], []
    miejsce = (plan.get("logo_miejsce") or "prawy-dol").replace("lewy", "left").replace("prawy", "right").replace("srodek", "center").replace("gora", "top").replace("dol", "bottom").replace("-", " ")

    def jeden(z):
        g, f, cel = z
        W, H = gr.FORMATY[f]
        kier = "vertical (portrait)" if H > W * 1.05 else "horizontal (landscape)" if W > H * 1.05 else "square"
        prop = najblizsze_proporcje(W, H)
        prompt = (st["glowa"] + f"{g['prompt']}\n\nDesign a finished social media graphic, {kier} format {W}x{H} px, aspect ratio {prop}. "
                  "Compose everything for this exact frame and keep all text at least 7% away from every edge. "
                  + f"{st['wspolne']}\n"
                  "Keep all text exactly as given in quotes, correct Polish spelling and diacritics, large and readable. "
                  + (f"Leave a clean, calm empty area in the {miejsce} corner for the brand logo (it is added later); do not draw any logo yourself. " if logo else "")
                  + "No other logos, no watermarks.")
        obrazy = (plan.get("obrazy") or []) + (g.get("obrazy") or [])
        obrazy += [r for r in st["refy"] if r not in obrazy]
        bl = None
        for proba in range(2):
            if licz["stop"]:
                return
            if agy:
                w = obraz_agy.generuj(prompt, cel, prop, obrazy)
                if w.get("plik"):
                    tryb = dopasuj_px(cel, W, H)
                    bl = None
                    break
                bl = w.get("blad")
                if w.get("limit"):
                    licz["stop"] = True
                    break
                _t.sleep(15)
            else:
                try:
                    obraz(prompt, cel, "1:1", model, plan.get("rozmiar", "2K"), obrazy, (W, H), cicho=True)
                    tryb, bl = "przyciete", None
                    break
                except SystemExit:
                    bl = "Gemini API nie zwróciło obrazu"
        with zamek:
            licz["n"] += 1
            postep(f"Nano Banana: {g.get('nazwa')} {f} ({licz['n']}/{len(zadania)})", licz["n"] / max(1, len(zadania)))
            if bl:
                brakuje.append({"grafika": g.get("nazwa"), "format": f, "blad": bl})
                return
            if tryb == "z_tlem":
                z_tlem.append(f"{g.get('nazwa')}_{gr.SKROTY.get(f, f)}")
        if logo:
            naklej_logo(cel, logo, plan.get("logo_miejsce") or "prawy-dol")

    start = _t.time()
    with ThreadPoolExecutor(ile_naraz) as ex:
        list(ex.map(jeden, zadania))
    for g in grafiki:
        for f in formaty:
            cel = os.path.join(folder, f"{g.get('nazwa', 'grafika')}_{gr.SKROTY.get(f, f)}.png")
            if os.path.exists(cel) and not any(b["grafika"] == g.get("nazwa") and b["format"] == f for b in brakuje):
                wyniki.append({"grafika": g.get("nazwa"), "format": f, "plik": cel})
    pliki = wyniki
    # arkusz podglądu: rząd = grafika, kolumny = formaty
    from PIL import Image
    wys = 360
    wiersze = []
    for g in grafiki:
        ob = [Image.open(p["plik"]).convert("RGB") for p in pliki if p["grafika"] == g.get("nazwa")]
        ob = [o.resize((max(1, round(o.width * wys / o.height)), wys)) for o in ob]
        if not ob:
            continue
        w = Image.new("RGB", (sum(o.width for o in ob) + 16 * (len(ob) + 1), wys + 32), (30, 30, 30))
        x = 16
        for o in ob:
            w.paste(o, (x, 16))
            x += o.width + 16
        wiersze.append(w)
    podglad = os.path.join(folder, "podglad_serii.jpg")
    if wiersze:
        ark = Image.new("RGB", (max(w.width for w in wiersze), sum(w.height for w in wiersze)), (30, 30, 30))
        y = 0
        for w in wiersze:
            ark.paste(w, (0, y))
            y += w.height
        ark.save(podglad, quality=88)
    uw = "Grafiki z Nano Banana są płaskimi obrazami (tekst nie jest edytowalny w Photoshopie). Obejrzyj podgląd: model czasem przekręci litery."
    if z_tlem:
        uw += f" Model oddał zły kształt dla {len(z_tlem)} obrazów: wpasowałem je w całości z rozmytym tłem po bokach, zamiast przycinać tekst ({', '.join(z_tlem)}); jeśli wygląda słabo, zrób je od nowa (\"od_nowa\")."
    if brakuje:
        uw += f" Brakuje {len(brakuje)} obrazów (lista „brakuje”): " + ("Antigravity zgłosił wyczerpany limit obrazów, " if licz["stop"] else "") + \
              "uruchom to samo z --brakujace, gdy limit wróci; nie podstawiaj innych plików."
    wynik(pliki=pliki, liczba=len(pliki), podglad=podglad if wiersze else None, model="antigravity" if agy else model,
          styl=st["zrodlo"], referencje=st["refy"], brakuje=brakuje, z_tlem=z_tlem, naraz=ile_naraz,
          minuty=round((_t.time() - start) / 60, 1), uwaga=uw)


def modele():
    r = zapytanie("GET", f"{API}/models", naglowki={"x-goog-api-key": klucz("GEMINI_API_KEY")}, params={"pageSize": 200})
    nazwy = [m.get("name", "").replace("models/", "") for m in r.json().get("models", [])]
    wynik(modele_obrazowe=[n for n in nazwy if "image" in n or "banana" in n or "imagen" in n])


if __name__ == "__main__":
    wczytaj_env()
    p = argparse.ArgumentParser(description="Gemini: obrazy AI")
    sub = p.add_subparsers(dest="tryb", required=True)
    o = sub.add_parser("obraz")
    o.add_argument("--prompt", required=True); o.add_argument("--wyjscie", required=True)
    o.add_argument("--proporcje", default="9:16", help="9:16, 4:5, 1:1, 16:9")
    o.add_argument("--model", default=os.environ.get("GEMINI_MODEL", MODEL_DOMYSLNY))
    o.add_argument("--rozmiar", default="2K", help="1K, 2K, 4K")
    o.add_argument("--obrazy", nargs="*", default=None, help="obrazy wejściowe: logo, zdjęcie produktu, wzór stylu")
    o.add_argument("--px", default=None, help="dokładny rozmiar wyniku, np. 1200x628")
    sub.add_parser("modele")
    g = sub.add_parser("grafika")
    g.add_argument("--plan", required=True)
    g.add_argument("--brakujace", action="store_true", help="zrób tylko obrazy, których jeszcze nie ma w folderze")
    a = p.parse_args()
    if a.tryb == "obraz":
        px = tuple(int(x) for x in a.px.lower().split("x")) if a.px else None
        obraz(a.prompt, a.wyjscie, a.proporcje, a.model, a.rozmiar, a.obrazy, px)
    elif a.tryb == "grafika":
        grafika(a.plan, a.brakujace)
    else:
        modele()
