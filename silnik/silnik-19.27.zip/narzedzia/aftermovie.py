"""Materiał do aftermovie prosto z osi czasu Premiere (panel eksportuje sekwencję do XML).

  python narzedzia/aftermovie.py material --xml <sekwencja.xml> --folder wyniki/<...> [--mowa nie|auto|elevenlabs|lokalnie]

Co robi:
- czyta, jakie klipy leżą na osi czasu (ścieżki do plików na dysku i fragmenty od–do, które zostawiłeś),
- klipy tylko z dźwiękiem (bez obrazu) traktuje jako muzykę, którą chcesz użyć,
- robi analizę każdego klipu (arkusze kadrów, cięcia ujęć, przy --mowa także transkrypcję wywiadów),
- zapisuje <folder>/material_premiere.json i wypisuje krótkie podsumowanie.

Pliki RAW (BRAW, R3D) analizuje przez proksy. Szuka ich po kolei: proksy podpięte w Premiere (proksy.json w folderze
zadania, zapisuje go panel), podfolder _proksy obok oryginału, foldery z proksy z proksy.json albo narzedzia/proksy_foldery.json
(z podfolderami; nazwa proksy zaczyna się od nazwy oryginału, np. A039_C001_Proxy.mp4). Timeline dla Premiere i tak wskazuje oryginały.
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import blad, postep, wynik  # noqa: E402
import ciecie  # noqa: E402

SUROWE = {".braw", ".r3d", ".ari", ".crm"}
OBRAZY = {".png", ".jpg", ".jpeg", ".webp", ".psd", ".tif", ".tiff"}


def ma_obraz(defn):
    return defn is not None and defn.find("media/video") is not None


def zbierz(xml):
    tree, root, seq, defs, fps = ciecie.zaladuj(xml)
    klipy, muzyka = {}, {}

    def plik_klipu(c):
        f = c.find("file")
        if f is None:
            return None, None
        d = defs.get(("file", f.get("id")), f)
        return ciecie.plik_z_url(d.findtext("pathurl")), d

    for typ in ("video", "audio"):
        m = seq.find(f"media/{typ}")
        if m is None:
            continue
        for tr in m.findall("track"):
            if (tr.findtext("enabled") or "TRUE").upper() == "FALSE":
                continue
            for c in tr.findall("clipitem"):
                if (c.findtext("enabled") or "TRUE").upper() == "FALSE":
                    continue
                plik, d = plik_klipu(c)
                if not plik:
                    continue
                od = ciecie.liczba(c, "in", 0) / fps
                do = ciecie.liczba(c, "out", 0) / fps
                na_osi = ciecie.liczba(c, "start", 0) / fps
                if typ == "video":
                    k = klipy.setdefault(plik, {"plik": plik, "zakresy": [], "na_osi_s": na_osi})
                    k["zakresy"].append([round(od, 2), round(do, 2)])
                    k["na_osi_s"] = min(k["na_osi_s"], na_osi)
                elif not ma_obraz(d) and plik not in klipy:
                    mz = muzyka.setdefault(plik, {"plik": plik, "zakresy": []})
                    mz["zakresy"].append([round(od, 2), round(do, 2)])
    # dźwięk z klipów wideo nie jest muzyką
    for p in list(muzyka):
        if p in klipy:
            muzyka.pop(p)
    for k in klipy.values():
        k["zakresy"] = [list(x) for x in ciecie.scal_przedzialy([tuple(z) for z in k["zakresy"]], 0.5)]
    lista = sorted(klipy.values(), key=lambda k: k["na_osi_s"])
    return seq.findtext("name") or "Sekwencja", fps, lista, list(muzyka.values())


WIDEO = {".mp4", ".mov", ".mxf", ".m4v"}
PROKSY = {"mapa": {}, "foldery": [], "indeks": None}


def ustaw_proksy(folder):
    """Proksy z panelu (folder zadania/proksy.json) i wspólna lista folderów z proksy."""
    import re
    d = {}
    try:
        d = json.loads((Path(folder) / "proksy.json").read_text(encoding="utf-8"))
    except Exception:
        pass
    foldery = list(d.get("foldery") or [])
    try:
        foldery += json.loads((Path(__file__).resolve().parent / "proksy_foldery.json").read_text(encoding="utf-8"))
    except Exception:
        pass
    norm = lambda x: re.sub(r"[\\/]+", "/", str(x)).lower()
    PROKSY["mapa"] = {norm(k): v for k, v in (d.get("mapa") or {}).items() if v}
    PROKSY["foldery"] = [f for f in dict.fromkeys(foldery) if f and Path(f).is_dir()]
    PROKSY["brak"] = [f for f in dict.fromkeys(foldery) if f and not Path(f).is_dir()]
    PROKSY["norm"] = norm
    PROKSY["indeks"] = None


def _indeks():
    """Wszystkie pliki wideo z folderów z proksy (z podfolderami), raz na uruchomienie."""
    if PROKSY["indeks"] is None:
        idx = []
        for f in PROKSY["foldery"]:
            for x in Path(f).rglob("*"):
                if x.suffix.lower() in WIDEO and x.is_file() and "_analiza" not in x.parts:
                    idx.append(x)
        PROKSY["indeks"] = idx
    return PROKSY["indeks"]


def do_analizy(plik):
    """Plik, który da się przeanalizować (dla RAW: jego proksy)."""
    import re
    p = Path(plik)
    if p.suffix.lower() not in SUROWE:
        return p
    norm = PROKSY.get("norm") or (lambda x: str(x).lower())
    m = PROKSY["mapa"].get(norm(plik))
    if m and Path(m).exists():
        return Path(m)
    for e in (".mp4", ".mov", ".MP4", ".MOV"):
        x = p.parent / "_proksy" / (p.stem + e)
        if x.exists():
            return x
    pasuje = []
    for x in _indeks():
        st = x.stem.lower()
        if st == p.stem.lower() or (st.startswith(p.stem.lower()) and re.fullmatch(r"[ _\-.]*(proxy|proksy|prx)?[ _\-.\d]*", st[len(p.stem):])):
            pasuje.append(x)
    if pasuje:
        # dokładna nazwa przed „_Proxy”, a przy kilku: najnowszy plik
        pasuje.sort(key=lambda x: (x.stem.lower() != p.stem.lower(), -x.stat().st_mtime))
        return pasuje[0]
    return None


def material(xml, folder, mowa="nie", jezyk=None):
    import analiza
    folder = Path(folder) if Path(folder).is_absolute() else ciecie.sciezka(folder)
    folder.mkdir(parents=True, exist_ok=True)
    ustaw_proksy(folder)
    nazwa, fps, klipy, muzyka = zbierz(xml)
    if not klipy:
        blad("Na osi czasu nie ma klipów wideo. Wrzuć nagrania na timeline (mogą być nieprzycięte) i uruchom ponownie.")
    brak = [k["plik"] for k in klipy if not Path(k["plik"]).exists()]
    if brak:
        blad("Nie widzę tych plików na dysku (offline w Premiere?): " + "; ".join(brak[:5]))
    bez_proksy = [Path(k["plik"]).name for k in klipy if do_analizy(k["plik"]) is None]
    if bez_proksy:
        gdzie = ", ".join(PROKSY["foldery"]) or "brak ustawionych folderów"
        blad("Pliki RAW bez proksy: " + ", ".join(bez_proksy[:6]) + (" (i inne)" if len(bez_proksy) > 6 else "") +
             f". Szukałem: proksy podpięte w Premiere, podfolder _proksy obok nagrań, foldery z proksy ({gdzie})" +
             (f"; tych folderów nie ma na dysku: {', '.join(PROKSY['brak'])}" if PROKSY.get("brak") else "") +
             ". Nazwa proksy musi zaczynać się od nazwy oryginału (np. A039_C001_Proxy.mp4). Folder z proksy wskażesz w panelu: Aftermovie > Pliki RAW i proksy.")
    for i, k in enumerate(klipy):
        postep(f"Analiza klipu {i + 1} z {len(klipy)}: {Path(k['plik']).name}", ulamek=i / len(klipy))
        a = analiza.analizuj(do_analizy(k["plik"]), mowa, jezyk)
        k["analiza"] = str(Path(do_analizy(k["plik"])).parent / "_analiza" / (Path(do_analizy(k["plik"])).stem + ".json"))
        if str(do_analizy(k["plik"])) != str(k["plik"]):
            k["proksy"] = str(do_analizy(k["plik"]))
        k["dlugosc_pliku_s"] = a.get("dlugosc_s")
        k["pion"] = a.get("pion")
        k["dzwiek"] = a.get("dzwiek")
        k["arkusze"] = [x["plik"] for x in a.get("arkusze", [])]
        if a.get("mowa"):
            k["mowa"] = {"slowa_plik": a["mowa"]["slowa_plik"], "liczba_slow": a["mowa"]["liczba_slow"],
                         "poczatek": " / ".join(f["tekst"] for f in a["mowa"]["frazy"][:3])[:200]}
    # mapa proksy -> oryginał: montaż pracuje na proksy, a eksport do Premiere wskaże oryginały
    nowe = {k["proksy"]: k["plik"] for k in klipy if k.get("proksy")}
    if nowe:
        import porzadek
        mp = porzadek.system("proksy") / "mapa.json"
        try:
            stare = json.loads(mp.read_text(encoding="utf-8"))
        except Exception:
            stare = {}
        stare.update(nowe)
        mp.parent.mkdir(parents=True, exist_ok=True)
        mp.write_text(json.dumps(stare, ensure_ascii=False, indent=1), encoding="utf-8")
    postep("Materiał przejrzany", ulamek=1)
    minut = sum(z[1] - z[0] for k in klipy for z in k["zakresy"]) / 60
    dane = {"sekwencja": nazwa, "fps": fps, "klipy": klipy, "muzyka_z_osi": muzyka, "minut_materialu": round(minut, 1)}
    cel = folder / "material_premiere.json"
    cel.write_text(json.dumps(dane, ensure_ascii=False, indent=1), encoding="utf-8")
    wynik(plik=str(cel), sekwencja=nazwa, klipow=len(klipy), minut_materialu=round(minut, 1),
          muzyka_z_osi=[Path(m["plik"]).name for m in muzyka],
          z_mowa=sum(1 for k in klipy if k.get("mowa")),
          arkuszy=sum(len(k["arkusze"]) for k in klipy),
          rada="Obejrzyj arkusze (Read) i trzymaj się zakresów 'zakresy' każdego klipu: to fragmenty, które zostawił użytkownik. "
               "Gdy klip ma pole 'proksy' (pliki RAW), w planie montażu jako plik sceny podaj właśnie je; eksport do Premiere sam wskaże oryginał.")


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Materiał do aftermovie z osi czasu Premiere")
    sub = p.add_subparsers(dest="tryb", required=True)
    m = sub.add_parser("material")
    m.add_argument("--xml", required=True)
    m.add_argument("--folder", required=True)
    m.add_argument("--mowa", default="nie", choices=["nie", "auto", "elevenlabs", "subtitle-edit", "lokalnie"])
    m.add_argument("--jezyk", default=None)
    a = p.parse_args()
    material(a.xml, a.folder, a.mowa, a.jezyk)
