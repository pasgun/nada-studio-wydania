"""Montaż multicam podcastu: kamera przełącza się na osobę, która mówi (na podstawie jej mikrofonu), jak AutoPod.

Układ w Premiere (jak w AutoPod): kamery jedna nad drugą na osobnych ścieżkach wideo (np. V1 plan ogólny,
V2 prowadzący, V3 gość), mikrofony na osobnych ścieżkach audio (np. A1 prowadzący, A2 gość). Może być też jeden plik
z rejestratora z mikrofonami w osobnych kanałach (A1 = kanał 1, A2 = kanał 2).

  python narzedzia/multicam.py analizuj --xml sekwencja.xml --folder wyniki/<...> --uklad uklad.json
  python narzedzia/multicam.py zastosuj --xml sekwencja.xml --folder wyniki/<...> [--dzwiek] [--moc 80] [--silnik elevenlabs|ffmpeg] [--nieuzyte wylacz|usun]

uklad.json:
{"ogolna": 1,                                   numer ścieżki wideo z planem ogólnym (0 = brak)
 "osoby": [{"nazwa": "Prowadzący", "kamera": 2, "mikrofon": 1},
           {"nazwa": "Gość", "kamera": 3, "mikrofon": 2}],
 "min_ujecie": 2.5,          najkrótsze ujęcie (s) – im więcej, tym rzadziej przełącza
 "wtracenia": 1.0,           krótsze wypowiedzi („mhm”, „tak”) nie przełączają kamery
 "przebicia_db": 8,          głos o tyle dB cichszy niż w drugim mikrofonie to przebicie, nie mowa
 "rozmowa": "ogolna",        gdy mówią naraz: "ogolna" | "zostaw" (zostań na obecnej osobie)
 "max_ujecie": 15,           po tylu sekundach jednej osoby wstaw przebitkę (0 = nigdy)
 "wstawka": 2.5,             długość wstawki (s)
 "wstawka_kat": "ogolna",    co wstawić w długi monolog: "ogolna" | "reakcja" (kamera słuchacza) | "na_zmiane"
 "wyprzedzenie": 0.25,       cięcie chwilę przed początkiem wypowiedzi (jak robi montażysta)
 "czulosc": 0.35}            0–1: od jakiej głośności mikrofon „mówi” (mniej = czulej)

Wynik „zastosuj”: nowa sekwencja „... - multicam”: klipy kamer pocięte w miejscach przełączeń, nieaktywne ujęcia
WYŁĄCZONE (nie usunięte; włączasz je Shift+E w Premiere). Z --dzwiek: na każdy mikrofon nowa ścieżka z czystym,
wyrównanym głosem, bez przebić drugiej osoby (oryginalne ścieżki mikrofonów zostają wyłączone, do porównania).
"""
import argparse
import copy
import json
import re
import subprocess
import sys
import wave
import xml.etree.ElementTree as ET
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, postep, wynik  # noqa: E402
import ciecie  # noqa: E402

KROK = 0.05  # s: rozdzielczość analizy głośności
DOMYSLNE = {"ogolna": 1, "osoby": [], "min_ujecie": 2.5, "wtracenia": 1.0, "przebicia_db": 8, "rozmowa": "ogolna",
            "max_ujecie": 15, "wstawka": 2.5, "wstawka_kat": "ogolna", "wyprzedzenie": 0.25, "czulosc": 0.35}


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


# ---------- dźwięk z osi (wyeksportowany przez Premiere) ----------
def wczytaj_z_osi(plik):
    """{numer ścieżki A (jak w Premiere): WAV tej ścieżki tak, jak gra na osi}. Panel eksportuje je przed analizą."""
    if not plik:
        return {}
    p = sciezka(plik)
    if not p.exists():
        return {}
    d = json.loads(p.read_text(encoding="utf-8"))
    return {int(k): v for k, v in d.items() if v and Path(v).exists()}


def mikrofon(seq, defs, nr, cel, dl, z_osi, sr=16000):
    """Dźwięk mikrofonu A<nr> jako mono WAV o długości sekwencji: z eksportu Premiere (z Twoimi ustawieniami kanałów,
    głośności i efektami), a gdy go nie ma (np. polecenie spoza panelu), z plików według XML."""
    if nr in z_osi:
        ciecie.ff(["-i", z_osi[nr], "-ac", "1", "-ar", sr, "-af", f"apad=whole_dur={dl:.3f},atrim=0:{dl:.3f}", "-c:a", "pcm_s16le", cel],
                  f"dźwięk ścieżki A{nr} z Premiere")
        return "premiere"
    ciecie.miks(seq, defs, cel, dl, sciezki={nr}, sr=sr)
    return "pliki"


# ---------- głośność mikrofonów ----------
def poziomy(wav):
    """Głośność w dB co 50 ms (wav mono 16 kHz)."""
    import numpy as np
    with wave.open(str(wav)) as w:
        sr = w.getframerate()
        dane = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768
    n = int(sr * KROK)
    k = len(dane) // n
    ramki = dane[:k * n].reshape(k, n)
    rms = np.sqrt((ramki ** 2).mean(axis=1) + 1e-10)
    return 20 * np.log10(rms)


def aktywnosc(db, ust):
    """Kto mówi w każdej ramce 50 ms: tablica [osoby x ramki] z True/False, z odrzuceniem przebić."""
    import numpy as np
    db = np.array(db)
    n_os, n = db.shape
    progi = []
    for i in range(n_os):
        tlo, mowa = np.percentile(db[i], 20), np.percentile(db[i], 95)
        progi.append(tlo + (mowa - tlo) * float(ust["czulosc"]))
    akt = np.zeros_like(db, dtype=bool)
    for i in range(n_os):
        inne = np.max(np.delete(db, i, axis=0), axis=0) if n_os > 1 else np.full(n, -200.0)
        akt[i] = (db[i] > progi[i]) & (db[i] >= inne - float(ust["przebicia_db"]))
    # wygładzenie: krótkie dziury (<0,4 s) zalepiamy, krótkie wyskoki (<0,15 s) usuwamy
    def domknij(a, max_r, wartosc):
        a = a.copy()
        i = 0
        while i < len(a):
            if a[i] == wartosc:
                j = i
                while j < len(a) and a[j] == wartosc:
                    j += 1
                if j - i <= max_r and i > 0 and j < len(a):
                    a[i:j] = not wartosc
                i = j
            else:
                i += 1
        return a
    for i in range(n_os):
        akt[i] = domknij(akt[i], int(0.4 / KROK), False)
        akt[i] = domknij(akt[i], int(0.15 / KROK), True)
    return akt, progi


def odcinki(a):
    """[(od_ramki, do_ramki)] gdzie a jest True."""
    wyn, i = [], 0
    while i < len(a):
        if a[i]:
            j = i
            while j < len(a) and a[j]:
                j += 1
            wyn.append((i, j))
            i = j
        else:
            i += 1
    return wyn


# ---------- decyzje kamer ----------
def decyzje(akt, ust, dl):
    """Lista ujęć [(od_s, do_s, kat)], kat = indeks osoby albo -1 (plan ogólny)."""
    import numpy as np
    n_os, n = akt.shape
    ogolna = int(ust.get("ogolna") or 0) > 0
    # wypowiedzi krótsze niż „wtracenia” nie liczą się do przełączania
    znaczace = np.zeros_like(akt)
    for i in range(n_os):
        for a, b in odcinki(akt[i]):
            if (b - a) * KROK >= float(ust["wtracenia"]):
                znaczace[i, a:b] = True
    # pożądany kąt w każdej ramce
    chce = np.full(n, -2)  # -2 = bez zmian
    for t in range(n):
        kto = np.flatnonzero(znaczace[:, t])
        if len(kto) == 1:
            chce[t] = kto[0]
        elif len(kto) > 1:
            chce[t] = -1 if (ogolna and ust["rozmowa"] == "ogolna") else -2
    pierwszy = next((int(c) for c in chce if c != -2), -1 if ogolna else 0)
    min_r = int(float(ust["min_ujecie"]) / KROK)
    wyprz = int(float(ust["wyprzedzenie"]) / KROK)
    ujecia, kat, start = [], pierwszy, 0
    t = 0
    while t < n:
        c = chce[t]
        if c != -2 and c != kat:
            # potwierdzenie: nowy kąt musi utrzymać się 0,5 s (patrzymy w przód, bo znamy całe nagranie)
            dalej = chce[t:t + int(0.5 / KROK)]
            if np.mean((dalej == c) | (dalej == -2)) >= 0.8:
                ciecie_t = max(t - wyprz, start + min_r)
                if ciecie_t <= t + wyprz and ciecie_t > start:
                    ujecia.append((start, ciecie_t, kat))
                    kat, start = int(c), ciecie_t
                    t = ciecie_t + 1
                    continue
        t += 1
    ujecia.append((start, n, kat))
    # długie ujęcia jednej osoby: wstawka planu ogólnego
    rodzaj = ust.get("wstawka_kat", "ogolna")
    if not ogolna and rodzaj != "reakcja":
        rodzaj = "reakcja"
    max_r = int(float(ust["max_ujecie"]) / KROK)
    wst = int(float(ust["wstawka"]) / KROK)
    licznik = [0]

    def kat_wstawki(k):
        """Plan ogólny albo reakcja słuchacza (kamera drugiej osoby), według ustawienia."""
        sluchacz = (k + 1) % n_os
        if rodzaj == "reakcja":
            return sluchacz
        if rodzaj == "na_zmiane":
            licznik[0] += 1
            return -1 if licznik[0] % 2 else sluchacz
        return -1
    if max_r > 0:
        nowe = []
        for a, b, k in ujecia:
            if k >= 0 and b - a > max_r + wst + min_r:
                x = a
                while b - x > max_r + wst + min_r:
                    # wstawkę kładziemy na krótkiej pauzie w mowie, jeśli jest w pobliżu
                    cel = x + max_r
                    okno = range(max(x + min_r, cel - int(3 / KROK)), min(b - wst - min_r, cel + int(3 / KROK)))
                    cisza = [u for u in okno if not akt[k, u]]
                    cel = cisza[0] if cisza else cel
                    nowe += [(x, cel, k), (cel, cel + wst, kat_wstawki(k))]
                    x = cel + wst
                nowe.append((x, b, k))
            else:
                nowe.append((a, b, k))
        ujecia = nowe
    return [(round(a * KROK, 3), round(min(b * KROK, dl), 3), k) for a, b, k in ujecia if b > a]


def analizuj(xml, folder, uklad, z_osi=None):
    import numpy as np
    folder = sciezka(folder)
    folder.mkdir(parents=True, exist_ok=True)
    ust = {**DOMYSLNE, **json.loads(sciezka(uklad).read_text(encoding="utf-8"))} if isinstance(uklad, (str, Path)) else {**DOMYSLNE, **uklad}
    if len(ust["osoby"]) < 2:
        blad("Podaj co najmniej dwie osoby (kamera + mikrofon) w układzie.")
    tree, root, seq, defs, fps = ciecie.zaladuj(xml)
    dl = ciecie.liczba(seq, "duration") / fps
    db = []
    z_osi = wczytaj_z_osi(z_osi)
    zrodla = set()
    for o in ust["osoby"]:
        cel = folder / f"mikrofon_{o['mikrofon']}.wav"
        postep(f"Dźwięk mikrofonu: {o['nazwa']} (A{o['mikrofon']})")
        zrodla.add(mikrofon(seq, defs, int(o["mikrofon"]), cel, dl, z_osi))
        db.append(poziomy(cel))
        cel.unlink(missing_ok=True)
    n = min(len(x) for x in db)
    db = [x[:n] for x in db]
    postep("Wybieram kamery")
    akt, progi = aktywnosc(db, ust)
    ujecia = decyzje(akt, ust, dl)
    np.save(folder / "aktywnosc.npy", akt)
    (folder / "ujecia.json").write_text(json.dumps({"ustawienia": ust, "ujecia": ujecia}, ensure_ascii=False), encoding="utf-8")
    nazwy = [o["nazwa"] for o in ust["osoby"]]
    czas = {"Plan ogólny" if k < 0 else nazwy[k]: 0.0 for _, _, k in ujecia}
    for a, b, k in ujecia:
        czas["Plan ogólny" if k < 0 else nazwy[k]] += b - a
    mowa = {nazwy[i]: round(float(akt[i].sum()) * KROK / 60, 1) for i in range(len(nazwy))}
    wynik(ujec=len(ujecia), srednie_ujecie_s=round(dl / max(1, len(ujecia)), 1),
          udzial_kamer_min={k: round(v / 60, 1) for k, v in czas.items()}, mowa_min=mowa, folder=str(folder),
          dzwiek_z="premiere" if zrodla == {"premiere"} else "pliki")


# ---------- dźwięk: czysty, wyrównany, bez przebić ----------
def obwiednia(akt_i, akt_inni, cel, dl, tlumienie_db=18, cisza_db=6, sr=48000):
    """Plik WAV z mnożnikiem głośności: 1 gdy ta osoba mówi, ciszej gdy mówi ktoś inny (przebicie), lekko ciszej w ciszy."""
    import numpy as np
    n = len(akt_i)
    g = np.full(n, 10 ** (-cisza_db / 20), dtype=np.float32)
    inny = akt_inni.any(axis=0) if akt_inni.size else np.zeros(n, dtype=bool)
    g[inny] = 10 ** (-tlumienie_db / 20)
    mowi = akt_i.copy()
    # podtrzymanie 0,3 s po wypowiedzi i 0,1 s przed (żeby nie ucinać końcówek)
    for a, b in odcinki(akt_i):
        mowi[max(0, a - 2):min(n, b + 6)] = True
    g[mowi] = 1.0
    # wygładzenie (przejścia ~100 ms) i rozciągnięcie do próbek audio
    jadro = np.ones(3) / 3
    g = np.convolve(g, jadro, mode="same")
    probki_na_ramke = int(sr * KROK)
    with wave.open(str(cel), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        total = int(dl * sr)
        x_ramek = np.arange(n) * probki_na_ramke
        for start in range(0, total, sr * 30):
            koniec = min(total, start + sr * 30)
            t = np.arange(start, koniec)
            w.writeframes((np.interp(t, x_ramek, g) * 32767).astype(np.int16).tobytes())


def glosnosc_lufs(plik):
    """Zmierzona głośność zintegrowana (LUFS) – tylko pomiar, nic nie zmienia."""
    import subprocess
    r = subprocess.run(["ffmpeg", "-hide_banner", "-nostats", "-i", str(plik), "-af", "ebur128=framelog=quiet", "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    m = re.findall(r"I:\s+(-?[\d.]+) LUFS", r.stderr)
    return float(m[-1]) if m else -16.0


def dzwiek_podcastu(seq, defs, folder, ust, akt, dl, moc=80, silnik="elevenlabs", z_osi=None):
    import numpy as np
    import dzwiek
    wyniki = []
    m = max(0, min(100, moc)) / 100
    for i, o in enumerate(ust["osoby"]):
        postep(f"Czysty dźwięk: {o['nazwa']}")
        surowy = folder / f"mic{i + 1}_48k.wav"
        mikrofon(seq, defs, int(o["mikrofon"]), surowy, dl, z_osi or {}, sr=48000)
        zrodlo = surowy
        if silnik == "elevenlabs":
            mp3 = folder / f"mic{i + 1}.mp3"
            ciecie.ff(["-i", surowy, "-c:a", "libmp3lame", "-b:a", "192k", mp3], "kompresja do wysyłki")
            iso = folder / f"mic{i + 1}_izolowany.audio"
            dzwiek.izolacja_elevenlabs(mp3, iso)
            zrodlo = iso
        env = folder / f"mic{i + 1}_obwiednia.wav"
        obwiednia(akt[i], np.delete(akt, i, axis=0), env, dl)
        bezpieczna = re.sub(r"[^\w-]+", "_", o["nazwa"])
        cel = folder / f"{bezpieczna}_czysty.wav"
        lancuch = dzwiek.lancuch_studyjny(1.0, silnik == "ffmpeg")
        tmp = folder / f"{bezpieczna}_przed.wav"
        # 1) czysty głos (AI + studio) zmieszany z oryginałem wg mocy i wyrównany (kompresja, loudnorm),
        # 2) DOPIERO POTEM wyciszanie przebić obwiednią: po niej nic już nie podbija cichych miejsc,
        #    więc przyciszony głos drugiej osoby zostaje cichy
        ciecie.ff(["-i", zrodlo, "-i", surowy, "-i", env, "-filter_complex",
                   f"[0:a]aformat=sample_rates=48000:channel_layouts=mono,{lancuch},aresample=48000,asetpts=N/SR/TB,apad=whole_dur={dl:.3f},atrim=0:{dl:.3f}[c];"
                   f"[1:a]aformat=sample_rates=48000:channel_layouts=mono,highpass=f=80,loudnorm=I=-16:TP=-2,aresample=48000,asetpts=N/SR/TB,apad=whole_dur={dl:.3f},atrim=0:{dl:.3f}[o];"
                   f"[c][o]amix=inputs=2:weights='{m:.2f} {1 - m:.2f}':normalize=0,"
                   "acompressor=threshold=-20dB:ratio=3:attack=10:release=200:makeup=1[mx];"
                   f"[2:a]aformat=sample_rates=48000:channel_layouts=mono[e];[mx][e]amultiply,"
                   f"aresample=48000,asetpts=N/SR/TB,apad=whole_dur={dl:.3f},atrim=0:{dl:.3f}[a]",
                   "-map", "[a]", "-c:a", "pcm_s24le", "-ar", 48000, tmp], f"dźwięk {o['nazwa']}")
        # 3) głośność całości do -16 LUFS stałym wzmocnieniem (bez dynamicznego podbijania) + limiter
        zysk = -16 - glosnosc_lufs(tmp)
        ciecie.ff(["-i", tmp, "-af", f"volume={zysk:.2f}dB,alimiter=limit=0.84:attack=5:release=50:level=false",
                   "-c:a", "pcm_s24le", "-ar", 48000, cel], f"głośność {o['nazwa']}")
        tmp.unlink(missing_ok=True)
        for x in (surowy, env):
            x.unlink(missing_ok=True)
        wyniki.append({"osoba": o["nazwa"], "plik": str(cel)})
    return wyniki


# ---------- nowa sekwencja ----------
def podziel_sciezke(track, punkty_kl, wybor, usun=False):
    """Tnie klipy na ścieżce w punktach cięć; wybor(od, do) mówi, czy kawałek ma być włączony (usun=True: nieaktywne kawałki znikają)."""
    for el in list(track):
        if el.tag not in ciecie.ELEMENTY:
            continue
        s, e, i = ciecie.liczba(el, "start", -1), ciecie.liczba(el, "end", -1), ciecie.liczba(el, "in", 0)
        if s < 0 or e < 0:
            continue
        idx = list(track).index(el)
        track.remove(el)
        granice = [s] + [p for p in punkty_kl if s < p < e] + [e]
        for k, (a, b) in enumerate(zip(granice, granice[1:])):
            c = copy.deepcopy(el)
            c.set("id", (el.get("id") or "klip") + (f"-m{k}" if k else ""))
            ciecie.ustaw(c, "start", a)
            ciecie.ustaw(c, "end", b)
            ciecie.ustaw(c, "in", i + (a - s))
            ciecie.ustaw(c, "out", i + (b - s))
            for l in c.findall("link"):
                c.remove(l)
            en = c.find("enabled")
            if en is None:
                en = ET.SubElement(c, "enabled")
            aktywny = wybor(a, b)
            if usun and not aktywny:
                continue
            en.text = "TRUE" if aktywny else "FALSE"
            track.insert(idx, c)
            idx += 1


def nowa_sciezka_audio(seq, plik, nazwa, dl_kl, fps_tb, ntsc):
    audio = seq.find("media/audio")
    tr = ET.SubElement(audio, "track")
    c = ET.SubElement(tr, "clipitem", id=f"czysty-{abs(hash(plik)) % 10**8}")
    ET.SubElement(c, "name").text = nazwa
    ET.SubElement(c, "enabled").text = "TRUE"
    ET.SubElement(c, "duration").text = str(dl_kl)
    r = ET.SubElement(c, "rate")
    ET.SubElement(r, "timebase").text = str(fps_tb)
    ET.SubElement(r, "ntsc").text = "TRUE" if ntsc else "FALSE"
    for tag, v in (("start", 0), ("end", dl_kl), ("in", 0), ("out", dl_kl)):
        ET.SubElement(c, tag).text = str(v)
    f = ET.SubElement(c, "file", id=f"plik-czysty-{abs(hash(plik)) % 10**8}")
    ET.SubElement(f, "name").text = Path(plik).name
    ET.SubElement(f, "pathurl").text = "file://localhost/" + str(Path(plik).resolve()).replace("\\", "/").replace(":", "%3a").lstrip("/")
    r2 = ET.SubElement(f, "rate")
    ET.SubElement(r2, "timebase").text = str(fps_tb)
    ET.SubElement(r2, "ntsc").text = "TRUE" if ntsc else "FALSE"
    ET.SubElement(f, "duration").text = str(dl_kl)
    m = ET.SubElement(ET.SubElement(f, "media"), "audio")
    sc = ET.SubElement(m, "samplecharacteristics")
    ET.SubElement(sc, "depth").text = "24"
    ET.SubElement(sc, "samplerate").text = "48000"
    ET.SubElement(m, "channelcount").text = "1"
    st = ET.SubElement(c, "sourcetrack")
    ET.SubElement(st, "mediatype").text = "audio"
    ET.SubElement(st, "trackindex").text = "1"
    ET.SubElement(tr, "enabled").text = "TRUE"
    ET.SubElement(tr, "locked").text = "FALSE"


def zastosuj(xml, folder, dzwiek_wl=False, moc=80, silnik="elevenlabs", nieuzyte="wylacz", z_osi=None):
    import numpy as np
    folder = sciezka(folder)
    dane = json.loads((folder / "ujecia.json").read_text(encoding="utf-8"))
    ust, ujecia = dane["ustawienia"], dane["ujecia"]
    tree, root, seq, defs, fps = ciecie.zaladuj(xml)
    defs = {k: copy.deepcopy(v) for k, v in defs.items()}
    dl_kl = ciecie.liczba(seq, "duration")
    dl = dl_kl / fps
    kl = lambda s: int(round(s * fps))  # noqa: E731
    punkty = sorted({kl(a) for a, _, _ in ujecia[1:]})
    sciezka_kata = {-1: int(ust.get("ogolna") or 0)}
    for i, o in enumerate(ust["osoby"]):
        sciezka_kata[i] = int(o["kamera"])
    przedzialy = [(kl(a), kl(b), k) for a, b, k in ujecia]

    def kat_w(a, b):
        sr = (a + b) / 2
        return next((k for x, y, k in przedzialy if x <= sr < y), przedzialy[-1][2])
    # plan dla panelu: Premiere sam tnie kopię sekwencji w tych miejscach (efekty, LUT-y, kadrowanie zostają)
    aktywne = {}
    for a, b, k in przedzialy:
        nr = sciezka_kata.get(k)
        if nr:
            aktywne.setdefault(nr, []).append([round(a / fps, 4), round(b / fps, 4)])
    plan_premiere = {"punkty": [round(p / fps, 4) for p in punkty], "kamery": {str(k): v for k, v in aktywne.items()},
                     "wszystkie_kamery": sorted({v for v in sciezka_kata.values() if v}),
                     "mikrofony": sorted({int(o["mikrofon"]) for o in ust["osoby"]}), "usun": nieuzyte == "usun"}
    tracks = seq.find("media/video").findall("track")
    kamery = set(sciezka_kata.values()) - {0}
    for nr, tr in enumerate(tracks, 1):
        if nr in kamery:
            podziel_sciezke(tr, punkty, lambda a, b, nr=nr: sciezka_kata.get(kat_w(a, b)) == nr, usun=nieuzyte == "usun")
    ciecie.napraw_definicje(root, defs)
    uwagi = ["Nieużyte ujęcia kamer są usunięte (oryginalna sekwencja zostaje bez zmian)." if nieuzyte == "usun" else
             "Nieaktywne ujęcia kamer są wyłączone, nie usunięte: zaznacz klip i Shift+E, żeby go włączyć."]
    czyste = []
    if dzwiek_wl:
        akt = np.load(folder / "aktywnosc.npy")
        czyste = dzwiek_podcastu(seq, defs, folder, ust, akt, dl, moc, silnik, wczytaj_z_osi(z_osi))
        a_tracks = seq.find("media/audio").findall("track")
        mikrofony = {int(o["mikrofon"]) for o in ust["osoby"]}
        mapa_a = ciecie.mapa_sciezek_audio(seq)
        for nr, tr in enumerate(a_tracks, 1):
            if mapa_a.get(nr, nr) in mikrofony:
                for c in tr.findall("clipitem"):
                    en = c.find("enabled")
                    if en is None:
                        en = ET.SubElement(c, "enabled")
                    en.text = "FALSE"
        r = seq.find("rate")
        for c in czyste:
            nowa_sciezka_audio(seq, c["plik"], f"{c['osoba']} (czysty)", dl_kl, ciecie.liczba(r, "timebase", 25),
                               (r.findtext("ntsc") or "").upper() == "TRUE")
        uwagi.append("Czysty dźwięk jest na nowych ścieżkach na dole; oryginalne mikrofony są wyłączone (do porównania).")
    nazwa = (seq.findtext("name") or "Podcast") + " - multicam"
    seq.find("name").text = nazwa
    u = seq.find("uuid")
    if u is not None:
        seq.remove(u)
    bezpieczna = re.sub(r"[^\w\-. ]+", "_", nazwa)
    cel = folder / f"{bezpieczna}.xml"
    ET.indent(tree, space=" ")
    tree.write(cel, encoding="UTF-8", xml_declaration=True)
    t = cel.read_text(encoding="utf-8")
    if "<!DOCTYPE" not in t:
        cel.write_text(t.replace("?>", "?>\n<!DOCTYPE xmeml>", 1), encoding="utf-8")
    plan_premiere["czyste"] = [c["plik"] for c in czyste]
    wynik(xml=str(cel), nazwa=nazwa, ujec=len(ujecia), czyste_sciezki=czyste, uwagi=uwagi, premiere=plan_premiere)


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Multicam podcastu")
    sub = p.add_subparsers(dest="tryb", required=True)
    a1 = sub.add_parser("analizuj"); a1.add_argument("--xml", required=True); a1.add_argument("--folder", required=True)
    a1.add_argument("--uklad", required=True); a1.add_argument("--z-premiere", default=None)
    a2 = sub.add_parser("zastosuj"); a2.add_argument("--xml", required=True); a2.add_argument("--folder", required=True)
    a2.add_argument("--dzwiek", action="store_true"); a2.add_argument("--moc", type=int, default=80)
    a2.add_argument("--silnik", default="elevenlabs", choices=["elevenlabs", "ffmpeg"])
    a2.add_argument("--nieuzyte", default="wylacz", choices=["wylacz", "usun"]); a2.add_argument("--z-premiere", default=None)
    a = p.parse_args()
    if a.tryb == "analizuj":
        analizuj(a.xml, a.folder, a.uklad, a.z_premiere)
    else:
        zastosuj(a.xml, a.folder, a.dzwiek, a.moc, a.silnik, a.nieuzyte, a.z_premiere)
