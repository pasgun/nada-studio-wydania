"""Licznik limitów Claude (pasek stanu Claude Code) + historia zużycia na rodzaj zadania.

Claude Code wywołuje ten skrypt jako „status line” (ustawienie w .claude/settings.json) i podaje mu na wejściu
stan sesji, w tym limity planu Pro/Max: okno 5-godzinne i tygodniowe (procent zużycia i godzina odnowienia).
Skrypt:
- wypisuje krótki pasek na dole Claude Code, np. „5 h: 23% (do 14:05) · tydzień: 41% (pt 09:00)”,
- zapisuje ostatni stan do _system/licznik/limity.json,
- zapamiętuje, ile procent limitu tygodniowego zużyła każda sesja i jakiego rodzaju było zadanie (/rolka, /grafika...),
  żeby Studio mogło policzyć, ile takich zadań zmieści się jeszcze w limicie.

  python narzedzia/limity.py --pokaz      (stan i średnie zużycie na rodzaj zadania, JSON)
Klucze API i treść rozmów nie są nigdzie zapisywane; z rozmowy czytany jest tylko pierwszy wpis (rodzaj zadania).
"""
import json
import sys
import time
from datetime import datetime
from pathlib import Path

KATALOG = Path(__file__).resolve().parent.parent
FOLDER = KATALOG / "_system" / "licznik"
if (KATALOG / "wyniki" / "_licznik").exists():  # przeniesienie ze starego miejsca
    try:
        sys.path.insert(0, str(KATALOG / "narzedzia"))
        import porzadek
        porzadek.system("licznik")
    except Exception:
        pass
RODZAJE = ["rolka", "grafika", "aftermovie", "jak-wzor", "animacje", "multicam", "napisy", "ciecie", "transkrypcja", "pion",
           "miniatury", "dzwiek", "tlumaczenie", "formaty", "brandbook"]
DNI = ["pn", "wt", "śr", "cz", "pt", "sb", "nd"]


def czytaj(p, dom):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return dom


def zapisz(p, d):
    p = Path(p)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(p)


def rodzaj_sesji(transkrypt):
    """Rodzaj zadania z pierwszej wiadomości (np. „/rolka {...}”, polecenie z panelu Premiere)."""
    try:
        with open(transkrypt, encoding="utf-8", errors="replace") as f:
            for i, linia in enumerate(f):
                if i > 60:
                    break
                if '"user"' not in linia:
                    continue
                t = linia.lower()
                for r in RODZAJE:
                    if f"/{r} " in t or f"/{r}\\n" in t or f"skills/{r}/skill.md" in t:
                        return r
                if "/aftermovie" in t:
                    return "aftermovie"
                return "inne"
    except Exception:
        pass
    return None


def kiedy(ts):
    if not ts:
        return ""
    d = datetime.fromtimestamp(float(ts))
    teraz = datetime.now()
    return d.strftime("%H:%M") if d.date() == teraz.date() else f"{DNI[d.weekday()]} {d.strftime('%H:%M')}"


def pasek(dane):
    rl = dane.get("rate_limits") or {}
    cz = []
    if rl.get("five_hour"):
        cz.append(f"5 h: {round(rl['five_hour'].get('used_percentage', 0))}% (do {kiedy(rl['five_hour'].get('resets_at'))})")
    if rl.get("seven_day"):
        cz.append(f"tydzień: {round(rl['seven_day'].get('used_percentage', 0))}% ({kiedy(rl['seven_day'].get('resets_at'))})")
    return " · ".join(cz) or "limity pojawią się po pierwszej odpowiedzi"


def status_line():
    try:
        dane = json.loads(sys.stdin.read() or "{}")
    except Exception:
        dane = {}
    rl = dane.get("rate_limits") or {}
    teraz = time.time()
    if rl:
        zapisz(FOLDER / "limity.json", {"rate_limits": rl, "czas": teraz, "model": (dane.get("model") or {}).get("display_name")})
        sid = dane.get("session_id")
        if sid and rl.get("seven_day"):
            sesje = czytaj(FOLDER / "sesje.json", {})
            s = sesje.get(sid) or {"start": teraz, "rodzaj": None, "pierwsze": rl}
            if not s.get("rodzaj") and dane.get("transcript_path"):
                s["rodzaj"] = rodzaj_sesji(dane["transcript_path"])
            s["ostatnie"] = rl
            s["czas"] = teraz
            sesje[sid] = s
            # najwyżej 400 ostatnich sesji
            if len(sesje) > 400:
                for k in sorted(sesje, key=lambda k: sesje[k].get("czas", 0))[:-400]:
                    sesje.pop(k)
            zapisz(FOLDER / "sesje.json", sesje)
    print(pasek(dane))


def podsumowanie():
    lim = czytaj(FOLDER / "limity.json", {})
    sesje = czytaj(FOLDER / "sesje.json", {})
    na_rodzaj = {}
    for s in sesje.values():
        a = ((s.get("pierwsze") or {}).get("seven_day") or {}).get("used_percentage")
        b = ((s.get("ostatnie") or {}).get("seven_day") or {}).get("used_percentage")
        r = s.get("rodzaj") or "inne"
        if a is None or b is None or b < a:  # okno się odnowiło w trakcie: pomijamy
            continue
        na_rodzaj.setdefault(r, []).append(round(b - a, 2))
    srednie = {}
    for r, lista in na_rodzaj.items():
        lista = sorted(lista)
        srednie[r] = {"zadan": len(lista), "mediana_proc_tygodnia": lista[len(lista) // 2]}
    return {"limity": lim.get("rate_limits"), "zapisano": lim.get("czas"), "model": lim.get("model"), "zuzycie_na_rodzaj": srednie}


if __name__ == "__main__":
    if "--pokaz" in sys.argv:
        print(json.dumps({"ok": True, **podsumowanie()}, ensure_ascii=False, indent=1))
    else:
        status_line()
