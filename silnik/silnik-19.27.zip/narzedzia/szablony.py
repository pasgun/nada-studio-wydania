"""Szablony rolek i stories (zdjęcia + teksty + ruch) bez After Effects albo jako opis dla After Effects.

  python narzedzia/szablony.py lista
  python narzedzia/szablony.py render --szablon ed-walizka --wyjscie wyniki/<...>/story.mp4
         [--wartosci '{"pola": {"tytul": "..."}, "zdjecia": {"z1": "C:/zdjecia/a.jpg"}, "kolory": {"a": "#ff6b2c"}}']
         [--klient klienci/<x>] [--podglad] [--ae]
  python narzedzia/szablony.py galeria --wyjscie wyniki/galeria_szablonow.png

--podglad: arkusz 8 klatek obok pliku (<nazwa>_podglad.png) do obejrzenia.
--ae: zapisuje też <nazwa>_ae.json (opis kompozycji dla narzedzia/szablony/ae_buduj.jsx, czyli dla After Effects).
Opis pól każdego szablonu (zdjęcia, teksty) pokazuje „lista”. Kolory: tl (tło), t (tekst), a (akcent), g (plama), d (drugi tekst).
Wygodniej: panel w Premiere albo After Effects, kafel „Szablony rolek”.
"""
import argparse
import json
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, wynik  # noqa: E402
import animacje  # noqa: E402  (node, marka i fonty)

FOLDER = Path(__file__).resolve().parent / "szablony"


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


def node(args):
    r = subprocess.run([animacje.node(), str(FOLDER / "render.js"), *args], capture_output=True, text=True, encoding="utf-8", errors="replace")
    for linia in r.stderr.splitlines():
        if linia.startswith("POSTEP:"):
            print(linia, file=sys.stderr)
    try:
        d = json.loads(r.stdout[r.stdout.index("{"):])
    except Exception:
        blad("Render szablonu nie zwrócił wyniku: " + (r.stderr or r.stdout)[-600:])
    if not d.get("ok"):
        blad(d.get("blad", "błąd renderu"))
    d.pop("ok", None)
    return d


def render(szablon, wyjscie, wartosci=None, klient=None, podglad=False, ae=False, W=1080, H=1920, fps=30):
    w = json.loads(wartosci) if isinstance(wartosci, str) and wartosci else (wartosci or {})
    marka, _ = animacje.marka(klient)
    if marka and "kolory" not in w:
        w["kolory"] = {k: v for k, v in {"a": marka.get("kolor_glowny"), "g": marka.get("kolor_akcent")}.items() if v}
    if marka.get("font") and "fonty" not in w:
        w["fonty"] = {"n": {"rodzina": marka["font"]}}
    fonty = []
    for nazwa in {((w.get("fonty") or {}).get("n") or {}).get("rodzina", "Oswald"), ((w.get("fonty") or {}).get("t") or {}).get("rodzina", "Montserrat")}:
        fonty += animacje.pliki_fontow(nazwa, klient, wagi=(300, 400, 500, 600, 700, 800))
    w["zdjecia"] = {k: str(sciezka(v)) for k, v in (w.get("zdjecia") or {}).items() if v}
    cel = sciezka(wyjscie)
    spec = {"szablon": szablon, "wartosci": w, "W": W, "H": H, "fps": fps, "fonty": fonty, "wyjscie": str(cel)}
    if podglad:
        spec["podglad"] = str(cel.with_name(cel.stem + "_podglad.png"))
    if ae:
        spec["ae"] = str(cel.with_name(cel.stem + "_ae.json"))
    with tempfile.NamedTemporaryFile("w", suffix=".json", delete=False, encoding="utf-8") as t:
        json.dump(spec, t, ensure_ascii=False)
    try:
        d = node(["--spec", t.name])
    finally:
        Path(t.name).unlink(missing_ok=True)
    wynik(**d)


if __name__ == "__main__":
    a = argparse.ArgumentParser(description="Szablony rolek")
    sub = a.add_subparsers(dest="tryb", required=True)
    sub.add_parser("lista")
    r = sub.add_parser("render")
    r.add_argument("--szablon", required=True); r.add_argument("--wyjscie", required=True); r.add_argument("--wartosci")
    r.add_argument("--klient"); r.add_argument("--podglad", action="store_true"); r.add_argument("--ae", action="store_true")
    r.add_argument("--fps", type=int, default=30)
    g = sub.add_parser("galeria"); g.add_argument("--wyjscie", required=True)
    x = a.parse_args()
    if x.tryb == "lista":
        wynik(**node(["--lista"]))
    elif x.tryb == "render":
        render(x.szablon, x.wyjscie, x.wartosci, x.klient, x.podglad, x.ae, fps=x.fps)
    else:
        wynik(**node(["--galeria", str(sciezka(x.wyjscie)), "--fonty", ",".join(animacje.pliki_fontow("Oswald", None) + animacje.pliki_fontow("Montserrat", None))]))
