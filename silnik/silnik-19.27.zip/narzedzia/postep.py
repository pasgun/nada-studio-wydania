"""Etapy dłuższego zadania (np. aftermovie z panelu Premiere): panel rysuje z nich pasek postępu i szacowany czas.

  python narzedzia/postep.py --etap material [--tekst "Przeglądam 12 klipów"]
  python narzedzia/postep.py --gotowe --xml wyniki/.../premiere/aftermovie_poziom.xml [--xml ...] [--tekst "..."]
  python narzedzia/postep.py --blad "Brak muzyki w folderze muzyka/"

Plik postępu wskazuje zmienna NM_POSTEP (ustawia ją panel) albo --plik. Bez nich polecenie nic nie robi
(zadanie uruchomione w zwykłym terminalu po prostu nie ma paska).

Etapy i ich wagi zapisuje panel w postep.json ("etapy": [{"klucz": "material", "nazwa": "...", "waga": 35}, ...]).
Narzędzia w trakcie etapu same dopisują ułamek (np. analiza 5 z 20 klipów = 0,25), patrz wspolne.postep().
"""
import argparse
import json
import os
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import wynik, zapisz_postep  # noqa: E402


def _znajdz(x, plik):
    """Ścieżka po porządkach (porzadek.py): gdy pliku już nie ma, szuka go po nazwie w folderze zadania."""
    x = Path(x).resolve()
    if x.exists():
        return str(x)
    for baza in (Path(plik).resolve().parent, x.parent.parent):
        try:
            for k in baza.rglob(x.name):
                return str(k)
        except OSError:
            pass
    return str(x)


def main():
    p = argparse.ArgumentParser(description="Postęp zadania dla panelu")
    p.add_argument("--plik", default=None)
    p.add_argument("--etap", default=None, help="klucz etapu z listy etapów")
    p.add_argument("--tekst", default=None)
    p.add_argument("--gotowe", action="store_true")
    p.add_argument("--xml", action="append", default=[], help="timeline do wczytania w Premiere (można kilka)")
    p.add_argument("--wideo", action="append", default=[], help="gotowe pliki wideo")
    p.add_argument("--blad", default=None)
    a = p.parse_args()
    plik = a.plik or os.environ.get("NM_POSTEP")
    if not plik:
        wynik(zapisano=False, powod="brak NM_POSTEP (zadanie nie z panelu)")
        return
    dane = {}
    try:
        dane = json.loads(Path(plik).read_text(encoding="utf-8"))
    except Exception:
        pass
    teraz = time.time()
    if a.etap:
        historia = dane.get("historia", [])
        historia.append({"etap": a.etap, "od": teraz})
        zapisz_postep(plik, etap=a.etap, ulamek=0, tekst=a.tekst or "", historia=historia, stan="trwa")
    if a.gotowe:
        zapisz_postep(plik, stan="gotowe", etap="gotowe", ulamek=1, tekst=a.tekst or "Gotowe",
                      xml=[_znajdz(x, plik) for x in a.xml], wideo=[_znajdz(x, plik) for x in a.wideo], koniec=teraz)
    if a.blad:
        zapisz_postep(plik, stan="blad", tekst=a.blad, koniec=teraz)
    if a.tekst and not (a.etap or a.gotowe or a.blad):
        zapisz_postep(plik, tekst=a.tekst)
    wynik(zapisano=True)


if __name__ == "__main__":
    main()
