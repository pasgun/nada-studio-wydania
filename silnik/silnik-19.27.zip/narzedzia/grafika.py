"""Grafiki w barwach marki: tło (stock / AI / Envato) + nagłówek + podtytuł + przycisk CTA + logo.

Jedna grafika:
  python narzedzia/grafika.py --tlo wyniki/X/tlo.jpg --wyjscie wyniki/X/grafika.png --format post-4x5 \
     --folder-klienta klienci/marka --naglowek "Czym jest *ETF*?" --podtytul "Koszyk setek firm w jednym zakupie" \
     --cta "Odbierz darmowe szkolenie" --kolory '{"primary":"#0B1F3A","accent":"#22C55E","text":"#FFFFFF","highlight":"#22C55E"}'

Seria (wiele grafik w kilku formatach naraz):
  python narzedzia/grafika.py seria --plan wyniki/X/seria.json

  seria.json:
  {
    "folder_klienta": "klienci/marka", "wyjscie": "wyniki/X/grafiki",
    "formaty": ["post-4x5", "story-9x16", "square"],
    "font": "Montserrat", "font_tekstu": "Inter",
    "kolory": {"primary": "#0B1F3A", "accent": "#22C55E", "text": "#FFFFFF", "highlight": "#22C55E"},
    "cta": "Odbierz darmowe szkolenie",                       (domyślne dla wszystkich)
    "grafiki": [
      {"nazwa": "czym-jest-etf", "tlo": "wyniki/X/tla/01.jpg", "naglowek": "Czym jest *ETF*?",
       "podtytul": "...", "cta": "...", "fokus_x": 0.5, "fokus_y": 0.4, "uklad": "auto"},   (fokus: punkt tła, który ma zostać w kadrze)
      {"nazwa": "miniatura", "tlo": "...", "naglowek": "...", "osoba": {"plik": "wyniki/X/osoba/01.png", "strona": "prawo",
       "wysokosc": 0.95, "odbij": false, "obrys": "#FFFFFF"}},   (prowadzący wycięty z tła przez narzedzia/osoba.py,
       osobna warstwa w PSD; przy "uklad": "auto" tekst staje po drugiej stronie)
      ...
    ]
  }
  Wynik: <wyjscie>/<nr>_<nazwa>_<format>.png, <wyjscie>/podglad_serii.jpg (wszystko na jednym arkuszu)
  oraz <wyjscie>/photoshop/seria.psd: jeden plik, rząd = grafika, kolumny = formaty, każda na osobnym artboardzie
  (01_nazwa_1080x1350, 01_nazwa_1080x1920...), warstwy (tło, przyciemnienie,
  nagłówek i podtytuł jako edytowalny tekst, przycisk, logo). Wymaga Node.js; "psd": false w planie wyłącza.
  Same pliki PSD jeszcze raz: python narzedzia/grafika.py psd --plan wyniki/X/seria.json

Porównanie z wzorami klienta (kontrola):
  python narzedzia/grafika.py porownaj --folder wyniki/X/grafiki --referencje klienci/marka/referencje/grafiki
  arkusze porownanie_*.jpg: na górze 2–3 najnowsze wzory w tych samych proporcjach, pod nimi nasze grafiki.
  Wynik serii ma też "kontrola" (wielkość liter i twarzy w % wysokości) i "uwagi_kontroli" (tekst na twarzy,
  za mały nagłówek, prowadzący wiszący w powietrzu, tekst przy krawędzi): popraw je przed raportem.

Słowa w *gwiazdkach* dostają kolor podświetlenia, w !wykrzyknikach! kolor alarmowy (kolory.alarm, domyślnie czerwony).

Układ nagłówka „stos” ("styl_tekstu": "stos"; domyślny, gdy grafika ma prowadzącego albo nagłówek ma znak |):
  jak na miniaturach YouTube: wielkie linie (WERSALIKI) ciasno jedna nad drugą, z cieniem, przy dolnej krawędzi.
  "naglowek": "TE DANE W RAPORCIE|*WPROWADZAJĄ W*|+!BŁĄD!"   | = nowa linia, + na początku linii = ogromna na całą
  szerokość (krótkie słowo dostaje rozstrzelone litery), - na początku = mały dopisek (np. "-OTO POWÓD").
  Najdłuższa zwykła linia wypełnia szerokość bloku (w poziomie do 68% kadru, nigdy na twarz prowadzącego).
  W pionie długie linie dzielą się same, tekst zaczyna się pod brodą prowadzącego.
  Opcje przy grafice albo w serii: "miejsce_tekstu": "dol" | "srodek" | "gora", "rowno": true (każda linia na całą
  szerokość), "tlo_linii": "#111111" (ciemny pasek pod każdą linią), "pasek_dol": "#D0FC00" (pasek marki na dole kadru,
  "pasek_wys": 0.055), "cien": false (bez cienia), "wielkie": false (bez zamiany na wersaliki), "przyciemnienie": 0–1.
  "styl_tekstu": "zwykly" = dawny układ (nagłówek, podtytuł, przycisk w jednym rozmiarze).

Prowadzący ("osoba"): PNG z narzedzia/osoba.py. Gdy obok leży .json z twarzą, kadr jest po głowie: "glowa" (wysokość
  głowy jako część wysokości kadru; domyślnie 0.56 w poziomie, 0.36 w kwadracie i 4:5, 0.22 w story), "x_twarzy"
  (środek twarzy, część szerokości), "gora" (czubek głowy od góry). Ciało zawsze sięga dolnej krawędzi.
  "kadr": "cala" + "wysokosc": 0.95 = cała sylwetka jak dawniej.
Formaty: post-4x5 (1080x1350), story-9x16 (1080x1920), square (1080x1080), poziom-16x9 (1920x1080),
link-1200x628 (reklama/link Facebook, LinkedIn), display-300x250 (baner Google), pinterest-2x3 (1000x1500),
yt-1280x720 (miniatura YouTube), x-1500x500 (nagłówek X), linkedin-1584x396 (baner LinkedIn).
Układ tekstu ("uklad" w serii albo przy grafice): auto, dol, gora, srodek, lewo, prawo.
Bez logo: "logo": false (albo "bez_logo": true) w serii albo przy grafice; bez tego bierze logo.png klienta.
Opcjonalnie (w serii albo przy grafice): "logo_skala": 2 (większe logo, domyślnie 1), "logo_miejsce": lewo | srodek | prawo,
"cta_odstep": 2.5 (przycisk dalej od napisów, domyślnie 1).
"""
import argparse
import json
import re
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import blad, wynik  # noqa: E402
from montaz import hex_rgb, sciezka  # noqa: E402
import fonty  # noqa: E402

FORMATY = {
    "post-4x5": (1080, 1350), "story-9x16": (1080, 1920), "square": (1080, 1080), "poziom-16x9": (1920, 1080),
    "link-1200x628": (1200, 628), "display-300x250": (300, 250), "pinterest-2x3": (1000, 1500),
    "yt-1280x720": (1280, 720), "x-1500x500": (1500, 500), "linkedin-1584x396": (1584, 396),
}
SKROTY = {"post-4x5": "4x5", "story-9x16": "9x16", "square": "1x1", "poziom-16x9": "16x9", "link-1200x628": "1200x628",
          "display-300x250": "300x250", "pinterest-2x3": "2x3", "yt-1280x720": "yt", "x-1500x500": "x-naglowek",
          "linkedin-1584x396": "linkedin-baner"}


def dodaj_wlasne(formaty):
    """Własne rozmiary ze Studio: „wlasny-1200x900” (szerokość x wysokość w pikselach, 50–8000)."""
    for f in formaty or []:
        m = re.match(r"^wlasny-(\d{2,4})x(\d{2,4})$", str(f))
        if m and f not in FORMATY:
            w, h = int(m.group(1)), int(m.group(2))
            if 50 <= w <= 8000 and 50 <= h <= 8000:
                FORMATY[f] = (w, h)
                SKROTY[f] = f"{w}x{h}"
    return formaty


def cover(img, W, H, fx=0.5, fy=0.5):
    """Kadruje tło do formatu, trzymając punkt fokusu (fx, fy w zakresie 0–1) jak najbliżej środka."""
    s = max(W / img.width, H / img.height)
    img = img.resize((max(W, int(img.width * s + 1)), max(H, int(img.height * s + 1))))
    x = int(min(max(img.width * fx - W / 2, 0), img.width - W))
    y = int(min(max(img.height * fy - H / 2, 0), img.height - H))
    return img.crop((x, y, x + W, y + H))


def linie_z_wyroznieniem(tekst, font, max_w, d):
    """Dzieli tekst na linie; zwraca listę linii, każda to lista (słowo, wyróżnione)."""
    slowa = [(s.replace("*", ""), "*" in s) for s in tekst.split()]
    linie, biez = [], []
    for s in slowa:
        proba = " ".join(x for x, _ in biez + [s])
        if biez and d.textlength(proba, font=font) > max_w:
            linie.append(biez)
            biez = [s]
        else:
            biez.append(s)
    if biez:
        linie.append(biez)
    return linie


class Warstwy:
    """Grafika złożona z warstw (tło, przyciemnienie, teksty, przycisk, logo). Ta sama lista warstw
    daje gotowy PNG i plik Photoshopa (tekst zostaje edytowalny)."""

    def __init__(self, W, H):
        self.W, self.H, self.lista = W, H, []

    def nowa(self, nazwa, tekst=None, krycie=1.0):
        from PIL import Image
        img = Image.new("RGBA", (self.W, self.H), (0, 0, 0, 0))
        self.lista.append({"nazwa": nazwa, "img": img, "tekst": tekst, "krycie": krycie})
        return img

    def zlacz(self):
        from PIL import Image
        wyn = Image.new("RGBA", (self.W, self.H), (0, 0, 0, 255))
        for w in self.lista:
            img = w["img"]
            if w["krycie"] < 1:
                a = img.getchannel("A").point(lambda v: int(v * w["krycie"]))
                img = img.copy()
                img.putalpha(a)
            wyn.alpha_composite(img)
        return wyn

    def zapisz_do_psd(self, folder):
        """Każda warstwa przycięta do swojej zawartości + opis (pozycja, tekst) do złożenia PSD."""
        folder = Path(folder)
        folder.mkdir(parents=True, exist_ok=True)
        opis = []
        for i, w in enumerate(self.lista):
            box = w["img"].getbbox()
            if not box:
                continue
            plik = folder / f"w{i:02d}.png"
            w["img"].crop(box).save(plik, compress_level=1)
            opis.append({"nazwa": w["nazwa"], "plik": str(plik), "x": box[0], "y": box[1], "krycie": w["krycie"], "tekst": w["tekst"]})
        return opis


def opis_tekstu(linie, font, plik_fontu, rozmiar, interlinia, x, y_gora, kolor, podsw=None, wyrownanie="left"):
    """Dane warstwy tekstowej dla Photoshopa: tekst z łamaniem linii, font, kolory fragmentów, punkt zaczepienia (linia bazowa)."""
    teksty, runs = [], []
    for li, linia in enumerate(linie):
        for k, (slowo, wyr) in enumerate(linia):
            fragment = slowo + (" " if k < len(linia) - 1 else ("\n" if li < len(linie) - 1 else ""))
            teksty.append(fragment)
            kol = podsw if (wyr and podsw) else kolor
            if runs and runs[-1]["kolor"] == list(kol[:3]):
                runs[-1]["dl"] += len(fragment)
            else:
                runs.append({"dl": len(fragment), "kolor": list(kol[:3])})
    return {"tekst": "".join(teksty), "font": fonty.nazwa_postscript(plik_fontu), "rozmiar": rozmiar, "interlinia": interlinia,
            "x": x, "y": y_gora + font.getmetrics()[0], "wyrownanie": wyrownanie, "runs": runs}


def wklej(warstwa, im, x, y):
    """Nakłada obraz z przezroczystością także wtedy, gdy wystaje poza kadr (np. prowadzący ucięty z boku)."""
    x0, y0 = max(0, -x), max(0, -y)
    if x0 >= im.width or y0 >= im.height or x >= warstwa.width or y >= warstwa.height:
        return
    warstwa.alpha_composite(im.crop((x0, y0, min(im.width, warstwa.width - x), min(im.height, warstwa.height - y))), (max(0, x), max(0, y)))


def kadr_osoby(osoba, W, H):
    """Domyślny kadr prowadzącego zależny od formatu (jak na miniaturach YouTube: duża głowa przy krawędzi)."""
    if W / H >= 1.3:
        return {"glowa": 0.56, "gora": 0.02, "x_twarzy": 0.77}
    if H / W > 1.6:
        return {"glowa": 0.22, "gora": 0.13, "x_twarzy": 0.62}
    return {"glowa": 0.36, "gora": 0.05, "x_twarzy": 0.70}


def dodaj_osobe(ws, osoba, W, H):
    """Prowadzący wycięty z tła (PNG z przezroczystością, np. z narzedzia/osoba.py), zawsze dociągnięty do dolnej krawędzi
    (nie wisi w powietrzu). Gdy obok PNG leży .json z osoba.py (położenie twarzy), kadruje po głowie:
    osoba: {"plik", "strona": "prawo"|"lewo", "odbij": false (lustro, żeby patrzył w stronę tekstu),
            "obrys": "#FFFFFF" (obwódka, opcjonalnie),
            "glowa": 0.56 (wysokość głowy od czubka do brody jako część wysokości kadru; domyślnie zależnie od formatu),
            "x_twarzy": 0.77 (środek twarzy w poziomie, część szerokości; przy "lewo" liczone od prawej),
            "gora": 0.02 (czubek głowy od górnej krawędzi), "kadr": "glowa" | "cala" (cała sylwetka, "wysokosc": 0.95)}
    Zwraca ramkę twarzy w kadrze (x0, y0, x1, y1) albo None."""
    from PIL import Image, ImageFilter, ImageOps
    p = sciezka(osoba["plik"])
    if not p.exists():
        blad(f"Nie ma pliku prowadzącego {p} (wytnij go: python narzedzia/osoba.py wytnij ...)")
    im = Image.open(p).convert("RGBA")
    tw = None
    try:
        tw = json.loads(p.with_suffix(".json").read_text(encoding="utf-8")).get("twarz")
    except Exception:
        tw = None
    if osoba.get("odbij"):
        im = ImageOps.mirror(im)
        if tw:
            tw = {**tw, "x": im.width - tw["x"] - tw["szer"]}
    strona = osoba.get("strona", "prawo")
    if tw and osoba.get("kadr", "glowa") == "glowa":
        k = {**kadr_osoby(osoba, W, H), **{n: float(osoba[n]) for n in ("glowa", "gora", "x_twarzy") if n in osoba}}
        gg = tw.get("glowa_gora", tw["y"])
        glowa_px = max(1.0, tw["y"] + tw["wys"] * 1.02 - gg)
        s = k["glowa"] * H / glowa_px
        gora = k["gora"] * H
        y = gora - gg * s
        if y + im.height * s < H:  # sylwetka kończy się nad dolną krawędzią: przesuwamy w dół albo powiększamy
            y_dol = H - im.height * s
            if y_dol + gg * s <= H * 0.25:
                y = y_dol
            else:
                s = (H - gora) / max(1, im.height - gg)
                y = gora - gg * s
        xt = k["x_twarzy"] if strona == "prawo" else 1 - k["x_twarzy"]
        x = xt * W - (tw["x"] + tw["szer"] / 2) * s
        fx0, fx1 = x + tw["x"] * s, x + (tw["x"] + tw["szer"]) * s
        if fx1 > W * 0.98:
            x -= fx1 - W * 0.98
        if fx0 < W * 0.02:
            x += W * 0.02 - fx0
    else:
        wys = int(H * float(osoba.get("wysokosc", 0.95)))
        s = wys / im.height
        if im.width * s > W * 0.6:  # bardzo szeroki kadr: nie więcej niż 60% szerokości
            s = W * 0.6 / im.width
        przes = int(W * float(osoba.get("przesun", 0)))
        x = (W - im.width * s - int(W * 0.02) - przes) if strona == "prawo" else (int(W * 0.02) + przes)
        y = H - im.height * s
    im = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)
    x, y = int(round(x)), int(round(y))
    if osoba.get("obrys"):
        r = max(2, int(H * 0.006))
        a = im.getchannel("A").filter(ImageFilter.MaxFilter(r * 2 + 1))
        ob = Image.new("RGBA", im.size, (*hex_rgb(osoba["obrys"], (255, 255, 255)), 255))
        ob.putalpha(a)
        wklej(ws.nowa("Prowadzący obrys"), ob, x, y)
    wklej(ws.nowa("Prowadzący"), im, x, y)
    if tw:
        return (x + tw["x"] * s, y + tw["y"] * s, x + (tw["x"] + tw["szer"]) * s, y + (tw["y"] + tw["wys"]) * s)
    return None


def slowa_kolorowe(linia):
    """Słowa z oznaczeniem koloru: *tak* = kolor wyróżnienia, !tak! = kolor alarmowy (czerwony); działa też na kilka słów."""
    wyn, stan = [], None
    for s in linia.split():
        if stan is None and s[:1] in ("*", "!") and len(s) > 1:
            stan, s = s[0], s[1:]
        kol = stan
        if stan and s.endswith(stan):
            s, stan = s[:-1], None
        if s:
            wyn.append((s, kol))
    return wyn


def podziel_na_linie(tekst):
    """Linie bloku „stos”: po znaku | albo automatycznie na 1–3 równe linie."""
    if "|" in tekst:
        return [l.strip() for l in tekst.split("|") if l.strip()]
    slowa = tekst.split()
    dl = len(tekst)
    n = 1 if dl <= 12 else 2 if dl <= 30 else 3
    n = min(n, len(slowa))
    cel = dl / max(1, n)
    linie, biez = [], []
    for s in slowa:
        if biez and len(" ".join(biez + [s])) > cel * 1.15 and len(linie) < n - 1:
            linie.append(" ".join(biez))
            biez = []
        biez.append(s)
    linie.append(" ".join(biez))
    return linie


def blok_stos(ws, d, tekst, f_plik, x0, szer, baseline_dol, gora_min, H, kolory_slow, wielkie=True, wyrownanie="left",
              rowno=False, tlo_linii=None, max_znakow=None):
    """Nagłówek jak na miniaturach YouTube: wielkie linie ciasno jedna nad drugą, blok przyklejony do dołu.
    Linie rozdziela znak |. Najdłuższa zwykła linia wypełnia szerokość bloku, reszta ma ten sam rozmiar;
    linia zaczynająca się od + jest powiększona na całą szerokość (krótkie słowo dostaje rozstrzelone litery, np. „B Ł Ą D”),
    od - jest mała (dopisek pod spodem, np. „OTO PRZYCZYNY”). rowno=True: każda linia na całą szerokość.
    tlo_linii: kolor prostokąta pod każdą linią (jak paski na części miniatur). Każda linia to osobna warstwa w PSD.
    Zwraca (górna krawędź bloku, warstwy tekstu)."""
    from PIL import ImageDraw, ImageFont
    surowe = []
    for l in podziel_na_linie(tekst):
        rodzaj = "+" if l.startswith("+") else "-" if l.startswith("-") else ("+" if rowno else "")
        l = l.lstrip("+-").strip()
        slowa = slowa_kolorowe(l.upper() if wielkie else l)
        if slowa:
            surowe.append((rodzaj, slowa))
    # wąskie formaty (pion): długie linie dzielimy na krótsze, żeby litery były duże
    while max_znakow:
        nowe, zmiana = [], False
        for rodzaj, l in surowe:
            dl = len(" ".join(s for s, _ in l))
            k = None
            if rodzaj != "-" and len(l) > 1 and dl > max_znakow:
                # podział najbliżej połowy; żadna część nie może być samym krótkim słowem („W”, „NA”),
                # a linia nie kończy się jednoliterowym słowem (zasada polskiej typografii)
                dobre = []
                for j in range(1, len(l)):
                    lewa, prawa = " ".join(s for s, _ in l[:j]), " ".join(s for s, _ in l[j:])
                    if len(lewa) >= 3 and len(prawa) >= 3 and len(l[j - 1][0]) > 1:
                        dobre.append((abs(len(lewa) - len(prawa)), j))
                k = min(dobre)[1] if dobre else None
            if k:
                nowe += [(rodzaj, l[:k]), (rodzaj, l[k:])]
                zmiana = True
            else:
                nowe.append((rodzaj, l))
        surowe = nowe
        if not zmiana:
            break
    if not surowe:
        return baseline_dol, []
    baza = 100
    fb = ImageFont.truetype(f_plik, baza)
    maks = H * 0.30  # największa linia (wielkość fontu)

    def pelna(l):
        return baza * szer / max(1, d.textlength(" ".join(s for s, _ in l), font=fb))

    zwykle = [pelna(l) for r, l in surowe if r == ""]
    rozm_bazy = min(min(zwykle) if zwykle else min(pelna(l) for _, l in surowe) * 0.6, H * 0.2)

    def miary(skala):
        wyn = []
        for rodzaj, l in surowe:
            r = min(maks, pelna(l)) if rodzaj == "+" else rozm_bazy * (0.5 if rodzaj == "-" else 1.0)
            r *= skala
            t = " ".join(s for s, _ in l)
            f = ImageFont.truetype(f_plik, max(8, int(r)))
            cap = -f.getbbox("H", anchor="ls")[1]
            szer_l = d.textlength(t, font=f)
            sledzenie = 0.0
            znaki = len(t.replace(" ", ""))
            if rodzaj == "+" and len(l) == 1 and 2 <= znaki <= 8 and szer_l < szer * skala * 0.92:
                sledzenie = (szer * skala - szer_l) / (znaki - 1) * 0.85  # krótkie słowo: rozstrzelone litery do szerokości bloku
                szer_l += sledzenie * (znaki - 1)
            wyn.append({"linia": l, "tekst": t, "font": f, "r": int(r), "cap": cap, "szer": szer_l, "sledzenie": sledzenie})
        return wyn

    skala = 1.0
    while True:
        m = miary(skala)
        wys = sum(x["cap"] for x in m) + sum(0.3 * m[i - 1]["cap"] for i in range(1, len(m)))
        if baseline_dol - wys >= gora_min or skala < 0.4:
            break
        skala *= 0.92
    odstep = 0.3 if not tlo_linii else 0.5  # z paskami pod liniami trochę luźniej
    bazy = [0.0] * len(m)
    bazy[-1] = baseline_dol
    for i in range(len(m) - 2, -1, -1):
        bazy[i] = bazy[i + 1] - m[i + 1]["cap"] - odstep * min(m[i]["cap"], m[i + 1]["cap"]) - (0.1 * m[i]["cap"] if m[i]["cap"] > m[i + 1]["cap"] * 1.5 else 0)
    if tlo_linii:
        dt = ImageDraw.Draw(ws.nowa("Tło linii"))
    warstwy = []
    for i, x in enumerate(m):
        lx = x0 + (szer * skala - x["szer"] if wyrownanie == "right" else 0)
        if tlo_linii:
            pad = x["cap"] * 0.22
            dt.rectangle([lx - pad, bazy[i] - x["cap"] - pad, lx + x["szer"] + pad, bazy[i] + pad], fill=tlo_linii)
        opis = opis_tekstu([[(s, k is not None) for s, k in x["linia"]]], x["font"], f_plik, x["r"], x["r"], lx,
                           bazy[i] - x["font"].getmetrics()[0], kolory_slow[None], None)
        opis["runs"] = []
        for k_, (s, k) in enumerate(x["linia"]):
            frag = s + (" " if k_ < len(x["linia"]) - 1 else "")
            kk = list(kolory_slow[k][:3])
            if opis["runs"] and opis["runs"][-1]["kolor"] == kk:
                opis["runs"][-1]["dl"] += len(frag)
            else:
                opis["runs"].append({"dl": len(frag), "kolor": kk})
        if x["sledzenie"]:
            opis["sledzenie"] = round(x["sledzenie"] / max(1, x["r"]) * 1000)
        dr = ImageDraw.Draw(ws.nowa(f"Nagłówek {i + 1}", opis))
        cx = lx
        for k_, (s, k) in enumerate(x["linia"]):
            if x["sledzenie"]:
                for z in s:
                    dr.text((cx, bazy[i]), z, font=x["font"], fill=kolory_slow[k], anchor="ls")
                    cx += d.textlength(z, font=x["font"]) + x["sledzenie"]
            else:
                dr.text((cx, bazy[i]), s, font=x["font"], fill=kolory_slow[k], anchor="ls")
                cx += d.textlength(s + " ", font=x["font"])
        warstwy.append(ws.lista[-1])
    return bazy[0] - m[0]["cap"], warstwy


def cien_tekstu(ws, miejsce, warstwy, H, sila=0.75):
    """Miękki cień pod tekstem (osobna warstwa pod napisami), żeby tekst czytał się na każdym tle."""
    from PIL import Image, ImageChops, ImageFilter
    if not warstwy:
        return
    a = Image.new("L", (ws.W, ws.H), 0)
    for w in warstwy:
        a = ImageChops.lighter(a, w["img"].getchannel("A"))
    r = max(2, int(H * 0.012))
    a = a.filter(ImageFilter.MaxFilter(3)).filter(ImageFilter.GaussianBlur(r)).point(lambda v: int(min(255, v * sila * 1.3)))
    przes = Image.new("L", (ws.W, ws.H), 0)
    przes.paste(a, (int(H * 0.004), int(H * 0.007)))
    cien = Image.new("RGBA", (ws.W, ws.H), (0, 0, 0, 0))
    cien.putalpha(przes)
    miejsce["img"].alpha_composite(cien)


def renderuj(spec, W, H, wyjscie, warstwy_folder=None):
    """spec: tlo, naglowek, podtytul, cta, kolory, folder_klienta, font, font_tekstu, logo, fokus_x, fokus_y,
    uklad: auto | dol | gora | srodek | lewo | prawo (gdzie stoi blok tekstu).
    warstwy_folder: jeśli podany, zapisuje tam warstwy do pliku Photoshopa i zwraca ich opis."""
    from PIL import Image, ImageDraw, ImageFont

    kol = spec.get("kolory") or {}
    tekst_k = hex_rgb(kol.get("text"), (255, 255, 255))
    podsw = hex_rgb(kol.get("highlight") or kol.get("accent"), (34, 197, 94))
    akcent = hex_rgb(kol.get("accent") or kol.get("highlight"), (34, 197, 94))
    ciemny = hex_rgb(kol.get("primary") or kol.get("background"), (10, 14, 22))
    poziom = W / H >= 1.3
    story = H / W > 1.6   # Instagram/TikTok zasłaniają górę i dół kadru: trzymamy treść w bezpiecznej strefie
    uklad = spec.get("uklad") or "auto"
    osoba = spec.get("osoba") if isinstance(spec.get("osoba"), dict) and spec["osoba"].get("plik") else None
    if osoba and uklad == "auto":
        uklad = "lewo" if osoba.get("strona", "prawo") == "prawo" else "prawo"  # tekst po drugiej stronie niż prowadzący
    if uklad == "auto":
        uklad = "lewo" if poziom else "dol"
    if poziom and uklad in ("dol", "gora"):
        uklad = "lewo"
    if not poziom and uklad in ("lewo", "prawo"):
        uklad = "dol"
    # „stos”: nagłówek jak na miniaturach YouTube (każda linia na szerokość bloku); domyślnie przy prowadzącym w poziomie
    styl_t = spec.get("styl_tekstu") or ("stos" if (osoba and W / H <= 2.2) or "|" in (spec.get("naglowek") or "") else "zwykly")
    stos = styl_t == "stos" and uklad != "srodek"
    ws = Warstwy(W, H)

    tlo = sciezka(spec["tlo"]) if spec.get("tlo") else None
    if tlo and tlo.exists():
        tlo_img = cover(Image.open(tlo).convert("RGB"), W, H, float(spec.get("fokus_x", 0.5)), float(spec.get("fokus_y", 0.5)))
    else:
        tlo_img = Image.new("RGB", (W, H), ciemny)
    ws.nowa("Tło").paste(tlo_img.convert("RGBA"))

    # przyciemnienie w kolorze marki tam, gdzie stoi tekst
    gd = ImageDraw.Draw(ws.nowa("Przyciemnienie"))
    if stos:
        # ciemniej przy dolnym rogu z tekstem, góra i prowadzący zostają jasne
        import numpy as np
        xs = np.linspace(0, 1, W)[None, :]
        if uklad == "prawo" or (uklad == "dol" and osoba and osoba.get("strona", "prawo") == "lewo"):
            xs = xs[:, ::-1]
        ys = np.linspace(0, 1, H)[:, None]
        sila = float(spec.get("przyciemnienie", 1.0))
        alfa = np.maximum(np.clip(1 - xs / 0.75, 0, 1) ** 1.3 * 190, np.clip((ys - 0.4) / 0.6, 0, 1) ** 1.4 * 210) * sila
        ciem = np.zeros((H, W, 4), np.uint8)
        ciem[..., :3] = ciemny
        ciem[..., 3] = np.clip(alfa, 0, 255).astype(np.uint8)
        ws.lista[-1]["img"] = Image.fromarray(ciem, "RGBA")
    elif uklad in ("lewo", "prawo"):
        koniec = int(W * 0.72)
        for i in range(koniec):
            alfa = int(235 * (1 - i / koniec) ** 1.2)
            x = i if uklad == "lewo" else W - 1 - i
            gd.line([(x, 0), (x, H)], fill=(*ciemny, alfa))
    elif uklad == "srodek":
        gd.rectangle([0, 0, W, H], fill=(*ciemny, 150))
    else:
        start = int(H * 0.35)
        for i in range(H - start):
            alfa = int(235 * (i / (H - start)) ** 1.3)
            y = start + i if uklad == "dol" else H - 1 - start - i
            gd.line([(0, y), (W, y)], fill=(*ciemny, alfa))
    if spec.get("pasek_dol"):
        # pasek w kolorze marki na dole kadru (stały element części serii miniatur), pod prowadzącym
        hp = int(H * float(spec.get("pasek_wys", 0.055)))
        ImageDraw.Draw(ws.nowa("Pasek")).rectangle([0, H - hp, W, H], fill=hex_rgb(spec["pasek_dol"], akcent))
    twarz = dodaj_osobe(ws, osoba, W, H) if osoba else None
    ws.twarz = twarz
    d = ImageDraw.Draw(Image.new("RGBA", (W, H)))  # do mierzenia tekstu

    folder_f = sciezka(spec["folder_klienta"]) / "fonty" if spec.get("folder_klienta") else Path(".")
    f_gruby = fonty.znajdz(folder_f, spec.get("font"), gruby=True)
    if spec.get("font") and (not f_gruby or Path(f_gruby).parent != folder_f):  # nie ma w fontach klienta: wspólne / Google Fonts
        f_gruby = fonty.znajdz_wage(spec["font"], 800, folder_f if folder_f.exists() else None)[0] or f_gruby
    f_zwykly = fonty.znajdz(folder_f, spec.get("font_tekstu") or spec.get("font"), gruby=False) or f_gruby
    if (spec.get("font_tekstu") or spec.get("font")) and Path(f_zwykly).parent != folder_f:
        f_zwykly = fonty.znajdz_wage(spec.get("font_tekstu") or spec.get("font"), 400, folder_f if folder_f.exists() else None)[0] or f_zwykly
    if not f_gruby:
        blad("Brak fontu. Pobierz font marki: python narzedzia/fonty.py pobierz --nazwa NAZWA --folder klienci/marka/fonty")

    # wielkość liter liczona od krótszego boku; bardzo szerokie banery (X, LinkedIn) dostają większy tekst
    baza = (H * 1.4 if W / H >= 2.5 else H * 0.95) if poziom else min(W, H)
    m = max(8, int(baza * 0.075))
    max_w = (W * 0.55) if poziom else (W - 2 * m)
    if uklad == "srodek" and poziom:
        max_w = W * 0.7
    if stos:
        m = max(8, int(W * 0.035)) if poziom else m
        max_w = (W * 0.68) if poziom else (W - 2 * m)
    if twarz and poziom and uklad in ("lewo", "prawo"):
        # tekst nie wchodzi na twarz prowadzącego
        wolne = (twarz[0] - m - W * 0.015) if uklad == "lewo" else (W - m - twarz[2] - W * 0.015)
        max_w = max(W * 0.45, min(max_w, wolne))
    r_nag = int(baza * (0.085 if H <= W * 1.05 else 0.105 if story else 0.095))
    r_pod = max(9, int(baza * 0.042))
    f_pod = ImageFont.truetype(f_zwykly, r_pod)
    r_cta = max(9, int(baza * 0.04))
    f_cta = ImageFont.truetype(f_gruby, r_cta)

    cta = spec.get("cta", "")
    if stos:
        return renderuj_stos(spec, ws, d, W, H, m, max_w, uklad, poziom, story, baza, f_gruby, f_zwykly, f_pod, r_pod, f_cta, r_cta,
                             cta, tekst_k, podsw, akcent, ciemny, kol, wyjscie, warstwy_folder)
    odstep = int(baza * 0.035)
    odstep_cta = int(odstep * float(spec.get("cta_odstep") or 1))  # "cta_odstep": przycisk dalej od tekstu
    # znaczniki układu „stos” w zwykłym układzie: | to zwykła spacja, !słowo! jak *słowo*
    nag_zwykly = " ".join(re.sub(r"^[+-]", "", l.strip()) for l in (spec.get("naglowek") or "").split("|"))
    nag_zwykly = re.sub(r"!([^!]+)!", lambda mm: " ".join(f"*{w}*" for w in mm.group(1).split()), nag_zwykly)
    wys_cta = int(baza * 0.105) if cta else 0
    gora_bezp = int(H * 0.12) if story else m
    dol_bezp = int(H * 0.17) if story else m
    lg = wczytaj_logo(spec, W, m, baza)
    pod_logo = (lg.height + int(baza * 0.04)) if lg else 0
    miejsce = H - gora_bezp - dol_bezp - (max(int(baza * 0.12), pod_logo) if uklad == "gora" else 0)
    # nagłówek: zmniejszamy, aż zmieści się w 4 liniach i w wysokości kadru
    while True:
        f_nag = ImageFont.truetype(f_gruby, max(9, r_nag))
        linie = linie_z_wyroznieniem(nag_zwykly, f_nag, max_w, d)
        pod_linie = linie_z_wyroznieniem(spec.get("podtytul", ""), f_pod, max_w, d) if spec.get("podtytul") else []
        wys_nag = len(linie) * int(r_nag * 1.1)
        wys_pod = len(pod_linie) * int(r_pod * 1.35)
        blok = wys_nag + (odstep + wys_pod if pod_linie else 0) + (odstep_cta + wys_cta if cta else 0)
        if (len(linie) <= 4 and blok <= miejsce) or r_nag < baza * 0.05:
            break
        r_nag = int(r_nag * 0.9)
    r_nag = max(9, r_nag)

    srodek_x = uklad == "srodek"
    if uklad == "dol":
        y = H - dol_bezp - blok
    elif uklad == "gora":
        y = gora_bezp + max(int(baza * 0.12), pod_logo)  # pod logo
    else:
        y = (H - blok) // 2 + (int(H * 0.04) if poziom else 0)
    x0 = (W - m - max_w) if uklad == "prawo" else m
    wyr = "center" if srodek_x else "left"

    def x_linii(szer):
        return (W - szer) / 2 if srodek_x else x0

    kotwica_x = W / 2 if srodek_x else x0
    dn = ImageDraw.Draw(ws.nowa("Nagłówek", opis_tekstu(linie, f_nag, f_gruby, r_nag, int(r_nag * 1.1), kotwica_x, y, tekst_k, podsw, wyr)))
    for linia in linie:
        szer = d.textlength(" ".join(s for s, _ in linia), font=f_nag)
        x = x_linii(szer)
        for slowo, wyr_ in linia:
            dn.text((x, y), slowo, font=f_nag, fill=podsw if wyr_ else tekst_k)
            x += d.textlength(slowo + " ", font=f_nag)
        y += int(r_nag * 1.1)
    if spec.get("cien"):
        mc = {"nazwa": "Cień tekstu", "img": Image.new("RGBA", (W, H), (0, 0, 0, 0)), "tekst": None, "krycie": 1.0}
        ws.lista.insert(len(ws.lista) - 1, mc)
        cien_tekstu(ws, mc, [ws.lista[-1]], H)
    if pod_linie:
        y += odstep
        dp = ImageDraw.Draw(ws.nowa("Podtytuł", opis_tekstu(pod_linie, f_pod, f_zwykly, r_pod, int(r_pod * 1.35), kotwica_x, y, tekst_k, None, wyr), 0.9))
        for linia in pod_linie:
            t = " ".join(s for s, _ in linia)
            dp.text((x_linii(d.textlength(t, font=f_pod)), y), t, font=f_pod, fill=tekst_k)
            y += int(r_pod * 1.35)
    if cta:
        y += odstep_cta
        tw = d.textlength(cta, font=f_cta)
        bw, bh = tw + baza * 0.09, wys_cta
        bx = x_linii(bw)
        ImageDraw.Draw(ws.nowa("Przycisk")).rounded_rectangle([bx, y, bx + bw, y + bh], radius=bh / 2, fill=akcent)
        bb = d.textbbox((0, 0), cta, font=f_cta)
        jasny = sum(akcent) / 3 > 140
        k_cta = ciemny if jasny else (255, 255, 255)
        ty = y + (bh - (bb[3] - bb[1])) / 2 - bb[1]
        ImageDraw.Draw(ws.nowa("Tekst przycisku", opis_tekstu([[(w, False) for w in cta.split()]], f_cta, f_gruby, r_cta, r_cta, bx + bw / 2, ty,
                                                               k_cta, None, "center"))).text((bx + (bw - tw) / 2, ty), cta, font=f_cta, fill=k_cta)

    domyslne = "srodek" if srodek_x else "prawo" if uklad == "prawo" else "lewo"
    return zakoncz(spec, ws, W, H, baza, m, domyslne, gora_bezp, wyjscie, warstwy_folder, f_gruby)


def wczytaj_logo(spec, W, m, baza):
    """Logo klienta z przyciętymi pustymi marginesami pliku; "logo_skala" powiększa (domyślnie 1). None = bez logo."""
    from PIL import Image
    if spec.get("logo") is False or spec.get("bez_logo"):
        return None  # zadanie „bez logo klienta”
    logo = sciezka(spec["logo"]) if spec.get("logo") else (sciezka(spec["folder_klienta"]) / "logo.png" if spec.get("folder_klienta") else None)
    if not (logo and logo.exists()):
        return None
    lg = Image.open(logo).convert("RGBA")
    ramka = lg.getchannel("A").point(lambda v: 255 if v > 8 else 0).getbbox()
    if ramka:
        lg = lg.crop(ramka)
    sk = float(spec.get("logo_skala") or 1)
    lg.thumbnail((int(min(W - 2 * m, baza * 0.28 * sk)), int(baza * 0.09 * sk)))
    return lg


def zakoncz(spec, ws, W, H, baza, m, domyslne_miejsce, ly, wyjscie, warstwy_folder, f_gruby):
    """Logo (gdy jest; "logo_miejsce": lewo | srodek | prawo), złożenie warstw, zapis PNG i warstw do PSD."""
    lg = wczytaj_logo(spec, W, m, baza)
    if lg:
        miejsce_logo = spec.get("logo_miejsce") or domyslne_miejsce
        lx = (W - lg.width) // 2 if miejsce_logo == "srodek" else (W - m - lg.width if miejsce_logo == "prawo" else m)
        ws.nowa("Logo").alpha_composite(lg, (int(lx), int(ly)))
    img = ws.zlacz()
    wyjscie = Path(wyjscie)
    wyjscie.parent.mkdir(parents=True, exist_ok=True)
    img.convert("RGB").save(wyjscie, quality=94)
    KONTROLA.clear()
    KONTROLA.update(kontrola(ws, W, H))
    opis = ws.zapisz_do_psd(warstwy_folder) if warstwy_folder else None
    return str(wyjscie), f_gruby, opis


KONTROLA = {}


def kontrola(ws, W, H):
    """Liczby do sprawdzenia grafiki (oprócz obejrzenia jej): wielkość tekstu i twarzy, nachodzenie tekstu na twarz,
    prowadzący wiszący w powietrzu, tekst ucięty krawędzią. Wynik trafia do „kontrola” i „uwagi” w wyniku serii."""
    tekst = [w for w in ws.lista if w["nazwa"].startswith("Nagłówek")]
    k, uwagi = {}, []
    caps = []
    for w in tekst:
        if w["tekst"]:
            caps.append(w["tekst"]["rozmiar"] * 0.72)  # wysokość wielkich liter ok. 0,72 rozmiaru fontu
    if caps:
        k["tekst_najwiekszy_proc"] = round(max(caps) / H * 100, 1)
        k["tekst_najmniejszy_proc"] = round(min(caps) / H * 100, 1)
    box = None
    for w in tekst:
        b = w["img"].getbbox()
        if b:
            box = b if not box else (min(box[0], b[0]), min(box[1], b[1]), max(box[2], b[2]), max(box[3], b[3]))
    if box:
        k["tekst_ramka"] = list(box)
        if box[0] <= 1 or box[2] >= W - 1 or box[1] <= 1 or box[3] >= H - 1:
            uwagi.append("tekst dotyka krawędzi kadru (może być ucięty)")
    tw = getattr(ws, "twarz", None)
    if tw:
        k["twarz_proc"] = round((tw[3] - tw[1]) / H * 100, 1)
        if box:
            fb = tuple(int(v) for v in (max(0, tw[0]), max(0, tw[1]), min(W, tw[2]), min(H, tw[3])))
            if fb[2] > fb[0] and fb[3] > fb[1]:
                zakryte = 0
                for w in tekst + [x for x in ws.lista if x["nazwa"] in ("Tło linii", "Podtytuł", "Przycisk")]:
                    a = w["img"].getchannel("A").crop(fb)
                    zakryte = max(zakryte, sum(a.point(lambda v: 1 if v > 128 else 0).getdata()))
                if zakryte > 0.03 * (fb[2] - fb[0]) * (fb[3] - fb[1]):
                    uwagi.append("tekst zasłania twarz prowadzącego")
        if tw[0] < 0 or tw[2] > W or tw[1] < 0:
            uwagi.append("twarz wychodzi poza kadr")
    for w in ws.lista:
        if w["nazwa"] == "Prowadzący":
            b = w["img"].getbbox()
            if b and b[3] < H - 2:
                uwagi.append("prowadzący nie sięga dolnej krawędzi (wisi w powietrzu)")
    poziom = W / H >= 1.3
    if caps and poziom and max(caps) / H < 0.06:
        uwagi.append(f"nagłówek mały (największe litery {max(caps) / H * 100:.0f}% wysokości; na miniaturach celuj w 7–20%)")
    if caps and not poziom and max(caps) / W < 0.05:
        uwagi.append("nagłówek mały jak na ten format")
    k["uwagi"] = uwagi
    return k


def renderuj_stos(spec, ws, d, W, H, m, max_w, uklad, poziom, story, baza, f_gruby, f_zwykly, f_pod, r_pod, f_cta, r_cta,
                  cta, tekst_k, podsw, akcent, ciemny, kol, wyjscie, warstwy_folder):
    """Układ „stos”: wielki nagłówek z linii na całą szerokość bloku przy dolnej krawędzi, pod nim (opcjonalnie)
    podtytuł i przycisk. Kolory: zwykły tekst, *wyróżnienie*, !alarm! (kolory.alarm, domyślnie czerwony)."""
    from PIL import Image, ImageDraw
    alarm = hex_rgb(kol.get("alarm"), (255, 31, 31))
    kolory_slow = {None: (*tekst_k, 255), "*": (*podsw, 255), "!": (*alarm, 255)}
    dol = int(H * (0.17 if story else 0.09)) + (int(H * float(spec.get("pasek_wys", 0.055))) if spec.get("pasek_dol") else 0)
    gora = int(H * (0.12 if story else 0.06))
    odstep = int(baza * 0.035)
    pod_linie = linie_z_wyroznieniem(spec.get("podtytul", ""), f_pod, max_w, d) if spec.get("podtytul") else []
    odstep_cta = int(odstep * float(spec.get("cta_odstep") or 1))
    wys_cta = int(baza * 0.105) if cta else 0
    reszta = (odstep + len(pod_linie) * int(r_pod * 1.35) if pod_linie else 0) + (odstep_cta + wys_cta if cta else 0)
    x0 = (W - m - max_w) if uklad == "prawo" else m
    wyr = "right" if uklad == "prawo" else "left"
    miejsce_cienia = {"nazwa": "Cień tekstu", "img": Image.new("RGBA", (W, H), (0, 0, 0, 0)), "tekst": None, "krycie": 1.0}
    ws.lista.append(miejsce_cienia)
    lg = wczytaj_logo(spec, W, m, baza)
    gorna_tekstu = min(H * 0.55, gora + ((lg.height + int(baza * 0.04)) if lg else 0))
    baseline = H - dol - reszta
    gora_bloku = gorna_tekstu if poziom else H * 0.45
    tw = getattr(ws, "twarz", None)
    if tw and not poziom:
        gora_bloku = max(gora_bloku, min(tw[3] + H * 0.02, baseline - H * 0.12))  # w pionie tekst zaczyna się pod brodą
    tlo_l = hex_rgb(spec["tlo_linii"], (17, 17, 17)) if spec.get("tlo_linii") else None
    args = (d, spec.get("naglowek", ""), f_gruby, x0, max_w)
    kw = dict(wielkie=spec.get("wielkie", True), wyrownanie=wyr, rowno=bool(spec.get("rowno")), tlo_linii=tlo_l,
              max_znakow=None if poziom else (11 if H / W > 1.15 else 16))
    miejsce_t = spec.get("miejsce_tekstu", "dol")
    if miejsce_t in ("srodek", "gora"):
        # najpierw pomiar wysokości bloku, potem właściwe położenie
        top, _ = blok_stos(Warstwy(W, H), *args, baseline, gora_bloku, H, kolory_slow, **kw)
        h = baseline - top
        cel_top = gora_bloku if miejsce_t == "gora" else max(gora_bloku, (H - h - reszta) / 2)
        baseline = min(baseline, cel_top + h)
    _, warstwy = blok_stos(ws, *args, baseline, gora_bloku, H, kolory_slow, **kw)
    y = baseline + int(H * 0.02)
    if pod_linie:
        y += odstep
        dp = ImageDraw.Draw(ws.nowa("Podtytuł", opis_tekstu(pod_linie, f_pod, f_zwykly, r_pod, int(r_pod * 1.35), x0, y, tekst_k, None, "left")))
        for linia in pod_linie:
            tx = " ".join(s for s, _ in linia)
            lx = x0 + (max_w - d.textlength(tx, font=f_pod) if wyr == "right" else 0)
            dp.text((lx, y), tx, font=f_pod, fill=tekst_k)
            y += int(r_pod * 1.35)
        warstwy.append(ws.lista[-1])
    if cta:
        y += odstep_cta
        tw = d.textlength(cta, font=f_cta)
        bw, bh = tw + baza * 0.09, wys_cta
        bx = x0 + (max_w - bw if wyr == "right" else 0)
        ImageDraw.Draw(ws.nowa("Przycisk")).rounded_rectangle([bx, y, bx + bw, y + bh], radius=bh / 2, fill=akcent)
        bb = d.textbbox((0, 0), cta, font=f_cta)
        k_cta = ciemny if sum(akcent) / 3 > 140 else (255, 255, 255)
        ty = y + (bh - (bb[3] - bb[1])) / 2 - bb[1]
        ImageDraw.Draw(ws.nowa("Tekst przycisku", opis_tekstu([[(w_, False) for w_ in cta.split()]], f_cta, f_gruby, r_cta, r_cta, bx + bw / 2, ty,
                                                               k_cta, None, "center"))).text((bx + (bw - tw) / 2, ty), cta, font=f_cta, fill=k_cta)
    if spec.get("cien", True):
        cien_tekstu(ws, miejsce_cienia, warstwy, H)
    return zakoncz(spec, ws, W, H, baza, m, "prawo" if uklad == "prawo" else "lewo", gora, wyjscie, warstwy_folder, f_gruby)


def arkusz_podgladu(pliki_wg_grafiki, formaty, wyj):
    """Wszystkie grafiki na jednym obrazku: wiersz = grafika, kolumna = format."""
    from PIL import Image, ImageDraw

    wys = 300
    kolumny = [min(560, int(FORMATY[f][0] * wys / FORMATY[f][1])) for f in formaty]
    odst = 16
    W = sum(kolumny) + odst * (len(formaty) + 1)
    H = len(pliki_wg_grafiki) * (wys + odst) + odst
    ark = Image.new("RGB", (W, H), (30, 30, 30))
    d = ImageDraw.Draw(ark)
    for r, pliki in enumerate(pliki_wg_grafiki):
        x = odst
        for c, plik in enumerate(pliki):
            im = Image.open(plik).convert("RGB")
            im.thumbnail((kolumny[c], wys))
            ark.paste(im, (x, odst + r * (wys + odst)))
            d.text((x + 6, odst + r * (wys + odst) + 6), f"{r + 1:02d} {SKROTY[formaty[c]]}", fill=(255, 220, 0))
            x += kolumny[c] + odst
    ark.save(wyj, quality=85)


def zloz_psd(formaty, nazwy, opisy, pliki, wyj):
    """Jeden plik Photoshopa na całą serię: rząd = grafika, kolumny = jej formaty, każda na osobnym artboardzie
    (np. 01_czym-jest-etf_1080x1350 | 01_czym-jest-etf_1080x1920 | ...). Teksty zostają edytowalne."""
    import shutil
    import subprocess
    from PIL import Image

    node = shutil.which("node")
    skrypt = Path(__file__).resolve().parent / "psd" / "zloz_psd.js"
    if not node:
        return None, ("Brak Node.js, więc plik Photoshopa nie powstał. Zainstaluj: winget install OpenJS.NodeJS.LTS, "
                      "zamknij i otwórz terminal, potem: python narzedzia/grafika.py psd --plan <seria.json>")
    odst = 200
    szer_kol = [FORMATY[f][0] for f in formaty]
    wys_rzedu = max(FORMATY[f][1] for f in formaty)
    DW = sum(szer_kol) + odst * (len(formaty) + 1)
    DH = len(nazwy) * wys_rzedu + odst * (len(nazwy) + 1)
    kompozyt = Image.new("RGB", (DW, DH), (40, 40, 40))
    artboardy = []
    for r, nazwa in enumerate(nazwy):
        ay = odst + r * (wys_rzedu + odst)
        ax = odst
        for c, f in enumerate(formaty):
            W, H = FORMATY[f]
            kompozyt.paste(Image.open(pliki[r][c]).convert("RGB"), (ax, ay))
            warstwy = []
            for w in opisy[r][c]:
                t = dict(w["tekst"]) if w["tekst"] else None
                if t:
                    t["x"] += ax
                    t["y"] += ay
                warstwy.append({**w, "x": w["x"] + ax, "y": w["y"] + ay, "tekst": t})
            artboardy.append({"nazwa": f"{r + 1:02d}_{nazwa}_{W}x{H}", "x": ax, "y": ay, "w": W, "h": H, "warstwy": warstwy})
            ax += W + odst
    duzy = DW > 30000 or DH > 30000  # powyżej 30 000 px Photoshop wymaga formatu PSB (otwiera się tak samo)
    folder_psd = wyj / "photoshop"
    folder_psd.mkdir(exist_ok=True)
    cel = folder_psd / ("seria.psb" if duzy else "seria.psd")
    komp_plik = wyj / "_psd" / "kompozyt.png"
    komp_plik.parent.mkdir(parents=True, exist_ok=True)
    kompozyt.save(komp_plik, compress_level=1)
    zadanie = {"wyjscie": str(cel), "szerokosc": DW, "wysokosc": DH, "kompozyt": str(komp_plik), "artboardy": artboardy}
    zad_plik = wyj / "_psd" / "psd.json"
    zad_plik.write_text(json.dumps(zadanie, ensure_ascii=False), encoding="utf-8")
    r_ = subprocess.run([node, str(skrypt), str(zad_plik)], capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r_.returncode != 0:
        return None, f"Składanie PSD nie powiodło się: {(r_.stderr or r_.stdout)[-800:]}"
    shutil.rmtree(wyj / "_psd", ignore_errors=True)
    return str(cel), None


def seria(plan_plik, tylko_psd=False):
    plan = json.loads(sciezka(plan_plik).read_text(encoding="utf-8"))
    formaty = [f for f in dodaj_wlasne(plan.get("formaty", ["post-4x5"])) if f in FORMATY]
    if not formaty:
        blad(f"Brak poprawnych formatów. Dostępne: {', '.join(FORMATY)}")
    grafiki = plan.get("grafiki") or []
    if not grafiki:
        blad("Plan serii nie ma listy „grafiki”.")
    wyj = sciezka(plan.get("wyjscie", "wyniki/seria"))
    psd = plan.get("psd", True) or tylko_psd
    wspolne = {k: plan.get(k) for k in ("folder_klienta", "font", "font_tekstu", "kolory", "logo", "bez_logo", "cta", "uklad",
                                         "logo_skala", "logo_miejsce", "cta_odstep", "styl_tekstu", "miejsce_tekstu", "rowno",
                                         "tlo_linii", "pasek_dol", "pasek_wys", "cien", "wielkie", "przyciemnienie")}
    wszystkie, opisy, nazwy, font_uzyty = [], [], [], None
    kontrole, uwagi_kontroli = [], []
    for i, g in enumerate(grafiki, 1):
        spec = {**{k: v for k, v in wspolne.items() if v is not None}, **g}
        nazwa = g.get("nazwa") or f"grafika{i}"
        nazwy.append(nazwa)
        pliki, op = [], []
        for f in formaty:
            W, H = FORMATY[f]
            plik, font_uzyty, o = renderuj(spec, W, H, wyj / f"{i:02d}_{nazwa}_{SKROTY[f]}.png",
                                           (wyj / "_psd" / f"{i:02d}_{f}") if psd else None)
            pliki.append(plik)
            op.append(o)
            spr = dict(KONTROLA)
            kontrole.append({"plik": plik, **spr})
            for u in spr.get("uwagi", []):
                uwagi_kontroli.append(f"{Path(plik).name}: {u}")
        wszystkie.append(pliki)
        opisy.append(op)
    podglad = wyj / "podglad_serii.jpg"
    arkusz_podgladu(wszystkie, formaty, podglad)
    pliki_psd, uwaga = zloz_psd(formaty, nazwy, opisy, wszystkie, wyj) if psd else (None, None)
    dane = dict(folder=str(wyj), liczba_grafik=len(grafiki), formaty=formaty, plikow=sum(len(p) for p in wszystkie),
                podglad=str(podglad), font=font_uzyty, photoshop=pliki_psd,
                artboardow=len(grafiki) * len(formaty) if pliki_psd else 0)
    if uwaga:
        dane["uwaga_photoshop"] = uwaga
    dane["kontrola"] = kontrole
    dane["uwagi_kontroli"] = uwagi_kontroli or ["brak (i tak obejrzyj każdą grafikę w pełnym rozmiarze)"]
    wynik(**dane)


def porownaj(folder, referencje, wyjscie=None, ile_wzorow=3):
    """Arkusze do kontroli: na górze 2–3 grafiki-wzory klienta o tych samych proporcjach (najnowsze), pod nimi nasze
    grafiki w tej samej wielkości. Jeden arkusz na proporcje: porownanie_<format>.jpg."""
    from PIL import Image, ImageDraw
    f = sciezka(folder)
    nasze = sorted(x for x in f.glob("*.png") if not x.name.startswith(("podglad", "porownanie")))
    if not nasze:
        blad(f"W {f} nie ma grafik PNG.")
    wz = []
    for r in ([sciezka(referencje)] if referencje else []):
        if r.is_dir():
            wz += [x for x in r.rglob("*") if x.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp") and "web" not in x.parts]
        elif r.exists():
            wz.append(r)
    wz.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    proporcje_wz = []
    for x in wz:
        try:
            with Image.open(x) as im:
                proporcje_wz.append((x, im.width / im.height))
        except Exception:
            pass
    grupy = {}
    for x in nasze:
        with Image.open(x) as im:
            grupy.setdefault(round(im.width / im.height, 2), []).append(x)
    wyj = sciezka(wyjscie) if wyjscie else f
    wyj.mkdir(parents=True, exist_ok=True)
    arkusze = []
    for prop, pliki in grupy.items():
        pasujace = [x for x, pr in proporcje_wz if abs(pr / prop - 1) < 0.12][:ile_wzorow]
        wys = 360 if prop >= 1.3 else 520
        szer = int(wys * prop)
        kol = max(2, min(3, 1700 // (szer + 16)))
        rzedy = [pasujace] if pasujace else []
        rzedy += [pliki[i:i + kol] for i in range(0, len(pliki), kol)]
        H = 16 + len(rzedy) * (wys + 44)
        W = 16 + max(len(r) for r in rzedy) * (szer + 16)
        ark = Image.new("RGB", (W, H), (28, 28, 28))
        d = ImageDraw.Draw(ark)
        y = 16
        for ri, r in enumerate(rzedy):
            wzory = bool(pasujace) and ri == 0
            d.text((16, y), "WZORY KLIENTA" if wzory else "NASZE", fill=(255, 220, 0) if wzory else (160, 230, 255))
            for ci, x in enumerate(r):
                im = Image.open(x).convert("RGB")
                im = im.resize((szer, wys))
                ark.paste(im, (16 + ci * (szer + 16), y + 20))
                d.text((16 + ci * (szer + 16), y + 22 + wys), x.name[:60], fill=(200, 200, 200))
            y += wys + 44
        cel = wyj / f"porownanie_{szer}x{wys}.jpg"
        ark.save(cel, quality=88)
        arkusze.append({"plik": str(cel), "wzory": [str(x) for x in pasujace], "nasze": len(pliki)})
    wynik(arkusze=arkusze, uwaga="Obejrzyj każdy arkusz (Read) i porównaj z wzorami: wielkość tekstu, wielkość twarzy, miejsce tekstu, "
          "kolory, ilość tekstu, kontrast. Każdą grafikę obejrzyj też osobno w pełnym rozmiarze.")


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "porownaj":
        p = argparse.ArgumentParser(description="Arkusz: nasze grafiki obok wzorów klienta")
        p.add_argument("tryb"); p.add_argument("--folder", required=True); p.add_argument("--referencje"); p.add_argument("--wyjscie")
        a = p.parse_args()
        porownaj(a.folder, a.referencje, a.wyjscie)
        sys.exit(0)
    if len(sys.argv) > 1 and sys.argv[1] in ("seria", "psd"):
        p = argparse.ArgumentParser(description="Seria grafik")
        p.add_argument("tryb")
        p.add_argument("--plan", required=True)
        a = p.parse_args()
        seria(a.plan, tylko_psd=a.tryb == "psd")
    else:
        p = argparse.ArgumentParser(description="Grafika w barwach marki")
        p.add_argument("--tlo"); p.add_argument("--wyjscie", required=True); p.add_argument("--format", default="post-4x5")
        p.add_argument("--folder-klienta"); p.add_argument("--font"); p.add_argument("--font-tekstu"); p.add_argument("--logo")
        p.add_argument("--naglowek", required=True); p.add_argument("--podtytul", default=""); p.add_argument("--cta", default="")
        p.add_argument("--kolory", default=""); p.add_argument("--fokus-x", type=float, default=0.5); p.add_argument("--fokus-y", type=float, default=0.5)
        p.add_argument("--uklad", default="auto", choices=["auto", "dol", "gora", "srodek", "lewo", "prawo"])
        a = p.parse_args()
        if a.format not in FORMATY:
            blad(f"Nieznany format {a.format}. Dostępne: {', '.join(FORMATY)}")
        W, H = FORMATY[a.format]
        spec = {"tlo": a.tlo, "naglowek": a.naglowek, "podtytul": a.podtytul, "cta": a.cta,
                "kolory": json.loads(a.kolory) if a.kolory else {}, "folder_klienta": a.folder_klienta,
                "font": a.font, "font_tekstu": a.font_tekstu, "logo": a.logo, "fokus_x": a.fokus_x, "fokus_y": a.fokus_y,
                "uklad": a.uklad}
        plik, f, _ = renderuj(spec, W, H, sciezka(a.wyjscie))
        wynik(plik=plik, format=f"{W}x{H}", font=f)
