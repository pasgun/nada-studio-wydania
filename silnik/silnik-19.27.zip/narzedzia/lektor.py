"""Lektor z ElevenLabs: tekst -> lektor.mp3 + slowa.json (czas każdego słowa, do napisów).

Użycie:
  python narzedzia/lektor.py --tekst-plik wyniki/X/lektor.txt --voice VOICE_ID --wyjscie wyniki/X
  python narzedzia/lektor.py --glosy        (lista Twoich głosów z ID)
"""
import argparse
import base64
import json
import subprocess
from pathlib import Path

from wspolne import blad, klucz, wynik, zapytanie

API = "https://api.elevenlabs.io/v1"


def lista_glosow():
    r = zapytanie("GET", f"{API}/voices", naglowki={"xi-api-key": klucz("ELEVENLABS_API_KEY")})
    glosy = [{"nazwa": g.get("name"), "voice_id": g.get("voice_id"), "kategoria": g.get("category")} for g in r.json().get("voices", [])]
    wynik(glosy=glosy)


def slowa_z_alignmentu(al):
    """Skleja znaki z ElevenLabs w słowa z czasem początku i końca."""
    znaki = al.get("characters") or []
    starty = al.get("character_start_times_seconds") or []
    konce = al.get("character_end_times_seconds") or []
    slowa, biezace, start = [], "", None
    koniec = 0.0
    for z, s, k in zip(znaki, starty, konce):
        if z.isspace():
            if biezace:
                slowa.append({"slowo": biezace, "start": round(start, 3), "koniec": round(koniec, 3)})
            biezace, start = "", None
            continue
        if start is None:
            start = s
        biezace += z
        koniec = k
    if biezace:
        slowa.append({"slowo": biezace, "start": round(start, 3), "koniec": round(koniec, 3)})
    return slowa


def dlugosc_audio(plik):
    try:
        out = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(plik)],
                             capture_output=True, text=True, encoding="utf-8", errors="replace", check=True).stdout.strip()
        return round(float(out), 2)
    except Exception:
        return None


def generuj(tekst, voice, model, wyjscie, predkosc, stabilnosc):
    wyjscie = Path(wyjscie)
    wyjscie.mkdir(parents=True, exist_ok=True)
    body = {"text": tekst, "model_id": model,
            "voice_settings": {"stability": stabilnosc, "similarity_boost": 0.8, "style": 0.2, "use_speaker_boost": True, "speed": predkosc}}
    if model != "eleven_v3":
        body["language_code"] = "pl"
    # 128 kbps działa na każdym planie ElevenLabs (192 kbps tylko od planu Creator)
    r = zapytanie("POST", f"{API}/text-to-speech/{voice}/with-timestamps",
                  naglowki={"xi-api-key": klucz("ELEVENLABS_API_KEY"), "Content-Type": "application/json"},
                  json_body=body, params={"output_format": "mp3_44100_128"}, timeout=300)
    dane = r.json()
    audio = wyjscie / "lektor.mp3"
    audio.write_bytes(base64.b64decode(dane["audio_base64"]))
    al = dane.get("alignment") or dane.get("normalized_alignment") or {}
    slowa = slowa_z_alignmentu(al)
    (wyjscie / "slowa.json").write_text(json.dumps(slowa, ensure_ascii=False, indent=1), encoding="utf-8")
    wynik(audio=str(audio), slowa=str(wyjscie / "slowa.json"), liczba_slow=len(slowa), dlugosc_s=dlugosc_audio(audio))


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Lektor ElevenLabs")
    p.add_argument("--glosy", action="store_true", help="pokaż listę głosów z ID")
    p.add_argument("--tekst-plik")
    p.add_argument("--tekst")
    p.add_argument("--voice")
    p.add_argument("--model", default="eleven_multilingual_v2")
    p.add_argument("--predkosc", type=float, default=1.0, help="0.7–1.2")
    p.add_argument("--stabilnosc", type=float, default=0.5)
    p.add_argument("--wyjscie")
    a = p.parse_args()
    if a.glosy:
        lista_glosow()
    else:
        tekst = a.tekst or (Path(a.tekst_plik).read_text(encoding="utf-8") if a.tekst_plik else "")
        if not tekst.strip():
            blad("Podaj --tekst albo --tekst-plik")
        if not a.voice:
            blad("Podaj --voice (voice ID z karty klienta). Listę pokaże: python narzedzia/lektor.py --glosy")
        if not a.wyjscie:
            blad("Podaj --wyjscie (folder zadania)")
        generuj(tekst.strip(), a.voice, a.model, a.wyjscie, a.predkosc, a.stabilnosc)
