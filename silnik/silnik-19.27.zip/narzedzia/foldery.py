"""Foldery na PC otwierane przyciskami ze Studio Nadamedia.

Przycisk „Utwórz folder” / „Otwórz folder” w Studio otwiera link studio-rolek://otworz?p=<ścieżka>.
Windows przekazuje go do tego skryptu, który tworzy folder (jeśli go nie ma), wrzuca do niego
krótką instrukcję CZYTAJ.txt i otwiera go w Eksploratorze.

Jednorazowa instalacja (bez uprawnień administratora):
  python narzedzia/foldery.py --instaluj
Usunięcie:
  python narzedzia/foldery.py --odinstaluj
Ręcznie, bez przeglądarki:
  python narzedzia/foldery.py --otworz klienci/marka/referencje/wideo

Bezpieczeństwo: skrypt działa tylko wewnątrz folderu silnika i tylko w folderach klienci, nagrania,
materialy, envato, muzyka, wyniki, napisy i zlecenia. Niczego nie usuwa i nie uruchamia innych programów poza Eksploratorem.
"""
import os
import re
import subprocess
import sys
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

KATALOG = Path(__file__).resolve().parent.parent
DOZWOLONE = {"klienci", "nagrania", "materialy", "envato", "muzyka", "wyniki", "napisy", "zlecenia"}
PROTOKOL = "studio-rolek"

OPISY = {
    "referencje/wideo": "Wrzuć tu 3–5 gotowych rolek albo filmów-wzorów (MP4) tego klienta.\n"
                        "Claude przeanalizuje je raz i zapisze notatkę stylu styl_wideo.md w folderze klienta.",
    "referencje/grafiki": "Wrzuć tu 3–10 grafik-wzorów (PNG, JPG): posty, banery, reklamy, które klient lubi.\n"
                          "Claude przeanalizuje je raz i zapisze notatkę stylu styl_grafiki.md w folderze klienta.",
    "nagrania": "Wrzuć tu nagrania do tego zadania (MP4, MOV, MXF, MTS).\n"
                "Pliki RAW (BRAW, R3D) zostaw tutaj, a ich proksy MP4 o tych samych nazwach wrzuć do podfolderu _proksy.",
    "materialy": "Wrzuć tu swoje materiały do tych grafik: zdjęcia produktu, ludzi, miejsca, zrzuty ekranu.\n"
                 "Claude użyje ich jako teł albo elementów grafik zamiast stocka lub AI.",
    "brandbook": "Wrzuć tu brandbook (PDF), księgę znaku, warianty logo (na jasne i ciemne tło), palety i zasady marki.\n"
                 "Claude przeczyta to raz i zapisze notatkę marki marka.md w folderze klienta: które kolory są tłem,\n"
                 "tekstem, akcentem i przyciskiem, jak używać logo i fontów. Po dorzuceniu nowych plików notatka się odświeży.",
    "logo": "Wrzuć tu wszystkie wersje logo (PNG z przezroczystym tłem albo SVG). Nazwy mówiące, do czego są, np.:\n"
            "logo_kolor.png, logo_biale.png (na ciemne tła i zdjęcia), logo_czarne.png, sygnet.png (sam znak), logo_poziome.png.\n"
            "Claude dobierze wersję do tła. logo.png w folderze klienta zostaje wersją domyślną.",
    "fonty": "Wrzuć tu pliki fontów marki (.ttf albo .otf), wszystkie grubości, które macie.\n"
             "Fonty z Google Fonts Claude pobierze sam, wystarczy nazwa w karcie klienta.",
    "zlecenia": "Wrzuć tu pliki do tego zlecenia (filmy, nagrania, grafiki, PSD).\n"
                "Gotowe wyniki pojawią się w podfolderze gotowe.",
    "napisy": "Wrzuć tu gotowe filmy (MP4, MOV), do których mają dojść napisy.\n"
              "Gotowe filmy z napisami pojawią się w podfolderze gotowe, obok każdego plik .srt.",
    "klient": "Folder klienta.\n"
              "logo.png        logo marki (najlepiej z przezroczystym tłem)\n"
              "fonty\\          pliki fontów marki (.ttf/.otf)\n"
              "makiety\\pl\\     zrzuty ekranów aplikacji klienta (inne języki: makiety\\sv\\ itd., te same nazwy plików)\n"
              "logo\\           wszystkie wersje logo (kolorowe, białe, sygnet...)\n"
              "brandbook\\      brandbook PDF, zasady marki\n"
              "referencje\\wideo\\    filmy-wzory\n"
              "referencje\\grafiki\\  grafiki-wzory",
}


def bezpieczna(sciezka_wzgl):
    """Zamienia ścieżkę z linku na ścieżkę w folderze silnika albo zwraca None, jeśli jest niedozwolona."""
    s = unquote(sciezka_wzgl or "").replace("\\", "/").strip().strip("/")
    czesci = [c for c in s.split("/") if c]
    if not czesci or czesci[0] not in DOZWOLONE:
        return None
    if any(c in (".", "..") or not re.fullmatch(r"[\w\-. ]{1,120}", c) for c in czesci):
        return None
    p = (KATALOG / Path(*czesci)).resolve()
    if KATALOG not in p.parents and p != KATALOG:
        return None
    return p, czesci


def opis_dla(czesci):
    w = "/".join(czesci)
    if len(czesci) == 2 and czesci[0] == "klienci":
        return "klient"
    if len(czesci) == 3 and czesci[0] == "klienci" and czesci[2] in ("brandbook", "logo", "fonty"):
        return czesci[2]
    for klucz in ("referencje/wideo", "referencje/grafiki"):
        if w.endswith(klucz):
            return klucz
    if czesci[0] in ("nagrania", "materialy", "napisy", "zlecenia") and len(czesci) == 2:
        return czesci[0]
    return None


def utworz(p, czesci):
    nowy = not p.exists()
    p.mkdir(parents=True, exist_ok=True)
    rodzaj = opis_dla(czesci)
    if rodzaj == "klient":
        for pod in ("fonty", "logo", "makiety/pl", "brandbook", "referencje/wideo", "referencje/grafiki"):
            (p / pod).mkdir(parents=True, exist_ok=True)
        for pod in ("fonty", "logo", "brandbook", "referencje/wideo", "referencje/grafiki"):
            c = p / pod / "CZYTAJ.txt"
            if not c.exists():
                c.write_text(OPISY[pod], encoding="utf-8")
    if rodzaj and not (p / "CZYTAJ.txt").exists():
        (p / "CZYTAJ.txt").write_text(OPISY[rodzaj], encoding="utf-8")
    return nowy


def otworz_w_eksploratorze(p):
    if sys.platform.startswith("win"):
        os.startfile(str(p))  # noqa: S606 — otwiera tylko folder w Eksploratorze
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(p)])
    else:
        subprocess.Popen(["xdg-open", str(p)])


def komunikat(tytul, tekst):
    """Okienko z błędem (gdy skrypt jest uruchamiany z przeglądarki, nie ma konsoli)."""
    if sys.platform.startswith("win"):
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(0, tekst, tytul, 0x40)
            return
        except Exception:
            pass
    print(f"{tytul}: {tekst}")


def otworz_klucze():
    """Plik z kluczami API (.env) w Notatniku, do wklejenia kluczy. Claude go nie czyta; robi to tylko ten skrypt na Twoim PC."""
    env = KATALOG / ".env"
    if not env.exists():
        wzor = KATALOG / ".env.przyklad"
        env.write_text(wzor.read_text(encoding="utf-8") if wzor.exists() else "", encoding="utf-8")
    if sys.platform.startswith("win"):
        subprocess.Popen(["notepad.exe", str(env)], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    elif sys.platform == "darwin":
        subprocess.Popen(["open", "-e", str(env)])
    else:
        subprocess.Popen(["xdg-open", str(env)])
    return 0


def obsluz(sciezka_wzgl):
    w = bezpieczna(sciezka_wzgl)
    if not w:
        komunikat("Studio rolek", f"Niedozwolona ścieżka: {sciezka_wzgl}")
        return 1
    p, czesci = w
    utworz(p, czesci)
    otworz_w_eksploratorze(p)
    return 0


def instaluj():
    if not sys.platform.startswith("win"):
        print("Instalacja przycisków działa tylko na Windows.")
        return 1
    import winreg
    py = Path(sys.executable)
    pyw = py.with_name("pythonw.exe")
    exe = pyw if pyw.exists() else py
    polecenie = f'"{exe}" "{Path(__file__).resolve()}" "%1"'
    klucz = rf"Software\Classes\{PROTOKOL}"
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, klucz) as k:
        winreg.SetValueEx(k, "", 0, winreg.REG_SZ, "URL:Studio rolek - foldery")
        winreg.SetValueEx(k, "URL Protocol", 0, winreg.REG_SZ, "")
    with winreg.CreateKey(winreg.HKEY_CURRENT_USER, klucz + r"\shell\open\command") as k:
        winreg.SetValueEx(k, "", 0, winreg.REG_SZ, polecenie)
    for f in sorted(DOZWOLONE):
        (KATALOG / f).mkdir(exist_ok=True)
    print("Gotowe. Przyciski folderów w Studio działają na tym komputerze.")
    print("Przy pierwszym kliknięciu Chrome zapyta o otwarcie aplikacji: zaznacz „Zawsze zezwalaj” i kliknij Otwórz.")
    return 0


def odinstaluj():
    if not sys.platform.startswith("win"):
        return 0
    import winreg
    for k in (r"\shell\open\command", r"\shell\open", r"\shell", ""):
        try:
            winreg.DeleteKey(winreg.HKEY_CURRENT_USER, rf"Software\Classes\{PROTOKOL}{k}")
        except OSError:
            pass
    print("Usunięto obsługę przycisków folderów.")
    return 0


if __name__ == "__main__":
    a = sys.argv[1:]
    if not a:
        print(__doc__)
        sys.exit(0)
    if a[0] == "--instaluj":
        sys.exit(instaluj())
    if a[0] == "--odinstaluj":
        sys.exit(odinstaluj())
    if a[0] == "--otworz" and len(a) > 1:
        sys.exit(obsluz(a[1]))
    if a[0].lower().startswith(PROTOKOL + ":"):
        u = urlparse(a[0])
        if u.netloc == "klucze" or u.path.strip("/") == "klucze":
            sys.exit(otworz_klucze())
        p = (parse_qs(u.query).get("p") or [""])[0]
        sys.exit(obsluz(p))
    komunikat("Studio rolek", f"Nieznane polecenie: {' '.join(a)}")
    sys.exit(1)
