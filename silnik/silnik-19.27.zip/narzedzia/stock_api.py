"""Własne stocki użytkownika (dodane w apce Nada Studio: _system/stocki.json).

  python narzedzia/stock_api.py lista
      stocki użytkownika: które mają API (silnik szuka i pobiera sam), a które są ręczne (folder jak envato/)
  python narzedzia/stock_api.py szukaj --serwis pexels --fraza "city at night" [--typ wideo|zdjecia] [--ile 15] [--pion]
  python narzedzia/stock_api.py pobierz --serwis pexels --url <link do pliku z wyniku szukaj> --wyjscie wyniki/.../sceny/s1.mp4
  python narzedzia/stock_api.py pliki --serwis artgrid
      pliki pobrane ręcznie do folderu stocka (stock_reczny/<serwis>/)

Wbudowana obsługa API: Pexels, Pixabay (klucz w .env: STOCK_PEXELS_API_KEY, STOCK_PIXABAY_API_KEY).
Inne serwisy z API: klucz jest w .env pod nazwą z „klucz_env”, dokumentacja w „docs” (patrz `lista`).
"""
import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, klucz, pobierz as pobierz_plik, wynik, zapytanie  # noqa: E402

PLIK = KATALOG_SILNIKA / "_system" / "stocki.json"
MEDIA = {".mp4", ".mov", ".webm", ".m4v", ".jpg", ".jpeg", ".png", ".webp", ".mp3", ".wav", ".aif", ".aiff", ".m4a"}


def stocki():
    try:
        return json.loads(PLIK.read_text(encoding="utf-8"))
    except Exception:
        return []


def stock(slug):
    for s in stocki():
        if s.get("slug") == slug:
            return s
    blad(f"Nie ma stocka „{slug}” na liście użytkownika (dodaje się go w apce: Ustawienia apki > Stocki).")


def szukaj_pexels(k, fraza, typ, ile, pion):
    if typ == "wideo":
        r = zapytanie("GET", "https://api.pexels.com/videos/search", naglowki={"Authorization": k},
                      params={"query": fraza, "per_page": ile, **({"orientation": "portrait"} if pion else {})})
        out = []
        for v in r.json().get("videos", []):
            pliki = sorted([f for f in v.get("video_files", []) if f.get("link")], key=lambda f: (f.get("height") or 0) * (f.get("width") or 0), reverse=True)
            najl = next((f for f in pliki if (f.get("height") or 0) <= 2160), pliki[0] if pliki else None)
            if najl:
                out.append({"id": v.get("id"), "czas_s": v.get("duration"), "szer": najl.get("width"), "wys": najl.get("height"),
                            "podglad": v.get("image"), "url": najl.get("link"), "strona": v.get("url"), "autor": (v.get("user") or {}).get("name")})
        return out
    r = zapytanie("GET", "https://api.pexels.com/v1/search", naglowki={"Authorization": k},
                  params={"query": fraza, "per_page": ile, **({"orientation": "portrait"} if pion else {})})
    return [{"id": p.get("id"), "szer": p.get("width"), "wys": p.get("height"), "podglad": (p.get("src") or {}).get("medium"),
             "url": (p.get("src") or {}).get("original"), "strona": p.get("url"), "autor": p.get("photographer")} for p in r.json().get("photos", [])]


def szukaj_pixabay(k, fraza, typ, ile, pion):
    if typ == "wideo":
        r = zapytanie("GET", "https://pixabay.com/api/videos/", params={"key": k, "q": fraza, "per_page": max(3, ile)})
        out = []
        for v in r.json().get("hits", []):
            w = v.get("videos") or {}
            najl = w.get("large") if (w.get("large") or {}).get("url") else w.get("medium") or {}
            out.append({"id": v.get("id"), "czas_s": v.get("duration"), "szer": najl.get("width"), "wys": najl.get("height"),
                        "podglad": najl.get("thumbnail"), "url": najl.get("url"), "strona": v.get("pageURL"), "autor": v.get("user")})
        return [o for o in out if o["url"] and (not pion or (o["wys"] or 0) > (o["szer"] or 0))]
    r = zapytanie("GET", "https://pixabay.com/api/", params={"key": k, "q": fraza, "per_page": max(3, ile), "image_type": "photo",
                                                            **({"orientation": "vertical"} if pion else {})})
    return [{"id": p.get("id"), "szer": p.get("imageWidth"), "wys": p.get("imageHeight"), "podglad": p.get("webformatURL"),
             "url": p.get("largeImageURL"), "strona": p.get("pageURL"), "autor": p.get("user")} for p in r.json().get("hits", [])]


OBSLUGA = {"pexels": szukaj_pexels, "pixabay": szukaj_pixabay}


def main():
    ap = argparse.ArgumentParser(description="Własne stocki użytkownika")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("lista")
    s = sub.add_parser("szukaj"); s.add_argument("--serwis", required=True); s.add_argument("--fraza", required=True)
    s.add_argument("--typ", default="wideo", choices=["wideo", "zdjecia"]); s.add_argument("--ile", type=int, default=15); s.add_argument("--pion", action="store_true")
    p = sub.add_parser("pobierz"); p.add_argument("--serwis", required=True); p.add_argument("--url", required=True); p.add_argument("--wyjscie", required=True)
    f = sub.add_parser("pliki"); f.add_argument("--serwis", required=True)
    a = ap.parse_args()
    if a.cmd == "lista":
        wynik(stocki=[{**x, "obsluga": "wbudowana" if x.get("slug") in OBSLUGA and x.get("api") == "tak" else ("wg dokumentacji API" if x.get("api") == "tak" else "ręcznie")} for x in stocki()])
    elif a.cmd == "szukaj":
        st = stock(a.serwis)
        if st.get("api") != "tak":
            blad(f"{st['nazwa']} nie ma API: użyj plików z folderu {st.get('folder')} (stock_api.py pliki --serwis {a.serwis}).")
        f = OBSLUGA.get(a.serwis)
        if not f:
            blad(f"Silnik nie ma wbudowanej obsługi {st['nazwa']}. Klucz jest w .env jako {st.get('klucz_env')}, dokumentacja: {st.get('docs') or 'brak'}.")
        wynik(serwis=a.serwis, wyniki=f(klucz(st["klucz_env"]), a.fraza, a.typ, max(3, min(80, a.ile)), a.pion))
    elif a.cmd == "pobierz":
        st = stock(a.serwis)
        cel = Path(a.wyjscie)
        cel = cel if cel.is_absolute() else KATALOG_SILNIKA / cel
        cel.parent.mkdir(parents=True, exist_ok=True)
        pobierz_plik(a.url, cel)
        wynik(plik=str(cel), serwis=st["nazwa"], licencja="sprawdź warunki licencji serwisu (np. podanie autora)")
    elif a.cmd == "pliki":
        st = stock(a.serwis)
        kat = KATALOG_SILNIKA / (st.get("folder") or f"stock_reczny/{a.serwis}")
        pl = sorted([str(x) for x in kat.rglob("*") if x.suffix.lower() in MEDIA]) if kat.exists() else []
        wynik(serwis=st["nazwa"], folder=str(kat), pliki=pl, uwaga=None if pl else "Folder jest pusty: poproś użytkownika, żeby pobrał pliki ze strony serwisu do tego folderu.")


if __name__ == "__main__":
    main()
