"""Z poziomu na pion: kadr 9:16 z filmu 16:9, który podąża za twarzą (albo za osobą, która mówi).

  python narzedzia/pion.py --plik film.mp4 [--wyjscie wynik.mp4] [--tryb twarz|mowca|srodek]
         [--slowa slowa.json --mapa "1=lewo,2=prawo"] [--format 1080x1920] [--plynnosc 0.5]
  python narzedzia/pion.py --folder zlecenia/<nazwa> ...      (wszystkie filmy z folderu, wyniki w gotowe/)

Tryby:
- twarz: śledzi największą twarz w kadrze, spokojnie jak operator (nie drga, rusza się, gdy twarz ucieka z środka)
- mowca: na rozmowach (podcast w szerokim planie): kadr na osobę, która właśnie mówi. Potrzebny plik słów z mówcami
         (python narzedzia/mowa.py --plik film.mp4 --mowcy) i mapa: który mówca siedzi z lewej, a który z prawej.
- srodek: stały kadr na środek
Przy każdym cięciu ujęcia kadr przeskakuje od razu (bez płynnego przejazdu). Wynik: obok filmu albo w gotowe/,
plus <nazwa>_pion_podglad.jpg (6 kadrów do sprawdzenia).
Wymaga: python -m pip install "opencv-python-headless<5"
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, postep, wynik  # noqa: E402

ROZSZ = {".mp4", ".mov", ".m4v", ".mkv", ".mts", ".mxf", ".avi", ".webm"}


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


def info(plik):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,r_frame_rate",
                        "-show_entries", "format=duration", "-of", "json", str(plik)], capture_output=True, text=True, encoding="utf-8", errors="replace")
    d = json.loads(r.stdout or "{}")
    st = (d.get("streams") or [{}])[0]
    a, b = (st.get("r_frame_rate") or "25/1").split("/")
    return int(st.get("width", 1920)), int(st.get("height", 1080)), float(a) / float(b or 1), float((d.get("format") or {}).get("duration", 0))


def wykryj(plik, co_s=0.2):
    """Twarze w próbkach co 0,2 s: [(t, [(x_srodka, y_srodka, wielkosc)], ciecie_przed)] w pikselach źródła."""
    try:
        import cv2
    except ImportError:
        blad('Brak biblioteki OpenCV. Uruchom: python -m pip install "opencv-python-headless<5"')
    przod = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_frontalface_default.xml")
    profil = cv2.CascadeClassifier(cv2.data.haarcascades + "haarcascade_profileface.xml")
    cap = cv2.VideoCapture(str(plik))
    fps = cap.get(cv2.CAP_PROP_FPS) or 25
    krok = max(1, int(round(fps * co_s)))
    wyn, n, poprz_hist = [], 0, None
    while True:
        if not cap.grab():
            break
        if n % krok == 0:
            ok, kl = cap.retrieve()
            if not ok:
                break
            h, w = kl.shape[:2]
            sk = 640 / w
            male = cv2.resize(kl, (640, int(h * sk)))
            szary = cv2.equalizeHist(cv2.cvtColor(male, cv2.COLOR_BGR2GRAY))
            hist = cv2.calcHist([male], [0, 1, 2], None, [8, 8, 8], [0, 256] * 3)
            cv2.normalize(hist, hist)
            ciecie = poprz_hist is not None and cv2.compareHist(poprz_hist, hist, cv2.HISTCMP_CORREL) < 0.55
            poprz_hist = hist
            min_r = int(min(male.shape[:2]) * 0.06)
            twarze = list(przod.detectMultiScale(szary, 1.15, 5, minSize=(min_r, min_r)))
            if not twarze:
                twarze = list(profil.detectMultiScale(szary, 1.15, 5, minSize=(min_r, min_r)))
                twarze += [(male.shape[1] - x - fw, y, fw, fh) for (x, y, fw, fh) in profil.detectMultiScale(cv2.flip(szary, 1), 1.15, 5, minSize=(min_r, min_r))]
            wyn.append((n / fps, [((x + fw / 2) / sk, (y + fh / 2) / sk, fw / sk) for (x, y, fw, fh) in twarze], ciecie))
        n += 1
    cap.release()
    return wyn


def mowca_w(slowa, t):
    for w in slowa:
        if w["start"] - 0.3 <= t <= w["koniec"] + 0.6:
            return w.get("mowca")
    return None


def tor(probki, W, cw, tryb, slowa=None, mapa=None, plynnosc=0.5):
    """Środek kadru dla każdej próbki: strefa martwa + łagodny dojazd; przy cięciu ujęcia skok."""
    x, wyn, poprz_cel = W / 2, [], W / 2
    for t, twarze, ciecie in probki:
        cel = poprz_cel
        if tryb == "srodek" or not twarze:
            cel = W / 2 if tryb == "srodek" else poprz_cel
        elif tryb == "mowca" and slowa:
            m = mowca_w(slowa, t)
            strona = (mapa or {}).get(m)
            po_x = sorted(twarze, key=lambda f: f[0])
            if strona == "lewo":
                cel = po_x[0][0]
            elif strona == "prawo":
                cel = po_x[-1][0]
            elif strona == "srodek":
                cel = po_x[len(po_x) // 2][0]
            else:
                cel = max(twarze, key=lambda f: f[2])[0]
        else:
            najw = max(twarze, key=lambda f: f[2])
            bliska = min(twarze, key=lambda f: abs(f[0] - poprz_cel))
            cel = bliska[0] if bliska[2] >= 0.6 * najw[2] else najw[0]
        poprz_cel = cel
        if ciecie or not wyn:
            x = cel
        else:
            strefa = cw * 0.18
            if abs(cel - x) > strefa:
                krok = (cel - x) * (0.12 + 0.5 * (1 - plynnosc))
                maks = cw * 0.06
                x += max(-maks, min(maks, krok))
        x = min(max(x, cw / 2), W - cw / 2)
        wyn.append((t, x, ciecie))
    return wyn


def renderuj(plik, wyj, tw, th, probki_x, W, H, fps, dl):
    ta = tw / th
    cw, ch = (int(min(W, H * ta)) // 2) * 2, (int(min(H, W / ta)) // 2) * 2
    y0 = (H - ch) // 2
    cmd = Path(wyj).with_suffix(".kadr.txt")
    linie, poprz = [], None
    # wartości co klatkę, liniowo między próbkami (skok tylko przy cięciu)
    n = int(dl * fps) + 1
    j = 0
    for k in range(n):
        t = k / fps
        while j + 1 < len(probki_x) and probki_x[j + 1][0] <= t:
            j += 1
        if j + 1 < len(probki_x) and not probki_x[j + 1][2]:
            t0, x0_, _ = probki_x[j]
            t1, x1_, _ = probki_x[j + 1]
            xs = x0_ + (x1_ - x0_) * ((t - t0) / max(1e-6, t1 - t0))
        else:
            xs = probki_x[j][1] if probki_x else W / 2
        x = int(round(min(max(xs - cw / 2, 0), W - cw)))
        if x != poprz:
            linie.append(f"{t:.4f} crop x {x};")
            poprz = x
    cmd.write_text("\n".join(linie) + "\n", encoding="utf-8")
    x_start = int(linie[0].split()[-1].rstrip(";")) if linie else (W - cw) // 2
    vf = f"sendcmd=f='{cmd.name}',crop=w={cw}:h={ch}:x={x_start}:y={y0},scale={tw}:{th}:flags=lanczos,setsar=1,format=yuv420p"
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(Path(plik).resolve()), "-vf", vf, "-map", "0:v:0", "-map", "0:a?",
                        "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-c:a", "aac", "-b:a", "192k", "-movflags", "+faststart",
                        str(Path(wyj).resolve())], cwd=str(cmd.parent), capture_output=True, text=True, encoding="utf-8", errors="replace")
    cmd.unlink(missing_ok=True)
    if r.returncode != 0:
        blad(f"Render pionu nie powiódł się: {r.stderr[-800:]}")


def podglad(wyj, dl):
    from PIL import Image
    kadry = []
    for i in range(6):
        t = dl * (i + 0.5) / 6
        p = Path(wyj).with_name(f"_k{i}.jpg")
        subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{t:.2f}", "-i", str(wyj), "-frames:v", "1", "-vf", "scale=270:-1", str(p)])
        if p.exists():
            kadry.append(Image.open(p).convert("RGB"))
            p.unlink()
    if not kadry:
        return None
    ark = Image.new("RGB", (sum(k.width for k in kadry) + 10 * (len(kadry) + 1), kadry[0].height + 20), (30, 30, 30))
    x = 10
    for k in kadry:
        ark.paste(k, (x, 10))
        x += k.width + 10
    cel = Path(wyj).with_name(Path(wyj).stem + "_podglad.jpg")
    ark.save(cel, quality=85)
    return str(cel)


def jeden(plik, wyj, tryb, slowa, mapa, fmt, plynnosc):
    W, H, fps, dl = info(plik)
    tw, th = (int(x) for x in fmt.lower().split("x"))
    ta = tw / th
    cw = int(min(W, H * ta))
    postep(f"Szukam twarzy w {Path(plik).name}")
    probki = wykryj(plik) if tryb != "srodek" else [(0.0, [], False)]
    twarzy = sum(1 for _, f, _ in probki if f)
    x = tor(probki, W, cw, tryb, slowa, mapa, plynnosc)
    postep(f"Renderuję pion {tw}x{th}")
    renderuj(plik, wyj, tw, th, x, W, H, fps, dl)
    return {"plik": Path(plik).name, "wynik": str(wyj), "podglad": podglad(wyj, dl), "probek": len(probki),
            "z_twarza_procent": round(100 * twarzy / max(1, len(probki))), "ciec_ujec": sum(1 for p in probki if p[2])}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Z poziomu na pion")
    p.add_argument("--plik"); p.add_argument("--folder"); p.add_argument("--wyjscie")
    p.add_argument("--tryb", default="twarz", choices=["twarz", "mowca", "srodek"])
    p.add_argument("--slowa"); p.add_argument("--mapa", default="")
    p.add_argument("--format", default="1080x1920"); p.add_argument("--plynnosc", type=float, default=0.5)
    a = p.parse_args()
    slowa = json.loads(sciezka(a.slowa).read_text(encoding="utf-8")) if a.slowa else None
    if isinstance(slowa, dict):
        slowa = slowa.get("slowa")
    mapa = dict(x.strip().split("=", 1) for x in a.mapa.split(",") if "=" in x)
    if a.tryb == "mowca" and not slowa:
        blad("Tryb „mowca” potrzebuje pliku słów z mówcami (--slowa) i mapy (--mapa \"1=lewo,2=prawo\").")
    if a.plik:
        pl = sciezka(a.plik)
        wyj = sciezka(a.wyjscie) if a.wyjscie else pl.with_name(pl.stem + "_pion.mp4")
        wynik(**jeden(pl, wyj, a.tryb, slowa, mapa, a.format, a.plynnosc))
    elif a.folder:
        f = sciezka(a.folder)
        pliki = sorted(x for x in f.iterdir() if x.suffix.lower() in ROZSZ)
        if not pliki:
            blad(f"W {f} nie ma filmów.")
        (f / "gotowe").mkdir(exist_ok=True)
        wynik(filmy=[jeden(x, f / "gotowe" / f"{x.stem}_pion.mp4", a.tryb, slowa, mapa, a.format, a.plynnosc) for x in pliki])
    else:
        blad("Podaj --plik albo --folder")
