"""Most między DaVinci Resolve a silnikiem (panel Nada Studio w wersji Studio i skrypty z menu Workspace > Scripts).

DaVinci sam eksportuje i importuje osie czasu (Final Cut Pro 7 XML), a ciężką pracę robi silnik:

  python narzedzia/davinci_most.py wyniki [--dni 30]
      osie czasu gotowe do wczytania: timeline'y z wyników zadań (Projekty/...xml) i z kolejki „Wyślij do DaVinci”
  python narzedzia/davinci_most.py tnij --xml os.xml [--wpadki wytnij|oznacz|pomin] [--jezyk pl] [--bez-ciszy]
      cięcie ciszy i wpadek: nowa oś (XML) + napisy SRT do zaimportowania
  python narzedzia/davinci_most.py napisy --xml os.xml [--jezyk pl]
      same napisy SRT do osi (bez cięcia)
  python narzedzia/davinci_most.py wczytane --plik X.xml
      zaznacza oś jako wczytaną (nie pokaże się więcej jako nowa)
  python narzedzia/davinci_most.py folder --nazwa "Nazwa osi"
      folder roboczy dla osi z DaVinci (wyniki/DaVinci/<nazwa> <data>)
  python narzedzia/davinci_most.py klienci | style | mozgi
      listy do panelu: foldery klientów, style napisów (gotowe i z Studio), dostępne mózgi
  python narzedzia/davinci_most.py panel-folder --nazwa "Animacje" [--klient <folder>]
      folder na rzeczy wstawiane z panelu: wyniki/<Klient>/Panel DaVinci/<nazwa>
  python narzedzia/davinci_most.py multicam --xml os.xml --uklad '<json>' [--dzwiek] [--nieuzyte wylacz|usun]
      multicam podcastu (jak w panelu Premiere): nowa oś do wczytania
  python narzedzia/davinci_most.py aftermovie --xml os.xml --dane '<json>' [--mozg claude]
      zadanie aftermovie w tle (mózg jak z przycisku „Wykonaj”); gotowa oś trafia do Wyniki
  python narzedzia/davinci_most.py zlecenie --id <id>
      stan zadania w tle (etap, postęp, ostatnia wiadomość)

Na końcu każde polecenie wypisuje JSON (jak inne narzędzia), a przed nim linie TAB (dla skryptów w Lua):
  XML<TAB>ścieżka   SRT<TAB>ścieżka   OS<TAB>ścieżka<TAB>tytuł<TAB>kiedy
"""
import argparse
import json
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, wynik  # noqa: E402

WYNIKI = KATALOG_SILNIKA / "wyniki"
SYS = KATALOG_SILNIKA / "_system" / "davinci"
WCZYTANE = SYS / "wczytane.json"
KOLEJKA = SYS / "do_wczytania.json"


def _czytaj(p, dom):
    try:
        return json.loads(Path(p).read_text(encoding="utf-8"))
    except Exception:
        return dom


def _pisz(p, d):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    Path(p).write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")


def _tytul(xml):
    """„Klient / Zadanie / Rolka 1” z położenia pliku w wynikach."""
    try:
        rel = xml.relative_to(WYNIKI).parts
    except ValueError:
        return xml.stem
    czesci = [c for c in rel[:-1] if c not in ("Projekty", "Materiały", "premiere")]
    czesci = [c.replace(" - Premiere", "") for c in czesci]
    return " / ".join(czesci[:3] + ([xml.stem] if len(czesci) < 3 else []))


def wyniki(dni=30):
    wczytane = set(_czytaj(WCZYTANE, []))
    teraz = time.time()
    osie = []
    if WYNIKI.exists():
        for x in WYNIKI.rglob("*.xml"):
            try:
                rel = x.relative_to(WYNIKI).parts
            except ValueError:
                continue
            if any(c.startswith("_") for c in rel) or "Poprzednie wersje" in rel:
                continue
            if not ("Projekty" in rel or "premiere" in rel or x.name.endswith("_ciecie.xml")):
                continue
            if x.name in ("sekwencja.xml",) or x.name.endswith(("_napisy.xml",)):
                continue
            m = x.stat().st_mtime
            if teraz - m > dni * 86400:
                continue
            osie.append({"plik": str(x), "tytul": _tytul(x), "kiedy": m, "nowa": str(x) not in wczytane})
    for k in _czytaj(KOLEJKA, []):
        p = Path(k.get("plik", ""))
        if p.exists() and not any(o["plik"] == str(p) for o in osie):
            osie.append({"plik": str(p), "tytul": k.get("tytul") or p.stem, "kiedy": p.stat().st_mtime, "nowa": str(p) not in wczytane, "z_kolejki": True})
    osie.sort(key=lambda o: o["kiedy"], reverse=True)
    for o in osie[:60]:
        print("OS\t" + o["plik"] + "\t" + o["tytul"].replace("\t", " ") + "\t" + time.strftime("%d.%m %H:%M", time.localtime(o["kiedy"])) + ("\tNOWA" if o["nowa"] else ""))
    return osie[:60]


def folder_osi(nazwa):
    czysta = "".join("-" if c in '<>:"/\\|?*' else c for c in (nazwa or "Oś z DaVinci")).strip() or "Oś z DaVinci"
    f = WYNIKI / "DaVinci" / f"{czysta} {time.strftime('%d.%m.%Y %H%M')}"
    f.mkdir(parents=True, exist_ok=True)
    return f


def _narzedzie(args):
    """Uruchamia narzędzie silnika i zwraca jego JSON (ostatni obiekt na wyjściu)."""
    r = subprocess.run([sys.executable, str(KATALOG_SILNIKA / "narzedzia" / args[0])] + args[1:], capture_output=True, text=True,
                       encoding="utf-8", errors="replace", cwd=str(KATALOG_SILNIKA))
    for linia in (r.stderr or "").splitlines():
        if linia.startswith("POSTEP"):
            print(linia, file=sys.stderr, flush=True)
    t = (r.stdout or "").strip()
    try:
        return json.loads(t[t.index("{"):]) if "{" in t else {"ok": False, "blad": (r.stderr or "")[-600:]}
    except Exception:
        return {"ok": False, "blad": (t or r.stderr or "")[-600:]}


def tnij(xml, wpadki="wytnij", jezyk=None, bez_ciszy=False, tylko_napisy=False):
    xml = Path(xml).resolve()
    if not xml.exists():
        blad(f"Nie ma pliku osi: {xml}")
    folder = xml.parent if xml.parent.parent.name == "DaVinci" else folder_osi(xml.stem)
    if xml.parent != folder:
        cel = folder / xml.name
        cel.write_bytes(xml.read_bytes())
        xml = cel
    a = ["ciecie.py", "analizuj", "--xml", str(xml), "--folder", str(folder)] + (["--jezyk", jezyk] if jezyk else [])
    w1 = _narzedzie(a)
    if w1.get("ok") is False:
        blad("Analiza osi nie wyszła: " + str(w1.get("blad")))
    z = ["ciecie.py", "zastosuj", "--xml", str(xml), "--folder", str(folder), "--wpadki", "pomin" if tylko_napisy else wpadki]
    if bez_ciszy or tylko_napisy:
        z.append("--bez-ciszy")
    w2 = _narzedzie(z)
    if w2.get("ok") is False:
        blad("Cięcie nie wyszło: " + str(w2.get("blad")))
    nowy = Path(w2.get("xml") or w2.get("sekwencja") or "")
    if not nowy.exists():
        kand = sorted(folder.glob("*_ciecie.xml"), key=lambda p: p.stat().st_mtime, reverse=True)
        nowy = kand[0] if kand else None
    srt = Path(w2.get("srt") or folder / "napisy.srt")
    if nowy and not tylko_napisy:
        print("XML\t" + str(nowy))
    if srt.exists():
        print("SRT\t" + str(srt))
    return {"folder": str(folder), "xml": str(nowy) if nowy and not tylko_napisy else None, "srt": str(srt) if srt.exists() else None,
            "wynik_ciecia": {k: v for k, v in w2.items() if k not in ("ok",)}}


def klienci():
    k = KATALOG_SILNIKA / "klienci"
    out = []
    if k.exists():
        for d in sorted(k.iterdir()):
            if d.is_dir() and not d.name.startswith(("_", ".")):
                nazwa = d.name
                for plik in ("brandbook/karta_klienta.json", "karta.json"):
                    try:
                        nazwa = json.loads((d / plik).read_text(encoding="utf-8")).get("nazwa") or nazwa
                        break
                    except Exception:
                        pass
                out.append({"folder": "klienci/" + d.name, "nazwa": nazwa})
    return out


def style():
    out = []
    for plik in ("napisy_style_moje.json", "napisy_style.json"):
        d = _czytaj(KATALOG_SILNIKA / "narzedzia" / plik, {})
        for s in (d.get("style") if isinstance(d, dict) else d) or []:
            if isinstance(s, dict) and isinstance(s.get("styl"), dict):
                out.append({"id": s.get("id"), "nazwa": s.get("nazwa"), "grupa": s.get("grupa") or "", "styl": s["styl"]})
    return out


def panel_folder(nazwa, klient=""):
    import porzadek
    f = porzadek.folder_zadania(Path(klient).name if klient else "", nazwa or "Panel", klient_folder=klient, podfolder="Panel DaVinci")
    f.mkdir(parents=True, exist_ok=True)
    return f


def multicam(xml, uklad, dzwiek=False, nieuzyte="wylacz"):
    xml = Path(xml).resolve()
    folder = xml.parent if xml.parent.parent.name == "DaVinci" else folder_osi(xml.stem)
    plik_u = folder / "uklad.json"
    plik_u.write_text(json.dumps(uklad, ensure_ascii=False, indent=1), encoding="utf-8")
    a = _narzedzie(["multicam.py", "analizuj", "--xml", str(xml), "--folder", str(folder), "--uklad", str(plik_u)])
    if a.get("ok") is False:
        blad("Analiza mikrofonów nie wyszła: " + str(a.get("blad")))
    z = ["multicam.py", "zastosuj", "--xml", str(xml), "--folder", str(folder), "--nieuzyte", nieuzyte] + (["--dzwiek"] if dzwiek else [])
    w = _narzedzie(z)
    if w.get("ok") is False:
        blad("Multicam nie wyszedł: " + str(w.get("blad")))
    if w.get("xml"):
        print("XML\t" + str(w["xml"]))
    return {"folder": str(folder), "xml": w.get("xml"), "nazwa": w.get("nazwa"), "ujec": a.get("ujec"), "srednie_ujecie_s": a.get("srednie_ujecie_s"), "uwagi": w.get("uwagi") or []}


def aftermovie(xml, dane, mozg="claude"):
    import mcp_studio
    import porzadek
    xml = Path(xml).resolve()
    kl = dane.get("klient") or {}
    folder = porzadek.folder_zadania(kl.get("nazwa") or "", dane.get("tytul") or xml.stem, klient_folder=kl.get("folder") or "")
    (folder / "sekwencja.xml").write_bytes(xml.read_bytes())
    zad = dict(dane, zrodlo="premiere", program="davinci", folder=folder.relative_to(KATALOG_SILNIKA).as_posix(), xml=str(folder / "sekwencja.xml"))
    (folder / "zadanie_panel.json").write_text(json.dumps(zad, ensure_ascii=False, indent=1), encoding="utf-8")
    polecenie = "/aftermovie " + json.dumps(zad, ensure_ascii=False)
    z = mcp_studio.wykonaj(polecenie, "Aftermovie (DaVinci): " + str(zad.get("tytul") or ""), mozg)
    return {"id": z["id"], "folder": str(folder)}


def zlecenie(zid):
    import mcp_studio
    kat = mcp_studio._katalog(zid)
    o = mcp_studio._opis(kat) or {}
    p = _czytaj(Path(kat) / "postep.json", {})
    return {"stan": o.get("stan"), "ostatnio": o.get("ostatnio"), "etap": p.get("etap"), "ulamek": p.get("ulamek"), "tekst": p.get("tekst"), "mozg": o.get("mozg_nazwa")}


def main():
    ap = argparse.ArgumentParser(description="Most DaVinci Resolve ↔ silnik Nada Studio")
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("wyniki"); a.add_argument("--dni", type=int, default=30)
    t = sub.add_parser("tnij"); t.add_argument("--xml", required=True); t.add_argument("--wpadki", default="wytnij", choices=["wytnij", "oznacz", "pomin"])
    t.add_argument("--jezyk", default=None); t.add_argument("--bez-ciszy", action="store_true")
    n = sub.add_parser("napisy"); n.add_argument("--xml", required=True); n.add_argument("--jezyk", default=None)
    w = sub.add_parser("wczytane"); w.add_argument("--plik", required=True)
    f = sub.add_parser("folder"); f.add_argument("--nazwa", default="")
    sub.add_parser("klienci"); sub.add_parser("style"); sub.add_parser("mozgi")
    pf = sub.add_parser("panel-folder"); pf.add_argument("--nazwa", default="Panel"); pf.add_argument("--klient", default="")
    m = sub.add_parser("multicam"); m.add_argument("--xml", required=True); m.add_argument("--uklad", required=True)
    m.add_argument("--dzwiek", action="store_true"); m.add_argument("--nieuzyte", default="wylacz", choices=["wylacz", "usun"])
    am = sub.add_parser("aftermovie"); am.add_argument("--xml", required=True); am.add_argument("--dane", required=True); am.add_argument("--mozg", default="claude")
    zl = sub.add_parser("zlecenie"); zl.add_argument("--id", required=True)
    a = ap.parse_args()
    if a.cmd == "wyniki":
        wynik(osie=wyniki(a.dni))
    elif a.cmd == "tnij":
        wynik(**tnij(a.xml, a.wpadki, a.jezyk, a.bez_ciszy))
    elif a.cmd == "napisy":
        wynik(**tnij(a.xml, jezyk=a.jezyk, tylko_napisy=True))
    elif a.cmd == "wczytane":
        l = _czytaj(WCZYTANE, [])
        if a.plik not in l:
            l.append(a.plik)
        _pisz(WCZYTANE, l[-500:])
        kol = [k for k in _czytaj(KOLEJKA, []) if k.get("plik") != a.plik]
        _pisz(KOLEJKA, kol)
        wynik(zapisano=True)
    elif a.cmd == "klienci":
        wynik(klienci=klienci())
    elif a.cmd == "style":
        wynik(style=style())
    elif a.cmd == "mozgi":
        import mcp_studio
        wynik(**mcp_studio.mozgi())
    elif a.cmd == "panel-folder":
        wynik(folder=str(panel_folder(a.nazwa, a.klient)))
    elif a.cmd == "multicam":
        wynik(**multicam(a.xml, json.loads(a.uklad), a.dzwiek, a.nieuzyte))
    elif a.cmd == "aftermovie":
        wynik(**aftermovie(a.xml, json.loads(a.dane), a.mozg))
    elif a.cmd == "zlecenie":
        wynik(**zlecenie(a.id))
    elif a.cmd == "folder":
        p = folder_osi(a.nazwa)
        print("FOLDER\t" + str(p))
        wynik(folder=str(p))


if __name__ == "__main__":
    main()
