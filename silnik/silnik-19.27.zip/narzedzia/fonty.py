"""Fonty marki: pobieranie z Google Fonts do folderu klienta i wyszukiwanie plików fontów.

Użycie:
  python narzedzia/fonty.py pobierz --nazwa "Montserrat" --folder klienci/marka/fonty
  python narzedzia/fonty.py pokaz --folder klienci/marka/fonty
  python narzedzia/fonty.py lista [--szukaj mont]          fonty Google z polskimi znakami (1491 rodzin, plik fonty_lista.json)
  python narzedzia/fonty.py instaluj --polecane [--kursywa] ok. 200 popularnych rodzin: pobiera wszystkie grubości do fonty/
                                                           i instaluje w Windows (dla Ciebie, bez uprawnień administratora),
                                                           żeby były w Premiere, After Effects i Photoshopie
  python narzedzia/fonty.py instaluj --rodzina "Montserrat" [--rodzina "Anton"] [--kursywa]
  python narzedzia/fonty.py wariant --rodzina "Montserrat" --waga 900 [--kursywa]   jeden plik (pobiera, gdy brak)
Nazwy grubości są takie jak w programach Adobe: Thin, ExtraLight, Light, Regular, Medium, SemiBold, Bold, ExtraBold, Black.
"""
import argparse
import re
import sys
from pathlib import Path

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import blad, wynik  # noqa: E402

ZAPASOWE = [
    "C:/Windows/Fonts/arialbd.ttf", "C:/Windows/Fonts/segoeuib.ttf",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "/System/Library/Fonts/Supplemental/Arial Bold.ttf",
]


NAZWY_WAG = {100: "Thin", 200: "ExtraLight", 300: "Light", 400: "Regular", 500: "Medium", 600: "SemiBold", 700: "Bold", 800: "ExtraBold", 900: "Black"}
LISTA = Path(__file__).resolve().parent / "fonty_lista.json"
BLEDY_SIECI = []


def nazwa_wariantu(waga, kursywa=False):
    """Nazwa jak w Adobe: 900 → Black, 400 + kursywa → Italic, 700 + kursywa → Bold Italic."""
    n = NAZWY_WAG.get(int(waga), str(waga))
    if kursywa:
        return "Italic" if int(waga) == 400 else n + " Italic"
    return n


def lista_google():
    import json
    try:
        return json.loads(LISTA.read_text(encoding="utf-8"))
    except Exception:
        return {"polecane": [], "rodziny": []}


def warianty_google(nazwa):
    """[(waga, kursywa)] dostępne w Google Fonts dla rodziny (z fonty_lista.json)."""
    for r in lista_google()["rodziny"]:
        if r[0].lower() == str(nazwa).lower():
            return r[0], [(int(v.rstrip("i")), v.endswith("i")) for v in r[2].split(",")]
    return None, []


def pobierz_google(nazwa, folder, wagi=(400, 600, 700, 800), cicho=False, kursywa=False):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    pobrane = []
    for waga in wagi:
        it = kursywa
        if isinstance(waga, (tuple, list)):
            waga, it = waga
        cel = folder / f"{nazwa.replace(' ', '')}-{waga}{'i' if it else ''}.ttf"
        if cel.exists() and cel.stat().st_size > 1000:
            pobrane.append(str(cel))
            continue
        os_ = f"ital,wght@1,{waga}" if it else f"wght@{waga}"
        url = f"https://fonts.googleapis.com/css2?family={nazwa.replace(' ', '+')}:{os_}"
        # Stary User-Agent sprawia, że Google zwraca pliki .ttf zamiast .woff2
        try:
            r = requests.get(url, headers={"User-Agent": "Mozilla/4.0"}, timeout=60)
        except Exception:
            BLEDY_SIECI.append(nazwa)
            continue
        if r.status_code != 200:
            continue
        for link in sorted(set(re.findall(r"url\((https://[^)]+\.ttf)\)", r.text)))[:1]:
            try:
                cel.write_bytes(requests.get(link, timeout=120).content)
                pobrane.append(str(cel))
            except Exception:
                pass
    if not pobrane and not cicho:
        blad(f"Nie znalazłem fontu '{nazwa}' w Google Fonts. Wrzuć pliki .ttf/.otf ręcznie do {folder}")
    return pobrane


def pliki_fontow(folder):
    folder = Path(folder)
    return sorted([p for p in folder.glob("*") if p.suffix.lower() in (".ttf", ".otf")]) if folder.exists() else []


def znajdz(folder, nazwa=None, gruby=True):
    """Zwraca ścieżkę do pliku fontu: najpierw z folderu klienta, potem zapasowy systemowy."""
    from PIL import ImageFont

    kandydaci = []
    for p in pliki_fontow(folder):
        try:
            rodzina, styl = ImageFont.truetype(str(p), 20).getname()
        except Exception:
            continue
        if nazwa and nazwa.replace(" ", "").lower() not in (rodzina + p.stem).replace(" ", "").lower():
            continue
        styl_l = (styl + p.stem).lower()
        punkty = 0
        if gruby and any(s in styl_l for s in ("bold", "700", "800", "extrabold", "black", "semibold", "600")):
            punkty += 2
        if not gruby and any(s in styl_l for s in ("regular", "400", "book")):
            punkty += 2
        if "italic" in styl_l:
            punkty -= 3
        kandydaci.append((punkty, str(p)))
    if kandydaci:
        return sorted(kandydaci, reverse=True)[0][1]
    for z in ZAPASOWE:
        if Path(z).exists():
            return z
    return None


WAGI_NAZW = [("thin", 100), ("hairline", 100), ("extralight", 200), ("ultralight", 200), ("light", 300),
             ("medium", 500), ("semibold", 600), ("demibold", 600), ("extrabold", 800), ("ultrabold", 800),
             ("heavy", 900), ("black", 900), ("bold", 700), ("regular", 400), ("book", 400), ("normal", 400)]
WSPOLNE_FONTY = Path(__file__).resolve().parent.parent / "fonty"


def waga_pliku(p, styl=""):
    """Grubość fontu 100–900: z tabeli OS/2 (fontTools), z nazwy stylu albo z końcówki nazwy pliku (-800)."""
    try:
        from fontTools.ttLib import TTFont
        return int(TTFont(str(p), lazy=True)["OS/2"].usWeightClass)
    except Exception:
        pass
    m = re.search(r"-(\d00)i?$", Path(p).stem)
    if m:
        return int(m.group(1))
    t = (styl + " " + Path(p).stem).lower().replace("-", "").replace(" ", "")
    for nazwa_w, w in WAGI_NAZW:
        if nazwa_w in t:
            return w
    return 400


def znajdz_wage(nazwa, waga=700, folder_klienta=None, pobieraj=True, kursywa=False):
    """Plik fontu o danej rodzinie i grubości. Szuka w fontach klienta i we wspólnym folderze fonty/,
    a gdy brak, pobiera tę grubość z Google Fonts do fonty/<Nazwa>/. Zwraca (plik, waga_pliku)."""
    from PIL import ImageFont

    def kandydaci():
        wyn = []
        foldery = [Path(folder_klienta)] if folder_klienta else []
        if nazwa:
            foldery.append(WSPOLNE_FONTY / nazwa.replace(" ", ""))
        for f in foldery:
            for p in pliki_fontow(f):
                try:
                    rodz, styl = ImageFont.truetype(str(p), 20).getname()
                except Exception:
                    continue
                if nazwa and nazwa.replace(" ", "").lower() not in (rodz + p.stem).replace(" ", "").lower():
                    continue
                jest_it = "italic" in (styl + p.stem).lower() or bool(re.search(r"-\d00i$", p.stem))
                kara = 1000 if jest_it != bool(kursywa) else 0
                zmienny = "[" in p.name or "variable" in p.name.lower()
                w = waga if zmienny else waga_pliku(p, styl)
                wyn.append((abs(w - waga) + kara, str(p), w))
        return sorted(wyn)

    k = kandydaci()
    if (not k or k[0][0] > 100) and nazwa and pobieraj:
        pobierz_google(nazwa, WSPOLNE_FONTY / nazwa.replace(" ", ""), wagi=((waga, bool(kursywa)),), cicho=True)
        k = kandydaci()
    if k:
        return k[0][1], k[0][2]
    zap = znajdz(folder_klienta or Path("."), nazwa, gruby=waga >= 600)
    return zap, waga


def wczytaj(plik, rozmiar, waga=None):
    """ImageFont z ustawioną grubością, jeśli plik jest fontem zmiennym (np. Montserrat[wght].ttf)."""
    from PIL import ImageFont
    f = ImageFont.truetype(str(plik), max(1, int(rozmiar)))
    if waga:
        try:
            osie = f.get_variation_axes()
            if osie:
                f.set_variation_by_axes([waga if "eight" in str(o.get("name", "")).lower() or i == 0 else o.get("default", 0)
                                         for i, o in enumerate(osie)])
        except Exception:
            pass
    return f


def nazwa_postscript(plik):
    """Pełna nazwa fontu dla Photoshopa (np. Montserrat-ExtraBold)."""
    try:
        from fontTools.ttLib import TTFont
        n = TTFont(str(plik), lazy=True)["name"].getDebugName(6)
        if n:
            return n
    except Exception:
        pass
    from PIL import ImageFont
    rodz, styl = ImageFont.truetype(str(plik), 20).getname()
    return f"{rodz}-{styl}".replace(" ", "")


def instaluj_windows(pliki):
    """Instaluje fonty dla bieżącego użytkownika Windows (bez administratora): kopia do
    %LOCALAPPDATA%\\Microsoft\\Windows\\Fonts i wpis w rejestrze. Programy Adobe widzą je po ponownym uruchomieniu."""
    if not sys.platform.startswith("win"):
        return {"zainstalowane": 0, "uwaga": "Instalacja w systemie działa tylko w Windows."}
    import ctypes
    import os
    import shutil
    import winreg
    cel_dir = Path(os.environ["LOCALAPPDATA"]) / "Microsoft" / "Windows" / "Fonts"
    cel_dir.mkdir(parents=True, exist_ok=True)
    n = 0
    klucz = winreg.CreateKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows NT\CurrentVersion\Fonts")
    try:
        for p in pliki:
            p = Path(p)
            cel = cel_dir / p.name
            try:
                if not cel.exists() or cel.stat().st_size != p.stat().st_size:
                    shutil.copy2(p, cel)
                nazwa = p.stem
                try:
                    from fontTools.ttLib import TTFont
                    nazwa = TTFont(str(cel), lazy=True)["name"].getDebugName(4) or nazwa
                except Exception:
                    pass
                winreg.SetValueEx(klucz, f"{nazwa} (TrueType)", 0, winreg.REG_SZ, str(cel))
                try:
                    ctypes.windll.gdi32.AddFontResourceW(str(cel))
                except Exception:
                    pass
                n += 1
            except Exception:
                continue
    finally:
        winreg.CloseKey(klucz)
    try:  # powiadomienie otwartych programów o nowych fontach
        ctypes.windll.user32.SendMessageTimeoutW(0xFFFF, 0x001D, 0, 0, 0x0002, 1000, None)
    except Exception:
        pass
    return {"zainstalowane": n, "folder": str(cel_dir)}


def instaluj(rodziny, kursywa=False, postep=True):
    import concurrent.futures as cf
    wyn, pliki, brak = [], [], []

    def jedna(r):
        nazwa, war = warianty_google(r)
        if not nazwa:
            return r, [], True
        war = [w for w in war if kursywa or not w[1]]
        return nazwa, pobierz_google(nazwa, WSPOLNE_FONTY / nazwa.replace(" ", ""), wagi=war, cicho=True), False

    with cf.ThreadPoolExecutor(6) as ex:
        for i, (nazwa, pl, nieznana) in enumerate(ex.map(jedna, rodziny)):
            if nieznana:
                brak.append(nazwa)
                continue
            pliki += pl
            wyn.append({"rodzina": nazwa, "pliki": len(pl)})
            if postep:
                print(f"[{i + 1}/{len(rodziny)}] {nazwa}: {len(pl)} plików", file=sys.stderr, flush=True)
    sysw = instaluj_windows(pliki)
    return {"rodziny": len(wyn), "pliki": len(pliki), "brak_w_google": brak, **sysw,
            "dalej": "Zamknij i otwórz Premiere, After Effects i Photoshopa, żeby zobaczyły nowe fonty."}


def rodzina(sciezka):
    from PIL import ImageFont
    return ImageFont.truetype(sciezka, 20).getname()[0]


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="tryb", required=True)
    a1 = sub.add_parser("pobierz"); a1.add_argument("--nazwa", required=True); a1.add_argument("--folder", required=True)
    a2 = sub.add_parser("pokaz"); a2.add_argument("--folder", required=True)
    a3 = sub.add_parser("lista"); a3.add_argument("--szukaj", default="")
    a4 = sub.add_parser("instaluj"); a4.add_argument("--rodzina", action="append", default=[]); a4.add_argument("--polecane", action="store_true")
    a4.add_argument("--kursywa", action="store_true", help="także kursywy (Italic)")
    a5 = sub.add_parser("wariant"); a5.add_argument("--rodzina", required=True); a5.add_argument("--waga", type=int, default=400); a5.add_argument("--kursywa", action="store_true")
    a = p.parse_args()
    if a.tryb == "lista":
        L = lista_google()
        r = [x for x in L["rodziny"] if a.szukaj.lower() in x[0].lower()]
        wynik(ile=len(r), rodziny=[{"nazwa": x[0], "warianty": [nazwa_wariantu(int(v.rstrip("i")), v.endswith("i")) for v in x[2].split(",")]} for x in r[:200]])
    elif a.tryb == "instaluj":
        rodz = (lista_google()["polecane"] if a.polecane else []) + a.rodzina
        if not rodz:
            blad("Podaj --polecane albo --rodzina \"Nazwa\".")
        wynik(**instaluj(list(dict.fromkeys(rodz)), kursywa=a.kursywa))
    elif a.tryb == "wariant":
        nazwa, war = warianty_google(a.rodzina)
        if not nazwa:
            blad(f"Nie ma rodziny '{a.rodzina}' w Google Fonts z polskimi znakami.")
        pl = pobierz_google(nazwa, WSPOLNE_FONTY / nazwa.replace(" ", ""), wagi=[(a.waga, a.kursywa)], cicho=True)
        if not pl:
            blad("Brak połączenia z Google Fonts (sprawdź internet)." if BLEDY_SIECI else f"Google nie ma wariantu {nazwa} {nazwa_wariantu(a.waga, a.kursywa)}.")
        wynik(plik=pl[0], nazwa=f"{nazwa} {nazwa_wariantu(a.waga, a.kursywa)}")
    elif a.tryb == "pobierz":
        wynik(pliki=pobierz_google(a.nazwa, a.folder))
    else:
        from PIL import ImageFont
        wynik(fonty=[{"plik": str(f), "nazwa": " ".join(ImageFont.truetype(str(f), 20).getname())} for f in pliki_fontow(a.folder)])
