"""Wyszukiwarka stocków dla panelu (Stock): wpisujesz, czego szukasz, albo dajesz ujęcia lub gotowy film,
a narzędzie znajduje podobne klipy w stocku Magnific i daje linki do tych samych wyszukiwań w Envato.

  python narzedzia/stock.py frazy --opis "ludzie tańczą na koncercie w nocy"      polskie zdanie -> angielskie frazy (Gemini)
  python narzedzia/stock.py z-klipow --klipy '[{"plik": "C:/x.mp4", "od": 2.0, "do": 6.5}]' --folder _system/stock/analiza
                                                                                    ujęcia (z osi albo pliki) -> opis i frazy
  python narzedzia/stock.py z-filmu --plik gotowy.mp4 --folder _system/stock/analiza [--ile 10]
                                                                                    gotowy film: ujęcie po ujęciu -> frazy
  python narzedzia/stock.py z-plikow --pliki '["C:/a.mp4", "C:/b.jpg"]' --folder ...   jeden długi film = jak z-filmu, inaczej jak z-klipow
  python narzedzia/stock.py szukaj --frazy '["concert crowd night", "dj hands"]' [--typ wideo|zdjecia]
                                   [--orientacja dowolna|pozioma|pionowa|kwadrat] [--strona 1] [--ile 12] [--z-ai]
  python narzedzia/stock.py pobierz --id 12345 [--typ wideo] --folder stock/2026-10-24 [--nazwa "concert crowd"]
  python narzedzia/stock.py licznik                                                 ile pobrań ze stocka dziś (limit 100)

Opisy ujęć i tłumaczenie fraz robi Gemini przez klucz GEMINI_API_KEY (model tekstowy flash, ułamek grosza za zapytanie).
Bez klucza fraza idzie do stocka tak, jak ją wpiszesz (po angielsku działa najlepiej).
Envato nie ma API do szukania ani pobierania: dostajesz linki do wyszukiwania na stronie, pobierasz sam.
Pliki RAW (BRAW, R3D) czyta przez proksy z _system/proksy/mapa.json.
"""
import argparse
import base64
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from urllib.parse import quote

sys.path.insert(0, str(Path(__file__).resolve().parent))
import requests  # noqa: E402

from wspolne import KATALOG_SILNIKA, blad, pobierz as pobierz_url, wczytaj_env, wynik  # noqa: E402

wczytaj_env()
GEMINI_API = "https://generativelanguage.googleapis.com/v1beta"
MODELE_TEKSTOWE = [m for m in (os.environ.get("GEMINI_TEXT_MODEL"), "gemini-2.5-flash", "gemini-flash-latest", "gemini-2.0-flash") if m]
RAW = {".braw", ".r3d", ".ari", ".crm"}
def _sys(n):
    import porzadek
    return porzadek.system(n)


LICZNIK = None  # _system/stock/pobrania.json (ustawiane przy pierwszym użyciu)
ORIENTACJE = {"pozioma": "horizontal", "pionowa": "vertical", "kwadrat": "square"}


# ---------- Gemini ----------
def gemini_json(prompt, obrazy=()):
    """Odpowiedź Gemini jako JSON. obrazy = ścieżki JPG. Próbuje kilku modeli (różne konta mają różne)."""
    try:
        import obraz_agy
        if obraz_agy.silnik() == "agy":  # domyślnie przez Antigravity (abonament), bez płatnego API
            t, err = obraz_agy.tekst(prompt + "\nReturn only valid JSON, no markdown.", list(obrazy))
            if not t:
                return None, err
            t = re.sub(r"^```(json)?|```$", "", t.strip()).strip()
            m = re.search(r"\{.*\}", t, re.S)
            try:
                return json.loads(m.group(0) if m else t), None
            except Exception as e:  # noqa: BLE001
                return None, f"zła odpowiedź Gemini: {e}"
    except ImportError:
        pass
    k = (os.environ.get("GEMINI_API_KEY") or "").strip()
    if not k:
        return None, "brak klucza GEMINI_API_KEY w .env"
    czesci = []
    for p in obrazy:
        try:
            czesci.append({"inline_data": {"mime_type": "image/jpeg", "data": base64.b64encode(Path(p).read_bytes()).decode()}})
        except OSError:
            pass
    czesci.append({"text": prompt})
    body = {"contents": [{"parts": czesci}], "generationConfig": {"responseMimeType": "application/json", "temperature": 0.4}}
    ostatni = ""
    for model in MODELE_TEKSTOWE:
        try:
            r = requests.post(f"{GEMINI_API}/models/{model}:generateContent", headers={"x-goog-api-key": k, "Content-Type": "application/json"},
                              json=body, timeout=120)
        except requests.RequestException as e:
            ostatni = str(e)
            continue
        if r.status_code in (404, 400) and "model" in r.text.lower():
            ostatni = f"{model}: {r.text[:200]}"
            continue
        if r.status_code >= 400:
            ostatni = f"HTTP {r.status_code}: {r.text[:300]}"
            if r.status_code in (401, 403):
                break
            continue
        try:
            tekst = r.json()["candidates"][0]["content"]["parts"][0]["text"]
            tekst = re.sub(r"^```(json)?|```$", "", tekst.strip()).strip()
            return json.loads(tekst), None
        except Exception as e:  # noqa: BLE001
            ostatni = f"zła odpowiedź Gemini: {e}"
    return None, ostatni


INSTRUKCJA_FRAZ = (
    "You help a video editor search stock footage sites (Magnific/Freepik, Envato). "
    "Search engines there work best with short English keyword phrases of 2-5 words, concrete nouns and actions, no articles. "
)


def frazy_z_opisu(opis, ile=4):
    d, err = gemini_json(INSTRUKCJA_FRAZ + f"The editor wrote (maybe in Polish): \"{opis}\". "
                         f"Return JSON {{\"frazy\": [{ile} different English search phrases, the most literal first, then useful variations "
                         "(other angle, close-up, wide shot, synonyms)], \"opis_pl\": \"one short Polish sentence what we are looking for\"}}.")
    if not d or not d.get("frazy"):
        return {"frazy": [opis.strip()], "opis_pl": opis.strip(), "uwaga": f"Bez tłumaczenia ({err})." if err else None}
    return {"frazy": [str(f).strip() for f in d["frazy"] if str(f).strip()][:ile], "opis_pl": d.get("opis_pl") or opis}


# ---------- klatki z ujęć ----------
def proksy_dla(plik):
    p = Path(plik)
    if p.suffix.lower() not in RAW:
        return p
    try:
        mapa = json.loads((_sys("proksy") / "mapa.json").read_text(encoding="utf-8"))
        n = lambda x: re.sub(r"[\\/]+", "/", str(x)).lower()  # noqa: E731
        odwr = {n(v): k for k, v in mapa.items()}
        pr = odwr.get(n(p))
        if pr and Path(pr).exists():
            return Path(pr)
    except Exception:  # noqa: BLE001
        pass
    return None


def dlugosc(plik):
    r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", str(plik)],
                       capture_output=True, text=True)
    try:
        return float(r.stdout.strip())
    except ValueError:
        return 0.0


def klatka(plik, t, cel, szer=512):
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-ss", f"{max(0.0, t):.3f}", "-i", str(plik), "-frames:v", "1",
                    "-vf", f"scale={szer}:-2", "-q:v", "4", str(cel)], capture_output=True)
    return Path(cel).exists() and Path(cel).stat().st_size > 0


def z_klipow(klipy, folder, ile_fraz=3):
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    ujecia, obrazy, pomin = [], [], []
    for i, k in enumerate(klipy[:12]):
        src = Path(k["proksy"]) if k.get("proksy") and Path(k["proksy"]).exists() else proksy_dla(k["plik"])
        if not src or not src.exists():
            pomin.append(f"{Path(k['plik']).name}: nie mogę odczytać (RAW bez proksy albo brak pliku)")
            continue
        obraz = src.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp")
        od = float(k.get("od") or 0)
        do = float(k.get("do") or 0) or (od + (dlugosc(src) - od if not obraz else 0))
        kl = []
        if obraz:
            c = folder / f"u{i:02d}_0.jpg"
            subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(src), "-vf", "scale=512:-2", str(c)], capture_output=True)
            if c.exists():
                kl.append(str(c))
        else:
            for j, f in enumerate((0.2, 0.5, 0.8)):
                c = folder / f"u{i:02d}_{j}.jpg"
                if klatka(src, od + (do - od) * f, c):
                    kl.append(str(c))
        if kl:
            ujecia.append({"nr": len(ujecia) + 1, "plik": str(k["plik"]), "od": od, "do": do, "klatki": kl, "miniatura": kl[len(kl) // 2]})
            obrazy += kl
    if not ujecia:
        blad("Nie udało się wyciąć klatek z żadnego ujęcia. " + "; ".join(pomin))
    return opisz(ujecia, obrazy, ile_fraz, pomin)


def ujecia_filmu(plik, folder, ile=10, prog=0.32):
    """Gotowy film: cięcia z wykrywania zmiany obrazu, z każdego ujęcia 1 klatka ze środka."""
    plik, folder = Path(plik), Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    dl = dlugosc(plik)
    r = subprocess.run(["ffmpeg", "-v", "info", "-i", str(plik), "-vf", f"scale=320:-2,select='gt(scene,{prog})',showinfo", "-an", "-f", "null", "-"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace")
    ciecia = [float(m) for m in re.findall(r"pts_time:([\d.]+)", r.stderr)]
    granice = [0.0] + [c for c in ciecia if 0.3 < c < dl - 0.3] + [dl]
    sceny = [(a, b) for a, b in zip(granice, granice[1:]) if b - a >= 0.6]
    if len(sceny) > ile:  # wybieramy równomiernie, najdłuższe w swoim odcinku
        krok = len(sceny) / ile
        sceny = [max(sceny[int(i * krok):int((i + 1) * krok)] or [sceny[int(i * krok)]], key=lambda s: s[1] - s[0]) for i in range(ile)]
    ujecia, obrazy = [], []
    for i, (a, b) in enumerate(sceny):
        c = folder / f"f{i:02d}.jpg"
        if klatka(plik, (a + b) / 2, c):
            ujecia.append({"nr": len(ujecia) + 1, "plik": str(plik), "od": round(a, 2), "do": round(b, 2), "klatki": [str(c)], "miniatura": str(c)})
            obrazy.append(str(c))
    if not ujecia:
        blad("Nie znalazłem ujęć w tym filmie.")
    return opisz(ujecia, obrazy, 2)


def opisz(ujecia, obrazy, ile_fraz, pomin=()):
    lista = "; ".join(f"shot {u['nr']} = images {', '.join(str(obrazy.index(k) + 1) for k in u['klatki'])}" for u in ujecia)
    d, err = gemini_json(
        INSTRUKCJA_FRAZ + "The images are frames from video shots, in order. " + lista + ". "
        "For every shot describe what is visible and how it is filmed (subject, action, place, time of day, light, colors, "
        "camera angle, shot size, camera movement guess, mood). Return JSON {\"ujecia\": [{\"nr\": 1, \"opis_pl\": \"short Polish description\", "
        f"\"frazy\": [{ile_fraz} English stock search phrases for footage that looks like this shot]}}], "
        "\"wspolne\": [2 English phrases for the overall look of all shots together]}.", obrazy[:24])
    if not d:
        for u in ujecia:
            u.update({"opis_pl": "", "frazy": []})
        return {"ujecia": ujecia, "wspolne": [], "uwaga": f"Gemini nie opisał ujęć ({err}). Wpisz frazę ręcznie.", "pominiete": list(pomin)}
    po_nr = {int(x.get("nr", 0)): x for x in d.get("ujecia", []) if isinstance(x, dict)}
    for u in ujecia:
        x = po_nr.get(u["nr"], {})
        u["opis_pl"] = x.get("opis_pl", "")
        u["frazy"] = [str(f) for f in (x.get("frazy") or [])][:ile_fraz]
    return {"ujecia": ujecia, "wspolne": [str(f) for f in (d.get("wspolne") or [])][:3], "pominiete": list(pomin)}


# ---------- Magnific ----------
def _urle(x, out):
    if isinstance(x, str) and x.startswith("http"):
        out.append(x)
    elif isinstance(x, dict):
        for v in x.values():
            _urle(v, out)
    elif isinstance(x, list):
        for v in x:
            _urle(v, out)
    return out


def podglad_wideo(el):
    """Adres krótkiego podglądu wideo (do odtwarzania po najechaniu myszką)."""
    wszystkie = _urle(el.get("previews"), []) + _urle(el.get("preview"), []) + _urle(el.get("video"), []) + _urle(el, [])
    wideo = [u for u in wszystkie if re.search(r"\.(mp4|webm|mov)(\?|$)", u, re.I)]
    # najmniejszy (zwykle najszybszy): preferuj adresy z „preview”, „small”, „360”, „480”
    wideo.sort(key=lambda u: (0 if re.search(r"preview|small|360|480|low", u, re.I) else 1, len(u)))
    return wideo[0] if wideo else None


def miniatura(el):
    for pole in ("thumbnails", "thumbnail", "image", "previews"):
        u = [x for x in _urle(el.get(pole), []) if re.search(r"\.(jpe?g|png|webp)(\?|$)", x, re.I)]
        if u:
            u.sort(key=lambda x: (0 if re.search(r"large|medium|640|720", x, re.I) else 1))
            return u[0]
    u = [x for x in _urle(el, []) if re.search(r"\.(jpe?g|png|webp)(\?|$)", x, re.I)]
    return u[0] if u else None


def szukaj_magnific(fraza, typ, orientacja, strona, ile, z_ai):
    import freepik  # klucz i nagłówki
    if typ == "wideo":
        url = f"{freepik.HOST}/v1/videos"
        baza = {"term": fraza, "order": "relevance"}
        if strona > 1:
            baza["page"] = strona
        warianty = [{}]
        if orientacja in ORIENTACJE:
            o = ORIENTACJE[orientacja]
            warianty = [{"filters[orientation][]": o}, {"filters[orientation][0]": o}, {f"filters[orientation][{o}]": 1}, {}]
        if not z_ai:
            baza["filters[ai-generated][excluded]"] = "true"
    else:
        url = f"{freepik.HOST}/v1/resources"
        baza = {"term": fraza, "order": "relevance", "limit": ile, "filters[content_type][photo]": 1}
        if strona > 1:
            baza["page"] = strona
        warianty = [{}]
        if orientacja in ORIENTACJE:
            o = {"horizontal": "landscape", "vertical": "portrait", "square": "square"}[ORIENTACJE[orientacja]]
            warianty = [{f"filters[orientation][{o}]": 1}, {}]
        if not z_ai:
            baza["filters[ai-generated][excluded]"] = 1
    odp = None
    for w in warianty:
        try:
            odp = requests.get(url, headers=freepik.naglowki(), params={**baza, **w}, timeout=60)
        except requests.RequestException as e:
            return [], f"Brak połączenia z Magnific: {e}"
        if odp.status_code == 400 and ("orientation" in odp.text or "filters" in odp.text):
            continue
        break
    if odp is None or odp.status_code >= 400:
        kod = odp.status_code if odp is not None else "?"
        if kod in (401, 403):
            return [], "Magnific odrzucił klucz (MAGNIFIC_API_KEY). Sprawdź klucz w Ustawieniach Studio."
        return [], f"Magnific: HTTP {kod} {(odp.text if odp is not None else '')[:200]}"
    dane = odp.json().get("data") or []
    try:  # pierwszy wynik zapisany do podglądu (gdy coś się nie wyświetla, widać, jakie pola przysłał Magnific)
        (_sys("stock") / f"ostatnia_odpowiedz_{typ}.json").write_text(
            json.dumps(dane[:1], ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception:  # noqa: BLE001
        pass
    wyniki = []
    for el in dane[:ile]:
        if typ == "wideo":
            poz = {"id": el.get("id"), "nazwa": el.get("name") or el.get("title"), "dlugosc": el.get("duration"),
                   "jakosc": el.get("quality") or el.get("resolution"), "premium": bool(el.get("premium")),
                   "ai": bool(el.get("is_ai_generated") or el.get("ai_generated")), "orientacja": el.get("orientation") or el.get("aspect_ratio"),
                   "miniatura": miniatura(el), "podglad": podglad_wideo(el), "strona": el.get("url")}
        else:
            poz = {"id": el.get("id"), "nazwa": el.get("title") or el.get("name"),
                   "premium": any((lic or {}).get("type") == "premium" for lic in el.get("licenses") or []),
                   "miniatura": miniatura(el), "podglad": None, "strona": el.get("url")}
        poz["zrodlo"], poz["typ"], poz["fraza"] = "magnific", typ, fraza
        if poz["id"]:
            wyniki.append(poz)
    return wyniki, None


def link_envato(fraza, typ):
    slug = re.sub(r"[^a-z0-9]+", "-", fraza.lower()).strip("-")
    return f"https://elements.envato.com/{'stock-video' if typ == 'wideo' else 'photos'}/{quote(slug)}"


def szukaj(frazy, typ, orientacja, strona, ile, z_ai):
    wszystkie, widziane, bledy = [], set(), []
    for f in frazy[:6]:
        w, err = szukaj_magnific(f, typ, orientacja, strona, ile, z_ai)
        if err:
            bledy.append(err)
            if "klucz" in err:
                break
        for x in w:
            if x["id"] in widziane:
                continue
            widziane.add(x["id"])
            wszystkie.append(x)
    # przeplatamy frazy, żeby na górze były najlepsze wyniki każdej z nich
    po_frazie = {}
    for x in wszystkie:
        po_frazie.setdefault(x["fraza"], []).append(x)
    przepl = []
    while any(po_frazie.values()):
        for f in list(po_frazie):
            if po_frazie[f]:
                przepl.append(po_frazie[f].pop(0))
    if not przepl and bledy:
        blad(bledy[0])
    return {"wyniki": przepl, "envato": [{"fraza": f, "url": link_envato(f, typ)} for f in frazy[:6]],
            "strona": strona, "bledy": sorted(set(bledy)), "pobrane_dzis": licznik()}


# ---------- pobieranie ----------
def licznik(dodaj=0):
    LICZNIK = _sys("stock") / "pobrania.json"
    dzis = time.strftime("%Y-%m-%d")
    try:
        d = json.loads(LICZNIK.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        d = {}
    if dodaj:
        d[dzis] = int(d.get(dzis, 0)) + dodaj
        d = {k: v for k, v in d.items() if k >= time.strftime("%Y-%m-%d", time.localtime(time.time() - 40 * 86400))}
        LICZNIK.parent.mkdir(parents=True, exist_ok=True)
        LICZNIK.write_text(json.dumps(d, indent=1), encoding="utf-8")
    return int(d.get(dzis, 0))


def pobierz(id_, typ, folder, nazwa):
    import freepik
    folder = Path(folder)
    folder.mkdir(parents=True, exist_ok=True)
    if typ == "wideo":
        sciezka, params = f"{freepik.HOST}/v1/videos/{id_}/download", None
    else:
        sciezka, params = f"{freepik.HOST}/v1/resources/{id_}/download", {"image_size": "original"}
    r = requests.get(sciezka, headers=freepik.naglowki(), params=params, timeout=120)
    if r.status_code == 429:
        blad("Magnific: dzienny limit pobrań ze stocka (100) wyczerpany. Spróbuj jutro albo pobierz z Envato.")
    if r.status_code >= 400:
        blad(f"Magnific nie dał pobrać (HTTP {r.status_code}): {r.text[:300]}")
    d = r.json().get("data", r.json())
    if isinstance(d, list):
        d = d[0] if d else {}
    url = d.get("url") or d.get("signed_url")
    if not url:
        blad(f"Magnific nie zwrócił linku do pobrania: {str(d)[:300]}")
    oryg = d.get("filename") or ""
    rozsz = Path(oryg).suffix.lower() or (".mp4" if typ == "wideo" else ".jpg")
    slug = re.sub(r"[^a-z0-9]+", "_", (nazwa or "stock").lower()).strip("_")[:40] or "stock"
    cel = folder / f"{slug}_{id_}{rozsz}"
    if cel.exists() and cel.stat().st_size > 0:
        return {"plik": str(cel), "juz_byl": True, "pobrane_dzis": licznik()}
    pobierz_url(url, cel)
    cel = freepik.rozpakuj_jesli_zip(cel, cel.with_suffix(".mp4" if typ == "wideo" else ".jpg"))
    return {"plik": str(cel), "nazwa_oryginalna": oryg, "pobrane_dzis": licznik(1)}


def main():
    ap = argparse.ArgumentParser(description="Wyszukiwarka stocków (Magnific + linki Envato)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    f = sub.add_parser("frazy"); f.add_argument("--opis", required=True); f.add_argument("--ile", type=int, default=4)
    k = sub.add_parser("z-klipow"); k.add_argument("--klipy", required=True); k.add_argument("--folder", required=True)
    m = sub.add_parser("z-filmu"); m.add_argument("--plik", required=True); m.add_argument("--folder", required=True); m.add_argument("--ile", type=int, default=10)
    z = sub.add_parser("z-plikow", help="pliki z dysku: jeden długi film = ujęcie po ujęciu, inaczej każdy plik jako ujęcie")
    z.add_argument("--pliki", required=True); z.add_argument("--folder", required=True)
    s = sub.add_parser("szukaj"); s.add_argument("--frazy", required=True); s.add_argument("--typ", default="wideo", choices=["wideo", "zdjecia"])
    s.add_argument("--orientacja", default="dowolna"); s.add_argument("--strona", type=int, default=1); s.add_argument("--ile", type=int, default=12)
    s.add_argument("--z-ai", action="store_true", help="pokazuj też materiały wygenerowane przez AI")
    p = sub.add_parser("pobierz"); p.add_argument("--id", required=True); p.add_argument("--typ", default="wideo", choices=["wideo", "zdjecia"])
    p.add_argument("--folder", required=True); p.add_argument("--nazwa", default="")
    sub.add_parser("licznik")
    a = ap.parse_args()
    if a.cmd == "frazy":
        wynik(**frazy_z_opisu(a.opis, a.ile))
    elif a.cmd == "z-klipow":
        wynik(**z_klipow(json.loads(a.klipy), a.folder))
    elif a.cmd == "z-filmu":
        if not Path(a.plik).exists():
            blad(f"Nie ma pliku {a.plik}")
        wynik(**ujecia_filmu(a.plik, a.folder, a.ile))
    elif a.cmd == "z-plikow":
        pliki = [p for p in json.loads(a.pliki) if Path(p).exists()]
        if not pliki:
            blad("Nie widzę żadnego z wybranych plików.")
        wideo = [p for p in pliki if Path(p).suffix.lower() not in (".jpg", ".jpeg", ".png", ".webp")]
        if len(pliki) == 1 and wideo and dlugosc(proksy_dla(wideo[0]) or wideo[0]) > 20:
            wynik(**ujecia_filmu(proksy_dla(wideo[0]) or wideo[0], a.folder, 10), film=True)
        else:
            wynik(**z_klipow([{"plik": p} for p in pliki], a.folder), film=False)
    elif a.cmd == "szukaj":
        fr = json.loads(a.frazy) if a.frazy.strip().startswith("[") else [a.frazy]
        wynik(**szukaj([x for x in fr if str(x).strip()], a.typ, a.orientacja, a.strona, a.ile, a.z_ai))
    elif a.cmd == "pobierz":
        wynik(**pobierz(a.id, a.typ, a.folder, a.nazwa))
    else:
        wynik(pobrane_dzis=licznik(), limit=100)


if __name__ == "__main__":
    main()
