"""Wersje językowe gotowej rolki: dubbing ElevenLabs (głos mówiącego w innym języku, z zachowaniem barwy i tła),
opcjonalnie z napisami w tym języku w wybranym stylu.

  python narzedzia/tlumacz.py dubbing --plik zlecenia/<nazwa>/rolka.mp4 --jezyki en,de,sv [--zrodlo pl] [--mowcy 0]
         [--styl styl.json] [--fonty klienci/<klient>/fonty]
  python narzedzia/tlumacz.py dubbing --folder zlecenia/<nazwa> --jezyki en ...
  python narzedzia/tlumacz.py jezyki

Wynik: <folder>/gotowe/<film>_<kod>.mp4 (oraz _<kod>_napisy.mp4 i .srt, gdy podasz --styl).
Koszt: kredyty ElevenLabs (dubbing liczy się za minutę filmu i język).
"""
import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, klucz, postep, wynik  # noqa: E402

JEZYKI = {"en": "angielski", "de": "niemiecki", "es": "hiszpański", "fr": "francuski", "it": "włoski", "pt": "portugalski",
          "pl": "polski", "sv": "szwedzki", "no": "norweski", "da": "duński", "fi": "fiński", "nl": "niderlandzki",
          "cs": "czeski", "sk": "słowacki", "uk": "ukraiński", "ru": "rosyjski", "hu": "węgierski", "ro": "rumuński",
          "bg": "bułgarski", "hr": "chorwacki", "el": "grecki", "tr": "turecki", "ar": "arabski", "hi": "hindi",
          "zh": "chiński", "ja": "japoński", "ko": "koreański", "id": "indonezyjski", "ms": "malajski", "fil": "filipiński",
          "ta": "tamilski", "vi": "wietnamski"}
ROZSZ = {".mp4", ".mov", ".m4v", ".mkv", ".webm", ".mp3", ".wav", ".m4a"}
API = "https://api.elevenlabs.io/v1/dubbing"


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


def dubbing(plik, jezyk, zrodlo="auto", mowcy=0):
    import requests
    h = {"xi-api-key": klucz("ELEVENLABS_API_KEY")}
    wideo = plik.suffix.lower() in {".mp4", ".mov", ".m4v", ".mkv", ".webm"}
    with open(plik, "rb") as f:
        r = requests.post(API, headers=h, files={"file": (plik.name, f, "video/mp4" if wideo else "audio/mpeg")},
                          data={"target_lang": jezyk, "source_lang": zrodlo or "auto", "num_speakers": str(mowcy),
                                "watermark": "false", "highest_resolution": "true", "name": f"{plik.stem}_{jezyk}"}, timeout=1800)
    if r.status_code >= 400:
        blad(f"ElevenLabs dubbing HTTP {r.status_code}: {r.text[:400]}")
    did = r.json()["dubbing_id"]
    start = time.time()
    while True:
        s = requests.get(f"{API}/{did}", headers=h, timeout=60).json()
        if s.get("status") == "dubbed":
            break
        if s.get("status") == "failed":
            blad(f"Dubbing {jezyk} nie powiódł się: {s.get('error') or s}")
        if time.time() - start > 3 * 3600:
            blad("Dubbing trwa ponad 3 godziny; sprawdź go w panelu ElevenLabs (Dubbing).")
        postep(f"Dubbing {JEZYKI.get(jezyk, jezyk)} w toku ({int(time.time() - start)} s)")
        time.sleep(15)
    cel = plik.parent / "gotowe" / f"{plik.stem}_{jezyk}{'.mp4' if wideo else '.mp3'}"
    cel.parent.mkdir(exist_ok=True)
    with requests.get(f"{API}/{did}/audio/{jezyk}", headers=h, stream=True, timeout=600) as d:
        if d.status_code >= 400:
            blad(f"Pobieranie dubbingu HTTP {d.status_code}: {d.text[:300]}")
        with open(cel, "wb") as f:
            for k in d.iter_content(1 << 16):
                f.write(k)
    return cel, did


def napisy_do(plik, jezyk, styl, fonty):
    import mowa
    import napisy
    t = mowa.transkrybuj(plik, jezyk, "auto")
    sl = plik.with_name(plik.stem + "_slowa.json")
    mowa.zapisz_slowa(t["slowa"], sl)
    return napisy.wypal_plik(plik, sl, napisy.wczytaj_styl(styl), fonty, plik.with_name(plik.stem + "_napisy.mp4"))


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Wersje językowe (dubbing)")
    sub = p.add_subparsers(dest="tryb", required=True)
    d = sub.add_parser("dubbing")
    d.add_argument("--plik"); d.add_argument("--folder"); d.add_argument("--jezyki", required=True)
    d.add_argument("--zrodlo", default="auto"); d.add_argument("--mowcy", type=int, default=0)
    d.add_argument("--styl"); d.add_argument("--fonty")
    sub.add_parser("jezyki")
    a = p.parse_args()
    if a.tryb == "jezyki":
        wynik(jezyki=JEZYKI)
        sys.exit(0)
    jezyki = [j.strip() for j in a.jezyki.split(",") if j.strip()]
    zle = [j for j in jezyki if j not in JEZYKI]
    if zle:
        blad(f"Nieznane kody języków: {', '.join(zle)}. Lista: python narzedzia/tlumacz.py jezyki")
    pliki = [sciezka(a.plik)] if a.plik else sorted(x for x in sciezka(a.folder).iterdir() if x.suffix.lower() in ROZSZ) if a.folder else []
    if not pliki:
        blad("Podaj --plik albo --folder z filmami.")
    wyn = []
    for pl in pliki:
        for j in jezyki:
            postep(f"Dubbing {pl.name} -> {JEZYKI[j]}")
            cel, did = dubbing(pl, j, a.zrodlo, a.mowcy)
            w = {"film": pl.name, "jezyk": j, "wynik": str(cel), "dubbing_id": did}
            if a.styl:
                w["napisy"] = napisy_do(cel, j, a.styl, sciezka(a.fonty) if a.fonty else None)
            wyn.append(w)
    wynik(wersje=wyn)
