"""Programy zainstalowane przez apkę Nada Studio (Python, ffmpeg, Node, Claude Code, Antigravity) dopisane do PATH.

Kreator apki zapisuje ich foldery w _system/sciezki.json: {"foldery": ["...\\python", "...\\ffmpeg\\bin", ...],
"claude": "...\\claude.exe", "agy": "...\\agy.exe"}. Każde narzędzie silnika importuje ten moduł (przez wspolne.py),
więc ffmpeg, node, claude i agy są widoczne także wtedy, gdy nie ma ich w PATH systemu (np. w panelu Premiere).
Bez tego pliku nic się nie zmienia (silnik działa jak dotąd, z programami z PATH).
"""
import json
import os
from pathlib import Path

KATALOG = Path(__file__).resolve().parent.parent
PLIK = KATALOG / "_system" / "sciezki.json"


def wczytaj():
    try:
        return json.loads(PLIK.read_text(encoding="utf-8"))
    except Exception:
        return {}


def dopisz():
    d = wczytaj()
    foldery = [f for f in d.get("foldery", []) if f and os.path.isdir(f)]
    obecne = os.environ.get("PATH", "").split(os.pathsep)
    nowe = [f for f in foldery if f not in obecne]
    if nowe:
        os.environ["PATH"] = os.pathsep.join(nowe + obecne)
    for klucz, zmienna in (("claude", "NM_CLAUDE"), ("agy", "NM_AGY")):
        if d.get(klucz) and os.path.exists(d[klucz]) and not os.environ.get(zmienna):
            os.environ[zmienna] = d[klucz]
    return d


dopisz()
