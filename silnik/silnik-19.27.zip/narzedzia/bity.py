"""Wykrywanie tempa i bitów w muzyce, żeby ciąć montaż w rytm (aftermovie, dynamiczne rolki).

Użycie:
  python narzedzia/bity.py --plik wyniki/X/muzyka.mp3 [--od 0] [--do 90]

Wynik (JSON, zapisany też obok muzyki jako <nazwa>_bity.json):
  bpm            tempo utworu
  bity           czasy wszystkich bitów w sekundach
  takty          co czwarty bit (początki taktów) — najlepsze miejsca na cięcia i przejścia
  mocne          bity z wyraźnym uderzeniem (np. werbel, akcent)
  energia_taktow głośność każdego taktu 0–1: niskie = spokojny wstęp/wyciszenie, wysokie = refren/drop
  drop           czas największego wzrostu energii (dobry moment na najmocniejsze ujęcia)

Wymaga biblioteki numpy: python -m pip install numpy
"""
import argparse
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, wynik  # noqa: E402

try:
    import numpy as np
except ImportError:
    blad("Brak biblioteki numpy. Uruchom: python -m pip install numpy")

SR, HOP, NFFT = 22050, 512, 2048


def wczytaj(plik, od, do):
    args = ["ffmpeg", "-hide_banner", "-loglevel", "error"]
    if od:
        args += ["-ss", str(od)]
    args += ["-i", str(plik)]
    if do:
        args += ["-t", str(do - (od or 0))]
    args += ["-ac", "1", "-ar", str(SR), "-f", "f32le", "-"]
    r = subprocess.run(args, capture_output=True)
    if r.returncode != 0:
        blad(f"Nie mogę odczytać muzyki: {r.stderr.decode('utf-8', 'replace')[-300:]}")
    return np.frombuffer(r.stdout, dtype=np.float32)


def obwiednia_uderzen(x):
    """Siła „uderzeń” w czasie: wzrost energii widma klatka po klatce (spectral flux)."""
    n = 1 + max(0, (len(x) - NFFT) // HOP)
    okno = np.hanning(NFFT).astype(np.float32)
    ramki = np.lib.stride_tricks.as_strided(x, shape=(n, NFFT), strides=(x.strides[0] * HOP, x.strides[0]))
    widmo = np.abs(np.fft.rfft(ramki * okno, axis=1))
    log = np.log1p(100 * widmo)
    flux = np.maximum(0, np.diff(log, axis=0)).sum(axis=1)
    flux = np.concatenate([[0], flux])
    srednia = np.convolve(flux, np.ones(16) / 16, mode="same")
    o = np.maximum(0, flux - srednia)
    rms = np.sqrt((ramki ** 2).mean(axis=1))
    return o / (o.max() or 1), rms


def tempo(o):
    """Tempo z autokorelacji obwiedni, z preferencją okolic 120 BPM."""
    fr = SR / HOP
    jadro = np.exp(-0.5 * (np.arange(-4, 5) / 1.5) ** 2)
    g = np.convolve(o, jadro / jadro.sum(), mode="same")  # wygładzenie: szczyty nie giną między klatkami
    ac = np.correlate(g - g.mean(), g - g.mean(), mode="full")[len(g) - 1:]
    lagi = np.arange(len(ac))
    bpm = 60 * fr / np.maximum(lagi, 1)
    zakres = (bpm >= 60) & (bpm <= 190)
    waga = np.exp(-0.5 * (np.log2(np.maximum(bpm, 1) / 120) / 0.6) ** 2)
    ocena = np.where(zakres, ac * waga, -np.inf)
    lag = int(np.argmax(ocena))
    # błąd o oktawę: akcent co drugi bit daje połowę tempa. Jeśli tempo ×2 też ma wyraźny rytm, bierzemy je.
    pol = int(round(lag / 2))
    if 60 * fr / max(pol, 1) <= 190 and pol > 1:
        szczyt = ac[max(1, pol - 1):pol + 2].max()
        if szczyt >= 0.5 * ac[lag] and 60 * fr / lag < 90:
            lag = int(max(1, pol - 1) + np.argmax(ac[max(1, pol - 1):pol + 2]))
    # dokładniejsze tempo: szczyt dopasowany parabolą między sąsiednimi klatkami
    if 1 <= lag < len(ac) - 1:
        a_, b_, c_ = ac[lag - 1], ac[lag], ac[lag + 1]
        mian = a_ - 2 * b_ + c_
        dokl = lag + (0.5 * (a_ - c_) / mian if mian else 0)
    else:
        dokl = lag
    return 60 * fr / dokl, dokl


def sledz_bity(o, okres, ciasnosc=100.0):
    """Programowanie dynamiczne (metoda Ellisa): bity tam, gdzie są uderzenia i równy rytm."""
    n = len(o)
    wynik_ = o.copy().astype(float)
    poprz = -np.ones(n, dtype=int)
    for t in range(n):
        lo, hi = t - int(round(2 * okres)), t - int(round(okres / 2))
        if hi <= 0:
            continue
        kand = np.arange(max(0, lo), hi)
        if len(kand) == 0:
            continue
        kara = -ciasnosc * np.log((t - kand) / okres) ** 2
        s = wynik_[kand] + kara
        k = int(np.argmax(s))
        wynik_[t] = o[t] + s[k]
        poprz[t] = kand[k]
    # koniec: najlepszy punkt w ostatnim okresie
    ogon = np.arange(max(0, n - int(okres)), n)
    t = int(ogon[np.argmax(wynik_[ogon])])
    bity = []
    while t >= 0:
        bity.append(t)
        t = poprz[t]
    bity = bity[::-1]
    # obcinamy „bity” na samym początku, gdzie jeszcze nie ma uderzeń
    while len(bity) > 4 and o[bity[0]] < 0.1:
        bity = bity[1:]
    return np.array(bity)


def analizuj(plik, od=0.0, do=None):
    x = wczytaj(plik, od, do)
    if len(x) < SR * 3:
        blad("Muzyka jest za krótka do analizy (potrzeba co najmniej 3 s).")
    o, rms = obwiednia_uderzen(x)
    bpm, okres = tempo(o)
    ramki_bitow = sledz_bity(o, float(okres))
    czas = lambda f: round(float(f) * HOP / SR + (od or 0), 3)  # noqa: E731
    bity = [czas(f) for f in ramki_bitow]
    sila = o[ramki_bitow]
    prog = np.quantile(sila, 0.7) if len(sila) else 0
    mocne = [b for b, s_ in zip(bity, sila) if s_ >= prog]
    # początek taktu: przesunięcie (0–3), przy którym bity mają największą łączną siłę
    przes = int(np.argmax([sila[k::4].sum() for k in range(4)])) if len(sila) >= 8 else 0
    takty = bity[przes::4]
    energia = []
    for i, t0 in enumerate(takty):
        t1 = takty[i + 1] if i + 1 < len(takty) else bity[-1]
        f0, f1 = int((t0 - (od or 0)) * SR / HOP), int((t1 - (od or 0)) * SR / HOP)
        energia.append(float(rms[f0:max(f0 + 1, f1)].mean()))
    e = np.array(energia) if energia else np.array([0.0])
    e = (e - e.min()) / ((e.max() - e.min()) or 1)
    drop = None
    if len(e) > 2:
        skok = np.diff(e)
        drop = takty[int(np.argmax(skok)) + 1]
    return {"plik": str(plik), "bpm": round(float(bpm), 1), "liczba_bitow": len(bity), "bity": bity, "takty": takty,
            "mocne": mocne, "energia_taktow": [round(float(v), 2) for v in e], "drop": drop,
            "dlugosc_s": round(len(x) / SR, 2)}


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Tempo i bity muzyki")
    p.add_argument("--plik", required=True)
    p.add_argument("--od", type=float, default=0.0)
    p.add_argument("--do", type=float, default=None)
    a = p.parse_args()
    plik = Path(a.plik)
    plik = plik if plik.is_absolute() else KATALOG_SILNIKA / plik
    if not plik.exists():
        blad(f"Nie ma pliku {plik}")
    d = analizuj(plik, a.od, a.do)
    zapis = plik.with_name(plik.stem + "_bity.json")
    zapis.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    # na ekran skrót (pełna lista bitów jest w pliku)
    wynik(plik_bitow=str(zapis), bpm=d["bpm"], liczba_bitow=d["liczba_bitow"], pierwsze_takty=d["takty"][:12],
          energia_taktow=d["energia_taktow"], drop=d["drop"], dlugosc_s=d["dlugosc_s"])
