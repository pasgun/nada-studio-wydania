"""Efekty dźwiękowe do przejść (whoosh, swish, uderzenie, błysk, narastanie) bez pobierania z sieci.

Biblioteka wbudowana: narzedzia/dzwieki/*.wav (zrobione tym narzędziem, darmowe, bez licencji do pilnowania).
Pierwszeństwo mają pliki użytkownika z muzyka/efekty/ (np. z Epidemic albo Envato): gdy nazwa pliku zawiera
słowo rodzaju (whoosh, swish, hit/impact, flash, riser), bierzemy je zamiast wbudowanych.

  python narzedzia/efekty.py generuj            robi od nowa bibliotekę wbudowaną
  python narzedzia/efekty.py lista              pokazuje, co jest do wyboru (wbudowane i z muzyka/efekty/)
  python narzedzia/efekty.py plan --os <rolka>_os_czasu.json    efekty, które montaż dałby przy przejściach

Montaż (montaz.py) dokłada je sam, gdy plan ma "efekty_auto": true (aftermovie z panelu ma to domyślnie):
whoosh przy whip, smudze i zoomie, swish przy kole, pikselach i rozmyciu, uderzenie z błyskiem przy flashu.
"""
import argparse
import json
import random
import sys
import wave
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, wynik  # noqa: E402

BIBLIOTEKA = Path(__file__).resolve().parent / "dzwieki"
UZYTKOWNIKA = KATALOG_SILNIKA / "muzyka" / "efekty"
SR = 48000

# rodzaj efektu -> słowa w nazwach plików użytkownika
SLOWA = {"whoosh": ("whoosh", "swoosh", "woosh", "whip", "pass", "przelot"),
         "swish": ("swish", "swipe", "transition", "przejscie"),
         "hit": ("hit", "impact", "boom", "uderzenie", "drop"),
         "flash": ("flash", "camera", "blysk", "shutter"),
         "riser": ("riser", "rise", "build", "narastanie")}
# przejście z silnika -> (rodzaj efektu, głośność, w którym miejscu przejścia ma wypaść szczyt 0..1)
PRZEJSCIA = {
    "whip-lewo": ("whoosh", 0.55, 0.5), "whip-prawo": ("whoosh", 0.55, 0.5), "whip-gora": ("whoosh", 0.55, 0.5),
    "whip-dol": ("whoosh", 0.55, 0.5), "smuga-lewo": ("whoosh", 0.5, 0.5), "smuga-prawo": ("whoosh", 0.5, 0.5),
    "zoom-in": ("whoosh", 0.55, 0.0), "zoom-out": ("whoosh", 0.5, 0.0), "zoom-przenikanie": ("whoosh", 0.45, 0.5),
    "kolo": ("swish", 0.45, 0.4), "pixel": ("swish", 0.4, 0.4), "rozmycie": ("swish", 0.4, 0.4),
    "flash": ("flash", 0.55, 0.3),
}


# ---------- synteza (tylko numpy) ----------
def _np():
    try:
        import numpy as np
        return np
    except ImportError:
        blad("Brak biblioteki numpy: pip install numpy")


def _filtr_pasmowy(np, x, f_od, f_do, q=1.4):
    """Szum przez filtr pasmowy, którego częstotliwość płynie od f_od do f_do (biquad liczony blokami po 64 próbki)."""
    y = np.zeros_like(x)
    x1 = x2 = y1 = y2 = 0.0
    n = len(x)
    for s in range(0, n, 64):
        t = s / max(1, n - 1)
        f = f_od * (f_do / f_od) ** t
        w0 = 2 * np.pi * min(f, SR * 0.45) / SR
        alfa = np.sin(w0) / (2 * q)
        b0, b2, a0 = alfa, -alfa, 1 + alfa
        a1, a2 = -2 * np.cos(w0), 1 - alfa
        for i in range(s, min(n, s + 64)):
            v = (b0 * x[i] + b2 * x2 - a1 * y1 - a2 * y2) / a0
            x2, x1, y2, y1 = x1, x[i], y1, v
            y[i] = v
    return y


def _obwiednia(np, n, szczyt=0.6, atak=2.2, opad=3.0):
    t = np.linspace(0, 1, n)
    e = np.where(t < szczyt, (t / szczyt) ** atak, ((1 - t) / (1 - szczyt)) ** opad)
    return e


def _pogłos(np, x, czas=0.25, zanik=0.35):
    y = x.copy()
    for d, g in ((0.031, 0.5), (0.047, 0.42), (0.071, 0.33), (0.113, 0.24), (0.167, 0.16)):
        k = int(d * SR / max(czas / 0.25, 0.4))
        if k < len(x):
            y[k:] += x[:-k] * g * zanik * 2
    return y


def _stereo(np, mono, pan_od=0.0, pan_do=0.0):
    p = np.linspace(pan_od, pan_do, len(mono))
    l, r = mono * np.sqrt((1 - p) / 2), mono * np.sqrt((1 + p) / 2)
    return np.stack([l, r], axis=1)


def _normalizuj(np, x, szczyt=0.89):
    m = float(np.max(np.abs(x))) or 1.0
    fade = min(len(x) // 10, int(0.01 * SR))
    if fade:
        x[:fade] *= np.linspace(0, 1, fade)[:, None] if x.ndim == 2 else np.linspace(0, 1, fade)
        x[-fade:] *= np.linspace(1, 0, fade)[:, None] if x.ndim == 2 else np.linspace(1, 0, fade)
    return x / m * szczyt


def whoosh(np, dl=0.7, f_od=250, f_do=2600, szczyt=0.62, pan=(-0.7, 0.7), ziarno=1):
    rng = np.random.default_rng(ziarno)
    n = int(dl * SR)
    szum = rng.standard_normal(n)
    a = _filtr_pasmowy(np, szum, f_od, f_do, q=1.9)
    b = _filtr_pasmowy(np, szum, f_od * 0.5, f_do * 0.45, q=0.8) * 0.6  # „ciało” przelotu
    e = _obwiednia(np, n, szczyt, 2.0, 2.6)
    return _stereo(np, (a + b) * e, *pan)


def swish(np, dl=0.32, ziarno=2):
    rng = np.random.default_rng(ziarno)
    n = int(dl * SR)
    a = _filtr_pasmowy(np, rng.standard_normal(n), 1800, 7000, q=1.6)
    return _stereo(np, a * _obwiednia(np, n, 0.45, 1.6, 2.2), -0.4, 0.4)


def hit(np, dl=1.1, ziarno=3):
    rng = np.random.default_rng(ziarno)
    n = int(dl * SR)
    t = np.arange(n) / SR
    f = 38 + 85 * np.exp(-t * 9)
    faza = 2 * np.pi * np.cumsum(f) / SR
    bas = np.sin(faza) * np.exp(-t * 3.2)
    trzask = _filtr_pasmowy(np, rng.standard_normal(n), 3000, 900, q=0.7) * np.exp(-t * 28) * 0.9
    m = _pogłos(np, bas + trzask, 0.4, 0.4)
    return _stereo(np, m)


def flash(np, dl=0.9, ziarno=4):
    rng = np.random.default_rng(ziarno)
    n = int(dl * SR)
    t = np.arange(n) / SR
    blysk = _filtr_pasmowy(np, rng.standard_normal(n), 9000, 3500, q=0.9) * np.exp(-t * 7)
    trzask = rng.standard_normal(n) * np.exp(-t * 60) * 0.8
    f = 45 + 60 * np.exp(-t * 12)
    bas = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 5) * 0.8
    return _stereo(np, _pogłos(np, blysk + trzask + bas, 0.3, 0.45))


def riser(np, dl=1.8, ziarno=5):
    rng = np.random.default_rng(ziarno)
    n = int(dl * SR)
    a = _filtr_pasmowy(np, rng.standard_normal(n), 200, 6000, q=2.2)
    t = np.linspace(0, 1, n)
    ton = np.sin(2 * np.pi * np.cumsum(220 * 2 ** (t * 2)) / SR) * 0.25
    e = t ** 2.4 * (1 - np.clip((t - 0.97) / 0.03, 0, 1))
    return _stereo(np, (a + ton) * e)


BIB = {
    "whoosh_1.wav": lambda np: whoosh(np, 0.7, 250, 2600, 0.62, (-0.7, 0.7), 1),
    "whoosh_2.wav": lambda np: whoosh(np, 0.55, 400, 3800, 0.58, (0.7, -0.7), 7),
    "whoosh_3.wav": lambda np: whoosh(np, 0.9, 150, 1800, 0.66, (-0.3, 0.3), 11),
    "swish_1.wav": lambda np: swish(np, 0.32, 2),
    "swish_2.wav": lambda np: swish(np, 0.26, 9),
    "hit_1.wav": lambda np: hit(np, 1.1, 3),
    "flash_1.wav": lambda np: flash(np, 0.9, 4),
    "riser_1.wav": lambda np: riser(np, 1.8, 5),
}


def zapisz_wav(np, sciezka, x):
    x = _normalizuj(np, np.asarray(x, dtype=np.float64))
    pcm = (np.clip(x, -1, 1) * 32767).astype("<i2")
    with wave.open(str(sciezka), "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes(pcm.tobytes())


def generuj():
    np = _np()
    BIBLIOTEKA.mkdir(parents=True, exist_ok=True)
    pliki = []
    for nazwa, f in BIB.items():
        zapisz_wav(np, BIBLIOTEKA / nazwa, f(np))
        pliki.append(str(BIBLIOTEKA / nazwa))
    (BIBLIOTEKA / "CZYTAJ.txt").write_text(
        "Wbudowane efekty dźwiękowe silnika (zrobione syntezą przez narzedzia/efekty.py, bez licencji do pilnowania).\n"
        "Własne efekty (np. z Epidemic Sound) wrzucaj do muzyka/efekty/: plik z „whoosh”, „swish”, „hit”, „flash” albo\n"
        "„riser” w nazwie ma pierwszeństwo przed tymi.\n", encoding="utf-8")
    return pliki


# ---------- wybór ----------
def dostepne():
    """rodzaj -> lista plików (najpierw użytkownika, potem wbudowane)."""
    w = {k: [] for k in SLOWA}
    if UZYTKOWNIKA.exists():
        for p in sorted(UZYTKOWNIKA.rglob("*")):
            if p.suffix.lower() not in (".wav", ".mp3", ".aif", ".aiff", ".flac", ".m4a"):
                continue
            n = p.stem.lower()
            for k, slowa in SLOWA.items():
                if any(s in n for s in slowa):
                    w[k].append(p)
                    break
    if not any((BIBLIOTEKA / n).exists() for n in BIB):
        try:
            generuj()
        except SystemExit:
            pass
    for k in SLOWA:
        w[k] += sorted(BIBLIOTEKA.glob(f"{k}_*.wav"))
    return w


def dlugosc_wav(p):
    try:
        with wave.open(str(p), "rb") as w:
            return w.getnframes() / float(w.getframerate())
    except Exception:
        return None


def szczyt_wav(p):
    """Kiedy w pliku jest najgłośniej (s): w to miejsce trafia środek przejścia."""
    try:
        np = _np()
        with wave.open(str(p), "rb") as w:
            x = np.frombuffer(w.readframes(w.getnframes()), dtype="<i2").astype(np.float32)
            x = x.reshape(-1, w.getnchannels()).mean(axis=1)
            okno = int(0.01 * w.getframerate())
            e = np.convolve(np.abs(x), np.ones(okno) / okno, mode="same")
            return float(np.argmax(e)) / w.getframerate()
    except Exception:
        return None


def auto_efekty(przejscia, calosc, ziarno=0, glosnosc_mnoznik=1.0, odstep_min=0.6, juz=()):
    """przejscia = [{"rodzaj": "whip-lewo", "czas": <start przejścia na osi>, "d": <długość przejścia>}].
    Zwraca efekty_dzwiekowe do planu: [{"plik", "czas", "glosnosc", "rodzaj"}]."""
    pule = dostepne()
    los = random.Random(ziarno)
    ostatnie = {}
    wynik_ = []
    ost_czas = -9.0
    for p in sorted(przejscia, key=lambda x: x["czas"]):
        r = PRZEJSCIA.get(p.get("rodzaj"))
        if not r:
            continue
        rodzaj, g, gdzie = r
        pula = pule.get(rodzaj) or pule.get("whoosh") or []
        if not pula:
            continue
        # różne pliki po kolei (bez powtarzania tego samego dwa razy z rzędu)
        kand = [x for x in pula if x != ostatnie.get(rodzaj)] or pula
        wlasne = [x for x in kand if UZYTKOWNIKA in x.parents]
        plik = los.choice(wlasne or kand)
        ostatnie[rodzaj] = plik
        sz = szczyt_wav(plik) if plik.suffix.lower() == ".wav" else None
        if sz is None:
            sz = 0.35
        t = p["czas"] + float(p.get("d") or 0) * gdzie - sz
        if t - ost_czas < odstep_min or any(abs(t - float(j)) < 0.4 for j in juz):
            continue
        t = max(0.0, t)
        if t >= calosc - 0.2:
            continue
        wynik_.append({"plik": str(plik), "czas": round(t, 3), "glosnosc": round(g * glosnosc_mnoznik, 3), "rodzaj": rodzaj,
                       "przejscie": p.get("rodzaj")})
        ost_czas = t
    return wynik_


def main():
    ap = argparse.ArgumentParser(description="Efekty dźwiękowe do przejść")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("generuj")
    sub.add_parser("lista")
    p = sub.add_parser("plan")
    p.add_argument("--os", required=True)
    a = ap.parse_args()
    if a.cmd == "generuj":
        wynik(pliki=generuj())
    elif a.cmd == "lista":
        wynik(efekty={k: [str(x) for x in v] for k, v in dostepne().items()})
    else:
        oc = json.loads(Path(a.os).read_text(encoding="utf-8"))
        prz = [{"rodzaj": e.get("przejscie"), "czas": e["od"], "d": e.get("przejscie_d") or 0.3}
               for e in oc["elementy"][1:] if e.get("przejscie")]
        wynik(efekty=auto_efekty(prz, oc["calosc"]))


if __name__ == "__main__":
    main()
