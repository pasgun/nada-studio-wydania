"""Sprawdza, czy silnik jest gotowy: biblioteki, ffmpeg, klucze API i połączenie z serwisami.

  python narzedzia/sprawdz.py            (sprawdzenie, nic nie kosztuje)
  python narzedzia/sprawdz.py --test     (dodatkowo próbna rolka z kolorowych plansz, bez płatnych serwisów)
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, higgsfield_dane, wczytaj_env  # noqa: E402

OK, ZLE, UWAGA = "[OK]", "[BŁĄD]", "[UWAGA]"


def linia(stan, tekst):
    print(f"{stan:8} {tekst}")


def sprawdz_api():
    import requests
    wczytaj_env()

    k = os.environ.get("ELEVENLABS_API_KEY")
    if not k:
        linia(ZLE, "ElevenLabs: brak ELEVENLABS_API_KEY w .env")
    else:
        r = requests.get("https://api.elevenlabs.io/v1/voices", headers={"xi-api-key": k}, timeout=30)
        if r.ok:
            glosy = r.json().get("voices", [])
            linia(OK, f"ElevenLabs: klucz działa, głosów na koncie: {len(glosy)}")
            for g in glosy[:12]:
                print(f"           {g.get('name')}: {g.get('voice_id')}")
        else:
            linia(ZLE, f"ElevenLabs: {r.status_code} {r.text[:150]}")

    k = os.environ.get("MAGNIFIC_API_KEY") or os.environ.get("FREEPIK_API_KEY")
    host = os.environ.get("FREEPIK_HOST", "https://api.magnific.com").rstrip("/")
    if not k:
        linia(ZLE, "Magnific stock: brak MAGNIFIC_API_KEY w .env (klucz z magnific.com/user/organization/api-keys)")
    else:
        r = requests.get(f"{host}/v1/videos", params={"term": "office"},
                         headers={"x-magnific-api-key": k, "x-freepik-api-key": k}, timeout=30)
        if r.status_code == 400:
            linia(OK, "Magnific stock: klucz przyjęty (serwis odpisał na zapytanie testowe)")
        elif r.ok:
            linia(OK, f"Magnific stock: klucz działa, znaleziono ujęcia testowe ({len(r.json().get('data') or [])})")
        else:
            linia(ZLE, f"Magnific stock: klucz odrzucony ({r.status_code}). Upewnij się, że to API key, a nie „webhook secret”, "
                       f"i że wkleiłeś go w całości. {r.text[:120]}")

    k = os.environ.get("GEMINI_API_KEY")
    if not k:
        linia(UWAGA, "Gemini: brak GEMINI_API_KEY (pomijam, jeśli nie używasz)")
    else:
        r = requests.get("https://generativelanguage.googleapis.com/v1beta/models", headers={"x-goog-api-key": k},
                         params={"pageSize": 200}, timeout=30)
        if r.ok:
            obrazowe = [m["name"].replace("models/", "") for m in r.json().get("models", []) if "image" in m.get("name", "") or "banana" in m.get("name", "")]
            linia(OK, f"Gemini: klucz działa; modele obrazów: {', '.join(obrazowe[:6]) or 'brak na liście'}")
        else:
            linia(ZLE, f"Gemini: {r.status_code} {r.text[:150]}")

    print("[INFO]   Magnific (dawny Freepik) działa przez połączenie MCP z abonamentu. Sprawdzisz je w Claude Code poleceniem /mcp.")

    dane = higgsfield_dane(wymagane=False)
    if not dane:
        linia(UWAGA, "Higgsfield: brak HIGGSFIELD_API_KEY (pomijam, jeśli nie używasz)")
    else:
        r = requests.get("https://api.higgsfield.ai/requests/00000000-0000-0000-0000-000000000000/status",
                         headers={"Authorization": f"Key {dane}"}, timeout=30)
        if r.status_code in (401, 403):
            podpowiedz = "" if ":" in dane else " Jeśli panel pokazał dwie wartości (ID i secret), wpisz je razem: ID:SECRET."
            linia(ZLE, f"Higgsfield: klucz odrzucony ({r.status_code}).{podpowiedz}")
        else:
            linia(OK, f"Higgsfield: klucz przyjęty (odpowiedź testowa {r.status_code})")


def test_montazu():
    test = KATALOG_SILNIKA / "_system" / "test"
    sceny = test / "sceny"
    sceny.mkdir(parents=True, exist_ok=True)
    f = lambda *a: subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", *a], check=True)  # noqa: E731
    f("-f", "lavfi", "-i", "testsrc2=size=1920x1080:rate=30", "-t", "4", str(sceny / "s1.mp4"))
    f("-f", "lavfi", "-i", "mandelbrot=size=720x1280:rate=30", "-t", "4", str(sceny / "s2.mp4"))
    f("-f", "lavfi", "-i", "sine=frequency=200:sample_rate=48000", "-t", "6", "-af", "volume=0.3", str(test / "lektor.mp3"))
    slowa, t = [], 0.2
    for w in "To jest próbna rolka. Napisy, logo i plansza końcowa działają.".split():
        d = 0.15 + 0.05 * len(w)
        slowa.append({"slowo": w, "start": round(t, 2), "koniec": round(t + d, 2)})
        t += d + 0.08
    (test / "slowa.json").write_text(json.dumps(slowa, ensure_ascii=False), encoding="utf-8")
    plan = {"wyjscie": "_system/test/rolka_test.mp4", "lektor": "_system/test/lektor.mp3", "slowa": "_system/test/slowa.json",
            "sceny": [{"plik": "_system/test/sceny/s1.mp4", "czas": 3}, {"plik": "_system/test/sceny/s2.mp4", "czas": 3}],
            "napisy": {"podswietlenie": "#22C55E"},
            "plansza_koncowa": {"tekst": "Silnik działa", "przycisk": "Gotowe", "czas": 2}}
    (test / "plan.json").write_text(json.dumps(plan, ensure_ascii=False, indent=1), encoding="utf-8")
    r = subprocess.run([sys.executable, str(Path(__file__).parent / "montaz.py"), "zloz", "--plan", "_system/test/plan.json"],
                       capture_output=True, text=True, encoding="utf-8", errors="replace", cwd=KATALOG_SILNIKA)
    if r.returncode == 0:
        linia(OK, f"Próbna rolka: {KATALOG_SILNIKA / '_system' / 'test' / 'rolka_test.mp4'}")
    else:
        linia(ZLE, "Próbna rolka nie wyszła:\n" + (r.stdout + r.stderr)[-1200:])


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--test", action="store_true")
    a = p.parse_args()

    print(f"Folder silnika: {KATALOG_SILNIKA}")
    w = KATALOG_SILNIKA / "WERSJA.txt"
    if w.exists():
        print(w.read_text(encoding="utf-8").splitlines()[0])
    linia(OK if sys.version_info >= (3, 10) else ZLE, f"Python {sys.version.split()[0]} (potrzebny 3.10+)")
    for lib in ("requests", "PIL"):
        try:
            __import__(lib)
            linia(OK, f"biblioteka {lib}")
        except ImportError:
            linia(ZLE, f"brak biblioteki {lib}: python -m pip install -r requirements.txt")
    try:
        __import__("numpy")
        linia(OK, "biblioteka numpy (bity muzyki)")
    except ImportError:
        linia(UWAGA, "brak numpy (potrzebny do cięcia w rytm muzyki): python -m pip install -r requirements.txt")
    try:
        __import__("fontTools")
        linia(OK, "biblioteka fontTools (fonty w napisach i plikach Photoshopa)")
    except ImportError:
        linia(UWAGA, "brak fontTools (dokładniejszy dobór grubości fontu): python -m pip install -r requirements.txt")
    for lib, opis in (("cv2", "OpenCV (pion z poziomu, miniatury)"), ("psd_tools", "psd-tools (formaty z PSD)")):
        try:
            __import__(lib)
            linia(OK, f"biblioteka {opis}")
        except ImportError:
            linia(UWAGA, f"brak: {opis}: python -m pip install -r requirements.txt")
    try:
        import mowa
        se = mowa.whisper_subtitle_edit()
        linia(OK if se else UWAGA, "Whisper z Subtitle Edit" + (f": {se[1]}" if se else ": nie znaleziono (rozpoznawanie mowy pójdzie przez ElevenLabs)"))
    except Exception:
        pass
    linia(OK if shutil.which("node") else UWAGA, "Node.js (pliki Photoshopa, render animacji)" + ("" if shutil.which("node") else ": winget install OpenJS.NodeJS.LTS i otwórz nowy terminal"))
    anim = KATALOG_SILNIKA / "narzedzia" / "animacje"
    if shutil.which("node"):
        if (anim / "node_modules" / "@napi-rs" / "canvas").exists():
            linia(OK, "biblioteka animacji (render przez Claude)")
        else:
            npm = shutil.which("npm") or shutil.which("npm.cmd")
            r = subprocess.run([npm, "install", "--no-audit", "--no-fund"], cwd=anim, capture_output=True, text=True, encoding="utf-8",
                               errors="replace", shell=sys.platform.startswith("win")) if npm else None
            linia(OK if r and r.returncode == 0 else UWAGA, "biblioteka animacji" + (": zainstalowana teraz" if r and r.returncode == 0 else ": w folderze narzedzia\\animacje uruchom npm install"))
    for prog in ("ffmpeg", "ffprobe"):
        linia(OK if shutil.which(prog) else ZLE, f"{prog}" + ("" if shutil.which(prog) else ": winget install Gyan.FFmpeg i otwórz nowy terminal"))
    linia(OK if (KATALOG_SILNIKA / ".env").exists() else ZLE, "plik .env" + ("" if (KATALOG_SILNIKA / ".env").exists() else ": skopiuj .env.przyklad jako .env i wklej klucze"))
    try:
        sprawdz_api()
    except Exception as e:  # brak requests albo internetu
        linia(ZLE, f"Sprawdzanie API przerwane: {e}")
    if a.test and shutil.which("ffmpeg"):
        test_montazu()
