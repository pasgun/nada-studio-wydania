"""Obrazy Nano Banana przez Antigravity CLI (agy): z limitów abonamentu Google AI Pro, bez klucza API i bez rachunków Google Cloud.

Antigravity ma wbudowane narzędzie generate_image (Nano Banana). To narzędzie uruchamia agy w tle (ukryte okno),
prosi je o jeden obraz, znajduje wygenerowany plik i kopiuje go tam, gdzie trzeba.

  python narzedzia/obraz_agy.py test                    próbny obraz: sprawdza, czy działa i czy trzeba dać zgodę
  python narzedzia/obraz_agy.py obraz --prompt "..." --wyjscie wyniki/X/a.png [--proporcje 4:5] [--obrazy wzor1.jpg wzor2.png] [--px 1080x1350]

Wynik testu: _system/studio/agy_obraz_test.txt. gemini.py używa tego sam, gdy w narzedzia/obrazy_ustawienia.json
jest "silnik": "agy" (domyślnie), więc grafiki w trybie Nano Banana nie korzystają z płatnego API.
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, wynik  # noqa: E402

OBRAZY_R = (".png", ".jpg", ".jpeg", ".webp")
TEST_LOG = KATALOG_SILNIKA / "_system" / "studio" / "agy_obraz_test.txt"


def sciezka_agy():
    try:
        import mcp_studio
        return mcp_studio.sciezka_agy()
    except Exception:
        return shutil.which("agy") or ""


def _katalogi_agy():
    """Gdzie Antigravity może odkładać wygenerowane obrazy (szukamy tam nowych plików po każdym wywołaniu).
    Bez folderu Temp i bez folderu wyników: stamtąd łatwo złapać cudzy albo poprzedni obraz."""
    h = Path.home()
    kand = [h / ".gemini", h / ".antigravity", Path(os.environ.get("LOCALAPPDATA", "")) / "agy",
            Path(os.environ.get("APPDATA", "")) / "Antigravity"]
    return [k for k in kand if str(k) not in ("agy", "Antigravity") and k.exists()]


def _spis(katalogi):
    """{plik: czas zmiany} wszystkich obrazów w katalogach, zanim agy zacznie."""
    spis = {}
    for k in katalogi:
        try:
            for p in k.rglob("*"):
                try:
                    if p.suffix.lower() in OBRAZY_R and p.is_file():
                        spis[str(p)] = p.stat().st_mtime
                except OSError:
                    continue
        except OSError:
            continue
    return spis


def _nowe_obrazy(przed, katalogi):
    """Tylko obrazy, których przed uruchomieniem nie było (albo zostały zmienione)."""
    teraz = _spis(katalogi)
    nowe = [Path(p) for p, t in teraz.items() if przed.get(p) != t]
    nowe = [p for p in nowe if p.stat().st_size > 3000]
    nowe.sort(key=lambda p: p.stat().st_mtime, reverse=True)
    return nowe


def _sciezki_z_logu(tekst):
    """Ścieżki obrazów wspomniane w odpowiedziach agy (wynik generate_image, końcowa odpowiedź)."""
    import re
    out = []
    for m in re.findall(r'([A-Za-z]:[\\/][^"\'<>|\n\r]+?\.(?:png|jpe?g|webp))', tekst, re.I):
        p = Path(m.replace("\\\\", "\\").replace("file:///", ""))
        if p.exists():
            out.append(p)
    for m in re.findall(r'file:///([^"\'\s)]+?\.(?:png|jpe?g|webp))', tekst, re.I):
        from urllib.parse import unquote
        p = Path(unquote(m))
        if p.exists():
            out.append(p)
    return out


import threading
_ZAJETE, _ZAMEK = set(), threading.Lock()   # obrazy już przypisane innym wywołaniom (kilka obrazów naraz)

LIMIT_SLOWA = ("resource_exhausted", "quota", "rate limit", "rate-limit", "too many requests", "(429", " 429 ", "usage limit", "limit reached",
               "wyczerpano limit", "limit zapytań")


def wymiary(plik):
    try:
        from PIL import Image
        with Image.open(plik) as im:
            return im.size
    except Exception:
        return None


def generuj(prompt, wyjscie, proporcje="1:1", obrazy=None, timeout=480, log=None):
    """Jeden obraz przez agy. Zwraca słownik: plik, wymiary (prawdziwe, przed dopasowaniem), sekundy;
    albo blad (+ limit=True, gdy Antigravity zgłosił wyczerpany limit, + odmowa, gdy nie dostał zgody).

    Agy pracuje w pustym, osobnym folderze (_system/gemini/agy_obrazy/<numer>), więc nie widzi innych grafik
    i nie da się mu „podsunąć” starego pliku; przyjmujemy tylko obraz, który naprawdę powstał w tym wywołaniu."""
    import uuid
    agy = sciezka_agy()
    if not agy:
        return {"blad": "Brak Antigravity CLI (agy). Instalacja: python narzedzia\\mozg.py sprawdz"}
    wyjscie = Path(wyjscie).resolve()
    wyjscie.parent.mkdir(parents=True, exist_ok=True)
    praca = KATALOG_SILNIKA / "_system" / "gemini" / "agy_obrazy" / uuid.uuid4().hex[:10]
    praca.mkdir(parents=True, exist_ok=True)
    cel_agy = praca / ("obraz" + (wyjscie.suffix or ".png"))
    obrazy = [str(Path(o).resolve()) for o in (obrazy or []) if Path(o).exists()]
    wzory = ""
    if obrazy:
        wzory = ("\nReference images (pass them to generate_image as input images if the tool accepts images; otherwise first open "
                 "each with view_file and describe its look precisely inside the image prompt):\n" + "\n".join(f"- {o}" for o in obrazy))
    polecenie = (
        "Your only job: create exactly one image, with the image-generator subagent (invoke_subagent with TypeName "
        "'image-generator') or the generate_image tool. Do not run any shell commands, "
        "do not edit or copy any existing files, do not ask questions.\n"
        f"Aspect ratio: {proporcje} (this is required: the image must have exactly this shape).\nImage description:\n{prompt}\n{wzory}\n"
        f"If the tool lets you choose where to save the image, save it as: {cel_agy}\n"
        "When done, reply with the full path of the newly generated image file and nothing else. "
        "If image generation fails, reply with the word FAILED and the reason; never return a path to an older image.")
    cmd = [agy, "-p", polecenie, "--output-format", "stream-json", "--mode", "accept-edits", "--add-dir", str(praca)]
    for d in sorted({str(Path(o).parent) for o in obrazy}):
        cmd += ["--add-dir", d]
    katalogi = _katalogi_agy() + [praca]
    przed = _spis(katalogi)
    start = time.time()
    flagi = 0x08000000 if sys.platform.startswith("win") else 0  # bez okna konsoli
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout,
                           cwd=str(KATALOG_SILNIKA), creationflags=flagi)
        tekst = (r.stdout or "") + "\n" + (r.stderr or "")
    except subprocess.TimeoutExpired as e:
        tekst = str(e.stdout or "") + str(e.stderr or "") + "\n(przekroczony czas)"
    if log:
        Path(log).parent.mkdir(parents=True, exist_ok=True)
        with open(log, "a", encoding="utf-8") as f:
            f.write(f"\n===== {time.strftime('%H:%M:%S')} =====\n$ agy -p ... (generate_image)\n{tekst[-20000:]}\n")
    odmowa = None
    for linia in tekst.splitlines():
        try:
            d = json.loads(linia)
        except Exception:
            continue
        res = d.get("result") if isinstance(d, dict) else None
        if isinstance(res, dict) and res.get("denied_actions"):
            odmowa = res["denied_actions"]
    nowe = {str(p) for p in _nowe_obrazy(przed, katalogi)}
    # ścieżka z odpowiedzi liczy się tylko, gdy to naprawdę nowy plik (nie stary obraz, który agy „znalazł”)
    kandydaci = [p for p in _sciezki_z_logu(tekst) if str(p) in nowe]
    if cel_agy.exists() and str(cel_agy) in nowe:
        kandydaci.insert(0, cel_agy)
    with _ZAMEK:
        kandydaci = [p for p in kandydaci if str(p) not in _ZAJETE]
        if not kandydaci:
            # agy nie podał ścieżki: bierzemy nowy plik tylko wtedy, gdy jest jeden jedyny (przy kilku obrazach naraz
            # nie wiadomo, który jest nasz, więc lepiej spróbować jeszcze raz niż wziąć cudzy)
            wolne = [p for p in nowe if p not in _ZAJETE]
            if len(wolne) == 1:
                kandydaci = [Path(wolne[0])]
        if kandydaci:
            _ZAJETE.add(str(kandydaci[0]))
    if not kandydaci:
        odp = []
        for linia in tekst.splitlines():
            try:
                d = json.loads(linia)
            except Exception:
                continue
            if isinstance(d, dict):
                su, res = d.get("step_update") or {}, d.get("result") or {}
                odp.append(str(su.get("text_delta") or "") + str(res.get("response") or "") if isinstance(res, dict) else "")
                if su.get("step_type") in ("tool", "subagent"):
                    odp.append(json.dumps(su, ensure_ascii=False)[-2000:])
        maly = (" ".join(odp) or tekst).lower()
        limit = any(w in maly for w in LIMIT_SLOWA)
        powod = "Antigravity zgłosił wyczerpany limit obrazów w abonamencie (spróbuj za jakiś czas)." if limit else \
            ("Antigravity zrobił kilka obrazów naraz i nie wiadomo, który jest ten." if len(nowe) > 1 else "Antigravity nie zrobił obrazu.")
        return {"blad": powod + (f" Odmowa zgody: {odmowa}" if odmowa else "") + (" Odpowiedź agy: " + " ".join(odp)[-300:] if odp else ""), "limit": limit, "odmowa": odmowa, "log": tekst[-3000:]}
    zrodlo = kandydaci[0]
    wym = wymiary(zrodlo)
    from PIL import Image
    with Image.open(zrodlo) as im:
        im.convert("RGB" if wyjscie.suffix.lower() in (".jpg", ".jpeg") else "RGBA").save(wyjscie)
    shutil.rmtree(praca, ignore_errors=True)  # tylko nasz roboczy folder (kopia obrazu zostaje też u agy)
    return {"plik": str(wyjscie), "zrodlo": str(zrodlo), "wymiary": list(wym) if wym else None, "sekundy": round(time.time() - start, 1)}


def ustawienia():
    """narzedzia/obrazy_ustawienia.json: {"silnik": "agy"} (domyślnie, abonament) albo "api" (klucz GEMINI_API_KEY, płatne)."""
    try:
        return json.loads((Path(__file__).resolve().parent / "obrazy_ustawienia.json").read_text(encoding="utf-8"))
    except Exception:
        return {}


def silnik():
    return "api" if ustawienia().get("silnik") == "api" else "agy"


def tekst(prompt, obrazy=None, timeout=300):
    """Odpowiedź tekstowa Gemini przez agy (abonament). obrazy = pliki do obejrzenia (view_file). Zwraca (tekst, błąd)."""
    agy = sciezka_agy()
    if not agy:
        return None, "brak Antigravity CLI (agy)"
    obrazy = [str(Path(o).resolve()) for o in (obrazy or []) if Path(o).exists()]
    pol = ("Do not run shell commands and do not edit files. " + (
        "First look at these images with view_file, in this order:\n" + "\n".join(f"{i + 1}. {o}" for i, o in enumerate(obrazy)) + "\n" if obrazy else "")
        + prompt + "\nReply with the answer only.")
    cmd = [agy, "-p", pol, "--output-format", "stream-json", "--mode", "accept-edits"]
    for d in sorted({str(Path(o).parent) for o in obrazy}):
        cmd += ["--add-dir", d]
    flagi = 0x08000000 if sys.platform.startswith("win") else 0
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=timeout,
                           cwd=str(KATALOG_SILNIKA), creationflags=flagi)
    except subprocess.TimeoutExpired:
        return None, "Antigravity nie odpowiedział na czas"
    odp = None
    for linia in (r.stdout or "").splitlines():
        try:
            d = json.loads(linia)
        except Exception:
            continue
        if isinstance(d, dict) and isinstance(d.get("result"), dict) and d["result"].get("response"):
            odp = d["result"]["response"]
    if not odp:
        return None, "Antigravity nie dał odpowiedzi: " + ((r.stderr or r.stdout or "")[-300:])
    return odp.replace("[GOTOWE]", "").strip(), None


def main():
    ap = argparse.ArgumentParser(description="Nano Banana przez Antigravity (abonament Google AI Pro)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("test")
    o = sub.add_parser("obraz")
    o.add_argument("--prompt", required=True); o.add_argument("--wyjscie", required=True)
    o.add_argument("--proporcje", default="1:1"); o.add_argument("--obrazy", nargs="*", default=None)
    o.add_argument("--px", default=None, help="dokładny rozmiar wyniku, np. 1200x628")
    a = ap.parse_args()
    if a.cmd == "test":
        TEST_LOG.parent.mkdir(parents=True, exist_ok=True)
        TEST_LOG.write_text(f"Test Nano Banana przez Antigravity, {time.strftime('%Y-%m-%d %H:%M')}\n", encoding="utf-8")
        cel = KATALOG_SILNIKA / "_system" / "studio" / "agy_obraz_test.png"
        w = generuj('A bright orange banana wearing tiny sunglasses on a plain white background, with the text "TEST NADA" in bold black letters.',
                    cel, "1:1", None, log=TEST_LOG)
        with open(TEST_LOG, "a", encoding="utf-8") as f:
            f.write("\n--- wynik ---\n" + json.dumps(w, ensure_ascii=False, indent=1) + "\n")
        if w.get("plik"):
            wynik(dziala=True, plik=w["plik"], sekundy=w.get("sekundy"), log=str(TEST_LOG))
        else:
            wynik(dziala=False, blad=w.get("blad"), odmowa=w.get("odmowa"), log=str(TEST_LOG),
                  dalej="Wyślij Claude'owi plik _system\\studio\\agy_obraz_test.txt (albo napisz, że test się skończył).")
        return
    w = generuj(a.prompt, a.wyjscie, a.proporcje, a.obrazy)
    if not w.get("plik"):
        blad(w.get("blad") or "Antigravity nie zwrócił obrazu.")
    if a.px:
        import gemini
        gemini.dopasuj_px(w["plik"], *[int(x) for x in a.px.lower().split("x")])
    wynik(**w)


if __name__ == "__main__":
    main()
