// Składa plik Photoshopa (PSD) z artboardami z opisu przygotowanego przez narzedzia/grafika.py.
// Użycie: node narzedzia/psd/zloz_psd.js zadanie.json
// Biblioteki (ag-psd, pngjs) są w podfolderze node_modules obok tego pliku, nic nie trzeba instalować.
'use strict';
const fs = require('fs');
const path = require('path');
const { PNG } = require('pngjs');
const { writePsdBuffer } = require('ag-psd');

function wczytajPng(plik) {
  const png = PNG.sync.read(fs.readFileSync(plik));
  return { width: png.width, height: png.height, data: new Uint8ClampedArray(png.data.buffer, png.data.byteOffset, png.data.length) };
}

function kolor(rgb) {
  return { r: rgb[0], g: rgb[1], b: rgb[2] };
}

function warstwa(w) {
  const img = wczytajPng(w.plik);
  const l = { name: w.nazwa, left: w.x, top: w.y, right: w.x + img.width, bottom: w.y + img.height, imageData: img, opacity: w.krycie ?? 1 };
  if (w.tekst) {
    const t = w.tekst;
    const runs = (t.runs || []).map((r) => ({ length: r.dl, style: { fillColor: kolor(r.kolor) } }));
    l.text = {
      text: t.tekst,
      transform: [1, 0, 0, 1, t.x, t.y],
      style: {
        font: { name: t.font },
        fontSize: t.rozmiar,
        autoLeading: false,
        leading: t.interlinia,
        fillColor: runs.length ? runs[0].style.fillColor : { r: 255, g: 255, b: 255 },
        ...(t.sledzenie ? { tracking: t.sledzenie } : {}),
      },
      styleRuns: runs.length > 1 ? runs : undefined,
      paragraphStyle: { justification: t.wyrownanie === 'center' ? 'center' : 'left' },
    };
  }
  return l;
}

function main() {
  const zad = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
  const artboardy = zad.artboardy.map((a) => ({
    name: a.nazwa,
    opened: true,
    artboard: { rect: { top: a.y, left: a.x, bottom: a.y + a.h, right: a.x + a.w }, presetName: 'Custom', backgroundType: 1 },
    // ag-psd: pierwsza warstwa na liście = najniżej
    children: a.warstwy.map(warstwa),
  }));
  const psd = {
    width: zad.szerokosc,
    height: zad.wysokosc,
    imageData: wczytajPng(zad.kompozyt),
    imageResources: { resolutionInfo: { horizontalResolution: 72, horizontalResolutionUnit: 'PPI', widthUnit: 'Inches',
      verticalResolution: 72, verticalResolutionUnit: 'PPI', heightUnit: 'Inches' } },
    artboards: { count: artboardy.length, autoExpandEnabled: true, autoNestEnabled: true, autoPositionEnabled: true,
      shrinkwrapOnSaveEnabled: true, docDefaultNewArtboardBackgroundColor: { r: 255, g: 255, b: 255 }, docDefaultNewArtboardBackgroundType: 1 },
    children: artboardy,
  };
  const bufor = writePsdBuffer(psd, { invalidateTextLayers: true, generateThumbnail: false, noBackground: true,
    psb: zad.szerokosc > 30000 || zad.wysokosc > 30000 });
  fs.mkdirSync(path.dirname(zad.wyjscie), { recursive: true });
  fs.writeFileSync(zad.wyjscie, bufor);
  console.log(JSON.stringify({ ok: true, plik: zad.wyjscie, artboardow: artboardy.length, mb: +(bufor.length / 1e6).toFixed(1) }));
}

try {
  main();
} catch (e) {
  console.error(e && e.stack ? e.stack : String(e));
  process.exit(1);
}
