"""Drugi „mózg” silnika: Gemini przez Antigravity CLI (agy), z logowaniem kontem Google.

Zużywa limity Twojego abonamentu Google AI Pro, bez kluczy API (klucz z .env NIE jest tu używany,
więc nic nie płacisz ponad abonament; gdy limit się skończy, Gemini przestaje odpowiadać do odnowienia).

  python narzedzia/mozg.py sprawdz          czy agy jest zainstalowane, wersja i jego pomoc (zapis do _system/studio/agy_pomoc.txt)
  python narzedzia/mozg.py instaluj         ustawia zgody na narzędzia silnika (python, ffmpeg, node) i daje Gemini te same połączenia co Claude Code
  python narzedzia/mozg.py test             próba Gemini w tle: czy może uruchomić narzędzia silnika bez pytania; zapis do _system/studio/agy_test.txt
  python narzedzia/mozg.py epidemic         Epidemic Sound z kluczem (EPIDEMIC_SOUND_MCP_API_KEY w .env) dla Claude Code i Gemini naraz
  python narzedzia/mozg.py polacz           tylko połączenia: Magnific, Epidemic Sound, Artlist itd. z Claude Code przepisane do Gemini (agy)
  python narzedzia/mozg.py pelne --tak|--nie  pozwala Gemini uruchamiać wszystko bez pytania (domyślnie: nie)
"""
import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, wynik  # noqa: E402
import mcp_studio  # noqa: E402

USTAWIENIA_SILNIKA = KATALOG_SILNIKA / "narzedzia" / "mozg_ustawienia.json"
# Antigravity zezwala w tle tylko na polecenia zapisane w zgodach znak w znak (gwiazdki nie działają: sprawdzone testem 24.10.2026).
# Dlatego Gemini uruchamia narzędzia silnika przez pomocnika narzedzia/uruchom.py: prośba w pliku, polecenie zawsze to samo.
ZGODY = ["command(python narzedzia/uruchom.py)", "command(python narzedzia\\uruchom.py)", "command(py narzedzia/uruchom.py)", "command(python3 narzedzia/uruchom.py)"]


def dopisz_zgody(reguly, usun=()):
    p = plik_ustawien_agy()
    try:
        d = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    except Exception:
        blad(f"Nie umiem odczytać {p}. Popraw albo usuń ten plik i spróbuj ponownie.")
    lista = d.setdefault("permissions", {}).setdefault("allow", [])
    lista[:] = [x for x in lista if x not in set(usun)]
    for r in reguly:
        if r not in lista:
            lista.append(r)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    return lista


def plik_ustawien_agy():
    return Path.home() / ".gemini" / "antigravity-cli" / "settings.json"


def sprawdz():
    agy = mcp_studio.sciezka_agy()
    if not agy:
        wynik(zainstalowane=False, dalej="Zainstaluj Antigravity CLI: w PowerShell wpisz  irm https://antigravity.google/cli/install.ps1 | iex  potem zamknij i otwórz PowerShell, wpisz  agy  i zaloguj się kontem Google (tym z abonamentem AI Pro).")
        return
    def uruchom(*a):
        try:
            r = subprocess.run([agy, *a], capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=40)
            return (r.stdout or "") + (r.stderr or "")
        except Exception as e:
            return f"(błąd: {e})"
    wersja = uruchom("--version").strip()
    pomoc = uruchom("--help")
    cel = mcp_studio._sys("studio") / "agy_pomoc.txt"
    cel.parent.mkdir(parents=True, exist_ok=True)
    cel.write_text(f"agy: {agy}\nwersja: {wersja}\n\n{pomoc}", encoding="utf-8")
    flagi = {f: (f in pomoc) for f in ("--output-format", "--mode", "--conversation", "--continue", "--dangerously-skip-permissions")}
    lista_mcp = uruchom("mcp", "list")
    with open(cel, "a", encoding="utf-8") as f:
        f.write("\n\n--- agy mcp list ---\n" + lista_mcp)
    wynik(zainstalowane=True, agy=agy, wersja=wersja, flagi=flagi, pomoc=str(cel),
          uwaga="Jeśli jeszcze się nie logowałeś: wpisz w PowerShell  agy  i zaloguj się kontem Google. Potem w Studio wybierz mózg Gemini.")


def instaluj():
    p = plik_ustawien_agy()
    p.parent.mkdir(parents=True, exist_ok=True)
    try:
        d = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}
    except Exception:
        blad(f"Nie umiem odczytać {p}. Popraw albo usuń ten plik i spróbuj ponownie.")
    if p.exists():
        shutil.copy(p, p.with_suffix(".json.kopia"))
    perm = d.setdefault("permissions", {})
    lista = perm.setdefault("allow", [])
    for z in ZGODY:
        if z not in lista:
            lista.append(z)
    p.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    agy = mcp_studio.sciezka_agy()
    pol = polacz(cicho=True)
    # zgody na narzędzia z połączeń (Magnific, Epidemic...), żeby Gemini w tle nie stawał na pytaniu o zgodę
    # Antigravity w tle zezwala tylko na zgody słowo w słowo: mcp(<serwer>/<narzędzie>) dla każdego narzędzia osobno.
    # Listę narzędzi każdego połączenia Antigravity trzyma w ~/.gemini/antigravity-cli/mcp/<serwer>/<narzędzie>.json
    serwery = {x["nazwa"] for x in pol} | {k.name for k in (p.parent / "mcp").glob("*") if k.is_dir()}
    for nazwa in sorted(serwery):
        for z in [f"mcp({nazwa})"] + [f"mcp({nazwa}/{n.stem})" for n in sorted((p.parent / "mcp" / nazwa).glob("*.json"))]:
            if z not in lista:
                lista.append(z)
    p.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    wynik(zgody=lista, plik=str(p), agy=agy or None, polaczenia=pol,
          dalej=("Gotowe. Zaloguj się raz: w PowerShell wpisz  agy  (otworzy się logowanie Google)." if agy else
                 "Zgody ustawione. Teraz zainstaluj Antigravity CLI: w PowerShell  irm https://antigravity.google/cli/install.ps1 | iex  , potem  agy  i logowanie Google."))


def serwery_claude():
    """Serwery MCP (połączenia z usługami) ustawione w Claude Code: dla wszystkich projektów i dla folderu silnika."""
    wyn = {}
    plik = Path.home() / ".claude.json"
    try:
        d = json.loads(plik.read_text(encoding="utf-8"))
    except Exception:
        d = {}
    wyn.update(d.get("mcpServers") or {})
    sil = str(KATALOG_SILNIKA).replace("\\", "/").lower().rstrip("/")
    for sciezka, proj in (d.get("projects") or {}).items():
        if str(sciezka).replace("\\", "/").lower().rstrip("/") == sil:
            wyn.update((proj or {}).get("mcpServers") or {})
    try:
        wyn.update(json.loads((KATALOG_SILNIKA / ".mcp.json").read_text(encoding="utf-8")).get("mcpServers") or {})
    except Exception:
        pass
    return wyn


def rozwin(tekst):
    """${ZMIENNA} w nagłówkach Claude Code zamienia na wartość z .env albo ze zmiennych systemu (Gemini sam tego nie robi)."""
    import re
    from wspolne import wczytaj_env
    wczytaj_env()
    return re.sub(r"\$\{([A-Z0-9_]+)\}", lambda m: os.environ.get(m.group(1), m.group(0)), str(tekst))


EPIDEMIC_URL = "https://www.epidemicsound.com/a/mcp-service/mcp"


def epidemic():
    """Epidemic Sound łączy się z programami w tle tylko kluczem z konta (Konto → API keys), nie logowaniem w przeglądarce."""
    from wspolne import wczytaj_env
    wczytaj_env()
    k = os.environ.get("EPIDEMIC_SOUND_MCP_API_KEY", "").strip()
    if not k:
        blad("Brak klucza EPIDEMIC_SOUND_MCP_API_KEY w pliku .env. Wygeneruj go na https://www.epidemicsound.com/account/api-keys "
             "(Konto → API keys, nie Developer Portal), wklej do .env po znaku = (np. Studio → Ustawienia → Otwórz plik kluczy) i uruchom to polecenie jeszcze raz.")
    kroki = []
    # 1) zmienna systemowa, z której Claude Code bierze klucz (klucz nie trafia do jego pliku ustawień)
    if sys.platform.startswith("win"):
        r = subprocess.run(["setx", "EPIDEMIC_SOUND_MCP_API_KEY", k], capture_output=True, text=True, creationflags=0x08000000)
        kroki.append({"krok": "zmienna systemowa EPIDEMIC_SOUND_MCP_API_KEY", "ok": r.returncode == 0})
    # 2) Claude Code: stare połączenie (logowanie) usuwamy, nowe z kluczem
    try:
        claude = mcp_studio.sciezka_claude()
    except Exception:
        claude = ""
    if claude:
        pre = ["cmd", "/c", claude] if claude.lower().endswith((".cmd", ".bat")) else [claude]
        for zakres in ("local", "user", "project"):
            subprocess.run(pre + ["mcp", "remove", "epidemic-sound", "-s", zakres], cwd=str(KATALOG_SILNIKA), capture_output=True, text=True)
        r = subprocess.run(pre + ["mcp", "add", "-s", "user", "--transport", "http", "epidemic-sound", EPIDEMIC_URL,
                                  "--header", "Authorization: Bearer ${EPIDEMIC_SOUND_MCP_API_KEY}"], cwd=str(KATALOG_SILNIKA), capture_output=True, text=True)
        kroki.append({"krok": "Claude Code", "ok": r.returncode == 0, "blad": None if r.returncode == 0 else (r.stderr or r.stdout)[-300:].replace(k, "***")})
    else:
        kroki.append({"krok": "Claude Code", "ok": False, "blad": "nie znalazłem polecenia claude"})
    # 3) Gemini (agy): to samo połączenie z kluczem
    cfg_plik = KATALOG_SILNIKA / ".agents" / "mcp_config.json"
    cfg_plik.parent.mkdir(parents=True, exist_ok=True)
    try:
        cfg = json.loads(cfg_plik.read_text(encoding="utf-8")) if cfg_plik.exists() else {}
    except Exception:
        cfg = {}
    cfg.setdefault("mcpServers", {})["epidemic-sound"] = {"serverUrl": EPIDEMIC_URL, "headers": {"Authorization": f"Bearer {k}"}}
    cfg_plik.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    agy = mcp_studio.sciezka_agy()
    if agy:
        subprocess.run([agy, "mcp", "remove", "epidemic-sound"], cwd=str(KATALOG_SILNIKA), capture_output=True, text=True)
        r = subprocess.run([agy, "mcp", "add", "-t", "http", "-H", f"Authorization: Bearer {k}", "epidemic-sound", EPIDEMIC_URL], cwd=str(KATALOG_SILNIKA), capture_output=True, text=True)
        kroki.append({"krok": "Gemini (agy)", "ok": True, "zapis": "agy mcp add" if r.returncode == 0 else "plik .agents/mcp_config.json"})
    else:
        kroki.append({"krok": "Gemini (agy)", "ok": True, "zapis": "plik .agents/mcp_config.json"})
    wynik(kroki=kroki, dalej="Zamknij całkiem i otwórz aplikację Claude i okna PowerShell (nowa zmienna systemowa działa w nowych oknach). "
                             "Sprawdzenie: claude mcp list (epidemic-sound: Connected) oraz agy mcp list.")


HIGGSFIELD_URL = "https://mcp.higgsfield.ai/mcp"


def higgsfield():
    """Higgsfield przez połączenie MCP: logowanie kontem higgsfield.ai i kredyty z ABONAMENTU (API ma osobne saldo w dolarach)."""
    try:
        claude = mcp_studio.sciezka_claude()
    except Exception:
        claude = ""
    if not claude:
        blad("Nie znalazłem polecenia claude (Claude Code). Zainstaluj je w apce: Ustawienia > Apka i programy.")
    pre = ["cmd", "/c", claude] if claude.lower().endswith((".cmd", ".bat")) else [claude]
    for zakres in ("local", "project"):
        subprocess.run(pre + ["mcp", "remove", "higgsfield", "-s", zakres], cwd=str(KATALOG_SILNIKA), capture_output=True, text=True)
    r = subprocess.run(pre + ["mcp", "add", "-s", "user", "--transport", "http", "higgsfield", HIGGSFIELD_URL], cwd=str(KATALOG_SILNIKA), capture_output=True, text=True)
    juz = "already exists" in (r.stderr or r.stdout or "")
    if r.returncode != 0 and not juz:
        blad("Nie udało się dodać połączenia Higgsfield do Claude Code: " + (r.stderr or r.stdout)[-300:])
    wynik(dodane=not juz, juz_bylo=juz, url=HIGGSFIELD_URL,
          dalej="Jeszcze jednorazowe logowanie: otwórz PowerShell w folderze silnika (C:\\Studio\\studio-rolek), wpisz claude, potem /mcp, "
                "wybierz higgsfield > Authenticate i zaloguj się w przeglądarce tym samym kontem co na higgsfield.ai. "
                "Od tej chwili zadania w tle generują w Higgsfield z kredytów abonamentu.")


def polacz(cicho=False):
    """Te same połączenia co w Claude Code (stock i AI Magnific, Epidemic Sound, Artlist...) dla Gemini.
    Wartości kluczy i nagłówków są przepisywane między plikami na tym komputerze, nigdy nie są wypisywane."""
    serwery = serwery_claude()
    agy = mcp_studio.sciezka_agy()
    cfg_plik = KATALOG_SILNIKA / ".agents" / "mcp_config.json"
    cfg_plik.parent.mkdir(parents=True, exist_ok=True)
    try:
        cfg = json.loads(cfg_plik.read_text(encoding="utf-8")) if cfg_plik.exists() else {}
    except Exception:
        cfg = {}
    docelowe = cfg.setdefault("mcpServers", {})
    raport = []
    for nazwa, sv in serwery.items():
        if not isinstance(sv, dict) or nazwa in ("studio-rolek",):
            continue
        url = sv.get("url") or sv.get("serverUrl")
        if url:
            wpis = {"serverUrl": url}
            if sv.get("headers"):
                wpis["headers"] = {hk: rozwin(hv) for hk, hv in sv["headers"].items()}
            rodzaj = "internet"
        elif sv.get("command"):
            wpis = {"command": sv["command"], "args": sv.get("args") or []}
            if sv.get("env"):
                wpis["env"] = {ek: rozwin(ev) for ek, ev in sv["env"].items()}
            rodzaj = "program na PC"
        else:
            continue
        docelowe[nazwa] = wpis
        sposob = "plik"
        if agy:
            # oficjalna droga: agy mcp add (opcje przed nazwą serwera)
            if url:
                arg = [agy, "mcp", "add", "-t", "http", *sum((["-H", f"{k}: {v}"] for k, v in (wpis.get("headers") or {}).items()), []), nazwa, url]
            else:
                arg = [agy, "mcp", "add", *sum((["-e", f"{k}={v}"] for k, v in (wpis.get("env") or {}).items()), []), nazwa, "--", sv["command"], *(sv.get("args") or [])]
            try:
                r = subprocess.run(arg, cwd=str(KATALOG_SILNIKA), capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=60)
                if r.returncode == 0:
                    sposob = "agy mcp add"
            except Exception:
                pass
        raport.append({"nazwa": nazwa, "rodzaj": rodzaj, "logowanie": "klucz przepisany" if (sv.get("headers") or sv.get("env")) else "może poprosić o zalogowanie przy pierwszym użyciu", "zapis": sposob})
    cfg_plik.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
    if cicho:
        return raport
    wynik(polaczenia=raport, plik=str(cfg_plik),
          uwaga=("Brak połączeń w Claude Code do przepisania." if not raport else
                 "Gotowe. Połączenia bez klucza (np. Magnific, Epidemic) przy pierwszym użyciu w Gemini poproszą o zalogowanie w przeglądarce: "
                 "otwórz PowerShell w folderze silnika, wpisz agy i napisz „sprawdź połączenie z magnific” – zaloguj się, gdy otworzy się strona."))


def test():
    """Próba w tle (tak jak z panelu): Gemini zapisuje prośbę i uruchamia narzędzia silnika przez pomocnika uruchom.py.
    Najpierw dopisuje stałe zgody na pomocnika. Do pliku trafiają tylko wyniki kroków."""
    agy = mcp_studio.sciezka_agy()
    if not agy:
        blad("Nie znalazłem Antigravity CLI (agy).")
    cel = mcp_studio._sys("studio") / "agy_test.txt"
    cel.parent.mkdir(parents=True, exist_ok=True)
    dopisz_zgody(ZGODY)
    prosba = '{"polecenia": [{"narzedzie": "postep.py", "argumenty": ["--etap", "proba", "--tekst", "próba Gemini"]}, {"narzedzie": "ffprobe", "argumenty": ["-hide_banner", "-version"]}]}'
    prompt = ("To jest test. Zrób dokładnie dwa kroki i nic więcej:\n"
              f"1. Zapisz plik _system/gemini/polecenie_gemini.json z taką treścią: {prosba}\n"
              "2. Uruchom polecenie: python narzedzia/uruchom.py\n"
              "Potem napisz jednym zdaniem, co wypisało polecenie.")
    env = {k: v for k, v in os.environ.items() if k != "NM_POSTEP"}
    try:
        r = subprocess.run([agy, "-p", prompt, "--output-format", "stream-json", *mcp_studio.flagi_agy(), "--print-timeout", "2m"],
                           cwd=str(KATALOG_SILNIKA), capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=150, env=env)
        wyj = r.stdout + "\n" + r.stderr
    except subprocess.TimeoutExpired as e:
        wyj = (e.stdout if isinstance(e.stdout, str) else (e.stdout or b"").decode("utf-8", "replace")) or ""
        wyj += "\n(przekroczony czas: Gemini prawdopodobnie czekał na zgodę)"
    kroki = []
    for l in wyj.splitlines():
        try:
            dd = json.loads(l)
        except Exception:
            continue
        su = dd.get("step_update") or {}
        if su.get("step_type") == "tool" and su.get("state") in ("DONE", "ERROR"):
            ti = su.get("tool_info") or {}
            par = ti.get("parameters") or {}
            kroki.append({"krok": par.get("CommandLine") or f"{su.get('tool_name')}: {par.get('Path') or par.get('TargetFile') or ''}", "stan": su.get("state"),
                          "blad": str((ti.get("error") or {}).get("message") or "").split("\n")[0][:200] or None,
                          "wynik": str(ti.get("output") or "")[-400:] or None})
    zapis = any(k["stan"] == "DONE" and "polecenie_gemini" in k["krok"] for k in kroki)
    uruchom = [k for k in kroki if "uruchom.py" in k["krok"]]
    dziala = bool(uruchom) and all(k["stan"] == "DONE" for k in uruchom)
    wykonane = sorted(mcp_studio._sys("gemini").glob("polecenie_gemini_*.wykonane.json"))
    cel.write_text("--- kroki ---\n" + json.dumps(kroki, ensure_ascii=False, indent=1) +
                   f"\n\nzapis prośby: {zapis}\npomocnik uruchomiony: {dziala}\nprośba zużyta przez pomocnika: {bool(wykonane)}\n\n--- surowy zapis (koniec) ---\n" +
                   "\n".join(l[:600] for l in wyj.splitlines()[-12:]), encoding="utf-8")
    wynik(zapis_prosby=zapis, pomocnik=dziala, plik=str(cel),
          uwaga=("Działa: Gemini uruchamia narzędzia silnika w tle bez pytania. Napisz Claude'owi, że test się skończył." if zapis and dziala else
                 "Test skończony. Napisz Claude'owi, że test się skończył: przeczyta wynik."))


def pelne(tak):
    d = mcp_studio.ustawienia_mozgu()
    d["pelne_uprawnienia"] = bool(tak)
    USTAWIENIA_SILNIKA.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    wynik(pelne_uprawnienia=bool(tak), uwaga="Gemini uruchamia teraz polecenia bez pytania." if tak else "Gemini pyta o polecenia spoza listy zgód (python, ffmpeg, node).")


def tryb(nazwa):
    d = mcp_studio.ustawienia_mozgu()
    d["tryb"] = nazwa
    USTAWIENIA_SILNIKA.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    wynik(tryb=nazwa, flagi=mcp_studio.flagi_agy(), uwaga="Zadania Gemini w tle (panel i Studio) startują teraz w tym trybie.")


if __name__ == "__main__":
    a = argparse.ArgumentParser(description="Gemini (Antigravity CLI) jako drugi mózg silnika")
    sub = a.add_subparsers(dest="tryb", required=True)
    sub.add_parser("sprawdz"); sub.add_parser("instaluj"); sub.add_parser("polacz"); sub.add_parser("epidemic"); sub.add_parser("higgsfield"); sub.add_parser("test")
    pl = sub.add_parser("pelne"); g = pl.add_mutually_exclusive_group(required=True); g.add_argument("--tak", action="store_true"); g.add_argument("--nie", action="store_true")
    tr = sub.add_parser("tryb", help="tryb pracy Gemini w tle"); tr.add_argument("nazwa", choices=sorted(mcp_studio.TRYBY_AGY))
    x = a.parse_args()
    if x.tryb == "sprawdz":
        sprawdz()
    elif x.tryb == "instaluj":
        instaluj()
    elif x.tryb == "polacz":
        polacz()
    elif x.tryb == "epidemic":
        epidemic()
    elif x.tryb == "higgsfield":
        higgsfield()
    elif x.tryb == "test":
        test()
    elif x.tryb == "tryb":
        tryb(x.nazwa)
    else:
        pelne(x.tak)
