"""Brandbook z linku albo z materiałów klienta.

  python narzedzia/brandbook.py strona --url https://firma.pl --folder klienci/<klient>/brandbook/_zrodla
     -> kolory z CSS (z liczbą użyć), fonty, kandydaci na logo (pobrane), tytuł, opis i teksty strony do oceny tonu
  python narzedzia/brandbook.py pdf --spec klienci/<klient>/brandbook/brandbook.json [--wyjscie ...pdf]
     -> Brandbook_<marka>.pdf (strony 16:9), podgląd stron PNG i karta_klienta.json (do wklejenia w Studio)

brandbook.json (pisze Claude po przejrzeniu strony i materiałów):
{"marka": "Emerald Media", "haslo": "...", "opis": "...", "wartosci": ["..."], "ton": ["..."], "grupa": "...",
 "logo": [{"plik": "klienci/x/logo/logo.png", "opis": "Wersja podstawowa", "tlo": "#FFFFFF"}],
 "logo_zasady": ["..."], "logo_zakazy": ["..."],
 "kolory": [{"nazwa": "Szmaragd", "hex": "#0F7B5F", "rola": "Kolor główny", "opis": "tła, duże plamy"}],
 "fonty": [{"nazwa": "Montserrat", "rola": "Nagłówki", "waga": 800}, {"nazwa": "Inter", "rola": "Tekst", "waga": 400}],
 "zdjecia": "styl zdjęć", "przyklady": ["ścieżki do obrazów"],
 "zastosowania": [{"naglowek": "Nagłówek z *wyróżnieniem*", "podtytul": "...", "cta": "...", "tlo": "opcjonalnie zdjęcie"}],
 "zakazy": ["..."], "cta": "domyślne CTA", "kontakt": "www, e-mail"}
"""
import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path
from urllib.parse import urljoin, urlparse

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, postep, wynik  # noqa: E402
import fonty  # noqa: E402

UA = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126 Safari/537.36"}


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


# ---------- strona ----------
def hex6(c):
    c = c.lower()
    if c.startswith("#"):
        h = c[1:]
        if len(h) in (3, 4):
            h = "".join(x * 2 for x in h[:3])
        return "#" + h[:6].upper() if len(h) >= 6 else None
    m = re.match(r"rgba?\(\s*(\d+)[ ,]+(\d+)[ ,]+(\d+)", c)
    if m:
        return "#" + "".join(f"{min(255, int(x)):02X}" for x in m.groups())
    return None


def strona(url, folder):
    import requests
    folder = sciezka(folder)
    folder.mkdir(parents=True, exist_ok=True)
    postep(f"Pobieram {url}")
    r = requests.get(url, headers=UA, timeout=40)
    if r.status_code >= 400:
        blad(f"Strona odpowiedziała {r.status_code}")
    if "charset" not in r.headers.get("content-type", "").lower():
        r.encoding = "utf-8"
    html = r.text
    css = "\n".join(re.findall(r"<style[^>]*>(.*?)</style>", html, flags=re.S | re.I))
    css += "\n" + " ".join(re.findall(r'style="([^"]*)"', html))
    linki = re.findall(r'<link[^>]+rel=["\']?stylesheet["\']?[^>]*>', html, flags=re.I)
    for l in linki[:12]:
        m = re.search(r'href=["\']([^"\']+)', l)
        if not m:
            continue
        try:
            cr = requests.get(urljoin(url, m.group(1)), headers=UA, timeout=30)
            cr.encoding = cr.encoding if "charset" in cr.headers.get("content-type", "").lower() else "utf-8"
            if cr.ok and len(cr.text) < 3_000_000:
                css += "\n" + cr.text
        except Exception:
            pass
    kolory = Counter()
    for c in re.findall(r"#[0-9a-fA-F]{3,8}\b|rgba?\([^)]*\)", css):
        h = hex6(c)
        if h:
            kolory[h] += 1
    zmienne = {k: hex6(v) for k, v in re.findall(r"(--[\w-]+)\s*:\s*(#[0-9a-fA-F]{3,8}|rgba?\([^)]*\))", css) if hex6(v)}
    fonty_css = Counter(f.strip().strip("'\"") for dek in re.findall(r"font-family\s*:\s*([^;}{]+)", css) for f in dek.split(",")[:1])
    google = sorted({unquote_plus(f).split(":")[0] for u in re.findall(r"fonts\.googleapis\.com/css2?\?[^\"'<>\s)]+", html + css)
                     for f in re.findall(r"family=([^&]+)", u.replace("&amp;", "&"))})
    # logo: obrazki z „logo” w adresie/alt/klasie, ikony, og:image, wbudowane SVG
    kand = []
    for tag in re.findall(r"<img[^>]+>", html, flags=re.I):
        if re.search(r"logo|brand|sygnet", tag, flags=re.I):
            m = re.search(r'src=["\']([^"\']+)', tag)
            if m:
                kand.append(urljoin(url, m.group(1)))
    for rel in ("apple-touch-icon", "icon", "shortcut icon"):
        for tag in re.findall(rf'<link[^>]+rel=["\'][^"\']*{rel}[^"\']*["\'][^>]*>', html, flags=re.I):
            m = re.search(r'href=["\']([^"\']+)', tag)
            if m:
                kand.append(urljoin(url, m.group(1)))
    m = re.search(r'<meta[^>]+property=["\']og:image["\'][^>]+content=["\']([^"\']+)', html, flags=re.I)
    if m:
        kand.append(urljoin(url, m.group(1)))
    pobrane = []
    for i, u in enumerate(dict.fromkeys(kand)):
        try:
            rr = requests.get(u, headers=UA, timeout=30)
            if not rr.ok:
                continue
            ext = Path(urlparse(u).path).suffix.lower() or ".png"
            if ext not in (".png", ".svg", ".jpg", ".jpeg", ".webp", ".ico", ".gif"):
                ext = ".png"
            cel = folder / f"logo_kandydat_{i + 1}{ext}"
            cel.write_bytes(rr.content)
            pobrane.append(str(cel))
        except Exception:
            pass
    for i, svg in enumerate(re.findall(r"<svg[^>]*(?:logo|brand)[^>]*>.*?</svg>", html, flags=re.S | re.I)[:3]):
        cel = folder / f"logo_svg_{i + 1}.svg"
        cel.write_text(svg, encoding="utf-8")
        pobrane.append(str(cel))
    tekst = re.sub(r"<(script|style|noscript)[^>]*>.*?</\1>", " ", html, flags=re.S | re.I)
    tytul = (re.search(r"<title[^>]*>(.*?)</title>", html, flags=re.S | re.I) or [None, ""])[1].strip()
    opis = (re.search(r'<meta[^>]+name=["\']description["\'][^>]+content=["\']([^"\']*)', html, flags=re.I) or [None, ""])[1]
    naglowki = [re.sub(r"<[^>]+>", "", h).strip() for h in re.findall(r"<h[1-3][^>]*>(.*?)</h[1-3]>", tekst, flags=re.S | re.I)]
    akapity = [re.sub(r"\s+", " ", re.sub(r"<[^>]+>", "", p)).strip() for p in re.findall(r"<p[^>]*>(.*?)</p>", tekst, flags=re.S | re.I)]
    (folder / "strona.txt").write_text(f"{url}\nTytuł: {tytul}\nOpis: {opis}\n\nNagłówki:\n" + "\n".join(h for h in naglowki if h)[:3000] +
                                       "\n\nTeksty:\n" + "\n".join(p for p in akapity if len(p) > 40)[:6000], encoding="utf-8")
    wynik(url=url, tytul=tytul, opis=opis, kolory=[{"hex": k, "uzyc": v} for k, v in kolory.most_common(16)],
          zmienne_css=dict(list(zmienne.items())[:30]), fonty=[f for f, _ in fonty_css.most_common(8)], google_fonts=google,
          logo=pobrane, teksty=str(folder / "strona.txt"))


def unquote_plus(x):
    from urllib.parse import unquote_plus as u
    return u(x)


# ---------- PDF ----------
W, H = 1920, 1080


def rgb(h, dom=(20, 20, 20)):
    h = (h or "").lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) if len(h) >= 6 else dom


def jasny(c):
    return (c[0] * 299 + c[1] * 587 + c[2] * 114) / 1000 > 150


def cmyk(c):
    r, g, b = [x / 255 for x in c]
    k = 1 - max(r, g, b)
    if k >= 1:
        return (0, 0, 0, 100)
    return tuple(round(100 * x) for x in ((1 - r - k) / (1 - k), (1 - g - k) / (1 - k), (1 - b - k) / (1 - k), k))


class Strony:
    def __init__(self, spec):
        self.s = spec
        f = spec.get("fonty") or []
        nag = next((x for x in f if "nag" in (x.get("rola", "").lower())), f[0] if f else {"nazwa": "Montserrat", "waga": 800})
        tek = next((x for x in f if "tek" in (x.get("rola", "").lower())), f[-1] if f else {"nazwa": "Inter", "waga": 400})
        self.f_nag = fonty.znajdz_wage(nag.get("nazwa"), int(nag.get("waga", 800)))[0]
        self.f_tek = fonty.znajdz_wage(tek.get("nazwa"), int(tek.get("waga", 400)))[0]
        self.f_tek_g = fonty.znajdz_wage(tek.get("nazwa"), 700)[0]
        kol = spec.get("kolory") or [{"hex": "#111827"}]
        self.glowny = rgb(kol[0]["hex"])
        self.akcent = rgb(kol[1]["hex"]) if len(kol) > 1 else self.glowny
        self.ciemny = next((rgb(k["hex"]) for k in kol if not jasny(rgb(k["hex"]))), (20, 24, 32))
        self.lista = []

    def font(self, plik, r):
        from PIL import ImageFont
        return ImageFont.truetype(plik, int(r)) if plik else ImageFont.load_default()

    def nowa(self, tytul=None, tlo=(250, 250, 248)):
        from PIL import Image, ImageDraw
        img = Image.new("RGB", (W, H), tlo)
        d = ImageDraw.Draw(img)
        if tytul:
            d.rectangle([0, 0, 18, H], fill=self.glowny)
            d.text((120, 90), tytul, font=self.font(self.f_nag, 64), fill=self.ciemny)
            d.text((W - 120, 100), f"{self.s.get('marka', '')} · Brandbook", font=self.font(self.f_tek, 22), fill=(130, 130, 130), anchor="ra")
            d.text((W - 120, H - 70), str(len(self.lista) + 1), font=self.font(self.f_tek, 22), fill=(130, 130, 130), anchor="ra")
        self.lista.append(img)
        return img, d

    def akapit(self, d, xy, tekst, font, max_w, kolor=(40, 40, 40), odst=1.4):
        x, y = xy
        for para in str(tekst).split("\n"):
            linia = ""
            for slowo in para.split():
                proba = (linia + " " + slowo).strip()
                if d.textlength(proba, font=font) > max_w and linia:
                    d.text((x, y), linia, font=font, fill=kolor)
                    y += font.size * odst
                    linia = slowo
                else:
                    linia = proba
            if linia:
                d.text((x, y), linia, font=font, fill=kolor)
                y += font.size * odst
        return y

    def punkty(self, d, xy, lista, font, max_w, kolor=(40, 40, 40), znak="•"):
        x, y = xy
        for p in lista or []:
            d.text((x, y), znak, font=font, fill=self.akcent if not jasny(self.akcent) else self.glowny)
            y = self.akapit(d, (x + 34, y), p, font, max_w - 34, kolor) + font.size * 0.4
        return y

    def obraz(self, img, plik, box, tlo=None):
        from PIL import Image, ImageDraw
        x0, y0, x1, y1 = box
        if tlo:
            ImageDraw.Draw(img).rounded_rectangle(box, 18, fill=rgb(tlo))
        p = sciezka(plik)
        if not p.exists():
            return
        if p.suffix.lower() == ".svg":
            try:
                import cairosvg
                import io
                im = Image.open(io.BytesIO(cairosvg.svg2png(url=str(p), output_width=800))).convert("RGBA")
            except Exception:
                ImageDraw.Draw(img).text((x0 + 20, y0 + 20), f"[SVG: {p.name}]", fill=(120, 120, 120))
                return
        else:
            im = Image.open(p).convert("RGBA")
        pad = 0.18 if tlo else 0.0
        bw, bh = (x1 - x0) * (1 - 2 * pad), (y1 - y0) * (1 - 2 * pad)
        s = min(bw / im.width, bh / im.height)
        im = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)
        img.paste(im, (int(x0 + (x1 - x0 - im.width) / 2), int(y0 + (y1 - y0 - im.height) / 2)), im)

    # ---- strony ----
    def okladka(self):
        img, d = self.nowa(tlo=self.glowny)
        loga = self.s.get("logo") or []
        lg = next((l for l in loga if l.get("tlo") and rgb(l["tlo"]) == self.glowny), None) or \
            next((l for l in loga if l.get("tlo") and jasny(rgb(l["tlo"])) == jasny(self.glowny)), None) or (loga[0] if loga else None)
        if lg:
            self.obraz(img, lg["plik"], (W / 2 - 420, 260, W / 2 + 420, 620))
        kol = (20, 20, 20) if jasny(self.glowny) else (255, 255, 255)
        d.text((W / 2, 700), self.s.get("marka", ""), font=self.font(self.f_nag, 96), fill=kol, anchor="ma")
        d.text((W / 2, 830), "Brandbook", font=self.font(self.f_tek, 40), fill=kol, anchor="ma")
        if self.s.get("haslo"):
            d.text((W / 2, 900), self.s["haslo"], font=self.font(self.f_tek, 30), fill=kol, anchor="ma")

    def o_marce(self):
        img, d = self.nowa("O marce")
        y = self.akapit(d, (120, 210), self.s.get("opis", ""), self.font(self.f_tek, 34), 980, odst=1.5)
        if self.s.get("grupa"):
            d.text((120, y + 30), "Dla kogo", font=self.font(self.f_tek_g, 30), fill=self.ciemny)
            self.akapit(d, (120, y + 80), self.s["grupa"], self.font(self.f_tek, 28), 980)
        if self.s.get("zdjecia") and not [p for p in self.s.get("przyklady") or [] if sciezka(p).exists()]:
            d.text((120, 760), "Styl zdjęć", font=self.font(self.f_tek_g, 30), fill=self.ciemny)
            self.akapit(d, (120, 810), self.s["zdjecia"], self.font(self.f_tek, 28), 980)
        d.text((1220, 210), "Wartości", font=self.font(self.f_tek_g, 30), fill=self.ciemny)
        y2 = self.punkty(d, (1220, 265), self.s.get("wartosci"), self.font(self.f_tek, 28), 580)
        d.text((1220, y2 + 30), "Ton komunikacji", font=self.font(self.f_tek_g, 30), fill=self.ciemny)
        self.punkty(d, (1220, y2 + 85), self.s.get("ton"), self.font(self.f_tek, 28), 580)

    def logo(self):
        loga = self.s.get("logo") or []
        if not loga:
            return
        img, d = self.nowa("Logo")
        n = min(len(loga), 4)
        szer = (W - 240 - (n - 1) * 30) / n
        for i, l in enumerate(loga[:4]):
            x0 = 120 + i * (szer + 30)
            self.obraz(img, l["plik"], (x0, 200, x0 + szer, 560), l.get("tlo") or "#FFFFFF")
            if (l.get("tlo") or "#FFFFFF").upper() in ("#FFFFFF", "#FAFAFA", "#FAFAF8"):
                d.rounded_rectangle((x0, 200, x0 + szer, 560), 18, outline=(220, 220, 220), width=2)
            self.akapit(d, (x0, 580), l.get("opis", ""), self.font(self.f_tek, 24), szer, (90, 90, 90))
        d.text((120, 690), "Zasady", font=self.font(self.f_tek_g, 30), fill=self.ciemny)
        self.punkty(d, (120, 745), self.s.get("logo_zasady"), self.font(self.f_tek, 26), 800)
        d.text((1000, 690), "Nie wolno", font=self.font(self.f_tek_g, 30), fill=(190, 40, 40))
        self.punkty(d, (1000, 745), self.s.get("logo_zakazy"), self.font(self.f_tek, 26), 800, znak="×")

    def kolory(self):
        kol = self.s.get("kolory") or []
        if not kol:
            return
        img, d = self.nowa("Kolory")
        n = min(len(kol), 6)
        szer = (W - 240 - (n - 1) * 24) / n
        for i, k in enumerate(kol[:6]):
            c = rgb(k["hex"])
            x0 = 120 + i * (szer + 24)
            d.rounded_rectangle((x0, 210, x0 + szer, 600), 20, fill=c, outline=(225, 225, 225) if jasny(c) else None, width=2)
            t = (20, 20, 20) if jasny(c) else (255, 255, 255)
            d.text((x0 + 26, 540), k.get("nazwa", ""), font=self.font(self.f_tek_g, 28), fill=t)
            f = self.font(self.f_tek, 24)
            d.text((x0, 630), k.get("rola", ""), font=self.font(self.f_tek_g, 26), fill=self.ciemny)
            d.text((x0, 675), f"HEX  {k['hex'].upper()}", font=f, fill=(60, 60, 60))
            d.text((x0, 710), f"RGB  {c[0]} {c[1]} {c[2]}", font=f, fill=(60, 60, 60))
            d.text((x0, 745), "CMYK {} {} {} {}".format(*cmyk(c)), font=f, fill=(60, 60, 60))
            self.akapit(d, (x0, 795), k.get("opis", ""), self.font(self.f_tek, 22), szer, (110, 110, 110))

    def typografia(self):
        f = self.s.get("fonty") or []
        if not f:
            return
        img, d = self.nowa("Typografia")
        n = min(len(f), 3)
        szer = (W - 240 - (n - 1) * 60) / n
        for i, x in enumerate(f[:3]):
            plik = fonty.znajdz_wage(x.get("nazwa"), int(x.get("waga", 400)))[0]
            x0 = 120 + i * (szer + 60)
            d.text((x0, 200), x.get("rola", ""), font=self.font(self.f_tek, 26), fill=(120, 120, 120))
            d.text((x0, 240), f"{x.get('nazwa')} {x.get('waga', '')}", font=self.font(self.f_tek_g, 34), fill=self.ciemny)
            d.text((x0, 300), "Aa", font=self.font(plik, 220), fill=self.glowny if not jasny(self.glowny) else self.ciemny)
            self.akapit(d, (x0, 580), "AĄBCĆDEĘFGHIJKLŁMNŃOÓPRSŚTUWYZŹŻ\naąbcćdeęfghijklłmnńoóprsśtuwyzźż\n0123456789 !?%&@", self.font(plik, 30), szer, (50, 50, 50))
            self.akapit(d, (x0, 800), "Zażółć gęślą jaźń. Szybki brązowy lis przeskoczył nad leniwym psem.", self.font(plik, 28), szer, (80, 80, 80))

    def zdjecia(self):
        prz = [p for p in self.s.get("przyklady") or [] if sciezka(p).exists()]
        if not prz:
            return
        img, d = self.nowa("Styl zdjęć i grafik")
        y = self.akapit(d, (120, 200), self.s.get("zdjecia", ""), self.font(self.f_tek, 30), W - 240)
        n = min(len(prz), 4)
        if n:
            szer = (W - 240 - (n - 1) * 24) / n
            for i, p in enumerate(prz[:4]):
                x0 = 120 + i * (szer + 24)
                self.obraz(img, p, (x0, y + 40, x0 + szer, H - 140), "#EEEEEE")

    def zastosowania(self):
        zast = self.s.get("zastosowania") or []
        if not zast:
            return
        import tempfile
        import grafika
        img, d = self.nowa("Przykłady zastosowania")
        kol = self.s.get("kolory") or []
        role = {"primary": kol[0]["hex"] if kol else "#111827", "accent": kol[1]["hex"] if len(kol) > 1 else "#22C55E",
                "text": "#FFFFFF", "highlight": kol[1]["hex"] if len(kol) > 1 else "#22C55E"}
        f = self.s.get("fonty") or [{"nazwa": "Montserrat"}]
        logo = next((l["plik"] for l in self.s.get("logo") or [] if l.get("tlo") and not jasny(rgb(l["tlo"]))), None)
        tmp = Path(tempfile.mkdtemp())
        n = min(len(zast), 3)
        szer = (W - 240 - (n - 1) * 40) / n
        for i, z in enumerate(zast[:3]):
            spec = {"naglowek": z.get("naglowek", ""), "podtytul": z.get("podtytul", ""), "cta": z.get("cta", self.s.get("cta", "")),
                    "tlo": z.get("tlo"), "kolory": role, "font": f[0].get("nazwa"), "font_tekstu": f[-1].get("nazwa"), "logo": logo}
            for x in f:  # fonty marki do grafik
                fonty.znajdz_wage(x.get("nazwa"), int(x.get("waga", 700)))
            spec["folder_klienta"] = None
            plik, _, _ = grafika.renderuj(spec, 1080, 1350, tmp / f"p{i}.png")
            x0 = 120 + i * (szer + 40)
            self.obraz(img, plik, (x0, 190, x0 + szer, H - 120))

    def zakazy(self):
        if not self.s.get("zakazy"):
            return
        img, d = self.nowa("Czego unikać")
        self.punkty(d, (120, 210), self.s["zakazy"], self.font(self.f_tek, 32), W - 240, znak="×")
        if self.s.get("kontakt"):
            d.text((120, H - 150), self.s["kontakt"], font=self.font(self.f_tek, 28), fill=(110, 110, 110))


def pdf(spec_plik, wyjscie=None):
    spec_plik = sciezka(spec_plik)
    s = json.loads(spec_plik.read_text(encoding="utf-8"))
    st = Strony(s)
    for etap in ("okladka", "o_marce", "logo", "kolory", "typografia", "zdjecia", "zastosowania", "zakazy"):
        postep(f"Strona: {etap}")
        getattr(st, etap)()
    nazwa = re.sub(r"[^\w\-]+", "_", s.get("marka", "marka")).strip("_")
    cel = sciezka(wyjscie) if wyjscie else spec_plik.parent / f"Brandbook_{nazwa}.pdf"
    st.lista[0].save(cel, save_all=True, append_images=st.lista[1:], resolution=150)
    podglad = spec_plik.parent / "_strony"
    podglad.mkdir(exist_ok=True)
    for i, im in enumerate(st.lista, 1):
        im.resize((960, 540)).save(podglad / f"strona_{i:02d}.jpg", quality=85)
    kol = s.get("kolory") or []
    f = s.get("fonty") or []
    karta = {"name": s.get("marka", ""), "paleta": [k["hex"].upper() for k in kol],
             "koloryUwagi": "; ".join(f"{k.get('nazwa')} {k['hex'].upper()}: {k.get('rola', '')}" for k in kol)[:300],
             "fonts": {"heading": f[0]["nazwa"] if f else "", "body": f[-1]["nazwa"] if f else ""},
             "tone": "; ".join(s.get("ton") or []), "audience": s.get("grupa", ""), "cta": s.get("cta", ""),
             "notes": "; ".join(s.get("zakazy") or [])}
    (spec_plik.parent / "karta_klienta.json").write_text(json.dumps(karta, ensure_ascii=False), encoding="utf-8")
    wynik(pdf=str(cel), stron=len(st.lista), podglad=str(podglad), karta_klienta=json.dumps(karta, ensure_ascii=False))


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Brandbook")
    sub = p.add_subparsers(dest="tryb", required=True)
    a1 = sub.add_parser("strona"); a1.add_argument("--url", required=True); a1.add_argument("--folder", required=True)
    a2 = sub.add_parser("pdf"); a2.add_argument("--spec", required=True); a2.add_argument("--wyjscie")
    a = p.parse_args()
    strona(a.url, a.folder) if a.tryb == "strona" else pdf(a.spec, a.wyjscie)
