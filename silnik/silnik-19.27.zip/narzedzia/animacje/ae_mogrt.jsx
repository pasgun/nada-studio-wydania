﻿/* Studio Nadamedia: animacja z panelu jako szablon .mogrt do Premiere, który się rozciąga.
 * Panel renderuje animację do MOV, a ten skrypt (uruchamiany w After Effects w tle) wkłada ją do kompozycji
 * z dwoma chronionymi fragmentami (wejście na początku, wyjście na końcu) i zapisuje jako .mogrt.
 * W Premiere ciągniesz koniec klipu: chronione fragmenty mają stałą długość, rozciąga się tylko środek.
 *
 *   NM_AE_MOGRT({ plik: "C:/.../anim.mov", mogrt: "C:/.../anim.mogrt", nazwa, W, H, fps, czas, wejscie, wyjscie, wynik, log })
 * Wynik trafia do pliku opcje.wynik: "ok|<ścieżka .mogrt>" albo "blad|<opis>".
 * Do projektu, który masz otwarty w AE, nic nie zostaje: kompozycja i plik są usuwane po zapisaniu .mogrt.
 */
function nm_mg_zapisz(sciezka, tekst, dopisz) {
    if (!sciezka) return;
    try { var f = new File(sciezka); f.encoding = "UTF-8"; f.open(dopisz ? "a" : "w"); f.write(tekst); f.close(); } catch (e) {}
}
function NM_AE_MOGRT(o) {
    var komp = null, film = null, folder = null;
    try {
        if (!app.project) app.newProject();
        // AE zapisuje .mogrt tylko z zapisanego projektu; nowy, pusty projekt zapisujemy obok animacji
        if (!app.project.file) {
            var aep = new File(String(o.mogrt).replace(/\.mogrt$/i, "_mogrt.aep"));
            app.project.save(aep);
        }
        folder = app.project.items.addFolder("Nada Studio – mogrt (tymczasowe)");
        film = app.project.importFile(new ImportOptions(new File(o.plik)));
        film.parentFolder = folder;
        var czas = Number(o.czas) || film.duration, fps = Number(o.fps) || film.frameRate || 30;
        komp = app.project.items.addComp(o.nazwa, Number(o.W) || film.width, Number(o.H) || film.height, 1, czas, fps);
        komp.parentFolder = folder;
        var l = komp.layers.add(film);
        l.startTime = 0;
        var we = Math.max(0, Math.min(Number(o.wejscie) || 0, czas - 0.05)), wy = Math.max(0, Math.min(Number(o.wyjscie) || 0, czas - we - 0.05));
        if (we > 0) {
            var m1 = new MarkerValue("Wejście (stała długość)"); m1.duration = we; m1.protectedRegion = true;
            komp.markerProperty.setValueAtTime(0, m1);
        }
        if (wy > 0) {
            var m2 = new MarkerValue("Wyjście (stała długość)"); m2.duration = wy; m2.protectedRegion = true;
            komp.markerProperty.setValueAtTime(czas - wy, m2);
        }
        try { komp.motionGraphicsTemplateName = o.nazwa; } catch (eN) {}
        var ok = komp.exportAsMotionGraphicsTemplate(true, o.mogrt);
        if (!ok || !new File(o.mogrt).exists) throw new Error("After Effects nie zapisał pliku .mogrt (" + o.mogrt + ")");
        try { komp.remove(); film.remove(); folder.remove(); } catch (eU) {}
        nm_mg_zapisz(o.wynik, "ok|" + new File(o.mogrt).fsName, false);
        return "ok";
    } catch (e) {
        try { if (komp) komp.remove(); if (film) film.remove(); if (folder) folder.remove(); } catch (e2) {}
        var b = "blad|" + e.toString() + (e.line ? " (linia " + e.line + ")" : "");
        nm_mg_zapisz(o.log, new Date().toString() + " mogrt: " + b + "\n", true);
        nm_mg_zapisz(o.wynik, b, false);
        return b;
    }
}
