/* Biblioteka animacji Studio Nadamedia.
 *
 * Jedno źródło dla: panelu w Premiere (podgląd i render do MOV z przezroczystością), Studio (galeria z podglądem)
 * i silnika (node render.js, gdy Claude robi animacje sam).
 *
 * Każdy preset rysuje jedną klatkę: NMAnim.rysuj(ctx, idPresetu, t, parametry, W, H)
 *   t – czas w sekundach od początku animacji, W×H – rozmiar klatki.
 * Tło zostaje przezroczyste: rysowane są tylko elementy animacji.
 *
 * Parametry wspólne (wszystkie opcjonalne, domyślne w DOMYSLNE):
 *   tekst, tekst2, lista (linie albo „a; b; c”, w wykresach „etykieta:wartość”), liczba, od, przed, po,
 *   x, y, x2, y2 (0–1, punkt na kadrze dla strzałek, kółek, pinezek), emoji,
 *   kolor_glowny, kolor_akcent, kolor_tekstu, kolor_tla, font, waga, rozmiar (mnożnik), wielkie (WIELKIE LITERY),
 *   cien, pozycja (srodek, gora, dol, lewy-dol, lewy-gora, prawy-dol, prawy-gora), tempo (mnożnik szybkości wejścia),
 *   czas (s), wyjscie (s), wyjscie_styl (zanik, w-gore, w-dol, zoom, brak), logo (obraz, jeśli jest).
 * W tekście *gwiazdki* wyróżniają słowa kolorem akcentu.
 *
 * Własne presety (np. napisane przez Claude z opisu) dodaje się przez NMAnim.dodaj({...}) w plikach wlasne/*.js;
 * wzór na dole tego pliku (sekcja „Jak napisać preset”).
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.NMAnim = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  // ---------- matematyka i ruch ----------
  const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
  const lerp = (a, b, t) => a + (b - a) * t;
  const E = {
    lin: (t) => t,
    inCubic: (t) => t * t * t,
    outCubic: (t) => 1 - Math.pow(1 - t, 3),
    inOutCubic: (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2),
    outQuint: (t) => 1 - Math.pow(1 - t, 5),
    outExpo: (t) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t)),
    inExpo: (t) => (t <= 0 ? 0 : Math.pow(2, 10 * t - 10)),
    outBack: (t) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
    outBackMocno: (t) => { const c1 = 3, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
    inBack: (t) => { const c1 = 1.70158; return (c1 + 1) * t * t * t - c1 * t * t; },
    outElastic: (t) => (t <= 0 ? 0 : t >= 1 ? 1 : Math.pow(2, -10 * t) * Math.sin((t * 10 - 0.75) * (2 * Math.PI) / 3) + 1),
    outBounce: (t) => {
      const n = 7.5625, d = 2.75;
      if (t < 1 / d) return n * t * t;
      if (t < 2 / d) return n * (t -= 1.5 / d) * t + 0.75;
      if (t < 2.5 / d) return n * (t -= 2.25 / d) * t + 0.9375;
      return n * (t -= 2.625 / d) * t + 0.984375;
    },
  };
  const okno = (t, od, dl) => (dl <= 0 ? (t >= od ? 1 : 0) : clamp((t - od) / dl));
  const los = (n) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };

  // ---------- kolory ----------
  function rgb(hex) {
    let h = String(hex || "#000").replace("#", "").trim();
    if (h.length === 3) h = h.split("").map((c) => c + c).join("");
    const n = parseInt(h.slice(0, 6), 16) || 0;
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  const rgba = (hex, a) => { const [r, g, b] = rgb(hex); return `rgba(${r},${g},${b},${a})`; };
  const jasnosc = (hex) => { const [r, g, b] = rgb(hex); return (0.299 * r + 0.587 * g + 0.114 * b) / 255; };
  const kontrast = (hex) => (jasnosc(hex) > 0.6 ? "#111111" : "#FFFFFF");
  function ciemniej(hex, k) { const [r, g, b] = rgb(hex); const f = (v) => Math.round(v * (1 - k)); return `rgb(${f(r)},${f(g)},${f(b)})`; }

  // ---------- płótno pomocnicze (warstwy) ----------
  let fabryka = null;
  function nowyCanvas(w, h) {
    if (fabryka) return fabryka(w, h);
    if (typeof OffscreenCanvas !== "undefined") return new OffscreenCanvas(w, h);
    const c = document.createElement("canvas"); c.width = w; c.height = h; return c;
  }
  const bufory = {};
  function warstwa(s, nr, rysujFn) {
    const k = `${nr}_${s.W}x${s.H}`;
    let c = bufory[k];
    if (!c) c = bufory[k] = nowyCanvas(s.W, s.H);
    const x = c.getContext("2d");
    x.setTransform(1, 0, 0, 1, 0, 0);
    x.globalAlpha = 1;
    x.globalCompositeOperation = "source-over";
    x.clearRect(0, 0, s.W, s.H);
    rysujFn(x);
    return c;
  }

  // ---------- kształty ----------
  function zaokr(ctx, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, Math.abs(w) / 2, Math.abs(h) / 2));
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y); ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r); ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h); ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r); ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }
  function gwiazda(ctx, cx, cy, ramiona, r1, r2, obrot = 0) {
    ctx.beginPath();
    for (let i = 0; i < ramiona * 2; i++) {
      const r = i % 2 ? r2 : r1, a = obrot + (i * Math.PI) / ramiona - Math.PI / 2;
      i ? ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r) : ctx.moveTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
    }
    ctx.closePath();
  }
  function serce(ctx, cx, cy, r) {
    ctx.beginPath();
    ctx.moveTo(cx, cy + r * 0.9);
    ctx.bezierCurveTo(cx - r * 1.6, cy - r * 0.1, cx - r * 0.7, cy - r * 1.2, cx, cy - r * 0.45);
    ctx.bezierCurveTo(cx + r * 0.7, cy - r * 1.2, cx + r * 1.6, cy - r * 0.1, cx, cy + r * 0.9);
    ctx.closePath();
  }
  function kursor(ctx, x, y, sk, kolor = "#FFFFFF") {
    ctx.save(); ctx.translate(x, y); ctx.scale(sk, sk);
    ctx.beginPath();
    ctx.moveTo(0, 0); ctx.lineTo(0, 34); ctx.lineTo(9, 26); ctx.lineTo(15, 40); ctx.lineTo(21, 37); ctx.lineTo(15, 24); ctx.lineTo(26, 24);
    ctx.closePath();
    ctx.fillStyle = kolor; ctx.strokeStyle = "#111"; ctx.lineWidth = 2.5; ctx.lineJoin = "round";
    ctx.fill(); ctx.stroke(); ctx.restore();
  }
  function ptaszek(ctx, x, y, r, e, kolor, gr) {
    // znak „✓” rysowany od lewej do prawej, e = 0..1
    const p = [[x - r * 0.55, y], [x - r * 0.15, y + r * 0.42], [x + r * 0.6, y - r * 0.45]];
    const d1 = Math.hypot(p[1][0] - p[0][0], p[1][1] - p[0][1]), d2 = Math.hypot(p[2][0] - p[1][0], p[2][1] - p[1][1]);
    const L = (d1 + d2) * e;
    ctx.beginPath(); ctx.moveTo(...p[0]);
    if (L <= d1) ctx.lineTo(lerp(p[0][0], p[1][0], L / d1), lerp(p[0][1], p[1][1], L / d1));
    else { ctx.lineTo(...p[1]); const k = (L - d1) / d2; ctx.lineTo(lerp(p[1][0], p[2][0], k), lerp(p[1][1], p[2][1], k)); }
    ctx.strokeStyle = kolor; ctx.lineWidth = gr; ctx.lineCap = "round"; ctx.lineJoin = "round"; ctx.stroke();
  }
  // linia po punktach rysowana do ułamka e (do strzałek i tras)
  function sciezkaCzesc(ctx, pkt, e) {
    const dl = []; let suma = 0;
    for (let i = 1; i < pkt.length; i++) { const d = Math.hypot(pkt[i][0] - pkt[i - 1][0], pkt[i][1] - pkt[i - 1][1]); dl.push(d); suma += d; }
    let zostalo = suma * clamp(e); ctx.beginPath(); ctx.moveTo(...pkt[0]);
    let koniec = pkt[0], kier = 0;
    for (let i = 1; i < pkt.length; i++) {
      if (zostalo <= 0) break;
      const d = dl[i - 1], k = Math.min(1, zostalo / d);
      koniec = [lerp(pkt[i - 1][0], pkt[i][0], k), lerp(pkt[i - 1][1], pkt[i][1], k)];
      kier = Math.atan2(pkt[i][1] - pkt[i - 1][1], pkt[i][0] - pkt[i - 1][0]);
      ctx.lineTo(...koniec); zostalo -= d;
    }
    return { koniec, kier, suma };
  }
  function krzywa(a, b, c, n = 40) { // kwadratowa Béziera jako punkty
    const w = [];
    for (let i = 0; i <= n; i++) { const t = i / n; w.push([(1 - t) * (1 - t) * a[0] + 2 * (1 - t) * t * b[0] + t * t * c[0], (1 - t) * (1 - t) * a[1] + 2 * (1 - t) * t * b[1] + t * t * c[1]]); }
    return w;
  }

  // ---------- tekst ----------
  const FONT_ZAPAS = '"Segoe UI", "Helvetica Neue", Arial, sans-serif';
  const font = (s, px, waga) => `${s.p.kursywa ? "italic " : ""}${waga || s.p.waga} ${Math.max(1, Math.round(px))}px "${s.p.font}", ${FONT_ZAPAS}`;
  const tekstP = (s, t) => { t = String(t == null ? "" : t); return s.p.wielkie ? t.toLocaleUpperCase("pl") : t; };
  function slowaZ(t) {
    const w = []; let wyr = false;
    String(t).split(/\s+/).filter(Boolean).forEach((x) => {
      let start = false, kon = false;
      if (x.startsWith("*")) { start = true; x = x.slice(1); }
      if (x.endsWith("*") || x.match(/\*[.,!?:;…]+$/)) { kon = true; x = x.replace(/\*([.,!?:;…]*)$/, "$1"); }
      if (start) wyr = true;
      if (x) w.push({ t: x, wyr });
      if (kon) wyr = false;
    });
    return w;
  }
  /* Układ akapitu: słowa z pozycją (x lewej krawędzi, y środka linii), linie, rozmiar bloku. */
  function uloz(s, tekst, px, o = {}) {
    const ctx = s.ctx, waga = o.waga || s.p.waga;
    ctx.font = font(s, px, waga);
    const maxW = o.maxW || s.W * 0.84 * (s.p.szerokosc || 1), lh = (o.lh || 1.12) * px * (s.p.interlinia || 1), align = o.align || s.poz.align;
    const sp = ctx.measureText(" ").width;
    const linie = []; let lin = { slowa: [], w: 0 };
    // Enter w polu tekstu = nowa linia: wtedy linie są dokładnie takie, jak wpisane (bez samoczynnego łamania)
    const akapity = String(tekstP(s, tekst)).split(/\r?\n/), reczne = akapity.filter((x) => x.trim()).length > 1;
    akapity.forEach((ak, ai) => {
      if (ai > 0 && lin.slowa.length && !o.jednaLinia) { linie.push(lin); lin = { slowa: [], w: 0 }; }
      slowaZ(ak).forEach((sl) => {
        sl.w = ctx.measureText(sl.t).width;
        const nw = lin.slowa.length ? lin.w + sp + sl.w : sl.w;
        if (lin.slowa.length && nw > maxW && !o.jednaLinia && !reczne) { linie.push(lin); lin = { slowa: [], w: 0 }; lin.slowa.push(sl); lin.w = sl.w; }
        else { lin.slowa.push(sl); lin.w = nw; }
      });
    });
    if (lin.slowa.length) linie.push(lin);
    const x = o.x != null ? o.x : s.poz.x, y = o.y != null ? o.y : s.poz.y;
    const h = linie.length * lh, y0 = (o.gora ? y : y - h / 2) + lh / 2;
    const slowa = []; let i = 0;
    linie.forEach((l, li) => {
      let xx = align === "left" ? x : align === "right" ? x - l.w : x - l.w / 2;
      l.x0 = xx; l.y = y0 + li * lh;
      l.slowa.forEach((sl) => { sl.x = xx; sl.y = l.y; sl.i = i++; sl.li = li; slowa.push(sl); xx += sl.w + sp; });
    });
    const szer = Math.max(0, ...linie.map((l) => l.w));
    const lewa = align === "left" ? x : align === "right" ? x - szer : x - szer / 2;
    return { slowa, linie, px, lh, h, w: szer, x: lewa, y: y0 - lh / 2, waga, font: font(s, px, waga), sp };
  }
  /* Znaki z pozycją (do animacji litera po literze). */
  function znaki(s, ul) {
    const ctx = s.ctx; ctx.font = ul.font;
    const z = []; let i = 0;
    ul.slowa.forEach((sl) => {
      let pref = "";
      for (const c of Array.from(sl.t)) {
        const x = sl.x + ctx.measureText(pref).width, w = ctx.measureText(c).width;
        z.push({ c, x, y: sl.y, w, slowo: sl, i: i++ }); pref += c;
      }
    });
    return z;
  }
  /* Rozmiar fontu, przy którym tekst mieści się w jednej linii o szerokości maxW. */
  function dopasuj(s, tekst, px, maxW, waga) {
    s.ctx.font = font(s, px, waga);
    const w = s.ctx.measureText(tekstP(s, tekst)).width;
    return w > maxW ? px * maxW / w : px;
  }
  function cien(s, ctx = s.ctx, mocno = 1) {
    if (!s.p.cien) return;
    mocno *= s.p.cien_moc == null ? 1 : +s.p.cien_moc;
    ctx.shadowColor = rgba(s.p.kolor_cienia || "#000000", Math.min(1, 0.35 * mocno)); ctx.shadowBlur = 18 * s.u * mocno; ctx.shadowOffsetY = 5 * s.u * mocno;
  }
  const bezCienia = (ctx) => { ctx.shadowColor = "transparent"; ctx.shadowBlur = 0; ctx.shadowOffsetY = 0; ctx.shadowOffsetX = 0; };
  function piszSlowo(s, sl, kolor, ctx = s.ctx, dx = 0, dy = 0) {
    ctx.fillStyle = sl.wyr ? s.k.a : (kolor || s.k.t);
    ctx.fillText(sl.t, sl.x + dx, sl.y + dy);
  }
  function lista(t) {
    return String(t || "").split(/\n|;|\|/).map((x) => x.trim()).filter(Boolean);
  }
  function pary(t) {
    return lista(t).map((x) => { const m = x.match(/^(.*?)[:=]\s*(-?[\d.,]+)\s*$/); return m ? { e: m[1].trim(), v: parseFloat(m[2].replace(",", ".")) } : { e: x, v: 0 }; });
  }
  function liczbaTekst(v, miejsca = 0) {
    const t = Number(v).toFixed(miejsca);
    const [c, u] = t.split(".");
    return c.replace(/\B(?=(\d{3})+(?!\d))/g, " ") + (u ? "," + u : "");
  }
  function miejscaPo(v) { const t = String(v); return t.includes(".") ? Math.min(2, t.split(".")[1].length) : 0; }

  // ---------- pozycje ----------
  const POZYCJE = {
    srodek: [0.5, 0.5, "center"], gora: [0.5, 0.2, "center"], dol: [0.5, 0.74, "center"],
    "lewy-dol": [0.07, 0.8, "left"], "lewy-gora": [0.07, 0.14, "left"], "lewy-srodek": [0.07, 0.5, "left"],
    "prawy-dol": [0.93, 0.8, "right"], "prawy-gora": [0.93, 0.14, "right"],
  };

  // ---------- presety ----------
  const PRESETY = [];
  const KATEGORIE = [
    { id: "tekst", nazwa: "Napisy i tytuły" },
    { id: "belki", nazwa: "Belki z nazwiskiem" },
    { id: "rolki", nazwa: "Grafiki do rolek" },
    { id: "liczby", nazwa: "Liczby i wykresy" },
    { id: "cta", nazwa: "Wezwania do działania" },
    { id: "przejscia", nazwa: "Przejścia i akcenty" },
    { id: "wlasne", nazwa: "Własne" },
  ];
  function dodaj(p) {
    const i = PRESETY.findIndex((x) => x.id === p.id);
    if (i >= 0) PRESETY.splice(i, 1, p); else PRESETY.push(p);
    return p;
  }
  const DOMYSLNE = {
    tekst: "Twój tekst *tutaj*", tekst2: "", lista: "", liczba: 100, od: 0, przed: "", po: "", emoji: "🔥",
    x: 0.5, y: 0.5, x2: 0.78, y2: 0.3,
    kolor_glowny: "#FF6B2C", kolor_akcent: "#FFD23F", kolor_tekstu: "#FFFFFF", kolor_tla: "#141414",
    font: "Montserrat", waga: 800, rozmiar: 1, wielkie: false, cien: true, pozycja: null, tempo: 1,
    czas: null, wyjscie: 0.4, wyjscie_styl: "zanik", logo: null,
    // wspólne dla wszystkich presetów (panel: „Ruch i układ” i „Tekst”)
    kursywa: false, interlinia: 1, odstep: 0, szerokosc: 1, obrys: 0, kolor_obrysu: "#000000", cien_moc: 1, kolor_cienia: "#000000",
    przesun_x: 0, przesun_y: 0, obrot: 0, krycie: 1, opoznienie: 0, wejscie_styl: "",
  };

  // Teksty — wejście słowami / literami
  dodaj({ id: "pop-slowa", nazwa: "Słowa wyskakują", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "To *zmieni* wszystko" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      ul.slowa.forEach((w) => {
        const e = okno(s.t, w.i * 0.11 / s.p.tempo, 0.38 / s.p.tempo); if (e <= 0) return;
        const sc = E.outBackMocno(e);
        ctx.save(); ctx.translate(w.x + w.w / 2, w.y); ctx.scale(sc, sc); ctx.globalAlpha *= clamp(e * 3);
        cien(s); piszSlowo(s, w, null, ctx, -w.x - w.w / 2, -w.y); ctx.restore();
      });
    } });
  dodaj({ id: "maszyna", nazwa: "Maszyna do pisania", kat: "tekst", czas: 3.5, pola: ["tekst"], przyklad: { tekst: "Pisane na *żywo*…" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 90 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul);
      const ile = Math.floor(okno(s.t, 0.1, z.length * 0.055 / s.p.tempo) * z.length);
      ctx.font = ul.font; cien(s);
      z.slice(0, ile).forEach((c) => { ctx.fillStyle = c.slowo.wyr ? s.k.a : s.k.t; ctx.fillText(c.c, c.x, c.y); });
      const ost = z[Math.max(0, ile - 1)];
      if (ost && Math.floor(s.t * 2.2) % 2 === 0 || ile < z.length) {
        const x = ile ? ost.x + ost.w + 4 * s.u : z[0].x, y = ile ? ost.y : z[0].y;
        bezCienia(ctx); ctx.fillStyle = s.k.a; ctx.fillRect(x, y - ul.px * 0.42, 7 * s.u, ul.px * 0.84);
      }
    } });
  dodaj({ id: "maska-linie", nazwa: "Linie wysuwają się spod maski", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Nowy rozdział *zaczyna się* dziś" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 96 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      ul.linie.forEach((l, li) => {
        const e = E.outQuint(okno(s.t, li * 0.12 / s.p.tempo, 0.7 / s.p.tempo));
        ctx.save(); ctx.beginPath(); ctx.rect(0, l.y - ul.lh * 0.6, s.W, ul.lh * 1.2); ctx.clip();
        const dy = (1 - e) * ul.lh * 1.1;
        l.slowa.forEach((w) => piszSlowo(s, w, null, ctx, 0, dy)); ctx.restore();
      });
    } });
  dodaj({ id: "maska-slowa", nazwa: "Słowa wjeżdżają z dołu", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Krok po *kroku* do celu" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 96 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      ul.slowa.forEach((w) => {
        const e = E.outCubic(okno(s.t, w.i * 0.09 / s.p.tempo, 0.5 / s.p.tempo));
        ctx.save(); ctx.beginPath(); ctx.rect(w.x - 20 * s.u, w.y - ul.lh * 0.6, w.w + 40 * s.u, ul.lh * 1.2); ctx.clip();
        piszSlowo(s, w, null, ctx, 0, (1 - e) * ul.lh); ctx.restore();
      });
    } });
  dodaj({ id: "rozmycie", nazwa: "Wyostrzenie z rozmycia", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Skup się na *tym*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      ul.slowa.forEach((w) => {
        const e = E.outCubic(okno(s.t, w.i * 0.1 / s.p.tempo, 0.7 / s.p.tempo)); if (e <= 0) return;
        ctx.save(); ctx.globalAlpha *= e;
        const b = (1 - e) * 22 * s.u; if (b > 0.3) ctx.filter = `blur(${b.toFixed(1)}px)`;
        const sc = lerp(1.25, 1, e); ctx.translate(w.x + w.w / 2, w.y); ctx.scale(sc, sc);
        piszSlowo(s, w, null, ctx, -w.x - w.w / 2, -w.y); ctx.restore();
      });
    } });
  dodaj({ id: "sprezyna-litery", nazwa: "Litery podskakują", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Super *okazja*!" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 104 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul); ctx.font = ul.font; cien(s);
      z.forEach((c) => {
        const e = okno(s.t, c.i * 0.028 / s.p.tempo, 0.5 / s.p.tempo); if (e <= 0) return;
        ctx.save(); ctx.globalAlpha *= clamp(e * 2.5);
        ctx.fillStyle = c.slowo.wyr ? s.k.a : s.k.t; ctx.fillText(c.c, c.x, c.y + (1 - E.outBackMocno(e)) * ul.px * 0.9); ctx.restore();
      });
    } });
  dodaj({ id: "fala", nazwa: "Fala liter", kat: "tekst", czas: 4, pola: ["tekst"], przyklad: { tekst: "Lato w *pełni*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul); ctx.font = ul.font; cien(s);
      z.forEach((c) => {
        const e = okno(s.t, c.i * 0.03 / s.p.tempo, 0.35); if (e <= 0) return;
        ctx.globalAlpha = e * s.alfa; ctx.fillStyle = c.slowo.wyr ? s.k.a : s.k.t;
        ctx.fillText(c.c, c.x, c.y + Math.sin(s.t * 5 - c.i * 0.55) * 12 * s.u * s.p.rozmiar);
      });
      ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "glitch", nazwa: "Glitch", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "SYSTEM *ERROR*", wielkie: true },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 104 * s.u * s.p.rozmiar), ctx = s.ctx;
      const krok = Math.floor(s.t * 14), zaklocenie = s.t < 0.6 / s.p.tempo || (s.t % 1.6) < 0.14;
      const c = warstwa(s, "glitch", (x) => { x.font = ul.font; x.textBaseline = "middle"; ul.slowa.forEach((w) => piszSlowo(s, w, null, x)); });
      const o = zaklocenie ? (los(krok) - 0.5) * 26 * s.u : 0;
      if (zaklocenie) {
        const kan = warstwa(s, "glitch2", (x) => { x.drawImage(c, 0, 0); x.globalCompositeOperation = "source-in"; x.fillStyle = "#00E5FF"; x.fillRect(0, 0, s.W, s.H); });
        ctx.save(); ctx.globalAlpha *= 0.8; ctx.drawImage(kan, o, 0); ctx.restore();
        const kan2 = warstwa(s, "glitch3", (x) => { x.drawImage(c, 0, 0); x.globalCompositeOperation = "source-in"; x.fillStyle = "#FF2E88"; x.fillRect(0, 0, s.W, s.H); });
        ctx.save(); ctx.globalAlpha *= 0.8; ctx.drawImage(kan2, -o, 0); ctx.restore();
        const y0 = ul.y, h = ul.h;
        for (let i = 0; i < 6; i++) {
          const yy = y0 + los(krok * 7 + i) * h, hh = (0.05 + los(krok + i * 3) * 0.12) * h, dx = (los(krok * 3 + i) - 0.5) * 60 * s.u;
          ctx.drawImage(c, 0, yy, s.W, hh, dx, yy, s.W, hh);
        }
        ctx.save(); ctx.globalAlpha *= 0.5; ctx.drawImage(c, 0, 0); ctx.restore();
      } else ctx.drawImage(c, 0, 0);
    } });
  dodaj({ id: "zakreslacz", nazwa: "Zakreślacz", kat: "tekst", czas: 3.5, pola: ["tekst"], przyklad: { tekst: "To jest *najważniejsze*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 96 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      const wej = E.outCubic(okno(s.t, 0, 0.45 / s.p.tempo));
      let cel = ul.slowa.filter((w) => w.wyr); if (!cel.length) cel = ul.linie[ul.linie.length - 1].slowa;
      const e = E.inOutCubic(okno(s.t, 0.45 / s.p.tempo, 0.55 / s.p.tempo));
      const grupy = {}; cel.forEach((w) => (grupy[w.li] = grupy[w.li] || []).push(w));
      Object.values(grupy).forEach((g) => {
        const x0 = g[0].x - 14 * s.u, x1 = g[g.length - 1].x + g[g.length - 1].w + 14 * s.u;
        ctx.save(); ctx.fillStyle = s.k.a; ctx.translate(0, g[0].y); ctx.transform(1, 0, -0.12, 1, 0, 0);
        zaokr(ctx, x0, -ul.px * 0.42, (x1 - x0) * e, ul.px * 0.86, 8 * s.u); ctx.fill(); ctx.restore();
      });
      ctx.globalAlpha = s.alfa * wej;
      ul.slowa.forEach((w) => {
        const pod = cel.includes(w);
        ctx.fillStyle = pod && e > 0.5 ? kontrast(s.k.a) : s.k.t;
        ctx.fillText(w.t, w.x, w.y + (1 - wej) * 30 * s.u);
      });
      ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "odkrycie-blokiem", nazwa: "Odkrycie blokiem", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Premiera *już jutro*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 96 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      ul.linie.forEach((l, li) => {
        const d = li * 0.12 / s.p.tempo, a = E.inOutCubic(okno(s.t, d, 0.4 / s.p.tempo)), b = E.inOutCubic(okno(s.t, d + 0.4 / s.p.tempo, 0.4 / s.p.tempo));
        const pad = 12 * s.u, x0 = l.x0 - pad, w = l.w + pad * 2, y = l.y - ul.lh * 0.5;
        if (b > 0) l.slowa.forEach((w2) => piszSlowo(s, w2));
        ctx.fillStyle = li % 2 ? s.k.a : s.k.g;
        const lewo = x0 + w * b, prawo = x0 + w * a;
        if (prawo > lewo) ctx.fillRect(lewo, y, prawo - lewo, ul.lh);
      });
    } });
  dodaj({ id: "podkreslenie", nazwa: "Podkreślenie", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Zapamiętaj *to*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 96 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      const e = E.outCubic(okno(s.t, 0, 0.5 / s.p.tempo)), l = E.inOutCubic(okno(s.t, 0.35 / s.p.tempo, 0.6 / s.p.tempo));
      ctx.globalAlpha = s.alfa * e; cien(s); ul.slowa.forEach((w) => piszSlowo(s, w, null, ctx, 0, (1 - e) * 24 * s.u)); bezCienia(ctx);
      ctx.globalAlpha = s.alfa;
      const ost = ul.linie[ul.linie.length - 1], y = ost.y + ul.px * 0.62;
      ctx.strokeStyle = s.k.a; ctx.lineWidth = 10 * s.u * s.p.rozmiar; ctx.lineCap = "round";
      ctx.beginPath(); ctx.moveTo(ul.x, y); ctx.lineTo(ul.x + ul.w * l, y); ctx.stroke();
    } });
  dodaj({ id: "stos-slow", nazwa: "Stos słów", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Mniej gadania *więcej* robienia", wielkie: true },
    rysuj(s) {
      const ctx = s.ctx, sl = slowaZ(tekstP(s, s.p.tekst)); if (!sl.length) return;
      const px0 = 150 * s.u * s.p.rozmiar, maxW = s.W * 0.8;
      const rozm = sl.map((w) => dopasuj(s, w.t, px0, maxW));
      const lh = rozm.map((r) => r * 0.98), h = lh.reduce((a, b) => a + b, 0);
      let y = s.poz.y - h / 2;
      sl.forEach((w, i) => {
        const e = okno(s.t, i * 0.16 / s.p.tempo, 0.3 / s.p.tempo); y += lh[i] / 2;
        if (e > 0) {
          ctx.save(); ctx.font = font(s, rozm[i], 900); const sz = ctx.measureText(w.t).width;
          const x = s.poz.align === "left" ? s.poz.x : s.poz.align === "right" ? s.poz.x - sz : s.poz.x - sz / 2;
          const sc = lerp(1.7, 1, E.outExpo(e)); ctx.translate(x + sz / 2, y); ctx.scale(sc, sc); ctx.globalAlpha *= clamp(e * 2);
          cien(s); ctx.fillStyle = w.wyr ? s.k.a : i % 2 ? s.k.t : s.k.t; ctx.fillText(w.t, -sz / 2, 0); ctx.restore();
        }
        y += lh[i] / 2;
      });
    } });
  dodaj({ id: "neon", nazwa: "Neon", kat: "tekst", czas: 3.5, pola: ["tekst"], przyklad: { tekst: "Open *late*", kolor_akcent: "#FF3CAC" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      const t = s.t * s.p.tempo, migot = t < 0.9 ? (los(Math.floor(t * 22)) > 0.45 ? 1 : 0.15) : 1;
      ctx.globalAlpha = s.alfa * migot; ctx.lineWidth = 3 * s.u; ctx.lineJoin = "round";
      ctx.shadowColor = s.k.a; ctx.shadowBlur = 34 * s.u * (0.8 + 0.2 * Math.sin(s.t * 6));
      ul.slowa.forEach((w) => { ctx.strokeStyle = s.k.a; ctx.strokeText(w.t, w.x, w.y); });
      ctx.shadowBlur = 12 * s.u; ul.slowa.forEach((w) => { ctx.fillStyle = "#FFFFFF"; ctx.fillText(w.t, w.x, w.y); });
      bezCienia(ctx); ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "blysk", nazwa: "Błysk przez tekst", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Edycja *premium*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx;
      const e = E.outCubic(okno(s.t, 0, 0.5 / s.p.tempo)), b = okno(s.t, 0.5 / s.p.tempo, 0.8 / s.p.tempo);
      const c = warstwa(s, "blysk", (x) => {
        x.font = ul.font; x.textBaseline = "middle"; ul.slowa.forEach((w) => piszSlowo(s, w, null, x));
        if (b > 0 && b < 1) {
          x.globalCompositeOperation = "source-atop";
          const sx = lerp(ul.x - ul.w * 0.4, ul.x + ul.w * 1.4, b), g = x.createLinearGradient(sx - 120 * s.u, 0, sx + 120 * s.u, 0);
          g.addColorStop(0, "rgba(255,255,255,0)"); g.addColorStop(0.5, "rgba(255,255,255,0.95)"); g.addColorStop(1, "rgba(255,255,255,0)");
          x.fillStyle = g; x.fillRect(0, 0, s.W, s.H);
        }
      });
      ctx.save(); ctx.globalAlpha *= e; ctx.translate(0, (1 - e) * 30 * s.u); cien(s); ctx.drawImage(c, 0, 0); ctx.restore();
    } });
  dodaj({ id: "rozstrzelenie", nazwa: "Litery zbiegają się", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "KOLEKCJA 2026", wielkie: true, waga: 600 },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 92 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul); ctx.font = ul.font;
      const e = E.outQuint(okno(s.t, 0, 1.2 / s.p.tempo)), cx = ul.x + ul.w / 2;
      ctx.globalAlpha = s.alfa * clamp(e * 1.5); cien(s);
      z.forEach((c) => { ctx.fillStyle = c.slowo.wyr ? s.k.a : s.k.t; ctx.fillText(c.c, cx + (c.x - cx) * (1 + (1 - e) * 0.7), c.y); });
      ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "uderzenie", nazwa: "Uderzenie z ekranu", kat: "tekst", czas: 2.5, pola: ["tekst"], przyklad: { tekst: "BOOM!", wielkie: true },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 130 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      const d = 0.35 / s.p.tempo, e = okno(s.t, 0, d), cx = ul.x + ul.w / 2, cy = ul.y + ul.h / 2;
      const drg = s.t > d && s.t < d + 0.25 ? (los(Math.floor(s.t * 60)) - 0.5) * 16 * s.u * (1 - (s.t - d) / 0.25) : 0;
      const rysujRaz = (sc, a) => { ctx.save(); ctx.globalAlpha *= a; ctx.translate(cx + drg, cy + drg * 0.6); ctx.scale(sc, sc); ctx.translate(-cx, -cy); ul.slowa.forEach((w) => piszSlowo(s, w)); ctx.restore(); };
      if (e < 1) { for (let i = 3; i >= 1; i--) rysujRaz(lerp(3, 1, E.inExpo(clamp(e - i * 0.06))), 0.15); }
      cien(s); rysujRaz(lerp(3, 1, E.inExpo(e)), clamp(e * 2.5)); bezCienia(ctx);
    } });
  dodaj({ id: "slowo-po-slowie", nazwa: "Słowo po słowie (rolki)", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Jedno słowo na *raz* robi robotę", wielkie: true },
    rysuj(s) {
      const ctx = s.ctx, sl = slowaZ(tekstP(s, s.p.tekst)); if (!sl.length) return;
      const dl = Math.max(0.2, (s.T - s.p.wyjscie) / sl.length), i = Math.min(sl.length - 1, Math.floor(s.t / dl)), w = sl[i];
      const e = okno(s.t - i * dl, 0, 0.16), px = dopasuj(s, w.t, 150 * s.u * s.p.rozmiar, s.W * 0.86, 900);
      ctx.font = font(s, px, 900); const sz = ctx.measureText(w.t).width;
      const x = s.poz.align === "left" ? s.poz.x : s.poz.align === "right" ? s.poz.x - sz : s.poz.x - sz / 2;
      ctx.save(); ctx.translate(x + sz / 2, s.poz.y); const sc = lerp(0.6, 1, E.outBackMocno(e)); ctx.scale(sc, sc);
      cien(s); ctx.fillStyle = w.wyr ? s.k.a : s.k.t; ctx.fillText(w.t, -sz / 2, 0); ctx.restore();
    } });
  dodaj({ id: "slowa-w-ramkach", nazwa: "Słowa kluczowe w ramkach", kat: "tekst", czas: 3.5, pola: ["tekst"], przyklad: { tekst: "Zarabiaj *więcej* pracując *mniej*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 92 * s.u * s.p.rozmiar, { lh: 1.3 }), ctx = s.ctx; ctx.font = ul.font;
      ul.slowa.forEach((w) => {
        const e = okno(s.t, w.i * 0.13 / s.p.tempo, 0.4 / s.p.tempo); if (e <= 0) return;
        ctx.save(); ctx.globalAlpha *= clamp(e * 2);
        if (w.wyr) {
          const sc = E.outBackMocno(e), pad = 14 * s.u;
          ctx.translate(w.x + w.w / 2, w.y); ctx.rotate((1 - sc) * 0.2 - 0.03); ctx.scale(sc, sc);
          ctx.fillStyle = s.k.a; zaokr(ctx, -w.w / 2 - pad, -ul.px * 0.55, w.w + pad * 2, ul.px * 1.1, 12 * s.u); ctx.fill();
          ctx.fillStyle = kontrast(s.k.a); ctx.fillText(w.t, -w.w / 2, 0);
        } else { cien(s); ctx.fillStyle = s.k.t; ctx.fillText(w.t, w.x, w.y + (1 - E.outCubic(e)) * 30 * s.u); }
        ctx.restore();
      });
    } });
  dodaj({ id: "obrot-liter", nazwa: "Litery obracają się", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Zobacz *nowość*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul); ctx.font = ul.font; cien(s);
      z.forEach((c) => {
        const e = okno(s.t, c.i * 0.035 / s.p.tempo, 0.55 / s.p.tempo); if (e <= 0) return;
        ctx.save(); ctx.translate(c.x + c.w / 2, c.y); ctx.scale(1, Math.max(0.001, E.outBack(e))); ctx.globalAlpha *= clamp(e * 2);
        ctx.fillStyle = c.slowo.wyr ? s.k.a : s.k.t; ctx.fillText(c.c, -c.w / 2, 0); ctx.restore();
      });
    } });
  dodaj({ id: "rozciecie", nazwa: "Rozcięcie", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Nowa *era*", wielkie: true },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 120 * s.u * s.p.rozmiar), ctx = s.ctx;
      const c = warstwa(s, "rozciecie", (x) => { x.font = ul.font; x.textBaseline = "middle"; ul.slowa.forEach((w) => piszSlowo(s, w, null, x)); });
      const e = E.outQuint(okno(s.t, 0, 0.8 / s.p.tempo)), sr = ul.y + ul.h / 2, d = (1 - e) * s.W * 0.6;
      ctx.drawImage(c, 0, 0, s.W, sr, -d, 0, s.W, sr);
      ctx.drawImage(c, 0, sr, s.W, s.H - sr, d, sr, s.W, s.H - sr);
      const l = okno(s.t, 0, 0.5 / s.p.tempo) * (1 - okno(s.t, 0.6 / s.p.tempo, 0.4));
      if (l > 0) { ctx.fillStyle = s.k.a; ctx.fillRect(ul.x - 30 * s.u, sr - 2 * s.u, (ul.w + 60 * s.u) * l, 4 * s.u); }
    } });
  dodaj({ id: "losowe-litery", nazwa: "Litery w losowej kolejności", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Coś się *szykuje*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul); ctx.font = ul.font; cien(s);
      z.forEach((c) => {
        const e = okno(s.t, los(c.i + 1) * 0.7 / s.p.tempo, 0.25); if (e <= 0) return;
        ctx.globalAlpha = s.alfa * e; ctx.fillStyle = c.slowo.wyr ? s.k.a : s.k.t; ctx.fillText(c.c, c.x, c.y);
      });
      ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "dekoder", nazwa: "Dekoder (losowe znaki)", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "DOSTĘP *PRZYZNANY*", wielkie: true, font: "Space Mono" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 88 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul); ctx.font = ul.font; cien(s);
      const ZN = "ABCDEFGHIJKLMNOPRSTUWXYZ0123456789#%&@$";
      z.forEach((c) => {
        const gotowe = 0.15 + c.i * 0.045 / s.p.tempo; if (s.t < c.i * 0.015) return;
        const zn = s.t >= gotowe || c.c === " " ? c.c : ZN[Math.floor(los(c.i * 13 + Math.floor(s.t * 25)) * ZN.length)];
        ctx.fillStyle = s.t >= gotowe ? (c.slowo.wyr ? s.k.a : s.k.t) : rgba(s.k.a, 0.8); ctx.fillText(zn, c.x, c.y);
      });
    } });
  dodaj({ id: "dlugi-cien", nazwa: "Długi cień", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "RETRO", wielkie: true },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 130 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      const e = E.outBack(okno(s.t, 0, 0.5 / s.p.tempo)), cien2 = E.outCubic(okno(s.t, 0.2 / s.p.tempo, 0.6 / s.p.tempo));
      const cx = ul.x + ul.w / 2, cy = ul.y + ul.h / 2; ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); ctx.translate(-cx, -cy);
      const n = Math.round(22 * cien2);
      for (let i = n; i >= 1; i--) { ctx.fillStyle = ciemniej(s.k.g, 0.15 + i / 60); ul.slowa.forEach((w) => ctx.fillText(w.t, w.x + i * 1.6 * s.u, w.y + i * 1.6 * s.u)); }
      ul.slowa.forEach((w) => piszSlowo(s, w)); ctx.restore();
    } });
  dodaj({ id: "kontur-wypelnienie", nazwa: "Kontur i wypełnienie", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "OUTLINE *FILL*", wielkie: true, waga: 900 },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 120 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      const a = okno(s.t, 0, 0.4 / s.p.tempo), b = E.inOutCubic(okno(s.t, 0.4 / s.p.tempo, 0.7 / s.p.tempo));
      ctx.globalAlpha = s.alfa * a; ctx.lineWidth = 3 * s.u; ctx.lineJoin = "round";
      ul.slowa.forEach((w) => { ctx.strokeStyle = w.wyr ? s.k.a : s.k.t; ctx.strokeText(w.t, w.x, w.y); });
      ctx.globalAlpha = s.alfa;
      ctx.save(); ctx.beginPath(); ctx.rect(ul.x - 10, 0, (ul.w + 20) * b, s.H); ctx.clip(); ul.slowa.forEach((w) => piszSlowo(s, w)); ctx.restore();
    } });
  dodaj({ id: "tytul-kinowy", nazwa: "Tytuł kinowy", kat: "tekst", czas: 4, pola: ["tekst", "tekst2"], przyklad: { tekst: "WARSZAWA", tekst2: "21.10.2026", wielkie: true, waga: 300 },
    rysuj(s) {
      const ctx = s.ctx, px = 110 * s.u * s.p.rozmiar, e = E.outQuint(okno(s.t, 0, 1.6 / s.p.tempo));
      const t = tekstP(s, s.p.tekst), od = lerp(0.6, 0.18, e) * px;
      ctx.font = font(s, px, s.p.waga);
      const zn = Array.from(t), szer = zn.reduce((a, c) => a + ctx.measureText(c).width, 0) + od * (zn.length - 1);
      let x = s.poz.x - (s.poz.align === "left" ? 0 : s.poz.align === "right" ? szer : szer / 2);
      ctx.globalAlpha = s.alfa * clamp(e * 1.4); cien(s); ctx.fillStyle = s.k.t;
      zn.forEach((c) => { ctx.fillText(c, x, s.poz.y); x += ctx.measureText(c).width + od; }); bezCienia(ctx);
      const l = E.inOutCubic(okno(s.t, 0.3 / s.p.tempo, 1 / s.p.tempo)), lw = szer * 0.7 * l, sx = s.poz.x - (s.poz.align === "left" ? -szer * 0.15 : s.poz.align === "right" ? szer * 0.85 : 0);
      ctx.globalAlpha = s.alfa; ctx.fillStyle = s.k.a;
      ctx.fillRect(sx - lw / 2, s.poz.y - px * 0.85, lw, 2.5 * s.u); ctx.fillRect(sx - lw / 2, s.poz.y + px * 0.8, lw, 2.5 * s.u);
      if (s.p.tekst2) {
        const e2 = okno(s.t, 0.9 / s.p.tempo, 0.6); ctx.globalAlpha = s.alfa * e2; ctx.font = font(s, px * 0.3, 500); const w2 = ctx.measureText(s.p.tekst2).width;
        ctx.fillStyle = s.k.t; ctx.fillText(s.p.tekst2, sx - w2 / 2, s.poz.y + px * 1.15 + (1 - e2) * 10 * s.u); ctx.globalAlpha = s.alfa;
      }
    } });
  dodaj({ id: "tytul-z-podtytulem", nazwa: "Tytuł z podtytułem", kat: "tekst", czas: 3.5, pola: ["tekst", "tekst2"], przyklad: { tekst: "Jak zacząć *inwestować*", tekst2: "Poradnik w 3 krokach" },
    rysuj(s) {
      const ctx = s.ctx, ul = uloz(s, s.p.tekst, 92 * s.u * s.p.rozmiar, { y: s.poz.y - 30 * s.u * s.p.rozmiar }); ctx.font = ul.font;
      const l = E.outCubic(okno(s.t, 0, 0.4 / s.p.tempo));
      const bx = (s.poz.align === "left" ? ul.x - 26 * s.u : ul.x - 26 * s.u);
      ctx.fillStyle = s.k.a; ctx.fillRect(bx, ul.y, 9 * s.u, (ul.h + 60 * s.u * s.p.rozmiar) * l);
      ul.linie.forEach((li, i) => {
        const e = E.outQuint(okno(s.t, 0.15 / s.p.tempo + i * 0.1, 0.6 / s.p.tempo));
        ctx.save(); ctx.beginPath(); ctx.rect(0, li.y - ul.lh * 0.6, s.W, ul.lh * 1.2); ctx.clip(); cien(s);
        li.slowa.forEach((w) => piszSlowo(s, w, null, ctx, 0, (1 - e) * ul.lh)); ctx.restore();
      });
      if (s.p.tekst2) {
        const e = E.outCubic(okno(s.t, 0.6 / s.p.tempo, 0.5)); ctx.globalAlpha = s.alfa * e;
        const u2 = uloz(s, s.p.tekst2, 44 * s.u * s.p.rozmiar, { y: ul.y + ul.h + 34 * s.u * s.p.rozmiar, waga: 500 });
        ctx.font = u2.font; u2.slowa.forEach((w) => { ctx.fillStyle = rgba(s.k.t, 0.85); ctx.fillText(w.t, w.x + (1 - e) * -20 * s.u, w.y); });
        ctx.globalAlpha = s.alfa;
      }
    } });
  dodaj({ id: "napis-na-plakietce", nazwa: "Napis na plakietce", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "Czy wiesz, że *80%* ludzi…" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 72 * s.u * s.p.rozmiar, { maxW: s.W * 0.78, lh: 1.25 }), ctx = s.ctx; ctx.font = ul.font;
      ul.linie.forEach((l, i) => {
        const e = E.outBack(okno(s.t, i * 0.1 / s.p.tempo, 0.45 / s.p.tempo)); if (e <= 0) return;
        const pad = 22 * s.u, cx = l.x0 + l.w / 2;
        ctx.save(); ctx.translate(cx, l.y); ctx.scale(e, e); ctx.translate(-cx, -l.y);
        ctx.fillStyle = s.k.tl === "#141414" ? "#FFFFFF" : s.k.tl; zaokr(ctx, l.x0 - pad, l.y - ul.lh * 0.5, l.w + pad * 2, ul.lh, 14 * s.u); ctx.fill();
        const kt = kontrast(s.k.tl === "#141414" ? "#FFFFFF" : s.k.tl);
        l.slowa.forEach((w) => { ctx.fillStyle = w.wyr ? s.k.g : kt; ctx.fillText(w.t, w.x, w.y); }); ctx.restore();
      });
    } });

  // Belki z nazwiskiem
  function belkaTeksty(s, x, y, px) {
    const ctx = s.ctx;
    ctx.font = font(s, px, s.p.waga); const w1 = ctx.measureText(tekstP(s, s.p.tekst)).width;
    ctx.font = font(s, px * 0.52, 500); const w2 = s.p.tekst2 ? ctx.measureText(s.p.tekst2).width : 0;
    return { w1, w2, w: Math.max(w1, w2) };
  }
  const prawa = (s) => s.poz.align === "right";
  dodaj({ id: "belka-prosta", nazwa: "Belka prosta", kat: "belki", czas: 4, pola: ["tekst", "tekst2"], dom: { pozycja: "lewy-dol" }, przyklad: { tekst: "Anna Kowalska", tekst2: "Prezes, Emerald Media" },
    rysuj(s) {
      const ctx = s.ctx, px = 58 * s.u * s.p.rozmiar, m = belkaTeksty(s, 0, 0, px), pad = 28 * s.u, h = px * (s.p.tekst2 ? 2.1 : 1.5);
      const W = m.w + pad * 2, x0 = prawa(s) ? s.poz.x - W : s.poz.x, y0 = s.poz.y - h / 2;
      const a = E.outQuint(okno(s.t, 0, 0.6 / s.p.tempo));
      ctx.fillStyle = rgba(s.k.tl, 0.92); ctx.fillRect(prawa(s) ? x0 + W * (1 - a) : x0, y0, W * a, h);
      ctx.fillStyle = s.k.g; ctx.fillRect(prawa(s) ? x0 + W - 8 * s.u : x0, y0, 8 * s.u, h * a);
      ctx.save(); ctx.beginPath(); ctx.rect(x0, y0, W, h); ctx.clip();
      const e1 = E.outCubic(okno(s.t, 0.25 / s.p.tempo, 0.5)), e2 = E.outCubic(okno(s.t, 0.4 / s.p.tempo, 0.5));
      const ty = s.p.tekst2 ? y0 + h * 0.36 : y0 + h / 2;
      ctx.font = font(s, px, s.p.waga); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), prawa(s) ? x0 + W - pad - m.w1 : x0 + pad, ty + (1 - e1) * h);
      if (s.p.tekst2) { ctx.font = font(s, px * 0.52, 500); ctx.fillStyle = rgba(s.k.t, 0.8); ctx.fillText(s.p.tekst2, prawa(s) ? x0 + W - pad - m.w2 : x0 + pad, y0 + h * 0.72 + (1 - e2) * h); }
      ctx.restore();
    } });
  dodaj({ id: "belka-akcent", nazwa: "Belka z akcentem", kat: "belki", czas: 4, pola: ["tekst", "tekst2"], dom: { pozycja: "lewy-dol" }, przyklad: { tekst: "Marek Nowak", tekst2: "Head of Marketing" },
    rysuj(s) {
      const ctx = s.ctx, px = 56 * s.u * s.p.rozmiar, m = belkaTeksty(s, 0, 0, px), pad = 26 * s.u, h1 = px * 1.5, h2 = px * 0.95;
      const x0 = prawa(s) ? s.poz.x - m.w - pad * 2 : s.poz.x, y0 = s.poz.y - (h1 + h2) / 2;
      const a = E.outBackMocno(okno(s.t, 0, 0.35 / s.p.tempo)), b = E.outQuint(okno(s.t, 0.2 / s.p.tempo, 0.6 / s.p.tempo)), c = E.outQuint(okno(s.t, 0.35 / s.p.tempo, 0.6 / s.p.tempo));
      ctx.save(); ctx.translate(x0, y0); ctx.scale(a, a); ctx.fillStyle = s.k.a; ctx.fillRect(-h1 * 0.25, -h1 * 0.18, h1 * 0.5, h1 * 0.5); ctx.restore();
      const W1 = (m.w1 + pad * 2) * b; ctx.fillStyle = s.k.g; ctx.fillRect(x0, y0, W1, h1);
      ctx.save(); ctx.beginPath(); ctx.rect(x0, y0, W1, h1); ctx.clip(); ctx.font = font(s, px, s.p.waga); ctx.fillStyle = kontrast(s.k.g);
      ctx.fillText(tekstP(s, s.p.tekst), x0 + pad, y0 + h1 / 2); ctx.restore();
      if (s.p.tekst2) {
        const W2 = (m.w2 + pad * 2) * c; ctx.fillStyle = "#FFFFFF"; ctx.fillRect(x0, y0 + h1, W2, h2);
        ctx.save(); ctx.beginPath(); ctx.rect(x0, y0 + h1, W2, h2); ctx.clip(); ctx.font = font(s, px * 0.52, 600); ctx.fillStyle = "#111";
        ctx.fillText(s.p.tekst2, x0 + pad, y0 + h1 + h2 / 2); ctx.restore();
      }
    } });
  dodaj({ id: "belka-linia", nazwa: "Belka z linią", kat: "belki", czas: 4, pola: ["tekst", "tekst2"], dom: { pozycja: "lewy-dol" }, przyklad: { tekst: "Kasia Wiśniewska", tekst2: "fotografka" },
    rysuj(s) {
      const ctx = s.ctx, px = 60 * s.u * s.p.rozmiar, m = belkaTeksty(s, 0, 0, px), x0 = prawa(s) ? s.poz.x - m.w : s.poz.x, y = s.poz.y;
      const l = E.inOutCubic(okno(s.t, 0, 0.5 / s.p.tempo)), e1 = E.outQuint(okno(s.t, 0.3 / s.p.tempo, 0.6)), e2 = E.outQuint(okno(s.t, 0.4 / s.p.tempo, 0.6));
      ctx.fillStyle = s.k.a; ctx.fillRect(prawa(s) ? x0 + m.w * (1 - l) : x0, y - 2.5 * s.u, m.w * l, 5 * s.u);
      ctx.save(); ctx.beginPath(); ctx.rect(x0 - 20, y - px * 1.4, m.w + 40, px * 1.37); ctx.clip(); cien(s);
      ctx.font = font(s, px, s.p.waga); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), prawa(s) ? x0 + m.w - m.w1 : x0, y - px * 0.62 + (1 - e1) * px * 1.3); ctx.restore();
      if (s.p.tekst2) {
        ctx.save(); ctx.beginPath(); ctx.rect(x0 - 20, y + 3 * s.u, m.w + 40, px); ctx.clip(); cien(s);
        ctx.font = font(s, px * 0.52, 500); ctx.fillStyle = rgba(s.k.t, 0.9); ctx.fillText(s.p.tekst2, prawa(s) ? x0 + m.w - m.w2 : x0, y + px * 0.48 - (1 - e2) * px); ctx.restore();
      }
    } });
  dodaj({ id: "belka-pigulka", nazwa: "Belka pigułka z inicjałami", kat: "belki", czas: 4, pola: ["tekst", "tekst2"], dom: { pozycja: "lewy-dol" }, przyklad: { tekst: "Jan Zieliński", tekst2: "@janzielinski" },
    rysuj(s) {
      const ctx = s.ctx, px = 48 * s.u * s.p.rozmiar, m = belkaTeksty(s, 0, 0, px), h = px * 2.3, r = h / 2;
      const W = h + m.w + 40 * s.u, x0 = prawa(s) ? s.poz.x - W : s.poz.x, y0 = s.poz.y - r;
      const a = E.outBackMocno(okno(s.t, 0, 0.4 / s.p.tempo)), b = E.outQuint(okno(s.t, 0.25 / s.p.tempo, 0.6 / s.p.tempo));
      ctx.save(); cien(s); ctx.fillStyle = "#FFFFFF"; zaokr(ctx, x0, y0, h + (W - h) * b, h, r); ctx.fill(); ctx.restore();
      ctx.save(); ctx.translate(x0 + r, y0 + r); ctx.scale(a, a); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, r * 0.82, 0, Math.PI * 2); ctx.fill();
      const ini = String(s.p.tekst || "").split(/\s+/).map((x) => x[0] || "").join("").slice(0, 2).toUpperCase();
      ctx.font = font(s, r * 0.8, 800); const wi = ctx.measureText(ini).width; ctx.fillStyle = kontrast(s.k.g); ctx.fillText(ini, -wi / 2, 0); ctx.restore();
      ctx.save(); ctx.beginPath(); zaokr(ctx, x0, y0, h + (W - h) * b, h, r); ctx.clip();
      const tx = x0 + h + 8 * s.u, e = okno(s.t, 0.45 / s.p.tempo, 0.4); ctx.globalAlpha *= e;
      ctx.font = font(s, px, s.p.waga); ctx.fillStyle = "#111"; ctx.fillText(tekstP(s, s.p.tekst), tx, s.p.tekst2 ? y0 + h * 0.38 : y0 + r);
      if (s.p.tekst2) { ctx.font = font(s, px * 0.6, 500); ctx.fillStyle = s.k.g; ctx.fillText(s.p.tekst2, tx, y0 + h * 0.68); }
      ctx.restore();
    } });
  dodaj({ id: "belka-dwukolor", nazwa: "Belka dwukolorowa", kat: "belki", czas: 4, pola: ["tekst", "tekst2"], dom: { pozycja: "lewy-dol", wielkie: true }, przyklad: { tekst: "Tomasz Lis", tekst2: "Ekspert ds. finansów" },
    rysuj(s) {
      const ctx = s.ctx, px = 54 * s.u * s.p.rozmiar, m = belkaTeksty(s, 0, 0, px), pad = 22 * s.u, h1 = px * 1.45, h2 = px;
      [[s.p.tekst, s.k.g, px, s.p.waga, m.w1, 0, h1], [s.p.tekst2, s.k.a, px * 0.52, 700, m.w2, h1 + 6 * s.u, h2]].forEach(([t, kol, r, wg, w, dy, h], i) => {
        if (!t) return;
        const e = E.outQuint(okno(s.t, i * 0.15 / s.p.tempo, 0.6 / s.p.tempo)), W = w + pad * 2;
        const x0 = (prawa(s) ? s.poz.x - W : s.poz.x) + (prawa(s) ? 1 : -1) * (1 - e) * (W + 60 * s.u) * 0, y0 = s.poz.y - (h1 + h2) / 2 + dy;
        ctx.save(); ctx.beginPath(); ctx.rect(x0, y0, W, h); ctx.clip();
        const dx = (1 - e) * -W * (prawa(s) ? -1 : 1);
        ctx.fillStyle = kol; ctx.fillRect(x0 + dx, y0, W, h);
        ctx.font = font(s, r, wg); ctx.fillStyle = kontrast(kol); ctx.fillText(i ? t : tekstP(s, t), x0 + pad + dx * 1.15, y0 + h / 2); ctx.restore();
      });
    } });
  dodaj({ id: "belka-minimal", nazwa: "Belka minimalistyczna", kat: "belki", czas: 4, pola: ["tekst", "tekst2"], dom: { pozycja: "lewy-dol" }, przyklad: { tekst: "Ola Mazur", tekst2: "architektka wnętrz" },
    rysuj(s) {
      const ctx = s.ctx, px = 58 * s.u * s.p.rozmiar, m = belkaTeksty(s, 0, 0, px), h = px * (s.p.tekst2 ? 1.9 : 1.2);
      const xl = prawa(s) ? s.poz.x : s.poz.x, y0 = s.poz.y - h / 2, l = E.outQuint(okno(s.t, 0, 0.45 / s.p.tempo));
      ctx.fillStyle = s.k.a; ctx.fillRect(xl - 3 * s.u, y0 + h * (1 - l) / 2, 6 * s.u, h * l);
      const odst = 24 * s.u, kier = prawa(s) ? -1 : 1;
      ctx.save(); ctx.beginPath(); prawa(s) ? ctx.rect(0, y0 - 10, xl - odst / 2, h + 20) : ctx.rect(xl + odst / 2, y0 - 10, s.W, h + 20); ctx.clip(); cien(s);
      const e1 = E.outQuint(okno(s.t, 0.2 / s.p.tempo, 0.6)), e2 = E.outQuint(okno(s.t, 0.32 / s.p.tempo, 0.6));
      ctx.font = font(s, px, s.p.waga); ctx.fillStyle = s.k.t;
      ctx.fillText(tekstP(s, s.p.tekst), prawa(s) ? xl - odst - m.w1 + (1 - e1) * m.w1 : xl + odst - (1 - e1) * (m.w1 + odst), s.p.tekst2 ? y0 + px * 0.55 : y0 + h / 2);
      if (s.p.tekst2) { ctx.font = font(s, px * 0.5, 400); ctx.fillStyle = rgba(s.k.t, 0.85); ctx.fillText(s.p.tekst2, prawa(s) ? xl - odst - m.w2 + (1 - e2) * m.w2 : xl + odst - (1 - e2) * (m.w2 + odst), y0 + px * 1.42); }
      ctx.restore(); void kier;
    } });
  dodaj({ id: "belka-social", nazwa: "Nick w social mediach", kat: "belki", czas: 3.5, pola: ["tekst"], dom: { pozycja: "dol" }, przyklad: { tekst: "@nadamedia" },
    rysuj(s) {
      const ctx = s.ctx, px = 56 * s.u * s.p.rozmiar; ctx.font = font(s, px, s.p.waga);
      const w = ctx.measureText(s.p.tekst).width, h = px * 1.8, W = w + h + 40 * s.u;
      const x0 = s.poz.align === "left" ? s.poz.x : s.poz.align === "right" ? s.poz.x - W : s.poz.x - W / 2, y0 = s.poz.y - h / 2;
      const e = E.outBackMocno(okno(s.t, 0, 0.45 / s.p.tempo)); ctx.save(); ctx.translate(x0 + W / 2, y0 + h / 2); ctx.scale(e, e); ctx.translate(-x0 - W / 2, -y0 - h / 2);
      cien(s); ctx.fillStyle = "#FFFFFF"; zaokr(ctx, x0, y0, W, h, h / 2); ctx.fill(); bezCienia(ctx);
      const g = ctx.createLinearGradient(x0, y0, x0 + h, y0 + h); g.addColorStop(0, s.k.g); g.addColorStop(1, s.k.a);
      ctx.fillStyle = g; zaokr(ctx, x0 + h * 0.14, y0 + h * 0.14, h * 0.72, h * 0.72, h * 0.22); ctx.fill();
      ctx.strokeStyle = "#FFF"; ctx.lineWidth = h * 0.06; ctx.beginPath(); ctx.arc(x0 + h / 2, y0 + h / 2, h * 0.16, 0, Math.PI * 2); ctx.stroke();
      zaokr(ctx, x0 + h * 0.27, y0 + h * 0.27, h * 0.46, h * 0.46, h * 0.13); ctx.stroke();
      ctx.font = font(s, px, s.p.waga); ctx.fillStyle = "#111"; ctx.fillText(s.p.tekst, x0 + h + 10 * s.u, y0 + h / 2); ctx.restore();
    } });

  // Grafiki do rolek
  const punkt = (s, a = "x", b = "y") => [clamp(+s.p[a]) * s.W, clamp(+s.p[b]) * s.H];
  dodaj({ id: "strzalka", nazwa: "Strzałka rysowana ręcznie", kat: "rolki", czas: 3, pola: ["tekst", "xy"], przyklad: { tekst: "Patrz tutaj!", x: 0.6, y: 0.55 },
    rysuj(s) {
      const ctx = s.ctx, [tx, ty] = punkt(s), u = s.u * s.p.rozmiar;
      const sx = tx + (tx > s.W / 2 ? -1 : 1) * 300 * u, sy = ty + (ty > s.H * 0.4 ? -1 : 1) * 260 * u;
      const e = E.inOutCubic(okno(s.t, 0.15 / s.p.tempo, 0.6 / s.p.tempo)), et = E.outBack(okno(s.t, 0, 0.35 / s.p.tempo));
      const pkt = krzywa([sx, sy + (ty > sy ? 40 : -40) * u], [sx + (tx - sx) * 0.1, ty + (sy - ty) * 0.15], [tx - (tx - sx) * 0.08, ty - (ty - sy) * 0.08]);
      ctx.strokeStyle = s.k.a; ctx.lineWidth = 11 * u; ctx.lineCap = "round"; ctx.lineJoin = "round"; cien(s);
      const { koniec, kier } = sciezkaCzesc(ctx, pkt, e); ctx.stroke();
      if (e > 0.85) {
        const g = E.outBack(okno(e, 0.85, 0.15)) * 40 * u;
        ctx.beginPath(); ctx.moveTo(koniec[0] - Math.cos(kier - 0.5) * g, koniec[1] - Math.sin(kier - 0.5) * g); ctx.lineTo(...koniec);
        ctx.lineTo(koniec[0] - Math.cos(kier + 0.5) * g, koniec[1] - Math.sin(kier + 0.5) * g); ctx.stroke();
      }
      if (s.p.tekst) {
        ctx.font = font(s, 58 * u, s.p.waga); const w = ctx.measureText(tekstP(s, s.p.tekst)).width;
        const lx = clamp(sx - w / 2, 30 * s.u, s.W - w - 30 * s.u), ly = sy + (ty > sy ? -30 : 50) * u;
        ctx.save(); ctx.translate(lx + w / 2, ly); ctx.rotate(-0.04); ctx.scale(et, et); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), -w / 2, 0); ctx.restore();
      }
    } });
  dodaj({ id: "kolko", nazwa: "Zakreślone kółko", kat: "rolki", czas: 3, pola: ["xy"], przyklad: { x: 0.5, y: 0.5 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), r = 170 * s.u * s.p.rozmiar, e = E.inOutCubic(okno(s.t, 0, 0.7 / s.p.tempo));
      const pkt = []; for (let i = 0; i <= 80; i++) { const a = -2.2 + (i / 80) * Math.PI * 2.15, rr = r * (1 + 0.06 * Math.sin(i * 0.21)); pkt.push([cx + Math.cos(a) * rr * 1.25, cy + Math.sin(a) * rr * 0.85]); }
      ctx.strokeStyle = s.k.a; ctx.lineWidth = 10 * s.u * s.p.rozmiar; ctx.lineCap = "round"; cien(s); sciezkaCzesc(ctx, pkt, e); ctx.stroke();
    } });
  dodaj({ id: "emoji", nazwa: "Emoji wyskakuje", kat: "rolki", czas: 2.5, pola: ["emoji", "xy"], przyklad: { emoji: "🔥", x: 0.75, y: 0.3 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), px = 170 * s.u * s.p.rozmiar, e = E.outElastic(okno(s.t, 0, 0.8 / s.p.tempo));
      ctx.save(); ctx.translate(cx, cy + Math.sin(s.t * 3) * 8 * s.u); ctx.rotate(Math.sin(s.t * 4) * 0.12 * (1 - okno(s.t, 1, 2) * 0.5)); ctx.scale(e, e);
      ctx.font = `${Math.round(px)}px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif`; const w = ctx.measureText(s.p.emoji).width;
      ctx.fillText(s.p.emoji, -w / 2, 0); ctx.restore();
    } });
  dodaj({ id: "obserwuj", nazwa: "Przycisk Obserwuj z kliknięciem", kat: "cta", czas: 3, pola: ["tekst", "tekst2"], dom: { pozycja: "dol" }, przyklad: { tekst: "Obserwuj", tekst2: "Obserwujesz ✓" },
    rysuj(s) {
      const ctx = s.ctx, px = 60 * s.u * s.p.rozmiar, klik = 1.3 / s.p.tempo, po = s.t > klik;
      ctx.font = font(s, px, 800); const t = po && s.p.tekst2 ? s.p.tekst2 : s.p.tekst, w = ctx.measureText(t).width;
      const W = Math.max(w, ctx.measureText(s.p.tekst).width) + 90 * s.u, h = px * 1.9, cx = s.poz.x, cy = s.poz.y;
      const e = E.outBackMocno(okno(s.t, 0, 0.4 / s.p.tempo)), nac = s.t > klik - 0.08 && s.t < klik + 0.12 ? 0.92 : 1;
      ctx.save(); ctx.translate(cx, cy); ctx.scale(e * nac, e * nac); cien(s);
      ctx.fillStyle = po ? "#3A3A3A" : s.k.g; zaokr(ctx, -W / 2, -h / 2, W, h, h * 0.3); ctx.fill(); bezCienia(ctx);
      ctx.fillStyle = po ? "#FFFFFF" : kontrast(s.k.g); ctx.fillText(t, -w / 2, 0); ctx.restore();
      if (s.t > klik) { const r = okno(s.t, klik, 0.5); ctx.strokeStyle = rgba("#FFFFFF", 1 - r); ctx.lineWidth = 4 * s.u; ctx.beginPath(); ctx.arc(cx + W * 0.25, cy + h * 0.2, 20 * s.u + r * 60 * s.u, 0, Math.PI * 2); ctx.stroke(); }
      const m = E.inOutCubic(okno(s.t, 0.4 / s.p.tempo, klik - 0.45 / s.p.tempo));
      kursor(ctx, lerp(cx + W, cx + W * 0.25, m), lerp(cy + h * 2.2, cy + h * 0.2, m), 1.6 * s.u * s.p.rozmiar * (s.t > klik - 0.08 && s.t < klik + 0.12 ? 0.85 : 1));
    } });
  dodaj({ id: "pasek-postepu", nazwa: "Pasek postępu filmu", kat: "rolki", czas: 15, pola: [], dom: { wyjscie: 0.01, wyjscie_styl: "brak" }, przyklad: { czas: 6 },
    rysuj(s) {
      const ctx = s.ctx, m = 30 * s.u, h = 12 * s.u * s.p.rozmiar, y = 40 * s.u, e = okno(s.t, 0, 0.3);
      ctx.globalAlpha = s.alfa * e; ctx.fillStyle = rgba("#FFFFFF", 0.3); zaokr(ctx, m, y, s.W - m * 2, h, h / 2); ctx.fill();
      ctx.fillStyle = s.k.g; zaokr(ctx, m, y, Math.max(h, (s.W - m * 2) * clamp(s.t / s.T)), h, h / 2); ctx.fill(); ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "lista-check", nazwa: "Lista z odhaczaniem", kat: "rolki", czas: 5, pola: ["lista"], dom: { pozycja: "lewy-srodek" }, przyklad: { lista: "Plan treści\nNagranie\nMontaż\n*Publikacja*" },
    rysuj(s) {
      const ctx = s.ctx, el = lista(s.p.lista), px = 62 * s.u * s.p.rozmiar, lh = px * 1.7, x = s.poz.align === "center" ? s.W * 0.18 : s.poz.x;
      const y0 = s.poz.y - (el.length - 1) * lh / 2, krok = Math.max(0.35, Math.min(0.8, (s.T - s.p.wyjscie - 0.6) / Math.max(1, el.length))) / s.p.tempo;
      el.forEach((t, i) => {
        const y = y0 + i * lh, e = E.outBack(okno(s.t, i * krok, 0.35)), c = E.outCubic(okno(s.t, i * krok + 0.25, 0.35));
        if (e <= 0) return; const b = px * 1.05;
        ctx.save(); ctx.translate(x + b / 2, y); ctx.scale(e, e); cien(s);
        ctx.fillStyle = c > 0 ? s.k.g : "rgba(255,255,255,0.15)"; ctx.strokeStyle = s.k.t; ctx.lineWidth = 4 * s.u;
        zaokr(ctx, -b / 2, -b / 2, b, b, 12 * s.u); ctx.fill(); if (c <= 0) ctx.stroke(); bezCienia(ctx);
        if (c > 0) ptaszek(ctx, 0, 0, b * 0.42, c, kontrast(s.k.g), 7 * s.u); ctx.restore();
        const sl = slowaZ(tekstP(s, t)); ctx.save(); ctx.globalAlpha *= clamp(e); ctx.font = font(s, px, s.p.waga); cien(s);
        let xx = x + b + 26 * s.u + (1 - e) * 30 * s.u; sl.forEach((w) => { ctx.fillStyle = w.wyr ? s.k.a : s.k.t; ctx.fillText(w.t, xx, y); xx += ctx.measureText(w.t + " ").width; }); ctx.restore();
      });
    } });
  dodaj({ id: "cena", nazwa: "Cena na gwiazdce", kat: "cta", czas: 3, pola: ["tekst", "tekst2", "xy"], przyklad: { tekst: "99 zł", tekst2: "tylko dziś", x: 0.72, y: 0.3 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), r = 190 * s.u * s.p.rozmiar, e = E.outBackMocno(okno(s.t, 0, 0.5 / s.p.tempo));
      ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); ctx.rotate(-0.12 + Math.sin(s.t * 2) * 0.03); cien(s);
      gwiazda(ctx, 0, 0, 16, r, r * 0.86, s.t * 0.3); ctx.fillStyle = s.k.a; ctx.fill(); bezCienia(ctx);
      const kt = kontrast(s.k.a), px = dopasuj(s, s.p.tekst, r * 0.62, r * 1.45, 900);
      ctx.font = font(s, px, 900); let w = ctx.measureText(s.p.tekst).width; ctx.fillStyle = kt; ctx.fillText(s.p.tekst, -w / 2, s.p.tekst2 ? r * 0.12 : 0);
      if (s.p.tekst2) { ctx.font = font(s, r * 0.2, 700); w = ctx.measureText(s.p.tekst2).width; ctx.fillText(s.p.tekst2, -w / 2, -r * 0.42); }
      ctx.restore();
    } });
  dodaj({ id: "odliczanie", nazwa: "Odliczanie 3-2-1", kat: "liczby", czas: 3.2, pola: ["liczba"], dom: { wyjscie: 0.2 }, przyklad: { liczba: 3 },
    rysuj(s) {
      const ctx = s.ctx, n = Math.max(1, Math.min(10, Math.round(+s.p.liczba || 3))), dl = (s.T - s.p.wyjscie) / n;
      const i = Math.min(n - 1, Math.floor(s.t / dl)), lt = s.t - i * dl, e = E.outBackMocno(okno(lt, 0, 0.3)), r = 200 * s.u * s.p.rozmiar;
      const cx = s.poz.x, cy = s.poz.y;
      ctx.strokeStyle = rgba(s.k.t, 0.25); ctx.lineWidth = 14 * s.u; ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = s.k.a; ctx.lineCap = "round"; ctx.beginPath(); ctx.arc(cx, cy, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * (1 - clamp(lt / dl))); ctx.stroke();
      const t = String(n - i); ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); ctx.globalAlpha *= 1 - okno(lt, dl - 0.15, 0.15) * 0.6;
      ctx.font = font(s, r * 1.1, 900); const w = ctx.measureText(t).width; cien(s); ctx.fillStyle = s.k.t; ctx.fillText(t, -w / 2, r * 0.04); ctx.restore();
    } });
  dodaj({ id: "licznik", nazwa: "Licznik liczby", kat: "liczby", czas: 3, pola: ["liczba", "od", "przed", "po", "tekst2"], przyklad: { liczba: 250, przed: "+", po: "%", tekst2: "więcej zasięgów" },
    rysuj(s) {
      const ctx = s.ctx, e = E.outExpo(okno(s.t, 0.1, 1.6 / s.p.tempo)), v = lerp(+s.p.od || 0, +s.p.liczba || 0, e);
      const t = `${s.p.przed || ""}${liczbaTekst(v, miejscaPo(s.p.liczba))}${s.p.po || ""}`, px = dopasuj(s, t, 190 * s.u * s.p.rozmiar, s.W * 0.86, 900);
      const wej = E.outBack(okno(s.t, 0, 0.4)); ctx.font = font(s, px, 900); const w = ctx.measureText(t).width;
      const x = s.poz.align === "left" ? s.poz.x : s.poz.align === "right" ? s.poz.x - w : s.poz.x - w / 2;
      ctx.save(); ctx.translate(x + w / 2, s.poz.y); ctx.scale(wej, wej); cien(s); ctx.fillStyle = s.k.a; ctx.fillText(t, -w / 2, 0); ctx.restore();
      if (s.p.tekst2) {
        const e2 = E.outCubic(okno(s.t, 0.5 / s.p.tempo, 0.5)); ctx.globalAlpha = s.alfa * e2;
        const u2 = uloz(s, s.p.tekst2, 52 * s.u * s.p.rozmiar, { y: s.poz.y + px * 0.75, gora: true, waga: 600 }); ctx.font = u2.font; cien(s);
        u2.slowa.forEach((w2) => piszSlowo(s, w2, null, ctx, 0, (1 - e2) * 20 * s.u)); ctx.globalAlpha = s.alfa;
      }
    } });
  dodaj({ id: "wykres-slupki", nazwa: "Wykres słupkowy", kat: "liczby", czas: 4, pola: ["lista", "po", "tekst"], przyklad: { lista: "2023: 40\n2024: 65\n*2025*: 120", po: " tys.", tekst: "Sprzedaż" },
    rysuj(s) {
      const ctx = s.ctx, d = pary(s.p.lista); if (!d.length) return;
      const W = s.W * 0.78 * s.p.rozmiar, H = s.H * (s.H > s.W ? 0.32 : 0.45) * s.p.rozmiar, x0 = s.poz.x - W / 2, y0 = s.poz.y + H / 2;
      const max = Math.max(...d.map((x) => x.v), 1), bw = W / d.length * 0.62, gap = W / d.length;
      const os = E.outCubic(okno(s.t, 0, 0.4)); ctx.fillStyle = rgba(s.k.t, 0.6); ctx.fillRect(x0, y0, W * os, 3 * s.u);
      if (s.p.tekst) { ctx.font = font(s, 50 * s.u * s.p.rozmiar, s.p.waga); ctx.fillStyle = s.k.t; ctx.globalAlpha = s.alfa * os; ctx.fillText(tekstP(s, s.p.tekst), x0, y0 - H - 60 * s.u); ctx.globalAlpha = s.alfa; }
      d.forEach((p, i) => {
        const e = E.outQuint(okno(s.t, 0.25 + i * 0.15 / s.p.tempo, 0.9 / s.p.tempo)), h = (p.v / max) * H * e, x = x0 + gap * i + (gap - bw) / 2;
        const wyr = /^\*.*\*$/.test(p.e), et = p.e.replace(/\*/g, "");
        cien(s, ctx, 0.6); ctx.fillStyle = wyr ? s.k.a : s.k.g; zaokr(ctx, x, y0 - h, bw, h, Math.min(14 * s.u, h / 2)); ctx.fill(); bezCienia(ctx);
        ctx.font = font(s, 36 * s.u * s.p.rozmiar, 600); ctx.fillStyle = s.k.t; let w = ctx.measureText(et).width; ctx.fillText(et, x + bw / 2 - w / 2, y0 + 36 * s.u);
        if (e > 0.05) { const vt = liczbaTekst(p.v * e, miejscaPo(p.v)) + (s.p.po || ""); ctx.font = font(s, 40 * s.u * s.p.rozmiar, 800); w = ctx.measureText(vt).width; ctx.fillText(vt, x + bw / 2 - w / 2, y0 - h - 30 * s.u); }
      });
    } });
  dodaj({ id: "wykres-kolo", nazwa: "Wykres kołowy (procent)", kat: "liczby", czas: 3.5, pola: ["liczba", "tekst2"], przyklad: { liczba: 73, tekst2: "klientów wraca" },
    rysuj(s) {
      const ctx = s.ctx, r = 190 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y, wej = E.outBack(okno(s.t, 0, 0.45)), e = E.outCubic(okno(s.t, 0.2, 1.4 / s.p.tempo));
      const v = clamp((+s.p.liczba || 0) / 100);
      ctx.save(); ctx.translate(cx, cy); ctx.scale(wej, wej);
      ctx.lineWidth = 42 * s.u * s.p.rozmiar; ctx.strokeStyle = rgba(s.k.t, 0.18); ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = s.k.g; ctx.lineCap = "round"; ctx.beginPath(); ctx.arc(0, 0, r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * v * e + 0.0001); ctx.stroke();
      const t = Math.round(v * 100 * e) + "%"; ctx.font = font(s, r * 0.62, 900); const w = ctx.measureText(t).width; cien(s); ctx.fillStyle = s.k.t; ctx.fillText(t, -w / 2, 0); ctx.restore();
      if (s.p.tekst2) { const e2 = okno(s.t, 0.6, 0.5); ctx.globalAlpha = s.alfa * e2; const u2 = uloz(s, s.p.tekst2, 50 * s.u * s.p.rozmiar, { y: cy + r + 60 * s.u, gora: true, align: "center", x: cx, waga: 600 }); ctx.font = u2.font; cien(s); u2.slowa.forEach((w2) => piszSlowo(s, w2)); ctx.globalAlpha = s.alfa; }
    } });
  dodaj({ id: "vs", nazwa: "Porównanie VS", kat: "rolki", czas: 3.5, pola: ["tekst", "tekst2"], przyklad: { tekst: "iPhone", tekst2: "Android", wielkie: true },
    rysuj(s) {
      const ctx = s.ctx, px = 76 * s.u * s.p.rozmiar, cy = s.poz.y, e1 = E.outQuint(okno(s.t, 0, 0.6 / s.p.tempo)), e2 = E.outBackMocno(okno(s.t, 0.35 / s.p.tempo, 0.45));
      ctx.font = font(s, px, 900); cien(s);
      const a = tekstP(s, s.p.tekst), b = tekstP(s, s.p.tekst2), wa = ctx.measureText(a).width, wb = ctx.measureText(b).width;
      ctx.fillStyle = s.k.t; ctx.fillText(a, s.W * 0.27 - wa / 2 - (1 - e1) * s.W * 0.5, cy); ctx.fillText(b, s.W * 0.73 - wb / 2 + (1 - e1) * s.W * 0.5, cy); bezCienia(ctx);
      const l = E.inOutCubic(okno(s.t, 0.1, 0.6)); ctx.strokeStyle = rgba(s.k.t, 0.7); ctx.lineWidth = 4 * s.u;
      ctx.beginPath(); ctx.moveTo(s.W / 2 + 60 * s.u, cy - 300 * s.u * l); ctx.lineTo(s.W / 2 - 60 * s.u, cy + 300 * s.u * l); ctx.stroke();
      const r = 82 * s.u * s.p.rozmiar; ctx.save(); ctx.translate(s.W / 2, cy); ctx.scale(e2, e2); ctx.rotate((1 - e2) * 0.6);
      cien(s); ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill(); bezCienia(ctx);
      ctx.font = font(s, r * 0.85, 900); const w = ctx.measureText("VS").width; ctx.fillStyle = kontrast(s.k.a); ctx.fillText("VS", -w / 2, 0); ctx.restore();
    } });
  dodaj({ id: "cytat", nazwa: "Cytat", kat: "rolki", czas: 4.5, pola: ["tekst", "tekst2"], przyklad: { tekst: "Najlepszy czas na start był wczoraj. Drugi najlepszy jest *dziś*.", tekst2: "— przysłowie" },
    rysuj(s) {
      const ctx = s.ctx, ul = uloz(s, s.p.tekst, 66 * s.u * s.p.rozmiar, { maxW: s.W * 0.76, lh: 1.25, waga: 600 }); ctx.font = ul.font;
      const q = E.outBackMocno(okno(s.t, 0, 0.4)); ctx.save(); ctx.translate(ul.x + 30 * s.u, ul.y - 70 * s.u); ctx.scale(q, q);
      ctx.font = font(s, 240 * s.u * s.p.rozmiar, 900); ctx.fillStyle = s.k.a; ctx.fillText("“", -50 * s.u, 60 * s.u); ctx.restore();
      ctx.font = ul.font; cien(s);
      ul.slowa.forEach((w) => { const e = okno(s.t, 0.3 + w.i * 0.06 / s.p.tempo, 0.3); if (e <= 0) return; ctx.globalAlpha = s.alfa * e; piszSlowo(s, w, null, ctx, 0, (1 - e) * 14 * s.u); });
      ctx.globalAlpha = s.alfa;
      if (s.p.tekst2) { const e = E.outCubic(okno(s.t, 0.5 + ul.slowa.length * 0.06, 0.5)); ctx.globalAlpha = s.alfa * e; ctx.font = font(s, 42 * s.u * s.p.rozmiar, 500); ctx.fillStyle = rgba(s.k.t, 0.85); ctx.fillText(s.p.tekst2, ul.x + (1 - e) * 30 * s.u, ul.y + ul.h + 50 * s.u); ctx.globalAlpha = s.alfa; }
    } });
  dodaj({ id: "dymek", nazwa: "Dymek rozmowy", kat: "rolki", czas: 3.5, pola: ["tekst", "xy"], przyklad: { tekst: "Serio?! 😮", x: 0.55, y: 0.35 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), ul0 = uloz(s, s.p.tekst, 56 * s.u * s.p.rozmiar, { maxW: s.W * 0.6, x: cx, y: cy, align: "center", lh: 1.2 });
      const pad = 34 * s.u, W = ul0.w + pad * 2, H = ul0.h + pad * 1.4, x0 = cx - W / 2, y0 = cy - H / 2;
      const e = E.outBackMocno(okno(s.t, 0, 0.45 / s.p.tempo)), ox = x0 + W * 0.22, oy = y0 + H + 40 * s.u;
      ctx.save(); ctx.translate(ox, oy); ctx.scale(e, e); ctx.translate(-ox, -oy); cien(s);
      ctx.fillStyle = "#FFFFFF"; zaokr(ctx, x0, y0, W, H, 40 * s.u); ctx.fill();
      ctx.beginPath(); ctx.moveTo(x0 + W * 0.18, y0 + H - 2); ctx.lineTo(ox, oy); ctx.lineTo(x0 + W * 0.36, y0 + H - 2); ctx.closePath(); ctx.fill(); bezCienia(ctx);
      ctx.font = ul0.font; ul0.slowa.forEach((w) => { ctx.fillStyle = w.wyr ? s.k.g : "#111"; ctx.fillText(w.t, w.x, w.y); }); ctx.restore();
    } });
  dodaj({ id: "pinezka", nazwa: "Pinezka z miejscem", kat: "rolki", czas: 3.5, pola: ["tekst", "tekst2", "xy"], przyklad: { tekst: "Kraków", tekst2: "Rynek Główny", x: 0.4, y: 0.45 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), r = 46 * s.u * s.p.rozmiar, e = okno(s.t, 0, 0.7 / s.p.tempo), y = lerp(cy - s.H * 0.4, cy, E.outBounce(e));
      if (e > 0) {
        ctx.fillStyle = "rgba(0,0,0,0.3)"; ctx.beginPath(); ctx.ellipse(cx, cy + 4 * s.u, r * 0.7 * clamp(e * 1.5), r * 0.22 * clamp(e * 1.5), 0, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.moveTo(cx, y); ctx.bezierCurveTo(cx - r * 0.3, y - r * 0.7, cx - r, y - r * 1.1, cx - r, y - r * 1.75);
        ctx.arc(cx, y - r * 1.75, r, Math.PI, 0); ctx.bezierCurveTo(cx + r, y - r * 1.1, cx + r * 0.3, y - r * 0.7, cx, y); ctx.fill();
        ctx.fillStyle = "#FFF"; ctx.beginPath(); ctx.arc(cx, y - r * 1.75, r * 0.4, 0, Math.PI * 2); ctx.fill();
      }
      const p = E.outQuint(okno(s.t, 0.7 / s.p.tempo, 0.6)); if (p <= 0 || !s.p.tekst) return;
      const px = 50 * s.u * s.p.rozmiar; ctx.font = font(s, px, s.p.waga); const w1 = ctx.measureText(tekstP(s, s.p.tekst)).width;
      ctx.font = font(s, px * 0.6, 500); const w2 = s.p.tekst2 ? ctx.measureText(s.p.tekst2).width : 0;
      const W = Math.max(w1, w2) + 50 * s.u, H = px * (s.p.tekst2 ? 2.2 : 1.6), x0 = cx + r * 1.5, y0 = cy - r * 1.75 - H / 2;
      ctx.save(); ctx.beginPath(); ctx.rect(x0, y0 - 10, W + 20, H + 20); ctx.clip(); cien(s);
      ctx.fillStyle = "#FFFFFF"; zaokr(ctx, x0 - W * (1 - p), y0, W, H, 16 * s.u); ctx.fill(); bezCienia(ctx);
      ctx.font = font(s, px, s.p.waga); ctx.fillStyle = "#111"; ctx.fillText(tekstP(s, s.p.tekst), x0 + 25 * s.u - W * (1 - p), s.p.tekst2 ? y0 + H * 0.36 : y0 + H / 2);
      if (s.p.tekst2) { ctx.font = font(s, px * 0.6, 500); ctx.fillStyle = s.k.g; ctx.fillText(s.p.tekst2, x0 + 25 * s.u - W * (1 - p), y0 + H * 0.7); }
      ctx.restore();
    } });
  dodaj({ id: "przesun-w-gore", nazwa: "Przesuń w górę", kat: "cta", czas: 3, pola: ["tekst"], dom: { pozycja: "dol" }, przyklad: { tekst: "Przesuń po więcej" },
    rysuj(s) {
      const ctx = s.ctx, e = E.outCubic(okno(s.t, 0, 0.4)), cx = s.poz.x, y = s.poz.y + 30 * s.u;
      ctx.globalAlpha = s.alfa * e; ctx.strokeStyle = s.k.t; ctx.lineWidth = 9 * s.u * s.p.rozmiar; ctx.lineCap = "round"; ctx.lineJoin = "round"; cien(s);
      for (let i = 0; i < 3; i++) {
        const f = ((s.t * 1.3 + i / 3) % 1), yy = y - f * 90 * s.u, a = Math.sin(f * Math.PI);
        ctx.globalAlpha = s.alfa * e * a; ctx.beginPath(); ctx.moveTo(cx - 34 * s.u, yy); ctx.lineTo(cx, yy - 30 * s.u); ctx.lineTo(cx + 34 * s.u, yy); ctx.stroke();
      }
      ctx.globalAlpha = s.alfa * e; ctx.font = font(s, 50 * s.u * s.p.rozmiar, 700); const w = ctx.measureText(tekstP(s, s.p.tekst)).width;
      ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), cx - w / 2, y + 70 * s.u); ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "logo-odkrycie", nazwa: "Odkrycie logo", kat: "cta", czas: 3, pola: ["logo", "tekst"], przyklad: { tekst: "nadamedia" },
    rysuj(s) {
      const ctx = s.ctx, cx = s.poz.x, cy = s.poz.y, R = 260 * s.u * s.p.rozmiar, e = E.outQuint(okno(s.t, 0.1, 0.9 / s.p.tempo)), ring = okno(s.t, 0, 1.1 / s.p.tempo);
      ctx.strokeStyle = rgba(s.k.a, 1 - ring); ctx.lineWidth = 8 * s.u; ctx.beginPath(); ctx.arc(cx, cy, R * 0.3 + ring * R * 1.1, 0, Math.PI * 2); ctx.stroke();
      ctx.save(); ctx.beginPath(); ctx.arc(cx, cy, Math.max(0.1, R * 1.4 * e), 0, Math.PI * 2); ctx.clip();
      const img = s.p.logo;
      if (img && (img.width || img.naturalWidth)) {
        const iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height, k = Math.min(R * 1.6 / iw, R * 1.0 / ih) * lerp(1.25, 1, e);
        ctx.drawImage(img, cx - iw * k / 2, cy - ih * k / 2, iw * k, ih * k);
      } else { const px = dopasuj(s, s.p.tekst, 120 * s.u * s.p.rozmiar, R * 1.8, 900); ctx.font = font(s, px, 900); const w = ctx.measureText(tekstP(s, s.p.tekst)).width; ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), cx - w / 2, cy); }
      ctx.restore();
    } });
  dodaj({ id: "reflektor", nazwa: "Reflektor (przyciemnienie wokół)", kat: "rolki", czas: 3, pola: ["xy"], przyklad: { x: 0.5, y: 0.42 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), e = E.outCubic(okno(s.t, 0, 0.5 / s.p.tempo)), r = lerp(Math.max(s.W, s.H), 220 * s.u * s.p.rozmiar, e);
      const c = warstwa(s, "reflektor", (x) => {
        x.fillStyle = `rgba(0,0,0,${0.62 * e})`; x.fillRect(0, 0, s.W, s.H); x.globalCompositeOperation = "destination-out";
        const g = x.createRadialGradient(cx, cy, r * 0.75, cx, cy, r); g.addColorStop(0, "rgba(0,0,0,1)"); g.addColorStop(1, "rgba(0,0,0,0)");
        x.fillStyle = g; x.beginPath(); x.arc(cx, cy, r, 0, Math.PI * 2); x.fill();
      });
      ctx.drawImage(c, 0, 0);
    } });
  dodaj({ id: "nagrywanie", nazwa: "Kadr kamery REC", kat: "rolki", czas: 5, pola: [], przyklad: {},
    rysuj(s) {
      const ctx = s.ctx, m = 50 * s.u, d = 90 * s.u, e = E.outCubic(okno(s.t, 0, 0.4)), g = 6 * s.u;
      ctx.strokeStyle = "#FFFFFF"; ctx.lineWidth = g; ctx.globalAlpha = s.alfa * e; const mm = m + (1 - e) * 40 * s.u;
      [[mm, mm, 1, 1], [s.W - mm, mm, -1, 1], [mm, s.H - mm, 1, -1], [s.W - mm, s.H - mm, -1, -1]].forEach(([x, y, a, b]) => {
        ctx.beginPath(); ctx.moveTo(x, y + d * b); ctx.lineTo(x, y); ctx.lineTo(x + d * a, y); ctx.stroke();
      });
      if (Math.floor(s.t * 1.6) % 2 === 0) { ctx.fillStyle = "#FF2D2D"; ctx.beginPath(); ctx.arc(mm + 50 * s.u, mm + 70 * s.u, 14 * s.u, 0, Math.PI * 2); ctx.fill(); }
      ctx.font = `700 ${Math.round(40 * s.u)}px Consolas, "Courier New", monospace`; ctx.fillStyle = "#FFF"; ctx.fillText("REC", mm + 80 * s.u, mm + 72 * s.u);
      const sek = Math.floor(s.t), kl = Math.floor((s.t % 1) * 25), tc = `00:00:${String(sek).padStart(2, "0")}:${String(kl).padStart(2, "0")}`;
      const w = ctx.measureText(tc).width; ctx.fillText(tc, s.W - mm - 40 * s.u - w, mm + 72 * s.u);
      ctx.strokeRect(s.W - mm - 140 * s.u, s.H - mm - 90 * s.u, 80 * s.u, 36 * s.u); ctx.fillRect(s.W - mm - 134 * s.u, s.H - mm - 84 * s.u, 50 * s.u, 24 * s.u); ctx.fillRect(s.W - mm - 60 * s.u, s.H - mm - 80 * s.u, 6 * s.u, 16 * s.u);
      ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "naklejka", nazwa: "Naklejka", kat: "rolki", czas: 3, pola: ["tekst", "xy"], przyklad: { tekst: "MUST HAVE", x: 0.7, y: 0.25, wielkie: true },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), px = 62 * s.u * s.p.rozmiar; ctx.font = font(s, px, 900);
      const t = tekstP(s, s.p.tekst), w = ctx.measureText(t).width, W = w + 60 * s.u, H = px * 1.7, e = E.outBackMocno(okno(s.t, 0, 0.45 / s.p.tempo));
      ctx.save(); ctx.translate(cx, cy); ctx.rotate(-0.1 + Math.sin(s.t * 3.2) * 0.04); ctx.scale(e, e); cien(s, ctx, 1.2);
      ctx.fillStyle = "#FFFFFF"; zaokr(ctx, -W / 2 - 10 * s.u, -H / 2 - 10 * s.u, W + 20 * s.u, H + 20 * s.u, 26 * s.u); ctx.fill(); bezCienia(ctx);
      ctx.fillStyle = s.k.g; zaokr(ctx, -W / 2, -H / 2, W, H, 18 * s.u); ctx.fill();
      ctx.fillStyle = kontrast(s.k.g); ctx.fillText(t, -w / 2, 0); ctx.restore();
    } });
  dodaj({ id: "etykieta", nazwa: "Etykieta NOWOŚĆ", kat: "cta", czas: 3, pola: ["tekst"], dom: { pozycja: "lewy-gora", wielkie: true }, przyklad: { tekst: "Nowość" },
    rysuj(s) {
      const ctx = s.ctx, px = 50 * s.u * s.p.rozmiar; ctx.font = font(s, px, 900); const t = tekstP(s, s.p.tekst), w = ctx.measureText(t).width;
      const H = px * 1.6, W = w + 70 * s.u, e = E.outQuint(okno(s.t, 0, 0.6 / s.p.tempo)), x0 = prawa(s) ? s.poz.x - W : s.poz.x, y0 = s.poz.y - H / 2;
      const dx = (1 - e) * (prawa(s) ? 1 : -1) * (W + x0 + 50);
      ctx.save(); ctx.translate(dx, 0); cien(s); ctx.fillStyle = s.k.a; ctx.beginPath();
      ctx.moveTo(x0, y0); ctx.lineTo(x0 + W, y0); ctx.lineTo(x0 + W - 24 * s.u, y0 + H / 2); ctx.lineTo(x0 + W, y0 + H); ctx.lineTo(x0, y0 + H); ctx.closePath(); ctx.fill(); bezCienia(ctx);
      ctx.fillStyle = kontrast(s.k.a); ctx.fillText(t, x0 + 24 * s.u, y0 + H / 2); ctx.restore();
    } });
  dodaj({ id: "klikniecie", nazwa: "Kursor i kliknięcie", kat: "rolki", czas: 2.5, pola: ["xy"], przyklad: { x: 0.55, y: 0.5 },
    rysuj(s) {
      const ctx = s.ctx, [tx, ty] = punkt(s), klik = 0.9 / s.p.tempo, m = E.inOutCubic(okno(s.t, 0, klik));
      if (s.t > klik) for (let i = 0; i < 2; i++) { const r = okno(s.t, klik + i * 0.12, 0.6); if (r <= 0 || r >= 1) continue; ctx.strokeStyle = rgba(s.k.a, 1 - r); ctx.lineWidth = 6 * s.u; ctx.beginPath(); ctx.arc(tx, ty, 10 * s.u + r * 90 * s.u, 0, Math.PI * 2); ctx.stroke(); }
      const sk = 2 * s.u * s.p.rozmiar * (s.t > klik && s.t < klik + 0.15 ? 0.85 : 1);
      kursor(ctx, lerp(tx + 260 * s.u, tx, m), lerp(ty + 300 * s.u, ty, m), sk);
    } });
  dodaj({ id: "powiadomienie", nazwa: "Powiadomienie na telefonie", kat: "rolki", czas: 4, pola: ["tekst", "tekst2"], dom: { pozycja: "gora" }, przyklad: { tekst: "Nowe zamówienie! 🎉", tekst2: "Ktoś właśnie kupił Twój kurs" },
    rysuj(s) {
      const ctx = s.ctx, W = Math.min(s.W * 0.88, 900 * s.u), H = 170 * s.u * s.p.rozmiar, x0 = s.W / 2 - W / 2;
      const e = E.outBack(okno(s.t, 0, 0.55 / s.p.tempo)), y0 = lerp(-H - 20, s.poz.y - H / 2, e);
      cien(s, ctx, 1.4); ctx.fillStyle = "rgba(245,245,247,0.97)"; zaokr(ctx, x0, y0, W, H, 34 * s.u); ctx.fill(); bezCienia(ctx);
      const ik = H * 0.42; ctx.fillStyle = s.k.g; zaokr(ctx, x0 + 26 * s.u, y0 + H / 2 - ik / 2, ik, ik, ik * 0.24); ctx.fill();
      const lit = (s.p.tekst || "N").replace(/[^A-Za-zĄĆĘŁŃÓŚŹŻąćęłńóśźż]/g, "")[0] || "N";
      ctx.font = font(s, ik * 0.55, 800); let w = ctx.measureText(lit.toUpperCase()).width; ctx.fillStyle = kontrast(s.k.g); ctx.fillText(lit.toUpperCase(), x0 + 26 * s.u + ik / 2 - w / 2, y0 + H / 2);
      const tx = x0 + 26 * s.u + ik + 24 * s.u;
      ctx.font = font(s, 40 * s.u * s.p.rozmiar, 700); ctx.fillStyle = "#111"; ctx.fillText(s.p.tekst, tx, y0 + H * 0.36);
      ctx.font = font(s, 34 * s.u * s.p.rozmiar, 400); ctx.fillStyle = "#444"; ctx.fillText(s.p.tekst2 || "", tx, y0 + H * 0.66);
      ctx.font = font(s, 28 * s.u, 400); ctx.fillStyle = "#888"; w = ctx.measureText("teraz").width; ctx.fillText("teraz", x0 + W - 30 * s.u - w, y0 + H * 0.36);
    } });
  dodaj({ id: "komentarz", nazwa: "Odpowiedź na komentarz", kat: "rolki", czas: 4, pola: ["tekst", "tekst2"], dom: { pozycja: "gora" }, przyklad: { tekst: "Jak to zrobiłeś?? 🤯", tekst2: "ania.k" },
    rysuj(s) {
      const ctx = s.ctx, px = 52 * s.u * s.p.rozmiar, ul = uloz(s, s.p.tekst, px, { maxW: s.W * 0.62, align: "left", x: 0, y: 0, waga: 600 });
      const naglowek = "Odpowiedz użytkownikowi " + (s.p.tekst2 || "widz"); ctx.font = font(s, 30 * s.u, 600);
      const W = Math.max(ul.w, ctx.measureText(naglowek).width, 300 * s.u) + 160 * s.u, H = ul.h + 110 * s.u, x0 = s.W / 2 - W / 2, y0 = s.poz.y - H / 2;
      const e = E.outBackMocno(okno(s.t, 0, 0.45 / s.p.tempo)); ctx.save(); ctx.translate(x0 + 40 * s.u, y0 + H); ctx.scale(e, e); ctx.translate(-x0 - 40 * s.u, -y0 - H);
      cien(s); ctx.fillStyle = "#FFFFFF"; zaokr(ctx, x0, y0, W, H, 30 * s.u); ctx.fill(); bezCienia(ctx);
      const r = 36 * s.u; ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(x0 + 30 * s.u + r, y0 + 30 * s.u + r, r, 0, Math.PI * 2); ctx.fill();
      ctx.font = font(s, 30 * s.u, 600); ctx.fillStyle = "#666"; ctx.fillText(naglowek, x0 + 120 * s.u, y0 + 46 * s.u);
      ctx.font = ul.font; ul.slowa.forEach((w) => { ctx.fillStyle = w.wyr ? s.k.g : "#111"; ctx.fillText(w.t, x0 + 120 * s.u + w.x, y0 + 72 * s.u + px * 0.6 + w.y - ul.y - ul.lh / 2 + ul.lh / 2); });
      ctx.restore();
    } });
  dodaj({ id: "wyszukiwarka", nazwa: "Wpisywanie w wyszukiwarkę", kat: "rolki", czas: 3.5, pola: ["tekst"], przyklad: { tekst: "jak zacząć montować filmy" },
    rysuj(s) {
      const ctx = s.ctx, px = 46 * s.u * s.p.rozmiar, W = s.W * 0.84, H = px * 2.2, x0 = s.poz.x - W / 2, y0 = s.poz.y - H / 2;
      const e = E.outBack(okno(s.t, 0, 0.4)), n = Array.from(s.p.tekst || ""), ile = Math.floor(okno(s.t, 0.45, n.length * 0.06 / s.p.tempo) * n.length);
      const enter = 0.5 + n.length * 0.06 / s.p.tempo + 0.25, nac = s.t > enter && s.t < enter + 0.15 ? 0.96 : 1;
      ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(e * nac, e * nac); ctx.translate(-s.poz.x, -s.poz.y);
      cien(s); ctx.fillStyle = "#FFFFFF"; zaokr(ctx, x0, y0, W, H, H / 2); ctx.fill(); bezCienia(ctx);
      ctx.strokeStyle = "#777"; ctx.lineWidth = 5 * s.u; ctx.beginPath(); ctx.arc(x0 + H * 0.5, s.poz.y - 4 * s.u, px * 0.36, 0, Math.PI * 2); ctx.stroke();
      ctx.beginPath(); ctx.moveTo(x0 + H * 0.5 + px * 0.26, s.poz.y + px * 0.22); ctx.lineTo(x0 + H * 0.5 + px * 0.5, s.poz.y + px * 0.46); ctx.stroke();
      ctx.font = font(s, px, 500); ctx.fillStyle = "#111"; const t = n.slice(0, ile).join(""); ctx.fillText(t, x0 + H * 0.95, s.poz.y);
      if (Math.floor(s.t * 2.4) % 2 === 0 || ile < n.length) { const w = ctx.measureText(t).width; ctx.fillStyle = s.k.g; ctx.fillRect(x0 + H * 0.95 + w + 4 * s.u, s.poz.y - px * 0.5, 4 * s.u, px); }
      ctx.restore();
    } });
  dodaj({ id: "gwiazdki", nazwa: "Ocena w gwiazdkach", kat: "liczby", czas: 3, pola: ["liczba", "tekst"], przyklad: { liczba: 5, tekst: "4,9 / 5 z 1200 opinii" },
    rysuj(s) {
      const ctx = s.ctx, r = 56 * s.u * s.p.rozmiar, n = clamp(+s.p.liczba || 5, 0, 5), x0 = s.poz.x - r * 2.4 * 2, y = s.poz.y;
      for (let i = 0; i < 5; i++) {
        const e = E.outBackMocno(okno(s.t, i * 0.12 / s.p.tempo, 0.4)); if (e <= 0) continue; const x = x0 + i * r * 2.4;
        ctx.save(); ctx.translate(x, y); ctx.scale(e, e); ctx.rotate((1 - e) * 1.2); cien(s);
        gwiazda(ctx, 0, 0, 5, r, r * 0.45); ctx.fillStyle = rgba(s.k.t, 0.25); ctx.fill(); bezCienia(ctx);
        const wyp = clamp(n - i); if (wyp > 0) { ctx.save(); ctx.beginPath(); ctx.rect(-r, -r, 2 * r * wyp, 2 * r); ctx.clip(); gwiazda(ctx, 0, 0, 5, r, r * 0.45); ctx.fillStyle = s.k.a; ctx.fill(); ctx.restore(); }
        ctx.restore();
      }
      if (s.p.tekst) { const e = okno(s.t, 0.7, 0.4); ctx.globalAlpha = s.alfa * e; const u2 = uloz(s, s.p.tekst, 46 * s.u * s.p.rozmiar, { x: s.poz.x, align: "center", y: y + r * 1.9, gora: true, waga: 600 }); ctx.font = u2.font; cien(s); u2.slowa.forEach((w) => piszSlowo(s, w)); ctx.globalAlpha = s.alfa; }
    } });
  dodaj({ id: "os-czasu", nazwa: "Oś czasu", kat: "rolki", czas: 5, pola: ["lista"], przyklad: { lista: "2019: Start\n2021: 1. biuro\n2023: 50 osób\n*2026*: Europa" },
    rysuj(s) {
      const ctx = s.ctx, d = lista(s.p.lista).map((x) => { const i = x.indexOf(":"); return i > 0 ? [x.slice(0, i).trim(), x.slice(i + 1).trim()] : [x, ""]; }); if (!d.length) return;
      const W = s.W * 0.84, x0 = s.W / 2 - W / 2, y = s.poz.y, krok = (s.T - s.p.wyjscie - 0.8) / d.length / s.p.tempo;
      const l = E.inOutCubic(okno(s.t, 0, Math.max(0.5, krok * d.length))); ctx.fillStyle = rgba(s.k.t, 0.7); ctx.fillRect(x0, y - 2 * s.u, W * l, 4 * s.u);
      d.forEach(([rok, opis], i) => {
        const x = x0 + W * (d.length === 1 ? 0.5 : i / (d.length - 1)) * 0.92 + W * 0.04, e = E.outBackMocno(okno(s.t, 0.2 + i * krok, 0.4)); if (e <= 0) return;
        const wyr = /^\*.*\*$/.test(rok), r2 = rok.replace(/\*/g, "");
        ctx.save(); ctx.translate(x, y); ctx.scale(e, e); ctx.fillStyle = wyr ? s.k.a : s.k.g; ctx.beginPath(); ctx.arc(0, 0, 18 * s.u, 0, Math.PI * 2); ctx.fill(); ctx.restore();
        ctx.globalAlpha = s.alfa * clamp(e); const gora = i % 2 === 0;
        ctx.font = font(s, 46 * s.u * s.p.rozmiar, 900); let w = ctx.measureText(r2).width; ctx.fillStyle = wyr ? s.k.a : s.k.t; cien(s);
        ctx.fillText(r2, clamp(x - w / 2, 10, s.W - w - 10), y + (gora ? -70 : 70) * s.u);
        ctx.font = font(s, 30 * s.u * s.p.rozmiar, 500); w = ctx.measureText(opis).width; ctx.fillStyle = s.k.t; ctx.fillText(opis, clamp(x - w / 2, 10, s.W - w - 10), y + (gora ? -122 : 118) * s.u); bezCienia(ctx);
        ctx.globalAlpha = s.alfa;
      });
    } });
  dodaj({ id: "przed-po", nazwa: "Przed / Po", kat: "rolki", czas: 3.5, pola: ["tekst", "tekst2"], przyklad: { tekst: "PRZED", tekst2: "PO" },
    rysuj(s) {
      const ctx = s.ctx, l = E.inOutCubic(okno(s.t, 0, 0.7 / s.p.tempo)), e = E.outBackMocno(okno(s.t, 0.35 / s.p.tempo, 0.45));
      ctx.fillStyle = "#FFFFFF"; ctx.fillRect(s.W / 2 - 3 * s.u, 0, 6 * s.u, s.H * l); const px = 54 * s.u * s.p.rozmiar, y = s.H * 0.1;
      [[s.p.tekst || "PRZED", s.W * 0.25, "#222"], [s.p.tekst2 || "PO", s.W * 0.75, s.k.g]].forEach(([t, x, kol]) => {
        ctx.save(); ctx.translate(x, y); ctx.scale(e, e); ctx.font = font(s, px, 900); const w = ctx.measureText(t).width;
        cien(s); ctx.fillStyle = kol; zaokr(ctx, -w / 2 - 26 * s.u, -px * 0.8, w + 52 * s.u, px * 1.6, 14 * s.u); ctx.fill(); bezCienia(ctx);
        ctx.fillStyle = kontrast(kol); ctx.fillText(t, -w / 2, 0); ctx.restore();
      });
    } });
  dodaj({ id: "hashtagi", nazwa: "Hashtagi wypływają", kat: "rolki", czas: 4, pola: ["lista"], przyklad: { lista: "#montaż; #rolki; #tiktok; #reels; #wideo" },
    rysuj(s) {
      const ctx = s.ctx, el = lista(s.p.lista), px = 50 * s.u * s.p.rozmiar;
      el.forEach((t, i) => {
        const e = E.outCubic(okno(s.t, i * 0.22 / s.p.tempo, 0.7)); if (e <= 0) return;
        ctx.font = font(s, px, 700); const w = ctx.measureText(t).width, x = s.W * (0.12 + los(i + 3) * 0.6), y = s.poz.y + (i - el.length / 2) * px * 1.5 + (1 - e) * 120 * s.u;
        ctx.save(); ctx.globalAlpha *= e; cien(s); ctx.fillStyle = rgba(s.k.tl, 0.85); zaokr(ctx, x - 18 * s.u, y - px * 0.75, w + 36 * s.u, px * 1.5, px * 0.75); ctx.fill(); bezCienia(ctx);
        ctx.fillStyle = i % 2 ? s.k.a : s.k.t; ctx.fillText(t, x, y); ctx.restore();
      });
    } });
  dodaj({ id: "serduszka", nazwa: "Serduszka lecą w górę", kat: "rolki", czas: 4, pola: ["xy"], dom: { wyjscie: 0.8 }, przyklad: { x: 0.82, y: 0.85 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s);
      for (let i = 0; i < 18; i++) {
        const st = i * 0.17, z = (s.t - st) / 2.2; if (z <= 0 || z >= 1) continue;
        const r = (22 + los(i) * 26) * s.u * s.p.rozmiar, x = cx + Math.sin(z * 6 + i) * 50 * s.u + (los(i + 9) - 0.5) * 80 * s.u, y = cy - z * s.H * 0.55;
        ctx.save(); ctx.globalAlpha *= Math.sin(z * Math.PI); serce(ctx, x, y, r); ctx.fillStyle = [s.k.g, s.k.a, "#FF3B5C"][i % 3]; ctx.fill(); ctx.restore();
      }
    } });
  dodaj({ id: "konfetti", nazwa: "Konfetti", kat: "przejscia", czas: 3, pola: ["xy"], dom: { wyjscie: 0.6 }, przyklad: { x: 0.5, y: 0.5 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), kol = [s.k.g, s.k.a, "#FFFFFF", "#4ADE80", "#60A5FA", "#F472B6"];
      for (let i = 0; i < 90; i++) {
        const a = los(i) * Math.PI * 2, v = (500 + los(i + 1) * 900) * s.u, t = s.t;
        const x = cx + Math.cos(a) * v * (1 - Math.exp(-t * 2.2)) * 0.55, y = cy + Math.sin(a) * v * (1 - Math.exp(-t * 2.2)) * 0.55 + 260 * s.u * t * t;
        const w = (10 + los(i + 2) * 14) * s.u * s.p.rozmiar;
        ctx.save(); ctx.translate(x, y); ctx.rotate(t * (4 + los(i + 3) * 8)); ctx.scale(1, Math.cos(t * 9 + i)); ctx.fillStyle = kol[i % kol.length]; ctx.fillRect(-w / 2, -w / 4, w, w / 2); ctx.restore();
      }
    } });
  dodaj({ id: "krok", nazwa: "Krok z numerem", kat: "rolki", czas: 3.5, pola: ["liczba", "tekst", "tekst2"], dom: { pozycja: "lewy-srodek" }, przyklad: { liczba: 1, tekst: "Zaplanuj treść", tekst2: "zanim włączysz kamerę" },
    rysuj(s) {
      const ctx = s.ctx, r = 70 * s.u * s.p.rozmiar, x = s.poz.align === "center" ? s.W * 0.15 : s.poz.x + r, y = s.poz.y;
      const e = E.outBackMocno(okno(s.t, 0, 0.4)); ctx.save(); ctx.translate(x, y); ctx.scale(e, e); ctx.rotate((1 - e) * -0.8); cien(s);
      ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill(); bezCienia(ctx);
      const n = String(Math.round(+s.p.liczba || 1)); ctx.font = font(s, r * 1.05, 900); const w = ctx.measureText(n).width; ctx.fillStyle = kontrast(s.k.g); ctx.fillText(n, -w / 2, 2 * s.u); ctx.restore();
      const tx = x + r + 30 * s.u, e1 = E.outQuint(okno(s.t, 0.2, 0.6)), e2 = E.outQuint(okno(s.t, 0.35, 0.6));
      ctx.save(); ctx.beginPath(); ctx.rect(tx, y - r * 1.5, s.W, r * 3); ctx.clip(); cien(s);
      ctx.font = font(s, 64 * s.u * s.p.rozmiar, s.p.waga); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), tx - (1 - e1) * 500 * s.u, s.p.tekst2 ? y - r * 0.28 : y);
      if (s.p.tekst2) { ctx.font = font(s, 40 * s.u * s.p.rozmiar, 500); ctx.fillStyle = rgba(s.k.t, 0.85); ctx.fillText(s.p.tekst2, tx - (1 - e2) * 500 * s.u, y + r * 0.45); }
      ctx.restore();
    } });
  dodaj({ id: "pytanie", nazwa: "Pytanie do widza", kat: "cta", czas: 3.5, pola: ["tekst"], przyklad: { tekst: "A Ty jak *myślisz*?" },
    rysuj(s) {
      const ctx = s.ctx, r = 80 * s.u * s.p.rozmiar, e = E.outBackMocno(okno(s.t, 0, 0.45)), cy = s.poz.y - 80 * s.u * s.p.rozmiar;
      ctx.save(); ctx.translate(s.poz.x, cy - r * 0.6); ctx.scale(e, e); ctx.rotate(Math.sin(s.t * 3) * 0.08); cien(s);
      ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill(); bezCienia(ctx);
      ctx.font = font(s, r * 1.3, 900); const w = ctx.measureText("?").width; ctx.fillStyle = kontrast(s.k.a); ctx.fillText("?", -w / 2, 4 * s.u); ctx.restore();
      const ul = uloz(s, s.p.tekst, 70 * s.u * s.p.rozmiar, { y: cy + r * 0.9, gora: true, align: "center", x: s.poz.x }); ctx.font = ul.font; cien(s);
      ul.slowa.forEach((w2) => { const e2 = okno(s.t, 0.3 + w2.i * 0.08, 0.3); if (e2 <= 0) return; ctx.globalAlpha = s.alfa * e2; piszSlowo(s, w2, null, ctx, 0, (1 - e2) * 20 * s.u); });
      ctx.globalAlpha = s.alfa;
    } });
  dodaj({ id: "statystyka", nazwa: "Duża statystyka", kat: "liczby", czas: 3.5, pola: ["tekst", "tekst2"], przyklad: { tekst: "3 mln", tekst2: "wyświetleń w miesiąc" },
    rysuj(s) {
      const ctx = s.ctx, px = dopasuj(s, s.p.tekst, 200 * s.u * s.p.rozmiar, s.W * 0.86, 900), e = E.outQuint(okno(s.t, 0, 0.6 / s.p.tempo));
      ctx.font = font(s, px, 900); const t = tekstP(s, s.p.tekst), w = ctx.measureText(t).width;
      const x = s.poz.align === "left" ? s.poz.x : s.poz.align === "right" ? s.poz.x - w : s.poz.x - w / 2, y = s.poz.y - 30 * s.u;
      ctx.save(); ctx.beginPath(); ctx.rect(0, y - px * 0.62, s.W, px * 1.2); ctx.clip(); cien(s); ctx.fillStyle = s.k.t; ctx.fillText(t, x, y + (1 - e) * px * 1.1); ctx.restore();
      const l = E.inOutCubic(okno(s.t, 0.3 / s.p.tempo, 0.5)); ctx.fillStyle = s.k.a; ctx.fillRect(x, y + px * 0.6, w * l, 12 * s.u * s.p.rozmiar);
      if (s.p.tekst2) { const e2 = E.outCubic(okno(s.t, 0.55 / s.p.tempo, 0.5)); ctx.globalAlpha = s.alfa * e2; ctx.font = font(s, 52 * s.u * s.p.rozmiar, 600); cien(s); ctx.fillStyle = s.k.t; const w2 = ctx.measureText(s.p.tekst2).width; ctx.fillText(s.p.tekst2, s.poz.align === "center" ? s.poz.x - w2 / 2 : x, y + px * 0.6 + 70 * s.u); ctx.globalAlpha = s.alfa; }
    } });
  dodaj({ id: "trasa", nazwa: "Trasa A → B", kat: "rolki", czas: 3.5, pola: ["tekst", "tekst2", "xy", "xy2"], przyklad: { tekst: "Warszawa", tekst2: "Lizbona", x: 0.25, y: 0.62, x2: 0.75, y2: 0.36 },
    rysuj(s) {
      const ctx = s.ctx, a = punkt(s), b = punkt(s, "x2", "y2"), mid = [(a[0] + b[0]) / 2, Math.min(a[1], b[1]) - Math.abs(b[0] - a[0]) * 0.3];
      const e = E.inOutCubic(okno(s.t, 0.3, 1.4 / s.p.tempo)), pkt = krzywa(a, mid, b, 60);
      ctx.setLineDash([16 * s.u, 14 * s.u]); ctx.strokeStyle = s.k.t; ctx.lineWidth = 6 * s.u; ctx.lineCap = "round"; cien(s);
      const { koniec } = sciezkaCzesc(ctx, pkt, e); ctx.stroke(); ctx.setLineDash([]);
      [[a, s.p.tekst, 0], [b, s.p.tekst2, 1.6 / s.p.tempo]].forEach(([p, t, d]) => {
        const k = E.outBackMocno(okno(s.t, d, 0.4)); if (k <= 0) return;
        ctx.save(); ctx.translate(...p); ctx.scale(k, k); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, 20 * s.u, 0, Math.PI * 2); ctx.fill();
        ctx.strokeStyle = "#FFF"; ctx.lineWidth = 5 * s.u; ctx.stroke(); if (t) { ctx.font = font(s, 46 * s.u * s.p.rozmiar, s.p.waga); const w = ctx.measureText(t).width; ctx.fillStyle = s.k.t; ctx.fillText(t, -w / 2, 64 * s.u); } ctx.restore();
      });
      if (e > 0 && e < 1) { ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(...koniec, 14 * s.u, 0, Math.PI * 2); ctx.fill(); }
    } });
  dodaj({ id: "lajk", nazwa: "Lajk z wybuchem", kat: "cta", czas: 2.5, pola: ["xy"], przyklad: { x: 0.5, y: 0.5 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), r = 90 * s.u * s.p.rozmiar, e = E.outElastic(okno(s.t, 0.1, 0.9 / s.p.tempo)), w = okno(s.t, 0.15, 0.5);
      if (w > 0 && w < 1) for (let i = 0; i < 12; i++) { const a = (i / 12) * Math.PI * 2, d1 = r * (1.1 + w * 0.9), d2 = r * (1.3 + w * 1.2); ctx.strokeStyle = rgba(i % 2 ? s.k.a : s.k.g, 1 - w); ctx.lineWidth = 7 * s.u; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * d1, cy + Math.sin(a) * d1); ctx.lineTo(cx + Math.cos(a) * d2, cy + Math.sin(a) * d2); ctx.stroke(); }
      ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); cien(s); serce(ctx, 0, r * 0.1, r); ctx.fillStyle = "#FF3B5C"; ctx.fill(); ctx.restore();
    } });

  // Przejścia i akcenty (pełny kadr, z własnym zakończeniem)
  dodaj({ id: "przejscie-panele", nazwa: "Przejście: panele kolorów", kat: "przejscia", czas: 1.2, pola: [], pelne: true, przyklad: {},
    rysuj(s) {
      const ctx = s.ctx, T = s.T;
      [[s.k.g, 0], [s.k.a, 0.08], [s.k.tl, 0.16]].forEach(([kol, d]) => {
        const a = E.inOutCubic(okno(s.t, d * T, T * 0.42)), b = E.inOutCubic(okno(s.t, T * 0.5 + d * T * 0.5, T * 0.42));
        const x0 = s.W * b, x1 = s.W * a; if (x1 > x0) { ctx.fillStyle = kol; ctx.fillRect(x0, 0, x1 - x0, s.H); }
      });
    } });
  dodaj({ id: "przejscie-kolo", nazwa: "Przejście: koło", kat: "przejscia", czas: 1.2, pola: ["xy"], pelne: true, przyklad: {},
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), R = Math.hypot(Math.max(cx, s.W - cx), Math.max(cy, s.H - cy)) * 1.02;
      const a = E.inOutCubic(okno(s.t, 0, s.T * 0.48)), b = E.inOutCubic(okno(s.t, s.T * 0.52, s.T * 0.48));
      const c = warstwa(s, "kolo", (x) => {
        x.fillStyle = s.k.g; x.beginPath(); x.arc(cx, cy, Math.max(0.1, R * a), 0, Math.PI * 2); x.fill();
        if (b > 0) { x.globalCompositeOperation = "destination-out"; x.beginPath(); x.arc(cx, cy, Math.max(0.1, R * b), 0, Math.PI * 2); x.fill(); }
      });
      ctx.drawImage(c, 0, 0);
    } });
  dodaj({ id: "przejscie-paski", nazwa: "Przejście: ukośne paski", kat: "przejscia", czas: 1.2, pola: [], pelne: true, przyklad: {},
    rysuj(s) {
      const ctx = s.ctx, n = 7, D = Math.hypot(s.W, s.H), sz = D / n;
      ctx.save(); ctx.translate(s.W / 2, s.H / 2); ctx.rotate(-0.5);
      for (let i = 0; i < n; i++) {
        const a = E.inOutCubic(okno(s.t, i * 0.035 * s.T, s.T * 0.4)), b = E.inOutCubic(okno(s.t, s.T * 0.5 + i * 0.035 * s.T, s.T * 0.4));
        const y = -D / 2 + i * sz, x0 = -D / 2 + D * b, x1 = -D / 2 + D * a;
        if (x1 > x0) { ctx.fillStyle = i % 2 ? s.k.a : s.k.g; ctx.fillRect(x0, y, x1 - x0, sz + 1); }
      }
      ctx.restore();
    } });
  dodaj({ id: "blysk-ekranu", nazwa: "Błysk ekranu", kat: "przejscia", czas: 0.6, pola: [], pelne: true, przyklad: { czas: 0.8 },
    rysuj(s) { const ctx = s.ctx, x = s.t / s.T, a = x < 0.25 ? x / 0.25 : 1 - (x - 0.25) / 0.75; ctx.fillStyle = `rgba(255,255,255,${clamp(a)})`; ctx.fillRect(0, 0, s.W, s.H); } });
  dodaj({ id: "kregi", nazwa: "Rozchodzące się kręgi", kat: "przejscia", czas: 2, pola: ["xy"], przyklad: {},
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), R = Math.max(s.W, s.H) * 0.7;
      for (let i = 0; i < 4; i++) { const e = E.outCubic(okno(s.t, i * 0.15, 1.1)); if (e <= 0 || e >= 1) continue; ctx.strokeStyle = rgba(i % 2 ? s.k.a : s.k.g, 1 - e); ctx.lineWidth = (30 - i * 5) * s.u; ctx.beginPath(); ctx.arc(cx, cy, R * e, 0, Math.PI * 2); ctx.stroke(); }
    } });
  dodaj({ id: "wybuch-linii", nazwa: "Wybuch linii (akcent)", kat: "przejscia", czas: 1.5, pola: ["xy"], przyklad: { x: 0.5, y: 0.45 },
    rysuj(s) {
      const ctx = s.ctx, [cx, cy] = punkt(s), r = 140 * s.u * s.p.rozmiar, e = okno(s.t, 0, 0.6 / s.p.tempo);
      ctx.lineCap = "round"; ctx.lineWidth = 10 * s.u * s.p.rozmiar;
      for (let i = 0; i < 10; i++) {
        const a = (i / 10) * Math.PI * 2 + 0.2, d1 = r * (1 + E.outCubic(e) * 0.9), d2 = r * (1 + E.outCubic(clamp(e * 1.6)) * 1.5);
        if (d2 <= d1) continue; ctx.strokeStyle = i % 2 ? s.k.a : s.k.g; ctx.beginPath(); ctx.moveTo(cx + Math.cos(a) * d1, cy + Math.sin(a) * d1); ctx.lineTo(cx + Math.cos(a) * d2, cy + Math.sin(a) * d2); ctx.stroke();
      }
    } });
  dodaj({ id: "linie-predkosci", nazwa: "Linie prędkości", kat: "przejscia", czas: 1.5, pola: [], przyklad: {},
    rysuj(s) {
      const ctx = s.ctx;
      for (let i = 0; i < 26; i++) {
        const y = los(i) * s.H, v = 1.5 + los(i + 4) * 2.5, L = (150 + los(i + 1) * 500) * s.u, x = ((s.t * v + los(i + 7)) % 1.4) * (s.W + L * 2) - L;
        ctx.fillStyle = rgba(i % 3 ? "#FFFFFF" : s.k.a, 0.3 + los(i + 2) * 0.5); ctx.fillRect(x, y, L, (3 + los(i + 3) * 6) * s.u);
      }
    } });
  dodaj({ id: "ksztalty-tlo", nazwa: "Pływające kształty (tło)", kat: "przejscia", czas: 6, pola: [], przyklad: {},
    rysuj(s) {
      const ctx = s.ctx;
      for (let i = 0; i < 14; i++) {
        const x = (los(i) * s.W + Math.sin(s.t * 0.6 + i) * 60 * s.u), y = ((los(i + 20) * s.H - s.t * (20 + los(i + 3) * 40) * s.u) % s.H + s.H) % s.H, r = (14 + los(i + 5) * 40) * s.u;
        ctx.save(); ctx.translate(x, y); ctx.rotate(s.t * (los(i + 8) - 0.5)); ctx.globalAlpha *= 0.35 + los(i + 6) * 0.4; ctx.strokeStyle = ctx.fillStyle = i % 2 ? s.k.a : s.k.g; ctx.lineWidth = 5 * s.u;
        const typ = i % 4;
        if (typ === 0) { ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.fill(); }
        else if (typ === 1) { ctx.beginPath(); ctx.arc(0, 0, r, 0, Math.PI * 2); ctx.stroke(); }
        else if (typ === 2) { ctx.fillRect(-r / 6, -r, r / 3, r * 2); ctx.fillRect(-r, -r / 6, r * 2, r / 3); }
        else { ctx.beginPath(); ctx.moveTo(0, -r); ctx.lineTo(r * 0.87, r * 0.5); ctx.lineTo(-r * 0.87, r * 0.5); ctx.closePath(); ctx.stroke(); }
        ctx.restore();
      }
    } });
  dodaj({ id: "ramka", nazwa: "Ramka rysowana dookoła", kat: "przejscia", czas: 3, pola: [], przyklad: {},
    rysuj(s) {
      const ctx = s.ctx, m = 40 * s.u, e = E.inOutCubic(okno(s.t, 0, 1.2 / s.p.tempo));
      const pkt = [[m, m], [s.W - m, m], [s.W - m, s.H - m], [m, s.H - m], [m, m]];
      ctx.strokeStyle = s.k.g; ctx.lineWidth = 12 * s.u * s.p.rozmiar; ctx.lineJoin = "round"; sciezkaCzesc(ctx, pkt, e); ctx.stroke();
    } });


  // =====================================================================
  // ---------- wersja 17: dużo nowych presetów w każdej kategorii ----------
  // =====================================================================
  const PI = Math.PI;
  /* Tekst wchodzący słowami, literami albo liniami. ruch(ctx, e, el, s, ul) ustawia przekształcenie
     (punkt 0,0 = środek elementu) i zwraca krycie (0–1); po nim rysowany jest sam element. */
  function tekstRuch(id, nazwa, o) {
    dodaj({ id, nazwa, kat: "tekst", czas: o.czas || 3, pola: o.pola || ["tekst"], dom: o.dom, przyklad: { tekst: o.przyklad },
      rysuj(s) {
        const ul = uloz(s, s.p.tekst, (o.px || 100) * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
        const jedn = o.jedn || "slowa", el = jedn === "znaki" ? znaki(s, ul) : jedn === "linie" ? ul.linie.map((l, i) => ({ l, i, x: l.x0, y: l.y, w: l.w })) : ul.slowa;
        const n = el.length, krok = (o.krok || (jedn === "znaki" ? 0.03 : 0.1)) / s.p.tempo, dl = (o.dl || 0.5) / s.p.tempo;
        el.forEach((x, i) => {
          const kol = o.kolejnosc ? o.kolejnosc(i, n) : i;
          const e = okno(s.t, kol * krok, dl);
          if (e <= 0 && !o.zawsze) return;
          ctx.save(); ctx.translate(x.x + x.w / 2, x.y);
          const a = o.ruch(ctx, e, x, s, ul, i, n);
          ctx.globalAlpha = s.alfa * (a == null ? 1 : clamp(a));
          if (o.cien !== false) cien(s);
          if (jedn === "znaki") { ctx.fillStyle = o.kolor ? o.kolor(s, x, i, n) : (x.slowo.wyr ? s.k.a : s.k.t); ctx.fillText(x.c, -x.w / 2, 0); }
          else if (jedn === "linie") x.l.slowa.forEach((w) => piszSlowo(s, w, null, ctx, -x.x - x.w / 2, -x.y));
          else { if (o.kolor) { ctx.fillStyle = o.kolor(s, x, i, n); ctx.fillText(x.t, -x.w / 2, 0); } else piszSlowo(s, x, null, ctx, -x.x - x.w / 2, -x.y); }
          ctx.restore();
        });
        if (o.po) o.po(s, ul);
      } });
  }
  tekstRuch("slowa-z-lewej", "Słowa wjeżdżają z lewej", { przyklad: "Szybko, *prosto*, skutecznie", ruch: (c, e, x, s) => { const k = E.outQuint(e); c.translate(-(1 - k) * 160 * s.u, 0); return e * 2; } });
  tekstRuch("slowa-z-prawej", "Słowa wjeżdżają z prawej", { przyklad: "Nowy *sezon* startuje", ruch: (c, e, x, s) => { const k = E.outQuint(e); c.translate((1 - k) * 160 * s.u, 0); return e * 2; } });
  tekstRuch("slowa-z-gory", "Słowa spadają z góry", { przyklad: "Wszystko w *jednym* miejscu", ruch: (c, e, x, s) => { const k = E.outBounce(e); c.translate(0, -(1 - k) * 220 * s.u); return e * 3; }, dl: 0.7 });
  tekstRuch("slowa-obrot", "Słowa z obrotem", { przyklad: "Kręci się *wokół* ciebie", ruch: (c, e, x, s) => { const k = E.outBack(e); c.rotate((1 - k) * -0.9); c.scale(k, k); return e * 2.5; } });
  tekstRuch("slowa-flip", "Słowa obracają się jak karty", { przyklad: "Odwróć *swoją* perspektywę", ruch: (c, e) => { const k = E.outBack(e); c.scale(1, Math.max(0.02, Math.abs(Math.cos((1 - k) * PI / 2)))); return e * 3; }, dl: 0.55 });
  tekstRuch("slowa-rozciagniecie", "Słowa rozciągają się", { przyklad: "Więcej *miejsca* na pomysły", ruch: (c, e) => { const k = E.outElastic(e); c.scale(Math.max(0.01, k), 1); return e * 4; }, dl: 0.9 });
  tekstRuch("slowa-zoom-duzy", "Słowa lecą na ekran", { przyklad: "Prosto w *twarz*", ruch: (c, e) => { const k = E.outCubic(e); const sk = lerp(3.2, 1, k); c.scale(sk, sk); return e * 1.6; }, dl: 0.45 });
  tekstRuch("slowa-skos", "Słowa ze skosem", { przyklad: "Pełna *prędkość* naprzód", ruch: (c, e, x, s) => { const k = E.outQuint(e); c.translate((1 - k) * 260 * s.u, 0); c.transform(1, 0, -(1 - k) * 0.8, 1, 0, 0); return e * 2; } });
  tekstRuch("slowa-naprzemian", "Słowa na zmianę z góry i z dołu", { przyklad: "Góra dół *rytm* gra", ruch: (c, e, x, s, ul, i) => { const k = E.outQuint(e); c.translate(0, (1 - k) * (i % 2 ? 1 : -1) * 120 * s.u); return e * 2; } });
  tekstRuch("slowa-od-srodka", "Słowa wybuchają od środka", { przyklad: "Wszystko *zaczyna się* tutaj", krok: 0, dl: 0.7, ruch: (c, e, x, s) => { const k = E.outBack(e); c.translate((s.poz.x - x.x - x.w / 2) * (1 - k), (s.poz.y - x.y) * (1 - k)); c.scale(k, k); return e * 2; } });
  tekstRuch("slowa-pulsuja", "Słowa pulsują w rytmie", { przyklad: "Czujesz *ten* rytm?", czas: 3.5, zawsze: true, ruch: (c, e, x, s, ul, i) => { const k = E.outBack(e); const b = 1 + 0.06 * Math.max(0, Math.sin((s.t * 2.2 - i * 0.18) * PI * 2)); c.scale(k * b, k * b); return e * 3; } });
  tekstRuch("slowa-drzenie", "Drżące słowa", { przyklad: "To *niesamowite*!", czas: 3, ruch: (c, e, x, s, ul, i) => { const k = E.outBackMocno(e); const d = 5 * s.u * (1 - okno(s.t, 1.2, 1)); c.translate((los(i * 7 + Math.floor(s.t * 24)) - 0.5) * d, (los(i * 13 + Math.floor(s.t * 24)) - 0.5) * d); c.scale(k, k); return e * 3; } });
  tekstRuch("slowa-kolejno-akcent", "Słowa rozświetlają się po kolei", { przyklad: "Każde słowo ma znaczenie", czas: 3.5, zawsze: true, kolor: (s, x, i, n) => { const f = okno(s.t, 0.4 + i * 0.28 / s.p.tempo, 0.12); return f > 0 && f < 1 ? s.k.a : f >= 1 ? s.k.t : rgba(s.k.t, 0.35); }, ruch: () => 1 });
  tekstRuch("litery-spadaja", "Litery spadają", { jedn: "znaki", przyklad: "Spadają *gwiazdy*", ruch: (c, e, x, s, ul, i) => { const k = E.outBounce(e); c.translate(0, -(1 - k) * 260 * s.u); return e * 4; }, dl: 0.75 });
  tekstRuch("litery-obrot", "Litery wirują", { jedn: "znaki", przyklad: "Wir *energii*", ruch: (c, e) => { const k = E.outBack(e); c.rotate((1 - k) * PI * 2); c.scale(k, k); return e * 3; }, dl: 0.6 });
  tekstRuch("litery-rozsypane", "Litery zlatują się z rozsypki", { jedn: "znaki", krok: 0.012, dl: 0.9, przyklad: "Układamy *całość*", ruch: (c, e, x, s, ul, i) => { const k = E.outQuint(e); c.translate((los(i * 3.1) - 0.5) * 900 * s.u * (1 - k), (los(i * 5.7) - 0.5) * 1100 * s.u * (1 - k)); c.rotate((los(i * 9.3) - 0.5) * 3 * (1 - k)); return e * 2; } });
  tekstRuch("litery-rozmycie-bok", "Litery wpływają z rozmyciem", { jedn: "znaki", przyklad: "Płynnie i *lekko*", ruch: (c, e, x, s) => { const k = E.outCubic(e); c.translate((1 - k) * 60 * s.u, 0); if (k < 0.98) c.filter = `blur(${((1 - k) * 14 * s.u).toFixed(1)}px)`; return e * 1.5; } });
  tekstRuch("litery-guma", "Gumowe litery", { jedn: "znaki", przyklad: "Boing *boing*!", ruch: (c, e) => { const k = E.outElastic(e); c.scale(1 + (1 - k) * 0.8, Math.max(0.01, k)); return e * 4; }, dl: 0.8 });
  tekstRuch("litery-od-konca", "Litery od końca", { jedn: "znaki", przyklad: "Na *wspak* do celu", kolejnosc: (i, n) => n - 1 - i, ruch: (c, e, x, s) => { const k = E.outBack(e); c.translate(0, (1 - k) * 80 * s.u); return e * 3; } });
  tekstRuch("litery-srodek", "Litery od środka na boki", { jedn: "znaki", przyklad: "SYMETRIA", kolejnosc: (i, n) => Math.abs(i - (n - 1) / 2), krok: 0.05, ruch: (c, e) => { const k = E.outBackMocno(e); c.scale(k, k); return e * 3; } });
  tekstRuch("litery-teczowe", "Tęczowe litery", { jedn: "znaki", czas: 3.5, przyklad: "Kolorowo *wszędzie*", zawsze: true, kolor: (s, x, i) => { const kol = [s.k.g, s.k.a, s.k.t]; return kol[(i + Math.floor(s.t * 6)) % 3]; }, ruch: (c, e) => { const k = E.outBack(e); c.scale(k, k); return e * 3; } });
  tekstRuch("litery-fala-ciagla", "Litery falują cały czas", { jedn: "znaki", czas: 4, przyklad: "Na *fali*", zawsze: true, ruch: (c, e, x, s, ul, i) => { c.translate(0, Math.sin(s.t * 5 - i * 0.45) * 18 * s.u * s.p.rozmiar); return E.outCubic(e) * 2; } });
  tekstRuch("linie-z-boku", "Linie wysuwają się na zmianę z boków", { jedn: "linie", przyklad: "Pierwsza linia z lewej druga z *prawej* strony", dl: 0.6, krok: 0.18, ruch: (c, e, x, s, ul, i) => { const k = E.outQuint(e); c.translate((1 - k) * (i % 2 ? 1 : -1) * s.W * 0.7, 0); return 1; } });
  tekstRuch("linie-zoom", "Linie przybliżają się po kolei", { jedn: "linie", przyklad: "Krok po kroku *bliżej* celu", krok: 0.22, ruch: (c, e) => { const k = E.outBack(e); c.scale(k, k); return e * 2; } });
  tekstRuch("linie-schodki", "Linie po schodkach", { jedn: "linie", przyklad: "Raz dwa trzy *cztery* pięć", krok: 0.2, ruch: (c, e, x, s, ul, i) => { const k = E.outCubic(e); c.translate(0, (1 - k) * 90 * s.u); c.translate((i - (ul.linie.length - 1) / 2) * 40 * s.u * k, 0); return e * 2; } });
  // tekst z dekoracją
  function tekstZDekoracja(id, nazwa, przyklad, deko, o = {}) {
    dodaj({ id, nazwa, kat: "tekst", czas: o.czas || 3.2, pola: ["tekst"], przyklad: { tekst: przyklad },
      rysuj(s) {
        const ul = uloz(s, s.p.tekst, (o.px || 96) * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
        const e = E.outCubic(okno(s.t, 0, 0.6 / s.p.tempo));
        deko(s, ul, ctx, "pod");
        ctx.globalAlpha = s.alfa * clamp(e * 2);
        ul.slowa.forEach((w) => { ctx.save(); cien(s); piszSlowo(s, w, null, ctx, 0, (1 - e) * 30 * s.u); ctx.restore(); });
        ctx.globalAlpha = s.alfa;
        deko(s, ul, ctx, "nad");
      } });
  }
  tekstZDekoracja("tekst-ramka-rysowana", "Ramka rysuje się wokół tekstu", "Ważna *informacja*", (s, ul, ctx, w) => {
    if (w !== "nad") return; const m = 28 * s.u, e = E.inOutCubic(okno(s.t, 0.3 / s.p.tempo, 0.9 / s.p.tempo));
    const x = ul.x - m, y = ul.y - m * 0.6, W = ul.w + m * 2, H = ul.h + m * 1.2;
    ctx.strokeStyle = s.k.a; ctx.lineWidth = 7 * s.u * s.p.rozmiar; ctx.lineJoin = "round";
    sciezkaCzesc(ctx, [[x, y], [x + W, y], [x + W, y + H], [x, y + H], [x, y]], e); ctx.stroke();
  });
  tekstZDekoracja("tekst-w-kolku", "Słowo w zakreślonym kółku", "To *działa* naprawdę", (s, ul, ctx, w) => {
    if (w !== "nad") return; const wyr = ul.slowa.filter((x) => x.wyr); const cel = wyr.length ? wyr : [ul.slowa[ul.slowa.length - 1]]; if (!cel[0]) return;
    const x0 = Math.min(...cel.map((x) => x.x)), x1 = Math.max(...cel.map((x) => x.x + x.w)), cy = cel[0].y, rx = (x1 - x0) / 2 + 30 * s.u, ry = ul.px * 0.75;
    const e = E.inOutCubic(okno(s.t, 0.5 / s.p.tempo, 0.8 / s.p.tempo)); ctx.strokeStyle = s.k.a; ctx.lineWidth = 6 * s.u * s.p.rozmiar; ctx.lineCap = "round";
    ctx.beginPath(); for (let i = 0; i <= 60 * e; i++) { const a = -PI * 0.6 + (i / 60) * PI * 2.15, r = 1 + 0.05 * Math.sin(i * 0.3); const px = (x0 + x1) / 2 + Math.cos(a) * rx * r, py = cy + Math.sin(a) * ry * r; i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); } ctx.stroke();
  });
  tekstZDekoracja("tekst-podkreslenie-fala", "Podkreślenie falą", "Nowy *poziom* jakości", (s, ul, ctx, w) => {
    if (w !== "nad") return; const l = ul.linie[ul.linie.length - 1], y = l.y + ul.px * 0.68, e = E.inOutCubic(okno(s.t, 0.35 / s.p.tempo, 0.8 / s.p.tempo));
    ctx.strokeStyle = s.k.a; ctx.lineWidth = 7 * s.u * s.p.rozmiar; ctx.lineCap = "round"; ctx.beginPath();
    for (let x = 0; x <= l.w * e; x += 4 * s.u) { const py = y + Math.sin(x / (22 * s.u)) * 7 * s.u; x ? ctx.lineTo(l.x0 + x, py) : ctx.moveTo(l.x0 + x, py); } ctx.stroke();
  });
  tekstZDekoracja("tekst-przekreslenie", "Przekreślenie i poprawka", "Trudne *łatwe*", (s, ul, ctx, w) => {
    if (w !== "nad") return; const zw = ul.slowa.filter((x) => !x.wyr); if (!zw.length) return;
    const e = E.inOutCubic(okno(s.t, 0.5 / s.p.tempo, 0.35 / s.p.tempo)); ctx.strokeStyle = s.k.g; ctx.lineWidth = 9 * s.u * s.p.rozmiar; ctx.lineCap = "round";
    zw.forEach((x) => { ctx.beginPath(); ctx.moveTo(x.x - 6 * s.u, x.y + 4 * s.u); ctx.lineTo(x.x - 6 * s.u + (x.w + 12 * s.u) * e, x.y - 4 * s.u); ctx.stroke(); });
  });
  tekstZDekoracja("tekst-nawiasy", "Tekst w nawiasach", "Najważniejsze *teraz*", (s, ul, ctx, w) => {
    if (w !== "nad") return; const e = E.outBackMocno(okno(s.t, 0.1 / s.p.tempo, 0.5 / s.p.tempo)), m = 36 * s.u, h = ul.h + m, gr = 8 * s.u * s.p.rozmiar, r = 26 * s.u;
    ctx.strokeStyle = s.k.a; ctx.lineWidth = gr; const cx = ul.x + ul.w / 2, d = (ul.w / 2 + m) * e;
    [[-1, cx - d], [1, cx + d]].forEach(([k, x]) => { ctx.beginPath(); ctx.moveTo(x - k * r, ul.y - m / 2); ctx.lineTo(x, ul.y - m / 2); ctx.lineTo(x, ul.y - m / 2 + h); ctx.lineTo(x - k * r, ul.y - m / 2 + h); ctx.stroke(); });
  });
  tekstZDekoracja("tekst-plama", "Tekst na plamie koloru", "Coś *wyjątkowego*", (s, ul, ctx, w) => {
    if (w !== "pod") return; const e = E.outBackMocno(okno(s.t, 0, 0.55 / s.p.tempo)), cx = ul.x + ul.w / 2, cy = ul.y + ul.h / 2;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); ctx.rotate(-0.04); ctx.fillStyle = s.k.g; ctx.beginPath();
    const rx = ul.w / 2 + 60 * s.u, ry = ul.h / 2 + 50 * s.u; for (let i = 0; i <= 24; i++) { const a = i / 24 * PI * 2, r = 1 + 0.08 * Math.sin(a * 3 + s.t * 2); const px = Math.cos(a) * rx * r, py = Math.sin(a) * ry * r; i ? ctx.lineTo(px, py) : ctx.moveTo(px, py); }
    ctx.closePath(); ctx.fill(); ctx.restore();
  });
  tekstZDekoracja("tekst-swiatlo", "Przelatujący błysk po tekście", "Błyszczy *jak nowe*", (s, ul, ctx, w) => {
    if (w !== "nad") return; const e = okno(s.t, 0.6 / s.p.tempo, 0.7 / s.p.tempo); if (e <= 0 || e >= 1) return;
    const x = ul.x - 100 * s.u + (ul.w + 200 * s.u) * E.inOutCubic(e);
    ctx.save(); ctx.globalCompositeOperation = "source-atop"; const g = ctx.createLinearGradient(x - 60 * s.u, 0, x + 60 * s.u, 0);
    g.addColorStop(0, "rgba(255,255,255,0)"); g.addColorStop(0.5, "rgba(255,255,255,0.9)"); g.addColorStop(1, "rgba(255,255,255,0)");
    ctx.fillStyle = g; ctx.fillRect(ul.x - 100 * s.u, ul.y - 50 * s.u, ul.w + 200 * s.u, ul.h + 100 * s.u); ctx.restore();
  });
  tekstZDekoracja("tekst-kropki", "Tekst z kropkami akcentu", "Proste. Szybkie. *Twoje.*", (s, ul, ctx, w) => {
    if (w !== "nad") return; ul.slowa.forEach((x, i) => { const e = E.outBackMocno(okno(s.t, (0.3 + i * 0.12) / s.p.tempo, 0.35)); if (e <= 0) return;
      ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(x.x + x.w / 2, x.y - ul.px * 0.72, 7 * s.u * s.p.rozmiar * e, 0, PI * 2); ctx.fill(); });
  });
  tekstZDekoracja("tekst-cudzyslow", "Krótki cytat w cudzysłowie", "Najlepsza *decyzja* w tym roku", (s, ul, ctx, w) => {
    if (w !== "nad") return; const e = E.outBackMocno(okno(s.t, 0, 0.5 / s.p.tempo)); ctx.save(); ctx.translate(ul.x - 10 * s.u, ul.y - 30 * s.u); ctx.scale(e, e);
    ctx.font = font(s, 220 * s.u * s.p.rozmiar, 900); ctx.fillStyle = s.k.a; ctx.fillText("„", -70 * s.u, -10 * s.u); ctx.restore();
  }, { px: 84 });
  dodaj({ id: "tekst-licznik-slow", nazwa: "Słowa jak na liczydle", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "WYNIK *GWARANTOWANY*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 100 * s.u * s.p.rozmiar), ctx = s.ctx, z = znaki(s, ul), AL = "ABCDEFGHIJKLMNOPRSTUWZ0123456789"; ctx.font = ul.font; cien(s);
      z.forEach((c) => {
        const e = okno(s.t, c.i * 0.04 / s.p.tempo, 0.7 / s.p.tempo); if (e <= 0) return;
        ctx.save(); ctx.beginPath(); ctx.rect(c.x - 4 * s.u, c.y - ul.px * 0.6, c.w + 8 * s.u, ul.px * 1.2); ctx.clip();
        const ile = 5, przes = (1 - E.outCubic(e)) * ile;
        for (let k = 0; k <= ile; k++) { const yy = c.y + (k - przes) * ul.px * 1.1; const ch = k === 0 ? c.c : AL[Math.floor(los(c.i * 11 + k) * AL.length)];
          if (Math.abs(yy - c.y) < ul.px * 1.2) { ctx.fillStyle = c.slowo.wyr ? s.k.a : s.k.t; ctx.fillText(ch, c.x, yy); } }
        ctx.restore();
      });
    } });
  dodaj({ id: "tekst-rozsuniecie", nazwa: "Tekst rozsuwa się na dwie połowy", kat: "tekst", czas: 3, pola: ["tekst"], przyklad: { tekst: "OTWIERAMY *NOWE*" },
    rysuj(s) {
      const ul = uloz(s, s.p.tekst, 110 * s.u * s.p.rozmiar), ctx = s.ctx; ctx.font = ul.font;
      const e = E.outQuint(okno(s.t, 0.1, 0.8 / s.p.tempo)), d = (1 - e) * ul.px * 0.9;
      [[-1, ul.y - 40 * s.u, ul.y + ul.h / 2], [1, ul.y + ul.h / 2, ul.y + ul.h + 40 * s.u]].forEach(([k, y0, y1]) => {
        ctx.save(); ctx.beginPath(); ctx.rect(0, y0, s.W, y1 - y0); ctx.clip(); ctx.translate(0, k * d); ctx.globalAlpha = s.alfa * clamp(e * 2);
        ul.slowa.forEach((w) => piszSlowo(s, w)); ctx.restore();
      });
      ctx.fillStyle = s.k.a; const lw = ul.w * E.outQuint(okno(s.t, 0, 0.5 / s.p.tempo)) * (1 - E.inCubic(okno(s.t, 0.5, 0.5)));
      ctx.fillRect(ul.x + (ul.w - lw) / 2, ul.y + ul.h / 2 - 3 * s.u, lw, 6 * s.u);
    } });

  // ---------- belki z nazwiskiem (v17) ----------
  /* Wspólny układ belki: prostokąt (x0, y0, W, h) przy pozycji, teksty po lewej (albo po prawej przy pozycji z prawej). */
  function belkaUklad(s, px, padX, wysK) {
    const m = belkaTeksty(s, 0, 0, px), pad = (padX || 28) * s.u, h = px * (wysK || (s.p.tekst2 ? 2.1 : 1.5));
    const W = m.w + pad * 2, x0 = prawa(s) ? s.poz.x - W : s.poz.x - (s.poz.align === "center" ? W / 2 : 0), y0 = s.poz.y - h / 2;
    return { m, pad, h, W, x0, y0, px };
  }
  function belkaTekst(s, b, e1, e2, o = {}) {
    const ctx = s.ctx, p = prawa(s), ty = s.p.tekst2 ? b.y0 + b.h * 0.37 : b.y0 + b.h / 2;
    const x1 = p ? b.x0 + b.W - b.pad - b.m.w1 : b.x0 + b.pad + (o.dx || 0), x2 = p ? b.x0 + b.W - b.pad - b.m.w2 : b.x0 + b.pad + (o.dx || 0);
    ctx.save(); if (o.klip !== false) { ctx.beginPath(); ctx.rect(b.x0 - 4 * s.u, b.y0, b.W + 8 * s.u + (o.dx || 0), b.h); ctx.clip(); }
    ctx.font = font(s, b.px, s.p.waga); ctx.fillStyle = o.k1 || s.k.t; ctx.globalAlpha = s.alfa * clamp(e1 * 2); ctx.fillText(tekstP(s, s.p.tekst), x1, ty + (1 - e1) * b.h * (o.ruch == null ? 0.6 : o.ruch));
    if (s.p.tekst2) { ctx.font = font(s, b.px * 0.52, 500); ctx.fillStyle = o.k2 || rgba(s.k.t, 0.82); ctx.globalAlpha = s.alfa * clamp(e2 * 2); ctx.fillText(s.p.tekst2, x2, b.y0 + b.h * 0.73 + (1 - e2) * b.h * (o.ruch == null ? 0.6 : o.ruch)); }
    ctx.restore(); ctx.globalAlpha = s.alfa;
  }
  function belkaN(id, nazwa, przyklad, fn, o = {}) {
    dodaj({ id, nazwa, kat: "belki", czas: o.czas || 4, pola: o.pola || ["tekst", "tekst2"], dom: Object.assign({ pozycja: "lewy-dol" }, o.dom || {}), przyklad, rysuj: fn });
  }
  const T = (s, od, dl) => okno(s.t, od / s.p.tempo, dl / s.p.tempo);
  belkaN("belka-skos", "Belka ukośna", { tekst: "Kasia Wiśniewska", tekst2: "Fotografka ślubna" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 56 * s.u * s.p.rozmiar, 40), a = E.outQuint(T(s, 0, 0.6)), sk = b.h * 0.35;
    ctx.save(); cien(s); ctx.fillStyle = s.k.g; ctx.beginPath(); const w = (b.W + sk) * a;
    ctx.moveTo(b.x0 + sk, b.y0); ctx.lineTo(b.x0 + sk + w, b.y0); ctx.lineTo(b.x0 + w, b.y0 + b.h); ctx.lineTo(b.x0, b.y0 + b.h); ctx.closePath(); ctx.fill(); ctx.restore();
    belkaTekst(s, b, E.outCubic(T(s, 0.25, 0.5)), E.outCubic(T(s, 0.4, 0.5)), { dx: sk * 0.5, k1: kontrast(s.k.g), k2: rgba(kontrast(s.k.g), 0.8) });
  });
  belkaN("belka-dwa-paski", "Dwa paski z przeciwnych stron", { tekst: "Piotr Zieliński", tekst2: "Trener personalny" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 56 * s.u * s.p.rozmiar), a = E.outQuint(T(s, 0, 0.55)), c = E.outQuint(T(s, 0.12, 0.55)), h1 = b.h * 0.58;
    ctx.fillStyle = s.k.g; ctx.fillRect(b.x0 - (1 - a) * s.W * 0.5, b.y0, b.W, h1);
    ctx.fillStyle = s.k.tl; ctx.fillRect(b.x0 + (1 - c) * s.W * 0.5, b.y0 + h1, b.W * 0.85, b.h - h1);
    const p = prawa(s); ctx.save(); ctx.globalAlpha = s.alfa * clamp(a * 2); ctx.font = font(s, b.px, s.p.waga); ctx.fillStyle = kontrast(s.k.g); ctx.fillText(tekstP(s, s.p.tekst), p ? b.x0 + b.W - b.pad - b.m.w1 : b.x0 + b.pad, b.y0 + h1 / 2);
    if (s.p.tekst2) { ctx.globalAlpha = s.alfa * clamp(c * 2); ctx.font = font(s, b.px * 0.48, 600); ctx.fillStyle = s.k.t; ctx.fillText(s.p.tekst2, p ? b.x0 + b.W * 0.85 - b.pad - b.m.w2 * 0.92 : b.x0 + b.pad, b.y0 + h1 + (b.h - h1) / 2); } ctx.restore();
  }, { });
  belkaN("belka-live", "Belka z kropką na żywo", { tekst: "NA ŻYWO", tekst2: "Gala Biznesu 2026" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 50 * s.u * s.p.rozmiar, 30, s.p.tekst2 ? 1.6 : 1.4), a = E.outBackMocno(T(s, 0, 0.45)), r = b.px * 0.22;
    const W1 = b.m.w1 + b.pad * 2 + r * 3; ctx.save(); ctx.translate(b.x0, b.y0 + b.h / 2); ctx.scale(a, a); cien(s);
    ctx.fillStyle = "#E11D48"; zaokr(ctx, 0, -b.px * 0.7, W1, b.px * 1.4, b.px * 0.7); ctx.fill(); bezCienia(ctx);
    ctx.fillStyle = "#FFFFFF"; ctx.globalAlpha = s.alfa * (0.55 + 0.45 * Math.round((Math.sin(s.t * 6) + 1) / 2)); ctx.beginPath(); ctx.arc(b.pad + r, 0, r, 0, PI * 2); ctx.fill(); ctx.globalAlpha = s.alfa;
    ctx.font = font(s, b.px, 800); ctx.fillText(tekstP(s, s.p.tekst), b.pad + r * 3, 0);
    if (s.p.tekst2) { const e2 = E.outCubic(T(s, 0.3, 0.5)); ctx.globalAlpha = s.alfa * e2; ctx.font = font(s, b.px * 0.8, 600); ctx.fillStyle = s.k.t; ctx.fillText(s.p.tekst2, W1 + 24 * s.u - (1 - e2) * 30 * s.u, 0); }
    ctx.restore();
  }, { pola: ["tekst", "tekst2"] });
  belkaN("belka-pionowa-linia", "Pionowa linia i tekst", { tekst: "Ola Lewandowska", tekst2: "Architektka wnętrz" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 60 * s.u * s.p.rozmiar, 34), a = E.outQuint(T(s, 0, 0.5)), p = prawa(s);
    ctx.fillStyle = s.k.a; const lx = p ? b.x0 + b.W : b.x0; ctx.fillRect(lx - 4 * s.u, b.y0 + b.h / 2 - b.h / 2 * a, 8 * s.u, b.h * a);
    belkaTekst(s, b, E.outCubic(T(s, 0.25, 0.6)), E.outCubic(T(s, 0.4, 0.6)), { ruch: 0 , klip: false });
    ctx.save(); ctx.globalAlpha = 1; ctx.restore();
  });
  belkaN("belka-szklo", "Belka jak matowe szkło", { tekst: "Tomasz Kamiński", tekst2: "Założyciel, Studio Kadr" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 54 * s.u * s.p.rozmiar, 34), a = E.outBack(T(s, 0, 0.55));
    ctx.save(); ctx.translate(b.x0 + b.W / 2, b.y0 + b.h / 2); ctx.scale(lerp(0.9, 1, a), lerp(0.9, 1, a)); ctx.globalAlpha = s.alfa * clamp(a * 1.5);
    ctx.fillStyle = "rgba(255,255,255,0.16)"; zaokr(ctx, -b.W / 2, -b.h / 2, b.W, b.h, 22 * s.u); ctx.fill();
    ctx.strokeStyle = "rgba(255,255,255,0.45)"; ctx.lineWidth = 2 * s.u; ctx.stroke(); ctx.restore();
    belkaTekst(s, b, E.outCubic(T(s, 0.2, 0.5)), E.outCubic(T(s, 0.35, 0.5)), { ruch: 0.3 });
  });
  belkaN("belka-podkreslenie", "Nazwisko z podkreśleniem", { tekst: "Michał Wójcik", tekst2: "Szef kuchni" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 62 * s.u * s.p.rozmiar, 0), a = E.inOutCubic(T(s, 0.15, 0.6)), p = prawa(s);
    belkaTekst(s, b, E.outCubic(T(s, 0, 0.5)), E.outCubic(T(s, 0.35, 0.5)), { ruch: 0.4 });
    ctx.fillStyle = s.k.a; const y = b.y0 + b.h * (s.p.tekst2 ? 0.56 : 0.82), w = b.m.w1 * a; ctx.fillRect(p ? b.x0 + b.W - w : b.x0, y, w, 6 * s.u * s.p.rozmiar);
  });
  belkaN("belka-ramka", "Belka w ramce", { tekst: "Agnieszka Dąbrowska", tekst2: "Psycholog" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 54 * s.u * s.p.rozmiar, 30), e = E.inOutCubic(T(s, 0, 0.8));
    ctx.strokeStyle = s.k.g; ctx.lineWidth = 5 * s.u; sciezkaCzesc(ctx, [[b.x0, b.y0], [b.x0 + b.W, b.y0], [b.x0 + b.W, b.y0 + b.h], [b.x0, b.y0 + b.h], [b.x0, b.y0]], e); ctx.stroke();
    belkaTekst(s, b, E.outCubic(T(s, 0.3, 0.5)), E.outCubic(T(s, 0.45, 0.5)));
  });
  belkaN("belka-od-srodka", "Belka rozsuwa się od środka", { tekst: "Jakub Mazur", tekst2: "Reżyser" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 56 * s.u * s.p.rozmiar), a = E.outQuint(T(s, 0, 0.6));
    ctx.save(); cien(s); ctx.fillStyle = s.k.tl; ctx.fillRect(b.x0 + b.W / 2 * (1 - a), b.y0, b.W * a, b.h); ctx.restore();
    ctx.fillStyle = s.k.g; ctx.fillRect(b.x0 + b.W / 2 * (1 - a), b.y0 + b.h - 6 * s.u, b.W * a, 6 * s.u);
    belkaTekst(s, b, E.outCubic(T(s, 0.3, 0.5)), E.outCubic(T(s, 0.42, 0.5)), { ruch: 0 });
  });
  belkaN("belka-social-handle", "Imię i nazwa konta", { tekst: "Zuza Gotuje", tekst2: "@zuzagotuje" }, (s) => {
    const ctx = s.ctx, px = 52 * s.u * s.p.rozmiar, b = belkaUklad(s, px, 28, 1.5), r = b.h * 0.42, a = E.outBackMocno(T(s, 0, 0.45)), e = E.outQuint(T(s, 0.15, 0.6));
    const W = b.W + r * 2 + 20 * s.u, x0 = prawa(s) ? s.poz.x - W : s.poz.x;
    ctx.save(); cien(s); ctx.fillStyle = s.k.tl; zaokr(ctx, x0, b.y0, (W) * e, b.h, b.h / 2); ctx.fill(); ctx.restore();
    ctx.save(); ctx.translate(x0 + b.h / 2, b.y0 + b.h / 2); ctx.scale(a, a); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill();
    ctx.font = font(s, r * 1.05, 800); ctx.fillStyle = kontrast(s.k.g); const ini = String(s.p.tekst || "?").trim().split(/\s+/).map((x) => x[0]).join("").slice(0, 2).toUpperCase(); const iw = ctx.measureText(ini).width; ctx.fillText(ini, -iw / 2, 0); ctx.restore();
    const bb = Object.assign({}, b, { x0: x0 + r * 2 + 8 * s.u, W: b.W }); belkaTekst(s, bb, E.outCubic(T(s, 0.3, 0.5)), E.outCubic(T(s, 0.42, 0.5)), { k2: s.k.a });
  });
  belkaN("belka-news", "Pasek informacyjny", { tekst: "PILNE", tekst2: "Rusza nabór do programu dla młodych twórców" }, (s) => {
    const ctx = s.ctx, px = 44 * s.u * s.p.rozmiar, h = px * 1.8, y0 = s.poz.y - h / 2, a = E.outQuint(T(s, 0, 0.5)), c = E.outQuint(T(s, 0.2, 0.6));
    ctx.font = font(s, px, 900); const w1 = ctx.measureText(tekstP(s, s.p.tekst)).width + 50 * s.u;
    ctx.fillStyle = rgba(s.k.tl, 0.95); ctx.fillRect(0, y0, s.W * c, h);
    ctx.fillStyle = "#DC2626"; ctx.fillRect(0, y0, w1 * a, h);
    ctx.save(); ctx.beginPath(); ctx.rect(0, y0, s.W, h); ctx.clip(); ctx.fillStyle = "#FFFFFF"; ctx.fillText(tekstP(s, s.p.tekst), 25 * s.u - (1 - a) * w1, y0 + h / 2);
    ctx.font = font(s, px * 0.85, 600); ctx.fillStyle = s.k.t; const tw = ctx.measureText(s.p.tekst2 || "").width, dost = s.W - w1 - 40 * s.u;
    const przes = tw > dost ? -Math.max(0, s.t - 1.2) * 120 * s.u : 0; ctx.beginPath(); ctx.rect(w1, y0, s.W - w1, h); ctx.clip();
    ctx.globalAlpha = s.alfa * clamp(c * 2); ctx.fillText(s.p.tekst2 || "", w1 + 24 * s.u + przes + (1 - c) * 60 * s.u, y0 + h / 2); ctx.restore();
  }, { dom: { pozycja: "dol" }, czas: 5 });
  belkaN("belka-podcast", "Belka podcastu z mikrofonem", { tekst: "Rozmowy o pieniądzach", tekst2: "odc. 24 · gość: Ewa Nowicka" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 50 * s.u * s.p.rozmiar, 30, 2.2), a = E.outBackMocno(T(s, 0, 0.45)), e = E.outQuint(T(s, 0.1, 0.6)), r = b.h * 0.44;
    const x0 = prawa(s) ? s.poz.x - b.W - b.h : s.poz.x;
    ctx.save(); cien(s); ctx.fillStyle = s.k.tl; zaokr(ctx, x0, b.y0, (b.W + b.h) * e, b.h, 18 * s.u); ctx.fill(); ctx.restore();
    ctx.save(); ctx.translate(x0 + b.h / 2, b.y0 + b.h / 2); ctx.scale(a, a); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill();
    ctx.fillStyle = kontrast(s.k.g); zaokr(ctx, -r * 0.2, -r * 0.55, r * 0.4, r * 0.7, r * 0.2); ctx.fill(); ctx.strokeStyle = kontrast(s.k.g); ctx.lineWidth = r * 0.09;
    ctx.beginPath(); ctx.arc(0, -r * 0.1, r * 0.33, 0, PI); ctx.stroke(); ctx.beginPath(); ctx.moveTo(0, r * 0.23); ctx.lineTo(0, r * 0.5); ctx.stroke(); ctx.restore();
    // fala dźwięku
    ctx.fillStyle = s.k.a; for (let i = 0; i < 5; i++) { const hh = (0.3 + 0.7 * Math.abs(Math.sin(s.t * 7 + i * 1.3))) * b.h * 0.25 * e; ctx.fillRect(x0 + b.h + b.W - 70 * s.u + i * 11 * s.u, b.y0 + b.h * 0.3 - hh / 2, 6 * s.u, hh); }
    belkaTekst(s, Object.assign({}, b, { x0: x0 + b.h - 10 * s.u }), E.outCubic(T(s, 0.3, 0.5)), E.outCubic(T(s, 0.45, 0.5)));
  });
  belkaN("belka-lokalizacja", "Lokalizacja z pinezką", { tekst: "Zakopane", tekst2: "Tatry, Polska" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 60 * s.u * s.p.rozmiar, 0), a = E.outBounce(T(s, 0, 0.7)), r = b.px * 0.42, px0 = prawa(s) ? b.x0 + b.W + r * 1.6 : b.x0;
    ctx.save(); ctx.translate(px0, b.y0 + b.h / 2 - (1 - a) * 200 * s.u); cien(s); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, -r * 0.4, r, PI * 0.85, PI * 2.15); ctx.lineTo(0, r * 1.3); ctx.closePath(); ctx.fill();
    bezCienia(ctx); ctx.fillStyle = kontrast(s.k.g); ctx.beginPath(); ctx.arc(0, -r * 0.4, r * 0.4, 0, PI * 2); ctx.fill(); ctx.restore();
    belkaTekst(s, Object.assign({}, b, { x0: b.x0 + (prawa(s) ? 0 : r * 1.6) }), E.outCubic(T(s, 0.35, 0.5)), E.outCubic(T(s, 0.5, 0.5)));
  });
  belkaN("belka-etykieta-nad", "Etykieta nad nazwiskiem", { tekst: "Marta Kowalczyk", tekst2: "GOŚĆ ODCINKA" }, (s) => {
    const ctx = s.ctx, px = 62 * s.u * s.p.rozmiar, p = prawa(s); ctx.font = font(s, px, s.p.waga); const w1 = ctx.measureText(tekstP(s, s.p.tekst)).width;
    ctx.font = font(s, px * 0.42, 800); const w2 = ctx.measureText(s.p.tekst2 || "").width + 30 * s.u, h2 = px * 0.75;
    const x = p ? s.poz.x - w1 : s.poz.x, y = s.poz.y, a = E.outBackMocno(T(s, 0, 0.4)), e = E.outQuint(T(s, 0.2, 0.6));
    ctx.save(); ctx.translate(p ? s.poz.x - w2 : x, y - px * 1.05); ctx.scale(a, a); ctx.fillStyle = s.k.a; zaokr(ctx, 0, -h2 / 2, w2, h2, 6 * s.u); ctx.fill();
    ctx.fillStyle = kontrast(s.k.a); ctx.fillText(s.p.tekst2 || "", 15 * s.u, 0); ctx.restore();
    ctx.save(); ctx.beginPath(); ctx.rect(x - 10 * s.u, y - px * 0.7, w1 + 20 * s.u, px * 1.4); ctx.clip(); cien(s); ctx.font = font(s, px, s.p.waga); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), x, y + (1 - e) * px * 1.3); ctx.restore();
  });
  belkaN("belka-numer", "Belka z numerem", { tekst: "Jak zacząć oszczędzać", tekst2: "01" }, (s) => {
    const ctx = s.ctx, px = 54 * s.u * s.p.rozmiar, h = px * 1.7, p = prawa(s); ctx.font = font(s, px, s.p.waga); const w = ctx.measureText(tekstP(s, s.p.tekst)).width + 60 * s.u;
    const kw = h, x0 = p ? s.poz.x - w - kw : s.poz.x, y0 = s.poz.y - h / 2, a = E.outBackMocno(T(s, 0, 0.45)), e = E.outQuint(T(s, 0.2, 0.6));
    ctx.save(); cien(s); ctx.fillStyle = s.k.tl; ctx.fillRect(x0 + kw, y0, w * e, h); ctx.restore();
    ctx.save(); ctx.translate(x0 + kw / 2, y0 + h / 2); ctx.scale(a, a); ctx.fillStyle = s.k.g; ctx.fillRect(-kw / 2, -h / 2, kw, h);
    ctx.font = font(s, px * 1.1, 900); ctx.fillStyle = kontrast(s.k.g); const nw = ctx.measureText(s.p.tekst2 || "").width; ctx.fillText(s.p.tekst2 || "", -nw / 2, 0); ctx.restore();
    ctx.save(); ctx.beginPath(); ctx.rect(x0 + kw, y0, w, h); ctx.clip(); ctx.font = font(s, px, s.p.waga); ctx.fillStyle = s.k.t; ctx.fillText(tekstP(s, s.p.tekst), x0 + kw + 30 * s.u - (1 - e) * w, y0 + h / 2); ctx.restore();
  });
  belkaN("belka-gradient", "Belka z przenikaniem koloru", { tekst: "Natalia Wrona", tekst2: "Wokalistka" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 58 * s.u * s.p.rozmiar, 34), a = E.outQuint(T(s, 0, 0.7)), p = prawa(s);
    const g = ctx.createLinearGradient(p ? b.x0 + b.W : b.x0, 0, p ? b.x0 - b.W * 0.4 : b.x0 + b.W * 1.4, 0); g.addColorStop(0, rgba(s.k.g, 0.95)); g.addColorStop(1, rgba(s.k.g, 0));
    ctx.fillStyle = g; ctx.fillRect(p ? b.x0 + b.W - (b.W * 1.4) * a : b.x0, b.y0, b.W * 1.4 * a, b.h);
    belkaTekst(s, b, E.outCubic(T(s, 0.2, 0.5)), E.outCubic(T(s, 0.35, 0.5)), { k1: kontrast(s.k.g), k2: rgba(kontrast(s.k.g), 0.8) });
  });
  belkaN("belka-kafelki", "Nazwisko i stanowisko na kafelkach", { tekst: "Adam Krawczyk", tekst2: "CEO" }, (s) => {
    const ctx = s.ctx, px = 54 * s.u * s.p.rozmiar, p = prawa(s), h = px * 1.6; ctx.font = font(s, px, s.p.waga); const w1 = ctx.measureText(tekstP(s, s.p.tekst)).width + 50 * s.u;
    ctx.font = font(s, px * 0.62, 800); const w2 = s.p.tekst2 ? ctx.measureText(s.p.tekst2).width + 40 * s.u : 0;
    const x0 = p ? s.poz.x - w1 - w2 - 10 * s.u : s.poz.x, y0 = s.poz.y - h / 2, a = E.outBackMocno(T(s, 0, 0.45)), c = E.outBackMocno(T(s, 0.15, 0.45));
    const kaf = (x, w, kol, tk, t, f, e) => { ctx.save(); ctx.translate(x + w / 2, y0 + h / 2); ctx.scale(1, e); cien(s); ctx.fillStyle = kol; zaokr(ctx, -w / 2, -h / 2, w, h, 10 * s.u); ctx.fill(); bezCienia(ctx); ctx.font = f; ctx.fillStyle = tk; const tw = ctx.measureText(t).width; ctx.fillText(t, -tw / 2, 0); ctx.restore(); };
    kaf(x0, w1, s.k.tl, s.k.t, tekstP(s, s.p.tekst), font(s, px, s.p.waga), a);
    if (s.p.tekst2) kaf(x0 + w1 + 10 * s.u, w2, s.k.a, kontrast(s.k.a), s.p.tekst2, font(s, px * 0.62, 800), c);
  });
  belkaN("belka-maszyna", "Belka pisana na klawiaturze", { tekst: "Karol Szymański", tekst2: "programista" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 52 * s.u * s.p.rozmiar, 30), e = E.outQuint(T(s, 0, 0.45)), p = prawa(s);
    ctx.fillStyle = rgba(s.k.tl, 0.9); ctx.fillRect(b.x0, b.y0, b.W * e, b.h);
    const t1 = tekstP(s, s.p.tekst), t2 = s.p.tekst2 || "", n1 = Math.floor(clamp((s.t - 0.4 / s.p.tempo) / (t1.length * 0.05 / s.p.tempo)) * t1.length), n2 = Math.floor(clamp((s.t - 0.5 / s.p.tempo - t1.length * 0.05 / s.p.tempo) / (Math.max(1, t2.length) * 0.04 / s.p.tempo)) * t2.length);
    const ty = s.p.tekst2 ? b.y0 + b.h * 0.37 : b.y0 + b.h / 2;
    ctx.font = font(s, b.px, s.p.waga); ctx.fillStyle = s.k.t; ctx.fillText(t1.slice(0, n1), b.x0 + b.pad, ty);
    ctx.font = font(s, b.px * 0.52, 500); ctx.fillStyle = s.k.a; ctx.fillText(t2.slice(0, n2), b.x0 + b.pad, b.y0 + b.h * 0.73);
    if (Math.floor(s.t * 2.5) % 2 === 0) { ctx.font = font(s, n2 > 0 || n1 >= t1.length ? b.px * 0.52 : b.px, 500); const tt = n2 > 0 || n1 >= t1.length ? t2.slice(0, n2) : t1.slice(0, n1); const xw = ctx.measureText(tt).width; ctx.fillStyle = s.k.a; ctx.fillRect(b.x0 + b.pad + xw + 4 * s.u, (n2 > 0 || n1 >= t1.length ? b.y0 + b.h * 0.73 : ty) - b.px * 0.3, 4 * s.u, b.px * 0.6); }
    void p;
  });
  belkaN("belka-minimal-kreska", "Mała kreska i tekst", { tekst: "Joanna Pawlak", tekst2: "Projektantka mody" }, (s) => {
    const ctx = s.ctx, b = belkaUklad(s, 50 * s.u * s.p.rozmiar, 0), a = E.inOutCubic(T(s, 0, 0.5)), p = prawa(s);
    ctx.fillStyle = s.k.a; const kw = 60 * s.u * a; ctx.fillRect(p ? b.x0 + b.W - kw : b.x0, b.y0 - 14 * s.u, kw, 5 * s.u);
    belkaTekst(s, b, E.outCubic(T(s, 0.25, 0.6)), E.outCubic(T(s, 0.4, 0.6)), { ruch: 0.5 });
  });

  // ---------- grafiki do rolek (v17) ----------
  function ikonaN(id, nazwa, fn, o = {}) {
    dodaj({ id, nazwa, kat: "rolki", czas: o.czas || 3, pola: o.pola || ["tekst"], dom: Object.assign({ pozycja: "srodek" }, o.dom || {}), przyklad: o.przyklad || {}, rysuj: fn });
  }
  function podpis(s, y, e, px, pole) {
    const tx = s.p[pole || "tekst"]; if (!tx) return; const ctx = s.ctx, u = uloz(s, tx, (px || 64) * s.u * s.p.rozmiar, { y, gora: true, align: "center", x: s.poz.x });
    ctx.save(); ctx.font = u.font; ctx.globalAlpha = s.alfa * clamp(e * 2); cien(s); u.slowa.forEach((w) => piszSlowo(s, w, null, ctx, 0, (1 - e) * 30 * s.u)); ctx.restore();
  }
  const R0 = (s, k) => (k || 120) * s.u * s.p.rozmiar;
  ikonaN("kciuk", "Kciuk w górę", (s) => {
    const ctx = s.ctx, r = R0(s, 130), a = E.outBackMocno(T(s, 0, 0.5)), ob = Math.sin(clamp(s.t * 3) * PI) * 0.25;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.rotate(-ob); cien(s); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); bezCienia(ctx);
    ctx.fillStyle = kontrast(s.k.g); zaokr(ctx, -r * 0.55, -r * 0.05, r * 0.25, r * 0.6, r * 0.06); ctx.fill(); zaokr(ctx, -r * 0.25, -r * 0.1, r * 0.75, r * 0.65, r * 0.15); ctx.fill();
    ctx.beginPath(); ctx.moveTo(-r * 0.22, -r * 0.05); ctx.lineTo(r * 0.02, -r * 0.6); ctx.quadraticCurveTo(r * 0.2, -r * 0.62, r * 0.17, -r * 0.35); ctx.lineTo(r * 0.12, -r * 0.08); ctx.closePath(); ctx.fill(); ctx.restore();
    podpis(s, s.poz.y + r * 1.3, E.outCubic(T(s, 0.35, 0.5)));
  }, { przyklad: { tekst: "Dobra robota!" } });
  ikonaN("wykrzyknik", "Wykrzyknik uwaga", (s) => {
    const ctx = s.ctx, r = R0(s, 130), a = E.outBackMocno(T(s, 0, 0.45)), dr = Math.sin(s.t * 30) * 0.05 * (1 - clamp(s.t - 0.4));
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.rotate(dr); cien(s); ctx.fillStyle = "#FACC15"; ctx.beginPath(); ctx.moveTo(0, -r); ctx.lineTo(r * 1.05, r * 0.75); ctx.lineTo(-r * 1.05, r * 0.75); ctx.closePath(); ctx.lineJoin = "round"; ctx.lineWidth = r * 0.18; ctx.strokeStyle = "#FACC15"; ctx.stroke(); ctx.fill(); bezCienia(ctx);
    ctx.fillStyle = "#111"; zaokr(ctx, -r * 0.09, -r * 0.45, r * 0.18, r * 0.75, r * 0.08); ctx.fill(); ctx.beginPath(); ctx.arc(0, r * 0.5, r * 0.11, 0, PI * 2); ctx.fill(); ctx.restore();
    podpis(s, s.poz.y + r * 1.25, E.outCubic(T(s, 0.3, 0.5)));
  }, { przyklad: { tekst: "Uważaj na *to*" } });
  ikonaN("zarowka", "Żarówka pomysł", (s) => {
    const ctx = s.ctx, r = R0(s, 110), a = E.outBackMocno(T(s, 0, 0.5)), sw = okno(s.t, 0.45 / s.p.tempo, 0.2);
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a);
    if (sw > 0) { ctx.strokeStyle = rgba(s.k.a, sw); ctx.lineWidth = r * 0.08; ctx.lineCap = "round"; for (let i = 0; i < 8; i++) { const an = -PI / 2 + (i - 3.5) * 0.42; ctx.beginPath(); ctx.moveTo(Math.cos(an) * r * 1.25, Math.sin(an) * r * 1.25 - r * 0.2); ctx.lineTo(Math.cos(an) * r * (1.25 + 0.35 * sw), Math.sin(an) * r * (1.25 + 0.35 * sw) - r * 0.2); ctx.stroke(); } }
    cien(s); ctx.fillStyle = sw > 0 ? s.k.a : "#9CA3AF"; ctx.beginPath(); ctx.arc(0, -r * 0.2, r * 0.8, PI * 0.8, PI * 2.2); ctx.lineTo(r * 0.35, r * 0.75); ctx.lineTo(-r * 0.35, r * 0.75); ctx.closePath(); ctx.fill(); bezCienia(ctx);
    ctx.fillStyle = "#6B7280"; zaokr(ctx, -r * 0.38, r * 0.78, r * 0.76, r * 0.18, r * 0.06); ctx.fill(); zaokr(ctx, -r * 0.3, r * 1.0, r * 0.6, r * 0.16, r * 0.06); ctx.fill(); ctx.restore();
    podpis(s, s.poz.y + r * 1.6, E.outCubic(T(s, 0.6, 0.5)));
  }, { przyklad: { tekst: "Mam *pomysł*" } });
  ikonaN("dzwonek", "Dzwonek powiadomień", (s) => {
    const ctx = s.ctx, r = R0(s, 110), a = E.outBackMocno(T(s, 0, 0.45)), dz = Math.sin(s.t * 18) * 0.35 * Math.max(0, 1 - Math.abs(s.t - 0.9) * 2);
    ctx.save(); ctx.translate(s.poz.x, s.poz.y - r * 0.6); ctx.scale(a, a); ctx.rotate(dz); cien(s); ctx.fillStyle = s.k.a; ctx.beginPath();
    ctx.moveTo(-r * 0.75, r * 1.2); ctx.quadraticCurveTo(-r * 0.6, r * 0.9, -r * 0.6, r * 0.4); ctx.quadraticCurveTo(-r * 0.6, -r * 0.25, 0, -r * 0.25); ctx.quadraticCurveTo(r * 0.6, -r * 0.25, r * 0.6, r * 0.4); ctx.quadraticCurveTo(r * 0.6, r * 0.9, r * 0.75, r * 1.2); ctx.closePath(); ctx.fill();
    ctx.beginPath(); ctx.arc(0, r * 1.32, r * 0.17, 0, PI * 2); ctx.fill(); ctx.beginPath(); ctx.arc(0, -r * 0.32, r * 0.1, 0, PI * 2); ctx.fill(); bezCienia(ctx); ctx.restore();
    const b = E.outBackMocno(T(s, 0.7, 0.4)); if (b > 0) { ctx.save(); ctx.translate(s.poz.x + r * 0.55, s.poz.y - r * 0.85); ctx.scale(b, b); ctx.fillStyle = "#EF4444"; ctx.beginPath(); ctx.arc(0, 0, r * 0.3, 0, PI * 2); ctx.fill(); ctx.font = font(s, r * 0.36, 800); ctx.fillStyle = "#fff"; const w = ctx.measureText("1").width; ctx.fillText("1", -w / 2, 0); ctx.restore(); }
    podpis(s, s.poz.y + r * 1.25, E.outCubic(T(s, 0.5, 0.5)));
  }, { przyklad: { tekst: "Włącz *powiadomienia*" } });
  ikonaN("koszyk", "Koszyk zakupowy", (s) => {
    const ctx = s.ctx, r = R0(s, 110), e = E.outQuint(T(s, 0, 0.7)), x = lerp(-s.W * 0.2, s.poz.x, e);
    ctx.save(); ctx.translate(x, s.poz.y); ctx.rotate((1 - e) * -0.15); cien(s); ctx.strokeStyle = s.k.g; ctx.lineWidth = r * 0.13; ctx.lineJoin = "round"; ctx.lineCap = "round";
    ctx.beginPath(); ctx.moveTo(-r * 1.1, -r * 0.7); ctx.lineTo(-r * 0.8, -r * 0.7); ctx.lineTo(-r * 0.5, r * 0.4); ctx.lineTo(r * 0.8, r * 0.4); ctx.lineTo(r * 1.0, -r * 0.4); ctx.lineTo(-r * 0.7, -r * 0.4); ctx.stroke();
    ctx.fillStyle = s.k.g; [-0.35, 0.65].forEach((k) => { ctx.beginPath(); ctx.arc(r * k, r * 0.68, r * 0.14, 0, PI * 2); ctx.fill(); });
    const b = E.outBounce(T(s, 0.55, 0.6)); if (b > 0) { ctx.fillStyle = s.k.a; zaokr(ctx, -r * 0.3, -r * 0.4 - (1 - b) * r * 1.5 - r * 0.45, r * 0.6, r * 0.55, r * 0.08); ctx.fill(); }
    ctx.restore(); podpis(s, s.poz.y + r * 1.15, E.outCubic(T(s, 0.7, 0.5)));
  }, { przyklad: { tekst: "Dodane do *koszyka*" } });
  ikonaN("odznaka-procent", "Gwiazda promocji -50%", (s) => {
    const ctx = s.ctx, r = R0(s, 160), a = E.outBackMocno(T(s, 0, 0.5));
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.rotate(s.t * 0.4 - 0.2); cien(s); ctx.fillStyle = s.k.g; gwiazda(ctx, 0, 0, 16, r, r * 0.84); ctx.fill(); bezCienia(ctx); ctx.rotate(-(s.t * 0.4 - 0.2) - 0.12);
    const t = tekstP(s, s.p.tekst), px = dopasuj(s, t, r * 0.7, r * 1.5, 900); ctx.font = font(s, px, 900); ctx.fillStyle = kontrast(s.k.g); const w = ctx.measureText(t).width; ctx.fillText(t, -w / 2, -px * 0.1);
    if (s.p.tekst2) { ctx.font = font(s, px * 0.35, 700); const w2 = ctx.measureText(s.p.tekst2).width; ctx.fillText(s.p.tekst2, -w2 / 2, px * 0.55); } ctx.restore();
  }, { pola: ["tekst", "tekst2"], przyklad: { tekst: "-50%", tekst2: "tylko dziś" } });
  ikonaN("stara-nowa-cena", "Stara cena przekreślona, nowa wskakuje", (s) => {
    const ctx = s.ctx, px = 110 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y;
    const a = E.outCubic(T(s, 0, 0.4)); ctx.font = font(s, px * 0.6, 700); const t1 = s.p.tekst || "", w1 = ctx.measureText(t1).width;
    ctx.globalAlpha = s.alfa * a; ctx.fillStyle = rgba(s.k.t, 0.7); ctx.fillText(t1, cx - w1 / 2, cy - px * 0.6); ctx.globalAlpha = s.alfa;
    const k = E.inOutCubic(T(s, 0.45, 0.35)); ctx.strokeStyle = "#EF4444"; ctx.lineWidth = 8 * s.u; ctx.beginPath(); ctx.moveTo(cx - w1 / 2 - 10 * s.u, cy - px * 0.55); ctx.lineTo(cx - w1 / 2 - 10 * s.u + (w1 + 20 * s.u) * k, cy - px * 0.65); ctx.stroke();
    const b = E.outBackMocno(T(s, 0.85, 0.45)); if (b > 0) { ctx.save(); ctx.translate(cx, cy + px * 0.35); ctx.scale(b, b); cien(s); ctx.font = font(s, px, 900); const t2 = s.p.tekst2 || ""; const w2 = ctx.measureText(t2).width; ctx.fillStyle = s.k.a; ctx.fillText(t2, -w2 / 2, 0); ctx.restore(); }
  }, { pola: ["tekst", "tekst2"], przyklad: { tekst: "299 zł", tekst2: "149 zł" } });
  ikonaN("mit-fakt", "Mit czy fakt", (s) => {
    const ctx = s.ctx, px = 80 * s.u * s.p.rozmiar, cx = s.poz.x, cy = s.poz.y, a = E.outBackMocno(T(s, 0, 0.4)), zm = s.t > 1.3 / s.p.tempo;
    const t = zm ? "FAKT" : "MIT", kol = zm ? "#22C55E" : "#EF4444", fl = Math.abs(Math.cos(clamp((s.t - 1.15 / s.p.tempo) / 0.3) * PI));
    ctx.save(); ctx.translate(cx, cy - px * 0.9); ctx.scale(a, a * (s.t > 1.15 / s.p.tempo && s.t < 1.45 / s.p.tempo ? Math.max(0.05, fl) : 1)); cien(s); ctx.font = font(s, px, 900); const w = ctx.measureText(t).width + 70 * s.u;
    ctx.fillStyle = kol; zaokr(ctx, -w / 2, -px * 0.7, w, px * 1.4, 16 * s.u); ctx.fill(); bezCienia(ctx); ctx.fillStyle = "#fff"; ctx.fillText(t, -w / 2 + 35 * s.u, 0); ctx.restore();
    podpis(s, cy + px * 0.3, E.outCubic(T(s, 0.3, 0.5)), 60);
  }, { przyklad: { tekst: "Kawa odwadnia organizm" }, czas: 3.5 });
  ikonaN("podium", "Podium TOP 3", (s) => {
    const ctx = s.ctx, el = lista(s.p.lista), w = 190 * s.u * s.p.rozmiar, wys = [260, 200, 150].map((x) => x * s.u * s.p.rozmiar), kol = [s.k.a, s.k.g, ciemniej(s.k.g, 0.3)];
    const ord = [1, 0, 2], baza = s.poz.y + 200 * s.u;
    ord.forEach((m, j) => {
      const e = E.outBackMocno(T(s, 0.15 + (2 - m) * 0.25, 0.5)); if (e <= 0) return; const x = s.poz.x + (j - 1) * (w + 10 * s.u) - w / 2, h = wys[m] * e;
      ctx.save(); cien(s); ctx.fillStyle = kol[m]; ctx.fillRect(x, baza - h, w, h); bezCienia(ctx); ctx.font = font(s, w * 0.42, 900); ctx.fillStyle = kontrast(kol[m]); const nt = String(m + 1), nw = ctx.measureText(nt).width; ctx.fillText(nt, x + w / 2 - nw / 2, baza - h + w * 0.32);
      if (el[m]) { const px = dopasuj(s, el[m], 44 * s.u * s.p.rozmiar, w * 1.05, 700); ctx.font = font(s, px, 700); ctx.fillStyle = s.k.t; const tw = ctx.measureText(el[m]).width; ctx.fillText(el[m], x + w / 2 - tw / 2, baza - h - px * 0.9); }
      ctx.restore();
    });
  }, { pola: ["lista"], przyklad: { lista: "Kraków\nGdańsk\nWrocław" }, czas: 3.5 });
  ikonaN("naklejka-nowosc", "Obrotowa naklejka NOWOŚĆ", (s) => {
    const ctx = s.ctx, r = R0(s, 140), a = E.outBackMocno(T(s, 0, 0.5)), t = tekstP(s, s.p.tekst || "NOWOŚĆ") + " • ", m = r + 30 * s.u;
    ctx.save(); ctx.translate(clamp(s.poz.x, m, s.W - m), clamp(s.poz.y, m, s.H - m)); ctx.scale(a, a); cien(s); ctx.fillStyle = s.k.g; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); bezCienia(ctx);
    ctx.rotate(s.t * 0.9); ctx.font = font(s, r * 0.2, 800); ctx.fillStyle = kontrast(s.k.g); const pow = (t + t).split(""), kat = (PI * 2) / pow.length;
    pow.forEach((c, i) => { ctx.save(); ctx.rotate(i * kat); ctx.translate(0, -r * 0.78); ctx.fillText(c, -ctx.measureText(c).width / 2, 0); ctx.restore(); });
    ctx.rotate(-s.t * 0.9); ctx.fillStyle = s.k.a; gwiazda(ctx, 0, 0, 5, r * 0.4, r * 0.18, -PI / 2); ctx.fill(); ctx.restore();
  }, { przyklad: { tekst: "NOWOŚĆ" }, dom: { pozycja: "prawy-gora" } });
  ikonaN("equalizer", "Słupki dźwięku", (s) => {
    const ctx = s.ctx, n = 11, w = 26 * s.u * s.p.rozmiar, H = 220 * s.u * s.p.rozmiar, a = E.outCubic(T(s, 0, 0.4));
    for (let i = 0; i < n; i++) { const h = H * a * (0.25 + 0.75 * Math.abs(Math.sin(s.t * (3 + los(i) * 4) + i))); const x = s.poz.x + (i - (n - 1) / 2) * w * 1.6 - w / 2;
      ctx.fillStyle = i % 3 === 1 ? s.k.a : s.k.g; zaokr(ctx, x, s.poz.y - h / 2, w, h, w / 2); ctx.fill(); }
    podpis(s, s.poz.y + H * 0.7, E.outCubic(T(s, 0.3, 0.5)));
  }, { przyklad: { tekst: "Podgłośnij!" }, czas: 4 });
  ikonaN("dymek-pisze", "Ktoś pisze…", (s) => {
    const ctx = s.ctx, r = 60 * s.u * s.p.rozmiar, a = E.outBackMocno(T(s, 0, 0.4)), w = r * 3.4, h = r * 1.6;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); cien(s); ctx.fillStyle = "#E5E7EB"; zaokr(ctx, -w / 2, -h / 2, w, h, h / 2); ctx.fill(); ctx.beginPath(); ctx.arc(-w / 2 + r * 0.25, h / 2 - r * 0.1, r * 0.3, 0, PI * 2); ctx.fill(); bezCienia(ctx);
    for (let i = 0; i < 3; i++) { const sk = 0.6 + 0.4 * Math.max(0, Math.sin(s.t * 7 - i * 0.9)); ctx.fillStyle = "#6B7280"; ctx.beginPath(); ctx.arc((i - 1) * r * 0.85, 0, r * 0.24 * sk, 0, PI * 2); ctx.fill(); }
    ctx.restore(); podpis(s, s.poz.y + h, E.outCubic(T(s, 0.3, 0.5)), 54);
  }, { przyklad: { tekst: "Odpowiedź za chwilę" } });
  ikonaN("wiadomosc", "Wiadomość SMS", (s) => {
    const ctx = s.ctx, px = 46 * s.u * s.p.rozmiar, a = E.outBackMocno(T(s, 0, 0.45)), u = uloz(s, s.p.tekst, px, { maxW: s.W * 0.6, align: "left", x: 0, y: 0, gora: true, waga: 500 });
    const w = u.w + 56 * s.u, h = u.h + 40 * s.u, x0 = s.poz.x - w / 2, y0 = s.poz.y - h / 2;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y + h / 2); ctx.scale(a, a); ctx.translate(-s.poz.x, -s.poz.y - h / 2); cien(s); ctx.fillStyle = s.k.g; zaokr(ctx, x0, y0, w, h, 30 * s.u); ctx.fill();
    ctx.beginPath(); ctx.moveTo(x0 + w - 30 * s.u, y0 + h - 4 * s.u); ctx.quadraticCurveTo(x0 + w + 10 * s.u, y0 + h + 6 * s.u, x0 + w + 16 * s.u, y0 + h); ctx.quadraticCurveTo(x0 + w, y0 + h - 10 * s.u, x0 + w - 4 * s.u, y0 + h - 30 * s.u); ctx.fill(); bezCienia(ctx);
    ctx.font = u.font; u.slowa.forEach((sl) => { ctx.fillStyle = sl.wyr ? s.k.a : kontrast(s.k.g); ctx.fillText(sl.t, x0 + 28 * s.u + sl.x, y0 + 20 * s.u + sl.y); });
    ctx.restore();
    const b = E.outCubic(T(s, 0.6, 0.3)); if (b > 0) { ctx.globalAlpha = s.alfa * b; ctx.font = font(s, px * 0.5, 600); ctx.fillStyle = rgba(s.k.t, 0.8); const tt = "Dostarczono"; ctx.fillText(tt, x0 + w - ctx.measureText(tt).width, y0 + h + px * 0.8); ctx.globalAlpha = s.alfa; }
  }, { przyklad: { tekst: "Hej, widziałeś już *nowy* odcinek?" } });
  ikonaN("reakcje", "Reakcje wylatują w górę", (s) => {
    const ctx = s.ctx, em = Array.from(s.p.emoji || "😍🔥👏😂❤️"), n = 18;
    for (let i = 0; i < n; i++) { const st = los(i * 3.3) * (s.T - 1.4), e = okno(s.t, st, 1.4); if (e <= 0 || e >= 1) continue;
      const x = s.poz.x + (los(i * 7.1) - 0.5) * s.W * 0.5 + Math.sin(e * 6 + i) * 30 * s.u, y = s.H * 0.85 - e * s.H * 0.55, sk = (0.6 + los(i) * 0.6) * s.p.rozmiar;
      ctx.globalAlpha = s.alfa * (1 - E.inCubic(e)); ctx.font = `${Math.round(70 * s.u * sk)}px "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif`; ctx.fillText(em[i % em.length], x, y); }
    ctx.globalAlpha = s.alfa;
  }, { pola: ["emoji"], przyklad: { emoji: "😍🔥👏😂❤️" }, czas: 4 });
  ikonaN("kadr-celownik", "Zaznaczenie kadru narożnikami", (s) => {
    const ctx = s.ctx, [cx, cy] = punkt(s), w = 360 * s.u * s.p.rozmiar, h = 300 * s.u * s.p.rozmiar, e = E.outBackMocno(T(s, 0, 0.5)), k = 60 * s.u, sk = lerp(1.8, 1, e);
    ctx.save(); ctx.translate(cx, cy); ctx.scale(sk, sk); ctx.globalAlpha = s.alfa * clamp(e * 2); ctx.strokeStyle = s.k.a; ctx.lineWidth = 8 * s.u; ctx.lineCap = "round";
    [[-1, -1], [1, -1], [1, 1], [-1, 1]].forEach(([a, b]) => { ctx.beginPath(); ctx.moveTo(a * w / 2, b * h / 2 - b * k); ctx.lineTo(a * w / 2, b * h / 2); ctx.lineTo(a * w / 2 - a * k, b * h / 2); ctx.stroke(); });
    ctx.restore(); if (s.p.tekst) { const e2 = E.outCubic(T(s, 0.4, 0.4)); ctx.save(); ctx.globalAlpha = s.alfa * e2; ctx.font = font(s, 44 * s.u * s.p.rozmiar, 800); const tw = ctx.measureText(s.p.tekst).width + 30 * s.u;
      ctx.fillStyle = s.k.a; ctx.fillRect(cx - w / 2, cy - h / 2 - 70 * s.u, tw, 56 * s.u); ctx.fillStyle = kontrast(s.k.a); ctx.fillText(s.p.tekst, cx - w / 2 + 15 * s.u, cy - h / 2 - 42 * s.u); ctx.restore(); }
  }, { pola: ["tekst", "xy"], przyklad: { tekst: "TU PATRZ", x: 0.5, y: 0.45 } });
  ikonaN("klawisze", "Skrót klawiszowy", (s) => {
    const ctx = s.ctx, kl = String(s.p.tekst || "Ctrl+S").split("+").map((x) => x.trim()).filter(Boolean), px = 56 * s.u * s.p.rozmiar, h = px * 1.9; ctx.font = font(s, px, 700);
    const sz = kl.map((k) => Math.max(h, ctx.measureText(k).width + px)), plus = px * 1.1, cal = sz.reduce((a, b) => a + b, 0) + plus * (kl.length - 1); let x = s.poz.x - cal / 2;
    kl.forEach((k, i) => { const e = E.outBackMocno(T(s, i * 0.2, 0.4)), wc = okno(s.t, (0.9 + i * 0.05) / s.p.tempo, 0.15), wd = wc > 0 && wc < 1 ? 6 * s.u : 0;
      ctx.save(); ctx.translate(x + sz[i] / 2, s.poz.y + wd); ctx.scale(e, e); ctx.fillStyle = "#D1D5DB"; zaokr(ctx, -sz[i] / 2, -h / 2 + 10 * s.u - wd, sz[i], h, 16 * s.u); ctx.fill();
      ctx.fillStyle = "#F9FAFB"; zaokr(ctx, -sz[i] / 2, -h / 2, sz[i], h - 10 * s.u, 16 * s.u); ctx.fill(); ctx.fillStyle = "#111827"; const tw = ctx.measureText(k).width; ctx.fillText(k, -tw / 2, -5 * s.u); ctx.restore();
      x += sz[i]; if (i < kl.length - 1) { ctx.globalAlpha = s.alfa * E.outCubic(T(s, i * 0.2 + 0.1, 0.3)); ctx.fillStyle = s.k.t; ctx.fillText("+", x + plus / 2 - ctx.measureText("+").width / 2, s.poz.y); ctx.globalAlpha = s.alfa; x += plus; } });
  }, { przyklad: { tekst: "Ctrl + Shift + S" } });
  ikonaN("zrobione", "Zrobione: ptaszek w kole", (s) => {
    const ctx = s.ctx, r = R0(s, 120), a = E.outBackMocno(T(s, 0, 0.45)), k = E.inOutCubic(T(s, 0.3, 0.5));
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); cien(s); ctx.fillStyle = "#22C55E"; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); bezCienia(ctx); ctx.restore();
    ptaszek(ctx, s.poz.x, s.poz.y, r * 0.55, k, "#FFFFFF", r * 0.16);
    podpis(s, s.poz.y + r * 1.3, E.outCubic(T(s, 0.6, 0.5)));
  }, { przyklad: { tekst: "Gotowe!" } });
  ikonaN("krzyzyk", "Nie: krzyżyk w kole", (s) => {
    const ctx = s.ctx, r = R0(s, 120), a = E.outBackMocno(T(s, 0, 0.45)), k1 = E.inOutCubic(T(s, 0.3, 0.25)), k2 = E.inOutCubic(T(s, 0.5, 0.25)), d = r * 0.42;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.rotate(Math.sin(clamp((s.t - 0.75) * 3) * PI * 3) * 0.08); cien(s); ctx.fillStyle = "#EF4444"; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); bezCienia(ctx);
    ctx.strokeStyle = "#fff"; ctx.lineWidth = r * 0.17; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(-d, -d); ctx.lineTo(-d + 2 * d * k1, -d + 2 * d * k1); ctx.stroke(); if (k2 > 0) { ctx.beginPath(); ctx.moveTo(d, -d); ctx.lineTo(d - 2 * d * k2, -d + 2 * d * k2); ctx.stroke(); } ctx.restore();
    podpis(s, s.poz.y + r * 1.3, E.outCubic(T(s, 0.6, 0.5)));
  }, { przyklad: { tekst: "Tego *nie* rób" } });
  ikonaN("kalendarz", "Kartka z kalendarza", (s) => {
    const ctx = s.ctx, w = 260 * s.u * s.p.rozmiar, h = w * 1.05, a = E.outBackMocno(T(s, 0, 0.5)), [d, ...mies] = String(s.p.tekst || "24 grudnia").split(/\s+/);
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.rotate((1 - a) * 0.3); cien(s); ctx.fillStyle = "#FFFFFF"; zaokr(ctx, -w / 2, -h / 2, w, h, 24 * s.u); ctx.fill(); bezCienia(ctx);
    ctx.save(); ctx.beginPath(); zaokr(ctx, -w / 2, -h / 2, w, h, 24 * s.u); ctx.clip(); ctx.fillStyle = s.k.g; ctx.fillRect(-w / 2, -h / 2, w, h * 0.3); ctx.restore();
    ctx.font = font(s, h * 0.13, 800); ctx.fillStyle = kontrast(s.k.g); const m = mies.join(" ").toLocaleUpperCase("pl"), mw = ctx.measureText(m).width; ctx.fillText(m, -mw / 2, -h * 0.35);
    ctx.font = font(s, h * 0.46, 900); ctx.fillStyle = "#111827"; const dw = ctx.measureText(d).width; ctx.fillText(d, -dw / 2, h * 0.15); ctx.restore();
    podpis(s, s.poz.y + h * 0.75, E.outCubic(T(s, 0.4, 0.5)), 56, "tekst2");
  }, { pola: ["tekst", "tekst2"], przyklad: { tekst: "24 grudnia", tekst2: "Wielka premiera" } });
  ikonaN("bateria", "Bateria się ładuje", (s) => {
    const ctx = s.ctx, w = 330 * s.u * s.p.rozmiar, h = w * 0.5, a = E.outBackMocno(T(s, 0, 0.4)), p = clamp((s.t - 0.4) / Math.max(0.5, s.T - 1.2)), poz = Math.min(4, Math.floor(p * 5));
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.strokeStyle = s.k.t; ctx.lineWidth = 10 * s.u; zaokr(ctx, -w / 2, -h / 2, w, h, 20 * s.u); ctx.stroke(); ctx.fillStyle = s.k.t; zaokr(ctx, w / 2 + 6 * s.u, -h * 0.18, 18 * s.u, h * 0.36, 6 * s.u); ctx.fill();
    const kw = (w - 40 * s.u) / 5; for (let i = 0; i <= poz; i++) { ctx.fillStyle = poz < 2 ? "#EF4444" : poz < 4 ? "#FACC15" : "#22C55E"; zaokr(ctx, -w / 2 + 14 * s.u + i * (kw + 3 * s.u), -h / 2 + 14 * s.u, kw - 3 * s.u, h - 28 * s.u, 6 * s.u); ctx.fill(); }
    ctx.restore(); podpis(s, s.poz.y + h * 0.9, E.outCubic(T(s, 0.3, 0.5)));
  }, { przyklad: { tekst: "Ładowanie *energii*…" }, czas: 4 });

  // ---------- liczby i wykresy (v17) ----------
  function liczbaN(id, nazwa, przyklad, fn, o = {}) { dodaj({ id, nazwa, kat: "liczby", czas: o.czas || 3.5, pola: o.pola || ["liczba", "od", "przed", "po", "tekst2"], dom: o.dom, przyklad, rysuj: fn }); }
  const wartosc = (s, e) => lerp(+s.p.od || 0, +s.p.liczba || 0, e);
  const liczbaT = (s, v) => `${s.p.przed || ""}${liczbaTekst(v, miejscaPo(s.p.liczba))}${s.p.po || ""}`;
  liczbaN("licznik-kolo", "Licznik w kole postępu", { liczba: 87, po: "%", tekst2: "zadowolonych klientów" }, (s) => {
    const ctx = s.ctx, r = 190 * s.u * s.p.rozmiar, e = E.outCubic(T(s, 0.1, 1.6)), a = E.outBack(T(s, 0, 0.4)), max = +s.p.max || 100;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); ctx.lineWidth = r * 0.16; ctx.lineCap = "round"; ctx.strokeStyle = rgba(s.k.t, 0.18); ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.stroke();
    ctx.strokeStyle = s.k.a; ctx.beginPath(); ctx.arc(0, 0, r, -PI / 2, -PI / 2 + PI * 2 * clamp(wartosc(s, e) / max)); ctx.stroke();
    const t = liczbaT(s, wartosc(s, e)); ctx.font = font(s, dopasuj(s, t, r * 0.72, r * 1.5, 900), 900); ctx.fillStyle = s.k.t; const w = ctx.measureText(t).width; ctx.fillText(t, -w / 2, 0); ctx.restore();
    podpis(s, s.poz.y + r * 1.35, E.outCubic(T(s, 0.6, 0.5)), 52, "tekst2");
  }, { pola: ["liczba", "od", "przed", "po", "tekst2"] });
  liczbaN("licznik-pasek", "Licznik z paskiem", { liczba: 72, po: "%", tekst2: "Ukończono kurs" }, (s) => {
    const ctx = s.ctx, W = s.W * 0.7 * s.p.rozmiar, h = 34 * s.u * s.p.rozmiar, e = E.outCubic(T(s, 0.2, 1.5)), a = E.outCubic(T(s, 0, 0.4)), x0 = s.poz.x - W / 2, max = +s.p.max || 100;
    ctx.globalAlpha = s.alfa * a; ctx.fillStyle = rgba(s.k.t, 0.2); zaokr(ctx, x0, s.poz.y, W, h, h / 2); ctx.fill();
    ctx.fillStyle = s.k.a; zaokr(ctx, x0, s.poz.y, Math.max(h, W * clamp(wartosc(s, e) / max)), h, h / 2); ctx.fill();
    const t = liczbaT(s, wartosc(s, e)); ctx.font = font(s, 110 * s.u * s.p.rozmiar, 900); ctx.fillStyle = s.k.t; cien(s); ctx.fillText(t, x0, s.poz.y - 80 * s.u * s.p.rozmiar);
    if (s.p.tekst2) { ctx.font = font(s, 46 * s.u * s.p.rozmiar, 600); ctx.fillText(s.p.tekst2, x0, s.poz.y + h + 50 * s.u); } ctx.globalAlpha = s.alfa;
  });
  liczbaN("licznik-pieniadze", "Rosnąca kwota", { liczba: 125000, po: " zł", tekst2: "przychodu w pierwszym roku" }, (s) => {
    const ctx = s.ctx, e = E.outQuint(T(s, 0.1, 1.8)), skok = 1 + 0.12 * Math.sin(clamp((s.t - 1.9 / s.p.tempo) * 4) * PI), t = liczbaT(s, Math.round(wartosc(s, e)));
    const px = dopasuj(s, t, 170 * s.u * s.p.rozmiar, s.W * 0.88, 900); ctx.font = font(s, px, 900); const w = ctx.measureText(t).width;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(skok, skok); cien(s, ctx, 1.5); ctx.fillStyle = "#22C55E"; ctx.fillText(t, -w / 2, 0); ctx.restore();
    for (let i = 0; i < 10; i++) { const st = 0.3 + los(i) * 1.6, k = okno(s.t, st, 1.2); if (k <= 0 || k >= 1) continue; ctx.globalAlpha = s.alfa * (1 - k); ctx.font = font(s, 60 * s.u, 900); ctx.fillStyle = s.k.a; ctx.fillText("$", s.poz.x + (los(i * 5) - 0.5) * s.W * 0.7, s.poz.y - k * 300 * s.u); }
    ctx.globalAlpha = s.alfa; podpis(s, s.poz.y + px * 0.8, E.outCubic(T(s, 0.5, 0.5)), 50, "tekst2");
  });
  liczbaN("strzalka-wzrost", "Strzałka wzrostu z procentem", { liczba: 340, przed: "+", po: "%", tekst2: "wzrost sprzedaży" }, (s) => {
    const ctx = s.ctx, W = 420 * s.u * s.p.rozmiar, H = 300 * s.u * s.p.rozmiar, e = E.inOutCubic(T(s, 0, 1)), x0 = s.poz.x - W / 2, y0 = s.poz.y + H / 2;
    const pkt = [[x0, y0], [x0 + W * 0.3, y0 - H * 0.35], [x0 + W * 0.5, y0 - H * 0.2], [x0 + W, y0 - H]]; ctx.strokeStyle = "#22C55E"; ctx.lineWidth = 18 * s.u * s.p.rozmiar; ctx.lineJoin = "round"; ctx.lineCap = "round"; cien(s);
    sciezkaCzesc(ctx, pkt, e); ctx.stroke(); if (e > 0.95) { ctx.fillStyle = "#22C55E"; ctx.save(); ctx.translate(x0 + W, y0 - H); ctx.rotate(Math.atan2(-H * 0.8, W * 0.5)); ctx.beginPath(); ctx.moveTo(30 * s.u, 0); ctx.lineTo(-25 * s.u, -30 * s.u); ctx.lineTo(-25 * s.u, 30 * s.u); ctx.closePath(); ctx.fill(); ctx.restore(); }
    bezCienia(ctx); const k = E.outCubic(T(s, 0.6, 1)), t = liczbaT(s, wartosc(s, k)); ctx.font = font(s, 120 * s.u * s.p.rozmiar, 900); ctx.fillStyle = s.k.t; cien(s); ctx.globalAlpha = s.alfa * clamp(k * 3); ctx.fillText(t, x0, y0 - H - 40 * s.u);
    ctx.globalAlpha = s.alfa; podpis(s, y0 + 50 * s.u, E.outCubic(T(s, 0.8, 0.5)), 50, "tekst2");
  });
  liczbaN("wykres-liniowy", "Wykres liniowy rysuje się", { lista: "Sty: 20\nLut: 35\nMar: 30\nKwi: 55\nMaj: 80", tekst: "Obserwujący (tys.)" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista), W = s.W * 0.78 * s.p.rozmiar, H = 420 * s.u * s.p.rozmiar, x0 = s.poz.x - W / 2, y0 = s.poz.y + H / 2, max = Math.max(1, ...d.map((x) => x.v));
    const e = E.inOutCubic(T(s, 0.3, 1.5)), a = E.outCubic(T(s, 0, 0.4)); ctx.globalAlpha = s.alfa * a; ctx.strokeStyle = rgba(s.k.t, 0.25); ctx.lineWidth = 2 * s.u;
    for (let i = 0; i <= 4; i++) { ctx.beginPath(); ctx.moveTo(x0, y0 - H * i / 4); ctx.lineTo(x0 + W, y0 - H * i / 4); ctx.stroke(); }
    const pkt = d.map((x, i) => [x0 + W * i / Math.max(1, d.length - 1), y0 - H * x.v / max]);
    ctx.strokeStyle = s.k.a; ctx.lineWidth = 9 * s.u; ctx.lineJoin = "round"; sciezkaCzesc(ctx, pkt, e); ctx.stroke();
    ctx.font = font(s, 34 * s.u * s.p.rozmiar, 600); d.forEach((x, i) => { const v = okno(e, i / Math.max(1, d.length - 1) - 0.02, 0.05); ctx.fillStyle = s.k.t; ctx.fillText(x.e, pkt[i][0] - ctx.measureText(x.e).width / 2, y0 + 40 * s.u);
      if (v > 0) { ctx.fillStyle = s.k.a; ctx.beginPath(); ctx.arc(pkt[i][0], pkt[i][1], 13 * s.u * E.outBack(v), 0, PI * 2); ctx.fill(); } });
    if (s.p.tekst) { ctx.font = font(s, 50 * s.u * s.p.rozmiar, 800); ctx.fillStyle = s.k.t; ctx.fillText(s.p.tekst, x0, y0 - H - 60 * s.u); } ctx.globalAlpha = s.alfa;
  }, { pola: ["lista", "tekst"], czas: 4 });
  liczbaN("wykres-poziomy", "Wykres słupkowy poziomy", { lista: "Instagram: 62\nTikTok: 81\nYouTube: 45\nFacebook: 30", po: "%" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista), W = s.W * 0.6 * s.p.rozmiar, h = 52 * s.u * s.p.rozmiar, lh = h * 1.9, max = Math.max(1, ...d.map((x) => x.v)), x0 = s.poz.x - W * 0.5, y0 = s.poz.y - (d.length - 1) * lh / 2;
    d.forEach((x, i) => { const e = E.outCubic(T(s, 0.2 + i * 0.15, 1)), y = y0 + i * lh; ctx.font = font(s, h * 0.7, 700); ctx.fillStyle = s.k.t; ctx.globalAlpha = s.alfa * clamp(e * 3); ctx.fillText(x.e, x0, y - h * 0.75);
      ctx.fillStyle = rgba(s.k.t, 0.15); zaokr(ctx, x0, y - h * 0.35, W, h * 0.7, h * 0.35); ctx.fill(); ctx.fillStyle = i % 2 ? s.k.g : s.k.a; zaokr(ctx, x0, y - h * 0.35, Math.max(h * 0.7, W * x.v / max * e), h * 0.7, h * 0.35); ctx.fill();
      const t = liczbaTekst(x.v * e) + (s.p.po || ""); ctx.fillStyle = s.k.t; ctx.fillText(t, x0 + W + 20 * s.u, y); });
    ctx.globalAlpha = s.alfa;
  }, { pola: ["lista", "po"], czas: 4 });
  liczbaN("ranking", "Ranking TOP 5", { lista: "Kraków\nWarszawa\nGdańsk\nPoznań\nWrocław", tekst: "Najlepsze miasta" }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista).slice(0, 8), px = 56 * s.u * s.p.rozmiar, lh = px * 1.75, x0 = s.W * 0.14, y0 = s.poz.y - (el.length - 1) * lh / 2;
    if (s.p.tekst) { const e = E.outCubic(T(s, 0, 0.4)); ctx.globalAlpha = s.alfa * e; ctx.font = font(s, px * 1.1, 900); ctx.fillStyle = s.k.a; ctx.fillText(tekstP(s, s.p.tekst), x0, y0 - lh * 1.2); }
    el.forEach((t, i) => { const j = el.length - 1 - i, e = E.outQuint(T(s, 0.25 + j * 0.18, 0.5)); if (e <= 0) return; const y = y0 + i * lh;
      ctx.globalAlpha = s.alfa * clamp(e * 2); ctx.save(); ctx.translate((1 - e) * -200 * s.u, 0); cien(s); ctx.fillStyle = i === 0 ? s.k.a : s.k.g; zaokr(ctx, x0, y - px * 0.65, px * 1.3, px * 1.3, 12 * s.u); ctx.fill(); bezCienia(ctx);
      ctx.font = font(s, px * 0.8, 900); ctx.fillStyle = kontrast(i === 0 ? s.k.a : s.k.g); const n = String(i + 1); ctx.fillText(n, x0 + px * 0.65 - ctx.measureText(n).width / 2, y);
      ctx.font = font(s, px, s.p.waga); ctx.fillStyle = s.k.t; cien(s); ctx.fillText(t, x0 + px * 1.6, y); ctx.restore(); });
    ctx.globalAlpha = s.alfa;
  }, { pola: ["lista", "tekst"], czas: 4.5, dom: { pozycja: "lewy-srodek" } });
  liczbaN("stoper", "Stoper odmierza czas", { liczba: 30, po: " s", tekst2: "tyle zajmuje przygotowanie" }, (s) => {
    const ctx = s.ctx, r = 170 * s.u * s.p.rozmiar, a = E.outBack(T(s, 0, 0.4)), e = clamp((s.t - 0.3) / Math.max(0.5, s.T - 1.2)), v = Math.round(lerp(+s.p.od || 0, +s.p.liczba || 0, e));
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); cien(s); ctx.fillStyle = "#FFFFFF"; ctx.beginPath(); ctx.arc(0, 0, r, 0, PI * 2); ctx.fill(); ctx.fillRect(-r * 0.15, -r * 1.25, r * 0.3, r * 0.2); bezCienia(ctx);
    ctx.strokeStyle = s.k.g; ctx.lineWidth = r * 0.08; ctx.beginPath(); ctx.arc(0, 0, r * 0.88, -PI / 2, -PI / 2 + PI * 2 * e); ctx.stroke();
    ctx.strokeStyle = "#111827"; ctx.lineWidth = r * 0.05; ctx.lineCap = "round"; ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(Math.cos(-PI / 2 + e * PI * 2 * 3) * r * 0.65, Math.sin(-PI / 2 + e * PI * 2 * 3) * r * 0.65); ctx.stroke();
    const t = `${s.p.przed || ""}${v}${s.p.po || ""}`; ctx.font = font(s, r * 0.42, 900); ctx.fillStyle = "#111827"; ctx.fillText(t, -ctx.measureText(t).width / 2, r * 0.45); ctx.restore();
    podpis(s, s.poz.y + r * 1.35, E.outCubic(T(s, 0.4, 0.5)), 50, "tekst2");
  }, { czas: 4 });
  liczbaN("ludziki", "9 na 10 osób", { liczba: 9, tekst2: "na 10 osób poleca nas znajomym" }, (s) => {
    const ctx = s.ctx, n = 10, w = 78 * s.u * s.p.rozmiar, ile = Math.round(+s.p.liczba || 0), x0 = s.poz.x - (n * w) / 2;
    for (let i = 0; i < n; i++) { const e = E.outBackMocno(T(s, i * 0.07, 0.4)); if (e <= 0) continue; const x = x0 + i * w + w / 2, y = s.poz.y, k = i < ile && s.t > (0.8 + i * 0.08) / s.p.tempo;
      ctx.save(); ctx.translate(x, y); ctx.scale(e, e); ctx.fillStyle = k ? s.k.a : rgba(s.k.t, 0.3); ctx.beginPath(); ctx.arc(0, -w * 0.45, w * 0.2, 0, PI * 2); ctx.fill(); zaokr(ctx, -w * 0.28, -w * 0.2, w * 0.56, w * 0.7, w * 0.22); ctx.fill(); ctx.restore(); }
    const t = `${ile}/10`; ctx.font = font(s, 140 * s.u * s.p.rozmiar, 900); ctx.fillStyle = s.k.a; cien(s); const a = E.outBack(T(s, 1.3, 0.4)); if (a > 0) { ctx.save(); ctx.translate(s.poz.x, s.poz.y - 200 * s.u * s.p.rozmiar); ctx.scale(a, a); ctx.fillText(t, -ctx.measureText(t).width / 2, 0); ctx.restore(); }
    podpis(s, s.poz.y + 90 * s.u * s.p.rozmiar, E.outCubic(T(s, 1.4, 0.5)), 48, "tekst2");
  }, { pola: ["liczba", "tekst2"], czas: 4 });
  liczbaN("mnoznik", "Mnożnik x3", { liczba: 3, przed: "x", tekst2: "szybsza praca" }, (s) => {
    const ctx = s.ctx, px = 280 * s.u * s.p.rozmiar, n = Math.max(1, Math.round(+s.p.liczba || 1)), krok = 0.35 / s.p.tempo, i = Math.min(n, 1 + Math.floor(s.t / krok)), lok = (s.t % krok) / krok;
    const sk = s.t < n * krok ? lerp(1.5, 1, E.outBack(lok)) : 1, t = `${s.p.przed || ""}${i}${s.p.po || ""}`; ctx.font = font(s, px, 900); const w = ctx.measureText(t).width;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(sk, sk); ctx.rotate(-0.06); cien(s, ctx, 2); ctx.fillStyle = s.k.a; ctx.fillText(t, -w / 2, 0); ctx.restore();
    podpis(s, s.poz.y + px * 0.6, E.outCubic(okno(s.t, n * krok, 0.4)), 60, "tekst2");
  }, { pola: ["liczba", "przed", "po", "tekst2"] });
  liczbaN("procent-donut", "Wykres kołowy z podziałem", { lista: "Wideo: 55\nZdjęcia: 30\nTekst: 15", tekst: "Co działa najlepiej" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista), r = 200 * s.u * s.p.rozmiar, suma = d.reduce((a, x) => a + x.v, 0) || 1, e = E.inOutCubic(T(s, 0.2, 1.3)), kol = [s.k.a, s.k.g, ciemniej(s.k.g, 0.35), "#9CA3AF", "#E5E7EB"];
    let k0 = -PI / 2; const cx = s.poz.x, cy = s.poz.y - 60 * s.u; ctx.lineWidth = r * 0.42;
    d.forEach((x, i) => { const k1 = k0 + (x.v / suma) * PI * 2; const kk = Math.min(k1, -PI / 2 + PI * 2 * e); if (kk > k0) { ctx.strokeStyle = kol[i % kol.length]; ctx.beginPath(); ctx.arc(cx, cy, r, k0, kk); ctx.stroke(); } k0 = k1; });
    ctx.font = font(s, 40 * s.u * s.p.rozmiar, 700); d.forEach((x, i) => { const a = E.outCubic(T(s, 1 + i * 0.15, 0.4)); ctx.globalAlpha = s.alfa * a; const y = cy + r * 1.45 + i * 60 * s.u * s.p.rozmiar; ctx.fillStyle = kol[i % kol.length]; ctx.fillRect(cx - r, y - 15 * s.u, 30 * s.u, 30 * s.u);
      ctx.fillStyle = s.k.t; ctx.fillText(`${x.e} ${Math.round(x.v / suma * 100)}%`, cx - r + 50 * s.u, y); });
    ctx.globalAlpha = s.alfa; if (s.p.tekst) { ctx.font = font(s, 56 * s.u * s.p.rozmiar, 800); ctx.fillStyle = s.k.t; const w = ctx.measureText(s.p.tekst).width; ctx.fillText(s.p.tekst, cx - w / 2, cy - r * 1.5); }
  }, { pola: ["lista", "tekst"], czas: 4 });
  liczbaN("porownanie-slupki", "Porównanie: my i konkurencja", { lista: "Konkurencja: 40\n*My*: 95", po: "%" }, (s) => {
    const ctx = s.ctx, d = pary(s.p.lista).slice(0, 2), H = 460 * s.u * s.p.rozmiar, w = 180 * s.u * s.p.rozmiar, max = Math.max(1, ...d.map((x) => x.v)), baza = s.poz.y + H / 2;
    d.forEach((x, i) => { const e = E.outBackMocno(T(s, 0.2 + i * 0.35, 0.8)), cx = s.poz.x + (i ? 1 : -1) * w * 0.85, h = H * x.v / max * Math.max(0, e), wyr = /\*/.test(x.e) || i === 1, nz = x.e.replace(/\*/g, "");
      ctx.fillStyle = wyr ? s.k.a : rgba(s.k.t, 0.35); zaokr(ctx, cx - w / 2, baza - h, w, h, 14 * s.u); ctx.fill(); ctx.font = font(s, 48 * s.u * s.p.rozmiar, 900); ctx.fillStyle = s.k.t; const t = liczbaTekst(x.v * clamp(e)) + (s.p.po || "");
      ctx.fillText(t, cx - ctx.measureText(t).width / 2, baza - h - 40 * s.u); ctx.font = font(s, 40 * s.u * s.p.rozmiar, 700); ctx.fillText(nz, cx - ctx.measureText(nz).width / 2, baza + 45 * s.u); });
  }, { pola: ["lista", "po"], czas: 3.5 });
  liczbaN("dni-do", "Ile dni zostało", { liczba: 7, tekst2: "dni do premiery" }, (s) => {
    const ctx = s.ctx, n = Math.round(+s.p.liczba || 0), start = n + 5, e = E.outQuint(T(s, 0.1, 1.4)), v = Math.round(lerp(start, n, e)), w = 170 * s.u * s.p.rozmiar, h = w * 1.3;
    String(v).padStart(2, "0").split("").forEach((c, i, arr) => { const x = s.poz.x + (i - (arr.length - 1) / 2) * (w + 18 * s.u); ctx.save(); ctx.translate(x, s.poz.y); cien(s); ctx.fillStyle = s.k.tl; zaokr(ctx, -w / 2, -h / 2, w, h, 18 * s.u); ctx.fill(); bezCienia(ctx);
      ctx.fillStyle = rgba("#000", 0.35); ctx.fillRect(-w / 2, -2 * s.u, w, 4 * s.u); ctx.font = font(s, h * 0.7, 900); ctx.fillStyle = s.k.a; ctx.fillText(c, -ctx.measureText(c).width / 2, 0); ctx.restore(); });
    podpis(s, s.poz.y + h * 0.75, E.outCubic(T(s, 0.6, 0.5)), 56, "tekst2");
  }, { pola: ["liczba", "tekst2"] });
  liczbaN("ocena", "Ocena 4,9 z gwiazdkami", { liczba: 4.9, tekst2: "na podstawie 1 200 opinii" }, (s) => {
    const ctx = s.ctx, r = 46 * s.u * s.p.rozmiar, v = +s.p.liczba || 5, e = E.outCubic(T(s, 0.1, 1.2)), wart = lerp(0, v, e);
    ctx.font = font(s, 170 * s.u * s.p.rozmiar, 900); const t = liczbaTekst(wart, 1); ctx.fillStyle = s.k.t; cien(s); ctx.fillText(t, s.poz.x - ctx.measureText(t).width / 2, s.poz.y - 80 * s.u * s.p.rozmiar); bezCienia(ctx);
    for (let i = 0; i < 5; i++) { const a = E.outBackMocno(T(s, 0.3 + i * 0.12, 0.4)); if (a <= 0) continue; const x = s.poz.x + (i - 2) * r * 2.4, y = s.poz.y + 60 * s.u * s.p.rozmiar;
      ctx.save(); ctx.translate(x, y); ctx.scale(a, a); ctx.fillStyle = rgba(s.k.t, 0.25); gwiazda(ctx, 0, 0, 5, r, r * 0.45, -PI / 2); ctx.fill(); ctx.save(); ctx.beginPath(); ctx.rect(-r, -r, r * 2 * clamp(wart - i), r * 2); ctx.clip(); ctx.fillStyle = "#FACC15"; gwiazda(ctx, 0, 0, 5, r, r * 0.45, -PI / 2); ctx.fill(); ctx.restore(); ctx.restore(); }
    podpis(s, s.poz.y + 150 * s.u * s.p.rozmiar, E.outCubic(T(s, 0.8, 0.5)), 44, "tekst2");
  }, { pola: ["liczba", "tekst2"] });
  liczbaN("tabela-przed-po", "Tabela przed i po", { lista: "Czas montażu: 8 h → 2 h\nKoszt: 2000 zł → 600 zł\nRolki w tygodniu: 1 → 5", tekst: "Przed → Po" }, (s) => {
    const ctx = s.ctx, el = lista(s.p.lista).map((x) => x.split(/→|->/).map((y) => y.trim())), px = 44 * s.u * s.p.rozmiar, lh = px * 2.4, W = s.W * 0.84, x0 = s.poz.x - W / 2, y0 = s.poz.y - (el.length - 1) * lh / 2;
    el.forEach((r, i) => { const e = E.outQuint(T(s, 0.2 + i * 0.25, 0.6)); if (e <= 0) return; const y = y0 + i * lh; const m = r[0].match(/^(.*?):\s*(.*)$/), et = m ? m[1] : "", przed = m ? m[2] : r[0], po = r[1] || "";
      ctx.globalAlpha = s.alfa * clamp(e * 2); ctx.fillStyle = rgba(s.k.tl, 0.85); zaokr(ctx, x0, y - lh * 0.42, W * e, lh * 0.84, 14 * s.u); ctx.fill();
      ctx.font = font(s, px * 0.7, 600); ctx.fillStyle = rgba(s.k.t, 0.7); ctx.fillText(et, x0 + 24 * s.u, y - px * 0.5);
      ctx.font = font(s, px, 800); ctx.fillStyle = rgba(s.k.t, 0.75); ctx.fillText(przed, x0 + 24 * s.u, y + px * 0.4); const pw = ctx.measureText(przed).width;
      ctx.fillStyle = s.k.a; ctx.fillText("→", x0 + 50 * s.u + pw, y + px * 0.4); ctx.fillText(po, x0 + 70 * s.u + pw + ctx.measureText("→").width, y + px * 0.4); });
    ctx.globalAlpha = s.alfa;
  }, { pola: ["lista", "tekst"], czas: 4.5 });

  // ---------- wezwania do działania (v17) ----------
  function ctaN(id, nazwa, przyklad, fn, o = {}) { dodaj({ id, nazwa, kat: "cta", czas: o.czas || 3, pola: o.pola || ["tekst", "tekst2"], dom: Object.assign({ pozycja: "dol" }, o.dom || {}), przyklad, rysuj: fn }); }
  function przycisk(s, t, cx, cy, px, kol, e, o = {}) {
    const ctx = s.ctx; ctx.font = font(s, px, 800); const w = ctx.measureText(t).width + px * 1.6 + (o.ikona ? px * 1.2 : 0), h = px * 1.9;
    ctx.save(); ctx.translate(cx, cy); ctx.scale(e, e); cien(s); ctx.fillStyle = kol; zaokr(ctx, -w / 2, -h / 2, w, h, o.r == null ? h / 2 : o.r); ctx.fill(); bezCienia(ctx);
    ctx.fillStyle = o.kt || kontrast(kol); ctx.fillText(t, -w / 2 + px * 0.8 + (o.ikona ? px * 1.2 : 0), 0); if (o.ikona) o.ikona(ctx, -w / 2 + px * 1.1, 0, px * 0.5, o.kt || kontrast(kol)); ctx.restore();
    return { w, h };
  }
  const ikZakladka = (c, x, y, r, k) => { c.fillStyle = k; c.beginPath(); c.moveTo(x - r * 0.6, y - r); c.lineTo(x + r * 0.6, y - r); c.lineTo(x + r * 0.6, y + r); c.lineTo(x, y + r * 0.45); c.lineTo(x - r * 0.6, y + r); c.closePath(); c.fill(); };
  const ikStrzalka = (c, x, y, r, k) => { c.strokeStyle = k; c.lineWidth = r * 0.35; c.lineCap = "round"; c.lineJoin = "round"; c.beginPath(); c.moveTo(x - r * 0.8, y + r * 0.6); c.quadraticCurveTo(x - r * 0.6, y - r * 0.5, x + r * 0.7, y - r * 0.4); c.stroke(); c.beginPath(); c.moveTo(x + r * 0.2, y - r * 0.9); c.lineTo(x + r * 0.8, y - r * 0.4); c.lineTo(x + r * 0.2, y + r * 0.1); c.stroke(); };
  const ikDymek = (c, x, y, r, k) => { c.fillStyle = k; c.beginPath(); c.ellipse(x, y - r * 0.1, r, r * 0.8, 0, 0, PI * 2); c.fill(); c.beginPath(); c.moveTo(x - r * 0.6, y + r * 0.4); c.lineTo(x - r * 0.9, y + r); c.lineTo(x - r * 0.1, y + r * 0.6); c.fill(); };
  const ikTelefon = (c, x, y, r, k) => { c.strokeStyle = k; c.lineWidth = r * 0.45; c.lineCap = "round"; c.beginPath(); c.arc(x, y, r * 0.8, PI * 0.6, PI * 1.4); c.stroke(); };
  const ikKoszyk = (c, x, y, r, k) => { c.strokeStyle = k; c.lineWidth = r * 0.25; c.lineJoin = "round"; c.beginPath(); c.moveTo(x - r, y - r * 0.6); c.lineTo(x - r * 0.6, y + r * 0.4); c.lineTo(x + r * 0.8, y + r * 0.4); c.lineTo(x + r, y - r * 0.3); c.closePath(); c.stroke(); c.fillStyle = k; c.beginPath(); c.arc(x - r * 0.4, y + r * 0.85, r * 0.2, 0, PI * 2); c.arc(x + r * 0.6, y + r * 0.85, r * 0.2, 0, PI * 2); c.fill(); };
  const ikPobierz = (c, x, y, r, k) => { c.strokeStyle = k; c.lineWidth = r * 0.3; c.lineCap = "round"; c.lineJoin = "round"; c.beginPath(); c.moveTo(x, y - r); c.lineTo(x, y + r * 0.4); c.moveTo(x - r * 0.55, y - r * 0.1); c.lineTo(x, y + r * 0.45); c.lineTo(x + r * 0.55, y - r * 0.1); c.moveTo(x - r, y + r); c.lineTo(x + r, y + r); c.stroke(); };
  const ikDM = (c, x, y, r, k) => { c.fillStyle = k; c.beginPath(); c.moveTo(x - r, y - r * 0.2); c.lineTo(x + r, y - r); c.lineTo(x + r * 0.3, y + r); c.lineTo(x, y + r * 0.1); c.closePath(); c.fill(); };
  ctaN("cta-zapisz-post", "Zapisz post na później", { tekst: "Zapisz na później", tekst2: "przyda się!" }, (s) => {
    const e = E.outBackMocno(T(s, 0, 0.45)), klik = s.t > 1.2 / s.p.tempo, nac = Math.abs(s.t - 1.2 / s.p.tempo) < 0.1 ? 0.9 : 1, px = 54 * s.u * s.p.rozmiar;
    przycisk(s, klik ? (s.p.tekst2 || "Zapisane ✓") : s.p.tekst, s.poz.x, s.poz.y, px, klik ? s.k.a : "#FFFFFF", e * nac, { ikona: ikZakladka, kt: klik ? kontrast(s.k.a) : "#111" });
    const m = E.inOutCubic(T(s, 0.4, 0.75)); if (s.t < 1.5 / s.p.tempo) kursor(s.ctx, lerp(s.poz.x + 260 * s.u, s.poz.x - 60 * s.u, m), lerp(s.poz.y + 260 * s.u, s.poz.y + 20 * s.u, m), 1.5 * s.u * s.p.rozmiar);
  });
  ctaN("cta-udostepnij", "Udostępnij znajomemu", { tekst: "Wyślij znajomemu", tekst2: "który musi to zobaczyć" }, (s) => {
    const e = E.outBackMocno(T(s, 0, 0.45)), px = 54 * s.u * s.p.rozmiar, k = Math.sin(s.t * 5) * 6 * s.u;
    przycisk(s, s.p.tekst, s.poz.x + k * 0, s.poz.y, px, s.k.g, e, { ikona: ikStrzalka });
    podpis(Object.assign({}, s, { p: Object.assign({}, s.p, { tekst: s.p.tekst2 }) }), s.poz.y + px * 1.5, E.outCubic(T(s, 0.4, 0.5)), 44);
  });
  ctaN("cta-komentarz", "Napisz w komentarzu", { tekst: "Napisz „TAK” w komentarzu", tekst2: "wyślę Ci poradnik" }, (s) => {
    const e = E.outBackMocno(T(s, 0, 0.45)), px = 52 * s.u * s.p.rozmiar, b = Math.sin(s.t * 4) * 0.04 + 1;
    przycisk(s, s.p.tekst, s.poz.x, s.poz.y, px, s.k.g, e * b, { ikona: ikDymek });
    podpis(Object.assign({}, s, { p: Object.assign({}, s.p, { tekst: s.p.tekst2 }) }), s.poz.y + px * 1.5, E.outCubic(T(s, 0.4, 0.5)), 44);
  });
  ctaN("cta-link-w-bio", "Link w bio ze strzałką", { tekst: "Link w bio", tekst2: "" }, (s) => {
    const ctx = s.ctx, e = E.outBackMocno(T(s, 0, 0.45)), px = 64 * s.u * s.p.rozmiar; przycisk(s, s.p.tekst, s.poz.x, s.poz.y, px, s.k.a, e);
    for (let i = 0; i < 3; i++) { const f = ((s.t * 1.4 + i / 3) % 1), y = s.poz.y - px * 1.4 - f * 160 * s.u; ctx.globalAlpha = s.alfa * e * Math.sin(f * PI); ctx.strokeStyle = s.k.t; ctx.lineWidth = 10 * s.u; ctx.lineCap = "round"; ctx.lineJoin = "round";
      ctx.beginPath(); ctx.moveTo(s.poz.x - 40 * s.u, y + 30 * s.u); ctx.lineTo(s.poz.x, y - 10 * s.u); ctx.lineTo(s.poz.x + 40 * s.u, y + 30 * s.u); ctx.stroke(); }
    ctx.globalAlpha = s.alfa;
  }, { pola: ["tekst"], czas: 3.5 });
  ctaN("cta-przesun", "Przesuń w górę", { tekst: "Przesuń w górę", tekst2: "" }, (s) => {
    const ctx = s.ctx, a = E.outCubic(T(s, 0, 0.4)), f = (s.t * 0.9) % 1, r = 46 * s.u * s.p.rozmiar, y = s.poz.y + 80 * s.u - E.inOutCubic(f) * 220 * s.u;
    ctx.globalAlpha = s.alfa * a * Math.sin(f * PI); ctx.fillStyle = "rgba(255,255,255,0.9)"; ctx.beginPath(); ctx.arc(s.poz.x, y, r, 0, PI * 2); ctx.fill();
    ctx.fillStyle = rgba("#FFFFFF", 0.25); zaokr(ctx, s.poz.x - r * 0.3, y, r * 0.6, E.inOutCubic(f) * 220 * s.u, r * 0.3); ctx.fill(); ctx.globalAlpha = s.alfa * a;
    ctx.font = font(s, 52 * s.u * s.p.rozmiar, 800); ctx.fillStyle = s.k.t; cien(s); const t = tekstP(s, s.p.tekst); ctx.fillText(t, s.poz.x - ctx.measureText(t).width / 2, s.poz.y + 200 * s.u); ctx.globalAlpha = s.alfa;
  }, { pola: ["tekst"], czas: 3.5 });
  ctaN("cta-kliknij-link", "Kliknij przycisk z kursorem", { tekst: "Sprawdź ofertę", tekst2: "" }, (s) => {
    const ctx = s.ctx, e = E.outBackMocno(T(s, 0, 0.45)), klik = 1.2 / s.p.tempo, nac = Math.abs(s.t - klik) < 0.1 ? 0.9 : 1, px = 58 * s.u * s.p.rozmiar;
    przycisk(s, s.p.tekst, s.poz.x, s.poz.y, px, s.k.g, e * nac, { r: 16 * s.u, ikona: ikStrzalka });
    if (s.t > klik) { const r = okno(s.t, klik, 0.5); ctx.strokeStyle = rgba("#FFFFFF", 1 - r); ctx.lineWidth = 5 * s.u; ctx.beginPath(); ctx.arc(s.poz.x + 60 * s.u, s.poz.y + 20 * s.u, 20 * s.u + r * 80 * s.u, 0, PI * 2); ctx.stroke(); }
    const m = E.inOutCubic(T(s, 0.4, klik * s.p.tempo - 0.45)); kursor(ctx, lerp(s.poz.x + 300 * s.u, s.poz.x + 60 * s.u, m), lerp(s.poz.y + 300 * s.u, s.poz.y + 20 * s.u, m), 1.6 * s.u * s.p.rozmiar * nac);
  }, { pola: ["tekst"] });
  ctaN("cta-zadzwon", "Zadzwoń teraz", { tekst: "Zadzwoń: 600 100 200", tekst2: "" }, (s) => {
    const e = E.outBackMocno(T(s, 0, 0.45)), px = 54 * s.u * s.p.rozmiar, dz = Math.sin(s.t * 26) * 0.08 * (Math.floor(s.t * 1.3) % 2);
    s.ctx.save(); s.ctx.translate(s.poz.x, s.poz.y); s.ctx.rotate(dz); s.ctx.translate(-s.poz.x, -s.poz.y); przycisk(s, s.p.tekst, s.poz.x, s.poz.y, px, "#22C55E", e, { ikona: ikTelefon, kt: "#FFFFFF" }); s.ctx.restore();
  }, { pola: ["tekst"] });
  ctaN("cta-dm", "Napisz do mnie", { tekst: "Napisz DM „START”", tekst2: "odpiszę dziś" }, (s) => {
    const e = E.outBackMocno(T(s, 0, 0.45)), px = 54 * s.u * s.p.rozmiar; przycisk(s, s.p.tekst, s.poz.x, s.poz.y, px, s.k.a, e, { ikona: ikDM });
    podpis(Object.assign({}, s, { p: Object.assign({}, s.p, { tekst: s.p.tekst2 }) }), s.poz.y + px * 1.5, E.outCubic(T(s, 0.4, 0.5)), 44);
  });
  ctaN("cta-kod-rabatowy", "Kod rabatowy do skopiowania", { tekst: "NADA20", tekst2: "-20% na pierwsze zamówienie" }, (s) => {
    const ctx = s.ctx, px = 70 * s.u * s.p.rozmiar, a = E.outBackMocno(T(s, 0, 0.45)); ctx.font = font(s, px, 900); const w = ctx.measureText(s.p.tekst).width + px * 2, h = px * 2;
    ctx.save(); ctx.translate(s.poz.x, s.poz.y); ctx.scale(a, a); cien(s); ctx.fillStyle = "#FFFFFF"; zaokr(ctx, -w / 2, -h / 2, w, h, 16 * s.u); ctx.fill(); bezCienia(ctx);
    ctx.setLineDash([14 * s.u, 10 * s.u]); ctx.strokeStyle = s.k.g; ctx.lineWidth = 5 * s.u; zaokr(ctx, -w / 2 + 12 * s.u, -h / 2 + 12 * s.u, w - 24 * s.u, h - 24 * s.u, 10 * s.u); ctx.stroke(); ctx.setLineDash([]);
    const kop = s.t > 1.4 / s.p.tempo; ctx.fillStyle = "#111827"; ctx.fillText(s.p.tekst, -ctx.measureText(s.p.tekst).width / 2, 0);
    if (kop) { const k = E.outBackMocno(okno(s.t, 1.4 / s.p.tempo, 0.3)); ctx.save(); ctx.translate(0, -h * 0.85); ctx.scale(k, k); ctx.font = font(s, px * 0.4, 700); const tt = "Skopiowano ✓", tw = ctx.measureText(tt).width + 30 * s.u; ctx.fillStyle = "#111827"; zaokr(ctx, -tw / 2, -px * 0.35, tw, px * 0.7, px * 0.35); ctx.fill(); ctx.fillStyle = "#fff"; ctx.fillText(tt, -tw / 2 + 15 * s.u, 0); ctx.restore(); }
    ctx.restore(); podpis(Object.assign({}, s, { p: Object.assign({}, s.p, { tekst: s.p.tekst2 }) }), s.poz.y + h * 0.8, E.outCubic(T(s, 0.4, 0.5)), 44);
  }, { czas: 3.5 });
  ctaN("cta-newsletter", "Zapisz się: pole e-mail", { tekst: "twoj@email.pl", tekst2: "Zapisz się" }, (s) => {
    const ctx = s.ctx, px = 44 * s.u * s.p.rozmiar, W = s.W * 0.78, h = px * 2.2, x0 = s.poz.x - W / 2, a = E.outCubic(T(s, 0, 0.5)), t = s.p.tekst || "", n = Math.floor(clamp((s.t - 0.4 / s.p.tempo) / (t.length * 0.05 / s.p.tempo)) * t.length);
    ctx.globalAlpha = s.alfa * a; cien(s); ctx.fillStyle = "#FFFFFF"; zaokr(ctx, x0, s.poz.y - h / 2, W, h, h / 2); ctx.fill(); bezCienia(ctx);
    ctx.font = font(s, px, 500); ctx.fillStyle = "#374151"; ctx.fillText(t.slice(0, n), x0 + px, s.poz.y); ctx.font = font(s, px, 800); const bw = ctx.measureText(s.p.tekst2 || "").width + px * 1.6;
    const klik = s.t > (0.6 + t.length * 0.05) / s.p.tempo + 0.3; ctx.fillStyle = klik ? "#22C55E" : s.k.g; zaokr(ctx, x0 + W - bw - 8 * s.u, s.poz.y - h / 2 + 8 * s.u, bw, h - 16 * s.u, (h - 16 * s.u) / 2); ctx.fill();
    ctx.fillStyle = kontrast(klik ? "#22C55E" : s.k.g); ctx.fillText(klik ? "✓" : s.p.tekst2 || "", x0 + W - bw - 8 * s.u + px * 0.8, s.poz.y); ctx.globalAlpha = s.alfa;
  }, { czas: 4 });
  ctaN("cta-wiecej", "Sprawdź więcej ze strzałkami", { tekst: "Zobacz więcej", tekst2: "" }, (s) => {
    const ctx = s.ctx, a = E.outCubic(T(s, 0, 0.4)), px = 58 * s.u * s.p.rozmiar; ctx.font = font(s, px, 800); const t = tekstP(s, s.p.tekst), w = ctx.measureText(t).width;
    ctx.globalAlpha = s.alfa * a; cien(s); ctx.fillStyle = s.k.t; ctx.fillText(t, s.poz.x - w / 2 - px, s.poz.y); bezCienia(ctx);
    for (let i = 0; i < 3; i++) { const f = 0.35 + 0.65 * Math.max(0, Math.sin(s.t * 6 - i * 0.8)); ctx.globalAlpha = s.alfa * a * f; ctx.strokeStyle = s.k.a; ctx.lineWidth = 9 * s.u; ctx.lineCap = "round"; ctx.lineJoin = "round"; const x = s.poz.x + w / 2 - px * 0.6 + i * px * 0.6;
      ctx.beginPath(); ctx.moveTo(x, s.poz.y - px * 0.35); ctx.lineTo(x + px * 0.3, s.poz.y); ctx.lineTo(x, s.poz.y + px * 0.35); ctx.stroke(); }
    ctx.globalAlpha = s.alfa;
  }, { pola: ["tekst"] });
  ctaN("cta-pobierz", "Pobierz aplikację", { tekst: "Pobierz za darmo", tekst2: "" }, (s) => {
    const e = E.outBackMocno(T(s, 0, 0.45)), px = 56 * s.u * s.p.rozmiar, b = 1 + Math.sin(s.t * 5) * 0.03; przycisk(s, s.p.tekst, s.poz.x, s.poz.y, px, "#111827", e * b, { ikona: ikPobierz, kt: "#FFFFFF", r: 18 * s.u });
  }, { pola: ["tekst"] });
  ctaN("cta-kup-teraz", "Kup teraz z koszykiem", { tekst: "Kup teraz", tekst2: "dostawa jutro" }, (s) => {
    const e = E.outBackMocno(T(s, 0, 0.45)), px = 60 * s.u * s.p.rozmiar, ob = Math.sin(s.t * 3) * 0.03; s.ctx.save(); s.ctx.translate(s.poz.x, s.poz.y); s.ctx.rotate(ob); s.ctx.translate(-s.poz.x, -s.poz.y);
    przycisk(s, s.p.tekst, s.poz.x, s.poz.y, px, s.k.a, e, { ikona: ikKoszyk }); s.ctx.restore();
    podpis(Object.assign({}, s, { p: Object.assign({}, s.p, { tekst: s.p.tekst2 }) }), s.poz.y + px * 1.5, E.outCubic(T(s, 0.4, 0.5)), 42);
  });
  ctaN("cta-polub-obserwuj", "Polub i obserwuj", { tekst: "Polub", tekst2: "Obserwuj" }, (s) => {
    const ctx = s.ctx, px = 50 * s.u * s.p.rozmiar, a = E.outBackMocno(T(s, 0, 0.4)), b = E.outBackMocno(T(s, 0.25, 0.4)), k1 = s.t > 1.1 / s.p.tempo, k2 = s.t > 1.7 / s.p.tempo;
    const ikS = (c, x, y, r, k) => { c.fillStyle = k1 ? "#fff" : "#EF4444"; serce(c, x, y + r * 0.1, r * 0.95); c.fill(); };
    przycisk(s, s.p.tekst || "", s.poz.x - 170 * s.u * s.p.rozmiar, s.poz.y, px, k1 ? "#EF4444" : "#FFFFFF", a * (Math.abs(s.t - 1.1 / s.p.tempo) < 0.1 ? 0.9 : 1), { kt: k1 ? "#fff" : "#111", ikona: ikS });
    const ikP = (c, x, y, r, k) => { if (k2) ptaszek(c, x, y, r * 1.1, 1, "#fff", r * 0.3); else { c.strokeStyle = k; c.lineWidth = r * 0.3; c.beginPath(); c.moveTo(x - r * 0.7, y); c.lineTo(x + r * 0.7, y); c.moveTo(x, y - r * 0.7); c.lineTo(x, y + r * 0.7); c.stroke(); } };
    przycisk(s, k2 ? "Obserwujesz" : s.p.tekst2 || "", s.poz.x + 170 * s.u * s.p.rozmiar, s.poz.y, px, k2 ? "#3A3A3A" : s.k.g, b, { kt: k2 ? "#fff" : undefined, ikona: ikP });
    void ctx;
  }, { czas: 3 });
  ctaN("cta-oferta-czas", "Oferta kończy się za…", { tekst: "Oferta kończy się za", liczba: 59 }, (s) => {
    const ctx = s.ctx, px = 48 * s.u * s.p.rozmiar, a = E.outCubic(T(s, 0, 0.4)), sek = Math.max(0, Math.ceil((+s.p.liczba || 59) - s.t)), t = `00:${String(Math.floor(sek / 60)).padStart(2, "0")}:${String(sek % 60).padStart(2, "0")}`;
    ctx.globalAlpha = s.alfa * a; ctx.font = font(s, px, 700); ctx.fillStyle = s.k.t; cien(s); const t1 = tekstP(s, s.p.tekst); ctx.fillText(t1, s.poz.x - ctx.measureText(t1).width / 2, s.poz.y - px * 1.3);
    ctx.font = font(s, px * 2.2, 900); const w = ctx.measureText(t).width + px * 1.4, h = px * 3; ctx.fillStyle = "#DC2626"; zaokr(ctx, s.poz.x - w / 2, s.poz.y - h * 0.15, w, h, 18 * s.u); ctx.fill(); bezCienia(ctx);
    ctx.fillStyle = "#fff"; ctx.fillText(t, s.poz.x - ctx.measureText(t).width / 2, s.poz.y + h * 0.35); ctx.globalAlpha = s.alfa;
  }, { pola: ["tekst", "liczba"], czas: 4 });

  // ---------- przejścia (v17, cały kadr) ----------
  function przejscieN(id, nazwa, fn, o = {}) { dodaj({ id, nazwa, kat: "przejscia", czas: o.czas || 1.2, pola: o.pola || [], pelne: true, przyklad: {}, rysuj: fn }); }
  /* Faza wejścia (zakrywa) i wyjścia (odkrywa): a, b w 0–1. */
  const fazy = (s) => [E.inOutCubic(okno(s.t, 0, s.T * 0.5)), E.inOutCubic(okno(s.t, s.T * 0.5, s.T * 0.5))];
  przejscieN("przejscie-wipe-skos", "Przejście: ukośna zasłona", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), D = s.W + s.H; ctx.fillStyle = s.k.g; ctx.beginPath();
    const x1 = -s.H + D * a, x0 = -s.H + D * b; ctx.moveTo(x0, 0); ctx.lineTo(x1 + s.H, 0); ctx.lineTo(x1, s.H); ctx.lineTo(x0 - s.H, s.H); ctx.closePath(); ctx.fill();
  });
  przejscieN("przejscie-kurtyna", "Przejście: kurtyna", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), w = s.W / 2 * (a - b); ctx.fillStyle = s.k.g; ctx.fillRect(0, 0, w, s.H); ctx.fillStyle = ciemniej(s.k.g, 0.12); ctx.fillRect(s.W - w, 0, w, s.H);
  });
  przejscieN("przejscie-romb", "Przejście: romb", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), R = (s.W + s.H) * 0.75, c = warstwa(s, "romb", (x) => {
      const r = (q) => { x.beginPath(); x.moveTo(s.W / 2, s.H / 2 - q); x.lineTo(s.W / 2 + q, s.H / 2); x.lineTo(s.W / 2, s.H / 2 + q); x.lineTo(s.W / 2 - q, s.H / 2); x.closePath(); x.fill(); };
      x.fillStyle = s.k.a; r(R * a); if (b > 0) { x.globalCompositeOperation = "destination-out"; r(R * b); } }); ctx.drawImage(c, 0, 0);
  });
  przejscieN("przejscie-gwiazda", "Przejście: gwiazda", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), R = (s.W + s.H) * 1.1, c = warstwa(s, "gw", (x) => {
      x.fillStyle = s.k.g; gwiazda(x, s.W / 2, s.H / 2, 5, Math.max(0.1, R * a), Math.max(0.05, R * a * 0.5), -PI / 2 + a); x.fill();
      if (b > 0) { x.globalCompositeOperation = "destination-out"; gwiazda(x, s.W / 2, s.H / 2, 5, Math.max(0.1, R * b), Math.max(0.05, R * b * 0.5), -PI / 2 - b); x.fill(); } }); ctx.drawImage(c, 0, 0);
  });
  przejscieN("przejscie-kaskada", "Przejście: kaskada pasków", (s) => {
    const ctx = s.ctx, n = 8, h = s.H / n;
    for (let i = 0; i < n; i++) { const a = E.inOutCubic(okno(s.t, i * 0.04, s.T * 0.45 - i * 0.02)), b = E.inOutCubic(okno(s.t, s.T * 0.5 + i * 0.04, s.T * 0.45 - i * 0.02));
      ctx.fillStyle = i % 2 ? s.k.g : s.k.a; ctx.fillRect(s.W * b, i * h - 1, s.W * (a - b), h + 2); }
  });
  przejscieN("przejscie-plamy", "Przejście: kolorowe plamy", (s) => {
    const ctx = s.ctx, n = 14, [a, b] = fazy(s), kol = [s.k.g, s.k.a, ciemniej(s.k.g, 0.2)];
    for (let i = 0; i < n; i++) { const st = los(i * 2.1) * 0.35, r = Math.max(0, (a - st) / (1 - st)) * (s.W + s.H) * 0.45 * (0.7 + los(i) * 0.6) * (1 - b); if (r <= 0) continue;
      ctx.fillStyle = kol[i % 3]; ctx.beginPath(); ctx.arc(los(i * 3.7) * s.W, los(i * 5.3) * s.H, r, 0, PI * 2); ctx.fill(); }
  });
  przejscieN("przejscie-szachownica", "Przejście: szachownica", (s) => {
    const ctx = s.ctx, k = 6, w = s.W / k, h = Math.ceil(s.H / w);
    for (let i = 0; i < k; i++) for (let j = 0; j < h; j++) { const op = ((i + j) % 2) * 0.12 + los(i * 9 + j) * 0.08, a = E.outCubic(okno(s.t, op, s.T * 0.3)), b = E.inCubic(okno(s.t, s.T * 0.55 + op, s.T * 0.25)), q = Math.max(0, a - b);
      if (q <= 0) continue; ctx.fillStyle = (i + j) % 2 ? s.k.g : s.k.a; const sz = w * q; ctx.fillRect(i * w + (w - sz) / 2, j * w + (w - sz) / 2, sz + 1, sz + 1); }
  });
  przejscieN("przejscie-zaluzje", "Przejście: żaluzje", (s) => {
    const ctx = s.ctx, n = 10, w = s.W / n, [a, b] = fazy(s); ctx.fillStyle = s.k.g;
    for (let i = 0; i < n; i++) { const q = b > 0 ? 1 - b : a; ctx.fillRect(b > 0 ? i * w + w * b : i * w, 0, w * q + 1, s.H); }
  });
  przejscieN("przejscie-trzy-kolory", "Przejście: trzy kolory", (s) => {
    const ctx = s.ctx, kol = [s.k.a, s.k.g, s.k.tl];
    kol.forEach((k, i) => { const a = E.inOutCubic(okno(s.t, i * 0.08, s.T * 0.42)), b = E.inOutCubic(okno(s.t, s.T * 0.5 + i * 0.08, s.T * 0.42)); ctx.fillStyle = k; ctx.fillRect(0, s.H * (1 - a), s.W, s.H * (a - b)); });
  });
  przejscieN("przejscie-fala", "Przejście: fala", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), fala = (p, dir) => { ctx.beginPath(); const y = s.H * (1 - p) - 80 * s.u; ctx.moveTo(0, s.H); for (let x = 0; x <= s.W; x += 10) ctx.lineTo(x, y + Math.sin(x / s.W * PI * 3 + s.t * 8 * dir) * 60 * s.u); ctx.lineTo(s.W, s.H); ctx.closePath(); };
    ctx.save(); ctx.fillStyle = s.k.g; fala(a * 1.15, 1); ctx.fill(); ctx.restore();
    if (b > 0) { ctx.save(); ctx.globalCompositeOperation = "destination-out"; fala(b * 1.15, -1); ctx.fill(); ctx.restore(); }
  });
  przejscieN("przejscie-glitch", "Przejście: zakłócenia", (s) => {
    const ctx = s.ctx, f = Math.floor(s.t * 30), siła = Math.sin(clamp(s.t / s.T) * PI);
    for (let i = 0; i < 16; i++) { if (los(f * 17 + i) > siła) continue; const y = los(f * 7 + i) * s.H, h = (0.02 + los(f + i * 3) * 0.12) * s.H; ctx.fillStyle = [s.k.g, s.k.a, "#FFFFFF", "#000000"][i % 4]; ctx.globalAlpha = 0.85; ctx.fillRect((los(i + f) - 0.5) * 80 * s.u, y, s.W, h); }
    ctx.globalAlpha = 1; if (siła > 0.85) { ctx.fillStyle = s.k.g; ctx.fillRect(0, 0, s.W, s.H); }
  }, { czas: 0.8 });
  przejscieN("przejscie-trojkaty", "Przejście: trójkąty", (s) => {
    const ctx = s.ctx, k = 5, w = s.W / k, rz = Math.ceil(s.H / w) + 1;
    for (let j = 0; j < rz; j++) for (let i = 0; i <= k; i++) { const op = (j / rz) * 0.3, a = E.outBack(okno(s.t, op, s.T * 0.28)), b = E.inCubic(okno(s.t, s.T * 0.5 + op, s.T * 0.25)), q = Math.max(0, a - b);
      if (q <= 0) continue; const cx = i * w + (j % 2 ? w / 2 : 0), cy = j * w; ctx.fillStyle = (i + j) % 2 ? s.k.g : s.k.a; ctx.save(); ctx.translate(cx, cy); ctx.scale(q, q); ctx.rotate(j % 2 ? PI : 0);
      ctx.beginPath(); ctx.moveTo(0, -w * 0.9); ctx.lineTo(w * 0.9, w * 0.6); ctx.lineTo(-w * 0.9, w * 0.6); ctx.closePath(); ctx.fill(); ctx.restore(); }
  });
  przejscieN("przejscie-zoom-ramka", "Przejście: wjazd w ramkę", (s) => {
    const ctx = s.ctx, [a, b] = fazy(s), q = Math.max(0, a - b), m = s.W * 0.5 * q;
    const c = warstwa(s, "ramka", (x) => { x.fillStyle = s.k.g; x.fillRect(0, 0, s.W, s.H); if (q < 1) { x.globalCompositeOperation = "destination-out"; x.fillRect(m, m * s.H / s.W, s.W - 2 * m, s.H - 2 * m * s.H / s.W); } });
    if (q > 0) ctx.drawImage(c, 0, 0);
  });
  przejscieN("przejscie-blysk-kolor", "Przejście: błysk koloru", (s) => {
    const ctx = s.ctx, q = Math.sin(clamp(s.t / s.T) * PI); ctx.globalAlpha = q; ctx.fillStyle = s.k.a; ctx.fillRect(0, 0, s.W, s.H); ctx.globalAlpha = 1;
  }, { czas: 0.6 });

  // ---------- rysowanie klatki ----------
  function stan(ctx, preset, t, p0, W, H) {
    const p = Object.assign({}, DOMYSLNE, preset.dom || {}, p0 || {});
    ["rozmiar", "tempo", "wyjscie", "waga", "liczba", "x", "y", "x2", "y2", "interlinia", "odstep", "szerokosc", "obrys", "cien_moc", "przesun_x", "przesun_y", "obrot", "krycie", "opoznienie"].forEach((k) => { if (p[k] !== "" && p[k] != null && !isNaN(+p[k])) p[k] = +p[k]; });
    if (!(p.tempo > 0)) p.tempo = 1;
    const T = +p.czas || preset.czas || 3;
    const poz = POZYCJE[p.pozycja] || POZYCJE[(preset.dom && preset.dom.pozycja) || "srodek"];
    if (!(p.interlinia > 0)) p.interlinia = 1; if (!(p.szerokosc > 0)) p.szerokosc = 1;
    return {
      ctx, p, t, T, W, H, u: Math.min(W, H) / 1080, alfa: 1,
      k: { g: p.kolor_glowny, a: p.kolor_akcent, t: p.kolor_tekstu, tl: p.kolor_tla },
      poz: { x: poz[0] * W, y: poz[1] * H, align: poz[2] },
      wyj: preset.pelne ? 0 : okno(t, T - p.wyjscie, p.wyjscie),
    };
  }
  function znajdz(id) { return PRESETY.find((x) => x.id === id) || null; }
  // dodatkowe wejście nakładane na każdy preset (panel: „Wejście całości”)
  const WEJSCIA = {
    "": null, "z-dolu": (e, s, ctx) => ctx.translate(0, (1 - E.outCubic(e)) * 140 * s.u), "z-gory": (e, s, ctx) => ctx.translate(0, -(1 - E.outCubic(e)) * 140 * s.u),
    "z-lewej": (e, s, ctx) => ctx.translate(-(1 - E.outCubic(e)) * 220 * s.u, 0), "z-prawej": (e, s, ctx) => ctx.translate((1 - E.outCubic(e)) * 220 * s.u, 0),
    "zoom": (e, s, ctx) => { const k = lerp(0.6, 1, E.outBack(e)); ctx.translate(s.poz.x, s.poz.y); ctx.scale(k, k); ctx.translate(-s.poz.x, -s.poz.y); },
    "obrot": (e, s, ctx) => { ctx.translate(s.poz.x, s.poz.y); ctx.rotate((1 - E.outBack(e)) * -0.35); ctx.translate(-s.poz.x, -s.poz.y); },
    "zanik": null,
  };
  function rysuj(ctx, id, t, p, W, H) {
    const preset = typeof id === "string" ? znajdz(id) : id;
    if (!preset) throw new Error("Nie ma presetu " + id);
    const op = +((p || {}).opoznienie) || 0;
    if (op) { if (t < op) return stan(ctx, preset, 0, p, W, H); t -= op; }
    const s = stan(ctx, preset, t, p, W, H);
    if (t < 0 || t > s.T + 1e-6) return s;
    ctx.save();
    ctx.textBaseline = "middle"; ctx.textAlign = "left";
    const P = s.p;
    // przesunięcie, obrót i krycie całości
    if (P.przesun_x || P.przesun_y) ctx.translate(P.przesun_x * W, P.przesun_y * H);
    if (P.obrot) { ctx.translate(s.poz.x, s.poz.y); ctx.rotate(P.obrot * Math.PI / 180); ctx.translate(-s.poz.x, -s.poz.y); }
    const we = P.wejscie_styl && P.wejscie_styl !== "brak" ? okno(t, 0, 0.55 / P.tempo) : 1;
    if (we < 1 && WEJSCIA[P.wejscie_styl]) WEJSCIA[P.wejscie_styl](we, s, ctx);
    if (s.wyj > 0) {
      const e = E.inCubic(s.wyj), styl = P.wyjscie_styl;
      if (styl !== "brak") s.alfa = 1 - e;
      if (styl === "w-gore") ctx.translate(0, -60 * s.u * e);
      if (styl === "w-dol") ctx.translate(0, 60 * s.u * e);
      if (styl === "w-lewo") ctx.translate(-120 * s.u * e, 0);
      if (styl === "w-prawo") ctx.translate(120 * s.u * e, 0);
      if (styl === "zoom") { ctx.translate(s.poz.x, s.poz.y); ctx.scale(1 + 0.25 * e, 1 + 0.25 * e); ctx.translate(-s.poz.x, -s.poz.y); }
      if (styl === "zoom-out") { ctx.translate(s.poz.x, s.poz.y); ctx.scale(1 - 0.4 * e, 1 - 0.4 * e); ctx.translate(-s.poz.x, -s.poz.y); }
      if (styl === "rozmycie" && e > 0.02) ctx.filter = `blur(${(e * 24 * s.u).toFixed(1)}px)`;
    }
    if (P.wejscie_styl && P.wejscie_styl !== "brak" && we < 1) s.alfa *= E.outCubic(we);
    s.alfa *= P.krycie == null ? 1 : clamp(+P.krycie);
    ctx.globalAlpha = s.alfa;
    // odstęp liter i obrys tekstu działają na każdy napis rysowany przez preset
    const zmiany = [];
    if (P.odstep && "letterSpacing" in ctx) { const st = ctx.letterSpacing; ctx.letterSpacing = Math.round(P.odstep * 100 * s.u * P.rozmiar) + "px"; zmiany.push(() => (ctx.letterSpacing = st)); }
    if (P.obrys > 0) {
      const ft = ctx.fillText, gr = P.obrys * 4 * s.u * P.rozmiar;
      ctx.fillText = function (tx, x, y, m) {
        this.save(); this.strokeStyle = P.kolor_obrysu || "#000"; this.lineWidth = gr * 2; this.lineJoin = "round"; this.miterLimit = 2;
        if (m != null) this.strokeText(tx, x, y, m); else this.strokeText(tx, x, y); this.restore();
        return m != null ? ft.call(this, tx, x, y, m) : ft.call(this, tx, x, y);
      };
      zmiany.push(() => { try { delete ctx.fillText; } catch (e) {} if (ctx.fillText !== ft) ctx.fillText = ft; });
    }
    try { preset.rysuj(s); } finally { zmiany.forEach((f) => f()); ctx.restore(); }
    return s;
  }
  function czas(id, p) { const pr = znajdz(id); return (pr ? (+((p || {}).czas) || pr.czas || 3) : 3) + (+((p || {}).opoznienie) || 0); }
  /* Ile sekund od początku trwa wejście (do momentu, gdy obraz się uspokaja). Panel chroni ten fragment przy rozciąganiu na osi. */
  function wejscie(id, p, W = 180, H = 320) {
    const pr = znajdz(id); if (!pr) return 0.8;
    const T = czas(id, p), pw = (p || {}).wyjscie != null ? (p || {}).wyjscie : (pr.dom && pr.dom.wyjscie != null ? pr.dom.wyjscie : DOMYSLNE.wyjscie), wyj = pr.pelne ? 0 : (+pw || 0), granica = Math.max(0.2, T - wyj - 0.05);
    const c = nowyCanvas(W, H), x = c.getContext("2d");
    const klatka = (t) => { x.setTransform(1, 0, 0, 1, 0, 0); x.globalAlpha = 1; x.filter = "none"; x.clearRect(0, 0, W, H); try { rysuj(x, pr, t, p, W, H); } catch (e) {} return x.getImageData(0, 0, W, H).data.slice(); };
    const krok = 1 / 15, ruch = [];
    let poprz = klatka(0);
    for (let t = krok; t <= granica + 1e-6; t += krok) {
      const d = klatka(t); let zm = 0;
      for (let i = 3; i < d.length; i += 4) if (Math.abs(d[i] - poprz[i]) + Math.abs(d[i - 1] - poprz[i - 1]) + Math.abs(d[i - 2] - poprz[i - 2]) > 24) zm++;
      ruch.push({ t, r: zm > Math.max(2, W * H * 0.0002) }); poprz = d;
    }
    const ost = ruch.filter((k) => k.r).pop();
    if (!ost) return Math.min(granica, 0.3);
    // obraz stoi po ostatnim ruchu: chronimy wejście do tego miejsca, środek się wydłuża
    if (granica - ost.t >= 0.4) return +Math.min(granica, ost.t + krok).toFixed(2);
    // ruch trwa do końca (pasek postępu, lista pojawiająca się punkt po punkcie, migający kursor):
    // nic nie chronimy na początku, przy wydłużaniu cały ruch rozkłada się na dłuższy czas (wyjście zostaje stałe)
    return 0;
  }
  return {
    PRESETY, KATEGORIE, DOMYSLNE, POZYCJE, WEJSCIA, E, dodaj, znajdz, rysuj, czas, wejscie,
    ustawFabryke: (f) => { fabryka = f; },
    pomoc: { E, clamp, lerp, okno, los, rgba, kontrast, ciemniej, zaokr, gwiazda, serce, kursor, ptaszek, sciezkaCzesc, krzywa, uloz, znaki, dopasuj, font, tekstP, slowaZ, cien, bezCienia, piszSlowo, lista, pary, liczbaTekst, warstwa, punkt },
  };
});

/* Jak napisać preset (np. w narzedzia/animacje/wlasne/moj-preset.js):

NMAnim.dodaj({
  id: "moj-preset", nazwa: "Mój preset", kat: "wlasne", czas: 3,
  pola: ["tekst", "tekst2"],                 // które pola pokazać w panelu: tekst, tekst2, lista, liczba, od, przed, po, emoji, xy, xy2, logo
  dom: { pozycja: "dol" },                   // domyślne parametry tego presetu
  przyklad: { tekst: "Przykład" },           // tekst do podglądu w galerii
  rysuj(s) {
    // s.ctx (canvas 2D), s.t (s), s.T (czas całości), s.W, s.H, s.u (jednostka: 1 przy 1080 px krótszego boku),
    // s.p (parametry), s.k.g / s.k.a / s.k.t / s.k.tl (kolory marki: główny, akcent, tekst, tło), s.poz {x, y, align}
    const { okno, E, uloz, piszSlowo } = NMAnim.pomoc;
    const ul = uloz(s, s.p.tekst, 90 * s.u * s.p.rozmiar);
    s.ctx.font = ul.font;
    ul.slowa.forEach((w) => { const e = E.outCubic(okno(s.t, w.i * 0.1, 0.4)); s.ctx.globalAlpha = s.alfa * e; piszSlowo(s, w); });
  },
});

Zasady: tło przezroczyste (nie zamalowuj kadru, chyba że to przejście z pelne: true), kolory tylko z s.k,
font z s.p.font, wielkości mnożone przez s.u i s.p.rozmiar, wejście krótkie (do ~0,8 s / s.p.tempo),
wyjście robi biblioteka sama (s.alfa), więc używaj ctx.globalAlpha = s.alfa * ... zamiast = ....
*/
