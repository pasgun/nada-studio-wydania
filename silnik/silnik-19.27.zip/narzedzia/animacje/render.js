/* Render animacji z biblioteki do pliku (bez Premiere). Uruchamia go narzedzia/animacje.py.
 *
 *   node narzedzia/animacje/render.js --spec spec.json
 *
 * spec.json:
 * { "preset": "pop-slowa", "parametry": {...}, "W": 1080, "H": 1920, "fps": 30,
 *   "wyjscie": "wyniki/.../anim.mov",      .mov = ProRes 4444 z przezroczystością (Premiere), .webm = VP9 z alfą,
 *                                            .mp4 = na tło (parametry.tlo albo czarne), folder/ = klatki PNG
 *   "podglad": "wyniki/.../anim_podglad.png",   arkusz 8 klatek na szachownicy (do obejrzenia)
 *   "fonty": ["klienci/x/fonty/Montserrat-ExtraBold.ttf"], "logo": "klienci/x/logo/logo.png",
 *   "tlo": "plik.jpg" (tylko do podglądu), "ffmpeg": "ffmpeg" }
 *
 *   node narzedzia/animacje/render.js --galeria wyniki/galeria.png [--fonty a.ttf,b.ttf]   (arkusz wszystkich presetów)
 *   node narzedzia/animacje/render.js --lista                                               (presety jako JSON)
 */
"use strict";
const fs = require("fs");
const path = require("path");
const cp = require("child_process");
const { createCanvas, GlobalFonts, loadImage } = require("@napi-rs/canvas");

const NMAnim = require("./animacje.js");
global.NMAnim = NMAnim;
NMAnim.ustawFabryke((w, h) => createCanvas(w, h));
const WLASNE = path.join(__dirname, "wlasne");
if (fs.existsSync(WLASNE)) {
  for (const f of fs.readdirSync(WLASNE).filter((x) => x.endsWith(".js")).sort()) {
    try { require(path.join(WLASNE, f)); } catch (e) { process.stderr.write(`POSTEP: Błąd w presecie ${f}: ${e.message}\n`); }
  }
}

function arg(nazwa) { const i = process.argv.indexOf(nazwa); return i >= 0 ? process.argv[i + 1] : null; }
function wynik(o) { process.stdout.write(JSON.stringify(Object.assign({ ok: true }, o), null, 1) + "\n"); }
function blad(t) { process.stdout.write(JSON.stringify({ ok: false, blad: t }) + "\n"); process.exit(1); }

function zaladujFonty(lista) {
  const rodziny = new Set();
  (lista || []).forEach((f) => {
    if (!f || !fs.existsSync(f)) return;
    const r = GlobalFonts.registerFromPath(f);
    if (r) rodziny.add(path.basename(f));
  });
  return [...rodziny];
}

function szachownica(ctx, W, H, k = 40) {
  for (let y = 0; y < H; y += k) for (let x = 0; x < W; x += k) { ctx.fillStyle = ((x / k + y / k) % 2) ? "#3a3a3a" : "#2b2b2b"; ctx.fillRect(x, y, k, k); }
}

async function render(spec) {
  const W = spec.W || 1080, H = spec.H || 1920, fps = spec.fps || 30;
  const preset = NMAnim.znajdz(spec.preset);
  if (!preset) blad(`Nie ma presetu „${spec.preset}”. Lista: node narzedzia/animacje/render.js --lista`);
  zaladujFonty(spec.fonty);
  const p = Object.assign({}, preset.przyklad || {}, spec.parametry || {});
  if (spec.logo && fs.existsSync(spec.logo)) p.logo = await loadImage(spec.logo);
  const T = NMAnim.czas(spec.preset, p), n = Math.max(1, Math.round(T * fps));
  const c = createCanvas(W, H), ctx = c.getContext("2d");
  const wyniki = {};

  if (spec.podglad) {
    const kol = 4, ile = 8, sk = Math.min(1, 480 / Math.max(W, H)), w = Math.round(W * sk), h = Math.round(H * sk);
    const ark = createCanvas(w * kol, h * Math.ceil(ile / kol) + 0), a = ark.getContext("2d");
    const tlo = spec.tlo && fs.existsSync(spec.tlo) ? await loadImage(spec.tlo) : null;
    for (let i = 0; i < ile; i++) {
      const t = (i + 0.5) / ile * T; ctx.clearRect(0, 0, W, H); NMAnim.rysuj(ctx, preset, t, p, W, H);
      const x = (i % kol) * w, y = Math.floor(i / kol) * h;
      a.save(); a.beginPath(); a.rect(x, y, w, h); a.clip();
      if (tlo) a.drawImage(tlo, x, y, w, h); else { a.translate(x, y); szachownica(a, w, h, 16); a.setTransform(1, 0, 0, 1, 0, 0); }
      a.drawImage(c, x, y, w, h); a.restore();
      a.fillStyle = "rgba(0,0,0,.6)"; a.fillRect(x, y, 70, 22); a.fillStyle = "#fff"; a.font = "14px sans-serif"; a.fillText(t.toFixed(2) + " s", x + 6, y + 16);
    }
    fs.mkdirSync(path.dirname(path.resolve(spec.podglad)), { recursive: true });
    fs.writeFileSync(spec.podglad, ark.toBuffer("image/png"));
    wyniki.podglad = path.resolve(spec.podglad);
  }

  if (spec.wyjscie) {
    const out = path.resolve(spec.wyjscie), ext = path.extname(out).toLowerCase();
    fs.mkdirSync(ext ? path.dirname(out) : out, { recursive: true });
    if (!ext) {
      for (let i = 0; i < n; i++) { ctx.clearRect(0, 0, W, H); NMAnim.rysuj(ctx, preset, i / fps, p, W, H); fs.writeFileSync(path.join(out, `klatka_${String(i).padStart(5, "0")}.png`), c.toBuffer("image/png")); }
      wyniki.klatki = out;
    } else {
      const kod = ext === ".mov" ? ["-c:v", "prores_ks", "-profile:v", "4444", "-pix_fmt", "yuva444p10le", "-vendor", "apl0"]
        : ext === ".webm" ? ["-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p", "-b:v", "4M", "-auto-alt-ref", "0"]
        : ["-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18"];
      const wejscie = ["-f", "rawvideo", "-pix_fmt", "rgba", "-s", `${W}x${H}`, "-r", String(fps), "-i", "-"];
      const args = ["-hide_banner", "-loglevel", "error", "-y", ...wejscie];
      if (ext === ".mp4") args.push("-filter_complex", `color=c=${(spec.parametry && spec.parametry.tlo) || "black"}:s=${W}x${H}:r=${fps}[t];[t][0:v]overlay=shortest=1[v]`, "-map", "[v]");
      args.push(...kod, out);
      const ff = cp.spawn(spec.ffmpeg || "ffmpeg", args, { stdio: ["pipe", "ignore", "pipe"] });
      let err = ""; ff.stderr.on("data", (d) => (err += d));
      const pisz = (buf) => new Promise((ok) => (ff.stdin.write(buf) ? ok() : ff.stdin.once("drain", ok)));
      for (let i = 0; i < n; i++) {
        ctx.clearRect(0, 0, W, H); NMAnim.rysuj(ctx, preset, i / fps, p, W, H);
        await pisz(Buffer.from(ctx.getImageData(0, 0, W, H).data.buffer));
        if (i % fps === 0) process.stderr.write(`POSTEP: Klatka ${i + 1} z ${n}\n`);
      }
      ff.stdin.end();
      const kodWyj = await new Promise((ok) => ff.on("close", ok));
      if (kodWyj !== 0) blad("ffmpeg: " + err.slice(-500));
      wyniki.plik = out;
    }
  }
  wynik(Object.assign({ preset: spec.preset, czas_s: T, klatek: n, W, H }, wyniki));
}

async function galeria(cel, fonty) {
  zaladujFonty(fonty);
  const W = 540, H = 960, kol = 8, pr = NMAnim.PRESETY, wiersze = Math.ceil(pr.length / kol), sk = 0.42;
  const w = Math.round(W * sk), h = Math.round(H * sk) + 26;
  const ark = createCanvas(w * kol, h * wiersze), a = ark.getContext("2d"), c = createCanvas(W, H), ctx = c.getContext("2d");
  a.fillStyle = "#111"; a.fillRect(0, 0, ark.width, ark.height);
  pr.forEach((p, i) => {
    const T = NMAnim.czas(p.id, p.przyklad), t = p.pelne ? T * 0.35 : Math.min(T - 0.5, T * 0.6);
    ctx.clearRect(0, 0, W, H); const x = (i % kol) * w, y = Math.floor(i / kol) * h;
    try { NMAnim.rysuj(ctx, p, t, p.przyklad, W, H); } catch (e) { a.fillStyle = "#f55"; a.font = "12px sans-serif"; a.fillText("BŁĄD: " + e.message, x + 4, y + 40); }
    a.save(); a.translate(x, y); szachownica(a, w, h - 26, 12); a.restore();
    a.drawImage(c, x, y, w, h - 26);
    a.fillStyle = "#ddd"; a.font = "12px sans-serif"; a.fillText(p.id, x + 4, y + h - 9);
  });
  fs.writeFileSync(cel, ark.toBuffer("image/png"));
  wynik({ galeria: path.resolve(cel), presetow: pr.length });
}

(async () => {
  try {
    if (process.argv.includes("--lista")) {
      wynik({ kategorie: NMAnim.KATEGORIE, presety: NMAnim.PRESETY.map((p) => ({ id: p.id, nazwa: p.nazwa, kat: p.kat, czas: p.czas, pola: p.pola, przyklad: p.przyklad })) });
    } else if (arg("--galeria")) {
      await galeria(arg("--galeria"), (arg("--fonty") || "").split(",").filter(Boolean));
    } else if (arg("--spec")) {
      await render(JSON.parse(fs.readFileSync(arg("--spec"), "utf8")));
    } else blad("Użycie: --spec spec.json | --galeria plik.png | --lista");
  } catch (e) { blad(String(e && e.stack || e)); }
})();
