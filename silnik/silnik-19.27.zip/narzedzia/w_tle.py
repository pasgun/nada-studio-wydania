"""Uruchamia program (Gemini, Claude Code) w tle w ukrytej konsoli i czeka, aż skończy.

Panel i Studio startują ten pomocnik zamiast programu. Program dostaje własną, niewidoczną konsolę,
więc polecenia, które sam uruchamia (np. PowerShell przy każdym kroku Gemini), nie otwierają okien.

  python narzedzia/w_tle.py --log <plik_logu> [--wejscie <plik_z_tekstem_na_wejście>] -- <program> <argumenty...>
"""
import os
import subprocess
import sys


def main():
    a = sys.argv[1:]
    if "--" not in a:
        print("użycie: w_tle.py --log PLIK [--wejscie PLIK] -- program argumenty...", file=sys.stderr)
        return 2
    i = a.index("--")
    opcje, cmd = a[:i], a[i + 1:]
    log = opcje[opcje.index("--log") + 1] if "--log" in opcje else None
    wejscie = opcje[opcje.index("--wejscie") + 1] if "--wejscie" in opcje else None
    if not cmd or not log:
        return 2
    flagi = 0
    if sys.platform.startswith("win"):
        flagi = 0x08000000 | 0x00000200  # CREATE_NO_WINDOW (ukryta konsola, dzieci ją dziedziczą) + osobna grupa procesów
        if cmd[0].lower().endswith((".cmd", ".bat")):
            cmd = ["cmd", "/c", *cmd]
    with open(log, "ab") as wyj:
        stdin = open(wejscie, "rb") if wejscie else subprocess.DEVNULL
        try:
            p = subprocess.Popen(cmd, stdin=stdin, stdout=wyj, stderr=wyj, creationflags=flagi, env=os.environ.copy())
            return p.wait()
        finally:
            if wejscie:
                stdin.close()


if __name__ == "__main__":
    sys.exit(main())
