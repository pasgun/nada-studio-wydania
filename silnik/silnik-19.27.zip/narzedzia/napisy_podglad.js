/* Podgląd stylu napisów na płótnie (panel Premiere i Studio): ten sam wygląd co narzedzia/napisy.py.
 * NMNapisy.rysuj(ctx, styl, W, H, tekst, aktywne, skala) – jeden kadr z fragmentem napisu. */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.NMNapisy = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";
  const DOMYSLNY = {
    slow_na_raz: 3, max_linii: 2, tryb: "fraza", font: "Montserrat", grubosc: 800, rozmiar: 72, litery: "wielkie",
    pozycja_y: 66, pozycja_x: 50, kolor: "#FFFFFF", aktywne_kolor: "#FFFFFF", aktywne_tlo: "#7C3AED", aktywne_tlo_wl: true,
    aktywne_skala: 1.0, obrys: 0, obrys_kolor: "#000000", cien: 6, cien_kolor: "#000000", tlo_krycie: 0, tlo_kolor: "#000000",
    animacja: "pop", kluczowe_wl: false, kluczowe: ["#22C55E", "#FACC15", "#EF4444"], rozstaw: 1.15, przytrzymaj_s: 0.5,
    kursywa: false, tlo_tryb: "linia", tlo_zaokr: 0.22, aktywne_ksztalt: "prostokat", nieaktywne_krycie: 100,
  };
  const styl = (s) => Object.assign({}, DOMYSLNY, s || {});
  const tekst = (s, t) => (s.litery === "wielkie" ? t.toLocaleUpperCase("pl") : s.litery === "male" ? t.toLocaleLowerCase("pl") : t);
  const font = (s, px) => `${s.kursywa ? "italic " : ""}${s.grubosc} ${Math.max(1, Math.round(px))}px "${s.font}", "Arial Black", sans-serif`;
  const kolor = (h, a) => {
    h = String(h || "#FFFFFF").replace("#", "");
    if (h.length === 8) { a = (a == null ? 1 : a) * parseInt(h.slice(6), 16) / 255; h = h.slice(0, 6); }
    const n = parseInt(h, 16) || 0;
    return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${a == null ? 1 : a})`;
  };
  function zawin(sz, maxW, sp) {
    const linie = []; let b = [], w = 0;
    sz.forEach((x, i) => { let n = w + (b.length ? sp : 0) + x; if (b.length && n > maxW) { linie.push(b); b = []; n = x; } b.push(i); w = n; });
    if (b.length) linie.push(b);
    return linie;
  }
  function rr(ctx, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  /* slowa: tablica tekstów, akt: indeks wypowiadanego słowa (albo null), skala: powiększenie aktywnego. */
  function rysuj(ctx, s0, W, H, slowa, akt, skala) {
    const s = styl(s0); skala = skala || +s.aktywne_skala || 1;
    const k = Math.min(W, H) / 1080, r = Math.max(6, s.rozmiar * k);
    ctx.save(); ctx.textBaseline = "middle"; ctx.font = font(s, r);
    const t = slowa.map((w) => tekst(s, w)), sz = t.map((x) => ctx.measureText(x).width);
    const sp = ctx.measureText(" ").width * (s.aktywne_tlo_wl ? 1.35 : 1), maxW = W * (H >= W ? 0.84 : 0.62), lh = r * s.rozstaw;
    let linie = zawin(sz, maxW, sp).slice(0, Math.max(1, s.max_linii));
    const poz = [], y1 = H * s.pozycja_y / 100, cx = W * s.pozycja_x / 100;
    linie.forEach((ln, li) => {
      const lw = ln.reduce((a, i) => a + sz[i], 0) + sp * (ln.length - 1);
      let x = Math.min(Math.max(cx - lw / 2, W * 0.04), W * 0.96 - lw); const y = y1 + li * lh;
      ln.forEach((i) => { poz[i] = [x, y]; x += sz[i] + sp; });
    });
    const wid = linie.flat();
    // tło
    if (s.tlo_krycie > 0) {
      let pr = [];
      linie.forEach((ln) => {
        if (s.tlo_tryb === "slowa") ln.forEach((i) => pr.push([poz[i][0] - r * 0.18, poz[i][1] - r * 0.6, poz[i][0] + sz[i] + r * 0.18, poz[i][1] + r * 0.6]));
        else pr.push([poz[ln[0]][0] - r * 0.3, poz[ln[0]][1] - r * 0.62, poz[ln[ln.length - 1]][0] + sz[ln[ln.length - 1]] + r * 0.3, poz[ln[0]][1] + r * 0.62]);
      });
      if (s.tlo_tryb === "blok" && pr.length) pr = [[Math.min(...pr.map((p) => p[0])) - r * 0.1, pr[0][1] - r * 0.12, Math.max(...pr.map((p) => p[2])) + r * 0.1, pr[pr.length - 1][3] + r * 0.12]];
      ctx.fillStyle = kolor(s.tlo_kolor, s.tlo_krycie / 100);
      pr.forEach((p) => { rr(ctx, p[0], p[1], p[2] - p[0], p[3] - p[1], Math.min((p[3] - p[1]) / 2, r * 1.24 * s.tlo_zaokr)); ctx.fill(); });
    }
    const slowo = (i, obrys) => {
      const sk = i === akt ? skala : 1; ctx.font = font(s, r * sk); ctx.textAlign = "center";
      const x = poz[i][0] + sz[i] / 2, y = poz[i][1];
      if (obrys) ctx.strokeText(t[i], x, y); else ctx.fillText(t[i], x, y);
    };
    if (s.cien > 0) {
      ctx.save(); ctx.shadowColor = kolor(s.cien_kolor, Math.min(1, 0.55 + s.cien / 25)); ctx.shadowBlur = s.cien * k * 1.8; ctx.shadowOffsetY = s.cien * k * 0.35;
      ctx.fillStyle = "rgba(0,0,0,1)"; wid.forEach((i) => slowo(i)); ctx.restore();
    }
    if (akt != null && poz[akt] && s.aktywne_tlo_wl) {
      const [x, y] = poz[akt], c = x + sz[akt] / 2, bw = sz[akt] * skala / 2 + r * 0.16 * skala, bh = r * 0.6 * skala;
      ctx.fillStyle = kolor(s.aktywne_tlo);
      if (s.aktywne_ksztalt === "podkreslenie") { rr(ctx, c - bw + r * 0.1, y + bh * 0.62, bw * 2 - r * 0.2, bh * 0.33, r * 0.08); ctx.fill(); }
      else if (s.aktywne_ksztalt === "marker") { ctx.fillStyle = kolor(s.aktywne_tlo, 0.85); ctx.fillRect(c - bw, y - bh * 0.05, bw * 2, bh * 0.77); }
      else { rr(ctx, c - bw, y - bh, bw * 2, bh * 2, s.aktywne_ksztalt === "pigulka" ? bh : s.aktywne_ksztalt === "kwadrat" ? 0 : r * 0.2 * skala); ctx.fill(); }
    }
    const kol = wid.filter((i) => i !== akt); if (akt != null && poz[akt]) kol.push(akt);
    kol.forEach((i) => {
      if (s.obrys > 0) { ctx.lineWidth = s.obrys * k * 2 * (i === akt ? skala : 1); ctx.lineJoin = "round"; ctx.strokeStyle = kolor(s.obrys_kolor); slowo(i, true); }
      ctx.fillStyle = i === akt ? kolor(s.aktywne_kolor) : kolor(s.kolor, akt != null ? s.nieaktywne_krycie / 100 : 1); slowo(i);
    });
    ctx.restore();
  }
  return { DOMYSLNY, styl, rysuj };
});
