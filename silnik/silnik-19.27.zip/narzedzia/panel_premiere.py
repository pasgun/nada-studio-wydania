"""Instalacja panelu „Studio Nadamedia” w Premiere Pro i After Effects: cięcie ciszy i wpadek, multicam podcastu,
aftermovie, animacje, szablony rolek (edycja w After Effects, Dynamic Link do Premiere) i transkrypcja sekwencji.

  python narzedzia/panel_premiere.py --instaluj      (raz; potem zrestartuj Premiere)
  python narzedzia/panel_premiere.py --odinstaluj

Co robi instalacja:
- kopiuje panel z folderu premiere/ do folderu rozszerzeń Adobe (bez uprawnień administratora),
- zapisuje w nim, gdzie jest silnik, Python, ffmpeg i Claude Code,
- instaluje bibliotekę do renderu animacji przez Claude (npm install w narzedzia/animacje, jeśli jest Node.js),
- włącza w Premiere wczytywanie rozszerzeń spoza sklepu Adobe (ustawienie PlayerDebugMode w rejestrze użytkownika).
Po zmianach w silniku uruchom --instaluj ponownie, żeby panel dostał nową wersję.
W Premiere: Okno > Rozszerzenia > Studio Nadamedia. W After Effects: Okno > Rozszerzenia > Studio Nadamedia
(ten sam panel; w AE pokazuje szablony i animacje i buduje je w otwartym projekcie).
Przy pierwszym „Edytuj w After Effects” AE może zapytać o zapis projektu: wybierz „Zapisz”.
"""
import argparse
import json
import os
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, wynik  # noqa: E402

ID = "com.nadamedia.studio"
WERSJE_CSXS = range(9, 14)


def folder_rozszerzen():
    if sys.platform.startswith("win"):
        return Path(os.environ["APPDATA"]) / "Adobe" / "CEP" / "extensions"
    return Path.home() / "Library" / "Application Support" / "Adobe" / "CEP" / "extensions"


def tryb_debug(wlacz=True):
    if sys.platform.startswith("win"):
        import winreg
        for v in WERSJE_CSXS:
            k = winreg.CreateKey(winreg.HKEY_CURRENT_USER, rf"Software\Adobe\CSXS.{v}")
            if wlacz:
                winreg.SetValueEx(k, "PlayerDebugMode", 0, winreg.REG_SZ, "1")
            winreg.CloseKey(k)
    else:
        import subprocess
        for v in WERSJE_CSXS:
            subprocess.run(["defaults", "write", f"com.adobe.CSXS.{v}", "PlayerDebugMode", "1"], check=False)


def instaluj():
    zrodlo = KATALOG_SILNIKA / "premiere"
    if not (zrodlo / "CSXS" / "manifest.xml").exists():
        blad(f"Brak plików panelu w {zrodlo}")
    cel = folder_rozszerzen() / ID
    cel.parent.mkdir(parents=True, exist_ok=True)
    if cel.exists():
        shutil.rmtree(cel)
    shutil.copytree(zrodlo, cel)
    py = Path(sys.executable)
    if py.name.lower() == "pythonw.exe":
        py = py.with_name("python.exe")
    claude = shutil.which("claude") or ""
    if not claude and sys.platform.startswith("win"):
        for k in (Path.home() / ".local" / "bin" / "claude.exe", Path(os.environ.get("APPDATA", "")) / "npm" / "claude.cmd"):
            if k.exists():
                claude = str(k)
                break
    ffmpeg = shutil.which("ffmpeg") or "ffmpeg"
    import sciezki
    (cel / "config.json").write_text(json.dumps({"silnik": str(KATALOG_SILNIKA), "python": str(py), "claude": claude, "ffmpeg": ffmpeg,
                                                 "sciezki": sciezki.wczytaj().get("foldery", [])},
                                                ensure_ascii=False, indent=1), encoding="utf-8")
    tryb_debug(True)
    uwagi = []
    if not shutil.which("ffmpeg"):
        uwagi.append("Nie widzę ffmpeg w PATH: animacje z panelu nie zapiszą się do pliku, dopóki go nie dodasz.")
    animacje = KATALOG_SILNIKA / "narzedzia" / "animacje"
    npm = shutil.which("npm") or shutil.which("npm.cmd")
    if npm and not (animacje / "node_modules" / "@napi-rs" / "canvas").exists():
        import subprocess
        r = subprocess.run([npm, "install", "--no-audit", "--no-fund"], cwd=animacje, capture_output=True, text=True,
                           encoding="utf-8", errors="replace", shell=sys.platform.startswith("win"))
        if r.returncode != 0:
            uwagi.append("Nie udało się npm install w narzedzia/animacje (animacje z panelu działają, Claude nie wyrenderuje własnych): " + r.stderr[-200:])
    elif not npm:
        uwagi.append("Brak Node.js: animacje z panelu działają, ale Claude nie wyrenderuje własnych animacji (zainstaluj Node.js LTS i uruchom --instaluj ponownie).")
    if not claude:
        uwagi.append("Nie znalazłem Claude Code: cięcie, multicam i animacje z biblioteki działają, ale wpadki sprawdzi tylko regułami, a aftermovie i animacje z opisu nie ruszą.")
    wynik(panel=str(cel), claude=claude or None, python=str(py),
          dalej="Zamknij i otwórz Premiere, potem Okno > Rozszerzenia > Studio Nadamedia.", uwagi=uwagi)


def odinstaluj():
    cel = folder_rozszerzen() / ID
    if cel.exists():
        shutil.rmtree(cel)
    wynik(usunieto=str(cel))


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Panel Studio Nadamedia w Premiere Pro")
    g = p.add_mutually_exclusive_group(required=True)
    g.add_argument("--instaluj", action="store_true")
    g.add_argument("--odinstaluj", action="store_true")
    a = p.parse_args()
    instaluj() if a.instaluj else odinstaluj()
