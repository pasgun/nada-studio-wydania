/* Szablony rolek i stories Studio Nadamedia (w stylu szablonów Instagram Stories z Envato).
 *
 * Szablon to PRZEPIS, nie wideo: lista warstw (zdjęcia, teksty, kształty) z ruchem wejścia i wyjścia.
 * Z jednego przepisu powstaje:
 *   - podgląd i render (canvas): panel w Premiere/After Effects, Studio, node (render.js),
 *   - edytowalna kompozycja After Effects (ae_buduj.jsx dostaje wynik NMSzablony.doAE(...)).
 *
 * Układ bazowy 1080 × 1920 (9:16). Kolory to żetony: $tl (tło), $t (tekst), $a (akcent), $g (plama / drugie tło),
 * $d (tekst drugorzędny) albo zwykły #hex. Fonty: "n" (nagłówki, domyślnie Oswald) i "t" (tekst, domyślnie Montserrat).
 *
 * Warstwy:
 *   prost   {x, y, w, h, kolor, r (zaokrąglenie), obrys (grubość: tylko obrys)}
 *   kolo    {x, y (środek), r, kolor, obrys}
 *   trojkat {x, y (środek), r, kolor, obrot}
 *   linia   {x1, y1, x2, y2, kolor, g (grubość)}
 *   cien    {x, y, w, h, kolor, od (krycie u góry), do (krycie u dołu)}   pionowe przejście koloru (np. pod tekst na zdjęciu)
 *   zdjecie {pole, x, y, w, h, maska: prost|kolo|romb|luk|zaokr|{x,y,w,h}, r, bw, ruch: [skala_od, skala_do], dopasuj: wypelnij|zawrzyj}
 *   tekst   {pole albo tekst, x, y (góra), rozmiar, font n|t, waga, kolor, wyr lewo|srodek|prawo, szer (zawijanie), interlinia,
 *            rozstaw (1/1000 em jak w AE), wielkie, obrot}
 * Każda warstwa: we {typ, t, d, e} (wejście), wy {...} (wyjście; domyślnie wspólne wyjście szablonu), krycie, obrot.
 * Ruchy: zanik, gora, dol, lewo, prawo, skala, pop, zoom, odkryj-lewo, odkryj-prawo, odkryj-gora, odkryj-dol,
 *        maska-gora, rysuj (linia, obrys), pisz (tekst litera po literze), licz (liczba w tekście rośnie od zera).
 * Wygładzenie e: plynnie (domyślnie), ostro, sprezyna.
 */
(function (root, factory) {
  if (typeof module === "object" && module.exports) module.exports = factory();
  else root.NMSzablony = factory();
})(typeof self !== "undefined" ? self : this, function () {
  "use strict";

  const BW = 1080, BH = 1920;
  const clamp = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
  const lerp = (a, b, t) => a + (b - a) * t;
  const EASE = {
    plynnie: (t) => 1 - Math.pow(1 - t, 4),
    ostro: (t) => (t >= 1 ? 1 : 1 - Math.pow(2, -10 * t)),
    sprezyna: (t) => { const c1 = 2.2, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); },
    lin: (t) => t,
    wej: (t) => t * t * t,
  };

  // ---------- kolory ----------
  function hex(h) {
    let s = String(h || "#000").replace("#", "").trim();
    if (s.length === 3) s = s.split("").map((c) => c + c).join("");
    const n = parseInt(s.slice(0, 6), 16) || 0;
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  const rgba = (h, a) => { const [r, g, b] = hex(h); return `rgba(${r},${g},${b},${a})`; };
  function kolor(k, kol) { return typeof k === "string" && k[0] === "$" ? (kol[k.slice(1)] || "#ff00ff") : k || kol.t; }

  // ---------- pola ----------
  const zd = (id, etykieta) => ({ id, typ: "zdjecie", etykieta });
  const tx = (id, etykieta, dom, wiersze) => ({ id, typ: "tekst", etykieta, dom, wiersze: wiersze || (String(dom).includes("\n") ? 2 : 1) });
  const lg = (id, etykieta) => ({ id, typ: "zdjecie", etykieta, logo: true });

  // ---------- warstwy (skróty do pisania szablonów) ----------
  const W = (typ, t = 0, d = 0.7, e) => ({ typ, t, d, e });
  const P = (x, y, w, h, kolor, o = {}) => ({ typ: "prost", x, y, w, h, kolor, ...o });
  const K = (x, y, r, kolor, o = {}) => ({ typ: "kolo", x, y, r, kolor, ...o });
  const TR = (x, y, r, kolor, o = {}) => ({ typ: "trojkat", x, y, r, kolor, ...o });
  const L = (x1, y1, x2, y2, kolor, g = 3, o = {}) => ({ typ: "linia", x1, y1, x2, y2, kolor, g, ...o });
  const C = (x, y, w, h, kolor, od, doo, o = {}) => ({ typ: "cien", x, y, w, h, kolor, od, do: doo, ...o });
  const Z = (pole, x, y, w, h, o = {}) => ({ typ: "zdjecie", pole, x, y, w, h, ...o });
  const T = (pole, x, y, o = {}) => ({ typ: "tekst", pole, x, y, ...o });
  const TL = (tekst, x, y, o = {}) => ({ typ: "tekst", tekst, x, y, ...o });

  const CIEMNE = { tl: "#111111", t: "#FFFFFF", a: "#FFFFFF", g: "#2A2A2A", d: "#9C9C9C" };
  const JASNE = { tl: "#ECECEC", t: "#111111", a: "#111111", g: "#FFFFFF", d: "#7A7A7A" };
  const BIALE = { tl: "#FFFFFF", t: "#111111", a: "#111111", g: "#F1F1F1", d: "#8A8A8A" };

  const KATEGORIE = [
    { id: "edytorskie", nazwa: "Edytorskie" },
    { id: "minimal", nazwa: "Minimalistyczne" },
    { id: "ksztalty", nazwa: "Koła i romby" },
    { id: "kolaz", nazwa: "Kolaże" },
    { id: "statystyki", nazwa: "Liczby i obserwujący" },
    { id: "cytaty", nazwa: "Cytaty i hasła" },
    { id: "promocje", nazwa: "Promocje i produkty" },
    { id: "wydarzenia", nazwa: "Wydarzenia" },
    { id: "lifestyle", nazwa: "Podróże i lifestyle" },
    { id: "zakonczenia", nazwa: "Zapowiedzi i zakończenia" },
    { id: "wlasne", nazwa: "Własne" },
  ];

  const SZABLONY = [];
  const dodaj = (s) => { const i = SZABLONY.findIndex((x) => x.id === s.id); if (i >= 0) SZABLONY.splice(i, 1, s); else SZABLONY.push(s); return s; };

  // ======================= EDYTORSKIE =======================
  dodaj({ id: "ed-walizka", nazwa: "Zdjęcie u góry, tytuł na dole", kat: "edytorskie", czas: 8, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie główne"), zd("z2", "Małe zdjęcie w kółku"), tx("etykieta", "Nadtytuł", "GET INSPIRED"), tx("tytul", "Tytuł", "LIVE LIFE\nOUT OF A SUITCASE"),
      tx("opis", "Opis", "Krótki opis w dwóch linijkach, który dopowiada, o co chodzi w tej historii.", 2), tx("stopka", "Stopka", "TWOJASTRONA.PL")],
    warstwy: [
      Z("z1", 0, 0, 1080, 1010, { ruch: [1.15, 1], we: W("odkryj-gora", 0.05, 1) }),
      P(800, 830, 150, 440, "$d", { r: 75, krycie: 0.55, we: W("odkryj-gora", 0.7, 0.7) }),
      Z("z2", 810, 1125, 130, 130, { maska: "kolo", we: W("pop", 1.2, 0.6, "sprezyna") }),
      T("etykieta", 90, 1100, { rozmiar: 24, font: "t", waga: 600, rozstaw: 250, kolor: "$d", we: W("lewo", 0.8, 0.6) }),
      T("tytul", 90, 1150, { rozmiar: 104, font: "n", waga: 700, interlinia: 1.02, wielkie: true, maks: 700, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 90, 1420, { rozmiar: 30, font: "t", szer: 640, kolor: "$d", interlinia: 1.45, we: W("gora", 1.3, 0.6) }),
      T("stopka", 90, 1790, { rozmiar: 24, font: "t", waga: 600, rozstaw: 200, we: W("zanik", 1.6, 0.6) }),
      L(870, 1795, 990, 1795, "$t", 3, { we: W("rysuj", 1.7, 0.6) }),
    ] });
  dodaj({ id: "ed-kola", nazwa: "Dwa zdjęcia w kołach i linia", kat: "edytorskie", czas: 8, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie w dużym kole"), zd("z2", "Zdjęcie w małym kole"), tx("tytul", "Tytuł", "STRESS LESS\nAND ENJOY THE BEST"), tx("opis", "Opis", "Lorem ipsum dolor sit amet, consectetur adipiscing elit sed do eiusmod.", 2), tx("stopka", "Stopka", "TWOJASTRONA.PL")],
    warstwy: [
      L(70, 1190, 1010, 560, "$t", 3, { we: W("rysuj", 0.2, 1.1) }),
      Z("z1", 160, 320, 560, 560, { maska: "kolo", bw: true, ruch: [1.2, 1.05], we: W("skala", 0.3, 0.9) }),
      Z("z2", 560, 740, 430, 430, { maska: "kolo", ruch: [1.15, 1], we: W("skala", 0.6, 0.9) }),
      K(470, 1060, 18, "$t", { we: W("pop", 1.1, 0.5, "sprezyna") }),
      T("tytul", 90, 1330, { rozmiar: 104, font: "n", waga: 700, interlinia: 1.02, wielkie: true, we: W("maska-gora", 1.0, 0.8) }),
      T("opis", 90, 1580, { rozmiar: 30, font: "t", szer: 640, kolor: "$d", interlinia: 1.45, we: W("gora", 1.3, 0.6) }),
      P(90, 1750, 6, 60, "$t", { we: W("odkryj-gora", 1.4, 0.5) }),
      T("stopka", 90, 1830, { rozmiar: 22, font: "t", waga: 600, rozstaw: 200, kolor: "$d", we: W("zanik", 1.6, 0.6) }),
      P(950, 1790, 40, 40, "$t", { we: W("pop", 1.7, 0.5) }),
    ] });
  dodaj({ id: "ed-portret", nazwa: "Portret w ramce na jasnym tle", kat: "edytorskie", czas: 8, kolory: JASNE,
    pola: [zd("z1", "Portret"), tx("nad", "Nadtytuł", "EXPERIENCE THE DIFFERENCE"), tx("tytul", "Tytuł", "FAVORITE BRANDS\nAND HOTTEST TRENDS"), tx("opis", "Opis", "Opis w jednej albo dwóch linijkach pod tytułem.", 2), tx("p1", "Przycisk 1", "PROMO"), tx("p2", "Przycisk 2", "SKLEP")],
    warstwy: [
      P(170, 230, 740, 1000, "#111111", { we: W("odkryj-dol", 0.05, 0.8) }),
      Z("z1", 210, 270, 660, 920, { bw: true, ruch: [1.15, 1], we: W("zanik", 0.5, 0.9) }),
      L(820, 160, 1040, 520, "$t", 3, { we: W("rysuj", 0.9, 0.7) }),
      K(120, 1000, 14, "$t", { we: W("pop", 1.0, 0.5) }), K(960, 600, 10, "$t", { we: W("pop", 1.1, 0.5) }),
      T("nad", 540, 1300, { rozmiar: 22, font: "t", waga: 600, rozstaw: 250, wyr: "srodek", we: W("zanik", 0.9, 0.6) }),
      T("tytul", 540, 1345, { rozmiar: 92, font: "n", waga: 700, interlinia: 1.04, wielkie: true, wyr: "srodek", we: W("maska-gora", 1.0, 0.8) }),
      T("opis", 540, 1560, { rozmiar: 28, font: "t", szer: 760, wyr: "srodek", kolor: "$d", we: W("gora", 1.3, 0.6) }),
      P(360, 1680, 160, 58, "$t", { obrys: 3, we: W("zanik", 1.5, 0.5) }), T("p1", 440, 1696, { rozmiar: 22, font: "t", waga: 700, wyr: "srodek", rozstaw: 150, we: W("zanik", 1.5, 0.5) }),
      P(560, 1680, 160, 58, "$t", { we: W("zanik", 1.6, 0.5) }), T("p2", 640, 1696, { rozmiar: 22, font: "t", waga: 700, wyr: "srodek", rozstaw: 150, kolor: "$tl", we: W("zanik", 1.6, 0.5) }),
      L(420, 1830, 660, 1830, "$t", 4, { we: W("rysuj", 1.8, 0.6) }),
    ] });
  dodaj({ id: "ed-przygoda", nazwa: "Duże zdjęcie, dwa małe i przycisk play", kat: "edytorskie", czas: 8, kolory: JASNE,
    pola: [zd("z1", "Zdjęcie główne"), zd("z2", "Małe zdjęcie 1"), zd("z3", "Małe zdjęcie 2"), tx("nad", "Nadtytuł", "GET TRAVEL INSPIRED"), tx("tytul", "Tytuł", "THE ADVENTURE\nLIFESTYLE"), tx("opis", "Opis", "Krótki opis przygody w jednej linijce.")],
    warstwy: [
      P(0, 0, 1080, 160, "#111111", { we: W("odkryj-dol", 0, 0.5) }),
      T("nad", 90, 64, { rozmiar: 22, font: "t", waga: 600, rozstaw: 200, kolor: "#FFFFFF", we: W("zanik", 0.4, 0.5) }),
      Z("z1", 60, 200, 960, 880, { ruch: [1.15, 1], we: W("odkryj-dol", 0.2, 0.9) }),
      Z("z2", 30, 700, 280, 190, { we: W("lewo", 0.8, 0.6) }), Z("z3", 30, 905, 280, 190, { we: W("lewo", 0.95, 0.6) }),
      T("tytul", 540, 1170, { rozmiar: 96, font: "n", waga: 700, interlinia: 1.02, wielkie: true, wyr: "srodek", we: W("maska-gora", 1.0, 0.8) }),
      T("opis", 540, 1400, { rozmiar: 28, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.3, 0.6) }),
      P(470, 1520, 140, 140, "#1D2B4A", { r: 10, we: W("pop", 1.4, 0.6, "sprezyna") }), TR(548, 1590, 36, "#FFFFFF", { obrot: 90, we: W("pop", 1.55, 0.6, "sprezyna") }),
      L(130, 1590, 220, 1590, "$t", 4, { we: W("rysuj", 1.6, 0.5) }), L(860, 1590, 950, 1590, "$t", 4, { we: W("rysuj", 1.6, 0.5) }),
    ] });
  dodaj({ id: "ed-okladka", nazwa: "Okładka magazynu", kat: "edytorskie", czas: 7, kolory: { ...CIEMNE, a: "#FFFFFF" },
    pola: [zd("z1", "Zdjęcie na całość"), tx("tytul", "Nazwa magazynu", "VOGUE STYLE"), tx("numer", "Numer i data", "NR 10 · PAŹDZIERNIK 2026"), tx("naglowek", "Nagłówek", "Nowa kolekcja\njuż jest"), tx("opis", "Dopisek", "Wywiad, sesja i 12 stron inspiracji")],
    warstwy: [
      Z("z1", 0, 0, 1080, 1920, { ruch: [1.2, 1.02], we: W("zanik", 0, 0.8) }),
      C(0, 0, 1080, 520, "#000000", 0.55, 0), C(0, 1180, 1080, 740, "#000000", 0, 0.75),
      T("tytul", 540, 110, { rozmiar: 190, font: "n", waga: 700, wyr: "srodek", wielkie: true, rozstaw: 20, we: W("maska-gora", 0.3, 0.9) }),
      T("numer", 540, 340, { rozmiar: 24, font: "t", waga: 600, wyr: "srodek", rozstaw: 300, we: W("zanik", 0.8, 0.6) }),
      T("naglowek", 80, 1450, { rozmiar: 96, font: "n", waga: 700, interlinia: 1.0, wielkie: true, szer: 900, we: W("maska-gora", 0.9, 0.8) }),
      L(80, 1700, 300, 1700, "$a", 5, { we: W("rysuj", 1.2, 0.6) }),
      T("opis", 80, 1740, { rozmiar: 30, font: "t", szer: 900, we: W("gora", 1.3, 0.6) }),
    ] });
  dodaj({ id: "ed-polaroid", nazwa: "Zdjęcie w białej ramce", kat: "edytorskie", czas: 7, kolory: { ...CIEMNE, g: "#FFFFFF" },
    pola: [zd("z1", "Zdjęcie"), tx("podpis", "Podpis na ramce", "summer '26"), tx("tytul", "Tytuł", "MEMORIES\nWE MADE"), tx("opis", "Opis", "Krótki opis albo miejsce")],
    warstwy: [
      P(150, 260, 780, 940, "$g", { obrot: -4, we: W("pop", 0.1, 0.8, "sprezyna") }),
      Z("z1", 190, 300, 700, 720, { obrot: -4, ruch: [1.12, 1], we: W("zanik", 0.5, 0.7) }),
      T("podpis", 540, 1060, { rozmiar: 44, font: "t", waga: 500, wyr: "srodek", kolor: "#222222", obrot: -4, we: W("pisz", 0.9, 0.8) }),
      T("tytul", 90, 1350, { rozmiar: 120, font: "n", waga: 700, interlinia: 1.0, wielkie: true, we: W("maska-gora", 1.0, 0.8) }),
      T("opis", 90, 1620, { rozmiar: 30, font: "t", kolor: "$d", we: W("gora", 1.3, 0.6) }),
      L(90, 1720, 290, 1720, "$t", 4, { we: W("rysuj", 1.5, 0.6) }),
    ] });
  dodaj({ id: "ed-pasy", nazwa: "Zdjęcie w trzech pasach", kat: "edytorskie", czas: 7, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "URBAN\nSTORIES"), tx("opis", "Opis", "Miasto, ludzie i światło")],
    warstwy: [
      Z("z1", 90, 150, 900, 1150, { maska: { x: 90, y: 150, w: 290, h: 1150 }, ruch: [1.12, 1], we: W("odkryj-dol", 0.1, 0.8) }),
      Z("z1", 90, 150, 900, 1150, { maska: { x: 395, y: 150, w: 290, h: 1150 }, ruch: [1.12, 1], we: W("odkryj-gora", 0.25, 0.8) }),
      Z("z1", 90, 150, 900, 1150, { maska: { x: 700, y: 150, w: 290, h: 1150 }, ruch: [1.12, 1], we: W("odkryj-dol", 0.4, 0.8) }),
      T("tytul", 90, 1400, { rozmiar: 130, font: "n", waga: 700, interlinia: 0.98, wielkie: true, we: W("maska-gora", 1.0, 0.8) }),
      T("opis", 90, 1680, { rozmiar: 32, font: "t", kolor: "$d", we: W("gora", 1.3, 0.6) }),
      P(930, 1690, 60, 60, "$a", { obrys: 3, we: W("pop", 1.5, 0.5) }),
    ] });

  // ======================= MINIMAL =======================
  dodaj({ id: "mi-pionowy", nazwa: "Pionowy napis obok zdjęcia", kat: "minimal", czas: 8, kolory: BIALE,
    pola: [zd("z1", "Zdjęcie"), tx("slowo", "Pionowy napis", "Minimalist"), tx("tag", "Mały napis u góry", "#twojprofil"), tx("opis", "Opis", "Krótki opis pod zdjęciem.")],
    warstwy: [
      T("tag", 170, 330, { rozmiar: 30, font: "t", waga: 500, we: W("zanik", 0.2, 0.6) }),
      L(170, 385, 520, 385, "$t", 2, { we: W("rysuj", 0.3, 0.6) }),
      Z("z1", 330, 520, 580, 900, { bw: true, ruch: [1.1, 1], we: W("odkryj-gora", 0.4, 0.9) }),
      TR(380, 570, 70, "#111111", { obrot: 225, we: W("zanik", 1.0, 0.5) }),
      T("slowo", 245, 1420, { rozmiar: 88, font: "t", waga: 700, obrot: -90, we: W("odkryj-dol", 0.8, 0.8) }),
      T("opis", 330, 1480, { rozmiar: 28, font: "t", szer: 560, kolor: "$d", we: W("gora", 1.2, 0.6) }),
    ] });
  dodaj({ id: "mi-projekt", nazwa: "Imię, projekt i zdjęcie", kat: "minimal", czas: 8, kolory: BIALE,
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł (cienki)", "Your name\nProject"), tx("podpis", "Podpis", "ONLY ON INSTAGRAM"), tx("przycisk", "Przycisk", "SPRAWDŹ")],
    warstwy: [
      L(200, 280, 200, 470, "$t", 2, { we: W("rysuj", 0.1, 0.5) }),
      T("tytul", 230, 280, { rozmiar: 84, font: "t", waga: 300, interlinia: 1.05, we: W("lewo", 0.3, 0.8) }),
      Z("z1", 240, 620, 600, 760, { bw: true, ruch: [1.12, 1], we: W("odkryj-dol", 0.5, 0.9) }),
      T("podpis", 540, 1470, { rozmiar: 26, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, we: W("zanik", 1.1, 0.6) }),
      P(470, 1570, 140, 44, "#111111", { we: W("odkryj-lewo", 1.3, 0.5) }),
      T("przycisk", 540, 1580, { rozmiar: 18, font: "t", waga: 700, wyr: "srodek", rozstaw: 200, kolor: "#FFFFFF", we: W("zanik", 1.5, 0.4) }),
    ] });
  dodaj({ id: "mi-blok", nazwa: "Zdjęcie na kolorowym bloku", kat: "minimal", czas: 8, kolory: { ...BIALE, a: "#E8B730" },
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "Stories"), tx("opis", "Opis", "Minimalistyczny opis w dwóch krótkich linijkach tekstu.", 2)],
    warstwy: [
      P(300, 360, 560, 760, "$a", { we: W("odkryj-gora", 0.1, 0.8) }),
      Z("z1", 220, 440, 560, 760, { ruch: [1.12, 1], we: W("odkryj-dol", 0.4, 0.9) }),
      T("tytul", 540, 1340, { rozmiar: 64, font: "t", waga: 600, wyr: "srodek", rozstaw: 120, we: W("maska-gora", 1.0, 0.7) }),
      T("opis", 540, 1450, { rozmiar: 26, font: "t", wyr: "srodek", szer: 620, kolor: "$d", interlinia: 1.5, we: W("gora", 1.2, 0.6) }),
      L(500, 1600, 580, 1600, "$t", 3, { we: W("rysuj", 1.4, 0.5) }),
    ] });
  dodaj({ id: "mi-ramka", nazwa: "Zdjęcie z przesuniętą ramką", kat: "minimal", czas: 8, kolory: BIALE,
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "After Effects\ntemplate"), tx("etykieta", "Etykieta", "STYLE")],
    warstwy: [
      Z("z1", 270, 330, 600, 900, { ruch: [1.12, 1], we: W("zanik", 0.2, 0.8) }),
      P(220, 400, 560, 940, "$t", { obrys: 4, we: W("rysuj", 0.6, 1.0) }),
      P(440, 1310, 200, 50, "#111111", { we: W("odkryj-lewo", 1.0, 0.5) }),
      T("etykieta", 540, 1322, { rozmiar: 22, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, kolor: "#FFFFFF", we: W("zanik", 1.2, 0.4) }),
      T("tytul", 540, 1450, { rozmiar: 64, font: "t", waga: 600, wyr: "srodek", rozstaw: 80, interlinia: 1.1, we: W("maska-gora", 1.2, 0.8) }),
    ] });
  dodaj({ id: "mi-dwa", nazwa: "Dwa zdjęcia jedno nad drugim", kat: "minimal", czas: 8, kolory: BIALE,
    pola: [zd("z1", "Zdjęcie górne"), zd("z2", "Zdjęcie dolne"), tx("tytul", "Tytuł", "Envato\nmarket"), tx("etykieta", "Etykieta", "INSTAGRAM"), tx("opis", "Opis", "Krótki tekst o projekcie w kilku linijkach, wyrównany do lewej.", 3)],
    warstwy: [
      T("tytul", 120, 220, { rozmiar: 76, font: "t", waga: 700, interlinia: 1.05, we: W("lewo", 0.2, 0.8) }),
      Z("z1", 600, 160, 380, 820, { bw: true, ruch: [1.1, 1], we: W("odkryj-dol", 0.3, 0.9) }),
      T("etykieta", 120, 560, { rozmiar: 24, font: "t", waga: 600, rozstaw: 250, we: W("zanik", 0.8, 0.6) }),
      T("opis", 120, 640, { rozmiar: 26, font: "t", szer: 420, kolor: "$d", interlinia: 1.5, we: W("gora", 1.0, 0.6) }),
      Z("z2", 120, 1060, 840, 700, { ruch: [1.12, 1], we: W("odkryj-gora", 0.9, 0.9) }),
    ] });
  dodaj({ id: "mi-tekst", nazwa: "Sam napis między liniami", kat: "minimal", czas: 6, kolory: BIALE,
    pola: [tx("nad", "Mały napis", "MINIMALISM"), tx("tytul", "Napis", "Less is\nmore"), tx("podpis", "Podpis", "kolekcja jesień 2026")],
    warstwy: [
      T("nad", 540, 620, { rozmiar: 24, font: "t", waga: 600, wyr: "srodek", rozstaw: 400, we: W("zanik", 0.1, 0.6) }),
      L(240, 700, 840, 700, "$t", 2, { we: W("rysuj", 0.2, 0.8) }),
      T("tytul", 540, 780, { rozmiar: 150, font: "t", waga: 300, wyr: "srodek", interlinia: 1.0, we: W("maska-gora", 0.5, 0.9) }),
      L(240, 1150, 840, 1150, "$t", 2, { we: W("rysuj", 0.6, 0.8) }),
      T("podpis", 540, 1200, { rozmiar: 30, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.0, 0.6) }),
    ] });

  // ======================= KSZTAŁTY =======================
  dodaj({ id: "ks-romby", nazwa: "Zdjęcia w rombach", kat: "ksztalty", czas: 8, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie w dużym rombie"), zd("z2", "Zdjęcie w małym rombie"), tx("tytul", "Tytuł", "KEEP CALM AND\nNEVER STOP TRAVELLING"), tx("stopka", "Stopka", "@twojprofil")],
    warstwy: [
      T("tytul", 540, 230, { rozmiar: 64, font: "n", waga: 700, interlinia: 1.05, wielkie: true, wyr: "srodek", we: W("maska-gora", 0.1, 0.8) }),
      Z("z1", 200, 520, 680, 680, { maska: "romb", ruch: [1.15, 1], we: W("skala", 0.4, 0.9) }),
      Z("z2", 330, 1130, 420, 420, { maska: "romb", bw: true, ruch: [1.15, 1], we: W("skala", 0.7, 0.9) }),
      K(170, 1300, 12, "$t", { we: W("pop", 1.1, 0.4) }), K(910, 860, 12, "$t", { we: W("pop", 1.2, 0.4) }),
      T("stopka", 540, 1760, { rozmiar: 28, font: "t", waga: 600, wyr: "srodek", rozstaw: 120, kolor: "$d", we: W("zanik", 1.3, 0.6) }),
    ] });
  dodaj({ id: "ks-kolo", nazwa: "Duże koło ze zdjęciem", kat: "ksztalty", czas: 8, kolory: JASNE,
    pola: [zd("z1", "Zdjęcie w kole"), tx("tytul", "Tytuł", "FALL IN LOVE\nWITH THE COLLECTION"), tx("opis", "Opis", "Nowe wzory, te same wygody. Sprawdź całą kolekcję.", 2), tx("przycisk", "Przycisk", "KUP TERAZ")],
    warstwy: [
      K(540, 680, 390, "$t", { obrys: 3, we: W("rysuj", 0.1, 1.0) }),
      Z("z1", 180, 320, 720, 720, { maska: "kolo", bw: true, ruch: [1.2, 1.02], we: W("skala", 0.3, 0.9) }),
      L(90, 680, 150, 680, "$t", 3, { we: W("rysuj", 0.8, 0.4) }), L(930, 680, 990, 680, "$t", 3, { we: W("rysuj", 0.8, 0.4) }),
      T("tytul", 540, 1180, { rozmiar: 86, font: "n", waga: 700, wyr: "srodek", interlinia: 1.04, wielkie: true, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 540, 1410, { rozmiar: 28, font: "t", wyr: "srodek", szer: 760, kolor: "$d", we: W("gora", 1.2, 0.6) }),
      P(390, 1560, 300, 80, "$t", { we: W("odkryj-lewo", 1.4, 0.6) }),
      T("przycisk", 540, 1584, { rozmiar: 26, font: "t", waga: 700, wyr: "srodek", rozstaw: 200, kolor: "$tl", we: W("zanik", 1.6, 0.4) }),
    ] });
  dodaj({ id: "ks-luk", nazwa: "Zdjęcie w łuku", kat: "ksztalty", czas: 8, kolory: { tl: "#EFE8DF", t: "#2B2420", a: "#B8794A", g: "#FFFFFF", d: "#8C7B6E" },
    pola: [zd("z1", "Zdjęcie w łuku"), tx("nad", "Nadtytuł", "NEW SEASON"), tx("tytul", "Tytuł", "Slow\nmornings"), tx("opis", "Opis", "Kawa, światło i dobra książka.")],
    warstwy: [
      Z("z1", 190, 260, 700, 1000, { maska: "luk", ruch: [1.15, 1], we: W("odkryj-gora", 0.1, 1.0) }),
      K(860, 300, 70, "$a", { we: W("pop", 0.8, 0.6, "sprezyna") }),
      T("nad", 540, 1340, { rozmiar: 24, font: "t", waga: 600, wyr: "srodek", rozstaw: 400, kolor: "$a", we: W("zanik", 0.9, 0.6) }),
      T("tytul", 540, 1390, { rozmiar: 120, font: "t", waga: 300, wyr: "srodek", interlinia: 1.0, we: W("maska-gora", 1.0, 0.8) }),
      T("opis", 540, 1680, { rozmiar: 30, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.3, 0.6) }),
    ] });
  dodaj({ id: "ks-zaokr", nazwa: "Zaokrąglone kafle", kat: "ksztalty", czas: 8, kolory: { tl: "#101820", t: "#FFFFFF", a: "#7CE0C3", g: "#1C2833", d: "#8FA3B5" },
    pola: [zd("z1", "Zdjęcie 1"), zd("z2", "Zdjęcie 2"), zd("z3", "Zdjęcie 3"), tx("tytul", "Tytuł", "Weekend\nvibes"), tx("tag", "Tag", "#lifestyle")],
    warstwy: [
      Z("z1", 80, 180, 560, 760, { maska: "zaokr", r: 60, ruch: [1.12, 1], we: W("gora", 0.1, 0.8) }),
      Z("z2", 660, 180, 340, 360, { maska: "zaokr", r: 60, we: W("gora", 0.25, 0.8) }),
      Z("z3", 660, 560, 340, 380, { maska: "zaokr", r: 60, we: W("gora", 0.4, 0.8) }),
      P(80, 980, 920, 560, "$g", { r: 60, we: W("gora", 0.55, 0.8) }),
      T("tytul", 150, 1060, { rozmiar: 130, font: "n", waga: 700, interlinia: 0.98, wielkie: true, we: W("maska-gora", 0.9, 0.8) }),
      P(150, 1420, 260, 64, "$a", { r: 32, we: W("odkryj-lewo", 1.2, 0.5) }),
      T("tag", 280, 1437, { rozmiar: 28, font: "t", waga: 700, wyr: "srodek", kolor: "$tl", we: W("zanik", 1.4, 0.4) }),
    ] });

  // ======================= KOLAŻE =======================
  dodaj({ id: "ko-trzy", nazwa: "Kolaż: jedno duże i dwa małe", kat: "kolaz", czas: 8, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie duże"), zd("z2", "Zdjęcie małe 1"), zd("z3", "Zdjęcie małe 2"), tx("tytul", "Tytuł", "INSTAGRAM\nSTORIES"), tx("opis", "Opis", "Lorem ipsum dolor sit amet")],
    warstwy: [
      Z("z1", 80, 160, 920, 900, { ruch: [1.12, 1], we: W("odkryj-dol", 0.1, 0.8) }),
      Z("z2", 80, 1090, 445, 460, { bw: true, we: W("odkryj-gora", 0.4, 0.8) }),
      Z("z3", 555, 1090, 445, 460, { we: W("odkryj-dol", 0.55, 0.8) }),
      P(0, 1600, 1080, 320, "$tl"),
      T("tytul", 80, 1610, { rozmiar: 90, font: "n", waga: 700, interlinia: 0.98, wielkie: true, we: W("maska-gora", 0.9, 0.7) }),
      T("opis", 1000, 1690, { rozmiar: 26, font: "t", wyr: "prawo", kolor: "$d", we: W("zanik", 1.2, 0.6) }),
    ] });
  dodaj({ id: "ko-siatka", nazwa: "Siatka 2×2 z tytułem w środku", kat: "kolaz", czas: 8, kolory: BIALE,
    pola: [zd("z1", "Zdjęcie 1"), zd("z2", "Zdjęcie 2"), zd("z3", "Zdjęcie 3"), zd("z4", "Zdjęcie 4"), tx("tytul", "Tytuł w środku", "OUR\nWEEK")],
    warstwy: [
      Z("z1", 0, 0, 540, 960, { ruch: [1.1, 1], we: W("odkryj-dol", 0.0, 0.7) }),
      Z("z2", 540, 0, 540, 960, { ruch: [1.1, 1], we: W("odkryj-gora", 0.15, 0.7) }),
      Z("z3", 0, 960, 540, 960, { ruch: [1.1, 1], we: W("odkryj-dol", 0.3, 0.7) }),
      Z("z4", 540, 960, 540, 960, { ruch: [1.1, 1], we: W("odkryj-gora", 0.45, 0.7) }),
      P(290, 760, 500, 400, "$tl", { we: W("skala", 0.8, 0.6) }),
      T("tytul", 540, 810, { rozmiar: 130, font: "n", waga: 700, wyr: "srodek", interlinia: 0.95, wielkie: true, we: W("maska-gora", 1.0, 0.7) }),
    ] });
  dodaj({ id: "ko-film", nazwa: "Klatki filmu", kat: "kolaz", czas: 8, kolory: CIEMNE,
    pola: [zd("z1", "Klatka 1"), zd("z2", "Klatka 2"), zd("z3", "Klatka 3"), tx("tytul", "Tytuł", "SHOT ON\nFILM")],
    warstwy: [
      P(140, 0, 800, 1920, "#000000", { we: W("zanik", 0, 0.4) }),
      ...[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].flatMap((i) => [P(165, 40 + i * 160, 40, 70, "#2B2B2B"), P(875, 40 + i * 160, 40, 70, "#2B2B2B")]),
      Z("z1", 240, 140, 600, 460, { we: W("odkryj-dol", 0.2, 0.7) }),
      Z("z2", 240, 640, 600, 460, { bw: true, we: W("odkryj-dol", 0.4, 0.7) }),
      Z("z3", 240, 1140, 600, 460, { we: W("odkryj-dol", 0.6, 0.7) }),
      T("tytul", 540, 1660, { rozmiar: 80, font: "n", waga: 700, wyr: "srodek", interlinia: 1.0, wielkie: true, we: W("maska-gora", 1.0, 0.7) }),
    ] });
  dodaj({ id: "ko-schodki", nazwa: "Zdjęcia schodkami", kat: "kolaz", czas: 8, kolory: { tl: "#F4F1EC", t: "#111111", a: "#111111", g: "#FFFFFF", d: "#777777" },
    pola: [zd("z1", "Zdjęcie 1"), zd("z2", "Zdjęcie 2"), zd("z3", "Zdjęcie 3"), tx("tytul", "Tytuł", "NEW\nPOST"), tx("tag1", "Tag 1", "Fashion"), tx("tag2", "Tag 2", "Beauty blog")],
    warstwy: [
      T("tytul", 90, 160, { rozmiar: 150, font: "n", waga: 700, interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.1, 0.8) }),
      Z("z1", 520, 140, 470, 620, { bw: true, we: W("lewo", 0.3, 0.8) }),
      Z("z2", 300, 700, 470, 620, { we: W("prawo", 0.5, 0.8) }),
      Z("z3", 90, 1260, 470, 520, { bw: true, we: W("lewo", 0.7, 0.8) }),
      P(620, 1500, 300, 70, "$t", { r: 35, obrys: 3, we: W("zanik", 1.1, 0.5) }), T("tag1", 770, 1520, { rozmiar: 26, font: "t", wyr: "srodek", we: W("zanik", 1.1, 0.5) }),
      P(620, 1600, 300, 70, "$t", { r: 35, obrys: 3, we: W("zanik", 1.25, 0.5) }), T("tag2", 770, 1620, { rozmiar: 26, font: "t", wyr: "srodek", we: W("zanik", 1.25, 0.5) }),
    ] });

  // ======================= STATYSTYKI =======================
  dodaj({ id: "st-obserwujacy", nazwa: "Licznik obserwujących", kat: "statystyki", czas: 8, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie"), tx("liczba", "Liczba", "70K"), tx("podpis", "Podpis pod liczbą", "FOLLOWERS"), tx("tytul", "Tytuł", "INSTA\nSTORIES"), tx("opis", "Opis", "Dziękujemy, że jesteście z nami!")],
    warstwy: [
      T("liczba", 330, 200, { rozmiar: 210, font: "n", waga: 700, wyr: "srodek", we: W("licz", 0.1, 1.4) }),
      T("podpis", 330, 450, { rozmiar: 40, font: "n", waga: 500, wyr: "srodek", rozstaw: 80, we: W("zanik", 0.6, 0.6) }),
      P(110, 560, 440, 560, "$t", { obrys: 3, we: W("rysuj", 0.5, 0.9) }),
      Z("z1", 140, 590, 380, 500, { ruch: [1.12, 1], we: W("zanik", 0.8, 0.7) }),
      T("opis", 330, 1170, { rozmiar: 26, font: "t", wyr: "srodek", szer: 400, kolor: "$d", we: W("gora", 1.0, 0.6) }),
      L(640, 140, 640, 1780, "$d", 2, { we: W("rysuj", 0.3, 1.0) }),
      T("tytul", 680, 1340, { rozmiar: 124, font: "n", waga: 700, interlinia: 0.95, wielkie: true, we: W("maska-gora", 1.0, 0.8) }),
      K(960, 1740, 48, "$t", { obrys: 3, we: W("pop", 1.4, 0.5) }), TL("NEW", 960, 1725, { rozmiar: 24, font: "t", waga: 700, wyr: "srodek", we: W("zanik", 1.5, 0.4) }),
    ] });
  dodaj({ id: "st-followers-bialy", nazwa: "FOLLOWERS i liczba na białym", kat: "statystyki", czas: 8, kolory: { ...BIALE, d: "#B5B5B5" },
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "FOLLOWERS"), tx("liczba", "Liczba", "73K"), tx("w1", "Napis 1", "LIKE"), tx("w2", "Napis 2", "SHARE"), tx("w3", "Napis 3", "FOLLOW")],
    warstwy: [
      T("tytul", 80, 170, { rozmiar: 110, font: "n", waga: 700, wielkie: true, we: W("maska-gora", 0.1, 0.7) }),
      T("liczba", 1000, 170, { rozmiar: 110, font: "n", waga: 300, wyr: "prawo", kolor: "$d", we: W("licz", 0.4, 1.2) }),
      T("w1", 80, 330, { rozmiar: 24, font: "t", waga: 600, rozstaw: 200, we: W("zanik", 0.7, 0.5) }),
      T("w2", 540, 330, { rozmiar: 24, font: "t", waga: 600, rozstaw: 200, wyr: "srodek", we: W("zanik", 0.8, 0.5) }),
      T("w3", 1000, 330, { rozmiar: 24, font: "t", waga: 600, rozstaw: 200, wyr: "prawo", we: W("zanik", 0.9, 0.5) }),
      Z("z1", 80, 420, 920, 1420, { ruch: [1.12, 1], we: W("odkryj-dol", 0.5, 0.9) }),
    ] });
  dodaj({ id: "st-trzy", nazwa: "Trzy liczby", kat: "statystyki", czas: 8, kolory: CIEMNE,
    pola: [tx("tytul", "Tytuł", "2026 W LICZBACH"), tx("l1", "Liczba 1", "120+"), tx("o1", "Opis 1", "zrealizowanych projektów"), tx("l2", "Liczba 2", "35K"), tx("o2", "Opis 2", "obserwujących"), tx("l3", "Liczba 3", "98%"), tx("o3", "Opis 3", "zadowolonych klientów")],
    warstwy: [
      T("tytul", 90, 200, { rozmiar: 44, font: "t", waga: 700, rozstaw: 150, we: W("lewo", 0.1, 0.7) }),
      ...[0, 1, 2].flatMap((i) => [
        L(90, 470 + i * 430, 990, 470 + i * 430, "$d", 2, { we: W("rysuj", 0.3 + i * 0.25, 0.7) }),
        T("l" + (i + 1), 90, 510 + i * 430, { rozmiar: 190, font: "n", waga: 700, we: W("licz", 0.4 + i * 0.25, 1.2) }),
        T("o" + (i + 1), 90, 740 + i * 430, { rozmiar: 32, font: "t", kolor: "$d", we: W("gora", 0.7 + i * 0.25, 0.6) }),
      ]),
    ] });
  dodaj({ id: "st-procent", nazwa: "Duży procent na zdjęciu", kat: "statystyki", czas: 7, kolory: { ...CIEMNE, a: "#F5C542" },
    pola: [zd("z1", "Zdjęcie w tle"), tx("liczba", "Liczba", "87%"), tx("opis", "Opis", "klientów poleca nas\nznajomym")],
    warstwy: [
      Z("z1", 0, 0, 1080, 1920, { ruch: [1.15, 1.02], bw: true, we: W("zanik", 0, 0.8) }),
      P(0, 0, 1080, 1920, "#000000", { krycie: 0.5 }),
      T("liczba", 540, 640, { rozmiar: 320, font: "n", waga: 700, wyr: "srodek", kolor: "$a", we: W("licz", 0.3, 1.5) }),
      L(390, 1060, 690, 1060, "$t", 4, { we: W("rysuj", 1.0, 0.6) }),
      T("opis", 540, 1110, { rozmiar: 54, font: "t", waga: 600, wyr: "srodek", interlinia: 1.2, we: W("gora", 1.1, 0.7) }),
    ] });

  // ======================= CYTATY I HASŁA =======================
  dodaj({ id: "cy-cudzyslow", nazwa: "Cytat z dużym cudzysłowem", kat: "cytaty", czas: 8, kolory: BIALE,
    pola: [tx("cytat", "Cytat", "Najlepszy czas na start był wczoraj. Drugi najlepszy jest dziś.", 3), tx("autor", "Autor", "— Twoje imię")],
    warstwy: [
      TL("“", 90, 330, { rozmiar: 360, font: "n", waga: 700, kolor: "$a", we: W("pop", 0.1, 0.7, "sprezyna") }),
      T("cytat", 90, 700, { rozmiar: 76, font: "t", waga: 600, szer: 880, interlinia: 1.25, we: W("maska-gora", 0.4, 0.9) }),
      L(90, 1300, 250, 1300, "$t", 4, { we: W("rysuj", 1.0, 0.5) }),
      T("autor", 90, 1340, { rozmiar: 34, font: "t", kolor: "$d", we: W("gora", 1.1, 0.6) }),
      TL("”", 990, 1400, { rozmiar: 360, font: "n", waga: 700, wyr: "prawo", kolor: "$g", we: W("zanik", 1.2, 0.6) }),
    ] });
  dodaj({ id: "cy-zdjecie", nazwa: "Cytat na przyciemnionym zdjęciu", kat: "cytaty", czas: 8, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie w tle"), tx("cytat", "Cytat", "Rób to, co kochasz, a nie przepracujesz ani jednego dnia.", 3), tx("autor", "Autor", "KONFUCJUSZ")],
    warstwy: [
      Z("z1", 0, 0, 1080, 1920, { ruch: [1.15, 1.02], we: W("zanik", 0, 0.8) }),
      P(0, 0, 1080, 1920, "#000000", { krycie: 0.55 }),
      P(140, 640, 800, 640, "$t", { obrys: 3, we: W("rysuj", 0.3, 1.0) }),
      T("cytat", 540, 760, { rozmiar: 62, font: "t", waga: 600, wyr: "srodek", szer: 680, interlinia: 1.3, we: W("gora", 0.7, 0.8) }),
      T("autor", 540, 1180, { rozmiar: 28, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, kolor: "$d", we: W("zanik", 1.1, 0.6) }),
    ] });
  dodaj({ id: "cy-hashtagi", nazwa: "Hashtagi na zdjęciu", kat: "cytaty", czas: 8, kolory: { ...CIEMNE, a: "#FFFFFF" },
    pola: [zd("z1", "Zdjęcie"), tx("lista", "Hashtagi (każdy w linii)", "#CREATE\n#MOOD\n#CHANGE\n#WORLD\n#BE CUTE", 5)],
    warstwy: [
      Z("z1", 0, 0, 1080, 1920, { bw: true, ruch: [1.15, 1], we: W("zanik", 0, 0.8) }),
      P(0, 0, 1080, 1920, "#000000", { krycie: 0.35 }),
      T("lista", 90, 1000, { rozmiar: 104, font: "n", waga: 700, interlinia: 1.05, wielkie: true, we: W("pisz", 0.4, 1.6) }),
    ] });
  dodaj({ id: "cy-karta", nazwa: "Czarna karta z hasłami", kat: "cytaty", czas: 8, kolory: BIALE,
    pola: [tx("lista", "Hasła (każde w linii)", "#CREATE\n#YOUR\n#VISION\n#BE YOUNG\n#BE COOL", 5), tx("podpis", "Podpis", "nadamedia")],
    warstwy: [
      P(280, 520, 520, 880, "#111111", { we: W("odkryj-dol", 0.1, 0.7) }),
      T("lista", 340, 640, { rozmiar: 70, font: "n", waga: 700, interlinia: 1.1, wielkie: true, kolor: "#FFFFFF", we: W("pisz", 0.6, 1.4) }),
      T("podpis", 540, 1480, { rozmiar: 28, font: "t", waga: 600, wyr: "srodek", rozstaw: 300, kolor: "$d", we: W("zanik", 1.4, 0.6) }),
    ] });
  dodaj({ id: "cy-haslo", nazwa: "Hasło dużymi literami", kat: "cytaty", czas: 6, kolory: { tl: "#111111", t: "#FFFFFF", a: "#FF5A36", g: "#1E1E1E", d: "#8A8A8A" },
    pola: [tx("tytul", "Hasło", "DON'T\nSTOP\nCREATING"), tx("podpis", "Podpis", "@twojprofil")],
    warstwy: [
      T("tytul", 90, 560, { rozmiar: 230, font: "n", waga: 700, interlinia: 0.92, wielkie: true, we: W("maska-gora", 0.1, 0.9) }),
      P(90, 1300, 300, 18, "$a", { we: W("odkryj-lewo", 0.8, 0.6) }),
      T("podpis", 90, 1380, { rozmiar: 34, font: "t", waga: 600, kolor: "$d", we: W("zanik", 1.0, 0.6) }),
    ] });

  // ======================= PROMOCJE =======================
  dodaj({ id: "pr-rabat", nazwa: "Rabat procentowy", kat: "promocje", czas: 7, kolory: { tl: "#111111", t: "#FFFFFF", a: "#FF3D3D", g: "#FFFFFF", d: "#A0A0A0" },
    pola: [zd("z1", "Zdjęcie produktu"), tx("liczba", "Rabat", "-50%"), tx("tytul", "Tytuł", "BLACK WEEK"), tx("opis", "Dopisek", "tylko do niedzieli"), tx("przycisk", "Przycisk", "KUP TERAZ")],
    warstwy: [
      Z("z1", 0, 0, 1080, 1000, { ruch: [1.15, 1], we: W("odkryj-gora", 0, 0.8) }),
      T("tytul", 90, 1060, { rozmiar: 70, font: "n", waga: 700, rozstaw: 80, wielkie: true, we: W("lewo", 0.5, 0.6) }),
      T("liczba", 70, 1150, { rozmiar: 330, font: "n", waga: 700, kolor: "$a", we: W("pop", 0.7, 0.8, "sprezyna") }),
      T("opis", 90, 1560, { rozmiar: 40, font: "t", waga: 500, kolor: "$d", we: W("gora", 1.0, 0.6) }),
      P(90, 1680, 420, 110, "$a", { we: W("odkryj-lewo", 1.2, 0.6) }),
      T("przycisk", 300, 1714, { rozmiar: 36, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, we: W("zanik", 1.4, 0.4) }),
    ] });
  dodaj({ id: "pr-produkt", nazwa: "Produkt z ceną", kat: "promocje", czas: 7, kolory: { tl: "#E9E4DC", t: "#1A1A1A", a: "#1A1A1A", g: "#FFFFFF", d: "#7A746C" },
    pola: [zd("z1", "Zdjęcie produktu"), tx("nazwa", "Nazwa", "Ceramic Vase"), tx("opis", "Opis", "Ręcznie robiona, 25 cm"), tx("cena", "Cena", "189 zł")],
    warstwy: [
      P(140, 220, 800, 1080, "$g", { we: W("skala", 0.05, 0.7) }),
      Z("z1", 180, 260, 720, 1000, { ruch: [1.1, 1], we: W("zanik", 0.4, 0.7) }),
      K(860, 1240, 130, "$a", { we: W("pop", 0.9, 0.7, "sprezyna") }),
      T("cena", 860, 1210, { rozmiar: 54, font: "n", waga: 700, wyr: "srodek", kolor: "$tl", we: W("zanik", 1.1, 0.4) }),
      T("nazwa", 140, 1420, { rozmiar: 90, font: "t", waga: 300, we: W("maska-gora", 1.0, 0.7) }),
      T("opis", 140, 1550, { rozmiar: 34, font: "t", kolor: "$d", we: W("gora", 1.2, 0.6) }),
    ] });
  dodaj({ id: "pr-nowosc", nazwa: "Nowość w sklepie", kat: "promocje", czas: 7, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "NEW\nARRIVAL"), tx("opis", "Opis", "Zobacz w sklepie online"), tx("link", "Link", "sklep.pl")],
    warstwy: [
      Z("z1", 0, 0, 1080, 1920, { ruch: [1.15, 1], we: W("zoom", 0, 1.0) }),
      C(0, 1000, 1080, 920, "#000000", 0, 0.85),
      T("tytul", 90, 1200, { rozmiar: 200, font: "n", waga: 700, interlinia: 0.92, wielkie: true, we: W("maska-gora", 0.5, 0.9) }),
      T("opis", 90, 1600, { rozmiar: 36, font: "t", we: W("gora", 1.0, 0.6) }),
      P(90, 1700, 240, 66, "$t", { r: 33, obrys: 3, we: W("zanik", 1.2, 0.5) }), T("link", 210, 1719, { rozmiar: 26, font: "t", waga: 700, wyr: "srodek", we: W("zanik", 1.2, 0.5) }),
    ] });
  dodaj({ id: "pr-kolekcja", nazwa: "Kolekcja: trzy produkty", kat: "promocje", czas: 8, kolory: BIALE,
    pola: [zd("z1", "Produkt 1"), zd("z2", "Produkt 2"), zd("z3", "Produkt 3"), tx("tytul", "Tytuł", "AUTUMN\nCOLLECTION"), tx("p1", "Podpis 1", "Płaszcz · 499 zł"), tx("p2", "Podpis 2", "Sweter · 249 zł"), tx("p3", "Podpis 3", "Szal · 129 zł")],
    warstwy: [
      T("tytul", 90, 120, { rozmiar: 120, font: "n", waga: 700, interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.1, 0.8) }),
      ...[0, 1, 2].flatMap((i) => [
        Z("z" + (i + 1), 90, 440 + i * 480, 420, 420, { we: W("lewo", 0.4 + i * 0.2, 0.7) }),
        T("p" + (i + 1), 560, 620 + i * 480, { rozmiar: 40, font: "t", waga: 500, we: W("prawo", 0.6 + i * 0.2, 0.6) }),
        L(560, 690 + i * 480, 760, 690 + i * 480, "$t", 3, { we: W("rysuj", 0.7 + i * 0.2, 0.5) }),
      ]),
    ] });

  // ======================= WYDARZENIA =======================
  dodaj({ id: "wy-data", nazwa: "Wydarzenie z datą", kat: "wydarzenia", czas: 8, kolory: { tl: "#0F0F14", t: "#FFFFFF", a: "#C9A96E", g: "#1A1A22", d: "#9A98A6" },
    pola: [zd("z1", "Zdjęcie"), tx("dzien", "Dzień", "18"), tx("miesiac", "Miesiąc", "LISTOPAD"), tx("tytul", "Nazwa wydarzenia", "GALA\nBIZNESU"), tx("miejsce", "Miejsce i godzina", "Warszawa · 19:00")],
    warstwy: [
      Z("z1", 0, 0, 1080, 1100, { bw: true, ruch: [1.15, 1], we: W("odkryj-gora", 0, 0.9) }),
      C(0, 700, 1080, 400, "$tl", 0, 1),
      T("dzien", 90, 1000, { rozmiar: 260, font: "n", waga: 700, kolor: "$a", we: W("licz", 0.5, 1.0) }),
      T("miesiac", 400, 1110, { rozmiar: 44, font: "t", waga: 600, rozstaw: 300, we: W("lewo", 0.8, 0.6) }),
      L(400, 1190, 990, 1190, "$a", 2, { we: W("rysuj", 0.9, 0.6) }),
      T("tytul", 90, 1330, { rozmiar: 140, font: "n", waga: 700, interlinia: 0.95, wielkie: true, we: W("maska-gora", 1.0, 0.8) }),
      T("miejsce", 90, 1680, { rozmiar: 36, font: "t", kolor: "$d", we: W("gora", 1.3, 0.6) }),
    ] });
  dodaj({ id: "wy-odliczanie", nazwa: "Już za X dni", kat: "wydarzenia", czas: 6, kolory: { tl: "#141414", t: "#FFFFFF", a: "#4ADE80", g: "#222222", d: "#8A8A8A" },
    pola: [tx("nad", "Nad liczbą", "JUŻ ZA"), tx("liczba", "Liczba", "3"), tx("pod", "Pod liczbą", "DNI"), tx("opis", "Opis", "Premiera nowej kolekcji")],
    warstwy: [
      K(540, 900, 380, "$a", { obrys: 6, we: W("rysuj", 0.1, 1.0) }),
      T("nad", 540, 600, { rozmiar: 50, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, we: W("zanik", 0.3, 0.6) }),
      T("liczba", 540, 680, { rozmiar: 360, font: "n", waga: 700, wyr: "srodek", kolor: "$a", we: W("pop", 0.5, 0.8, "sprezyna") }),
      T("pod", 540, 1100, { rozmiar: 50, font: "t", waga: 700, wyr: "srodek", rozstaw: 300, we: W("zanik", 0.8, 0.6) }),
      T("opis", 540, 1400, { rozmiar: 40, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.0, 0.6) }),
    ] });
  dodaj({ id: "wy-zaproszenie", nazwa: "Zaproszenie w ramce", kat: "wydarzenia", czas: 8, kolory: { tl: "#F5F0E8", t: "#2A2420", a: "#A88B5D", g: "#FFFFFF", d: "#8C8073" },
    pola: [tx("nad", "Nadtytuł", "ZAPRASZAMY NA"), tx("tytul", "Tytuł", "Wieczór\nautorski"), tx("data", "Data", "24.11.2026 · 18:00"), tx("miejsce", "Miejsce", "Galeria Sztuki, Kraków")],
    warstwy: [
      P(90, 160, 900, 1600, "$a", { obrys: 3, we: W("rysuj", 0.1, 1.2) }),
      P(120, 190, 840, 1540, "$a", { obrys: 1, we: W("rysuj", 0.3, 1.2) }),
      T("nad", 540, 560, { rozmiar: 30, font: "t", waga: 600, wyr: "srodek", rozstaw: 400, kolor: "$a", we: W("zanik", 0.6, 0.6) }),
      T("tytul", 540, 660, { rozmiar: 140, font: "t", waga: 300, wyr: "srodek", interlinia: 1.0, we: W("maska-gora", 0.8, 0.9) }),
      L(440, 1040, 640, 1040, "$a", 2, { we: W("rysuj", 1.1, 0.6) }),
      T("data", 540, 1100, { rozmiar: 44, font: "t", waga: 600, wyr: "srodek", we: W("gora", 1.2, 0.6) }),
      T("miejsce", 540, 1180, { rozmiar: 34, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.35, 0.6) }),
    ] });
  dodaj({ id: "wy-prelegent", nazwa: "Prelegent / gość", kat: "wydarzenia", czas: 8, kolory: { tl: "#0B1F3A", t: "#FFFFFF", a: "#22C55E", g: "#13294B", d: "#9FB3CC" },
    pola: [zd("z1", "Zdjęcie osoby"), tx("nad", "Nadtytuł", "PRELEGENT"), tx("imie", "Imię i nazwisko", "Anna Kowalska"), tx("rola", "Funkcja", "CEO, Emerald Media"), tx("temat", "Temat", "Jak budować markę w social mediach", 2)],
    warstwy: [
      P(0, 0, 1080, 1920, "$g", { we: W("zanik", 0, 0.3) }),
      Z("z1", 240, 260, 600, 600, { maska: "kolo", ruch: [1.15, 1], we: W("skala", 0.2, 0.8) }),
      K(540, 560, 320, "$a", { obrys: 5, we: W("rysuj", 0.4, 1.0) }),
      T("nad", 540, 980, { rozmiar: 28, font: "t", waga: 700, wyr: "srodek", rozstaw: 400, kolor: "$a", we: W("zanik", 0.8, 0.6) }),
      T("imie", 540, 1040, { rozmiar: 96, font: "n", waga: 700, wyr: "srodek", wielkie: true, we: W("maska-gora", 0.9, 0.7) }),
      T("rola", 540, 1170, { rozmiar: 36, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.1, 0.6) }),
      L(440, 1290, 640, 1290, "$a", 3, { we: W("rysuj", 1.2, 0.5) }),
      T("temat", 540, 1350, { rozmiar: 52, font: "t", waga: 600, wyr: "srodek", szer: 860, interlinia: 1.25, we: W("gora", 1.3, 0.6) }),
    ] });

  // ======================= LIFESTYLE =======================
  dodaj({ id: "li-pelne", nazwa: "Pełne zdjęcie i tytuł na dole", kat: "lifestyle", czas: 7, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie"), tx("nad", "Nadtytuł", "TRAVEL DIARY"), tx("tytul", "Tytuł", "LOST IN\nLISBON"), tx("opis", "Opis", "3 dni, 40 km pieszo i najlepsze pastéis")],
    warstwy: [
      Z("z1", 0, 0, 1080, 1920, { ruch: [1.18, 1.02], we: W("zoom", 0, 1.1) }),
      C(0, 900, 1080, 1020, "#000000", 0, 0.8),
      T("nad", 90, 1280, { rozmiar: 26, font: "t", waga: 700, rozstaw: 400, we: W("lewo", 0.6, 0.6) }),
      T("tytul", 90, 1340, { rozmiar: 170, font: "n", waga: 700, interlinia: 0.92, wielkie: true, we: W("maska-gora", 0.7, 0.9) }),
      T("opis", 90, 1700, { rozmiar: 34, font: "t", we: W("gora", 1.1, 0.6) }),
    ] });
  dodaj({ id: "li-pocztowka", nazwa: "Pocztówka z miejsca", kat: "lifestyle", czas: 7, kolory: { tl: "#D9CFC1", t: "#2B2B2B", a: "#C0392B", g: "#FFFFFF", d: "#6E6458" },
    pola: [zd("z1", "Zdjęcie"), tx("miejsce", "Miejsce", "Santorini"), tx("wsp", "Współrzędne", "36.3932° N, 25.4615° E"), tx("opis", "Opis", "Greetings from")],
    warstwy: [
      P(90, 300, 900, 1180, "$g", { obrot: 3, we: W("pop", 0.1, 0.8, "sprezyna") }),
      Z("z1", 130, 340, 820, 900, { obrot: 3, ruch: [1.12, 1], we: W("zanik", 0.4, 0.7) }),
      T("opis", 540, 1280, { rozmiar: 36, font: "t", waga: 400, wyr: "srodek", obrot: 3, kolor: "$d", we: W("zanik", 0.8, 0.6) }),
      T("miejsce", 540, 1320, { rozmiar: 100, font: "n", waga: 700, wyr: "srodek", obrot: 3, wielkie: true, we: W("maska-gora", 0.9, 0.8) }),
      K(860, 300, 70, "$a", { obrys: 4, we: W("rysuj", 1.2, 0.7) }),
      T("wsp", 540, 1640, { rozmiar: 30, font: "t", wyr: "srodek", kolor: "$d", we: W("pisz", 1.3, 1.0) }),
    ] });
  dodaj({ id: "li-podzial", nazwa: "Podział: zdjęcie i kolor", kat: "lifestyle", czas: 7, kolory: { tl: "#1F3A2E", t: "#F4EDE1", a: "#E9B872", g: "#2A4A3B", d: "#B8C4B9" },
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "Green\nliving"), tx("opis", "Opis", "Pięć roślin, które przeżyją wszystko", 2), tx("numer", "Numer", "01")],
    warstwy: [
      Z("z1", 0, 0, 1080, 960, { ruch: [1.15, 1], we: W("odkryj-dol", 0, 0.9) }),
      T("numer", 980, 1030, { rozmiar: 120, font: "n", waga: 700, wyr: "prawo", kolor: "$a", we: W("zanik", 0.7, 0.6) }),
      T("tytul", 90, 1060, { rozmiar: 160, font: "t", waga: 300, interlinia: 0.95, we: W("maska-gora", 0.6, 0.9) }),
      T("opis", 90, 1460, { rozmiar: 38, font: "t", szer: 760, kolor: "$d", interlinia: 1.35, we: W("gora", 1.0, 0.6) }),
      L(90, 1650, 330, 1650, "$a", 4, { we: W("rysuj", 1.2, 0.6) }),
    ] });
  dodaj({ id: "li-kroki", nazwa: "Lista kroków ze zdjęciem", kat: "lifestyle", czas: 9, kolory: BIALE,
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "MORNING\nROUTINE"), tx("k1", "Krok 1", "Szklanka wody"), tx("k2", "Krok 2", "10 minut ruchu"), tx("k3", "Krok 3", "Kawa bez telefonu"), tx("k4", "Krok 4", "Plan na dzień")],
    warstwy: [
      Z("z1", 540, 0, 540, 1920, { ruch: [1.15, 1], we: W("odkryj-dol", 0, 0.9) }),
      T("tytul", 70, 170, { rozmiar: 104, font: "n", waga: 700, interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.3, 0.8) }),
      ...[0, 1, 2, 3].flatMap((i) => [
        TL("0" + (i + 1), 70, 620 + i * 260, { rozmiar: 64, font: "n", waga: 700, kolor: "$d", we: W("zanik", 0.7 + i * 0.25, 0.5) }),
        T("k" + (i + 1), 70, 710 + i * 260, { rozmiar: 36, font: "t", waga: 600, szer: 420, we: W("lewo", 0.75 + i * 0.25, 0.6) }),
        L(70, 800 + i * 260, 300, 800 + i * 260, "$t", 2, { we: W("rysuj", 0.8 + i * 0.25, 0.5) }),
      ]),
    ] });

  // ======================= ZAPOWIEDZI I ZAKOŃCZENIA =======================
  dodaj({ id: "za-nowy-post", nazwa: "Nowy post (przesuń w górę)", kat: "zakonczenia", czas: 6, kolory: CIEMNE,
    pola: [zd("z1", "Zdjęcie z posta"), tx("tytul", "Tytuł", "NOWY\nPOST"), tx("opis", "Opis", "zobacz na profilu")],
    warstwy: [
      T("tytul", 540, 220, { rozmiar: 170, font: "n", waga: 700, wyr: "srodek", interlinia: 0.92, wielkie: true, we: W("maska-gora", 0.1, 0.8) }),
      P(240, 620, 600, 750, "#FFFFFF", { we: W("pop", 0.4, 0.8, "sprezyna") }),
      Z("z1", 270, 650, 540, 600, { ruch: [1.12, 1], we: W("zanik", 0.7, 0.6) }),
      TR(540, 1560, 40, "$t", { obrot: 0, we: W("gora", 1.0, 0.6) }), TR(540, 1620, 40, "$t", { obrot: 0, krycie: 0.5, we: W("gora", 1.1, 0.6) }),
      T("opis", 540, 1700, { rozmiar: 34, font: "t", waga: 600, wyr: "srodek", rozstaw: 150, we: W("zanik", 1.2, 0.6) }),
    ] });
  dodaj({ id: "za-obserwuj", nazwa: "Obserwuj profil", kat: "zakonczenia", czas: 6, kolory: { tl: "#111111", t: "#FFFFFF", a: "#3B82F6", g: "#1E1E1E", d: "#9A9A9A" },
    pola: [zd("z1", "Zdjęcie profilowe"), tx("nick", "Nick", "@nadamedia"), tx("opis", "Opis", "Więcej takich treści codziennie"), tx("przycisk", "Przycisk", "OBSERWUJ")],
    warstwy: [
      K(540, 620, 230, "$a", { obrys: 8, we: W("rysuj", 0.1, 0.9) }),
      Z("z1", 330, 410, 420, 420, { maska: "kolo", ruch: [1.12, 1], we: W("skala", 0.3, 0.7) }),
      T("nick", 540, 940, { rozmiar: 76, font: "t", waga: 700, wyr: "srodek", we: W("maska-gora", 0.6, 0.7) }),
      T("opis", 540, 1060, { rozmiar: 36, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 0.8, 0.6) }),
      P(300, 1200, 480, 120, "$a", { r: 24, we: W("pop", 1.0, 0.7, "sprezyna") }),
      T("przycisk", 540, 1238, { rozmiar: 40, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, we: W("zanik", 1.2, 0.4) }),
    ] });
  dodaj({ id: "za-dziekuje", nazwa: "Dziękuję za obejrzenie", kat: "zakonczenia", czas: 5, kolory: BIALE,
    pola: [lg("logo", "Logo"), tx("tytul", "Tekst", "Thanks for watching"), tx("opis", "Pod spodem", "do zobaczenia jutro")],
    warstwy: [
      Z("logo", 390, 560, 300, 300, { dopasuj: "zawrzyj", we: W("skala", 0.1, 0.7) }),
      T("tytul", 540, 960, { rozmiar: 80, font: "t", waga: 300, wyr: "srodek", we: W("maska-gora", 0.4, 0.8) }),
      L(470, 1100, 610, 1100, "$t", 2, { we: W("rysuj", 0.8, 0.5) }),
      T("opis", 540, 1140, { rozmiar: 32, font: "t", wyr: "srodek", kolor: "$d", we: W("zanik", 1.0, 0.6) }),
    ] });
  dodaj({ id: "za-pytanie", nazwa: "Pytanie do widzów", kat: "zakonczenia", czas: 7, kolory: { tl: "#FFD43B", t: "#111111", a: "#111111", g: "#FFFFFF", d: "#5C4A00" },
    pola: [tx("nad", "Nadtytuł", "PYTANIE DNIA"), tx("pytanie", "Pytanie", "Kawa czy herbata?"), tx("o1", "Odpowiedź A", "KAWA ☕"), tx("o2", "Odpowiedź B", "HERBATA 🍵")],
    warstwy: [
      T("nad", 540, 500, { rozmiar: 32, font: "t", waga: 800, wyr: "srodek", rozstaw: 400, we: W("zanik", 0.1, 0.6) }),
      T("pytanie", 540, 600, { rozmiar: 120, font: "n", waga: 700, wyr: "srodek", szer: 900, interlinia: 1.0, wielkie: true, we: W("maska-gora", 0.3, 0.8) }),
      P(140, 1060, 800, 150, "$g", { r: 75, we: W("lewo", 0.8, 0.6) }), T("o1", 540, 1110, { rozmiar: 52, font: "t", waga: 800, wyr: "srodek", we: W("zanik", 0.9, 0.5) }),
      P(140, 1260, 800, 150, "$g", { r: 75, we: W("prawo", 1.0, 0.6) }), T("o2", 540, 1310, { rozmiar: 52, font: "t", waga: 800, wyr: "srodek", we: W("zanik", 1.1, 0.5) }),
    ] });
  dodaj({ id: "za-tytulowa", nazwa: "Plansza tytułowa serii", kat: "zakonczenia", czas: 5, kolory: { tl: "#111111", t: "#FFFFFF", a: "#FF6B2C", g: "#1E1E1E", d: "#9A9A9A" },
    pola: [tx("numer", "Odcinek", "ODC. 07"), tx("tytul", "Tytuł", "JAK ZACZĄĆ\nNAGRYWAĆ"), tx("opis", "Seria", "seria: montaż od zera")],
    warstwy: [
      P(90, 700, 30, 360, "$a", { we: W("odkryj-gora", 0.1, 0.5) }),
      T("numer", 160, 690, { rozmiar: 40, font: "t", waga: 700, rozstaw: 300, kolor: "$a", we: W("lewo", 0.3, 0.6) }),
      T("tytul", 160, 760, { rozmiar: 130, font: "n", waga: 700, interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.4, 0.8) }),
      T("opis", 160, 1080, { rozmiar: 36, font: "t", kolor: "$d", we: W("gora", 0.8, 0.6) }),
    ] });

  // ---------- zdjęcia zastępcze (gdy nie ma pliku) ----------
  const ZASTEPCZE = [["#C9B8A6", "#5E4B3C"], ["#A9B7C6", "#33414F"], ["#C7C2B8", "#4A4740"], ["#B9A3A0", "#4C3633"], ["#AFC0A8", "#36452F"], ["#D2C1A0", "#6B5634"]];
  let fabryka = null;
  function nowyCanvas(w, h) {
    if (fabryka) return fabryka(w, h);
    if (typeof OffscreenCanvas !== "undefined") return new OffscreenCanvas(w, h);
    const c = document.createElement("canvas"); c.width = w; c.height = h; return c;
  }
  const pamiecZastepczych = {};
  function zastepcze(nr, w = 800, h = 1000) {
    const k = nr + "_" + w + "x" + h;
    if (pamiecZastepczych[k]) return pamiecZastepczych[k];
    const c = nowyCanvas(w, h), x = c.getContext("2d"), [a, b] = ZASTEPCZE[nr % ZASTEPCZE.length];
    const g = x.createLinearGradient(0, 0, w * 0.4, h); g.addColorStop(0, a); g.addColorStop(1, b);
    x.fillStyle = g; x.fillRect(0, 0, w, h);
    x.globalAlpha = 0.18; x.fillStyle = "#FFFFFF";
    x.beginPath(); x.arc(w * 0.68, h * 0.3, Math.min(w, h) * 0.28, 0, Math.PI * 2); x.fill();
    x.globalAlpha = 0.12; x.fillStyle = "#000000";
    x.beginPath(); x.ellipse(w * 0.4, h * 0.95, w * 0.7, h * 0.32, 0, 0, Math.PI * 2); x.fill();
    x.globalAlpha = 0.5; x.strokeStyle = "#FFFFFF"; x.lineWidth = Math.max(2, w / 180);
    const s = Math.min(w, h) * 0.12, cx = w / 2, cy = h / 2;
    x.strokeRect(cx - s, cy - s * 0.7, s * 2, s * 1.4); x.beginPath(); x.arc(cx, cy, s * 0.4, 0, Math.PI * 2); x.stroke();
    x.globalAlpha = 1;
    return (pamiecZastepczych[k] = c);
  }

  // ---------- przygotowanie szablonu z wartościami ----------
  const FONTY_DOM = { n: { rodzina: "Oswald", waga: 700 }, t: { rodzina: "Montserrat", waga: 400 } };
  function znajdz(id) { return SZABLONY.find((s) => s.id === id) || null; }
  /* wartosci: {pola: {id: tekst}, zdjecia: {id: obraz|null}, ustawieniaZdjec: {id: {skala, x, y, bw, ruch}}, kolory: {...},
                skaleTekstow: {_wszystkie: 1, <pole>: 1.2} (mnożniki wielkości tekstów),
                fonty: {n: {rodzina, waga}, t: {...}}, czas (s), tempo (mnożnik) } */
  function stan(sz, wart = {}) {
    const kol = Object.assign({}, sz.kolory || CIEMNE, wart.kolory || {});
    const fonty = { n: Object.assign({}, FONTY_DOM.n, (wart.fonty || {}).n || {}), t: Object.assign({}, FONTY_DOM.t, (wart.fonty || {}).t || {}) };
    const czas = +wart.czas || sz.czas || 7;
    const tempo = +wart.tempo || 1;
    const wyjscie = Object.assign({ typ: "zanik", d: 0.45 }, sz.wyjscie || {}, wart.wyjscie || {});
    return { sz, kol, fonty, czas, tempo, wyjscie, wart };
  }
  function tekstPola(st, w) {
    if (w.tekst != null) return String(w.tekst);
    const pola = st.wart.pola || {}, p = (st.sz.pola || []).find((x) => x.id === w.pole);
    const v = pola[w.pole] != null ? pola[w.pole] : p ? p.dom : "";
    return String(v == null ? "" : v);
  }
  const fontCSS = (st, w, px) => {
    const f = st.fonty[w.font || "t"];
    return `${f.kursywa ? "italic " : ""}${f.wymus ? f.waga : (w.waga || f.waga)} ${Math.max(1, Math.round(px))}px "${f.rodzina}", "Segoe UI", Arial, sans-serif`;
  };
  function szerTekstu(ctx, t, rozstawPx) {
    if (!rozstawPx) return ctx.measureText(t).width;
    let s = 0; for (const c of Array.from(t)) s += ctx.measureText(c).width + rozstawPx; return Math.max(0, s - rozstawPx);
  }
  /* Układ tekstu w jednostkach bazowych: linie, szerokość, wysokość, linia bazowa pierwszego wiersza. */
  function ukladTekstu(ctx, st, w) {
    let t = tekstPola(st, w);
    if (w.wielkie) t = t.toLocaleUpperCase("pl");
    const sk = st.wart.skaleTekstow || {}, mn = (+sk._wszystkie || 1) * (+sk[w.pole] || 1); // wielkość ustawiona w panelu
    let px = (w.rozmiar || 40) * mn, rozstaw = (w.rozstaw || 0) / 1000 * px;
    ctx.font = fontCSS(st, w, px);
    if (!w.szer) {
      // dłuższy tekst niż w przykładzie: zmniejsz font, żeby nie wyszedł poza kadr ani na sąsiednie elementy
      const wyr0 = w.wyr || "lewo", limit = w.maks || (wyr0 === "srodek" ? 2 * Math.min(w.x, BW - w.x) - 100 : wyr0 === "prawo" ? w.x - 70 : BW - w.x - 70);
      const najszersza = Math.max(0, ...t.split(/\n/).map((l) => szerTekstu(ctx, l, rozstaw)));
      if (!w.obrot && najszersza > limit && limit > 50) { px *= limit / najszersza; rozstaw = (w.rozstaw || 0) / 1000 * px; ctx.font = fontCSS(st, w, px); }
    }
    const linie = [];
    t.split(/\n/).forEach((akapit) => {
      if (!w.szer) { linie.push(akapit); return; }
      let biez = "";
      akapit.split(/\s+/).filter(Boolean).forEach((sl) => {
        const prob = biez ? biez + " " + sl : sl;
        if (biez && szerTekstu(ctx, prob, rozstaw) > w.szer) { linie.push(biez); biez = sl; } else biez = prob;
      });
      linie.push(biez);
    });
    const lh = px * (w.interlinia || 1.2), szer = Math.max(0, ...linie.map((l) => szerTekstu(ctx, l, rozstaw)));
    const wyr = w.wyr || "lewo", lewa = wyr === "srodek" ? w.x - szer / 2 : wyr === "prawo" ? w.x - szer : w.x;
    return { linie, px, lh, rozstaw, szer, wys: lh * (linie.length - 1) + px * 0.9, lewa, gora: w.y, baza: w.y + px * 0.78, wyr };
  }
  function granice(ctx, st, w) {
    if (w.typ === "kolo" || w.typ === "trojkat") return { x: w.x - w.r, y: w.y - w.r, w: w.r * 2, h: w.r * 2 };
    if (w.typ === "linia") return { x: Math.min(w.x1, w.x2), y: Math.min(w.y1, w.y2), w: Math.abs(w.x2 - w.x1) || w.g, h: Math.abs(w.y2 - w.y1) || w.g };
    if (w.typ === "tekst") { const u = ukladTekstu(ctx, st, w); return { x: u.lewa, y: w.y, w: u.szer, h: u.wys, u }; }
    return { x: w.x, y: w.y, w: w.w, h: w.h };
  }

  // ---------- ruch ----------
  function okno(t, od, dl) { return dl <= 0 ? (t >= od ? 1 : 0) : clamp((t - od) / dl); }
  function animacja(st, w, t) {
    const r = { a: 1, dx: 0, dy: 0, sk: 1, clip: null, frac: 1, raw: 1, maskaGora: 0 };
    const we = w.we, tempo = st.tempo;
    if (we) {
      const raw = okno(t, we.t / tempo, (we.d || 0.7) / tempo), e = (EASE[we.e || "plynnie"] || EASE.plynnie)(raw);
      r.raw = raw;
      switch (we.typ) {
        case "zanik": r.a *= e; break;
        case "gora": r.dy += (1 - e) * 90; r.a *= e; break;
        case "dol": r.dy -= (1 - e) * 90; r.a *= e; break;
        case "lewo": r.dx -= (1 - e) * 140; r.a *= e; break;
        case "prawo": r.dx += (1 - e) * 140; r.a *= e; break;
        case "skala": r.sk *= 0.82 + 0.18 * e; r.a *= e; break;
        case "pop": r.sk *= Math.max(0, EASE.sprezyna(raw)); r.a *= clamp(raw * 3); break;
        case "zoom": r.sk *= 1.25 - 0.25 * e; r.a *= e; break;
        case "odkryj-lewo": r.clip = [0, 0, e, 1]; break;
        case "odkryj-prawo": r.clip = [1 - e, 0, 1, 1]; break;
        case "odkryj-gora": r.clip = [0, 0, 1, e]; break;
        case "odkryj-dol": r.clip = [0, 1 - e, 1, 1]; break;
        case "maska-gora": r.maskaGora = 1 - e; break;
        case "rysuj": r.frac = e; break;
        case "pisz": r.frac = raw; break;
        case "licz": r.frac = e; r.a *= clamp(raw * 4); break;
      }
    }
    const wy = w.wy || st.wyjscie;
    if (wy && wy.typ !== "brak") {
      const start = wy.t != null ? wy.t : st.czas - (wy.d || 0.45);
      const x = EASE.wej(okno(t, start, wy.d || 0.45));
      if (x > 0) {
        switch (wy.typ) {
          case "gora": r.dy -= x * 90; r.a *= 1 - x; break;
          case "lewo": r.dx -= x * 140; r.a *= 1 - x; break;
          case "skala": r.sk *= 1 - 0.18 * x; r.a *= 1 - x; break;
          default: r.a *= 1 - x;
        }
      }
    }
    r.a *= w.krycie == null ? 1 : w.krycie;
    return r;
  }

  // ---------- rysowanie ----------
  function sciezkaMaski(ctx, m, x, y, w, h, r) {
    ctx.beginPath();
    if (m && typeof m === "object") { ctx.rect(m.x, m.y, m.w, m.h); return; }
    if (m === "kolo") ctx.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2);
    else if (m === "romb") { ctx.moveTo(x + w / 2, y); ctx.lineTo(x + w, y + h / 2); ctx.lineTo(x + w / 2, y + h); ctx.lineTo(x, y + h / 2); ctx.closePath(); }
    else if (m === "luk") { ctx.moveTo(x, y + h); ctx.lineTo(x, y + w / 2); ctx.arc(x + w / 2, y + w / 2, w / 2, Math.PI, 0); ctx.lineTo(x + w, y + h); ctx.closePath(); }
    else if (m === "zaokr") zaokr(ctx, x, y, w, h, r || 40, true);
    else ctx.rect(x, y, w, h);
  }
  function zaokr(ctx, x, y, w, h, r, bezBegin) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    if (!bezBegin) ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function obwodProst(x, y, w, h) { return [[x, y], [x + w, y], [x + w, y + h], [x, y + h], [x, y]]; }
  function czescSciezki(ctx, pkt, e) {
    let suma = 0; const dl = [];
    for (let i = 1; i < pkt.length; i++) { const d = Math.hypot(pkt[i][0] - pkt[i - 1][0], pkt[i][1] - pkt[i - 1][1]); dl.push(d); suma += d; }
    let zost = suma * clamp(e); ctx.beginPath(); ctx.moveTo(...pkt[0]);
    for (let i = 1; i < pkt.length && zost > 0; i++) { const k = Math.min(1, zost / dl[i - 1]); ctx.lineTo(lerp(pkt[i - 1][0], pkt[i][0], k), lerp(pkt[i - 1][1], pkt[i][1], k)); zost -= dl[i - 1]; }
  }
  function liczba(t, frac) {
    const m = String(t).match(/^([^\d-]*)(-?[\d]+(?:[.,]\d+)?)(.*)$/s);
    if (!m) return t;
    const v = parseFloat(m[2].replace(",", ".")), miejsca = (m[2].split(/[.,]/)[1] || "").length;
    return m[1] + (v * frac).toFixed(miejsca).replace(".", m[2].includes(",") ? "," : ".") + m[3];
  }
  function obrazDla(st, pole) { const z = (st.wart.zdjecia || {})[pole]; return z && (z.videoWidth || z.naturalWidth || z.width) ? z : null; }
  function rysujZdjecie(ctx, st, w, idx) {
    const us = (st.wart.ustawieniaZdjec || {})[w.pole] || {};
    const img = obrazDla(st, w.pole) || (w.dopasuj === "zawrzyj" ? null : zastepcze(idx, Math.round(w.w), Math.round(w.h)));
    ctx.save();
    if (w.obrot) { ctx.translate(w.x + w.w / 2, w.y + w.h / 2); ctx.rotate(w.obrot * Math.PI / 180); ctx.translate(-(w.x + w.w / 2), -(w.y + w.h / 2)); }
    sciezkaMaski(ctx, w.maska, w.x, w.y, w.w, w.h, w.r); ctx.clip();
    if (!img) { // logo bez pliku: napis zastępczy
      ctx.fillStyle = rgba(st.kol.t, 0.15); ctx.fillRect(w.x, w.y, w.w, w.h);
      ctx.fillStyle = st.kol.t; ctx.font = `600 ${Math.round(w.h * 0.14)}px "Segoe UI", Arial`; ctx.textAlign = "center"; ctx.textBaseline = "middle";
      ctx.fillText("LOGO", w.x + w.w / 2, w.y + w.h / 2); ctx.restore(); return;
    }
    const iw = img.videoWidth || img.naturalWidth || img.width, ih = img.videoHeight || img.naturalHeight || img.height;
    const pas = w.dopasuj === "zawrzyj" ? Math.min(w.w / iw, w.h / ih) : Math.max(w.w / iw, w.h / ih);
    const ruch = us.ruch === "brak" ? [1, 1] : us.ruch === "oddal" ? [1, 1.15] : (w.ruch || [1, 1]);
    const p = clamp(st.t / st.czas), sk = pas * (+us.skala || 1) * lerp(ruch[0], ruch[1], EASE.plynnie(p));
    const dw = iw * sk, dh = ih * sk;
    const cx = w.x + w.w / 2 + (+us.x || 0) * w.w / 2, cy = w.y + w.h / 2 + (+us.y || 0) * w.h / 2;
    if ((w.bw && us.bw !== false) || us.bw === true) ctx.filter = "grayscale(1)";
    ctx.drawImage(img, cx - dw / 2, cy - dh / 2, dw, dh);
    ctx.restore();
  }
  function rysujTekst(ctx, st, w, a, b) {
    const u = b.u, kol = kolor(w.kolor || "$t", st.kol);
    ctx.font = fontCSS(st, w, u.px); ctx.fillStyle = kol; ctx.textBaseline = "alphabetic"; ctx.textAlign = "left";
    let linie = u.linie;
    if (w.we && w.we.typ === "pisz") {
      const wszystkie = linie.join("\n"), n = Math.floor(wszystkie.length * a.frac);
      linie = wszystkie.slice(0, n).split("\n");
    }
    if (w.we && w.we.typ === "licz") linie = linie.map((l) => liczba(l, a.frac));
    linie.forEach((l, i) => {
      const sz = szerTekstu(ctx, l, u.rozstaw);
      let x = u.wyr === "srodek" ? w.x - sz / 2 : u.wyr === "prawo" ? w.x - sz : w.x;
      const y = u.baza + i * u.lh;
      if (!u.rozstaw) ctx.fillText(l, x, y);
      else for (const c of Array.from(l)) { ctx.fillText(c, x, y); x += ctx.measureText(c).width + u.rozstaw; }
    });
  }
  function rysujWarstwe(ctx, st, w, t, idx) {
    const b = granice(ctx, st, w), a = animacja(st, w, t);
    if (a.a <= 0.001) return;
    ctx.save();
    ctx.globalAlpha = a.a;
    ctx.translate(a.dx, a.dy);
    const cx = b.x + b.w / 2, cy = b.y + b.h / 2;
    if (a.sk !== 1) { ctx.translate(cx, cy); ctx.scale(a.sk, a.sk); ctx.translate(-cx, -cy); }
    if (w.obrot && w.typ !== "zdjecie" && w.typ !== "trojkat") {
      const ox = w.typ === "tekst" ? w.x : cx, oy = w.typ === "tekst" ? w.y : cy;
      ctx.translate(ox, oy); ctx.rotate(w.obrot * Math.PI / 180); ctx.translate(-ox, -oy);
    }
    if (a.clip) { const [x0, y0, x1, y1] = a.clip; ctx.beginPath(); ctx.rect(b.x + b.w * x0 - 2, b.y + b.h * y0 - 2, b.w * (x1 - x0) + 4, b.h * (y1 - y0) + 4); ctx.clip(); }
    if (a.maskaGora) { ctx.beginPath(); ctx.rect(b.x - 40, b.y - 10, b.w + 80, b.h + 30); ctx.clip(); ctx.translate(0, a.maskaGora * (b.h + 30)); }
    const kol = kolor(w.kolor, st.kol);
    switch (w.typ) {
      case "prost":
        if (w.obrys) {
          ctx.strokeStyle = kol; ctx.lineWidth = w.obrys;
          if (w.we && w.we.typ === "rysuj") { czescSciezki(ctx, obwodProst(w.x, w.y, w.w, w.h), a.frac); ctx.stroke(); }
          else { if (w.r) zaokr(ctx, w.x, w.y, w.w, w.h, w.r); else { ctx.beginPath(); ctx.rect(w.x, w.y, w.w, w.h); } ctx.stroke(); }
        } else { ctx.fillStyle = kol; if (w.r) { zaokr(ctx, w.x, w.y, w.w, w.h, w.r); ctx.fill(); } else ctx.fillRect(w.x, w.y, w.w, w.h); }
        break;
      case "kolo":
        ctx.beginPath();
        if (w.obrys) { const e = w.we && w.we.typ === "rysuj" ? a.frac : 1; ctx.arc(w.x, w.y, w.r, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * e); ctx.strokeStyle = kol; ctx.lineWidth = w.obrys; ctx.stroke(); }
        else { ctx.arc(w.x, w.y, w.r, 0, Math.PI * 2); ctx.fillStyle = kol; ctx.fill(); }
        break;
      case "trojkat": {
        ctx.translate(w.x, w.y); ctx.rotate(((w.obrot || 0) - 90) * Math.PI / 180);
        ctx.beginPath(); for (let i = 0; i < 3; i++) { const k = (i * 2 * Math.PI) / 3; ctx[i ? "lineTo" : "moveTo"](Math.cos(k) * w.r, Math.sin(k) * w.r); }
        ctx.closePath(); ctx.fillStyle = kol; ctx.fill(); break;
      }
      case "linia": ctx.strokeStyle = kol; ctx.lineWidth = w.g; ctx.lineCap = "butt"; czescSciezki(ctx, [[w.x1, w.y1], [w.x2, w.y2]], a.frac); ctx.stroke(); break;
      case "cien": {
        const g = ctx.createLinearGradient(0, w.y, 0, w.y + w.h); g.addColorStop(0, rgba(kol, w.od)); g.addColorStop(1, rgba(kol, w.do));
        ctx.fillStyle = g; ctx.fillRect(w.x, w.y, w.w, w.h); break;
      }
      case "zdjecie": rysujZdjecie(ctx, st, w, idx); break;
      case "tekst": rysujTekst(ctx, st, w, a, b); break;
    }
    ctx.restore();
  }
  /* Klatka szablonu w czasie t (s) na płótnie W×H. */
  function rysuj(ctx, szOrId, t, wart, W, H, opcje = {}) {
    const sz = typeof szOrId === "string" ? znajdz(szOrId) : szOrId;
    if (!sz) throw new Error("Nie ma szablonu " + szOrId);
    const st = stan(sz, wart); st.t = t;
    ctx.save();
    ctx.scale(W / BW, H / BH);
    if (!opcje.bezTla) {
      const a = animacja(st, { we: { typ: "zanik", t: 0, d: 0.25 }, wy: { typ: "brak" } }, t);
      ctx.globalAlpha = a.a; ctx.fillStyle = st.kol.tl; ctx.fillRect(0, 0, BW, BH); ctx.globalAlpha = 1;
    }
    const nrPola = {};
    sz.warstwy.forEach((w) => { if (w.typ === "zdjecie" && !(w.pole in nrPola)) nrPola[w.pole] = Object.keys(nrPola).length; });
    sz.warstwy.forEach((w) => { const idx = w.typ === "zdjecie" ? nrPola[w.pole] : 0; try { rysujWarstwe(ctx, st, w, t, idx); } catch (e) { /* pojedyncza warstwa nie psuje klatki */ } });
    ctx.restore();
    return st;
  }
  function czas(szOrId, wart) { const sz = typeof szOrId === "string" ? znajdz(szOrId) : szOrId; return sz ? stan(sz, wart).czas : 7; }

  /* Opis dla After Effects: wszystko policzone (kolory, linie tekstu, granice), w pikselach kompozycji W×H. */
  const WAGI = { 100: "Thin", 200: "ExtraLight", 300: "Light", 400: "Regular", 500: "Medium", 600: "SemiBold", 700: "Bold", 800: "ExtraBold", 900: "Black" };
  function doAE(ctx, szOrId, wart, W = BW, H = BH) {
    const sz = typeof szOrId === "string" ? znajdz(szOrId) : szOrId, st = stan(sz, wart), s = W / BW;
    const k = (v) => v * s, rgb01 = (h) => hex(h).map((v) => +(v / 255).toFixed(4));
    const wynik = { id: sz.id, nazwa: sz.nazwa, W, H, czas: st.czas, tlo: rgb01(st.kol.tl), warstwy: [] };
    const tempo = st.tempo, an = (x) => x && Object.assign({}, x, { t: (x.t || 0) / tempo, d: (x.d || 0.7) / tempo });
    sz.warstwy.forEach((w, i) => {
      const b = granice(ctx, st, w);
      const o = { typ: w.typ, nazwa: "", x: k(b.x), y: k(b.y), w: k(b.w), h: k(b.h), krycie: w.krycie == null ? 1 : w.krycie, obrot: w.obrot || 0,
        we: an(w.we), wy: w.wy || Object.assign({}, st.wyjscie, { t: st.wyjscie.t != null ? st.wyjscie.t : st.czas - (st.wyjscie.d || 0.45) }) };
      if (w.kolor) o.kolor = rgb01(kolor(w.kolor, st.kol));
      if (w.typ === "prost") Object.assign(o, { r: k(w.r || 0), obrys: w.obrys ? k(w.obrys) : 0, nazwa: "Kształt " + (i + 1) });
      if (w.typ === "kolo") Object.assign(o, { cx: k(w.x), cy: k(w.y), promien: k(w.r), obrys: w.obrys ? k(w.obrys) : 0, nazwa: "Koło " + (i + 1) });
      if (w.typ === "trojkat") Object.assign(o, { cx: k(w.x), cy: k(w.y), promien: k(w.r), nazwa: "Trójkąt " + (i + 1) });
      if (w.typ === "linia") Object.assign(o, { x1: k(w.x1), y1: k(w.y1), x2: k(w.x2), y2: k(w.y2), g: k(w.g), nazwa: "Linia " + (i + 1) });
      if (w.typ === "cien") Object.assign(o, { od: w.od, do: w.do, nazwa: "Cień " + (i + 1) });
      if (w.typ === "zdjecie") {
        const us = (st.wart.ustawieniaZdjec || {})[w.pole] || {};
        const m = w.maska && typeof w.maska === "object" ? { x: k(w.maska.x), y: k(w.maska.y), w: k(w.maska.w), h: k(w.maska.h) } : (w.maska || "prost");
        Object.assign(o, { pole: w.pole, plik: ((st.wart.plikiZdjec || {})[w.pole]) || null, klip: ((st.wart.klipy || {})[w.pole]) || null, maska: m, r: k(w.r || 40), bw: (w.bw && us.bw !== false) || us.bw === true,
          ruch: us.ruch === "brak" ? [1, 1] : us.ruch === "oddal" ? [1, 1.15] : (w.ruch || [1, 1]), skala: +us.skala || 1, przes: [+us.x || 0, +us.y || 0],
          dopasuj: w.dopasuj || "wypelnij", nazwa: ((sz.pola || []).find((p) => p.id === w.pole) || {}).etykieta || w.pole });
      }
      if (w.typ === "tekst") {
        const u = b.u, f = st.fonty[w.font || "t"], waga = f.wymus ? f.waga : (w.waga || f.waga);
        Object.assign(o, { linie: u.linie, rozmiar: k(u.px), rodzina: f.rodzina, waga, font: f.rodzina.replace(/\s+/g, "") + "-" + ((WAGI[waga] || "Regular") + (f.kursywa ? "Italic" : "")).replace("RegularItalic", "Italic"),
          wyr: u.wyr, rozstaw: w.rozstaw || 0, interlinia: k(u.lh), px: k(w.x), baza: k(u.baza), wielkie: !!w.wielkie,
          kolor: rgb01(kolor(w.kolor || "$t", st.kol)), nazwa: ((sz.pola || []).find((p) => p.id === w.pole) || {}).etykieta || (u.linie[0] || "Tekst").slice(0, 24) });
      }
      wynik.warstwy.push(o);
    });
    return wynik;
  }


  // =====================================================================
  // ---------- wersja 17: dużo nowych szablonów w każdej kategorii ----------
  // =====================================================================
  KATEGORIE.splice(KATEGORIE.findIndex((k) => k.id === "wlasne"), 0, { id: "porady", nazwa: "Porady i listy" }, { id: "opinie", nazwa: "Opinie i rekomendacje" });
  const PAL = {
    noc: CIEMNE, papier: JASNE, biel: BIALE,
    granat: { tl: "#0F1B33", t: "#FFFFFF", a: "#F5C542", g: "#1C2C4F", d: "#9FB0CF" },
    oliwka: { tl: "#2F3A2C", t: "#F3EFE6", a: "#D9B26A", g: "#44533F", d: "#B6BFA9" },
    roz: { tl: "#F7E3E1", t: "#3B1F27", a: "#E2557A", g: "#FFFFFF", d: "#9B6F78" },
    piasek: { tl: "#E9DFCF", t: "#2A2420", a: "#B5651D", g: "#F7F2EA", d: "#8C7E6E" },
    limonka: { tl: "#111111", t: "#FFFFFF", a: "#C6F432", g: "#222222", d: "#A0A0A0" },
    fiolet: { tl: "#1B1033", t: "#FFFFFF", a: "#A78BFA", g: "#2D1B54", d: "#B8A9D9" },
    czerwien: { tl: "#141414", t: "#FFFFFF", a: "#FF3D3D", g: "#262626", d: "#A3A3A3" },
    mieta: { tl: "#DFF3EA", t: "#0F2E24", a: "#13A37A", g: "#FFFFFF", d: "#5E8577" },
    pomarancz: { tl: "#FF6B2C", t: "#FFFFFF", a: "#111111", g: "#FF8A57", d: "#FFE1D2" },
    zolty: { tl: "#FFD23F", t: "#111111", a: "#111111", g: "#FFFFFF", d: "#5C4A00" },
    niebo: { tl: "#EAF2FF", t: "#0B1F44", a: "#2563EB", g: "#FFFFFF", d: "#6B7FA3" },
  };
  const S = (o) => dodaj(o);
  const Zp = (pole, x, y, w, h, o = {}) => Z(pole, x, y, w, h, Object.assign({ ruch: [1.14, 1] }, o));

  // ---------- EDYTORSKIE ----------
  [["ed-pelne-ramka", "Pełne zdjęcie z ramką i tytułem", "noc"], ["ed-pelne-ramka-jasne", "Zdjęcie z ramką na jasnym", "papier"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "edytorskie", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie"), tx("nad", "Nadtytuł", "HISTORIA MARKI"), tx("tytul", "Tytuł", "Tworzymy\nz pasją"), tx("opis", "Opis", "Od małej pracowni do marki, którą zna cała Polska.", 2)],
    warstwy: [
      Zp("z1", 60, 60, 960, 1220, { we: W("odkryj-dol", 0.05, 0.9) }),
      P(100, 100, 880, 1140, "$tl", { obrys: 4, we: W("rysuj", 0.6, 0.9) }),
      T("nad", 90, 1350, { rozmiar: 24, font: "t", waga: 700, rozstaw: 250, kolor: "$a", we: W("lewo", 0.8, 0.6) }),
      T("tytul", 90, 1400, { rozmiar: 110, font: "n", waga: 700, interlinia: 1.0, wielkie: true, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 90, 1660, { rozmiar: 32, font: "t", szer: 880, kolor: "$d", interlinia: 1.4, we: W("gora", 1.3, 0.6) }),
    ] }));
  [["ed-dwa-pionowe", "Dwa pionowe zdjęcia i tytuł", "biel"], ["ed-dwa-pionowe-granat", "Dwa pionowe zdjęcia, granat", "granat"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "edytorskie", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie lewe"), zd("z2", "Zdjęcie prawe"), tx("tytul", "Tytuł", "Przed sezonem"), tx("opis", "Opis", "Nowe kolory, nowe formy i więcej światła.", 2), tx("stopka", "Stopka", "NR 04 / 2026")],
    warstwy: [
      Zp("z1", 60, 200, 470, 900, { we: W("odkryj-gora", 0.1, 0.9) }),
      Zp("z2", 550, 340, 470, 900, { we: W("odkryj-dol", 0.3, 0.9) }),
      T("tytul", 90, 1300, { rozmiar: 104, font: "n", waga: 700, wielkie: true, szer: 900, we: W("maska-gora", 0.8, 0.8) }),
      L(90, 1560, 400, 1560, "$a", 5, { we: W("rysuj", 1.1, 0.6) }),
      T("opis", 90, 1600, { rozmiar: 32, font: "t", szer: 800, kolor: "$d", interlinia: 1.4, we: W("gora", 1.2, 0.6) }),
      T("stopka", 990, 1790, { rozmiar: 24, font: "t", waga: 600, rozstaw: 200, wyr: "prawo", we: W("zanik", 1.5, 0.6) }),
    ] }));
  [["ed-luk", "Zdjęcie w łuku", "piasek"], ["ed-luk-oliwka", "Zdjęcie w łuku, oliwka", "oliwka"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "edytorskie", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie"), tx("nad", "Nadtytuł", "NOWA KOLEKCJA"), tx("tytul", "Tytuł", "Spokój\nw detalach"), tx("opis", "Opis", "Ręcznie robione, w małych seriach.")],
    warstwy: [
      T("nad", 540, 160, { rozmiar: 26, font: "t", waga: 700, rozstaw: 300, wyr: "srodek", kolor: "$a", we: W("zanik", 0.1, 0.6) }),
      Zp("z1", 190, 260, 700, 1000, { maska: "luk", we: W("odkryj-gora", 0.2, 1.0) }),
      T("tytul", 540, 1340, { rozmiar: 112, font: "n", waga: 700, wyr: "srodek", interlinia: 1.0, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 540, 1610, { rozmiar: 32, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.2, 0.6) }),
      K(540, 1760, 10, "$a", { we: W("pop", 1.4, 0.5) }),
    ] }));
  S({ id: "ed-gazeta", nazwa: "Strona gazety z kolumnami", kat: "edytorskie", czas: 8, kolory: PAL.papier,
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "WIELKI DZIEŃ\nDLA MIASTA"), tx("opis", "Lead", "Po trzech latach przygotowań otwieramy nowe miejsce w samym centrum. Zobacz, co przygotowaliśmy.", 3), tx("stopka", "Stopka", "WYDANIE SPECJALNE")],
    warstwy: [
      T("stopka", 90, 110, { rozmiar: 24, font: "t", waga: 800, rozstaw: 300, we: W("zanik", 0.1, 0.5) }),
      L(90, 160, 990, 160, "$t", 4, { we: W("rysuj", 0.2, 0.6) }), L(90, 172, 990, 172, "$t", 1, { we: W("rysuj", 0.3, 0.6) }),
      T("tytul", 90, 220, { rozmiar: 120, font: "n", waga: 700, interlinia: 0.98, wielkie: true, we: W("maska-gora", 0.4, 0.8) }),
      Zp("z1", 90, 520, 900, 820, { bw: true, we: W("odkryj-dol", 0.7, 0.9) }),
      T("opis", 90, 1400, { rozmiar: 34, font: "t", szer: 900, interlinia: 1.45, we: W("gora", 1.1, 0.7) }),
      L(90, 1760, 990, 1760, "$t", 2, { we: W("rysuj", 1.4, 0.6) }),
    ] });

  // ---------- MINIMALISTYCZNE ----------
  [["mi-srodek", "Małe zdjęcie na środku", "biel"], ["mi-srodek-noc", "Małe zdjęcie na środku, ciemne", "noc"], ["mi-srodek-roz", "Małe zdjęcie na środku, róż", "roz"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "minimal", czas: 7, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "mniej znaczy więcej"), tx("opis", "Podpis", "kolekcja jesień 2026")],
    warstwy: [
      Zp("z1", 290, 560, 500, 640, { we: W("skala", 0.1, 0.9) }),
      T("tytul", 540, 1290, { rozmiar: 54, font: "t", waga: 300, wyr: "srodek", rozstaw: 60, we: W("maska-gora", 0.7, 0.7) }),
      T("opis", 540, 1380, { rozmiar: 24, font: "t", waga: 600, wyr: "srodek", rozstaw: 300, kolor: "$d", wielkie: true, we: W("zanik", 1.0, 0.6) }),
      L(490, 470, 590, 470, "$t", 2, { we: W("rysuj", 0.6, 0.5) }),
    ] }));
  [["mi-linia", "Tytuł z cienką linią", "biel"], ["mi-linia-mieta", "Tytuł z cienką linią, mięta", "mieta"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "minimal", czas: 7, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "Prosto.\nCzysto.\nPięknie."), tx("stopka", "Stopka", "twojastrona.pl")],
    warstwy: [
      T("tytul", 90, 220, { rozmiar: 100, font: "t", waga: 300, interlinia: 1.1, we: W("lewo", 0.1, 0.9) }),
      L(90, 640, 90, 1780, "$t", 2, { we: W("rysuj", 0.4, 1.0) }),
      Zp("z1", 160, 700, 830, 1000, { we: W("odkryj-gora", 0.5, 0.9) }),
      T("stopka", 990, 1800, { rozmiar: 24, font: "t", waga: 500, wyr: "prawo", kolor: "$d", we: W("zanik", 1.3, 0.6) }),
    ] }));
  S({ id: "mi-slowo", nazwa: "Jedno wielkie słowo", kat: "minimal", czas: 6, kolory: PAL.biel,
    pola: [tx("slowo", "Słowo", "focus"), tx("opis", "Podpis", "Twoja myśl na dziś")],
    warstwy: [
      T("slowo", 540, 760, { rozmiar: 250, font: "t", waga: 800, wyr: "srodek", rozstaw: -30, we: W("maska-gora", 0.1, 0.9) }),
      T("opis", 540, 1080, { rozmiar: 30, font: "t", waga: 500, wyr: "srodek", kolor: "$d", we: W("zanik", 0.8, 0.6) }),
      K(540, 1200, 8, "$t", { we: W("pop", 1.1, 0.5) }),
    ] });

  // ---------- KOŁA I ROMBY ----------
  [["ks-trzy-kola", "Trzy zdjęcia w kołach", "noc"], ["ks-trzy-kola-roz", "Trzy zdjęcia w kołach, róż", "roz"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "ksztalty", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie duże"), zd("z2", "Zdjęcie średnie"), zd("z3", "Zdjęcie małe"), tx("tytul", "Tytuł", "Weekend\nw górach"), tx("opis", "Opis", "Trzy dni, dwa szczyty, jedna ekipa.")],
    warstwy: [
      Zp("z1", 90, 180, 620, 620, { maska: "kolo", we: W("skala", 0.1, 0.9) }),
      Zp("z2", 600, 640, 400, 400, { maska: "kolo", we: W("skala", 0.35, 0.9) }),
      Zp("z3", 220, 900, 260, 260, { maska: "kolo", we: W("skala", 0.6, 0.9) }),
      K(890, 300, 60, "$a", { we: W("pop", 0.9, 0.5, "sprezyna") }),
      T("tytul", 90, 1320, { rozmiar: 120, font: "n", waga: 700, interlinia: 0.98, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 90, 1600, { rozmiar: 32, font: "t", kolor: "$d", we: W("gora", 1.2, 0.6) }),
    ] }));
  [["ks-romb", "Zdjęcie w rombie", "granat"], ["ks-romb-jasny", "Zdjęcie w rombie, jasne", "piasek"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "ksztalty", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Tytuł", "NOWY\nROZDZIAŁ"), tx("opis", "Opis", "Zaczynamy od dziś")],
    warstwy: [
      Zp("z1", 140, 240, 800, 800, { maska: "romb", we: W("skala", 0.1, 1.0) }),
      TR(540, 1180, 40, "$a", { obrot: 180, we: W("pop", 0.8, 0.5) }),
      T("tytul", 540, 1270, { rozmiar: 130, font: "n", waga: 700, wyr: "srodek", interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 540, 1560, { rozmiar: 34, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.2, 0.6) }),
    ] }));
  [["ks-kolo-tlo", "Wielkie koło za zdjęciem", "pomarancz"], ["ks-kolo-tlo-limonka", "Wielkie koło za zdjęciem, limonka", "limonka"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "ksztalty", czas: 7, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie (najlepiej wycięta postać lub produkt)"), tx("tytul", "Tytuł", "ENERGIA\nNA CAŁY DZIEŃ"), tx("opis", "Opis", "Nowy smak już w sklepach")],
    warstwy: [
      K(540, 720, 470, "$g", { we: W("skala", 0.05, 0.9, "sprezyna") }),
      K(540, 720, 520, "$a", { obrys: 4, we: W("rysuj", 0.4, 1.0) }),
      Zp("z1", 190, 330, 700, 820, { maska: "kolo", we: W("gora", 0.5, 0.8) }),
      T("tytul", 540, 1320, { rozmiar: 110, font: "n", waga: 700, wyr: "srodek", interlinia: 0.98, wielkie: true, we: W("maska-gora", 0.9, 0.8) }),
      T("opis", 540, 1580, { rozmiar: 34, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.2, 0.6) }),
    ] }));

  // ---------- KOLAŻE ----------
  [["ko-siatka-4", "Siatka czterech zdjęć", "biel"], ["ko-siatka-4-noc", "Siatka czterech zdjęć, ciemna", "noc"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "kolaz", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie 1"), zd("z2", "Zdjęcie 2"), zd("z3", "Zdjęcie 3"), zd("z4", "Zdjęcie 4"), tx("tytul", "Tytuł", "Nasz tydzień"), tx("opis", "Opis", "Najlepsze chwile z planu")],
    warstwy: [
      T("tytul", 90, 150, { rozmiar: 96, font: "n", waga: 700, we: W("maska-gora", 0.05, 0.7) }),
      T("opis", 90, 290, { rozmiar: 30, font: "t", kolor: "$d", we: W("zanik", 0.4, 0.6) }),
      Zp("z1", 60, 400, 470, 620, { we: W("skala", 0.3, 0.7) }), Zp("z2", 550, 400, 470, 620, { we: W("skala", 0.45, 0.7) }),
      Zp("z3", 60, 1040, 470, 620, { we: W("skala", 0.6, 0.7) }), Zp("z4", 550, 1040, 470, 620, { we: W("skala", 0.75, 0.7) }),
      P(60, 1700, 960, 6, "$a", { we: W("odkryj-lewo", 1.2, 0.6) }),
    ] }));
  [["ko-rozrzucone", "Rozrzucone zdjęcia", "piasek"], ["ko-rozrzucone-fiolet", "Rozrzucone zdjęcia, fiolet", "fiolet"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "kolaz", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie 1"), zd("z2", "Zdjęcie 2"), zd("z3", "Zdjęcie 3"), tx("tytul", "Tytuł", "Wspomnienia\nz lata")],
    warstwy: [
      P(120, 200, 560, 700, "$g", { obrot: -6, we: W("pop", 0.1, 0.7, "sprezyna") }), Zp("z1", 150, 230, 500, 600, { obrot: -6, we: W("zanik", 0.3, 0.6) }),
      P(420, 620, 560, 700, "$g", { obrot: 5, we: W("pop", 0.4, 0.7, "sprezyna") }), Zp("z2", 450, 650, 500, 600, { obrot: 5, we: W("zanik", 0.6, 0.6) }),
      P(140, 1060, 480, 560, "$g", { obrot: -2, we: W("pop", 0.7, 0.7, "sprezyna") }), Zp("z3", 165, 1085, 430, 470, { obrot: -2, we: W("zanik", 0.9, 0.6) }),
      T("tytul", 990, 1660, { rozmiar: 96, font: "n", waga: 700, wyr: "prawo", interlinia: 1.0, we: W("maska-gora", 1.1, 0.8) }),
    ] }));
  [["ko-pasy-poziome", "Trzy zdjęcia w poziomych pasach", "noc"], ["ko-pasy-poziome-zolty", "Trzy pasy, żółty", "zolty"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "kolaz", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie 1"), zd("z2", "Zdjęcie 2"), zd("z3", "Zdjęcie 3"), tx("tytul", "Tytuł", "TRZY KROKI"), tx("opis", "Opis", "do lepszej formy")],
    warstwy: [
      Zp("z1", 0, 0, 1080, 520, { we: W("odkryj-lewo", 0.05, 0.8) }), Zp("z2", 0, 540, 1080, 520, { we: W("odkryj-prawo", 0.25, 0.8) }), Zp("z3", 0, 1080, 1080, 520, { we: W("odkryj-lewo", 0.45, 0.8) }),
      P(0, 1600, 1080, 320, "$tl", { we: W("odkryj-gora", 0.6, 0.6) }),
      T("tytul", 90, 1640, { rozmiar: 100, font: "n", waga: 700, wielkie: true, we: W("maska-gora", 0.9, 0.7) }),
      T("opis", 90, 1780, { rozmiar: 34, font: "t", kolor: "$d", we: W("gora", 1.1, 0.6) }),
    ] }));

  // ---------- LICZBY I OBSERWUJĄCY ----------
  [["st-wielka-liczba", "Wielka liczba na środku", "limonka"], ["st-wielka-liczba-granat", "Wielka liczba, granat", "granat"], ["st-wielka-liczba-biel", "Wielka liczba, białe tło", "biel"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "statystyki", czas: 7, kolory: PAL[p],
    pola: [tx("nad", "Nad liczbą", "W TYM ROKU"), tx("liczba", "Liczba", "250 000"), tx("opis", "Pod liczbą", "osób obejrzało nasze rolki"), tx("stopka", "Stopka", "dziękujemy!")],
    warstwy: [
      T("nad", 540, 640, { rozmiar: 30, font: "t", waga: 700, rozstaw: 250, wyr: "srodek", kolor: "$d", we: W("zanik", 0.1, 0.6) }),
      T("liczba", 540, 720, { rozmiar: 200, font: "n", waga: 700, wyr: "srodek", kolor: "$a", maks: 960, we: W("licz", 0.3, 1.5) }),
      T("opis", 540, 1000, { rozmiar: 40, font: "t", waga: 600, wyr: "srodek", szer: 860, we: W("gora", 1.0, 0.6) }),
      L(440, 1170, 640, 1170, "$a", 5, { we: W("rysuj", 1.3, 0.5) }),
      T("stopka", 540, 1230, { rozmiar: 30, font: "t", wyr: "srodek", kolor: "$d", we: W("zanik", 1.5, 0.5) }),
    ] }));
  [["st-wykres", "Słupki wzrostu", "noc"], ["st-wykres-mieta", "Słupki wzrostu, mięta", "mieta"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "statystyki", czas: 8, kolory: PAL[p],
    pola: [tx("tytul", "Tytuł", "Wzrost obserwujących"), tx("l1", "Wartość 1", "2K"), tx("l2", "Wartość 2", "9K"), tx("l3", "Wartość 3", "24K"), tx("l4", "Wartość 4", "61K"), tx("opis", "Podpis", "styczeń – kwiecień")],
    warstwy: [
      T("tytul", 90, 220, { rozmiar: 70, font: "n", waga: 700, szer: 900, we: W("maska-gora", 0.1, 0.7) }),
      ...[260, 480, 760, 1100].map((h, i) => P(110 + i * 230, 1600 - h, 180, h, i === 3 ? "$a" : "$g", { r: 12, we: W("odkryj-gora", 0.4 + i * 0.2, 0.8) })),
      ...[260, 480, 760, 1100].map((h, i) => T("l" + (i + 1), 200 + i * 230, 1600 - h - 80, { rozmiar: 46, font: "t", waga: 800, wyr: "srodek", we: W("licz", 0.7 + i * 0.2, 0.8) })),
      L(90, 1620, 990, 1620, "$d", 3, { we: W("rysuj", 0.3, 0.6) }),
      T("opis", 90, 1680, { rozmiar: 32, font: "t", kolor: "$d", we: W("zanik", 1.5, 0.6) }),
    ] }));
  [["st-kamien-milowy", "Kamień milowy z konfetti", "fiolet"], ["st-kamien-milowy-roz", "Kamień milowy, róż", "roz"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "statystyki", czas: 7, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie profilowe"), tx("liczba", "Liczba", "100K"), tx("tytul", "Tytuł", "Jest nas już"), tx("opis", "Opis", "Dziękuję za każde serduszko!")],
    warstwy: [
      ...[[160, 260, 22], [920, 320, 16], [220, 1500, 18], [860, 1450, 24], [540, 180, 12], [980, 900, 14], [100, 900, 12]].map(([x, y, r], i) => K(x, y, r, i % 2 ? "$a" : "$t", { we: W("pop", 0.8 + i * 0.08, 0.5, "sprezyna") })),
      Zp("z1", 390, 330, 300, 300, { maska: "kolo", we: W("skala", 0.1, 0.7) }),
      T("tytul", 540, 720, { rozmiar: 60, font: "t", waga: 600, wyr: "srodek", we: W("zanik", 0.4, 0.6) }),
      T("liczba", 540, 800, { rozmiar: 280, font: "n", waga: 700, wyr: "srodek", kolor: "$a", we: W("licz", 0.5, 1.4) }),
      T("opis", 540, 1160, { rozmiar: 40, font: "t", wyr: "srodek", szer: 860, we: W("gora", 1.2, 0.6) }),
    ] }));

  // ---------- CYTATY I HASŁA ----------
  [["cy-duzy-cudzyslow", "Duży cudzysłów", "noc"], ["cy-duzy-cudzyslow-piasek", "Duży cudzysłów, piasek", "piasek"], ["cy-duzy-cudzyslow-granat", "Duży cudzysłów, granat", "granat"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "cytaty", czas: 8, kolory: PAL[p],
    pola: [tx("cytat", "Cytat", "Nie musisz być wielki, żeby zacząć. Musisz zacząć, żeby być wielki.", 3), tx("autor", "Autor", "— Zig Ziglar")],
    warstwy: [
      TL("“", 90, 380, { rozmiar: 420, font: "n", waga: 700, kolor: "$a", we: W("pop", 0.05, 0.7, "sprezyna") }),
      T("cytat", 90, 760, { rozmiar: 74, font: "n", waga: 600, szer: 900, interlinia: 1.2, we: W("maska-gora", 0.4, 1.0) }),
      L(90, 1400, 260, 1400, "$a", 5, { we: W("rysuj", 1.2, 0.5) }),
      T("autor", 90, 1440, { rozmiar: 36, font: "t", waga: 600, kolor: "$d", we: W("lewo", 1.3, 0.6) }),
    ] }));
  [["cy-na-zdjeciu", "Cytat na zdjęciu", "noc"], ["cy-na-zdjeciu-oliwka", "Cytat na zdjęciu, oliwka", "oliwka"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "cytaty", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie w tle"), tx("cytat", "Cytat", "Najlepszy moment na start jest teraz.", 2), tx("autor", "Podpis", "@twojprofil")],
    warstwy: [
      Zp("z1", 0, 0, 1080, 1920, { we: W("zanik", 0, 0.8) }),
      P(0, 0, 1080, 1920, "#000000", { krycie: 0.45, we: W("zanik", 0.2, 0.6) }),
      T("cytat", 540, 760, { rozmiar: 96, font: "n", waga: 700, wyr: "srodek", szer: 900, interlinia: 1.1, kolor: "#FFFFFF", we: W("maska-gora", 0.5, 1.0) }),
      L(470, 1150, 610, 1150, "$a", 5, { we: W("rysuj", 1.2, 0.5) }),
      T("autor", 540, 1190, { rozmiar: 32, font: "t", waga: 600, wyr: "srodek", kolor: "#FFFFFF", we: W("zanik", 1.3, 0.6) }),
    ] }));
  [["cy-haslo-pasy", "Hasło na kolorowych pasach", "pomarancz"], ["cy-haslo-pasy-zolty", "Hasło na pasach, żółty", "zolty"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "cytaty", czas: 6, kolory: PAL[p],
    pola: [tx("w1", "Linia 1", "RÓB"), tx("w2", "Linia 2", "TO, CO"), tx("w3", "Linia 3", "KOCHASZ")],
    warstwy: [
      ...[0, 1, 2].flatMap((i) => [P(0, 560 + i * 280, 1080, 240, i === 1 ? "$a" : "$g", { we: W(i % 2 ? "odkryj-prawo" : "odkryj-lewo", 0.1 + i * 0.2, 0.6) }),
        T("w" + (i + 1), 540, 590 + i * 280, { rozmiar: 160, font: "n", waga: 700, wyr: "srodek", wielkie: true, kolor: i === 1 ? "$tl" : "$t", we: W("maska-gora", 0.4 + i * 0.2, 0.6) })]),
    ] }));

  // ---------- PROMOCJE I PRODUKTY ----------
  [["pr-premiera", "Premiera produktu", "noc"], ["pr-premiera-niebo", "Premiera produktu, niebieski", "niebo"], ["pr-premiera-roz", "Premiera produktu, róż", "roz"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "promocje", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie produktu"), tx("nad", "Nadtytuł", "PREMIERA"), tx("nazwa", "Nazwa produktu", "Krem nocny\nRegeneracja"), tx("opis", "Opis", "Z witaminą C i kwasem hialuronowym"), tx("cena", "Cena", "89 zł"), tx("przycisk", "Przycisk", "ZAMÓW")],
    warstwy: [
      P(90, 160, 900, 1000, "$g", { r: 40, we: W("skala", 0.05, 0.7) }),
      Zp("z1", 140, 210, 800, 900, { maska: "zaokr", r: 30, we: W("zanik", 0.3, 0.7) }),
      P(90, 120, 280, 80, "$a", { r: 40, we: W("pop", 0.6, 0.5, "sprezyna") }), T("nad", 230, 140, { rozmiar: 30, font: "t", waga: 800, wyr: "srodek", rozstaw: 200, kolor: "$tl", we: W("zanik", 0.7, 0.4) }),
      T("nazwa", 90, 1230, { rozmiar: 90, font: "n", waga: 700, interlinia: 1.0, szer: 900, we: W("maska-gora", 0.8, 0.8) }),
      T("opis", 90, 1460, { rozmiar: 32, font: "t", kolor: "$d", szer: 900, we: W("gora", 1.1, 0.6) }),
      T("cena", 90, 1570, { rozmiar: 110, font: "n", waga: 700, kolor: "$a", we: W("pop", 1.3, 0.6, "sprezyna") }),
      P(640, 1600, 350, 110, "$t", { r: 55, we: W("odkryj-lewo", 1.4, 0.5) }), T("przycisk", 815, 1634, { rozmiar: 36, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, kolor: "$tl", we: W("zanik", 1.6, 0.4) }),
    ] }));
  [["pr-wyprzedaz", "Wyprzedaż z wielkim napisem", "czerwien"], ["pr-wyprzedaz-zolty", "Wyprzedaż, żółty", "zolty"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "promocje", czas: 6, kolory: PAL[p],
    pola: [tx("w1", "Napis", "SALE"), tx("rabat", "Rabat", "do -70%"), tx("opis", "Kiedy", "tylko ten weekend"), tx("przycisk", "Przycisk", "SPRAWDŹ")],
    warstwy: [
      T("w1", 540, 420, { rozmiar: 400, font: "n", waga: 700, wyr: "srodek", wielkie: true, we: W("maska-gora", 0.05, 0.8) }),
      P(140, 980, 800, 200, "$a", { obrot: -4, we: W("pop", 0.5, 0.6, "sprezyna") }),
      T("rabat", 540, 1010, { rozmiar: 130, font: "n", waga: 700, wyr: "srodek", kolor: "$tl", obrot: -4, we: W("zanik", 0.7, 0.4) }),
      T("opis", 540, 1290, { rozmiar: 44, font: "t", waga: 600, wyr: "srodek", we: W("gora", 0.9, 0.6) }),
      P(340, 1500, 400, 110, "$t", { obrys: 4, r: 55, we: W("rysuj", 1.1, 0.7) }), T("przycisk", 540, 1534, { rozmiar: 38, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, we: W("zanik", 1.3, 0.4) }),
    ] }));
  [["pr-trzy-produkty", "Trzy produkty z cenami", "biel"], ["pr-trzy-produkty-piasek", "Trzy produkty, piasek", "piasek"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "promocje", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Produkt 1"), zd("z2", "Produkt 2"), zd("z3", "Produkt 3"), tx("tytul", "Tytuł", "Nowości tygodnia"), tx("c1", "Cena 1", "49 zł"), tx("c2", "Cena 2", "79 zł"), tx("c3", "Cena 3", "129 zł")],
    warstwy: [
      T("tytul", 90, 150, { rozmiar: 84, font: "n", waga: 700, szer: 900, we: W("maska-gora", 0.05, 0.7) }),
      ...[0, 1, 2].flatMap((i) => [P(90, 360 + i * 500, 900, 440, "$g", { r: 30, we: W("odkryj-lewo", 0.3 + i * 0.2, 0.7) }),
        Zp("z" + (i + 1), 120, 390 + i * 500, 380, 380, { maska: "zaokr", r: 20, we: W("skala", 0.5 + i * 0.2, 0.6) }),
        T("c" + (i + 1), 940, 520 + i * 500, { rozmiar: 90, font: "n", waga: 700, wyr: "prawo", kolor: "$a", we: W("pop", 0.7 + i * 0.2, 0.6, "sprezyna") })]),
    ] }));

  // ---------- WYDARZENIA ----------
  [["wy-bilet", "Bilet na wydarzenie", "granat"], ["wy-bilet-limonka", "Bilet na wydarzenie, limonka", "limonka"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "wydarzenia", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie"), tx("tytul", "Nazwa", "NOC\nKONCERTÓW"), tx("data", "Data", "14.11.2026"), tx("godz", "Godzina", "20:00"), tx("miejsce", "Miejsce", "Klub Stodoła, Warszawa"), tx("przycisk", "Przycisk", "KUP BILET")],
    warstwy: [
      Zp("z1", 0, 0, 1080, 900, { we: W("odkryj-gora", 0, 0.8) }),
      P(80, 820, 920, 900, "$g", { r: 30, we: W("gora", 0.4, 0.7) }),
      T("tytul", 140, 880, { rozmiar: 110, font: "n", waga: 700, interlinia: 0.95, wielkie: true, we: W("maska-gora", 0.7, 0.8) }),
      L(140, 1170, 940, 1170, "$d", 3, { we: W("rysuj", 0.9, 0.6) }),
      T("data", 140, 1210, { rozmiar: 64, font: "n", waga: 700, kolor: "$a", we: W("lewo", 1.0, 0.6) }),
      T("godz", 940, 1210, { rozmiar: 64, font: "n", waga: 700, wyr: "prawo", we: W("prawo", 1.1, 0.6) }),
      T("miejsce", 140, 1320, { rozmiar: 34, font: "t", kolor: "$d", szer: 800, we: W("gora", 1.2, 0.6) }),
      P(140, 1500, 800, 120, "$a", { r: 60, we: W("odkryj-lewo", 1.4, 0.6) }), T("przycisk", 540, 1538, { rozmiar: 40, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, kolor: "$tl", we: W("zanik", 1.6, 0.4) }),
    ] }));
  [["wy-odliczanie-dni", "Zostało X dni", "noc"], ["wy-odliczanie-dni-fiolet", "Zostało X dni, fiolet", "fiolet"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "wydarzenia", czas: 6, kolory: PAL[p],
    pola: [tx("nad", "Nad liczbą", "ZOSTAŁO"), tx("liczba", "Liczba", "3"), tx("pod", "Pod liczbą", "DNI"), tx("opis", "Do czego", "do startu zapisów")],
    warstwy: [
      T("nad", 540, 420, { rozmiar: 60, font: "n", waga: 700, wyr: "srodek", rozstaw: 200, we: W("zanik", 0.1, 0.6) }),
      K(540, 900, 330, "$a", { obrys: 10, we: W("rysuj", 0.2, 1.0) }),
      T("liczba", 540, 700, { rozmiar: 400, font: "n", waga: 700, wyr: "srodek", we: W("pop", 0.6, 0.7, "sprezyna") }),
      T("pod", 540, 1290, { rozmiar: 80, font: "n", waga: 700, wyr: "srodek", rozstaw: 200, kolor: "$a", we: W("gora", 0.9, 0.6) }),
      T("opis", 540, 1420, { rozmiar: 36, font: "t", wyr: "srodek", kolor: "$d", we: W("zanik", 1.2, 0.6) }),
    ] }));
  [["wy-agenda", "Plan dnia wydarzenia", "biel"], ["wy-agenda-granat", "Plan dnia, granat", "granat"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "wydarzenia", czas: 8, kolory: PAL[p],
    pola: [tx("tytul", "Tytuł", "Plan dnia"), tx("g1", "Godzina 1", "10:00"), tx("p1", "Punkt 1", "Otwarcie i kawa"), tx("g2", "Godzina 2", "11:30"), tx("p2", "Punkt 2", "Warsztaty z montażu"), tx("g3", "Godzina 3", "14:00"), tx("p3", "Punkt 3", "Panel dyskusyjny"), tx("g4", "Godzina 4", "17:00"), tx("p4", "Punkt 4", "After party")],
    warstwy: [
      T("tytul", 90, 200, { rozmiar: 110, font: "n", waga: 700, we: W("maska-gora", 0.05, 0.7) }),
      L(180, 480, 180, 1640, "$d", 3, { we: W("rysuj", 0.3, 1.2) }),
      ...[0, 1, 2, 3].flatMap((i) => [K(180, 520 + i * 360, 22, "$a", { we: W("pop", 0.5 + i * 0.25, 0.5, "sprezyna") }),
        T("g" + (i + 1), 240, 480 + i * 360, { rozmiar: 54, font: "n", waga: 700, kolor: "$a", we: W("lewo", 0.55 + i * 0.25, 0.5) }),
        T("p" + (i + 1), 240, 560 + i * 360, { rozmiar: 40, font: "t", waga: 600, szer: 760, we: W("lewo", 0.65 + i * 0.25, 0.5) })]),
    ] }));

  // ---------- PODRÓŻE I LIFESTYLE ----------
  [["li-pocztowka-ramka", "Pocztówka w ramce", "piasek"], ["li-pocztowka-niebo", "Pocztówka, niebieski", "niebo"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "lifestyle", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie"), tx("nad", "Pozdrowienia z", "POZDROWIENIA Z"), tx("miejsce", "Miejsce", "Lizbony"), tx("opis", "Opis", "5 dni, 40 km pieszo i milion pasteis de nata.", 2)],
    warstwy: [
      P(80, 200, 920, 1200, "$g", { obrot: 2, we: W("pop", 0.05, 0.8, "sprezyna") }),
      Zp("z1", 120, 240, 840, 960, { obrot: 2, we: W("zanik", 0.4, 0.7) }),
      T("nad", 540, 1240, { rozmiar: 28, font: "t", waga: 700, rozstaw: 300, wyr: "srodek", kolor: "$d", obrot: 2, we: W("zanik", 0.9, 0.5) }),
      T("miejsce", 540, 1440, { rozmiar: 150, font: "n", waga: 700, wyr: "srodek", kolor: "$a", obrot: -3, we: W("pop", 1.0, 0.7, "sprezyna") }),
      T("opis", 540, 1680, { rozmiar: 32, font: "t", wyr: "srodek", szer: 860, we: W("gora", 1.3, 0.6) }),
    ] }));
  [["li-mapa-trasa", "Trasa podróży", "oliwka"], ["li-mapa-trasa-noc", "Trasa podróży, ciemna", "noc"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "lifestyle", czas: 8, kolory: PAL[p],
    pola: [tx("tytul", "Tytuł", "Nasza trasa"), tx("m1", "Miejsce 1", "Kraków"), tx("m2", "Miejsce 2", "Wiedeń"), tx("m3", "Miejsce 3", "Wenecja"), tx("m4", "Miejsce 4", "Rzym"), tx("opis", "Opis", "2400 km w 10 dni")],
    warstwy: [
      T("tytul", 90, 180, { rozmiar: 110, font: "n", waga: 700, we: W("maska-gora", 0.05, 0.7) }),
      L(200, 560, 820, 860, "$a", 6, { we: W("rysuj", 0.4, 0.6) }), L(820, 860, 300, 1180, "$a", 6, { we: W("rysuj", 0.9, 0.6) }), L(300, 1180, 780, 1500, "$a", 6, { we: W("rysuj", 1.4, 0.6) }),
      ...[[200, 560], [820, 860], [300, 1180], [780, 1500]].flatMap(([x, y], i) => [K(x, y, 30, "$t", { we: W("pop", 0.3 + i * 0.5, 0.5, "sprezyna") }),
        T("m" + (i + 1), x + (i % 2 ? -60 : 60), y - 30, { rozmiar: 50, font: "t", waga: 700, wyr: i % 2 ? "prawo" : "lewo", we: W("zanik", 0.4 + i * 0.5, 0.5) })]),
      T("opis", 540, 1700, { rozmiar: 36, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 2.0, 0.6) }),
    ] }));
  [["li-dzien", "Mój dzień w trzech kadrach", "roz"], ["li-dzien-mieta", "Mój dzień, mięta", "mieta"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "lifestyle", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Rano"), zd("z2", "Południe"), zd("z3", "Wieczór"), tx("tytul", "Tytuł", "Mój dzień"), tx("e1", "Podpis 1", "rano"), tx("e2", "Podpis 2", "w pracy"), tx("e3", "Podpis 3", "wieczorem")],
    warstwy: [
      T("tytul", 540, 130, { rozmiar: 100, font: "n", waga: 700, wyr: "srodek", we: W("maska-gora", 0.05, 0.7) }),
      ...[0, 1, 2].flatMap((i) => [Zp("z" + (i + 1), 140 + (i % 2) * 300, 320 + i * 520, 500, 440, { maska: "zaokr", r: 30, we: W(i % 2 ? "prawo" : "lewo", 0.3 + i * 0.25, 0.7) }),
        T("e" + (i + 1), i % 2 ? 380 : 700, 540 + i * 520, { rozmiar: 46, font: "t", waga: 700, wyr: i % 2 ? "prawo" : "lewo", kolor: "$a", we: W("zanik", 0.6 + i * 0.25, 0.5) })]),
    ] }));

  // ---------- ZAPOWIEDZI I ZAKOŃCZENIA ----------
  [["za-dzieki-logo", "Dzięki z logo", "noc"], ["za-dzieki-logo-pomarancz", "Dzięki z logo, pomarańcz", "pomarancz"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "zakonczenia", czas: 5, kolory: PAL[p],
    pola: [lg("logo", "Logo"), tx("tytul", "Tytuł", "Dzięki,\nże jesteś!"), tx("opis", "Opis", "Zostaw komentarz i obserwuj po więcej")],
    warstwy: [
      Z("logo", 390, 300, 300, 300, { dopasuj: "zawrzyj", we: W("pop", 0.1, 0.7, "sprezyna") }),
      T("tytul", 540, 780, { rozmiar: 140, font: "n", waga: 700, wyr: "srodek", interlinia: 0.98, we: W("maska-gora", 0.4, 0.8) }),
      T("opis", 540, 1140, { rozmiar: 38, font: "t", wyr: "srodek", szer: 860, kolor: "$d", we: W("gora", 0.9, 0.6) }),
    ] }));
  [["za-zapowiedz", "Zapowiedź: już wkrótce", "fiolet"], ["za-zapowiedz-granat", "Zapowiedź, granat", "granat"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "zakonczenia", czas: 6, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie (rozmyte w tle)"), tx("nad", "Nadtytuł", "JUŻ WKRÓTCE"), tx("tytul", "Tytuł", "Coś\nwielkiego"), tx("data", "Data", "01.12")],
    warstwy: [
      Zp("z1", 0, 0, 1080, 1920, { we: W("zanik", 0, 1.0) }),
      P(0, 0, 1080, 1920, "$tl", { krycie: 0.7, we: W("zanik", 0.2, 0.6) }),
      T("nad", 540, 600, { rozmiar: 40, font: "t", waga: 700, rozstaw: 400, wyr: "srodek", kolor: "$a", we: W("zanik", 0.5, 0.7) }),
      T("tytul", 540, 700, { rozmiar: 200, font: "n", waga: 700, wyr: "srodek", interlinia: 0.92, wielkie: true, we: W("maska-gora", 0.8, 0.9) }),
      P(390, 1200, 300, 110, "$a", { r: 55, we: W("pop", 1.3, 0.6, "sprezyna") }), T("data", 540, 1222, { rozmiar: 60, font: "n", waga: 700, wyr: "srodek", kolor: "$tl", we: W("zanik", 1.5, 0.4) }),
    ] }));
  [["za-link", "Link w bio", "limonka"], ["za-link-biel", "Link w bio, białe", "biel"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "zakonczenia", czas: 5, kolory: PAL[p],
    pola: [tx("tytul", "Tytuł", "Całość\nna YouTube"), tx("przycisk", "Przycisk", "LINK W BIO"), tx("opis", "Opis", "pełny odcinek: 42 minuty")],
    warstwy: [
      T("tytul", 540, 560, { rozmiar: 150, font: "n", waga: 700, wyr: "srodek", interlinia: 0.95, we: W("maska-gora", 0.1, 0.8) }),
      TR(540, 1020, 50, "$a", { obrot: 0, we: W("gora", 0.6, 0.5) }),
      P(240, 1100, 600, 140, "$a", { r: 70, we: W("pop", 0.7, 0.6, "sprezyna") }),
      T("przycisk", 540, 1143, { rozmiar: 50, font: "t", waga: 800, wyr: "srodek", rozstaw: 120, kolor: "$tl", we: W("zanik", 0.9, 0.4) }),
      T("opis", 540, 1330, { rozmiar: 34, font: "t", wyr: "srodek", kolor: "$d", we: W("gora", 1.1, 0.6) }),
    ] }));

  // ---------- PORADY I LISTY (nowa kategoria) ----------
  [["po-lista-5", "5 porad w punktach", "noc"], ["po-lista-5-mieta", "5 porad, mięta", "mieta"], ["po-lista-5-zolty", "5 porad, żółty", "zolty"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "porady", czas: 9, kolory: PAL[p],
    pola: [tx("tytul", "Tytuł", "5 sposobów\nna lepsze rolki"), ...[1, 2, 3, 4, 5].map((i) => tx("p" + i, "Punkt " + i, ["Pierwsze 2 sekundy to hak", "Napisy na środku kadru", "Cięcie co 2–3 sekundy", "Muzyka pod emocję", "Jasne wezwanie na końcu"][i - 1]))],
    warstwy: [
      T("tytul", 90, 200, { rozmiar: 96, font: "n", waga: 700, interlinia: 1.0, szer: 900, we: W("maska-gora", 0.05, 0.8) }),
      ...[0, 1, 2, 3, 4].flatMap((i) => [K(140, 680 + i * 230, 46, "$a", { we: W("pop", 0.6 + i * 0.25, 0.5, "sprezyna") }),
        TL(String(i + 1), 140, 650 + i * 230, { rozmiar: 54, font: "n", waga: 700, wyr: "srodek", kolor: "$tl", we: W("zanik", 0.7 + i * 0.25, 0.4) }),
        T("p" + (i + 1), 220, 655 + i * 230, { rozmiar: 44, font: "t", waga: 600, szer: 780, we: W("lewo", 0.65 + i * 0.25, 0.5) })]),
    ] }));
  [["po-tak-nie", "Tak / nie: dobre i złe praktyki", "biel"], ["po-tak-nie-noc", "Tak / nie, ciemne", "noc"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "porady", czas: 8, kolory: PAL[p],
    pola: [tx("tytul", "Tytuł", "Rób tak, nie tak"), tx("tak", "Dobrze", "Krótki hak w pierwszej sekundzie", 2), tx("nie", "Źle", "Długi wstęp i przedstawianie się", 2)],
    warstwy: [
      T("tytul", 540, 220, { rozmiar: 96, font: "n", waga: 700, wyr: "srodek", we: W("maska-gora", 0.05, 0.7) }),
      P(90, 480, 900, 560, "#22C55E", { r: 30, krycie: 0.18, we: W("odkryj-lewo", 0.3, 0.7) }), K(200, 600, 60, "#22C55E", { we: W("pop", 0.6, 0.5, "sprezyna") }), TL("TAK", 200, 582, { rozmiar: 34, font: "t", waga: 800, wyr: "srodek", kolor: "#FFFFFF", we: W("zanik", 0.7, 0.4) }),
      T("tak", 300, 560, { rozmiar: 50, font: "t", waga: 700, szer: 640, we: W("lewo", 0.7, 0.6) }),
      P(90, 1120, 900, 560, "#EF4444", { r: 30, krycie: 0.18, we: W("odkryj-lewo", 1.0, 0.7) }), K(200, 1240, 60, "#EF4444", { we: W("pop", 1.3, 0.5, "sprezyna") }), TL("NIE", 200, 1222, { rozmiar: 34, font: "t", waga: 800, wyr: "srodek", kolor: "#FFFFFF", we: W("zanik", 1.4, 0.4) }),
      T("nie", 300, 1200, { rozmiar: 50, font: "t", waga: 700, szer: 640, we: W("lewo", 1.4, 0.6) }),
    ] }));
  [["po-krok", "Krok po kroku ze zdjęciem", "piasek"], ["po-krok-granat", "Krok po kroku, granat", "granat"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "porady", czas: 7, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie"), tx("nr", "Numer kroku", "KROK 1"), tx("tytul", "Tytuł", "Ustaw światło z boku"), tx("opis", "Opis", "Okno albo lampa pod kątem 45° da miękki, filmowy cień.", 2)],
    warstwy: [
      Zp("z1", 0, 0, 1080, 1100, { we: W("odkryj-gora", 0, 0.8) }),
      P(90, 1040, 300, 100, "$a", { r: 50, we: W("pop", 0.5, 0.5, "sprezyna") }), T("nr", 240, 1064, { rozmiar: 40, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, kolor: "$tl", we: W("zanik", 0.6, 0.4) }),
      T("tytul", 90, 1200, { rozmiar: 90, font: "n", waga: 700, szer: 900, interlinia: 1.0, we: W("maska-gora", 0.7, 0.8) }),
      T("opis", 90, 1480, { rozmiar: 36, font: "t", szer: 900, kolor: "$d", interlinia: 1.4, we: W("gora", 1.1, 0.6) }),
    ] }));
  [["po-mit-fakt", "Mit i fakt", "fiolet"], ["po-mit-fakt-biel", "Mit i fakt, białe", "biel"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "porady", czas: 8, kolory: PAL[p],
    pola: [tx("mit", "Mit", "Do rolek potrzebujesz drogiego sprzętu", 2), tx("fakt", "Fakt", "Telefon i dobre światło wystarczą na start", 2)],
    warstwy: [
      P(90, 300, 300, 110, "#EF4444", { r: 20, we: W("pop", 0.1, 0.5, "sprezyna") }), TL("MIT", 240, 322, { rozmiar: 60, font: "n", waga: 700, wyr: "srodek", kolor: "#FFFFFF", we: W("zanik", 0.2, 0.4) }),
      T("mit", 90, 460, { rozmiar: 70, font: "n", waga: 700, szer: 900, interlinia: 1.05, we: W("maska-gora", 0.3, 0.8) }),
      L(90, 920, 990, 920, "$d", 3, { we: W("rysuj", 0.9, 0.6) }),
      P(90, 1000, 340, 110, "#22C55E", { r: 20, we: W("pop", 1.2, 0.5, "sprezyna") }), TL("FAKT", 260, 1022, { rozmiar: 60, font: "n", waga: 700, wyr: "srodek", kolor: "#FFFFFF", we: W("zanik", 1.3, 0.4) }),
      T("fakt", 90, 1160, { rozmiar: 70, font: "n", waga: 700, szer: 900, interlinia: 1.05, kolor: "$a", we: W("maska-gora", 1.4, 0.8) }),
    ] }));

  // ---------- OPINIE I REKOMENDACJE (nowa kategoria) ----------
  [["op-opinia", "Opinia klienta z gwiazdkami", "biel"], ["op-opinia-noc", "Opinia klienta, ciemna", "noc"], ["op-opinia-roz", "Opinia klienta, róż", "roz"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "opinie", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie klienta"), tx("opinia", "Opinia (wpisz prawdziwą)", "Wpisz tu opinię klienta, którą dostałeś (np. z Google).", 3), tx("autor", "Imię i nazwisko", "Imię Nazwisko"), tx("rola", "Kim jest", "klientka od 2024")],
    warstwy: [
      ...[0, 1, 2, 3, 4].map((i) => K(300 + i * 120, 340, 34, "#F5B301", { we: W("pop", 0.1 + i * 0.1, 0.4, "sprezyna") })),
      T("opinia", 540, 460, { rozmiar: 62, font: "n", waga: 600, wyr: "srodek", szer: 900, interlinia: 1.25, we: W("maska-gora", 0.6, 1.0) }),
      Zp("z1", 440, 1120, 200, 200, { maska: "kolo", we: W("skala", 1.2, 0.6) }),
      T("autor", 540, 1360, { rozmiar: 44, font: "t", waga: 700, wyr: "srodek", we: W("gora", 1.4, 0.5) }),
      T("rola", 540, 1430, { rozmiar: 30, font: "t", wyr: "srodek", kolor: "$d", we: W("zanik", 1.5, 0.5) }),
    ] }));
  [["op-polecam", "Polecam: produkt z opisem", "piasek"], ["op-polecam-limonka", "Polecam, limonka", "limonka"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "opinie", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Zdjęcie produktu"), tx("nad", "Nadtytuł", "MÓJ HIT MIESIĄCA"), tx("nazwa", "Nazwa", "Kamera X200"), tx("plus", "Zalety", "lekka · świetna stabilizacja · 4K 60 kl./s", 2)],
    warstwy: [
      T("nad", 90, 160, { rozmiar: 30, font: "t", waga: 800, rozstaw: 250, kolor: "$a", we: W("lewo", 0.05, 0.6) }),
      Zp("z1", 90, 240, 900, 1000, { maska: "zaokr", r: 40, we: W("odkryj-gora", 0.2, 0.9) }),
      T("nazwa", 90, 1320, { rozmiar: 110, font: "n", waga: 700, szer: 900, we: W("maska-gora", 0.8, 0.8) }),
      T("plus", 90, 1500, { rozmiar: 38, font: "t", szer: 900, kolor: "$d", interlinia: 1.4, we: W("gora", 1.1, 0.6) }),
      K(920, 1200, 70, "$a", { we: W("pop", 1.3, 0.6, "sprezyna") }), TL("10/10", 920, 1180, { rozmiar: 36, font: "t", waga: 800, wyr: "srodek", kolor: "$tl", we: W("zanik", 1.4, 0.4) }),
    ] }));
  [["op-przed-po", "Przed i po", "noc"], ["op-przed-po-biel", "Przed i po, białe", "biel"]].forEach(([id, nazwa, p]) => S({ id, nazwa, kat: "opinie", czas: 8, kolory: PAL[p],
    pola: [zd("z1", "Przed"), zd("z2", "Po"), tx("e1", "Podpis 1", "PRZED"), tx("e2", "Podpis 2", "PO"), tx("opis", "Opis", "3 miesiące współpracy")],
    warstwy: [
      Zp("z1", 0, 0, 1080, 900, { bw: true, we: W("odkryj-lewo", 0.05, 0.8) }),
      Zp("z2", 0, 920, 1080, 900, { we: W("odkryj-prawo", 0.5, 0.8) }),
      P(60, 60, 240, 90, "$tl", { r: 45, we: W("pop", 0.6, 0.5, "sprezyna") }), T("e1", 180, 78, { rozmiar: 40, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, we: W("zanik", 0.7, 0.4) }),
      P(60, 980, 200, 90, "$a", { r: 45, we: W("pop", 1.0, 0.5, "sprezyna") }), T("e2", 160, 998, { rozmiar: 40, font: "t", waga: 800, wyr: "srodek", rozstaw: 150, kolor: "$tl", we: W("zanik", 1.1, 0.4) }),
      P(0, 1820, 1080, 100, "$tl", { we: W("odkryj-gora", 1.2, 0.5) }), T("opis", 540, 1846, { rozmiar: 36, font: "t", waga: 600, wyr: "srodek", we: W("zanik", 1.3, 0.5) }),
    ] }));

  return { SZABLONY, KATEGORIE, BAZA: [BW, BH], dodaj, znajdz, rysuj, czas, doAE, stan, zastepcze,
    ustawFabryke: (f) => { fabryka = f; }, pomoc: { W, P, K, TR, L, C, Z, T, TL, zd, tx, lg, CIEMNE, JASNE, BIALE } };
});
