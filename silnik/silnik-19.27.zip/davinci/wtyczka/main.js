/* Nada Studio: wtyczka Workflow Integration dla DaVinci Resolve Studio.
 * Działa jak mała apka wewnątrz DaVinci: okno panelu + dostęp do projektu przez WorkflowIntegration.node
 * (moduł z przykładów DaVinci, kopiowany przez instalator) + uruchamianie silnika Nada Studio (Python). */
"use strict";
const { app, BrowserWindow, ipcMain, dialog, shell } = require("electron");
const path = require("path");
const fs = require("fs");
const { spawn } = require("child_process");

const PLUGIN_ID = "pl.nadamedia.studio.davinci";
let WI = null, resolve = null, okno = null;

let cfg = {};
try { cfg = JSON.parse(fs.readFileSync(path.join(__dirname, "config.json"), "utf8")); } catch (e) {}

async function dawinczi() {
  if (resolve) return resolve;
  if (!WI) {
    try { WI = require("./WorkflowIntegration.node"); } catch (e) { throw new Error("Brak modułu WorkflowIntegration.node (zainstaluj panel ponownie w apce Nada Studio)."); }
  }
  const ok = await WI.Initialize(PLUGIN_ID);
  if (!ok) throw new Error("DaVinci nie pozwolił połączyć się z projektem (Workflow Integration działa w wersji Studio).");
  resolve = await WI.GetResolve();
  if (!resolve) throw new Error("Nie mam dostępu do DaVinci Resolve.");
  return resolve;
}

async function projekt() {
  const r = await dawinczi();
  const pm = await r.GetProjectManager();
  const p = await pm.GetCurrentProject();
  if (!p) throw new Error("Otwórz projekt w DaVinci.");
  return { r, p, mp: await p.GetMediaPool() };
}

function env() {
  const e = Object.assign({}, process.env, { PYTHONIOENCODING: "utf-8", PYTHONUTF8: "1" });
  const k = Object.keys(e).find((x) => x.toUpperCase() === "PATH") || "PATH";
  e[k] = (cfg.sciezki || []).concat([e[k] || ""]).join(path.delimiter);
  delete e.ELECTRON_RUN_AS_NODE;
  return e;
}

/* narzędzie silnika: zwraca JSON z ostatniego obiektu na wyjściu; postęp (POSTEP: ...) leci do okna */
function silnik(skrypt, args) {
  return new Promise((ok) => {
    if (!cfg.silnik || !cfg.python) return ok({ ok: false, blad: "Panel nie zna silnika. Zainstaluj go ponownie w apce Nada Studio (Ustawienia apki > Panele)." });
    const p = spawn(cfg.python, [path.join(cfg.silnik, "narzedzia", skrypt), ...args], { cwd: cfg.silnik, env: env(), windowsHide: true });
    let out = "", err = "";
    p.stdout.setEncoding("utf8"); p.stderr.setEncoding("utf8");
    p.stdout.on("data", (d) => (out += d));
    p.stderr.on("data", (d) => {
      err += d;
      for (const l of String(d).split(/\r?\n/)) if (l.startsWith("POSTEP: ") && okno) okno.webContents.send("postep", l.slice(8));
    });
    p.on("error", (e) => ok({ ok: false, blad: String(e) }));
    p.on("close", () => {
      const t = out.trim();
      try { ok(JSON.parse(t.slice(t.indexOf("{\n") >= 0 ? t.indexOf("{\n") : t.indexOf("{")))); } catch (e) { ok({ ok: false, blad: (err || t).slice(-800) }); }
    });
  });
}

/* ---------- działania na projekcie ---------- */
async function eksportujOs() {
  const { r, p } = await projekt();
  const tl = await p.GetCurrentTimeline();
  if (!tl) throw new Error("Otwórz oś czasu (timeline), którą chcesz przerobić.");
  const nazwa = await tl.GetName();
  const f = await silnik("davinci_most.py", ["folder", "--nazwa", nazwa]);
  if (!f.folder) throw new Error(f.blad || "Nie mam folderu roboczego.");
  const plik = path.join(f.folder, (nazwa || "os").replace(/[<>:"/\\|?*]/g, "-") + ".xml");
  const typ = r.EXPORT_FCP_7_XML !== undefined ? r.EXPORT_FCP_7_XML : await r.EXPORT_FCP_7_XML;
  const pod = r.EXPORT_NONE !== undefined ? r.EXPORT_NONE : await r.EXPORT_NONE;
  const ok = await tl.Export(plik, typ, pod);
  if (!ok || !fs.existsSync(plik)) throw new Error("DaVinci nie wyeksportował osi do XML. Zrób to ręcznie: Plik > Export > Timeline… > FCP 7 XML, i wskaż plik w panelu.");
  return { plik, nazwa };
}

async function importujOs(plik, nazwa) {
  const { p, mp } = await projekt();
  const tl = await mp.ImportTimelineFromFile(plik, { timelineName: nazwa || path.basename(plik, ".xml"), importSourceClips: true });
  if (!tl) throw new Error("DaVinci nie wczytał osi z pliku " + path.basename(plik) + ". Spróbuj ręcznie: Plik > Import > Timeline…");
  try { await p.SetCurrentTimeline(tl); } catch (e) {}
  await silnik("davinci_most.py", ["wczytane", "--plik", plik]);
  return { ok: true, nazwa: await tl.GetName() };
}

async function importujPliki(pliki) {
  const { mp } = await projekt();
  const w = await mp.ImportMedia(pliki.filter((x) => x && fs.existsSync(x)));
  return { ok: !!w, ile: w ? w.length || pliki.length : 0 };
}

/* ---------- wstawianie plików na oś ---------- */
const fpsOsi = async (tl) => { const f = parseFloat(await tl.GetSetting("timelineFrameRate")); return f > 0 ? f : 25; };
function tcNaKlatki(tc, fps) {
  const m = String(tc || "").match(/(\d+):(\d+):(\d+)[:;](\d+)/);
  if (!m) return null;
  const r = Math.round(fps);
  return ((+m[1] * 60 + +m[2]) * 60 + +m[3]) * r + +m[4];
}
async function infoOsi() {
  const { p } = await projekt();
  const tl = await p.GetCurrentTimeline();
  if (!tl) throw new Error("Otwórz oś czasu (timeline).");
  const szer = parseInt(await tl.GetSetting("timelineResolutionWidth"), 10) || 1920, wys = parseInt(await tl.GetSetting("timelineResolutionHeight"), 10) || 1080;
  const sciezki = async (typ) => { const n = await tl.GetTrackCount(typ); const l = []; for (let i = 1; i <= n; i++) l.push({ nr: i, nazwa: (await tl.GetTrackName(typ, i)) || (typ === "video" ? "V" : "A") + i }); return l; };
  return { ok: true, nazwa: await tl.GetName(), szer, wys, fps: await fpsOsi(tl), wideo: await sciezki("video"), audio: await sciezki("audio") };
}
/* folder w Media Pool (np. „Nada – animacje”); tworzy go, gdy go nie ma */
async function folderMP(mp, nazwa) {
  const root = await mp.GetRootFolder();
  let f = null;
  try { const sub = (await root.GetSubFolderList()) || []; for (const x of sub) if ((await x.GetName()) === nazwa) { f = x; break; } } catch (e) {}
  if (!f) f = await mp.AddSubFolder(root, nazwa);
  if (f) await mp.SetCurrentFolder(f);
  return f;
}
/* importuje plik do Media Pool i kładzie go na nowej ścieżce wideo: pod głowicą albo na początku osi */
async function wstawNaOs(plik, gdzie, bin) {
  if (!plik || !fs.existsSync(plik)) throw new Error("Brak pliku do wstawienia: " + plik);
  const { p, mp } = await projekt();
  const tl = await p.GetCurrentTimeline();
  if (!tl) throw new Error("Otwórz oś czasu (timeline).");
  await folderMP(mp, bin || "Nada Studio");
  const el = await mp.ImportMedia([plik]);
  const item = el && el[0];
  if (!item) throw new Error("DaVinci nie zaimportował pliku " + path.basename(plik));
  const fps = await fpsOsi(tl);
  let klatka = gdzie === "start" ? await tl.GetStartFrame() : tcNaKlatki(await tl.GetCurrentTimecode(), fps);
  if (klatka == null) klatka = await tl.GetStartFrame();
  let dl = parseInt(await item.GetClipProperty("Frames"), 10) || 0;
  let nr = null;
  try { if (await tl.AddTrack("video")) nr = await tl.GetTrackCount("video"); } catch (e) {}
  const opis = { mediaPoolItem: item, startFrame: 0, recordFrame: klatka };
  if (dl > 0) opis.endFrame = dl - 1;
  if (nr) opis.trackIndex = nr;
  let w = null;
  try { w = await mp.AppendToTimeline([opis]); } catch (e) {}
  if (!w || !w.length) return { ok: true, naOsi: false, uwaga: "Plik jest w Media Pool (folder „" + (bin || "Nada Studio") + "”). Przeciągnij go na oś: DaVinci nie pozwolił wstawić go automatycznie." };
  return { ok: true, naOsi: true, sciezka: nr ? "V" + nr : "oś", plik };
}
async function importDoBinu(pliki, bin) {
  const { mp } = await projekt();
  await folderMP(mp, bin);
  const w = await mp.ImportMedia(pliki.filter((x) => x && fs.existsSync(x)));
  return { ok: !!w, ile: w ? w.length : 0 };
}
const formatOsi = (i) => `${i.szer}x${i.wys}`;
const stempel = () => new Date().toISOString().slice(0, 19).replace(/[-:T]/g, "");

function jezyk() { try { return fs.readFileSync(path.join(cfg.silnik || "", "_system", "jezyk.txt"), "utf8").trim() === "en" ? "en" : "pl"; } catch (e) { return cfg.jezyk === "en" ? "en" : "pl"; } }

/* ---------- IPC z okna panelu ---------- */
function obsluga() {
  const h = (k, f) => ipcMain.handle(k, async (e, ...a) => { try { return await f(...a); } catch (err) { return { ok: false, blad: err.message || String(err) }; } });
  h("stan", async () => {
    let dv = null;
    try { const { p } = await projekt(); const tl = await p.GetCurrentTimeline(); dv = { projekt: await p.GetName(), os: tl ? await tl.GetName() : null }; } catch (e) { dv = { blad: e.message }; }
    return { ok: true, silnik: cfg.silnik || null, dv };
  });
  h("jezyk", () => jezyk());
  h("wyniki", () => silnik("davinci_most.py", ["wyniki"]));
  h("wczytaj", (plik, nazwa) => importujOs(plik, nazwa));
  h("tnij", async (opcje) => {
    const os = opcje.plik ? { plik: opcje.plik, nazwa: path.basename(opcje.plik, ".xml") } : await eksportujOs();
    const args = ["tnij", "--xml", os.plik, "--wpadki", opcje.wpadki || "wytnij"].concat(opcje.jezyk ? ["--jezyk", opcje.jezyk] : []).concat(opcje.bezCiszy ? ["--bez-ciszy"] : []);
    const w = await silnik("davinci_most.py", args);
    if (w.ok === false) return w;
    const out = { ok: true, wynik: w.wynik_ciecia, folder: w.folder };
    if (w.xml) out.os = await importujOs(w.xml, os.nazwa + (jezyk() === "en" ? " (cut)" : " (cięcie)"));
    if (w.srt) out.napisy = await importujPliki([w.srt]);
    return out;
  });
  h("napisy", async (opcje) => {
    const os = opcje.plik ? { plik: opcje.plik } : await eksportujOs();
    const w = await silnik("davinci_most.py", ["napisy", "--xml", os.plik].concat(opcje.jezyk ? ["--jezyk", opcje.jezyk] : []));
    if (w.ok === false) return w;
    return { ok: true, srt: w.srt, napisy: w.srt ? await importujPliki([w.srt]) : null };
  });
  // listy do panelu
  h("dane", async () => {
    const [k, s, m, an, sz] = await Promise.all([silnik("davinci_most.py", ["klienci"]), silnik("davinci_most.py", ["style"]), silnik("davinci_most.py", ["mozgi"]),
      silnik("animacje.py", ["lista"]), silnik("szablony.py", ["lista"])]);
    return { ok: true, klienci: k.klienci || [], style: s.style || [], mozgi: m, animacje: an, szablony: sz };
  });
  h("os", () => infoOsi());
  // animacje i szablony: render w silniku, potem na oś pod głowicą
  h("animacja", async (o) => {
    const i = await infoOsi();
    const f = await silnik("davinci_most.py", ["panel-folder", "--nazwa", "Animacje", "--klient", o.klient || ""]);
    if (!f.folder) throw new Error(f.blad || "Nie mam folderu na animacje.");
    const plik = path.join(f.folder, `${o.preset}_${stempel()}.mov`);
    const args = ["render", "--preset", o.preset, "--wyjscie", plik, "--parametry", JSON.stringify(o.parametry || {}), "--format", formatOsi(i), "--fps", String(Math.round(i.fps))];
    if (o.klient) args.push("--klient", o.klient);
    const r = await silnik("animacje.py", args);
    if (r.ok === false) return r;
    return Object.assign(await wstawNaOs(r.plik || plik, "glowica", "Nada – animacje"), { czas: r.czas });
  });
  h("szablon", async (o) => {
    const f = await silnik("davinci_most.py", ["panel-folder", "--nazwa", "Szablony", "--klient", o.klient || ""]);
    if (!f.folder) throw new Error(f.blad || "Nie mam folderu na szablony.");
    const plik = path.join(f.folder, `${o.szablon}_${stempel()}.mov`);
    const args = ["render", "--szablon", o.szablon, "--wyjscie", plik, "--wartosci", JSON.stringify(o.wartosci || {}), "--fps", String(Math.round((await infoOsi()).fps))];
    if (o.klient) args.push("--klient", o.klient);
    const r = await silnik("szablony.py", args);
    if (r.ok === false) return r;
    return wstawNaOs(r.plik || plik, "glowica", "Nada – szablony");
  });
  // napisy w stylu rolek: cała oś, jeden plik z przezroczystym tłem od początku osi
  h("napisy-styl", async (o) => {
    const i = await infoOsi();
    const os = await eksportujOs();
    const args = ["sekwencja", "--xml", os.plik, "--folder", path.dirname(os.plik), "--styl", JSON.stringify(o.styl || {}), "--W", String(i.szer), "--H", String(i.wys)];
    if (o.jezyk) args.push("--jezyk", o.jezyk);
    if (o.klient && fs.existsSync(path.join(cfg.silnik, o.klient, "fonty"))) args.push("--fonty", path.join(cfg.silnik, o.klient, "fonty"));
    const r = await silnik("napisy.py", args);
    if (r.ok === false) return r;
    const w = await wstawNaOs(r.mov, "start", "Nada – napisy");
    if (r.srt) await importDoBinu([r.srt], "Nada – napisy");
    return Object.assign(w, { slow: r.liczba_slow, srt: r.srt });
  });
  // aftermovie: zadanie w tle; gotowa oś pojawia się w Wyniki
  h("aftermovie", async (o) => {
    const os = await eksportujOs();
    return silnik("davinci_most.py", ["aftermovie", "--xml", os.plik, "--dane", JSON.stringify(o.dane || {}), "--mozg", o.mozg || "claude"]);
  });
  h("zlecenie", (id) => silnik("davinci_most.py", ["zlecenie", "--id", String(id)]));
  // stock Magnific
  h("stock-frazy", (opis) => silnik("stock.py", ["frazy", "--opis", String(opis || "")]));
  h("stock-szukaj", (o) => silnik("stock.py", ["szukaj", "--frazy", JSON.stringify(o.frazy || []), "--typ", o.typ || "wideo", "--orientacja", o.orientacja || "", "--strona", String(o.strona || 1), "--ile", "12"].concat(o.ai ? ["--z-ai"] : [])));
  h("stock-pobierz", async (x) => {
    const f = path.join(cfg.silnik, "stock", new Date().toISOString().slice(0, 10));
    const r = await silnik("stock.py", ["pobierz", "--id", String(x.id), "--typ", x.typ || "wideo", "--folder", f, "--nazwa", x.nazwa || "stock"]);
    if (r.ok === false) return r;
    const w = await importDoBinu([r.plik], "Nada – stock");
    return { ok: true, plik: r.plik, wMediaPool: w.ok, pobrane_dzis: r.pobrane_dzis };
  });
  h("otworz-url", (u) => { if (/^https:\/\//i.test(String(u))) shell.openExternal(String(u)); return { ok: true }; });
  // multicam podcastu
  h("multicam", async (o) => {
    const os = await eksportujOs();
    const w = await silnik("davinci_most.py", ["multicam", "--xml", os.plik, "--uklad", JSON.stringify(o.uklad || {}), "--nieuzyte", o.nieuzyte || "wylacz"].concat(o.dzwiek ? ["--dzwiek"] : []));
    if (w.ok === false || !w.xml) return w.ok === false ? w : { ok: false, blad: "Multicam nie zwrócił osi." };
    const im = await importujOs(w.xml, os.nazwa + " (multicam)");
    return Object.assign(w, { os: im });
  });
  h("wskaz-plik", async (rodzaj) => {
    const filtry = rodzaj === "obraz" ? [{ name: "Zdjęcia i filmy", extensions: ["jpg", "jpeg", "png", "webp", "mp4", "mov"] }] : [];
    const r = await dialog.showOpenDialog(okno, { filters: filtry, properties: ["openFile"] });
    return r.canceled ? null : r.filePaths[0];
  });
  h("wskaz", async () => {
    const r = await dialog.showOpenDialog(okno, { filters: [{ name: "Oś czasu (XML)", extensions: ["xml", "fcpxml"] }], properties: ["openFile"] });
    return r.canceled ? null : r.filePaths[0];
  });
  h("otworz", (p) => shell.openPath(p));
}

app.whenReady().then(() => {
  obsluga();
  okno = new BrowserWindow({ width: 420, height: 720, minWidth: 340, title: "Nada Studio", backgroundColor: "#0e0e0d", useContentSize: true,
    webPreferences: { preload: path.join(__dirname, "preload.js"), contextIsolation: true, nodeIntegration: false } });
  okno.on("close", () => app.quit());
  okno.setMenuBarVisibility(false);
  okno.loadFile(path.join(__dirname, "index.html"));
});
app.on("window-all-closed", () => app.quit());
