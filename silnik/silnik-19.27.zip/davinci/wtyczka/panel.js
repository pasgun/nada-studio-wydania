"use strict";
const $ = (id) => document.getElementById(id);
const esc = (s) => String(s == null ? "" : s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const N = window.nada;

/* wersja angielska: gdy w apce Nada Studio wybrany jest angielski (_system/jezyk.txt w silniku) */
let EN = null;
const SLOWNIK = {
  "Animacje": "Animations",
  "Szablony": "Templates",
  "Napisy": "Captions",
  "Stock": "Stock",
  "Multicam": "Multicam",
  "Aftermovie": "Aftermovie",
  "Klient": "Client",
  "bez klienta (kolory Nada Studio)": "no client (Nada Studio colours)",
  "Napisy, belki z nazwiskiem, liczniki i grafiki w kolorach i foncie klienta. Plik z przezroczystym tłem trafia na nową ścieżkę pod głowicą.": "Captions, name bars, counters and graphics in the client's colours and font. A file with a transparent background goes onto a new track at the playhead.",
  "Rodzaj": "Type",
  "Animacja": "Animation",
  "Czas (s)": "Duration (s)",
  "Wstaw pod głowicą": "Insert at playhead",
  "Szablon": "Template",
  "Styl": "Style",
  "Gotowe animowane plansze do rolek (pion 9:16): wpisujesz teksty, wybierasz zdjęcia, a gotowy plik trafia na nową ścieżkę pod głowicą.": "Ready animated reel boards (vertical 9:16): type the texts, pick photos, and the finished file goes onto a new track at the playhead.",
  "Zrób napisy na całą oś": "Make captions for the whole timeline",
  "Tytuł": "Title",
  "O czym ma być": "What it's about",
  "Długość (s)": "Length (s)",
  "Format": "Format",
  "Dynamika": "Pace",
  "Przejścia": "Transitions",
  "Muzyka": "Music",
  "Nastrój": "Mood",
  "Narracja": "Narration",
  "Plansza końcowa": "End card",
  "Przycisk / CTA": "Button / CTA",
  "napisy do wypowiedzi": "captions for speech",
  "Mózg": "Brain",
  "Zrób aftermovie": "Make aftermovie",
  "Czego szukasz": "What are you looking for",
  "Orientacja": "Orientation",
  "Szukaj": "Search",
  "Więcej wyników": "More results",
  "Pobierz": "Download",
  "W Media Pool ✓": "In Media Pool ✓",
  "Odczytaj ścieżki z otwartej osi": "Read tracks from the open timeline",
  "Plan ogólny": "Wide shot",
  "+ osoba": "+ person",
  "Usuń osobę": "Remove person",
  "Kamera": "Camera",
  "Mikrofon": "Microphone",
  "czysty, wyrównany dźwięk mikrofonów (AI ElevenLabs, kredyty)": "clean, levelled microphone audio (ElevenLabs AI, credits)",
  "Nieużyte ujęcia kamer": "Unused camera shots",
  "wyłącz (zostają na osi)": "disable (stay on the timeline)",
  "usuń": "delete",
  "Zrób multicam": "Make multicam",
  "brak planu ogólnego": "no wide shot",
  "Słowo w *gwiazdkach* dostaje kolor akcentu klienta.": "A word in *asterisks* gets the client's accent colour.",
  "Wybierz…": "Choose…",
  "brak (zostanie wzór)": "none (the sample stays)",
  "wideo": "video",
  "zdjęcia": "photos",
  "dowolna": "any",
  "pozioma": "horizontal",
  "pionowa": "vertical",
  "sama muzyka": "music only",
  "wywiady z materiału": "interviews from footage",
  "lektor ElevenLabs": "ElevenLabs voice-over",
  "lektor + wywiady": "voice-over + interviews",
  "spokojna": "calm",
  "średnia": "medium",
  "dynamiczna": "dynamic",
  "mieszane": "mixed",
  "tylko cięcia": "cuts only",
  "subtelne": "subtle",
  "dynamiczne": "dynamic",
  "z osi czasu": "from the timeline",
  "z folderu muzyka/": "from the muzyka/ folder",
  "poziom 16:9": "horizontal 16:9",
  "pion 9:16": "vertical 9:16",
  "oba": "both",
  "Renderuję animację (kilka sekund)…": "Rendering the animation (a few seconds)…",
  "Renderuję szablon (kilkanaście sekund)…": "Rendering the template (about 15 seconds)…",
  "Dobieram frazy…": "Picking search phrases…",
  "Pobieram…": "Downloading…",
  "Eksportuję oś i uruchamiam zadanie…": "Exporting the timeline and starting the task…",
  "Eksportuję oś i słucham mikrofonów (kilka minut na godzinę nagrania)…": "Exporting the timeline and listening to the mics (a few minutes per hour of recording)…",
  "Eksportuję oś, rozpoznaję mowę i robię napisy (kilka minut na godzinę materiału)…": "Exporting the timeline, recognising speech and making captions (a few minutes per hour of footage)…",
  "Zadanie ruszyło. Postęp widać niżej i w Console w Studio; gotowa oś pojawi się w zakładce Wyniki.": "The task has started. Progress is shown below and in the Studio Console; the finished timeline will appear in the Results tab.",
  "Wpisz, czego szukasz.": "Type what you're looking for.",
  "Każda osoba musi mieć inną kamerę.": "Each person needs a different camera.",
  "Każda osoba musi mieć inny mikrofon.": "Each person needs a different microphone.",
  "Plan ogólny nie może być kamerą jednej z osób.": "The wide shot can't be one person's camera.",
  "Gotowe: animacja jest na ścieżce ": "Done: the animation is on track ",
  "Gotowe: szablon jest na ścieżce ": "Done: the template is on track ",
  "Wyniki": "Results", "Cięcie": "Cut", "Napisy": "Captions",
  "W DaVinci": "In DaVinci",
  "Wpadki i powtórzenia w otwartej osi czasu: silnik czyta, co mówisz, i wycina zdania powtórzone albo przerwane (tego DaVinci sam nie robi). Oryginał zostaje, powstaje nowa oś z cięciami i markerami. Samą ciszę wytnie też IntelliCut w DaVinci, ale tutaj możesz zrobić jedno i drugie naraz.": "Flubs and retakes in the open timeline: the engine reads what is said and cuts repeated or broken-off sentences (DaVinci doesn't do this itself). The original stays; a new timeline with cuts and markers is created. IntelliCut in DaVinci also removes silence, but here you can do both at once.",
  "nie tnij ciszy (tylko wpadki; ciszę wytnę IntelliCut w DaVinci)": "don't cut silences (flubs only; I'll cut silence with IntelliCut in DaVinci)",
  "Tych rzeczy panel nie dubluje, bo DaVinci Resolve Studio robi je sam:": "The panel doesn't duplicate these, because DaVinci Resolve Studio does them itself:",
  "Napisy z mowy:": "Captions from speech:", "Timeline > Create Subtitles from Audio (w wersji 20 także animowane napisy).": "Timeline > Create Subtitles from Audio (version 20 also has animated subtitles).",
  "Wycinanie ciszy:": "Removing silence:", "IntelliCut na stronie Fairlight.": "IntelliCut on the Fairlight page.",
  "Miks i poziomy dźwięku:": "Mix and audio levels:", "AI Audio Assistant na stronie Fairlight.": "AI Audio Assistant on the Fairlight page.",
  "Multicam na mówiącego:": "Multicam on the speaker:", "Multicam SmartSwitch.": "Multicam SmartSwitch.",
  "Czysty głos:": "Clean voice:", "Voice Isolation w Inspectorze klipu.": "Voice Isolation in the clip Inspector.",
  "Z Nada Studio bierzesz do DaVinci gotowe osie z zadań (zakładka Wyniki): rolki, aftermovie, cięcia, z muzyką i animacjami. W darmowej wersji DaVinci, która tych funkcji AI nie ma, napisy SRT i cięcie robią skrypty: Workspace > Scripts > Nada Studio.": "From Nada Studio you bring finished task timelines into DaVinci (Results tab): reels, aftermovies, cuts, with music and animations. In the free version of DaVinci, which lacks these AI features, SRT captions and cutting are done by scripts: Workspace > Scripts > Nada Studio.",

  "Osie czasu z zadań Nada Studio (rolki, aftermovie, cięcia). Kliknij, żeby wczytać do otwartego projektu.": "Timelines from Nada Studio tasks (reels, aftermovies, cuts). Click to load one into the open project.",
  "Odśwież": "Refresh", "Wczytaj plik XML…": "Load XML file…",
  "Cięcie ciszy i wpadek w otwartej osi czasu (jak w panelu Premiere). Oryginał zostaje, powstaje nowa oś z cięciami i markerami, a napisy SRT trafiają do Media Pool.": "Cuts silences and flubs in the open timeline (like the Premiere panel). The original stays; a new timeline with cuts and markers is created, and SRT captions go to the Media Pool.",
  "Wpadki": "Flubs", "wytnij": "cut", "tylko oznacz markerem": "only mark with a marker", "pomiń (sama cisza)": "skip (silence only)",
  "Język": "Language", "wykryj sam": "auto-detect", "polski": "Polish", "angielski": "English", "niemiecki": "German", "szwedzki": "Swedish",
  "nie tnij ciszy (tylko wpadki)": "don't cut silences (flubs only)", "Tnij otwartą oś": "Cut the open timeline", "…albo wskaż plik XML": "…or choose an XML file",
  "Napisy SRT do otwartej osi (rozpoznawanie mowy silnikiem Nada Studio). Plik trafi do Media Pool: przeciągnij go na ścieżkę napisów.": "SRT captions for the open timeline (speech recognition by the Nada Studio engine). The file goes to the Media Pool: drag it onto a subtitle track.",
  "Zrób napisy": "Make captions", "NOWA": "NEW",
  "Brak osi z ostatnich 30 dni. Zadania z Nada Studio pojawią się tu, gdy się skończą.": "No timelines from the last 30 days. Nada Studio tasks appear here when they finish.",
  "Panel nie zna silnika Nada Studio. Zainstaluj panel ponownie w apce (Ustawienia apki > Panele).": "The panel doesn't know where the Nada Studio engine is. Reinstall the panel in the app (App settings > Panels).",
  "Panel nie zna silnika. Zainstaluj go ponownie w apce Nada Studio (Ustawienia apki > Panele).": "The panel doesn't know where the engine is. Reinstall it in the Nada Studio app (App settings > Panels).",
  "Eksportuję oś i analizuję mowę (to potrwa: kilka minut na godzinę materiału)…": "Exporting the timeline and analysing speech (takes a few minutes per hour of footage)…",
  "Eksportuję oś i rozpoznaję mowę…": "Exporting the timeline and recognising speech…", "Nie wyszło.": "It didn't work.",
  "Otwórz projekt w DaVinci.": "Open a project in DaVinci.",
  "Otwórz oś czasu (timeline), którą chcesz przerobić.": "Open the timeline you want to process.",
  "Nie mam dostępu do DaVinci Resolve.": "No access to DaVinci Resolve.",
  "Brak modułu WorkflowIntegration.node (zainstaluj panel ponownie w apce Nada Studio).": "The WorkflowIntegration.node module is missing (reinstall the panel in the Nada Studio app).",
  "DaVinci nie pozwolił połączyć się z projektem (Workflow Integration działa w wersji Studio).": "DaVinci didn't allow connecting to the project (Workflow Integration works in the Studio version).",
  "DaVinci nie wyeksportował osi do XML. Zrób to ręcznie: Plik > Export > Timeline… > FCP 7 XML, i wskaż plik w panelu.": "DaVinci didn't export the timeline to XML. Do it manually: File > Export > Timeline… > FCP 7 XML, and choose the file in the panel.",
};
const POCZATKI = [["Gotowe: animacja jest na ścieżce ", "Done: the animation is on track "], ["Gotowe: szablon jest na ścieżce ", "Done: the template is on track "], ["Szukam w Magnific: ", "Searching Magnific: "], ["Wyniki: ", "Results: "], [". Najedź na kafelek, żeby obejrzeć.", ". Hover over a tile to preview."], ["Pobrane: ", "Downloaded: "], [" jest w Media Pool (folder „Nada – stock”).", " is in the Media Pool (“Nada – stock” folder)."], ["Gotowe: nowa oś „", "Done: new timeline “"], ["Gotowe: napisy (", "Done: captions ("], [" słów) są na ścieżce ", " words) are on track "], [", od początku osi.", ", from the start of the timeline."], ["Oś „", "Timeline “"], ["”: ", "”: "], [" ścieżek wideo, ", " video tracks, "], [" audio.", " audio."], ["Wczytuję „", "Loading “"], ["Wczytano oś: ", "Timeline loaded: "], ["Gotowe: napisy SRT są w Media Pool.", "Done: SRT captions are in the Media Pool."], ["Gotowe: nowa oś „", "Done: new timeline “"],
  ["\nByło ", "\nWas "], [" s, jest ", " s, now "], [" s, cięć: ", " s, cuts: "], [", markerów: ", ", markers: "], ["\nNapisy SRT są w Media Pool.", "\nSRT captions are in the Media Pool."], ["\nUwagi: ", "\nNotes: "], ["”…", "”…"], ["”.", "”."],
  ["DaVinci nie wczytał osi z pliku ", "DaVinci didn't load the timeline from "], [". Spróbuj ręcznie: Plik > Import > Timeline…", ". Try manually: File > Import > Timeline…"]];
function tr(t) {
  if (!EN || !t) return t;
  const r = t.trim();
  if (SLOWNIK[r]) return t.replace(r, SLOWNIK[r]);
  let w = t;
  for (const [pl, en] of POCZATKI) w = w.split(pl).join(en);
  return w;
}
function przetlumaczStrone() {
  const w = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
  let n;
  while ((n = w.nextNode())) { const r = n.nodeValue.trim(); if (r && SLOWNIK[r]) n.nodeValue = n.nodeValue.replace(r, SLOWNIK[r]); }
}
N.jezyk().then((j) => { if (j !== "en") return; EN = true; document.documentElement.lang = "en"; przetlumaczStrone(); let t0 = 0; new MutationObserver(() => { clearTimeout(t0); t0 = setTimeout(przetlumaczStrone, 50); }).observe(document.body, { childList: true, subtree: true }); }).catch(() => {});

function stan(t, klasa) { const s = $("stan"); t = tr(t); s.hidden = !t; s.className = "stan " + (klasa || ""); s.textContent = t || ""; }
N.naPostep((t) => stan(t + "…"));

document.querySelectorAll("nav button").forEach((b) => (b.onclick = () => {
  document.querySelectorAll("nav button").forEach((x) => x.classList.toggle("wybrana", x === b));
  document.querySelectorAll("main > section").forEach((s) => (s.hidden = s.id !== "zak-" + b.dataset.zak));
  stan("");
}));

async function zajety(przycisk, f) {
  document.querySelectorAll("button").forEach((b) => (b.disabled = true));
  try { await f(); } finally { document.querySelectorAll("button").forEach((b) => (b.disabled = false)); }
}

async function odswiezStan() {
  const s = await N.stan();
  $("projekt").textContent = s.dv && s.dv.projekt ? s.dv.projekt + (s.dv.os ? " · " + s.dv.os : "") : s.dv && s.dv.blad ? s.dv.blad : "";
  if (!s.silnik) stan("Panel nie zna silnika Nada Studio. Zainstaluj panel ponownie w apce (Ustawienia apki > Panele).", "zle");
}

async function rysujWyniki() {
  const w = await N.wyniki();
  const l = (w && w.osie) || [];
  $("lista").innerHTML = l.length ? l.map((o, i) => `<div class="poz" data-i="${i}"><b title="${esc(o.plik)}">${esc(o.tytul)}</b>${o.nowa ? '<span class="nowa">NOWA</span>' : "<span></span>"}<small>${esc(new Date(o.kiedy * 1000).toLocaleString(EN ? "en-GB" : "pl-PL", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" }))}</small></div>`).join("")
    : '<div class="pusto">Brak osi z ostatnich 30 dni. Zadania z Nada Studio pojawią się tu, gdy się skończą.</div>';
  $("lista").querySelectorAll(".poz").forEach((el) => (el.onclick = () => zajety(null, async () => {
    const o = l[Number(el.dataset.i)];
    stan("Wczytuję „" + o.tytul + "”…");
    const r = await N.wczytaj(o.plik, o.tytul.split(" / ").slice(-2).join(" - "));
    stan(r.ok ? "Wczytano oś: " + r.nazwa : r.blad, r.ok ? "ok" : "zle");
    rysujWyniki();
  })));
  if (w && w.ok === false) stan(w.blad, "zle");
}

$("odswiez").onclick = () => rysujWyniki();
$("wskazWynik").onclick = async () => {
  const p = await N.wskaz();
  if (!p) return;
  zajety(null, async () => { const r = await N.wczytaj(p); stan(r.ok ? "Wczytano oś: " + r.nazwa : r.blad, r.ok ? "ok" : "zle"); });
};

async function tnij(plik) {
  stan("Eksportuję oś i analizuję mowę (to potrwa: kilka minut na godzinę materiału)…");
  const r = await N.tnij({ plik, wpadki: $("wpadki").value, jezyk: $("jezyk").value, bezCiszy: $("bezCiszy").checked });
  if (!r.ok) return stan(r.blad || "Nie wyszło.", "zle");
  const w = r.wynik || {};
  stan(`Gotowe: nowa oś „${(r.os && r.os.nazwa) || ""}”.\nByło ${w.bylo_s ?? "?"} s, jest ${w.jest_s ?? "?"} s, cięć: ${w.ciec ?? "?"}, markerów: ${w.markerow ?? "?"}.` + (r.napisy ? "\nNapisy SRT są w Media Pool." : "") + (w.uwagi && w.uwagi.length ? "\nUwagi: " + w.uwagi.join("; ") : ""), "ok");
}
$("tnij").onclick = () => zajety(null, () => tnij(null));
$("tnijPlik").onclick = async () => { const p = await N.wskaz(); if (p) zajety(null, () => tnij(p)); };
if ($("napisy")) $("napisy").onclick = () => zajety(null, async () => {
  stan("Eksportuję oś i rozpoznaję mowę…");
  const r = await N.napisy({ jezyk: $("jezykN").value });
  stan(r.ok ? "Gotowe: napisy SRT są w Media Pool.\n" + (r.srt || "") : r.blad, r.ok ? "ok" : "zle");
});

/* ---------- wspólne: klient, listy z silnika ---------- */
const PAM = (k, d) => { try { const v = localStorage.getItem("nada-dv-" + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } };
const ZAP = (k, v) => { try { localStorage.setItem("nada-dv-" + k, JSON.stringify(v)); } catch (e) {} };
let DANE = null;
const klient = () => $("klient").value;
async function wczytajDane() {
  const d = await N.dane();
  if (d.ok === false) { stan(d.blad, "zle"); return; }
  DANE = d;
  $("klient").innerHTML = '<option value="">bez klienta (kolory Nada Studio)</option>' + (d.klienci || []).map((k) => `<option value="${esc(k.folder)}">${esc(k.nazwa)}</option>`).join("");
  $("klient").value = PAM("klient", "");
  rysujAnimacje(); rysujSzablony(); rysujStyle(); rysujMozgi();
}
$("klient").onchange = () => ZAP("klient", klient());
const wynikWstawienia = (r, co) => r.ok === false ? stan(r.blad || "Nie wyszło.", "zle") : stan(r.naOsi ? `Gotowe: ${co} jest na ścieżce ${r.sciezka}.` : (r.uwaga || "Gotowe."), "ok");
const etykieta = (id) => ({ tekst: "Tekst", tekst2: "Drugi tekst / podpis", liczba: "Liczba", przed: "Przed liczbą", po: "Po liczbie", od: "Od (liczba startowa)", lista: "Lista (jedna pozycja w linii)", emoji: "Emoji" })[id];

/* ---------- animacje ---------- */
function rysujAnimacje() {
  const a = (DANE && DANE.animacje) || {}, kat = a.kategorie || [], pres = a.presety || [];
  $("anKat").innerHTML = kat.filter((k) => pres.some((p) => p.kat === k.id)).map((k) => `<option value="${esc(k.id)}">${esc(k.nazwa)}</option>`).join("");
  $("anKat").value = PAM("anKat", $("anKat").value) || $("anKat").value;
  const lista = () => {
    $("anPreset").innerHTML = pres.filter((p) => p.kat === $("anKat").value).map((p) => `<option value="${esc(p.id)}">${esc(p.nazwa)}</option>`).join("");
    pola();
  };
  const pola = () => {
    const p = pres.find((x) => x.id === $("anPreset").value); if (!p) { $("anPola").innerHTML = ""; return; }
    $("anCzas").value = p.czas || 3;
    $("anPola").innerHTML = (p.pola || []).filter((f) => etykieta(f)).map((f) => f === "lista"
      ? `<label class="pole">${esc(etykieta(f))}<textarea data-an="${f}" rows="3">${esc(Array.isArray((p.przyklad || {})[f]) ? p.przyklad[f].join("\n") : (p.przyklad || {})[f] || "")}</textarea></label>`
      : `<label class="pole">${esc(etykieta(f))}<input type="text" data-an="${f}" value="${esc((p.przyklad || {})[f] != null ? p.przyklad[f] : "")}"></label>`).join("")
      + ((p.pola || []).includes("tekst") ? '<p class="opis">Słowo w *gwiazdkach* dostaje kolor akcentu klienta.</p>' : "");
  };
  $("anKat").onchange = () => { ZAP("anKat", $("anKat").value); lista(); };
  $("anPreset").onchange = pola;
  lista();
}
$("anWstaw").onclick = () => zajety(null, async () => {
  const par = { czas: +$("anCzas").value || 3 };
  document.querySelectorAll("[data-an]").forEach((el) => { const v = el.value; par[el.dataset.an] = el.dataset.an === "lista" ? v.split(/\r?\n/).filter(Boolean).join("\n") : el.dataset.an === "liczba" || el.dataset.an === "od" ? (parseFloat(String(v).replace(",", ".")) || 0) : v; });
  stan("Renderuję animację (kilka sekund)…");
  const r = await N.animacja({ preset: $("anPreset").value, parametry: par, klient: klient() });
  wynikWstawienia(r, "animacja");
});

/* ---------- szablony ---------- */
const SZ_PLIKI = {};
function rysujSzablony() {
  const s = (DANE && DANE.szablony) || {}, kat = s.kategorie || [], lst = s.szablony || [];
  $("szKat").innerHTML = kat.filter((k) => lst.some((x) => x.kat === k.id)).map((k) => `<option value="${esc(k.id)}">${esc(k.nazwa)}</option>`).join("");
  const lista = () => { $("szSzablon").innerHTML = lst.filter((x) => x.kat === $("szKat").value).map((x) => `<option value="${esc(x.id)}">${esc(x.nazwa)}</option>`).join(""); pola(); };
  const pola = () => {
    const x = lst.find((y) => y.id === $("szSzablon").value); if (!x) { $("szPola").innerHTML = ""; return; }
    $("szPola").innerHTML = (x.pola || []).map((f) => f.typ === "zdjecie"
      ? `<div class="pole">${esc(f.etykieta)}<div class="plik-wiersz"><button type="button" data-sz-plik="${esc(f.id)}">Wybierz…</button><span data-sz-nazwa="${esc(f.id)}">${SZ_PLIKI[f.id] ? esc(SZ_PLIKI[f.id].split(/[\\/]/).pop()) : "brak (zostanie wzór)"}</span></div></div>`
      : `<label class="pole">${esc(f.etykieta)}${(f.wiersze || 1) > 1 ? `<textarea data-sz="${esc(f.id)}" rows="${f.wiersze}">${esc(f.dom || "")}</textarea>` : `<input type="text" data-sz="${esc(f.id)}" value="${esc(f.dom || "")}">`}</label>`).join("");
    document.querySelectorAll("[data-sz-plik]").forEach((b) => (b.onclick = async () => { const p = await N.wskazPlik("obraz"); if (p) { SZ_PLIKI[b.dataset.szPlik] = p; document.querySelector(`[data-sz-nazwa="${b.dataset.szPlik}"]`).textContent = p.split(/[\\/]/).pop(); } }));
  };
  $("szKat").onchange = lista; $("szSzablon").onchange = pola;
  lista();
}
$("szWstaw").onclick = () => zajety(null, async () => {
  const x = ((DANE && DANE.szablony && DANE.szablony.szablony) || []).find((y) => y.id === $("szSzablon").value); if (!x) return;
  const w = {};
  document.querySelectorAll("[data-sz]").forEach((el) => (w[el.dataset.sz] = el.value));
  (x.pola || []).filter((f) => f.typ === "zdjecie" && SZ_PLIKI[f.id]).forEach((f) => (w[f.id] = SZ_PLIKI[f.id]));
  stan("Renderuję szablon (kilkanaście sekund)…");
  wynikWstawienia(await N.szablon({ szablon: x.id, wartosci: w, klient: klient() }), "szablon");
});

/* ---------- napisy w stylu rolek ---------- */
function rysujStyle() {
  const st = (DANE && DANE.style) || [], grupy = [...new Set(st.map((s) => s.grupa || ""))];
  $("npStyl").innerHTML = grupy.map((g) => `<optgroup label="${esc(g || "Style")}">${st.filter((s) => (s.grupa || "") === g).map((s) => `<option value="${esc(s.id)}">${esc(s.nazwa)}</option>`).join("")}</optgroup>`).join("");
  $("npStyl").value = PAM("npStyl", $("npStyl").value) || $("npStyl").value;
  $("npStyl").onchange = () => ZAP("npStyl", $("npStyl").value);
}
$("npZrob").onclick = () => zajety(null, async () => {
  const s = ((DANE && DANE.style) || []).find((x) => x.id === $("npStyl").value) || { styl: {} };
  stan("Eksportuję oś, rozpoznaję mowę i robię napisy (kilka minut na godzinę materiału)…");
  const r = await N.napisyStyl({ styl: s.styl, jezyk: $("npJezyk").value, klient: klient() });
  if (r.ok === false) return stan(r.blad || "Nie wyszło.", "zle");
  stan((r.naOsi ? `Gotowe: napisy (${r.slow || "?"} słów) są na ścieżce ${r.sciezka}, od początku osi.` : r.uwaga) + (r.srt ? "\nPlik SRT jest w Media Pool." : ""), "ok");
});

/* ---------- aftermovie ---------- */
function rysujMozgi() {
  const m = (DANE && DANE.mozgi) || {};
  const l = [["claude", "Claude"], ["gemini", "Gemini"]].filter(([id]) => m[id] !== false).concat((m.inne || []).map((x) => [x.id, x.nazwa]));
  $("amMozg").innerHTML = l.map(([id, n]) => `<option value="${esc(id)}">${esc(n)}</option>`).join("");
  $("amMozg").value = PAM("amMozg", "claude");
}
let amTimer = 0;
function amSledz(id) {
  clearInterval(amTimer);
  const pas = $("amPostep"); pas.hidden = false;
  const krok = async () => {
    const z = await N.zlecenie(id);
    if (z.ok === false) return;
    pas.querySelector("i").style.setProperty("--p", Math.round((z.ulamek || 0) * 100) + "%");
    pas.querySelector("span").textContent = z.stan === "gotowe" ? "Gotowe: oś jest w zakładce Wyniki" : z.stan === "blad" ? "Błąd: szczegóły w Console w Studio" : z.stan === "czeka" ? "Czeka na Ciebie: odpowiedz w Console w Studio" : (z.tekst || z.ostatnio || "Pracuje…");
    if (["gotowe", "blad", "przerwane", "zawieszone"].includes(z.stan)) { clearInterval(amTimer); if (z.stan === "gotowe") rysujWyniki(); }
  };
  krok(); amTimer = setInterval(krok, 8000);
}
$("amStart").onclick = () => zajety(null, async () => {
  const opt = $("klient").selectedOptions[0];
  const dane = { tytul: $("amTytul").value.trim(), brief: $("amBrief").value.trim(), dlugosc: +$("amDlugosc").value || 60,
    orientacje: $("amOrient").value === "oba" ? ["poziom", "pion"] : [$("amOrient").value], dynamika: $("amDynamika").value, przejscia: $("amPrzejscia").value,
    muzyka: { zrodlo: $("amMuzyka").value, nastroj: $("amNastroj").value }, narracja: { tryb: $("amNarracja").value }, napisy: $("amNapisy").checked,
    plansza: { tekst: $("amPlansza").value, przycisk: $("amCta").value }, klient: klient() ? { nazwa: opt ? opt.textContent : "", folder: klient() } : null };
  ZAP("amMozg", $("amMozg").value);
  stan("Eksportuję oś i uruchamiam zadanie…");
  const r = await N.aftermovie({ dane, mozg: $("amMozg").value });
  if (r.ok === false) return stan(r.blad || "Nie wyszło.", "zle");
  ZAP("amId", r.id);
  stan("Zadanie ruszyło. Postęp widać niżej i w Console w Studio; gotowa oś pojawi się w zakładce Wyniki.", "ok");
  amSledz(r.id);
});

/* ---------- stock ---------- */
const ST = { frazy: [], wyniki: [], strona: 1 };
function stFrazy() {
  $("stFrazy").innerHTML = ST.frazy.map((f, i) => `<button data-i="${i}" aria-pressed="${f.on}">${esc(f.t)}</button>`).join("");
  $("stFrazy").querySelectorAll("button").forEach((b) => (b.onclick = () => { const f = ST.frazy[+b.dataset.i]; f.on = !f.on; b.setAttribute("aria-pressed", String(f.on)); }));
}
function stGaleria() {
  $("stGaleria").innerHTML = ST.wyniki.map((x, i) => `<div class="karta"><div class="ekran" data-i="${i}" style="background-image:url('${esc(x.miniatura || "")}')"></div><p title="${esc(x.nazwa || "")}">${esc(x.nazwa || x.fraza || "")}</p><button data-pob="${i}">${x.pobrany ? "W Media Pool ✓" : "Pobierz"}</button></div>`).join("");
  $("stGaleria").querySelectorAll(".ekran").forEach((ek) => {
    const x = ST.wyniki[+ek.dataset.i];
    ek.onmouseenter = () => { if (!x.podglad || ek.querySelector("video")) return; const v = document.createElement("video"); v.muted = true; v.loop = true; v.autoplay = true; v.src = x.podglad; v.onerror = () => v.remove(); ek.appendChild(v); };
    ek.onmouseleave = () => { const v = ek.querySelector("video"); if (v) v.remove(); };
    ek.onclick = () => x.strona && N.otworzUrl(x.strona);
  });
  $("stGaleria").querySelectorAll("[data-pob]").forEach((b) => (b.onclick = () => zajety(null, async () => {
    const x = ST.wyniki[+b.dataset.pob];
    stan("Pobieram…");
    const r = await N.stockPobierz({ id: x.id, typ: x.typ || $("stTyp").value, nazwa: x.fraza || x.nazwa || "stock" });
    if (r.ok === false) return stan(r.blad || "Nie wyszło.", "zle");
    x.pobrany = true; stGaleria();
    stan(`Pobrane: ${r.plik.split(/[\\/]/).pop()} jest w Media Pool (folder „Nada – stock”).` + (r.pobrane_dzis != null ? ` Dziś pobrano: ${r.pobrane_dzis}/100.` : ""), "ok");
  })));
  $("stWiecej").hidden = !ST.wyniki.length;
}
async function stSzukaj(odNowa) {
  const akt = ST.frazy.filter((f) => f.on).map((f) => f.t).slice(0, 6);
  if (!akt.length) return stan("Wpisz, czego szukasz.", "zle");
  if (odNowa) { ST.strona = 1; ST.wyniki = []; }
  stan("Szukam w Magnific: " + akt.join(", ") + "…");
  const r = await N.stockSzukaj({ frazy: akt, typ: $("stTyp").value, orientacja: $("stOrient").value, strona: ST.strona });
  if (r.ok === false) return stan(r.blad || "Nie wyszło.", "zle");
  const znane = new Set(ST.wyniki.map((w) => String(w.id)));
  ST.wyniki.push(...(r.wyniki || []).filter((w) => !znane.has(String(w.id))));
  stFrazy(); stGaleria();
  stan(ST.wyniki.length ? `Wyniki: ${ST.wyniki.length}. Najedź na kafelek, żeby obejrzeć.` : "Nic nie znalazłem. Zmień opis albo orientację.", ST.wyniki.length ? "" : "zle");
}
$("stSzukaj").onclick = () => zajety(null, async () => {
  const opis = $("stOpis").value.trim(); if (!opis) return stan("Wpisz, czego szukasz.", "zle");
  stan("Dobieram frazy…");
  const r = await N.stockFrazy(opis);
  ST.frazy = ((r && r.ok !== false && r.frazy) || [opis]).map((t) => ({ t, on: true }));
  await stSzukaj(true);
});
$("stWiecej").onclick = () => zajety(null, async () => { ST.strona++; await stSzukaj(false); });

/* ---------- multicam ---------- */
let MC = { wideo: [], audio: [], osoby: PAM("mcOsoby", [{ nazwa: "Prowadzący", kamera: 2, mikrofon: 1 }, { nazwa: "Gość", kamera: 3, mikrofon: 2 }]) };
function mcRysuj() {
  const opcje = (l, v, pusta) => (pusta ? `<option value="0">${pusta}</option>` : "") + l.map((s) => `<option value="${s.nr}" ${+v === s.nr ? "selected" : ""}>${esc(s.nazwa)}</option>`).join("");
  $("mcOgolna").innerHTML = opcje(MC.wideo, PAM("mcOgolna", 1), "brak planu ogólnego");
  $("mcOsoby").innerHTML = MC.osoby.map((o, i) => `<div class="osoba"><label class="pole">Osoba ${i + 1}<input type="text" data-mc="nazwa" data-i="${i}" value="${esc(o.nazwa)}"></label>
    <div class="dwa"><label class="pole">Kamera <select data-mc="kamera" data-i="${i}">${opcje(MC.wideo, o.kamera)}</select></label><label class="pole">Mikrofon <select data-mc="mikrofon" data-i="${i}">${opcje(MC.audio, o.mikrofon)}</select></label></div>
    ${MC.osoby.length > 2 ? `<button type="button" data-mc-usun="${i}">Usuń osobę</button>` : ""}</div>`).join("");
  document.querySelectorAll("[data-mc]").forEach((el) => (el.onchange = () => { const o = MC.osoby[+el.dataset.i]; o[el.dataset.mc] = el.dataset.mc === "nazwa" ? el.value : +el.value; ZAP("mcOsoby", MC.osoby); }));
  document.querySelectorAll("[data-mc-usun]").forEach((b) => (b.onclick = () => { MC.osoby.splice(+b.dataset.mcUsun, 1); ZAP("mcOsoby", MC.osoby); mcRysuj(); }));
  $("mcDodaj").hidden = MC.osoby.length >= 4;
}
async function mcSciezki() {
  const i = await N.os();
  if (i.ok === false) return stan(i.blad, "zle");
  MC.wideo = i.wideo || []; MC.audio = i.audio || [];
  mcRysuj();
  stan(`Oś „${i.nazwa}”: ${MC.wideo.length} ścieżek wideo, ${MC.audio.length} audio.`);
}
$("mcOdswiez").onclick = () => zajety(null, mcSciezki);
$("mcOgolna").onchange = () => ZAP("mcOgolna", +$("mcOgolna").value);
$("mcDodaj").onclick = () => { MC.osoby.push({ nazwa: "Osoba " + (MC.osoby.length + 1), kamera: (MC.wideo[MC.osoby.length + 1] || {}).nr || 1, mikrofon: (MC.audio[MC.osoby.length] || {}).nr || 1 }); ZAP("mcOsoby", MC.osoby); mcRysuj(); };
$("mcStart").onclick = () => zajety(null, async () => {
  const uklad = { ogolna: +$("mcOgolna").value || 0, osoby: MC.osoby.map((o) => ({ nazwa: o.nazwa || "Osoba", kamera: +o.kamera, mikrofon: +o.mikrofon })) };
  const kam = uklad.osoby.map((o) => o.kamera), mik = uklad.osoby.map((o) => o.mikrofon);
  if (new Set(kam).size !== kam.length) return stan("Każda osoba musi mieć inną kamerę.", "zle");
  if (new Set(mik).size !== mik.length) return stan("Każda osoba musi mieć inny mikrofon.", "zle");
  if (uklad.ogolna && kam.includes(uklad.ogolna)) return stan("Plan ogólny nie może być kamerą jednej z osób.", "zle");
  stan("Eksportuję oś i słucham mikrofonów (kilka minut na godzinę nagrania)…");
  const r = await N.multicam({ uklad, dzwiek: $("mcDzwiek").checked, nieuzyte: $("mcNieuzyte").value });
  if (r.ok === false) return stan(r.blad || "Nie wyszło.", "zle");
  stan(`Gotowe: nowa oś „${(r.os && r.os.nazwa) || ""}”. Ujęć: ${r.ujec ?? "?"}, średnio ${r.srednie_ujecie_s ?? "?"} s.` + ((r.uwagi || []).length ? "\nUwagi: " + r.uwagi.join("; ") : ""), "ok");
});
document.querySelector('nav button[data-zak="multicam"]').addEventListener("click", () => { if (!MC.wideo.length) mcSciezki().catch(() => {}); });

odswiezStan();
rysujWyniki();
wczytajDane().catch((e) => stan(String(e.message || e), "zle"));
mcRysuj();
const amOst = PAM("amId", null); if (amOst) amSledz(amOst);
