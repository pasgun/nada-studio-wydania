-- Nada Studio: cięcie ciszy i wpadek w otwartej osi. Powstaje nowa oś (oryginał zostaje) i napisy SRT w Media Pool.
-- Trwa kilka minut na godzinę materiału; w tym czasie DaVinci nie reaguje.
local sciezka = debug.getinfo(1, "S").source:sub(2):match("^(.*)[/\\]")
local N = dofile(sciezka .. "/nada_wspolne.lib")
local plik, nazwa = N.eksportuj()
print(N.T("Nada Studio: analizuję „", "Nada Studio: analysing “") .. nazwa .. N.T("”…", "”…"))
local xml, srt
for _, l in ipairs(N.silnik("davinci_most.py", { "tnij", "--xml", plik })) do
  xml = l:match("^XML\t(.+)$") or xml
  srt = l:match("^SRT\t(.+)$") or srt
end
if not xml then print(N.T("Cięcie nie wyszło. Szczegóły zobaczysz w panelu Nada Studio (wersja Studio) albo w apce.", "The cut failed. Details are in the Nada Studio panel (Studio version) or in the app.")) return end
local tl = N.importuj_os(xml, nazwa .. N.T(" (cięcie)", " (cut)"))
print(tl and (N.T("Gotowe: nowa oś „", "Done: new timeline “") .. nazwa .. N.T(" (cięcie)”.", " (cut)”.")) or (N.T("Nie udało się wczytać ", "Could not load ") .. xml .. N.T(": zaimportuj ją ręcznie (Plik > Import > Timeline).", ": import it manually (File > Import > Timeline).")))
if srt then N.importuj_pliki({ srt }); print(N.T("Napisy SRT są w Media Pool.", "SRT captions are in the Media Pool.")) end
