-- Nada Studio: wczytuje do otwartego projektu nowe osie czasu z zadań (rolki, aftermovie, cięcia).
local sciezka = debug.getinfo(1, "S").source:sub(2):match("^(.*)[/\\]")
local N = dofile(sciezka .. "/nada_wspolne.lib")
local nowe, wszystkie = {}, 0
for _, l in ipairs(N.silnik("davinci_most.py", { "wyniki" })) do
  local p = N.pola(l)
  if p[1] == "OS" then
    wszystkie = wszystkie + 1
    if p[5] == "NOWA" then table.insert(nowe, { plik = p[2], tytul = p[3] }) end
  end
end
if #nowe == 0 then
  print(N.T("Nada Studio: brak nowych osi do wczytania (" .. wszystkie .. " już wczytanych z ostatnich 30 dni).", "Nada Studio: no new timelines to load (" .. wszystkie .. " already loaded from the last 30 days)."))
else
  for i, o in ipairs(nowe) do
    if i > 5 then print(N.T("…i " .. (#nowe - 5) .. " kolejnych: uruchom skrypt jeszcze raz.", "…and " .. (#nowe - 5) .. " more: run the script again.")); break end
    local tl = N.importuj_os(o.plik, o.tytul:gsub(" / ", " - "))
    print((tl and N.T("Wczytano: ", "Loaded: ") or N.T("Nie udało się wczytać: ", "Could not load: ")) .. o.tytul)
  end
end
