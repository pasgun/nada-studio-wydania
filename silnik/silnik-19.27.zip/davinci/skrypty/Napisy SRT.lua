-- Nada Studio: napisy SRT do otwartej osi (rozpoznawanie mowy silnikiem). Plik trafia do Media Pool.
local sciezka = debug.getinfo(1, "S").source:sub(2):match("^(.*)[/\\]")
local N = dofile(sciezka .. "/nada_wspolne.lib")
local plik, nazwa = N.eksportuj()
print(N.T("Nada Studio: rozpoznaję mowę w „", "Nada Studio: recognising speech in “") .. nazwa .. "”…")
local srt
for _, l in ipairs(N.silnik("davinci_most.py", { "napisy", "--xml", plik })) do srt = l:match("^SRT\t(.+)$") or srt end
if srt then N.importuj_pliki({ srt }); print(N.T("Gotowe: napisy SRT są w Media Pool (", "Done: SRT captions are in the Media Pool (") .. srt .. ").") else print(N.T("Napisy nie wyszły.", "Captions failed.")) end
