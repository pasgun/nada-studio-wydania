# Silnik rolek Nadamedia (dla Gemini i innych asystentów)

Wszystkie zasady pracy w tym folderze są w pliku `CLAUDE.md`. Przeczytaj go na początku każdego zadania i stosuj tak, jakby był pisany do Ciebie (dotyczy każdego asystenta, nie tylko Claude). Szczególnie sekcję „Styl zadania (`zadanie.styl`) ma pierwszeństwo przed marką”: gdy zadanie ma `styl.zrodlo` inne niż `marka`, nie opisuj wyglądu według marki, tylko według referencji albo opisu użytkownika.

- Kroki każdego rodzaju zadania są w `.claude/skills/<nazwa>/SKILL.md` (np. `rolka`, `grafika`, `napisy`). Gdy polecenie zaczyna się od `/nazwa`, przeczytaj ten plik i wykonaj go.
- Narzędzia uruchamiasz poleceniami `python narzedzia/<narzędzie>.py ...` w tym folderze. Każde wypisuje JSON z `"ok": true/false`.
- Klucze API są tylko w `.env`: nigdy ich nie czytaj, nie wypisuj i nie kopiuj.
- Masz te same połączenia co Claude Code (Magnific AI, Epidemic Sound, Artlist), jeśli użytkownik uruchomił `python narzedzia/mozg.py instaluj`. Stock Magnific (zdjęcia i ujęcia) bierzesz zawsze przez `python narzedzia/freepik.py`, lektora przez `lektor.py`, obrazy Nano Banana przez `gemini.py`, Higgsfield przez `higgsfield.py`: te narzędzia same biorą klucze z `.env`. Gdy połączenia nie ma, powiedz o tym i użyj zamiennika (muzyka z folderu `muzyka/`).
- Pliki `.env` i `.agents/mcp_config.json` zawierają klucze: nigdy ich nie czytaj ani nie wypisuj.
- Rozmawiaj po polsku (po angielsku, gdy `_system/jezyk.txt` zawiera `en`), bez żargonu. Gdy potrzebujesz decyzji użytkownika, zakończ odpowiedź pytaniem i znacznikiem `[CZEKAM]`; po skończeniu pracy dopisz `[GOTOWE]`.

## Gemini w tle: polecenia tylko przez pomocnika

Gdy pracujesz w tle (zadanie z panelu Premiere albo z przycisku „Wykonaj”), nikt nie kliknie „Zezwól”. Wolno Ci wtedy uruchomić w terminalu tylko jedno polecenie, dokładnie w tej postaci: `python narzedzia/uruchom.py` (bez niczego więcej). Każde inne polecenie zostanie odrzucone i zadanie stanie.
- Gdy instrukcja (CLAUDE.md, skill) każe uruchomić `python narzedzia/<narzędzie>.py ...`, `ffmpeg ...` albo `ffprobe ...`, zapisz najpierw plik prośby `polecenie_gemini.json` w folderze zadania (ścieżkę podaje polecenie zadania; bez niej `_system/gemini/polecenie_gemini.json`): `{"narzedzie": "postep.py", "argumenty": ["--etap", "material", "--tekst", "Przeglądam ujęcia"]}`. Każdy argument osobno, ścieżki z ukośnikiem `/`. Kilka narzędzi po kolei: `{"polecenia": [{...}, {...}]}`.
- Potem uruchom `python narzedzia/uruchom.py`. Pomocnik wypisze wynik narzędzia (JSON z `"ok"`) i kod wyjścia; przy każdym kolejnym narzędziu zapisz nową prośbę.
- Pliki czytasz i zapisujesz swoimi narzędziami do plików (to działa bez pytania). Folder zadania tworzy `wspolne.py` (przez pomocnika).

## Zmiany w narzędziach silnika

Narzędzia w `narzedzia/`, skille w `.claude/skills/` i pliki panelu w `premiere/` to kod użytkownika. Możesz w nich poprawić tylko drobny, oczywisty błąd, który blokuje zadanie (np. niezamknięty plik, literówka w ścieżce), i tylko wtedy, gdy bez tego zadania nie da się dokończyć. Nie przerabiaj działania narzędzi, nie dopisuj nowych funkcji i nie zmieniaj ustawień ani zgód. Każdą zmianę wypisz na końcu odpowiedzi i w raporcie zadania (`raport.md`) w sekcji „Zmiany w silniku”: który plik, co było źle, co zmieniłeś (jednym-dwoma zdaniami). Gdy błąd jest większy, nie poprawiaj go: opisz go w raporcie, a przy zadaniu z panelu zgłoś przez `postep.py --blad`.
