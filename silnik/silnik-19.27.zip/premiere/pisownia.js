/* Nada Studio: sprawdzanie pisowni po polsku w polach tekstu panelu (LanguageTool, darmowa usługa w internecie).
 * Po krótkiej przerwie w pisaniu tekst idzie do sprawdzenia; oczywiste literówki poprawiają się same (z „cofnij”),
 * reszta pokazuje się pod polem z propozycjami do kliknięcia. Bez internetu nic się nie dzieje.
 * Wysyłany jest tylko tekst z pola, nic więcej. */
(function () {
  "use strict";
  const KLUCZ = "nm-pisownia-auto";
  const auto = () => { try { const v = JSON.parse(localStorage.getItem(KLUCZ)); return v == null ? true : !!v; } catch (e) { return true; } };
  const N = typeof require === "function" ? require : (window.cep_node && window.cep_node.require);
  let https = null;
  try { https = N && N("https"); } catch (e) {}
  const pamiec = new Map(); // tekst -> wynik (żeby nie pytać dwa razy o to samo)
  let wolnoOd = 0;          // przerwa po błędzie sieci albo limicie usługi

  function sprawdz(tekst) {
    if (pamiec.has(tekst)) return Promise.resolve(pamiec.get(tekst));
    if (Date.now() < wolnoOd) return Promise.resolve(null);
    const dane = "language=pl-PL&text=" + encodeURIComponent(tekst);
    const gotowe = (j) => { const w = (j && j.matches) || []; pamiec.set(tekst, w); if (pamiec.size > 300) pamiec.delete(pamiec.keys().next().value); return w; };
    if (window.NM_PISOWNIA_TEST) return Promise.resolve(window.NM_PISOWNIA_TEST(tekst)).then(gotowe);
    if (https) {
      return new Promise((ok) => {
        const z = https.request({ host: "api.languagetool.org", path: "/v2/check", method: "POST", timeout: 8000,
          headers: { "Content-Type": "application/x-www-form-urlencoded", "Content-Length": new TextEncoder().encode(dane).length, Accept: "application/json" } }, (o) => {
          let b = ""; o.on("data", (d) => (b += d)); o.on("end", () => {
            if (o.statusCode === 429) { wolnoOd = Date.now() + 60000; ok(null); return; }
            try { ok(gotowe(JSON.parse(b))); } catch (e) { ok(null); }
          });
        });
        z.on("error", () => { wolnoOd = Date.now() + 30000; ok(null); });
        z.on("timeout", () => { z.destroy(); ok(null); });
        z.write(dane); z.end();
      });
    }
    return fetch("https://api.languagetool.org/v2/check", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: dane })
      .then((r) => (r.status === 429 ? ((wolnoOd = Date.now() + 60000), null) : r.json())).then((j) => (j ? gotowe(j) : null)).catch(() => ((wolnoOd = Date.now() + 30000), null));
  }

  const styl = document.createElement("style");
  styl.textContent = `.nm-pis{font-size:11px;color:#f3c77a;margin-top:2px;line-height:1.5;grid-column:1/-1}
.nm-pis button{background:#3a2e14;border:1px solid #6b5420;color:#ffe2a6;border-radius:4px;padding:0 5px;margin:1px 2px;cursor:pointer;font-size:11px}
.nm-pis .ok{color:#8bd3a0}.nm-pis a{color:#9ab;cursor:pointer;text-decoration:underline;margin-left:4px}
textarea.nm-ma-bledy{border-color:#8a6a1e!important}`;
  document.head.appendChild(styl);

  function pole(el) {
    if (el.dataset.nmPis) return;
    el.dataset.nmPis = "1";
    el.setAttribute("spellcheck", "true"); el.setAttribute("lang", "pl");
    let czas = 0, ostatni = "";
    const info = document.createElement("div"); info.className = "nm-pis"; info.hidden = true;
    el.insertAdjacentElement("afterend", info);
    const ustaw = (nowy) => { el.value = nowy; el.dispatchEvent(new Event("input", { bubbles: true })); el.dispatchEvent(new Event("change", { bubbles: true })); };
    async function teraz() {
      const t = el.value;
      if (t.trim().length < 3 || t === ostatni) return;
      ostatni = t;
      const bledy = await sprawdz(t);
      if (bledy == null || el.value !== t) return;
      // literówki: jedna sensowna propozycja = popraw od razu (oprócz słowa, które właśnie piszesz)
      const kursor = document.activeElement === el ? el.selectionStart : -1;
      const pewne = [], reszta = [];
      bledy.forEach((m) => {
        const propo = (m.replacements || []).map((r) => r.value).filter(Boolean);
        const lit = m.rule && m.rule.issueType === "misspelling";
        const slowo = t.substr(m.offset, m.length);
        const piszeTo = kursor >= m.offset && kursor <= m.offset + m.length;
        if (auto() && lit && propo.length && !piszeTo && !/\d|[*_#@]/.test(slowo) && !(slowo[0] === slowo[0].toUpperCase() && slowo.toLowerCase() !== slowo && m.offset > 0)) pewne.push({ m, na: propo[0], z: slowo });
        else if (propo.length || lit) reszta.push({ m, propo: propo.slice(0, 4), z: slowo });
      });
      let nowy = t;
      pewne.slice().sort((a, b) => b.m.offset - a.m.offset).forEach((p) => { nowy = nowy.slice(0, p.m.offset) + p.na + nowy.slice(p.m.offset + p.m.length); });
      if (nowy !== t) { const pozycja = el.selectionStart; ustaw(nowy); ostatni = nowy; try { if (document.activeElement === el) el.selectionStart = el.selectionEnd = Math.min(nowy.length, pozycja + (nowy.length - t.length)); } catch (e) {} }
      rysuj(pewne, reszta, t);
    }
    function rysuj(pewne, reszta, przed) {
      el.classList.toggle("nm-ma-bledy", reszta.length > 0);
      if (!pewne.length && !reszta.length) { info.hidden = true; return; }
      info.hidden = false; info.innerHTML = "";
      if (pewne.length) {
        const s = document.createElement("span"); s.className = "ok";
        s.textContent = "Poprawiłem: " + pewne.map((p) => `${p.z} → ${p.na}`).join(", ");
        const c = document.createElement("a"); c.textContent = "cofnij"; c.onclick = () => { ostatni = przed; ustaw(przed); info.hidden = true; };
        info.appendChild(s); info.appendChild(c); info.appendChild(document.createElement("br"));
      }
      reszta.slice(0, 6).forEach((r) => {
        const s = document.createElement("span"); s.textContent = `„${r.z}”${r.propo.length ? ": " : " (sprawdź)"}`; info.appendChild(s);
        r.propo.forEach((p) => {
          const b = document.createElement("button"); b.type = "button"; b.textContent = p; b.title = r.m.message || "";
          b.onclick = () => { const t = el.value, i = t.indexOf(r.z, Math.max(0, r.m.offset - 3)); if (i < 0) return; ustaw(t.slice(0, i) + p + t.slice(i + r.z.length)); teraz(); };
          info.appendChild(b);
        });
        info.appendChild(document.createTextNode(" "));
      });
    }
    el.addEventListener("input", (e) => { if (e.isTrusted === false && el.dataset.nmPisUstawia) return; clearTimeout(czas); czas = setTimeout(teraz, 1300); });
    el.addEventListener("blur", () => { clearTimeout(czas); teraz(); });
  }
  const wszystkie = () => document.querySelectorAll("textarea:not([data-bez-pisowni])").forEach(pole);
  const start = () => { wszystkie(); new MutationObserver(wszystkie).observe(document.body, { childList: true, subtree: true }); };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
  window.NMPisownia = { sprawdz, ustawAuto: (v) => { try { localStorage.setItem(KLUCZ, JSON.stringify(!!v)); } catch (e) {} }, auto };
})();
