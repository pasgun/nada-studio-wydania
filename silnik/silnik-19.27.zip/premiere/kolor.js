/* Nada Studio: wybór koloru od razu w HEX (zamiast okna Windows/Chromium, które startuje w RGB).
 * Każde <input type="color"> w panelu dostaje próbkę + pole HEX; kliknięcie próbki otwiera okienko
 * z polem barwy, suwakiem odcienia, polem HEX i kolorami z panelu. Wartość nadal czyta się z input.value.
 * Obok pola HEX stoją kolory wybranego klienta (jedno kliknięcie = ten kolor). Skąd je brać, mówi strona:
 * NMKolor.zrodloMarki((input) => ["#RRGGBB", {k: "#RRGGBB", n: "nazwa"}...]); NMKolor.odswiezMarke() rysuje je od nowa. */
(function () {
  "use strict";
  const OSTATNIE = "nm-kolory-ostatnie";
  const norm = (v) => {
    let h = String(v || "").trim().replace(/^#/, "");
    if (/^[0-9a-f]{3}$/i.test(h)) h = h.split("").map((c) => c + c).join("");
    return /^[0-9a-f]{6}$/i.test(h) ? "#" + h.toUpperCase() : null;
  };
  const hex2hsv = (hex) => {
    const n = parseInt(hex.slice(1), 16), r = (n >> 16 & 255) / 255, g = (n >> 8 & 255) / 255, b = (n & 255) / 255;
    const mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
    let h = 0;
    if (d) h = mx === r ? ((g - b) / d) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
    return [(h * 60 + 360) % 360, mx ? d / mx : 0, mx];
  };
  const hsv2hex = (h, s, v) => {
    const f = (n) => { const k = (n + h / 60) % 6; return v - v * s * Math.max(0, Math.min(k, 4 - k, 1)); };
    return "#" + [f(5), f(3), f(1)].map((x) => Math.round(x * 255).toString(16).padStart(2, "0")).join("").toUpperCase();
  };
  const czytajOst = () => { try { return JSON.parse(localStorage.getItem(OSTATNIE)) || []; } catch (e) { return []; } };
  const zapiszOst = (k) => { try { localStorage.setItem(OSTATNIE, JSON.stringify([k, ...czytajOst().filter((x) => x !== k)].slice(0, 12))); } catch (e) {} };

  const styl = document.createElement("style");
  styl.textContent = `
.nmk{display:inline-flex;align-items:center;gap:4px;width:100%;min-width:0;flex-wrap:wrap}
.nmk-marka{display:inline-flex;flex-wrap:wrap;gap:3px;align-items:center}
.nmk-marka[hidden]{display:none}
.nmk-marka button{width:18px;height:18px;border-radius:4px;border:1px solid rgba(128,128,128,.6);padding:0;cursor:pointer;box-shadow:inset 0 0 0 1px rgba(0,0,0,.35);flex:none}
.nmk-marka button[aria-pressed="true"]{outline:2px solid #ff8a3d;outline-offset:1px}
.nmk-marka button:hover{transform:scale(1.15)}
.nmk .pr{flex:0 0 26px;height:24px;border-radius:4px;border:1px solid rgba(255,255,255,.25);cursor:pointer;padding:0;box-shadow:inset 0 0 0 1px rgba(0,0,0,.35)}
.nmk input.hx{flex:1;min-width:64px;width:100%;font-family:Consolas,monospace;text-transform:uppercase;padding:4px 5px}
.nmk-okno{position:fixed;z-index:10000;width:212px;background:#202020;border:1px solid #3a3a3a;border-radius:8px;padding:8px;box-shadow:0 10px 30px rgba(0,0,0,.55);display:grid;gap:7px;font:12px "Segoe UI",system-ui,sans-serif;color:#e6e6e6}
.nmk-okno canvas{display:block;width:196px;border-radius:5px;cursor:crosshair;touch-action:none}
.nmk-okno .wiersz{display:flex;gap:6px;align-items:center}
.nmk-okno *{box-sizing:border-box}
.nmk-okno .wiersz input{flex:1;min-width:0;width:100%;font-family:Consolas,monospace;text-transform:uppercase;background:#151515;color:#eee;border:1px solid #3a3a3a;border-radius:4px;padding:5px 6px}
.nmk-okno .duza{flex:0 0 30px;width:30px;height:28px;border-radius:5px;border:1px solid rgba(255,255,255,.2)}
.nmk-okno .probki{display:grid;grid-template-columns:repeat(8,1fr);gap:4px}
.nmk-okno .probki button{height:18px;border-radius:3px;border:1px solid rgba(255,255,255,.18);padding:0;cursor:pointer}
.nmk-okno small{color:#8a8a8a}`;
  document.head.appendChild(styl);

  let okno = null, aktywny = null, zrodlo = null;
  /* kolory klienta dla danego pola: lista bez powtórzeń, najwyżej 10 */
  const markaDla = (inp) => {
    let l = [];
    try { l = (zrodlo && zrodlo(inp)) || []; } catch (e) { l = []; }
    const m = new Map();
    l.forEach((x) => { const k = norm(typeof x === "string" ? x : x && (x.k || x.kolor)); if (k && !m.has(k)) m.set(k, { k, n: (x && x.n) || "" }); });
    return [...m.values()].slice(0, 10);
  };
  function zamknij() { if (okno) { okno.remove(); okno = null; aktywny = null; } }
  document.addEventListener("pointerdown", (e) => { if (okno && !okno.contains(e.target) && !(e.target.closest && e.target.closest(".nmk"))) zamknij(); }, true);
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") zamknij(); });

  function otworz(inp, kotwica) {
    zamknij(); aktywny = inp;
    let [h, s, v] = hex2hsv(norm(inp.value) || "#FF6B2C");
    okno = document.createElement("div"); okno.className = "nmk-okno";
    okno.innerHTML = `<canvas class="sv" width="196" height="120"></canvas><canvas class="hue" width="196" height="12"></canvas>
      <div class="wiersz"><span class="duza"></span><input class="hex" maxlength="7" spellcheck="false" aria-label="Kolor HEX"></div>
      <small class="mk-tytul" hidden>Kolory klienta</small><div class="probki mk"></div>
      <small>Kolory w panelu i ostatnio użyte</small><div class="probki inne"></div>`;
    document.body.appendChild(okno);
    const r = kotwica.getBoundingClientRect();
    okno.style.left = Math.max(4, Math.min(innerWidth - 220, r.left)) + "px";
    okno.style.top = (r.bottom + 230 > innerHeight ? Math.max(4, r.top - 236) : r.bottom + 4) + "px";
    const sv = okno.querySelector(".sv"), hue = okno.querySelector(".hue"), pole = okno.querySelector(".hex"), duza = okno.querySelector(".duza");
    const rysuj = () => {
      const x = sv.getContext("2d");
      x.fillStyle = hsv2hex(h, 1, 1); x.fillRect(0, 0, 196, 120);
      let g = x.createLinearGradient(0, 0, 196, 0); g.addColorStop(0, "#fff"); g.addColorStop(1, "rgba(255,255,255,0)"); x.fillStyle = g; x.fillRect(0, 0, 196, 120);
      g = x.createLinearGradient(0, 0, 0, 120); g.addColorStop(0, "rgba(0,0,0,0)"); g.addColorStop(1, "#000"); x.fillStyle = g; x.fillRect(0, 0, 196, 120);
      x.beginPath(); x.arc(s * 196, (1 - v) * 120, 5, 0, 7); x.lineWidth = 2; x.strokeStyle = v > 0.6 && s < 0.4 ? "#000" : "#fff"; x.stroke();
      const y = hue.getContext("2d"), gh = y.createLinearGradient(0, 0, 196, 0);
      for (let i = 0; i <= 6; i++) gh.addColorStop(i / 6, hsv2hex(i * 60, 1, 1));
      y.fillStyle = gh; y.fillRect(0, 0, 196, 12); y.fillStyle = "#fff"; y.fillRect(h / 360 * 196 - 1.5, 0, 3, 12);
    };
    const ustaw = (hex, zrodlo) => {
      if (zrodlo !== "pole") pole.value = hex;
      duza.style.background = hex;
      inp.value = hex; inp.dispatchEvent(new Event("input", { bubbles: true }));
      rysuj();
    };
    const przeciagnij = (el, fn) => {
      const ruch = (e) => { const b = el.getBoundingClientRect(); fn(Math.max(0, Math.min(1, (e.clientX - b.left) / b.width)), Math.max(0, Math.min(1, (e.clientY - b.top) / b.height))); };
      el.addEventListener("pointerdown", (e) => { el.setPointerCapture(e.pointerId); ruch(e); el.onpointermove = ruch; });
      el.addEventListener("pointerup", () => { el.onpointermove = null; inp.dispatchEvent(new Event("change", { bubbles: true })); zapiszOst(norm(inp.value)); });
    };
    przeciagnij(sv, (a, b) => { s = a; v = 1 - b; ustaw(hsv2hex(h, s, v)); });
    przeciagnij(hue, (a) => { h = a * 360; ustaw(hsv2hex(h, s, v)); });
    pole.oninput = () => { const k = norm(pole.value); if (k) { [h, s, v] = hex2hsv(k); ustaw(k, "pole"); } };
    pole.onkeydown = (e) => { if (e.key === "Enter") { inp.dispatchEvent(new Event("change", { bubbles: true })); zapiszOst(norm(inp.value)); zamknij(); } };
    pole.onchange = () => { inp.dispatchEvent(new Event("change", { bubbles: true })); zapiszOst(norm(inp.value)); };
    const zPanelu = Array.from(document.querySelectorAll('input[type="color"]')).map((x) => norm(x.value)).filter(Boolean);
    const mk = markaDla(inp);
    const probki = [...new Set([...zPanelu, ...czytajOst(), "#FFFFFF", "#000000"])].filter((k) => !mk.some((x) => x.k === k)).slice(0, 24);
    okno.querySelector(".mk-tytul").hidden = !mk.length;
    okno.querySelector(".probki.mk").innerHTML = mk.map((x) => `<button style="background:${x.k}" title="${(x.n ? x.n + " " : "") + x.k}" data-k="${x.k}"></button>`).join("");
    okno.querySelector(".probki.inne").innerHTML = probki.map((k) => `<button style="background:${k}" title="${k}" data-k="${k}"></button>`).join("");
    okno.querySelectorAll(".probki button").forEach((b) => (b.onclick = () => { [h, s, v] = hex2hsv(b.dataset.k); ustaw(b.dataset.k); inp.dispatchEvent(new Event("change", { bubbles: true })); }));
    ustaw(norm(inp.value) || "#FF6B2C");
    pole.focus(); pole.select();
  }

  const opis = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value");
  function podlacz(inp) {
    if (inp.dataset.nmk) return;
    inp.dataset.nmk = "1";
    const w = document.createElement("span"); w.className = "nmk";
    const pr = document.createElement("button"); pr.type = "button"; pr.className = "pr"; pr.title = "Wybierz kolor";
    const hx = document.createElement("input"); hx.type = "text"; hx.className = "hx"; hx.maxLength = 7; hx.spellcheck = false; hx.setAttribute("aria-label", "Kolor HEX");
    // obok jest już pole z kodem koloru (np. w Studio): zostaje, dokładamy tylko próbkę z okienkiem HEX
    const obok = inp.parentNode.querySelector(".np-hex, #c-palHex");
    inp.parentNode.insertBefore(w, inp); w.appendChild(pr); if (!obok) w.appendChild(hx); w.appendChild(inp);
    if (obok) w.style.width = "auto";
    inp.style.display = "none";
    // kolory klienta obok pola z kodem koloru
    const mk = document.createElement("span"); mk.className = "nmk-marka"; mk.hidden = true; mk.setAttribute("role", "group"); mk.setAttribute("aria-label", "Kolory klienta");
    if (obok) obok.after(mk); else w.appendChild(mk);
    inp._nmkMarka = mk;
    const zaznacz = () => { const k = norm(opis.get.call(inp)); mk.querySelectorAll("button").forEach((b) => b.setAttribute("aria-pressed", String(b.dataset.k === k))); };
    inp._nmkZaznacz = zaznacz;
    mk.addEventListener("click", (e) => {
      const b = e.target.closest("button"); if (!b) return;
      e.preventDefault();
      inp.value = b.dataset.k;
      inp.dispatchEvent(new Event("input", { bubbles: true })); inp.dispatchEvent(new Event("change", { bubbles: true }));
      zapiszOst(b.dataset.k);
    });
    const pokaz = () => { const k = norm(opis.get.call(inp)) || "#000000"; pr.style.background = k; if (document.activeElement !== hx) hx.value = k; zaznacz(); };
    // wartość ustawiana z kodu (np. kolory marki) też odświeża próbkę
    Object.defineProperty(inp, "value", { configurable: true, get() { return opis.get.call(this); }, set(v) { opis.set.call(this, norm(v) ? norm(v).toLowerCase() : v); pokaz(); } });
    inp.addEventListener("input", pokaz); inp.addEventListener("change", pokaz);
    pr.onclick = (e) => { e.preventDefault(); if (aktywny === inp) zamknij(); else otworz(inp, w); };
    hx.oninput = () => { const k = norm(hx.value); if (k) { inp.value = k; pr.style.background = k; inp.dispatchEvent(new Event("input", { bubbles: true })); } };
    hx.onchange = () => { const k = norm(hx.value); if (k) { inp.dispatchEvent(new Event("change", { bubbles: true })); zapiszOst(k); } else pokaz(); };
    hx.onblur = pokaz;
    rysujMarke(inp);
    pokaz();
  }
  function rysujMarke(inp) {
    const mk = inp._nmkMarka; if (!mk) return;
    const l = markaDla(inp), klucz = l.map((x) => x.k + x.n).join(",");
    if (mk.dataset.klucz === klucz) return;
    mk.dataset.klucz = klucz;
    mk.hidden = !l.length;
    mk.title = l.length ? "Kolory klienta: kliknij, żeby użyć" : "";
    mk.innerHTML = l.map((x) => `<button type="button" style="background:${x.k}" data-k="${x.k}" title="${(x.n ? x.n + " " : "") + x.k}" aria-label="Kolor klienta ${x.k}"></button>`).join("");
    if (inp._nmkZaznacz) inp._nmkZaznacz();
  }
  function odswiezMarke() { document.querySelectorAll('input[type="color"][data-nmk]').forEach(rysujMarke); }
  // zmiana klienta w dowolnym miejscu (lista „Klient”) od razu zmienia kolory obok pól
  document.addEventListener("change", (e) => { const s = e.target; if (s && s.tagName === "SELECT" && /klient|client/i.test(s.id || "")) setTimeout(odswiezMarke, 0); }, true);
  // gdy strona ustawi klienta bez zdarzenia (np. otwarcie zadania), widoczne pola dogonią to same
  setInterval(() => document.querySelectorAll('input[type="color"][data-nmk]').forEach((inp) => { const mk = inp._nmkMarka; if (mk && mk.parentNode && mk.parentNode.offsetParent !== null) rysujMarke(inp); }), 1200);
  const wszystkie = (root) => root.querySelectorAll && root.querySelectorAll('input[type="color"]').forEach(podlacz);
  const start = () => {
    wszystkie(document);
    new MutationObserver((m) => m.forEach((x) => x.addedNodes.forEach((n) => { if (n.nodeType === 1) { if (n.matches && n.matches('input[type="color"]')) podlacz(n); else wszystkie(n); } }))).observe(document.body, { childList: true, subtree: true });
  };
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
  window.NMKolor = { podlacz, norm, odswiezMarke, zrodloMarki: (fn) => { zrodlo = fn; odswiezMarke(); } };
})();
