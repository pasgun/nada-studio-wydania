---
name: animacje
description: Robi animacje (napisy, belki z nazwiskiem, grafiki do rolek, liczby, wykresy, przejścia) z biblioteki presetów albo nowe z opisu, w kolorach i fontach marki klienta, jako pliki MOV z przezroczystością do Premiere. Uruchamiane poleceniem /animacje z danymi w JSON ze Studio albo z panelu w Premiere.
disable-model-invocation: true
---

Zadanie:

$ARGUMENTS

Biblioteka: `narzedzia/animacje/animacje.js` (presety, opis parametrów na górze pliku, wzór własnego presetu na dole). Lista: `python narzedzia/animacje.py lista`.

## Zasady wspólne

- Folder wyników: z panelu jest w `folder`; ze Studio pliki zapisuj do `<zlecenie.folder>/gotowe/` (utwórz go).
- Kolory i font: z panelu `marka_z_panelu`, ze Studio `zlecenie.marka` (wybrane przez użytkownika) mają pierwszeństwo przed marką klienta: przekaż je w `--parametry`.
- `zlecenie.tryb` `presety+opis`: zrób listę `animacje` (tryb `presety`) i nową animację z `opis` (tryb `opis`). Format ze Studio: `pion`, `poziom`, `kwadrat` albo `4x5`.
- Marka: `python narzedzia/animacje.py marka --klient <klient.folder>` pokazuje kolory, font i logo, których animacje użyją. Jeśli klient nie ma `animacje.json`, a ma `marka.md`, przeczytaj ją i zapisz `klienci/<x>/animacje.json` (`kolor_glowny`, `kolor_akcent`, `kolor_tekstu`, `kolor_tla`, `font`, `waga`, opcjonalnie `logo`) zgodnie z zasadami marki (np. akcent tylko na wyróżnienia, kolor tekstu czytelny na filmie). Nie zmieniaj istniejącego `animacje.json` bez prośby.
- Wyróżnienia w tekście: `*słowo*` (kolor akcentu). Teksty po polsku, krótkie (napis do 6–7 słów na raz).
- Format: `format` z zadania (`pion`, `poziom`, `kwadrat`, `4x5` albo `1920x1080`); z panelu rozmiar sekwencji.
- Z panelu: użytkownika nie ma przy komputerze, nie zadawaj pytań. Etapy: `python narzedzia/postep.py --etap <klucz> --tekst "..."` (klucze: `przygotowanie`, `projekt`, `render`, `kontrola`), na koniec `--gotowe`, przy błędzie `--blad "..."`.

## Tryb `presety` (lista gotowych animacji)

Dla każdej pozycji z `animacje` (`preset`, `parametry`): `python narzedzia/animacje.py render --preset <id> --klient <klient.folder> --format <format> --parametry '<json>' --wyjscie <folder>/<nn>_<id>.mov --podglad`. Obejrzyj podglądy (Read); popraw parametry, jeśli tekst się nie mieści albo kolor ginie.

## Tryb `opis` (nowa animacja z opisu użytkownika)

1. Przeczytaj opis (`opis`) i wzór na dole `animacje.js`. Jeśli istniejący preset da się dostroić parametrami, użyj go (tryb `presety`) i napisz to w raporcie.
2. Inaczej napisz nowy preset `narzedzia/animacje/wlasne/<id>.js` (id: małe litery i myślniki; `kat: "wlasne"`, `nazwa` po polsku, `pola`, `przyklad` z tekstem z opisu). Zasady: przezroczyste tło (chyba że to przejście, wtedy `pelne: true`), kolory tylko z `s.k`, font z `s.p.font`, rozmiary × `s.u` × `s.p.rozmiar`, płynne wejście (funkcje z `NMAnim.pomoc.E`), bez zewnętrznych plików i bibliotek, bez znaków marek i postaci chronionych prawem.
3. `python narzedzia/animacje.py render --preset <id> --klient ... --format ... --wyjscie <folder>/<id>.mov --podglad` i obejrzyj `<id>_podglad.png`. Popraw kod i powtórz (do 3 razy), aż ruch i kadr wyglądają dobrze (nic nie wychodzi poza kadr, tekst czytelny, wyróżnienia w akcencie).
4. Nowy preset od razu jest w galerii panelu i Studio (sekcja „Własne”).

## Tryb `film` (animacje do filmu według opisu)

Opis mówi, co i kiedy pokazać (np. „0:12 belka Anna Nowak, CEO; 0:40 licznik +250% zasięgów”). Gdy podano `xml` sekwencji i `dopasuj_do_mowy: true`, najpierw `python narzedzia/ciecie.py analizuj --xml <xml> --folder <folder>/mowa` i z `zdania.txt` ustal dokładne momenty (np. animacja startuje, gdy pada słowo). Każdą animację renderuj jak w trybie `presety` (albo nowy preset jak w `opis`). Zapisz `<folder>/wstawki.json`: `[{"plik": "<pełna ścieżka .mov>", "czas_s": 12.0, "opis": "belka Anna Nowak"}]` (czas na osi sekwencji). Panel położy je na wolnej ścieżce nad filmem.

## Raport

Lista plików (ścieżka, preset, czas trwania), decyzje podjęte samodzielnie. Z panelu na koniec: `python narzedzia/postep.py --gotowe --wideo <plik.mov> [--wideo ...] --tekst "<1 zdanie>"`.
