---
name: tlumaczenie
description: Wersje językowe gotowych rolek i filmów (dubbing głosem mówiącego, napisy w języku docelowym, tłumaczenie grafik z PSD). Uruchamiane poleceniem /tlumaczenie z danymi zlecenia w JSON ze Studio Nadamedia.
disable-model-invocation: true
---

Zlecenie ze Studio Nadamedia:

$ARGUMENTS

1. Filmy są w `zlecenie.folder`, grafiki do przetłumaczenia (PSD, PNG) w `zlecenie.folder/grafiki`, jeśli są.
2. Dubbing: `python narzedzia/tlumacz.py dubbing --folder <zlecenie.folder> --jezyki <zlecenie.jezyki> --zrodlo <zlecenie.jezyk_zrodla>`; gdy `zlecenie.napisy` to styl, zapisz go do `<folder>/styl.json` i dodaj `--styl <folder>/styl.json` (z `--fonty <klient.folder>/fonty`, jeśli jest klient). Uprzedź jednym zdaniem, że dubbing zużywa kredyty ElevenLabs za każdą minutę i język, jeśli `zlecenie.plan_przed_startem` jest true, i poczekaj na „ok”.
3. Grafiki w filmie (tekst wypalony w obrazie) nie dadzą się podmienić w gotowym pliku wideo. Jeśli w kadrach (wytnij kilka: `python narzedzia/montaz.py klatki --plik <film> --ile 6`) widzisz plansze z tekstem, napisz to w raporcie. Jeśli film powstał w tym silniku (jest jego `plan.json` w `wyniki/`), zrób wersję językową według sekcji „Wersje językowe” w `CLAUDE.md`.
4. Grafiki z folderu `grafiki`: PSD z warstwami tekstowymi tłumaczysz tak: przeczytaj teksty warstw (`python narzedzia/formaty.py --plik <psd> --formaty <format jak oryginał>` wypisze nazwy warstw), napisz `teksty_<kod>.json` {"Nazwa warstwy": "tłumaczenie"} i uruchom `formaty.py --plik <psd> --formaty <formaty> --tlumaczenia teksty_<kod>.json --sufiks <kod> --fonty <klient.folder>/fonty`. Tłumacz naturalnie, marketingowo, w podobnej długości.
5. Raport: pliki per język, napisy, grafiki, koszt (minuty × języki), uwagi o grafikach w filmie.
