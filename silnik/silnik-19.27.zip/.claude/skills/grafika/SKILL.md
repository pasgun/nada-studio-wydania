---
name: grafika
description: Robi jedną grafikę albo całą serię grafik (wiele sztuk w kilku formatach naraz) w barwach klienta na podstawie zadania ze Studio Nadamedia. Uruchamiane poleceniem /grafika z danymi zadania w JSON.
disable-model-invocation: true
---

Zrób grafiki według tego zadania ze Studio Nadamedia:

$ARGUMENTS

Zasady wyboru serwisów i limity są w `CLAUDE.md`. Zawsze używasz trybu serii (`grafika.py seria`), także dla jednej grafiki: wtedy lista ma jedną pozycję.

**Jakość ponad czas.** Grafika ma wyglądać jak zrobiona przez dobrego grafika klienta, nie „byle jak poprawnie”. Możesz pracować dłużej: oglądaj wzory klienta, oglądaj każdy wynik w pełnym rozmiarze, porównuj i poprawiaj (krok 5). Nie oddawaj grafiki, o której sam wiesz, że odstaje od wzorów.

## Tryb Nano Banana (`zadanie.tryb_grafiki: "nano"`)

Użytkownik wybrał, że całą grafikę (tło, tekst, układ) robi Nano Banana (Gemini), taniej i szybciej, bez edytowalnego PSD. Gemini jest wtedy dozwolony, nawet jeśli nie ma go w `serwisy`. Kroki 1 i 2 robisz tak samo (folder, marka, `teksty.md`), potem zamiast kroków 3–5:
1. Plan (przy `plan_przed_startem: true` pokaż go i czekaj na „ok”): ile obrazów powstanie (grafiki × formaty) i że płaci się z kredytów Google Cloud.
2. Zbuduj `<folder>/nb.json` według opisu na górze `narzedzia/gemini.py` (sekcja „Plan dla grafika”): `formaty` z zadania; `wspolne` po angielsku: kolory marki w HEX z `marka.md`, font nagłówków (nazwa i grubość), nastrój ze `styl_grafiki.md`; `logo` = wariant logo z dobrym kontrastem (z `marka.md`), `logo_miejsce` zgodnie ze stylem; dla każdej grafiki `prompt` po angielsku: co jest na obrazie, gdzie stoi tekst (`zadanie.uklad`), a teksty z `teksty.md` po polsku w cudzysłowie (nagłówek, podtytuł, CTA); zdjęcia użytkownika albo produktu w `obrazy` (model użyje ich jako materiału).
3. `python narzedzia/gemini.py grafika --plan <folder>/nb.json`
4. Obejrzyj `podglad_serii.jpg` (Read). Sprawdź pisownię każdego napisu litera po literze i polskie znaki. Złą grafikę wygeneruj jeszcze raz (popraw prompt, np. krótszy tekst), najwyżej 2 razy bez pytania; potem napisz, która ma błąd.
5. Raport jak w kroku 6, ale bez Photoshopa: napisz, że tekst jest częścią obrazu (do zmian trzeba wygenerować ponownie) i ile obrazów zużyto.

## 1. Przygotowanie

- Odczytaj `zadanie` i `klient`. Załóż folder wyników: `python narzedzia/wspolne.py --klient "<klient.skrot albo klient.nazwa>" --projekt "<zadanie.tytul>"` (zwraca np. `wyniki/emeraldmedia_seriaief10_211026`, czyli klient_projekt_DDMMRR), zapisz w nim `zadanie.json` (z polem `id` zadania). Przy `poprawki` pracuj na kopii poprzedniej wersji (`_v2`) i zmieniaj tylko wskazane grafiki.
- `zadanie.liczba` = ile różnych grafik (domyślnie 1). `zadanie.formaty` = lista formatów (pełna lista na górze `narzedzia/grafika.py`, m.in. `post-4x5`, `story-9x16`, `square`, `poziom-16x9`, `link-1200x628`, `display-300x250`, `yt-1280x720`). Każda grafika powstaje w każdym z formatów.
- `zadanie.uklad` = gdzie stoi tekst: `auto` (Ty decydujesz, zgodnie ze `styl_grafiki.md`, jeśli jest), `dol`, `gora`, `srodek`, `lewo`, `prawo`. W poziomych formatach `dol`/`gora` zamieniają się na `lewo`.
- Marka: `python narzedzia/marka.py sprawdz --folder <klient.folder>` i postępuj według sekcji „Marka i brandbook” w `CLAUDE.md`. `kolory` serii (primary, accent, text, highlight) i wariant logo bierzesz z `marka.md`; bez notatki z `paleta` i `kolory_uwagi` w zadaniu.
- Styl: jeśli klient ma `styl_grafiki.md`, trzymaj się go. Jeśli ma obrazy w `referencje/grafiki/` bez notatki, najpierw ją zrób (zasady w `CLAUDE.md`).
- `zadanie.materialy_folder` (gdy `serwisy` zawiera `materialy`): zdjęcia użytkownika. Obejrzyj je (Read) na początku i używaj ich jako teł w pierwszej kolejności.
- Fonty klienta: jeśli `fonty/` jest pusty, a font jest podany, `python narzedzia/fonty.py pobierz --nazwa "<font>" --folder <folder klienta>/fonty`.

## 2. Teksty

Napisz `teksty.md` z listą wszystkich grafik. Dla każdej: krótka nazwa (bez polskich znaków), nagłówek do 8 słów (1–2 najważniejsze słowa w `*gwiazdkach*`), podtytuł do 14 słów, CTA (z zadania albo klienta). Grafiki mają się różnić tematem albo kątem, nie tylko słowami. Jeśli brief zawiera listę tematów lub gotowe teksty, użyj ich. Pilnuj tonu i zakazów klienta.

Nagłówki z prowadzącym (miniatury YT i podobne) składa układ „stos” (opis na górze `grafika.py`), więc od razu dziel je na linie jak na wzorach klienta: `|` = nowa linia, `*słowo*` = kolor wyróżnienia, `!słowo!` = czerwony (negatyw: błąd, spada, tracisz), linia zaczynająca się od `+` = ogromna na całą szerokość (jedno mocne słowo, np. `+!BŁĄD!`), od `-` = mały dopisek pod spodem (np. `-OTO POWÓD`). Przykład: `TE DANE W RAPORCIE|*WPROWADZAJĄ W*|+!BŁĄD!`. Linie mają mieć podobną długość albo jedną wyraźnie mocniejszą; nie zostawiaj jednoliterowego słowa na końcu linii.

## 3. Plan i tła

- Plan w kilku zdaniach: skąd tła (najpierw materiały użytkownika, potem zdjęcia ze stocka Magnific, AI tylko tam, gdzie nie ma nic sensownego) i ile generacji AI. Przy `plan_przed_startem: true` pokaż listę tekstów i plan, poczekaj na „ok”.
- Jedno tło na grafikę, wspólne dla wszystkich formatów. Szukaj zdjęć dających się kadrować: najlepiej z głównym motywem w środku i spokojnym miejscem na tekst.
  - stock: `python narzedzia/freepik.py szukaj --fraza "<angielska fraza>" --typ zdjecia --ile 12 --podglady <folder>/podglady`, obejrzyj miniatury, potem `python narzedzia/freepik.py pobierz --id <id> --typ zdjecia --rozmiar original --wyjscie <folder>/tla/<nr>.jpg`
  - materiały użytkownika: pliki z `zadanie.materialy_folder` (najpierw te)
  - AI: Higgsfield przez narzędzia MCP serwera `higgsfield` (kredyty z abonamentu; wynik pobierz `pobierz.py`), gdy ich nie ma `python narzedzia/higgsfield.py obraz --prompt "..." --proporcje 3:4 --wyjscie <folder>/tla/<nr>.png` (saldo API), `gemini.py obraz --proporcje 4:5` albo Magnific MCP `images_generate`. W prompcie: bez napisów, spokojne miejsce tam, gdzie stanie tekst. Gdy formaty są i pionowe, i poziome, generuj szerzej (np. 1:1 albo 4:3), żeby kadrowanie miało zapas.
  - Envato: pliki z `envato/`
- Obejrzyj każde tło (Read) i ustal `fokus_x` / `fokus_y` (0–1): punkt, który ma zostać w kadrze przy przycinaniu do węższych formatów (np. twarz, produkt).
- **Osoba na grafice (np. prowadzący na miniaturze YT):** zdjęcia z `zadanie.materialy_folder`; gdy folder jest pusty albo go nie ma, poszukaj w innych folderach `materialy/` tego klienta i w `klienci/<folder>/referencje/` (np. `fotki_*`) i napisz, skąd je wziąłeś.
  1. `python narzedzia/osoba.py arkusz --folder <folder ze zdjęciami> --wyjscie <folder>/osoba`, obejrzyj arkusze (Read). Dobierz do każdej grafiki zdjęcie z miną i gestem pasującym do nagłówka (zdziwienie do „nie wiedziałeś”, sceptycyzm do „błąd”, wskazywanie palcem w stronę tekstu) i takie, gdzie twarz jest ostra i dobrze oświetlona. Różne grafiki serii = różne zdjęcia.
  2. `python narzedzia/osoba.py wytnij --pliki '["...","..."]' --folder-wyjscia <folder>/osoba` (domyślny model jest najdokładniejszy; nie zmieniaj go na słabszy, chyba że wynik ma `uwagi` o braku pamięci).
  3. Obejrzyj każde wycięcie (Read): czy są całe włosy, okulary, uszy i dłonie, czy nie zostało tło (np. kawałek krzesła). Wycięcie z dziurą albo resztkami tła zastąp innym zdjęciem.
  4. W `seria.json` przy grafice `"osoba": {"plik": "<folder>/osoba/01_....png", "strona": "prawo"}`. Obok PNG leży `.json` z twarzą: `grafika.py` sam kadruje wtedy jak na miniaturach (duża głowa przy krawędzi, ciało ucięte dolną krawędzią, nic nie wisi w powietrzu). `"patrzy"` w tym pliku mówi, w którą stronę zwrócona jest głowa: prowadzący ma patrzeć albo wskazywać w stronę tekstu, więc gdy patrzy w stronę krawędzi kadru, ustaw `"odbij": true`. Wielkość głowy zmienisz `"glowa"` (część wysokości kadru, na miniaturach YT zwykle 0.5–0.65), położenie `"x_twarzy"`. `"obrys": "#FFFFFF"` tylko, gdy wzory klienta go mają.
  Tło generuj z wolnym miejscem po stronie tekstu. Nie pisz własnych skryptów do wycinania: w zadaniach w tle i tak nie zadziałają.

## 4. Składanie

Zbuduj `<folder>/seria.json` według opisu na górze `narzedzia/grafika.py` (formaty z zadania, kolory z marki, fonty, `cta` domyślne, `uklad` z zadania, lista `grafiki`; pojedyncza grafika może mieć własny `uklad`). Przed złożeniem zmierz wzory klienta w tym samym formacie i przełóż je na ustawienia: gdzie stoi tekst (`uklad`, `miejsce_tekstu`: dol/srodek/gora), czy linie mają ciemne paski pod spodem (`tlo_linii`), czy na dole jest pasek w kolorze marki (`pasek_dol`), jak duża jest głowa (`osoba.glowa`), czy jest logo. Uruchom:

`python narzedzia/grafika.py seria --plan <folder>/seria.json`

## 5. Kontrola

Plik Photoshopa powstaje przy tym sam (`photoshop/seria.psd`, przy bardzo dużych seriach `seria.psb`). Jeśli wynik ma `uwaga_photoshop` o braku Node.js, zapytaj, czy zainstalować (`winget install OpenJS.NodeJS.LTS`); po instalacji i otwarciu nowego terminala uruchom `python narzedzia/grafika.py psd --plan <folder>/seria.json`.

Kontrola jest obowiązkowa i robisz ją jak grafik, który oddaje pracę klientowi:
1. Przeczytaj `uwagi_kontroli` z wyniku `grafika.py seria` (np. tekst zasłania twarz, nagłówek za mały, prowadzący wisi w powietrzu, tekst ucięty krawędzią). Każdą uwagę popraw.
2. `python narzedzia/grafika.py porownaj --folder <folder grafik> --referencje klienci/<folder>/referencje/grafiki` i obejrzyj każdy arkusz (Read): na górze wzory klienta, pod nimi nasze grafiki w tej samej wielkości. Porównaj po kolei: wielkość liter nagłówka, wielkość twarzy, miejsce tekstu, ilość tekstu, kolory i kontrast, tło (czy nie płaskie, czy rekwizyt jest czytelny).
3. Obejrzyj każdą grafikę osobno w pełnym rozmiarze (Read na PNG, nie tylko podgląd): pisownia litera po literze i polskie znaki, krawędzie wycięcia (włosy, okulary), czy tekst nie wchodzi na twarz i ważne elementy tła, czy nic nie jest ucięte.
4. Wypisz sobie, co odstaje od wzorów, popraw w `seria.json` (podział linii, `glowa`, `x_twarzy`, `odbij`, `miejsce_tekstu`, `fokus_x/y`, inne zdjęcie prowadzącego, inne tło) i złóż jeszcze raz. Do 3 rund poprawek bez pytania; zatrzymaj się wcześniej, gdy już nie widzisz różnic. Po ostatniej rundzie znowu kroki 1–3.
5. Dopiero gdy grafiki trzymają poziom wzorów, przejdź do raportu. Jeśli czegoś nie dało się poprawić (np. brak dobrego zdjęcia z daną miną), napisz to wprost.

## 6. Raport

- folder z grafikami, liczba plików (grafiki × formaty), ścieżka do `podglad_serii.jpg`
- co sprawdziłeś i co poprawiłeś w kontroli (krótko: ile rund, co zmieniłeś)
- plik Photoshopa: ścieżka z `photoshop` i liczba artboardów. Dodaj dwie wskazówki: przy otwieraniu Photoshop zapyta o aktualizację warstw tekstowych, kliknij „Aktualizuj”; żeby tekst miał font marki, zainstaluj fonty z `<folder klienta>/fonty` (prawy klik na pliku → Zainstaluj)
- skąd tła i ile generacji AI (stock: 0 kredytów, limit 100 pobrań dziennie)
- przypomnienie: w Studio wgraj `podglad_serii.jpg` jako gotowy plik zadania (pojedyncze pliki są w folderze), `/usage`, `/clear` przed kolejnym zadaniem
