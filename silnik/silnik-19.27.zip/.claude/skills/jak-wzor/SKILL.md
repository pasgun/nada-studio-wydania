---
name: jak-wzor
description: Robi rolkę podobną do podanego wzoru (gotowej rolki) z materiałów użytkownika: to samo tempo cięć, rodzaj ujęć, przejścia, napisy kinetyczne, muzyka i efekty dźwiękowe. Za darmo (silnik + Epidemic w abonamencie). Uruchamiane poleceniem /jak-wzor z danymi w JSON ze Studio.
disable-model-invocation: true
---

Zlecenie:

$ARGUMENTS

Cel: rolka o tym samym „charakterze” co wzór (tempo, budowa, typ ujęć, przejścia, styl napisów, energia muzyki), ale z materiałów użytkownika i o jego temacie. Nie kopiujesz cudzych treści 1:1: nie używasz muzyki ani ujęć ze wzoru, nie przepisujesz jego tekstów (tylko ich formę), bez logo i znaków wzoru.

## 1. Przygotowanie
- Folder: `zlecenie.folder` (w nim plik wzoru i podfolder `nagrania/` z materiałem; gdy nagrań brak, zatrzymaj się i poproś). Wyniki w `<folder>/gotowe/`.
- Marka i styl klienta: jak w `CLAUDE.md` („Marka i brandbook”, `styl_wideo.md`).

## 2. Rozbiór wzoru
`python narzedzia/wzor.py analizuj --plik <wzór> --folder <folder>/_wzor` (z `--mowa auto`, gdy we wzorze ktoś mówi albo jest lektor).
Obejrzyj wszystkie arkusze (Read). Zapisz `<folder>/przepis.md`:
- format, długość, liczba ujęć, średnia długość ujęcia, czy cięcia trafiają w bit (`ciecia_w_bit_proc`),
- budowa: hak (pierwsze 1–2 s), rozwinięcie, kulminacja, zakończenie / CTA,
- lista ujęć wzoru: nr, długość, rodzaj (plan ogólny, zbliżenie, detal, twarz, ruch kamery, produkt), przejście do kolejnego (cięcie, whip, zoom, flash, rozmycie, glitch, przenikanie),
- napisy i grafiki: jakie (kinetyczne słowo po słowie, duży tytuł, liczniki, strzałki, belki), gdzie na kadrze, kolory, wielkość; przypisz każdemu najbliższy preset z `python narzedzia/animacje.py lista` albo szablon z `python narzedzia/szablony.py lista`,
- muzyka: tempo (BPM), energia, gatunek na ucho z opisu, moment „drop”,
- efekty dźwiękowe: momenty z `uderzenia_s` (zwykle whoosh przy przejściach, hit przy wejściu tytułu, riser przed dropem),
- kolorystyka i nastrój (ciepłe / zimne, kontrast, czarno-białe).

## 3. Materiał
`python narzedzia/analiza.py folder --folder <folder>/nagrania --mowa nie` (z `auto`, gdy zlecenie chce wypowiedzi). Obejrzyj arkusze i dla każdego ujęcia wzoru wybierz najbliższe ujęcie z materiału (ten sam rodzaj planu i ruchu). Brakuje pasującego: najbliższe zastępstwo albo stock z `zlecenie.serwisy`, jeśli jest na liście.

## 4. Muzyka i efekty
- Muzyka z `epidemic` (zlecenie.muzyka): podobne tempo (±6 BPM), ta sama energia i nastrój, bez wokalu, jeśli wzór ma napisy do czytania. Pobierz do `<folder>/muzyka.mp3`, `python narzedzia/bity.py --plik <folder>/muzyka.mp3`. Bez Epidemic: plik z `muzyka/`.
- Efekty dźwiękowe z Epidemic Sound (wyszukaj „whoosh”, „hit”, „riser”, „click”) albo z `muzyka/efekty/`, w miejscach jak we wzorze, ściszone (0.5–0.7).

## 5. Napisy kinetyczne i grafiki
Teksty piszesz na temat zlecenia (`zlecenie.brief`), w formie wzoru (tyle słów na raz, tak samo krótko). Każdy element: `python narzedzia/animacje.py render --preset <id> --klient <klient.folder> --format <pion|poziom> --parametry '<json>' --wyjscie <folder>/gotowe/anim/<nn>.mov --podglad` (albo szablon: `python narzedzia/szablony.py render ...`). Obejrzyj podglądy.

## 6. Montaż
`plan.json` (opis na górze `narzedzia/montaz.py`): sceny z długościami jak we wzorze (przeskalowane do `zlecenie.dlugosc`, jeśli inna; cięcia na bitach nowej muzyki, gdy wzór tnie w bit), przejścia jak we wzorze, `nakladki` z animacjami (czas na osi rolki), `efekty_dzwiekowe`, `muzyka`, logo i plansza końcowa wg marki, `"napisy": false` (napisy są w nakładkach), `"premiere": true`.
`python narzedzia/montaz.py zloz --plan <folder>/plan.json`

## 7. Kontrola
`python narzedzia/montaz.py klatki --plik <rolka> --ile 10`; porównaj z arkuszem wzoru: tempo, kadry, czytelność napisów, nic ważnego nie zasłonięte. Do 2 poprawek bez pytania.

## 8. Raport
Plik, długość, ile ujęć (wzór vs nowa), utwór i efekty (tytuł, autor), co zmieniłeś względem wzoru i dlaczego. Koszt: 0 zł poza abonamentami (ElevenLabs tylko przy rozpoznawaniu mowy).
Higgsfield Katana (gotowe „edity” ze wzoru) jest płatna (kredyty Higgsfield) i działa przez łącznik Higgsfield w Claude: użyj jej tylko, gdy `zlecenie.katana` jest `true`, i powiedz wcześniej, ile kredytów zużyje.
