---
name: napisy
description: Generator napisów ze Studio Nadamedia. Dodaje napisy w wybranym stylu do gotowych filmów z folderu zlecenia. Uruchamiane poleceniem /napisy z danymi zlecenia w JSON.
disable-model-invocation: true
---

Dodaj napisy do filmów według tego zlecenia ze Studio Nadamedia:

$ARGUMENTS

Pracuj krok po kroku, po każdym kroku jedno krótkie zdanie, co jest zrobione.

## 1. Przygotowanie

- `zlecenie.folder` to folder z filmami (np. `napisy/2026-10-21_ief_napisy`). Jeśli nie ma w nim filmów, powiedz użytkownikowi, żeby wrzucił je przyciskiem „Utwórz folder” / „Otwórz folder” w Studio (Narzędzia), i poczekaj.
- Zapisz styl ze zlecenia do `<folder>/_napisy/styl.json` (pole `zlecenie.styl` bez zmian).
- Fonty: jeśli jest `klient`, fonty bierz z `<klient.folder>/fonty` (parametr `--fonty`). Brakujący font silnik pobierze sam z Google Fonts.

## 2. Rozpoznanie mowy

`python narzedzia/napisy.py transkrybuj --folder <folder> --jezyk <zlecenie.jezyk>` (pusty język: bez `--jezyk`, wykryje sam).
Krótkie filmy idą przez ElevenLabs, długie lokalnie przez Whisper, jeśli jest zainstalowany. Wcześniej rozpoznane filmy nie liczą się drugi raz.

## 3. Poprawa tekstu (gdy `popraw_tekst: true`)

Dla każdego filmu przeczytaj `_napisy/<film>_slowa.json` (jedno słowo w linii) i popraw narzędziem Edit tylko pole `"slowo"`:
- błędy rozpoznania, literówki, wielkie litery w nazwach własnych, nazwa klienta i produktów zgodnie z kartą klienta;
- interpunkcja na końcach zdań (kropka, pytajnik), bo od niej zależy podział napisów;
- zakazane słowa klienta (`zakazy_i_uwagi`): powiedz o nich, nie zmieniaj tego, co ktoś powiedział;
- nie ruszaj czasów (`start`, `koniec`) i nie łącz ani nie dziel słów, chyba że rozpoznanie skleiło dwa słowa w jedno (wtedy podziel czas po równo).
Jeśli styl ma `kluczowe_wl: true`, dopisz `"wazne": 1` do najważniejszego słowa w zdaniu (liczby, nazwy, obietnica), rzadziej `2` i `3`. Nie więcej niż co piąte słowo.
Gdy `pokaz_tekst_przed: true`: pokaż poprawiony tekst każdego filmu (same zdania, bez czasów) i poczekaj na „ok” albo poprawki.

## 4. Wypalenie

`python narzedzia/napisy.py wypal --folder <folder> --styl <folder>/_napisy/styl.json [--fonty <klient.folder>/fonty]`

Wynik: `<folder>/gotowe/<film>_napisy.mp4` i `<film>_napisy.srt`.

## 5. Kontrola

Z każdego gotowego filmu wytnij 3 kadry (`python narzedzia/montaz.py klatki --plik <wynik> --ile 3`) i obejrzyj je: napisy czytelne, nie wychodzą poza kadr, nie zasłaniają twarzy ani ważnych napisów w filmie. Jeśli zasłaniają, zmień `pozycja_y` w `styl.json` (np. z 66 na 75) i wypal ponownie; powiedz użytkownikowi, co zmieniłeś. Maksymalnie 2 poprawki bez pytania.

## 6. Raport

Krótko, po polsku:
- lista gotowych filmów (ścieżki) i folder `gotowe`
- font użyty w napisach (jeśli inny niż w stylu, napisz dlaczego)
- zużycie: minuty mowy rozpoznane przez ElevenLabs albo „lokalnie, za darmo”
- „Zużycie limitu Claude sprawdzisz poleceniem /usage. Przed kolejnym zadaniem wpisz /clear.”
