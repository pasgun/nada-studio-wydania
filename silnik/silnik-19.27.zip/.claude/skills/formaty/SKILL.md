---
name: formaty
description: Jedna gotowa grafika (najlepiej PSD) przerobiona na wiele rozmiarów naraz, z plikiem Photoshopa z artboardami. Uruchamiane poleceniem /formaty z danymi zlecenia w JSON ze Studio Nadamedia.
disable-model-invocation: true
---

Zlecenie ze Studio Nadamedia:

$ARGUMENTS

1. Grafika jest w `zlecenie.folder` (PSD, PSB, PNG albo JPG). Jeśli jest PSD i PNG tej samej grafiki, użyj PSD.
2. `python narzedzia/formaty.py --plik <grafika> --formaty <zlecenie.formaty po przecinku> [--fonty <klient.folder>/fonty]`
3. Obejrzyj podgląd (`gotowe/<nazwa>_podglad.jpg`). Sprawdź w każdym formacie: nic nie wychodzi poza kadr, teksty się nie nachodzą, logo nie wisi na środku zdjęcia, ważna część tła widoczna. Popraw przez `korekty.json` (opis na górze `formaty.py`; nazwy warstw są w wyniku) i uruchom ponownie z `--korekty`. Maksymalnie 3 poprawki.
4. Płaski PNG/JPG: narzędzie wstawia całą grafikę na rozmyte tło. Jeśli to wygląda słabo w bardzo innym formacie (np. 1:1 → 1584×396), zaproponuj przebudowę: odczytaj teksty z grafiki i złóż ją od nowa `grafika.py seria` (tło z grafiki albo nowe), i zapytaj przed tym.
5. Uwaga `uwaga_fonty`: przekaż ją (teksty bez fontu są obrazem; po wrzuceniu fontów do `fonty/` klienta będą ostre i edytowalne).
6. Raport: pliki, PSD (jeden plik, wszystkie rozmiary w rzędzie), uwagi.
