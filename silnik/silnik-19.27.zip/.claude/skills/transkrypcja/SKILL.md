---
name: transkrypcja
description: Transkrypcja nagrań z kodami czasowymi i mówcami (wywiady, podcasty, reportaże). Uruchamiane poleceniem /transkrypcja z danymi zlecenia w JSON ze Studio Nadamedia.
disable-model-invocation: true
---

Zlecenie ze Studio Nadamedia:

$ARGUMENTS

1. Pliki są w `zlecenie.folder`. Jeśli folder jest pusty, poproś o wrzucenie nagrań (przycisk w Studio) i poczekaj.
2. `python narzedzia/transkrypcja.py --folder <zlecenie.folder> --jezyk <zlecenie.jezyk> --mowcy --tc-start "<zlecenie.tc_start>" --fps <zlecenie.fps>` (pomiń puste parametry; `--mowcy`, gdy `zlecenie.mowcy` jest true; `--nazwy`, gdy podano imiona).
   Silnik: `--silnik subtitle-edit`, gdy `zlecenie.silnik` = „za darmo”; inaczej auto (ElevenLabs rozpoznaje mówców).
3. Gdy `zlecenie.popraw_tekst` jest true: przeczytaj każdy `_transkrypcja.txt` i popraw oczywiste błędy rozpoznania, nazwy własne (z kontekstu i z karty klienta), interpunkcję. Jeśli z rozmowy wynika, kto jest kim (przedstawiają się), zamień „Mówca 1” na imiona. Nie zmieniaj sensu wypowiedzi ani kodów czasowych.
4. Raport: lista plików txt i srt, minuty i silnik, mówcy. Przypomnij, że SRT importuje się w Premiere/DaVinci jako napisy.
