---
name: pion
description: Z filmu poziomego robi pionowy 9:16, z kadrem podążającym za twarzą albo za osobą, która mówi. Uruchamiane poleceniem /pion z danymi zlecenia w JSON ze Studio Nadamedia.
disable-model-invocation: true
---

Zlecenie ze Studio Nadamedia:

$ARGUMENTS

1. Filmy są w `zlecenie.folder`. Pusty folder: poproś o wrzucenie filmów i poczekaj.
2. Tryb `zlecenie.tryb`:
   - `twarz`: `python narzedzia/pion.py --folder <folder> --tryb twarz --format <zlecenie.format>`
   - `mowca` (rozmowa w szerokim planie): dla każdego filmu najpierw `python narzedzia/mowa.py --plik <film> --mowcy`, wytnij kadr (`ffmpeg -ss 5 -i <film> -frames:v 1 kadr.jpg`), obejrzyj go (Read) i z kilku pierwszych zdań w pliku słów ustal, który mówca siedzi z lewej, a który z prawej. Potem `python narzedzia/pion.py --plik <film> --tryb mowca --slowa <plik słów> --mapa "1=lewo,2=prawo" --wyjscie <folder>/gotowe/<film>_pion.mp4`
   - `srodek`: `--tryb srodek`
3. Obejrzyj `_podglad.jpg` każdego wyniku. Jeśli twarz jest ucięta albo kadr skacze bez sensu, powtórz z `--plynnosc 0.8` (spokojniej) albo zmień tryb; maksymalnie 2 próby bez pytania.
4. Jeśli `zlecenie.napisy` to styl napisów: dodaj napisy do gotowych pionów generatorem (`napisy.py transkrybuj` i `wypal` na folderze `gotowe`).
5. Raport: ścieżki, procent kadrów z twarzą, uwagi.
