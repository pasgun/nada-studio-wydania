---
name: miniatury
description: Miniatury YouTube z kadrów filmu, w barwach marki, z plikiem Photoshopa. Uruchamiane poleceniem /miniatury z danymi zlecenia w JSON ze Studio Nadamedia.
disable-model-invocation: true
---

Zlecenie ze Studio Nadamedia:

$ARGUMENTS

1. Film jest w `zlecenie.folder` (jeśli są też zdjęcia, możesz ich użyć jako teł). Marka: `python narzedzia/marka.py sprawdz --folder <klient.folder>` (sekcja „Marka i brandbook” w `CLAUDE.md`), gdy jest klient.
2. `python narzedzia/miniatury.py klatki --plik <film> --ile 12` i obejrzyj `klatki_arkusz.jpg` (Read). Wybierz kadry: wyraźna twarz z emocją, ostro, czytelnie w małym rozmiarze. Pole `twarz.strona` mówi, gdzie jest twarz: tekst stawiasz po drugiej stronie (`uklad`: twarz z prawej → `lewo`, z lewej → `prawo`).
3. Teksty: 2–5 słów, duże, mocne, zgodne z tematem z `zlecenie.temat` i tytułem filmu; 1 słowo wyróżnione w `*gwiazdkach*`. Bez podtytułu i CTA, chyba że zlecenie mówi inaczej. Liczba wersji: `zlecenie.liczba` (różne kadry albo różne teksty).
4. Zbuduj `<folder>/gotowe/seria.json` (formaty `["yt-1280x720"]`, tło = wybrany kadr, `fokus_x/y` na twarz, kolory i font z marki) i uruchom `python narzedzia/grafika.py seria --plan <folder>/gotowe/seria.json`. Plik PSD powstanie sam.
5. Obejrzyj `podglad_serii.jpg`: tekst musi być czytelny w miniaturze 320 px szerokości i nie zasłaniać twarzy. Popraw maksymalnie 2 razy.
6. Raport: pliki PNG, PSD, które wersje polecasz i dlaczego (jedno zdanie).
