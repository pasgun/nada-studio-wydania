---
name: multicam
description: Montaż multicam podcastu z sekwencji Premiere (XML): kamera przełącza się na osobę, która mówi do swojego mikrofonu, z odpornością na przebicia, czystym dźwiękiem jak Adobe Podcast i opcjonalnym cięciem ciszy i wpadek. Uruchamiane poleceniem /multicam z danymi w JSON ze Studio. Najwygodniej działa jako panel w Premiere.
disable-model-invocation: true
---

Zlecenie:

$ARGUMENTS

1. Potrzebny jest XML sekwencji z Premiere (`zlecenie.xml`; Plik > Eksportuj > Final Cut Pro XML). Brak: poproś o eksport albo zaproponuj panel w Premiere (`python narzedzia/panel_premiere.py --instaluj`, potem kafel „Multicam podcastu”).
2. Folder wyników: `python narzedzia/wspolne.py --klient "<klient>" --projekt "<nazwa> multicam"`.
3. Zapisz `<folder>/uklad.json` z `zlecenie.uklad` (opis pól na górze `narzedzia/multicam.py`). Jeśli użytkownik nie podał, które ścieżki to kto: przeczytaj XML (nazwy klipów na ścieżkach V i A) i ustal sam (zwykle V1 plan ogólny, V2 prowadzący, V3 gość, A1/A2 mikrofony); napisz, co przyjąłeś.
4. `python narzedzia/multicam.py analizuj --xml <xml> --folder <folder> --uklad <folder>/uklad.json`. Sprawdź `udzial_kamer_min` i `srednie_ujecie_s`: jeśli jedna osoba ma podejrzanie mało ekranu, a mówi dużo (`mowa_min`), podnieś `przebicia_db` albo obniż `czulosc` i powtórz.
5. `python narzedzia/multicam.py zastosuj --xml <xml> --folder <folder>` + `--dzwiek --moc <0-100> --silnik elevenlabs|ffmpeg`, gdy zlecenie chce czystego dźwięku.
6. Gdy `zlecenie.ciecie`: `python narzedzia/ciecie.py analizuj --xml "<xml z kroku 5>" --folder <folder>/ciecie ...`, wpadki jak w skillu `ciecie`, potem `zastosuj`.
7. Raport: ścieżka XML do importu (Plik > Importuj), liczba ujęć, udział kamer, nowe ścieżki z czystym dźwiękiem, uwagi (nieaktywne ujęcia są wyłączone, Shift+E włącza).
