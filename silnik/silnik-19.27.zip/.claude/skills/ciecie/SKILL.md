---
name: ciecie
description: Cięcie ciszy i wpadek w sekwencji z Premiere albo DaVinci Resolve bez panelu (przez plik XML). Uruchamiane poleceniem /ciecie z danymi zlecenia w JSON ze Studio Nadamedia.
disable-model-invocation: true
---

Zlecenie ze Studio Nadamedia:

$ARGUMENTS

Najwygodniej robi się to panelem w Premiere (Okno > Rozszerzenia > Studio Nadamedia). To polecenie jest dla DaVinci Resolve i dla sytuacji bez panelu.

1. W `zlecenie.folder` ma leżeć sekwencja zapisana jako XML:
   - Premiere: Plik > Eksportuj > Final Cut Pro XML
   - DaVinci Resolve: prawy klik na osi czasu w Media Pool > Timelines > Export > Timeline (FCP 7 XML .xml)
   Jeśli pliku nie ma, powiedz o tym krótko (z tą instrukcją) i poczekaj.
2. `python narzedzia/ciecie.py analizuj --xml <plik.xml> --folder <zlecenie.folder>/gotowe --jezyk <zlecenie.jezyk> --min-pauza <zlecenie.min_pauza> --zostaw <zlecenie.zostaw>`
3. Jeśli `zlecenie.wpadki` to nie `pomin`: wykonaj polecenia z `narzedzia/prompty/wpadki.md` (podstaw `{FOLDER}` = `<zlecenie.folder>/gotowe`) i zapisz wynik do `<zlecenie.folder>/gotowe/wpadki.json`.
4. `python narzedzia/ciecie.py zastosuj --xml <plik.xml> --folder <zlecenie.folder>/gotowe --wpadki <zlecenie.wpadki>` (dodaj `--bez-ciszy`, jeśli `zlecenie.cisza` jest false).
5. Raport: ścieżka do nowego XML i jak go zaimportować (Premiere: Plik > Importuj; DaVinci: File > Import > Timeline), ile było i jest minut, lista wpadek z `raport.txt` (krótko), pole `uwagi`. Przypomnij: oryginalna sekwencja zostaje bez zmian.
