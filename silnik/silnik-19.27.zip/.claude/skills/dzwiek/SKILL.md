---
name: dzwiek
description: Poprawa dźwięku mowy hurtem (jak Adobe Podcast Enhance) dla wszystkich plików z folderu zlecenia. Uruchamiane poleceniem /dzwiek z danymi zlecenia w JSON ze Studio Nadamedia.
disable-model-invocation: true
---

Zlecenie ze Studio Nadamedia:

$ARGUMENTS

1. Pliki są w `zlecenie.folder`. Pusty folder: poproś o wrzucenie plików i poczekaj.
2. `python narzedzia/dzwiek.py hurtem --folder <zlecenie.folder> --moc <zlecenie.moc> --silnik <zlecenie.silnik>`
   (`elevenlabs` = AI, najbliżej Adobe Podcast, kredyty ElevenLabs; `ffmpeg` = darmowa, lżejsza obróbka)
3. Raport: lista gotowych plików (`gotowe/`), łączne minuty i koszt. Jedno zdanie: wideo ma nietknięty obraz i nowy dźwięk; jeśli głos brzmi zbyt „sztucznie”, zrób jeszcze raz z mniejszą mocą (np. 60).
