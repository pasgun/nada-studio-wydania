"""Napisy w stylu Submagic: fragment zdania w stałym miejscu, wypowiadane słowo wyróżnione (kolor, tło, „pop”).

Ten sam styl (JSON) ustawiasz w Studio. Działa w montażu rolek (montaz.py) i jako osobne narzędzie
do gotowych filmów (generator napisów):

  python narzedzia/napisy.py transkrybuj --folder napisy/2026-10-21_ief [--jezyk pl] [--silnik auto|elevenlabs|lokalnie]
      -> napisy/.../_napisy/<film>_slowa.json (jedno słowo w linii; można poprawić słowa i dopisać "wazne": 1|2|3)
  python narzedzia/napisy.py wypal --folder napisy/2026-10-21_ief --styl styl.json
      -> napisy/.../gotowe/<film>_napisy.mp4 + <film>_napisy.srt
  Filmy przeciągnięte w Studio (z dowolnego miejsca na dysku): --folder to wtedy tylko folder roboczy zlecenia,
  a filmy idą w --pliki '["D:/rolki/a.mp4", ...]' przy obu krokach:
  python narzedzia/napisy.py transkrybuj --folder <folder zlecenia> --pliki '[...]'
  python narzedzia/napisy.py wypal --folder <folder zlecenia> --pliki '[...]' --styl styl.json [--zapis obok|folder --do D:/gotowe] [--dopisek _SUB]
      -> obok oryginału (albo w --do): a_SUB.mp4 + a_SUB.srt; oryginał zostaje nietknięty
  python narzedzia/napisy.py sekwencja --xml seq.xml --folder X --styl styl.json --W 1080 --H 1920   (panel Premiere: przezroczysty MOV)
  python narzedzia/napisy.py segmenty --xml seq.xml --folder X --styl styl.json --W 1080 --H 1920    (panel: każdy napis osobnym klipem + napisy.json)
  python narzedzia/napisy.py popraw --folder X --zmiany '[{"id":3,"tekst":"nowy"}]' [--styl S --wszystkie]   (panel: poprawki napisów)
  python narzedzia/napisy.py podglad --styl styl.json [--plik film.mp4] --wyjscie podglad.png

--styl przyjmuje ścieżkę do pliku JSON albo sam JSON. Pola stylu (wszystkie opcjonalne):
  slow_na_raz 1–8, max_linii 1–3, tryb "fraza" (cały fragment widoczny) | "narastajaco" (słowa dochodzą),
  font, grubosc 100–900, rozmiar (px przy szerokości 1080), litery "normalne" | "wielkie" | "male",
  pozycja_y (% wysokości: środek PIERWSZEJ linii, więc tekst nie skacze), pozycja_x (%),
  kolor, aktywne_kolor, aktywne_tlo, aktywne_tlo_wl, aktywne_skala (np. 1.1),
  obrys (grubość px, 0 = brak), obrys_kolor, cien (0–20), cien_kolor, tlo_krycie (0–100), tlo_kolor,
  animacja "brak" | "pop" | "mocny-pop" | "delikatny" | "podskok", kluczowe_wl, kluczowe ["#k1","#k2","#k3"], rozstaw (odstęp linii, 1.15),
  przytrzymaj_s (ile fragment wisi po ostatnim słowie, 0.5), kursywa (true/false),
  tlo_tryb "linia" (tło pod każdą linią) | "blok" (jedno tło pod całym fragmentem) | "slowa" (tło pod każdym słowem), tlo_zaokr (0–1, zaokrąglenie tła),
  aktywne_ksztalt "prostokat" | "pigulka" | "kwadrat" | "podkreslenie" | "marker" (pół słowa jak zakreślacz),
  nieaktywne_krycie (0–100: przygaszenie słów, które nie są właśnie wypowiadane).
Słowa kluczowe: w pliku słów pole "wazne": 1, 2 albo 3 = kolor z listy "kluczowe" (gdy kluczowe_wl).
"""
import argparse
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import KATALOG_SILNIKA, blad, wynik  # noqa: E402
import fonty  # noqa: E402

DOMYSLNY = {
    "slow_na_raz": 3, "max_linii": 2, "tryb": "fraza",
    "font": "Montserrat", "grubosc": 800, "rozmiar": 72, "litery": "wielkie",
    "pozycja_y": 66, "pozycja_x": 50,
    "kolor": "#FFFFFF", "aktywne_kolor": "#FFFFFF", "aktywne_tlo": "#7C3AED", "aktywne_tlo_wl": True, "aktywne_skala": 1.0,
    "obrys": 0, "obrys_kolor": "#000000", "cien": 6, "cien_kolor": "#000000",
    "tlo_krycie": 0, "tlo_kolor": "#000000", "animacja": "pop",
    "kluczowe_wl": False, "kluczowe": ["#22C55E", "#FACC15", "#EF4444"], "rozstaw": 1.15, "przytrzymaj_s": 0.5,
    "kursywa": False, "tlo_tryb": "linia", "tlo_zaokr": 0.22, "aktywne_ksztalt": "prostokat", "nieaktywne_krycie": 100,
}
ROZSZ_WIDEO = {".mp4", ".mov", ".m4v", ".mkv", ".webm", ".avi", ".mts", ".mxf"}


def sciezka(p):
    p = Path(p)
    return p if p.is_absolute() else KATALOG_SILNIKA / p


def hex_rgba(h, alfa=255, dom=(255, 255, 255)):
    h = (h or "").strip().lstrip("#")
    if len(h) == 8:  # RRGGBBAA
        return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4, 6))
    if len(h) == 6:
        return (*[int(h[i:i + 2], 16) for i in (0, 2, 4)], alfa)
    return (*dom, alfa)


def wczytaj_styl(styl):
    """Styl z pliku, tekstu JSON albo słownika; obsługuje też stare pola z plan.json (podswietlenie, pozycja 0–1...)."""
    if styl is None:
        styl = {}
    if isinstance(styl, (str, Path)):
        t = str(styl).strip()
        styl = json.loads(t) if t.startswith("{") else json.loads(sciezka(t).read_text(encoding="utf-8"))
    s = dict(styl)
    if "podswietlenie" in s and "aktywne_kolor" not in s:  # stary format napisów
        s["aktywne_kolor"] = s["podswietlenie"]
        s.setdefault("aktywne_tlo_wl", False)
        s.setdefault("obrys", 4)
        s.setdefault("cien", 0)
        s.setdefault("animacja", "brak")
    if "pozycja" in s and "pozycja_y" not in s:
        p = float(s["pozycja"])
        s["pozycja_y"] = p * 100 if p <= 1 else p
    if "max_slow" in s and "slow_na_raz" not in s:
        s["slow_na_raz"] = s["max_slow"]
    if "wielkie_litery" in s and "litery" not in s:
        s["litery"] = "wielkie" if s["wielkie_litery"] else "normalne"
    wyn = {**DOMYSLNY, **{k: v for k, v in s.items() if v is not None}}
    wyn["slow_na_raz"] = max(1, min(8, int(wyn["slow_na_raz"])))
    wyn["max_linii"] = max(1, min(3, int(wyn["max_linii"])))
    return wyn


class Uklad:
    """Wymiary i fonty dla danego kadru."""

    def __init__(self, styl, W, H, folder_fontow=None):
        self.s, self.W, self.H = styl, W, H
        self.k = min(W, H) / 1080  # skala: rozmiary w stylu są podane dla kadru o szerokości 1080
        self.r = max(8, int(float(styl["rozmiar"]) * self.k))
        self.font_plik, self.waga = fonty.znajdz_wage(styl.get("font"), int(styl.get("grubosc", 700)), folder_fontow, kursywa=bool(styl.get("kursywa")))
        if not self.font_plik:
            blad("Nie znalazłem żadnego fontu do napisów. Wrzuć plik .ttf do folderu fonty/ klienta.")
        self._fonty = {}
        self.font = self.f(self.r)
        self.lh = int(self.r * float(styl.get("rozstaw", 1.15)))
        self.max_w = W * (0.84 if H >= W else 0.62)
        self.spacja = self.font.getlength(" ") * (1.35 if styl.get("aktywne_tlo_wl") else 1.0)
        self.pad = int(self.r * 0.9 + float(styl.get("cien", 0)) * self.k * 1.5)
        y1 = H * float(styl["pozycja_y"]) / 100
        self.wys = self.lh * styl["max_linii"] + 2 * self.pad
        self.gora = int(min(max(y1 - self.lh / 2 - self.pad, 0), H - self.wys))
        self.y1 = y1 - self.gora  # środek pierwszej linii w pasku
        self.cx = W * float(styl["pozycja_x"]) / 100

    def f(self, rozmiar):
        rozmiar = max(6, int(rozmiar))
        if rozmiar not in self._fonty:
            self._fonty[rozmiar] = fonty.wczytaj(self.font_plik, rozmiar, self.waga)
        return self._fonty[rozmiar]

    def tekst(self, t):
        lit = self.s.get("litery")
        return t.upper() if lit == "wielkie" else t.lower() if lit == "male" else t

    def _zawin(self, szer_slow, max_w):
        linie, biez, szer = [], [], 0.0
        for i, sz in enumerate(szer_slow):
            nowa = szer + (self.spacja if biez else 0) + sz
            if biez and nowa > max_w:
                linie.append(biez)
                biez, nowa = [], sz
            biez.append(i)
            szer = nowa
        if biez:
            linie.append(biez)
        return linie

    def linie(self, slowa):
        """Podział słów na linie mieszczące się w szerokości, z wyrównaną długością linii (bez sierot).
        Zwraca listę list indeksów albo None (za dużo linii)."""
        szer_slow = [self.font.getlength(self.tekst(w["slowo"])) for w in slowa]
        linie = self._zawin(szer_slow, self.max_w)
        if len(linie) > self.s["max_linii"]:
            return None
        if len(linie) > 1:
            lacznie = sum(szer_slow) + self.spacja * (len(slowa) - 1)
            w = max(max(szer_slow), lacznie / len(linie))
            while w < self.max_w:
                proba = self._zawin(szer_slow, w)
                if len(proba) == len(linie):
                    return proba
                w *= 1.03
        return linie


def porcje(slowa, u):
    """Fragmenty zdań do pokazania naraz: max slow_na_raz słów, mieszczące się w max_linii; nowy fragment po końcu zdania i pauzie."""
    wyn, biez = [], []
    for i, w in enumerate(slowa):
        if biez and (w.get("nowa") or len(biez) >= u.s["slow_na_raz"] or u.linie(biez + [w]) is None):
            wyn.append(biez)
            biez = []
        biez.append(w)
        koniec_zdania = w["slowo"][-1:] in ".!?…"
        pauza = i + 1 < len(slowa) and slowa[i + 1]["start"] - w["koniec"] > 0.6
        if koniec_zdania or pauza:
            wyn.append(biez)
            biez = []
    if biez:
        wyn.append(biez)
    return wyn


def rysuj(por, u, aktywny=None, skala=1.0, widoczne_do=None):
    """Jeden stan napisu jako pasek RGBA (szerokość kadru × u.wys)."""
    from PIL import Image, ImageDraw, ImageFilter

    s = u.s
    img = Image.new("RGBA", (u.W, u.wys), (0, 0, 0, 0))
    if not por:
        return img
    linie = u.linie(por) or [list(range(len(por)))]
    teksty = [u.tekst(w["slowo"]) for w in por]
    szer = [u.font.getlength(t) for t in teksty]
    poz = {}  # indeks słowa -> (x lewej krawędzi, y środka linii)
    for li, ln in enumerate(linie):
        lw = sum(szer[i] for i in ln) + u.spacja * (len(ln) - 1)
        x = min(max(u.cx - lw / 2, u.W * 0.04), u.W * 0.96 - lw)
        y = u.y1 + li * u.lh
        for i in ln:
            poz[i] = (x, y)
            x += szer[i] + u.spacja
    widoczne = [i for i in range(len(por)) if widoczne_do is None or i <= widoczne_do]
    obrys = int(round(float(s.get("obrys", 0)) * u.k))
    obrys_k = hex_rgba(s.get("obrys_kolor"), 255, (0, 0, 0))

    # 1. tło pod całą linią
    krycie = int(float(s.get("tlo_krycie", 0)) * 2.55)
    if krycie > 0:
        warstwa = Image.new("RGBA", img.size, (0, 0, 0, 0))
        d = ImageDraw.Draw(warstwa)
        tryb_tla, zaokr = s.get("tlo_tryb", "linia"), float(s.get("tlo_zaokr", 0.22))
        kol_tla = hex_rgba(s.get("tlo_kolor"), krycie, (0, 0, 0))
        prost = []
        for ln in linie:
            ln_w = [i for i in ln if i in widoczne]
            if not ln_w:
                continue
            if tryb_tla == "slowa":
                for i in ln_w:
                    prost.append([poz[i][0] - u.r * 0.18, poz[i][1] - u.r * 0.6, poz[i][0] + szer[i] + u.r * 0.18, poz[i][1] + u.r * 0.6])
                continue
            prost.append([poz[ln_w[0]][0] - u.r * 0.3, poz[ln_w[0]][1] - u.r * 0.62, poz[ln_w[-1]][0] + szer[ln_w[-1]] + u.r * 0.3, poz[ln_w[0]][1] + u.r * 0.62])
        if tryb_tla == "blok" and prost:
            prost = [[min(p[0] for p in prost) - u.r * 0.1, prost[0][1] - u.r * 0.12, max(p[2] for p in prost) + u.r * 0.1, prost[-1][3] + u.r * 0.12]]
        for pr in prost:
            d.rounded_rectangle(pr, radius=min((pr[3] - pr[1]) / 2, u.r * 1.24 * zaokr), fill=kol_tla)
        img.alpha_composite(warstwa)

    przygas = max(0.0, min(1.0, float(s.get("nieaktywne_krycie", 100)) / 100))

    def kolor_slowa(i):
        if i == aktywny:
            return hex_rgba(s.get("aktywne_kolor"))
        w = por[i]
        if s.get("kluczowe_wl") and w.get("wazne") in (1, 2, 3):
            lista = s.get("kluczowe") or DOMYSLNY["kluczowe"]
            return hex_rgba(lista[min(len(lista), int(w["wazne"])) - 1])
        k = hex_rgba(s.get("kolor"))
        return k if przygas >= 1 or aktywny is None else k[:3] + (int(k[3] * przygas),)

    def rysuj_slowo(d, i, fill, stroke=True, stroke_fill=None):
        x, y = poz[i]
        sf = obrys_k if stroke_fill is None else stroke_fill
        if i == aktywny and skala != 1.0:
            f = u.f(u.r * skala)
            d.text((x + szer[i] / 2, y), teksty[i], font=f, fill=fill, anchor="mm",
                   stroke_width=int(obrys * skala) if stroke else 0, stroke_fill=sf)
        else:
            d.text((x, y), teksty[i], font=u.font, fill=fill, anchor="lm", stroke_width=obrys if stroke else 0, stroke_fill=sf)

    # 2. cień (rozmyta kopia tekstu)
    cien = float(s.get("cien", 0))
    if cien > 0:
        maska = Image.new("L", img.size, 0)
        dm = ImageDraw.Draw(maska)
        for i in widoczne:
            rysuj_slowo(dm, i, 255, stroke_fill=255)  # maska jest jednokanałowa
        maska = maska.filter(ImageFilter.GaussianBlur(cien * u.k * 0.9))
        przes = int(cien * u.k * 0.35)
        ck = hex_rgba(s.get("cien_kolor"), 255, (0, 0, 0))
        warstwa = Image.new("RGBA", img.size, ck[:3] + (0,))
        warstwa.putalpha(maska.point(lambda v: min(255, int(v * min(1.0, 0.55 + cien / 25)))))
        img.alpha_composite(warstwa, (0, przes))

    d = ImageDraw.Draw(img)
    # 3. tło pod wypowiadanym słowem
    if aktywny is not None and aktywny in widoczne and s.get("aktywne_tlo_wl"):
        x, y = poz[aktywny]
        cx_ = x + szer[aktywny] / 2
        bw = szer[aktywny] * skala / 2 + u.r * 0.16 * skala
        bh = u.r * 0.6 * skala
        ksz, kt = s.get("aktywne_ksztalt", "prostokat"), hex_rgba(s.get("aktywne_tlo"), 255)
        if ksz == "podkreslenie":
            d.rounded_rectangle([cx_ - bw + u.r * 0.1, y + bh * 0.62, cx_ + bw - u.r * 0.1, y + bh * 0.95], radius=u.r * 0.08, fill=kt)
        elif ksz == "marker":
            d.rectangle([cx_ - bw, y - bh * 0.05, cx_ + bw, y + bh * 0.72], fill=kt[:3] + (int(kt[3] * 0.85),))
        else:
            rad = {"pigulka": bh, "kwadrat": 0}.get(ksz, u.r * 0.2 * skala)
            d.rounded_rectangle([cx_ - bw, y - bh, cx_ + bw, y + bh], radius=rad, fill=kt)
    # 4. słowa (aktywne na wierzchu)
    for i in widoczne:
        if i != aktywny:
            rysuj_slowo(d, i, kolor_slowa(i))
    if aktywny is not None and aktywny in widoczne:
        rysuj_slowo(d, aktywny, kolor_slowa(aktywny))
    return img


def plan_stanow(slowa, u, fps, calosc):
    """Lista (czas_od, czas_do, por, aktywny, skala, widoczne_do) z czasami równymi klatkom."""
    s = u.s
    ps = porcje(slowa, u)
    przyt = float(s.get("przytrzymaj_s", 0.5))
    anim = s.get("animacja", "brak")
    bazowa = float(s.get("aktywne_skala", 1.0))
    krzywa = {"pop": [1.22, 1.12, 1.05], "mocny-pop": [1.38, 1.24, 1.12, 1.04], "delikatny": [1.08, 1.04], "podskok": [0.86, 1.14, 1.04]}.get(anim, [])
    q = lambda t: round(t * fps) / fps  # noqa: E731
    stany, srt = [], []
    for pi, por in enumerate(ps):
        nastepna = ps[pi + 1][0]["start"] if pi + 1 < len(ps) else None
        koniec = por[-1]["koniec"] + przyt
        if nastepna is not None:
            koniec = min(koniec, nastepna)
        koniec = min(koniec, calosc)
        srt.append((max(0.0, por[0]["start"] - 0.05), koniec, tekst_porcji(por, u)))
        stany += stany_porcji(por, u, fps, koniec)
    return stany, srt


def tekst_porcji(por, u):
    return "\n".join(" ".join(por[i]["slowo"] for i in ln) for ln in (u.linie(por) or [list(range(len(por)))]))


def stany_porcji(por, u, fps, koniec):
    """Stany (czas_od, czas_do, por, aktywny, skala, widoczne_do) jednego fragmentu napisu, od jego pierwszego słowa do końca."""
    s = u.s
    anim = s.get("animacja", "brak")
    bazowa = float(s.get("aktywne_skala", 1.0))
    krzywa = {"pop": [1.22, 1.12, 1.05], "mocny-pop": [1.38, 1.24, 1.12, 1.04], "delikatny": [1.08, 1.04], "podskok": [0.86, 1.14, 1.04]}.get(anim, [])
    q = lambda t: round(t * fps) / fps  # noqa: E731
    stany = []
    for j, w in enumerate(por):
        od = q(max(0.0, w["start"] - (0.05 if j == 0 else 0)))
        do = q(por[j + 1]["start"]) if j + 1 < len(por) else q(koniec)
        if do <= od:
            continue
        wid = j if s.get("tryb") == "narastajaco" else None
        t = od
        for sk in krzywa:
            if t + 1 / fps > do:
                break
            stany.append((t, t + 1 / fps, por, j, sk * bazowa, wid))
            t += 1 / fps
        if do > t:
            stany.append((t, do, por, j, bazowa, wid))
    return stany


def nakladka(slowa, styl, W, H, fps, folder, calosc, folder_fontow=None):
    """Renderuje napisy do PNG-ów i listy dla ffmpeg (concat). Zwraca dict: lista, y (górna krawędź paska), srt, font."""
    from PIL import Image

    styl = wczytaj_styl(styl)
    folder = Path(folder)
    if folder.exists():
        shutil.rmtree(folder)
    folder.mkdir(parents=True)
    u = Uklad(styl, W, H, folder_fontow)
    slowa = sorted([w for w in slowa if str(w.get("slowo", "")).strip()], key=lambda w: w["start"])
    stany, srt = plan_stanow(slowa, u, fps, calosc)
    pusty = folder / "pusty.png"
    Image.new("RGBA", (W, u.wys), (0, 0, 0, 0)).save(pusty)
    wpisy, t = [], 0.0
    for n, (od, do, por, akt, sk, wid) in enumerate(stany):
        if od > t + 1e-6:
            wpisy.append((pusty.name, od - t))
        plik = folder / f"n{n:05d}.png"
        rysuj(por, u, akt, sk, wid).save(plik, compress_level=1)
        wpisy.append((plik.name, do - od))
        t = do
    if calosc > t:
        wpisy.append((pusty.name, calosc - t))
    lista = folder / "lista.txt"
    tekst = "ffconcat version 1.0\n" + "".join(f"file '{p}'\nduration {d:.6f}\n" for p, d in wpisy)
    tekst += f"file '{wpisy[-1][0] if wpisy else pusty.name}'\n"
    lista.write_text(tekst, encoding="utf-8")
    return {"lista": lista, "y": u.gora, "srt": srt, "font": u.font_plik, "stanow": len(stany)}


def slowa_z_linii(linie_wlasne):
    """Gotowe linie bez czasu słów (np. tłumaczenie): czas rozkładany proporcjonalnie do długości słów."""
    wyn = []
    for l in linie_wlasne or []:
        slowa = l["tekst"].split()
        od, do = float(l["od"]), float(l["do"])
        lacznie = sum(len(w) + 1 for w in slowa) or 1
        t = od
        for k, w in enumerate(slowa):
            dl = (do - od) * (len(w) + 1) / lacznie
            wyn.append({"slowo": w, "start": t, "koniec": t + dl * 0.92, "nowa": k == 0})
            t += dl
    return wyn


def zapisz_srt(wpisy, plik):
    """Napisy w formacie SRT (do importu w Premiere: Plik > Importuj, potem przeciągnij na oś czasu)."""
    def ts(x):
        x = max(0.0, x)
        h, r = divmod(x, 3600)
        m, r = divmod(r, 60)
        sek = int(r)
        return f"{int(h):02d}:{int(m):02d}:{sek:02d},{int(round((r - sek) * 1000)):03d}"
    bloki, poprz = [], 0.0
    for a, b, tekst in sorted(wpisy):
        a = max(a, poprz)  # bez nakładania się napisów (Premiere ich nie lubi)
        if b - a < 0.2:
            continue
        bloki.append(f"{len(bloki) + 1}\n{ts(a)} --> {ts(b)}\n{tekst}\n")
        poprz = b
    Path(plik).write_text("\n".join(bloki), encoding="utf-8")


# ---------- generator napisów do gotowych filmów ----------
def info_wideo(plik):
    r = subprocess.run(["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,r_frame_rate:stream_side_data=rotation",
                        "-show_entries", "format=duration", "-of", "json", str(plik)], capture_output=True, text=True, encoding="utf-8", errors="replace")
    d = json.loads(r.stdout or "{}")
    st = (d.get("streams") or [{}])[0]
    W, H = int(st.get("width", 1080)), int(st.get("height", 1920))
    rot = 0
    for sd in st.get("side_data_list") or []:
        rot = int(sd.get("rotation", 0) or 0)
    if abs(rot) in (90, 270):
        W, H = H, W
    a, b = (st.get("r_frame_rate") or "30/1").split("/")
    fps = float(a) / float(b or 1) if float(b or 1) else 30.0
    return W, H, fps if 10 < fps < 121 else 30.0, float((d.get("format") or {}).get("duration", 0) or 0)


def filmy(folder):
    folder = sciezka(folder)
    if not folder.exists():
        blad(f"Nie ma folderu {folder}. Utwórz go przyciskiem w Studio (Narzędzia > Generator napisów) i wrzuć filmy.")
    return sorted(p for p in folder.iterdir() if p.suffix.lower() in ROZSZ_WIDEO and not p.stem.endswith("_napisy"))


def filmy_z_listy(folder, pliki):
    """Filmy przeciągnięte w Studio (pełne ścieżki gdziekolwiek na dysku) albo, bez listy, filmy z folderu zlecenia.
    Zwraca listę (film, nazwa_robocza): nazwa robocza nie powtarza się, nawet gdy dwa pliki mają tę samą nazwę."""
    if not pliki:
        return [(p, p.stem) for p in filmy(folder)]
    wyn, uzyte = [], set()
    for x in pliki:
        p = Path(x)
        if not p.exists():
            blad(f"Nie widzę pliku {p} (przeniesiony albo usunięty?)")
        n, i = p.stem, 2
        while n in uzyte:
            n, i = f"{p.stem}_{i}", i + 1
        uzyte.add(n)
        wyn.append((p, n))
    return wyn


def zapisz_slowa(slowa, plik):
    """Jedno słowo w linii: łatwo poprawić pojedyncze słowo albo dopisać "wazne"."""
    linie = [json.dumps({k: w[k] for k in ("slowo", "start", "koniec", "wazne") if k in w}, ensure_ascii=False) for w in slowa]
    Path(plik).write_text("[\n" + ",\n".join(linie) + "\n]\n", encoding="utf-8")


def transkrybuj(folder, jezyk=None, silnik="auto", od_nowa=False, pliki=None):
    import mowa
    lista = filmy_z_listy(folder, pliki)
    if not lista:
        blad(f"W folderze {folder} nie ma filmów ({', '.join(sorted(ROZSZ_WIDEO))}).")
    robocze = sciezka(folder) / "_napisy"
    robocze.mkdir(parents=True, exist_ok=True)
    wyn = []
    for p, nazwa in lista:
        cel = robocze / f"{nazwa}_slowa.json"
        if cel.exists() and not od_nowa:
            slowa = json.loads(cel.read_text(encoding="utf-8"))
            wyn.append({"film": str(p) if pliki else p.name, "slowa": str(cel), "liczba_slow": len(slowa), "tekst": " ".join(w["slowo"] for w in slowa)[:1500], "uwaga": "transkrypcja z wcześniej"})
            continue
        W, H, fps, dl = info_wideo(p)
        t = mowa.transkrybuj(p, jezyk, silnik)
        t["tekst"] = " ".join(w["slowo"] for w in t["slowa"])
        zapisz_slowa(t["slowa"], cel)
        wyn.append({"film": str(p) if pliki else p.name, "slowa": str(cel), "liczba_slow": len(t["slowa"]), "dlugosc_s": round(dl, 1),
                    "silnik": t["silnik"], "jezyk": t["jezyk"], "tekst": t["tekst"][:1500]})
    wynik(filmy=wyn, nastepny_krok="Popraw błędy w słowach (pliki _slowa.json), opcjonalnie dopisz \"wazne\", potem: napisy.py wypal")


def wypal_plik(film, slowa_plik, styl, folder_fontow=None, wyjscie=None, robocze=None):
    film = sciezka(film)
    W, H, fps, dl = info_wideo(film)
    fps_r = round(fps, 3)
    slowa = json.loads(Path(slowa_plik).read_text(encoding="utf-8"))
    robocze = Path(robocze) if robocze else film.parent / "_napisy" / f"{film.stem}_klatki"
    nk = nakladka(slowa, styl, W, H, fps_r, robocze, dl, folder_fontow)
    wyjscie = Path(wyjscie) if wyjscie else film.parent / "gotowe" / f"{film.stem}_napisy.mp4"
    wyjscie.parent.mkdir(parents=True, exist_ok=True)
    args = ["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(film), "-f", "concat", "-safe", "0", "-i", nk["lista"].name,
            "-filter_complex", f"[0:v][1:v]overlay=0:{nk['y']}:eof_action=pass:format=auto,format=yuv420p[v]",
            "-map", "[v]", "-map", "0:a?", "-c:v", "libx264", "-preset", "medium", "-crf", "18", "-c:a", "copy",
            "-movflags", "+faststart", str(wyjscie.resolve())]
    r = subprocess.run(args, cwd=str(robocze), capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        blad(f"Wypalanie napisów w {film.name} nie powiodło się:\n{r.stderr[-1200:]}")
    srt = wyjscie.with_suffix(".srt")
    zapisz_srt(nk["srt"], srt)
    shutil.rmtree(robocze, ignore_errors=True)
    return {"film": film.name, "wynik": str(wyjscie), "srt": str(srt), "font": nk["font"], "rozmiar_mb": round(wyjscie.stat().st_size / 1e6, 1)}


def wypal(folder, styl, folder_fontow=None, pliki=None, zapis="obok", do=None, dopisek="_SUB"):
    """Bez listy plików: wyniki w <folder>/gotowe/<film>_napisy.mp4 (jak dotąd). Z listą przeciągniętą w Studio:
    zapis="obok" kładzie <film><dopisek>.mp4 obok oryginału, zapis="folder" w folderze `do`. Oryginałów nie zmienia."""
    styl = wczytaj_styl(styl)
    wyn = []
    for p, nazwa in filmy_z_listy(folder, pliki):
        sl = sciezka(folder) / "_napisy" / f"{nazwa}_slowa.json"
        if not sl.exists():
            wyn.append({"film": str(p), "blad": "brak transkrypcji, uruchom najpierw: napisy.py transkrybuj"})
            continue
        cel = None
        if pliki:
            baza = Path(do) if (zapis == "folder" and do) else p.parent
            baza.mkdir(parents=True, exist_ok=True)
            cel = baza / f"{p.stem}{dopisek or ''}.mp4"
            if cel.resolve() == p.resolve():  # nigdy nie nadpisuj oryginału
                cel = baza / f"{p.stem}{dopisek or '_SUB'}_napisy.mp4"
        wyn.append(wypal_plik(p, sl, styl, folder_fontow, cel, sciezka(folder) / "_napisy" / f"{nazwa}_klatki" if pliki else None))
    wynik(gotowe=wyn, folder=str(Path(do)) if (pliki and zapis == "folder" and do) else (None if pliki else str(sciezka(folder) / "gotowe")))


def podglad(styl, wyjscie, film=None, folder_fontow=None):
    from PIL import Image
    styl = wczytaj_styl(styl)
    if film:
        W, H, _, dl = info_wideo(sciezka(film))
        tmp = Path(tempfile.mkdtemp()) / "k.png"
        subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-ss", f"{dl / 3:.2f}", "-i", str(sciezka(film)), "-frames:v", "1", str(tmp)])
        tlo = Image.open(tmp).convert("RGBA").resize((W, H))
    else:
        W, H = 1080, 1920
        tlo = Image.new("RGBA", (W, H), (0, 0, 0, 255))
    u = Uklad(styl, W, H, folder_fontow)
    przyklad = [{"slowo": w, "start": i * 0.3, "koniec": i * 0.3 + 0.25, "wazne": 1 if i == 3 else None}
                for i, w in enumerate("Tak wyglądają Twoje napisy w rolce".split())]
    por = porcje(przyklad, u)[0]
    pasek = rysuj(por, u, aktywny=min(1, len(por) - 1), skala=float(styl.get("aktywne_skala", 1.0)))
    tlo.alpha_composite(pasek, (0, u.gora))
    tlo.convert("RGB").save(sciezka(wyjscie))
    wynik(podglad=str(sciezka(wyjscie)), font=u.font_plik)


def sekwencja(xml, folder, styl, W, H, jezyk=None, silnik="auto", folder_fontow=None, slowa_plik=None, od_nowa=False, audio=None):
    """Panel w Premiere: dźwięk sekwencji -> słowa -> przezroczysty MOV z napisami w stylu (na ścieżkę nad filmem) + SRT."""
    import ciecie
    import mowa
    from wspolne import postep
    folder = sciezka(folder)
    folder.mkdir(parents=True, exist_ok=True)
    styl = wczytaj_styl(styl)
    tree, root, seq, defs, fps = ciecie.zaladuj(xml)
    dl = ciecie.liczba(seq, "duration") / fps
    slowa_plik = Path(slowa_plik) if slowa_plik else folder / "slowa.json"
    if slowa_plik.exists() and not od_nowa:
        slowa = json.loads(slowa_plik.read_text(encoding="utf-8"))
        zrodlo = "poprawione słowa z pliku"
    else:
        postep("Zbieram dźwięk sekwencji")
        wav = folder / "dzwiek.wav"
        if audio and Path(audio).exists():
            # dźwięk osi wyeksportowany przez Premiere (tak, jak słychać: kanały, głośność, wyciszenia)
            ciecie.ff(["-i", audio, "-ac", "1", "-ar", 16000, "-c:a", "pcm_s16le", wav], "dźwięk osi z Premiere")
        else:
            ciecie.miks(seq, defs, wav, dl)
        postep("Rozpoznaję mowę")
        t = mowa.transkrybuj(wav, jezyk, silnik)
        slowa = t["slowa"]
        zapisz_slowa(slowa, slowa_plik)
        zrodlo = t.get("silnik", silnik)
    if not slowa:
        blad("Nie rozpoznałem żadnych słów w dźwięku tej sekwencji.")
    postep(f"Rysuję napisy ({len(slowa)} słów)")
    fps_r = round(fps, 3)
    robocze = folder / "_klatki"
    nk = nakladka(slowa, styl, W, H, fps_r, robocze, dl, folder_fontow)
    nr = 1
    while (folder / f"napisy_{nr}.mov").exists():
        nr += 1
    mov = folder / f"napisy_{nr}.mov"
    postep("Zapisuję film z napisami (przezroczyste tło)")
    r = subprocess.run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0", "-i", nk["lista"].name,
                        "-filter_complex", f"[0:v]format=rgba,pad={W}:{H}:0:{nk['y']}:color=black@0,fps={fps_r}[v]", "-map", "[v]",
                        "-t", f"{dl:.3f}", "-c:v", "qtrle", "-pix_fmt", "argb", str(mov.resolve())],
                       cwd=str(robocze), capture_output=True, text=True, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        blad(f"Zapis napisów nie powiódł się:\n{r.stderr[-1200:]}")
    srt = mov.with_suffix(".srt")
    zapisz_srt(nk["srt"], srt)
    shutil.rmtree(robocze, ignore_errors=True)
    wynik(mov=str(mov), srt=str(srt), slowa=str(slowa_plik), liczba_slow=len(slowa), dlugosc_s=round(dl, 2), font=nk["font"], zrodlo=zrodlo)


# ---------- panel Premiere: każdy napis osobnym klipem (usuwasz, przesuwasz, poprawiasz jak zwykłe klipy) ----------
def segmenty_ze_slow(slowa, u, calosc):
    """Fragmenty napisów z czasem: [{id, od, do, slowa}] (od/do = sekundy na osi sekwencji)."""
    slowa = sorted([w for w in slowa if str(w.get("slowo", "")).strip()], key=lambda w: w["start"])
    ps = porcje(slowa, u)
    przyt = float(u.s.get("przytrzymaj_s", 0.5))
    wyn, poprz = [], 0.0
    for pi, por in enumerate(ps):
        nastepna = ps[pi + 1][0]["start"] - 0.05 if pi + 1 < len(ps) else None
        koniec = por[-1]["koniec"] + przyt
        if nastepna is not None:
            koniec = min(koniec, nastepna)
        koniec = min(koniec, calosc) if calosc else koniec
        od = max(poprz, por[0]["start"] - 0.05, 0.0)  # klipy na jednej ścieżce nie mogą na siebie nachodzić
        if koniec - od < 0.1:
            koniec = od + 0.1
        poprz = koniec
        wyn.append({"id": pi + 1, "od": round(od, 3), "do": round(koniec, 3), "slowa": [{k: w[k] for k in ("slowo", "start", "koniec", "wazne") if k in w} for w in por]})
    return wyn


def przelicz_slowa(seg, tekst):
    """Nowy tekst fragmentu: przy tej samej liczbie słów zostają ich czasy, przy innej czas rozkłada się według długości słów."""
    nowe = str(tekst or "").split()
    stare = seg["slowa"]
    if len(nowe) == len(stare):
        return [dict(w, slowo=n) for w, n in zip(stare, nowe)]
    od = stare[0]["start"] if stare else seg["od"] + 0.05
    do = stare[-1]["koniec"] if stare else seg["do"]
    lacznie = sum(len(w) + 1 for w in nowe) or 1
    t, wyn = od, []
    for w in nowe:
        dl = (do - od) * (len(w) + 1) / lacznie
        wyn.append({"slowo": w, "start": round(t, 3), "koniec": round(t + dl * 0.92, 3)})
        t += dl
    return wyn


def renderuj_segmenty(segmenty, styl, W, H, fps, folder, folder_fontow=None, wersja=1, naPostep=None):
    """Każdy fragment = osobny przezroczysty MOV (pełna klatka, czas od początku fragmentu). Zwraca nazwę pliku przy każdym fragmencie."""
    from PIL import Image
    folder = Path(folder)
    robocze = folder / "_klatki_seg"
    shutil.rmtree(robocze, ignore_errors=True)
    robocze.mkdir(parents=True)
    u = Uklad(wczytaj_styl(styl), W, H, folder_fontow)
    pusty = robocze / "pusty.png"
    Image.new("RGBA", (W, u.wys), (0, 0, 0, 0)).save(pusty)
    procesy, bledy = [], []

    def czekaj(maks):
        while len(procesy) > maks:
            p, seg = procesy.pop(0)
            _, err = p.communicate()
            if p.returncode != 0:
                bledy.append(f"napis {seg['id']}: {err[-300:]}")

    for n, seg in enumerate(segmenty):
        kat = robocze / f"s{seg['id']:05d}"
        kat.mkdir()
        dl = max(0.1, seg["do"] - seg["od"])
        por = [dict(w) for w in seg["slowa"]] or [{"slowo": " ", "start": seg["od"], "koniec": seg["do"]}]
        wpisy, t = [], 0.0
        for k, (od, do, p_, akt, sk, wid) in enumerate(stany_porcji(por, u, fps, seg["do"])):
            od, do = max(0.0, od - seg["od"]), min(dl, do - seg["od"])
            if do <= od:
                continue
            if od > t + 1e-6:
                wpisy.append(("../pusty.png", od - t))
            plik = kat / f"n{k:04d}.png"
            rysuj(p_, u, akt, sk, wid).save(plik, compress_level=1)
            wpisy.append((plik.name, do - od))
            t = do
        if dl > t + 1e-6:
            wpisy.append(("../pusty.png", dl - t))
        lista = kat / "lista.txt"
        lista.write_text("ffconcat version 1.0\n" + "".join(f"file '{p}'\nduration {d:.6f}\n" for p, d in wpisy) + f"file '{wpisy[-1][0]}'\n", encoding="utf-8")
        nazwa = f"napis_{seg['id']:04d}" + (f"_v{wersja}" if wersja > 1 else "") + ".mov"
        seg["plik"] = nazwa
        p = subprocess.Popen(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-f", "concat", "-safe", "0", "-i", "lista.txt",
                              "-filter_complex", f"[0:v]format=rgba,pad={W}:{H}:0:{u.gora}:color=black@0,fps={fps}[v]", "-map", "[v]",
                              "-t", f"{dl:.3f}", "-c:v", "qtrle", "-pix_fmt", "argb", str((folder / nazwa).resolve())],
                             cwd=str(kat), stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")
        procesy.append((p, seg))
        czekaj(4)
        if naPostep:
            naPostep((n + 1) / len(segmenty))
    czekaj(0)
    shutil.rmtree(robocze, ignore_errors=True)
    if bledy:
        blad("Nie udało się zapisać części napisów:\n" + "\n".join(bledy[:5]))
    return u


def zapisz_projekt_napisow(folder, dane):
    (Path(folder) / "napisy.json").write_text(json.dumps(dane, ensure_ascii=False, indent=1), encoding="utf-8")


def srt_z_segmentow(segmenty, u, plik):
    zapisz_srt([(s["od"], s["do"], tekst_porcji(s["slowa"], u)) for s in segmenty if s.get("slowa")], plik)


def segmenty_sekwencji(xml, folder, styl, W, H, jezyk=None, silnik="auto", folder_fontow=None, slowa_plik=None, od_nowa=False, audio=None):
    """Panel w Premiere: dźwięk sekwencji -> słowa -> każdy fragment napisu jako osobny przezroczysty MOV + napisy.json + SRT."""
    import ciecie
    import mowa
    from wspolne import postep
    folder = sciezka(folder)
    folder.mkdir(parents=True, exist_ok=True)
    styl = wczytaj_styl(styl)
    tree, root, seq, defs, fps = ciecie.zaladuj(xml)
    dl = ciecie.liczba(seq, "duration") / fps
    slowa_plik = Path(slowa_plik) if slowa_plik else folder / "slowa.json"
    if slowa_plik.exists() and not od_nowa:
        slowa = json.loads(slowa_plik.read_text(encoding="utf-8"))
        zrodlo = "słowa z wcześniej"
    else:
        postep("Zbieram dźwięk sekwencji", 0.02)
        wav = folder / "dzwiek.wav"
        if audio and Path(audio).exists():
            # dźwięk osi wyeksportowany przez Premiere (tak, jak słychać: kanały, głośność, wyciszenia)
            ciecie.ff(["-i", audio, "-ac", "1", "-ar", 16000, "-c:a", "pcm_s16le", wav], "dźwięk osi z Premiere")
        else:
            ciecie.miks(seq, defs, wav, dl)
        postep("Rozpoznaję mowę (to trwa najdłużej)", 0.08)
        t = mowa.transkrybuj(wav, jezyk, silnik)
        slowa = t["slowa"]
        zapisz_slowa(slowa, slowa_plik)
        zrodlo = t.get("silnik", silnik)
    if not slowa:
        blad("Nie rozpoznałem żadnych słów w dźwięku tej sekwencji.")
    _segmenty_i_projekt(slowa, folder, styl, W, H, fps, dl, folder_fontow, slowa_plik, zrodlo)


def _segmenty_i_projekt(slowa, folder, styl, W, H, fps, dl, folder_fontow, slowa_plik, zrodlo):
    """Wspólny koniec: słowa -> przezroczyste MOV-y fragmentów + napisy.json + SRT (panel potem je poprawia)."""
    from wspolne import postep
    fps_r = round(fps, 3)
    u = Uklad(styl, W, H, folder_fontow)
    seg = segmenty_ze_slow(slowa, u, dl)
    postep(f"Rysuję napisy: {len(seg)} fragmentów", 0.5)
    u = renderuj_segmenty(seg, styl, W, H, fps_r, folder, folder_fontow, naPostep=lambda x: postep(f"Rysuję napisy: {len(seg)} fragmentów", 0.5 + 0.48 * x))
    srt = folder / "napisy.srt"
    srt_z_segmentow(seg, u, srt)
    dane = {"wersja": 1, "styl": styl, "W": W, "H": H, "fps": fps_r, "dlugosc_s": round(dl, 3), "segmenty": seg, "srt": str(srt), "slowa": str(slowa_plik), "font": u.font_plik}
    zapisz_projekt_napisow(folder, dane)
    postep("Gotowe", 1.0)
    wynik(projekt=str(folder / "napisy.json"), folder=str(folder), liczba=len(seg), liczba_slow=len(slowa), srt=str(srt), font=u.font_plik, zrodlo=zrodlo)


def segmenty_z_rolki(slowa_plik, folder, styl, W, H, fps, dlugosc, folder_fontow=None):
    """Projekt Premiere z gotowej rolki: te same słowa i ten sam styl, które montaż wypalił w filmie
    (bez ponownego rozpoznawania mowy) -> fragmenty napisów jako osobne klipy, do poprawiania w panelu."""
    folder = sciezka(folder)
    folder.mkdir(parents=True, exist_ok=True)
    slowa_plik = sciezka(slowa_plik)
    if not slowa_plik or not slowa_plik.exists():
        blad(f"Brak pliku ze słowami napisów: {slowa_plik}")
    slowa = json.loads(slowa_plik.read_text(encoding="utf-8"))
    if not slowa:
        blad("Rolka nie ma słów do napisów.")
    kopia = folder / "slowa.json"
    if kopia.resolve() != slowa_plik.resolve():
        zapisz_slowa(slowa, kopia)
    _segmenty_i_projekt(slowa, folder, wczytaj_styl(styl), W, H, fps, float(dlugosc), folder_fontow, kopia, "styl i słowa z rolki")


def popraw_segmenty(folder, zmiany=None, styl=None, wszystkie=False, folder_fontow=None):
    """Poprawki z panelu: nowy tekst fragmentu (zmiany: [{id, tekst}]) albo nowy styl dla wszystkich. Renderuje tylko to, co się zmieniło."""
    from wspolne import postep
    folder = sciezka(folder)
    plik = folder / "napisy.json"
    if not plik.exists():
        blad("Nie ma napisy.json w tym folderze: zrób napisy od nowa.")
    dane = json.loads(plik.read_text(encoding="utf-8"))
    if styl:
        dane["styl"] = wczytaj_styl(styl)
    po_id = {s["id"]: s for s in dane["segmenty"]}
    do_renderu = []
    for z in zmiany or []:
        s = po_id.get(int(z["id"]))
        if not s:
            continue
        if "tekst" in z:
            s["slowa"] = przelicz_slowa(s, z["tekst"])
        if "od" in z and "do" in z:
            # klip przesunięty albo przycięty na osi: czasy słów idą razem z nim
            prz = float(z["od"]) - s["od"]
            s["slowa"] = [dict(w, start=round(w["start"] + prz, 3), koniec=round(w["koniec"] + prz, 3)) for w in s["slowa"]]
            s["od"], s["do"] = round(float(z["od"]), 3), round(float(z["do"]), 3)
        if z.get("usun"):
            s["usuniety"] = True
            continue
        do_renderu.append(s)
    if wszystkie:
        do_renderu = [s for s in dane["segmenty"] if not s.get("usuniety")]
    dane["wersja"] = int(dane.get("wersja", 1)) + 1
    if do_renderu:
        postep(f"Rysuję {len(do_renderu)} napis(y)", 0.05)
        u = renderuj_segmenty(do_renderu, dane["styl"], dane["W"], dane["H"], dane["fps"], folder, folder_fontow, wersja=dane["wersja"],
                              naPostep=lambda x: postep(f"Rysuję {len(do_renderu)} napis(y)", 0.05 + 0.9 * x))
    else:
        u = Uklad(dane["styl"], dane["W"], dane["H"], folder_fontow)
    srt_z_segmentow([s for s in dane["segmenty"] if not s.get("usuniety")], u, Path(dane.get("srt") or folder / "napisy.srt"))
    zapisz_projekt_napisow(folder, dane)
    wynik(projekt=str(plik), zmienione=[{"id": s["id"], "plik": str(folder / s["plik"]), "od": s["od"], "do": s["do"], "tekst": " ".join(w["slowo"] for w in s["slowa"])} for s in do_renderu])


if __name__ == "__main__":
    p = argparse.ArgumentParser(description="Napisy w stylu Submagic")
    sub = p.add_subparsers(dest="tryb", required=True)
    t = sub.add_parser("transkrybuj"); t.add_argument("--folder", required=True); t.add_argument("--jezyk", default=None)
    t.add_argument("--silnik", default="auto", choices=["auto", "elevenlabs", "subtitle-edit", "lokalnie"]); t.add_argument("--od-nowa", action="store_true")
    t.add_argument("--pliki", default=None, help='JSON: pełne ścieżki filmów przeciągniętych w Studio (zamiast filmów z --folder)')
    w = sub.add_parser("wypal"); w.add_argument("--folder"); w.add_argument("--plik"); w.add_argument("--slowa")
    w.add_argument("--styl", default="{}"); w.add_argument("--fonty", default=None, help="folder fontów klienta"); w.add_argument("--wyjscie")
    w.add_argument("--pliki", default=None, help="JSON: pełne ścieżki filmów (jak przy transkrybuj)")
    w.add_argument("--zapis", default="obok", choices=["obok", "folder"], help="obok = <film>_SUB.mp4 obok oryginału, folder = w --do")
    w.add_argument("--do", default=None, help="folder zapisu przy --zapis folder"); w.add_argument("--dopisek", default="_SUB")
    g = sub.add_parser("podglad"); g.add_argument("--styl", default="{}"); g.add_argument("--plik"); g.add_argument("--wyjscie", required=True)
    g.add_argument("--fonty", default=None)
    q = sub.add_parser("sekwencja"); q.add_argument("--xml", required=True); q.add_argument("--folder", required=True)
    q.add_argument("--styl", default="{}"); q.add_argument("--W", type=int, default=1080); q.add_argument("--H", type=int, default=1920)
    q.add_argument("--jezyk", default=None); q.add_argument("--silnik", default="auto", choices=["auto", "elevenlabs", "subtitle-edit", "lokalnie"])
    q.add_argument("--fonty", default=None); q.add_argument("--slowa", default=None); q.add_argument("--od-nowa", action="store_true"); q.add_argument("--audio", default=None)
    z = sub.add_parser("segmenty", help="panel Premiere: każdy napis osobnym klipem"); z.add_argument("--xml", required=True); z.add_argument("--folder", required=True)
    z.add_argument("--styl", default="{}"); z.add_argument("--W", type=int, default=1080); z.add_argument("--H", type=int, default=1920)
    z.add_argument("--jezyk", default=None); z.add_argument("--silnik", default="auto", choices=["auto", "elevenlabs", "subtitle-edit", "lokalnie"])
    z.add_argument("--fonty", default=None); z.add_argument("--slowa", default=None); z.add_argument("--od-nowa", action="store_true"); z.add_argument("--audio", default=None)
    zr = sub.add_parser("segmenty-rolki", help="projekt Premiere: napisy rolki (słowa i styl z montażu) jako osobne klipy")
    zr.add_argument("--slowa", required=True); zr.add_argument("--folder", required=True); zr.add_argument("--styl", default="{}")
    zr.add_argument("--W", type=int, default=1080); zr.add_argument("--H", type=int, default=1920); zr.add_argument("--fps", type=float, default=25)
    zr.add_argument("--dlugosc", type=float, required=True); zr.add_argument("--fonty", default=None)
    pz = sub.add_parser("popraw", help="panel Premiere: poprawki napisów zrobionych przez 'segmenty'"); pz.add_argument("--folder", required=True)
    pz.add_argument("--zmiany", default="[]", help='JSON: [{"id": 3, "tekst": "nowy tekst"}, {"id": 4, "od": 12.1, "do": 13.4}, {"id": 5, "usun": true}]')
    pz.add_argument("--styl", default=None); pz.add_argument("--wszystkie", action="store_true"); pz.add_argument("--fonty", default=None)
    a = p.parse_args()
    if a.tryb == "segmenty":
        segmenty_sekwencji(a.xml, a.folder, a.styl, a.W, a.H, a.jezyk, a.silnik, sciezka(a.fonty) if a.fonty else None, a.slowa, a.od_nowa, a.audio)
    elif a.tryb == "segmenty-rolki":
        st = a.styl
        if st and not st.lstrip().startswith("{") and Path(st).exists():
            st = Path(st).read_text(encoding="utf-8")
        segmenty_z_rolki(a.slowa, a.folder, json.loads(st or "{}"), a.W, a.H, a.fps, a.dlugosc, sciezka(a.fonty) if a.fonty else None)
    elif a.tryb == "popraw":
        zm = a.zmiany
        if zm and not zm.lstrip().startswith("[") and Path(zm).exists():
            zm = Path(zm).read_text(encoding="utf-8")
        popraw_segmenty(a.folder, json.loads(zm or "[]"), a.styl, a.wszystkie, sciezka(a.fonty) if a.fonty else None)
    elif a.tryb == "sekwencja":
        sekwencja(a.xml, a.folder, a.styl, a.W, a.H, a.jezyk, a.silnik, sciezka(a.fonty) if a.fonty else None, a.slowa, a.od_nowa, a.audio)
    elif a.tryb == "transkrybuj":
        transkrybuj(a.folder, a.jezyk, a.silnik, a.od_nowa, json.loads(a.pliki) if a.pliki else None)
    elif a.tryb == "wypal":
        ff = sciezka(a.fonty) if a.fonty else None
        if a.plik:
            if not a.slowa:
                blad("Przy --plik podaj też --slowa (plik _slowa.json)")
            wynik(**wypal_plik(a.plik, sciezka(a.slowa), wczytaj_styl(a.styl), ff, sciezka(a.wyjscie) if a.wyjscie else None))
        else:
            if not a.folder:
                blad("Podaj --folder (folder roboczy zlecenia)")
            wypal(a.folder, a.styl, ff, json.loads(a.pliki) if a.pliki else None, a.zapis, a.do, a.dopisek)
    else:
        podglad(a.styl, a.wyjscie, a.plik, sciezka(a.fonty) if a.fonty else None)
