---
name: rolka
description: Robi pionową rolkę (wideo 9:16) dla klienta na podstawie zadania ze Studio Nadamedia. Uruchamiane poleceniem /rolka z danymi zadania w JSON.
disable-model-invocation: true
---

Zrób rolkę według tego zadania ze Studio Nadamedia:

$ARGUMENTS

Pracuj krok po kroku. Po każdym kroku pisz jedno krótkie zdanie, co jest zrobione. Zasady wyboru serwisów i limity są w `CLAUDE.md`.

## 1. Przygotowanie

- Odczytaj JSON: `zadanie` (temat, brief, długość w sekundach, `serwisy`, `plan_przed_startem`, lektor, CTA, poprawki) i `klient` (folder, kolory, fonty, głos, ton, plansza końcowa, zakazy).
- Długość: `zadanie.dlugosc` to docelowa długość w sekundach (może być dłuższa niż 60 s, np. 90, 120, 180). Gdy `zadanie.dlugosc_wg_materialow` jest `true` (`dlugosc` jest wtedy puste), nie ma limitu: rolka trwa tyle, ile potrzebują materiały klienta (wypowiedzi z nagrań nie skracasz ani nie przyspieszasz, żeby zmieścić się w czasie; wycinasz tylko wpadki, pauzy i powtórzenia). Podaj w planie, ile wyjdzie, i nie poprawiaj długości lektora pod żadną liczbę.
- Załóż folder wyników: `python narzedzia/wspolne.py --klient "<klient.skrot albo klient.nazwa>" --projekt "<zadanie.tytul>"` (zwraca np. `wyniki/emeraldmedia_seriaief10_211026`, czyli klient_projekt_DDMMRR), zapisz w nim `zadanie.json` (z polem `id` zadania).
- Jeśli folder tego zadania już istnieje (przerwana sesja, np. po limicie), nie zaczynaj od zera: użyj gotowych plików (`lektor.mp3`, `sceny/`) i dokończ brakujące kroki.
- Jeśli zadanie ma `poprawki`, znajdź poprzedni folder w `wyniki/`, którego `zadanie.json` ma to samo `id`, pracuj na jego kopii z dopiskiem `_v2`, `_v3` i zmieniaj tylko to, czego dotyczą poprawki. Nie generuj od nowa scen, które były dobre.
- Sprawdź folder klienta. Brak `logo.png`: powiedz o tym i kontynuuj bez logo. Brak plików w `fonty/`, a font jest podany: `python narzedzia/fonty.py pobierz --nazwa "<font>" --folder <folder klienta>/fonty`.
- Lektor wymagany, a brak voice ID: zatrzymaj się i poproś o nie (lista: `python narzedzia/lektor.py --glosy`). Rolka oparta na mowie z nagrań lektora nie potrzebuje.
- Marka: `python narzedzia/marka.py sprawdz --folder <klient.folder>` i postępuj według sekcji „Marka i brandbook” w `CLAUDE.md`. Kolory planszy, przycisku i domyślnych napisów bierzesz z `marka.md`.
- Styl: jeśli klient ma `styl_wideo.md` (albo starszy `styl.md`), przeczytaj go. Jeśli ma filmy w `referencje/wideo/` bez aktualnej notatki, najpierw ją zrób (zasady w `CLAUDE.md`).
- Kilka rolek: jeśli `zadanie.liczba_rolek` > 1, robisz tyle rolek w jednym zadaniu. Tematy bierz z kolejnych linii briefu; jeśli brief ma jeden temat, zrób warianty (inny hak, inny kąt, inne ujęcia). Każda rolka ma podfolder `r1/`, `r2/`… w folderze zadania z własnym `lektor.txt`, `sceny/`, `plan.json`. Kroki 2–3 robisz dla wszystkich naraz (jeden plan z tabelą na każdą rolkę), kroki 4–7 po kolei dla każdej. Ujęcia stockowe możesz powtarzać między rolkami tylko wtedy, gdy brakuje innych. Jeśli praca się przerwie (limit Claude), po wznowieniu dokończ brakujące rolki, gotowych nie ruszaj.
- Rozdzielczości: `zadanie.rozdzielczosci` to lista `[[szerokość, wysokość], ...]` (domyślnie `[[1080, 1920]]`; ze Studio: pion 1080×1920, kwadrat 1080×1080 i/lub własna; starsze zadania mają jedną w `zadanie.rozdzielczosc`). Każda rolka ma powstać w każdej z nich. Pierwszą rozdzielczość z listy traktuj jako główną: scenariusz, lektor, muzyka i dobór ujęć są wspólne, a montujesz najpierw w niej (`"format"` w `plan.json`). Potem dla każdej kolejnej zrób osobny plan (`plan_<szer>x<wys>.json`) z tym samym lektorem, muzyką i cięciami, ale z kadrowaniem pod ten rozmiar (sprawdź, czy ważna rzecz w ujęciu nie wypada poza kadr; obrazy generowane i grafiki „Ruch” renderuj pod ten format, `--format <szer>x<wys>`) i złóż go w tym samym folderze rolki jako `rolka_kwadrat.mp4` (1080×1080), `rolka_poziom.mp4` (1920×1080) albo `rolka_<szer>x<wys>.mp4` (np. `rolka_1080x1350.mp4`); główna wersja to zwykłe `rolka.mp4`. Nie kopiuj i nie zmieniaj nazw gotowych plików ręcznie: `porzadek.py` sam nazwie je „Rolka 1.mp4”, „Rolka 1 - kwadrat.mp4”, „Rolka 1 - 1080x1350.mp4”. Kontrolę z kroku 7 zrób dla każdej rozdzielczości. W kwadracie i poziomie nie ma pasków aplikacji jak w pionie, ale tekst i tak trzymaj z dala od krawędzi.
- Premiere: jeśli `zadanie.premiere` jest `true`, ustaw w `plan.json` `"premiere": true`; obok rolki powstanie folder `premiere/` z timeline'em (opis w `CLAUDE.md`).
- Nagrania: jeśli `serwisy` zawiera `nagrania`, uruchom `python narzedzia/analiza.py folder --folder <zadanie.nagrania_folder>` i przejrzyj arkusze oraz frazy. Scenariusz buduj wtedy z tego, co jest w nagraniach (zasady w `CLAUDE.md`, sekcja „Własne nagrania”).

## 2. Scenariusz (`scenariusz.md`)

- Tekst lektora: około 2,4 słowa na sekundę (20 s to mniej więcej 45 słów). Hak w pierwszym zdaniu, forma „ty”, na końcu CTA z zadania lub klienta. Jeśli brief zawiera gotowy tekst lektora, użyj go bez zmian.
- Pilnuj tonu i zakazów klienta. Nie obiecuj rezultatów, których nie ma w briefie.
- Podziel na sceny po 2,5–4 s. Dla każdej sceny: fragment tekstu, opis kadru po polsku, prompt po angielsku. Jeśli klient ma `makiety/`, użyj co najmniej jednej makiety apki jako sceny.
- Zapisz sam tekst lektora do `lektor.txt`.

## 3. Plan serwisów

Dla każdej sceny wybierz źródło spośród `zadanie.serwisy`, według rekomendacji z `CLAUDE.md`: najpierw stock, generowanie tylko tam, gdzie stock nie wystarcza. Zanim pokażesz plan, sprawdź w stocku (`freepik.py szukaj` z miniaturami), czy dla scen są dobre ujęcia, żeby plan opierał się na tym, co faktycznie jest dostępne. Pokaż użytkownikowi tabelę:

| Scena | Co widać | Serwis | Obraz / wideo |

Pod tabelą podsumowanie zużycia: ile obrazów Gemini, ile generacji Magnific (obrazy, wideo), ile klipów Higgsfield, ile plików z Envato. Dodaj jedno zdanie z rekomendacją, np. „Proponuję wideo AI tylko w scenie 1, resztę jako obrazy z ruchem kamery”.

- `plan_przed_startem: true`: zatrzymaj się i czekaj na odpowiedź. Użytkownik może zmienić serwis przy scenie albo napisać „ok”.
- `plan_przed_startem: false`: pokaż plan i działaj dalej.
- Envato: wypisz, jakich plików szukać (frazy po angielsku), i sprawdź, co jest w `envato/`. Jeśli czegoś brakuje, poproś użytkownika o pobranie i poczekaj.

## 4. Lektor

`python narzedzia/lektor.py --tekst-plik <folder>/lektor.txt --voice <voice_id> --model <model> --wyjscie <folder>`

Jeśli długość wyjdzie o ponad 15% inna niż zadana (nie dotyczy `dlugosc_wg_materialow`), popraw tekst i wygeneruj ponownie (maksymalnie 3 podejścia) albo użyj `--predkosc` od 0.9 do 1.1.

## 5. Sceny (`<folder>/sceny/`)

- **gemini**: `python narzedzia/gemini.py obraz --prompt "..." --proporcje 9:16 --wyjscie <folder>/sceny/sN.png`
- **magnific**: narzędzie MCP `images_generate` (obraz) albo `video_generate` (wideo, najlepiej z obrazu startowego). Sprawdź parametry w opisie narzędzia: proporcje 9:16, możliwie tani model, chyba że scena wymaga lepszego. Wynik pobierz: `python narzedzia/pobierz.py --url "<adres>" --wyjscie <folder>/sceny/sN.mp4`
- **higgsfield**: `python narzedzia/higgsfield.py obraz`, obejrzyj, potem `higgsfield.py wideo --obraz <klatka> --prompt "<ruch kamery>"`
- **magnific-stock**: `python narzedzia/freepik.py szukaj --fraza "<angielska fraza>" --typ wideo --ile 12 --podglady <folder>/podglady` (albo `--typ zdjecia`). Obejrzyj miniatury (Read), wybierz najlepiej pasujące do sceny i marki, potem `python narzedzia/freepik.py pobierz --id <id> --typ wideo --wyjscie <folder>/sceny/sN.mp4`. Użyj ścieżki `plik` z wyniku, bo rozszerzenie może być inne (np. .mov). Pilnuj limitu 100 pobrań dziennie i nie pobieraj „na zapas”.
- **nagrania**: fragmenty klipów z `start`/`czas` wybrane na podstawie arkuszy i fraz; przy mowie `"dzwiek": true` i `"slowa"`.
- **envato**: pliki z `envato/`; przed użyciem obejrzyj kadr (`ffmpeg -ss 1 -i plik -frames:v 1 podglad.jpg`, potem Read)

Każdy wygenerowany obraz obejrzyj (Read), zanim go użyjesz albo animujesz. Słaby obraz: popraw prompt raz, potem zapytaj.

## 5b. Dźwięk i muzyka

- `popraw_dzwiek: true` i mowa z nagrań: `python narzedzia/dzwiek.py folder --folder <nagrania_folder>`, potem w scenach z mową `dzwiek_z` z plikiem `_czysty.wav` (sekcja „Dźwięk nagrań” w `CLAUDE.md`).
- Muzyka według sekcji „Muzyka i efekty” w `CLAUDE.md` i listy `serwisy` (`epidemic` pobiera sam, `artlist` daje propozycje do pobrania).

## 6. Montaż

Zbuduj `<folder>/plan.json` według opisu na górze `narzedzia/montaz.py`:
- `napisy`: styl z `zadanie.napisy` bez zmian; `false` = bez napisów; brak pola = styl z marki (sekcja „Napisy” w `CLAUDE.md`). Przy `kluczowe_wl: true` dopisz `"wazne"` w pliku słów, zanim złożysz rolkę
- `logo`: `<folder klienta>/logo.png` albo wariant z `brandbook/` wskazany w `marka.md` (na ciemne lub jasne tło), jeśli istnieje
- `plansza_koncowa`: tekst planszy klienta, przycisk = CTA, kolory z ról w `marka.md` (`tlo_plansza_koncowa`, `przycisk`, `tekst_przycisku`); bez notatki marki z `paleta` w zadaniu
- `muzyka`: `<folder>/muzyka.mp3` wybrany według sekcji „Muzyka i efekty” w `CLAUDE.md` (brief w `muzyka.md`, 3 kandydatów, `bity.py`), ze `start` z tej sekcji; głośność 0.15–0.2 pod lektorem. Gdzie się da, przesuń granice scen tak, żeby cięcia wypadały na końcach słów lektora (`slowa.json`) i na bitach z `bity.py` (różnica do 0,12 s); ustaw wtedy `"dopasuj_do_lektora": false` i podaj dokładne `czas` scen
- `nakladki`: 2–5 grafik ruchomych zaprojektowanych do tej rolki w „Ruchu” (sekcja „Animacje i grafiki ruchome” w `CLAUDE.md`: `ruch.py nowy` + `index.html` + `ruch.py render --projekt ... --podglad --tlo <kadr ujęcia, na którym stanie>`), w miejscach, gdzie pada hak, liczba, nazwa, obietnica albo CTA; jedna typografia i jeden język ruchu w całej rolce. Hak i CTA dopracuj według skilli `ad-creative` i `copywriting`. Plansza końcowa też może być grafiką z „Ruchu” (pełny kadr, MOV albo MP4) zamiast `plansza_koncowa`. Udane grafiki zapisz do „Moje” (`ruch.py zapisz`)
- każda scena: `ruch` i ewentualnie `przejscie` według sekcji „Ruch kamery i przejścia” w `CLAUDE.md` i `zadanie.przejscia`
- `efekty_dzwiekowe`, jeśli ich użyłeś

`python narzedzia/montaz.py zloz --plan <folder>/plan.json`

## 7. Kontrola

1. `python narzedzia/montaz.py klatki --plik <folder>/rolka.mp4 --ile 12` i obejrzyj wszystkie kadry (Read).
2. Wytnij gęsto początek: `ffmpeg -ss 0 -t 3 -i <folder>/rolka.mp4 -vf fps=5,scale=360:-1,tile=5x3 <folder>/kontrola/hak.jpg` i obejrzyj: czy w pierwszej sekundzie coś się dzieje, czy napis haka jest duży i czytelny.
3. Tak samo wytnij 1 s wokół każdego przejścia i wejścia grafiki (`-ss <czas-0.5> -t 1 ... fps=10 ... tile=5x2`): czy ruch jest płynny, czy nic nie miga, czy grafika nie stoi w bezpiecznej strefie aplikacji.
4. Porównaj z 2–3 arkuszami wzorów klienta (`referencje/wideo/_analiza/`) i z „gustem marki” w `marka.md`: wielkość i miejsce napisów, kompozycja kadru (ujęcie czy slajd), ilość grafik, tempo cięć, kolory. Wypisz 3 największe różnice, popraw i złóż jeszcze raz. Do 3 rund bez pytania.
5. Sprawdź w `muzyka.md`, czy wybrany fragment zaczyna się rytmem i kończy na takcie, i czy muzyka pod lektorem nie ginie (głośność 0.15–0.2).
6. Gdy zadanie miało `poprawki` dotyczące wyglądu, ruchu albo muzyki, dopisz je do „uwag z poprawek” w `marka.md` (i muzyczne do `klienci/<folder>/muzyka.md`).
W raporcie napisz w 2–3 zdaniach, co sprawdziłeś i co poprawiłeś.

## 8. Raport

Krótko, po polsku (przy kilku rolkach jedna tabela z wierszem na każdą rolkę):
- ścieżka do `rolka.mp4` i do pliku do wgrania w Studio (`podglad_do_studio` z wyniku montażu); przy kilku rolkach wypisz ścieżki wszystkich i zaproponuj wgranie do Studio pierwszej (strona przyjmuje jeden plik na zadanie)
- jeśli był eksport do Premiere: ścieżka do folderu `premiere/` i jedno zdanie, jak go zaimportować (Plik > Importuj, plik .xml)
- długość, liczba scen i z czego powstały
- tabela kosztów, wiersz na każdy użyty serwis:

| Serwis | Zużycie | Koszt |
| --- | --- | --- |
| ElevenLabs | liczba znaków wysłanych łącznie (policz z `lektor.txt` × liczba podejść) | z puli znaków planu |
| Magnific AI (MCP) | liczba obrazów i klipów + model | kredyty, jeśli narzędzie je zwróciło; inaczej „sprawdź w panelu Magnific” |
| Magnific stock | liczba pobranych plików | 0 kredytów, liczy się do limitu 100 dziennie |
| Higgsfield | liczba klipów × sekundy | ok. 0,07 USD za sekundę |
| Gemini | liczba obrazów | z kredytów Google |
| Envato | liczba użytych plików | w abonamencie |
| ElevenLabs Voice Isolator | minuty poprawionego dźwięku | kredyty ElevenLabs |
| Epidemic Sound | utwór (tytuł, autor) i efekty | w abonamencie |
| Artlist | wybrany utwór; generowanie AI tylko za zgodą | katalog w abonamencie, AI z kredytów |

- jedno zdanie: „Zużycie limitu Claude sprawdzisz poleceniem /usage. Przed kolejnym zadaniem wpisz /clear, żeby nowa rolka nie ciągnęła historii tej rozmowy.”
- przypomnienie: wgraj plik w Studio (Edytuj → Gotowy plik), status przesunie się na „Do akceptacji”

## 9. Wersje językowe

Sprawdź podfoldery `makiety/` klienta. Jeśli są języki inne niż `pl`, zapytaj jednym zdaniem, np. „Robimy też wersję: SV?”. Po „tak” zrób ją według sekcji „Wersje językowe” w `CLAUDE.md`, bez pokazywania tłumaczenia, i dopisz do raportu ścieżkę `rolka_<kod>.mp4` oraz zużycie znaków ElevenLabs.
