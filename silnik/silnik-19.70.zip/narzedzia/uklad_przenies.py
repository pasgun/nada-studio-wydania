"""Jednorazowe przeniesienie starych plików do nowego układu (narzedzia/uklad.py). Niczego nie kasuje.

  plan()        co i dokąd trafi (nic nie rusza)
  przenies()    przenosi, zostawia pod starymi adresami programu połączenia folderów, poprawia ścieżki w osiach XML i plikach JSON,
                zapisuje dziennik _system/uklad_dziennik.json (cofnij() przenosi wszystko z powrotem)

Skąd dokąd:
  klienci/<slug>                       -> Klienci\\NN Nazwa\\Assety (+ połączenie klienci/<slug>)
  wyniki/<Klient>/<zadanie>            -> Klienci\\NN Klient\\Filmy|Grafika\\NN <zadanie> (Materiały -> Assety, Projekty -> Premiere/Photoshop/After Effects)
  wyniki/<Klient>/Panel Premiere/<x>   -> Klienci\\NN Klient\\Assety\\Panel Premiere\\<x>
  nagrania/<x>, materialy/<x>          -> Assety\\Nagrania / Assety\\Zdjęcia zadania, które ich używa (z bazy Studio), inaczej Assety klienta
  zlecenia/<x>, napisy/<x>             -> nowe zadanie: pliki w Assety\\Pliki, gotowe na wierzchu
  muzyka, envato, stock, stock_reczny  -> Biblioteka\\Muzyka, Envato, Stock
Pliki otwarte w innym programie (Premiere, Photoshop) blokują przeniesienie folderu: taki folder zostaje na miejscu i jest w raporcie.
"""
import json
import os
import re
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import uklad  # noqa: E402
from uklad import ASSETY, FILMY, GRAFIKA, KATALOG, czysta_nazwa  # noqa: E402

WYNIKI = KATALOG / "wyniki"
# stare ścieżki zawsze zawierają któryś z tych folderów programu (pliki bez nich nie są czytane drugi raz)
FILTR = ["wyniki", "nagrania", "materialy", "zlecenia", "napisy", "klienci", "muzyka", "envato", "stock"]
WEJSCIA_PLIKI = {"zlecenia", "napisy"}
ZNAKI_GRAFIKI = re.compile(r"grafik|miniatur|karuzel|post|baner|plakat|ulotk|formaty|seria", re.I)


def _zwarty(t):
    from wspolne import slug_zwarty
    return slug_zwarty(t, 80)


def _info_z(d):
    """Opis starego zadania: Materiały/_info.json uzupełniony danymi z zadanie.json (numer, tytuł, rodzaj, folder klienta)."""
    inf = {}
    for p in (d / "Materiały" / "_info.json", d / ASSETY / "_info.json"):
        try:
            inf = json.loads(p.read_text(encoding="utf-8"))
            break
        except Exception:
            continue
    for z in (d / "Materiały" / "zadanie.json", d / "zadanie.json", d / "zadanie_panel.json"):
        try:
            x = json.loads(z.read_text(encoding="utf-8-sig"))
        except Exception:
            continue
        zz = x.get("zadanie", x) if isinstance(x, dict) else {}
        kl = x.get("klient") if isinstance(x.get("klient"), dict) else {}
        inf.setdefault("tytul", zz.get("tytul") or zz.get("title"))
        if not inf.get("zadanie_id") and zz.get("id"):
            inf["zadanie_id"] = str(zz.get("id"))
        inf.setdefault("rodzaj", x.get("typ") or zz.get("rodzaj") or zz.get("typ") or "")
        inf.setdefault("klient_folder", zz.get("klient_folder") or kl.get("folder") or "")
        break
    return {k: v for k, v in inf.items() if v}


def _czas(d):
    inf = _info_z(d)
    try:
        if inf.get("utworzono"):
            return time.mktime(time.strptime(inf["utworzono"][:16], "%Y-%m-%d %H:%M"))
    except Exception:
        pass
    try:
        return min([d.stat().st_mtime] + [x.stat().st_mtime for x in d.iterdir()][:200])
    except OSError:
        return 0


class Plan:
    def __init__(self, dane=None):
        self.dane = Path(dane) if dane else uklad.dane()
        self.klienci = {}       # klucz klienta -> {"slug", "nazwa", "folder", "czas"}
        self.ruchy = []         # {"z", "do", "rodzaj"}
        self.polaczenia = []    # {"link", "cel"}
        self.uwagi = []
        self.zadania = {}       # zadanie_id -> folder docelowy (względem dane)
        self.numery = {}        # folder kategorii -> następny numer
        self.studio = uklad.klienci_studia()
        self.cele = set()        # foldery docelowe zaplanowane do tej pory
        self.wejscia_zadan = {}  # (nagrania|materialy, nazwa) -> folder zadania (z zadanie.json w wynikach)

    # ----- klienci -----
    def _klucz(self, nazwa_albo_slug):
        """Dopasowanie nazwy (folderu z wyników, przedrostka nazwy nagrań) do klienta: dokładnie albo przedrostkiem."""
        z = _zwarty(nazwa_albo_slug)
        if not z:
            return None
        best = None
        for k, d in self.klienci.items():
            for w in {_zwarty(k), _zwarty(d["nazwa"]), _zwarty(d.get("skrot", ""))} - {""}:
                if z == w:
                    return k
                if len(w) >= 4 and z.startswith(w) and (best is None or len(w) > best[1]):
                    best = (k, len(w))
        return best[0] if best else None

    def zbierz_klientow(self):
        lista = []
        for slug, d in self.studio.items():
            lista.append({"slug": slug, "nazwa": d["nazwa"], "czas": (d.get("utworzono") or 0) / 1000})
        kl = KATALOG / "klienci"
        for k in sorted(kl.iterdir()) if kl.exists() else []:
            if k.is_dir() and k.name not in self.studio and not uklad.cel_polaczenia(k):
                lista.append({"slug": k.name, "nazwa": uklad.nazwa_klienta(k.name), "czas": _czas(k)})
        lista.sort(key=lambda x: x["czas"] or 9e12)
        istniejace = uklad.ustawienia().get("klienci", {})
        root = self.dane / "Klienci"
        nr = uklad.nastepny_numer(root) if root.exists() else 1
        for x in lista:
            if istniejace.get(x["slug"]):
                folder = istniejace[x["slug"]]
            else:
                folder = f"{nr:02d} {czysta_nazwa(x['nazwa'], 60)}"
                nr += 1
            self.klienci[x["slug"]] = {"slug": x["slug"], "nazwa": x["nazwa"], "folder": folder}
        self.klienci[""] = {"slug": "", "nazwa": "Bez klienta", "folder": uklad.BEZ_KLIENTA}

    def kfolder(self, klucz):
        return self.dane / "Klienci" / self.klienci[klucz]["folder"]

    def nowe_zadanie(self, klucz, kat, tytul):
        baza = self.kfolder(klucz) / kat
        if baza not in self.numery:
            self.numery[baza] = uklad.nastepny_numer(baza) if baza.exists() else 1
        n = self.numery[baza]
        self.numery[baza] += 1
        return baza / f"{n:02d} {czysta_nazwa(tytul)}"

    def ruch(self, z, do, rodzaj, **dod):
        do = Path(do)
        if rodzaj in ("panel", "plik", "nagrania", "materialy") and (str(do) in self.cele or do.exists()):
            # dwa foldery o tej samej nazwie (np. „animacje” z dwóch starych folderów panelu): drugi dostaje „(2)”
            n = 2
            while True:
                k = do.with_name(f"{do.name} ({n})")
                if str(k) not in self.cele and not k.exists():
                    do = k
                    break
                n += 1
        self.cele.add(str(do))
        self.ruchy.append({"z": str(z), "do": str(do), "rodzaj": rodzaj, **dod})

    # ----- plan -----
    def zbuduj(self):
        self.zbierz_klientow()
        # 1. Assety klientów
        for slug, d in self.klienci.items():
            if not slug:
                continue
            src = KATALOG / "klienci" / slug
            if src.is_dir() and not uklad.cel_polaczenia(src):
                self.ruch(src, self.kfolder(slug) / ASSETY, "klient")
                self.polaczenia.append({"link": str(src), "cel": str(self.kfolder(slug) / ASSETY)})
        # 2. wyniki
        zad = []
        for top in sorted(WYNIKI.iterdir()) if WYNIKI.exists() and not uklad.cel_polaczenia(WYNIKI) else []:
            if not top.is_dir() or top.name.startswith("_"):
                continue
            inf = _info_z(top)
            stary_zadanie = bool(inf.get("tytul") or (top / "zadanie.json").exists() or (top / "plan.json").exists())
            klucz = "" if top.name == "Bez klienta" else self._klucz(top.name)
            if stary_zadanie and not (top / "Panel Premiere").is_dir():
                k2 = self._klucz(((json.loads((top / "zadanie.json").read_text(encoding="utf-8-sig")) if (top / "zadanie.json").exists() else {}).get("klient") or {}).get("nazwa", "")) if (top / "zadanie.json").exists() else None
                zad.append((k2 if k2 is not None else (klucz or ""), top, inf.get("tytul") or top.name))
                continue
            if klucz is None:
                # folder, który nie jest klientem ze Studio (np. „Gra Heleny”, „Test”, „after-effects”)
                bk = self.kfolder("") / ASSETY
                if top.name == "after-effects":
                    self.ruch(top, bk / "Panel Premiere" / "After Effects", "panel")  # projekty AE z panelu (Dynamic Link)
                elif (top / "claude_log.jsonl").exists() or (top / "zadanie_panel.json").exists():
                    self.ruch(top, bk / "Panel Premiere" / top.name, "panel")  # stary przebieg z panelu
                elif all(d.name in ("Panel Premiere", "Panel DaVinci") for d in top.iterdir()):
                    for d in top.iterdir():
                        for x in sorted(d.iterdir()):
                            self.ruch(x, bk / d.name / f"{top.name} - {x.name}", "panel")
                else:
                    zad.append(("", top, top.name, True))  # folder użytkownika: jedno zadanie z całą zawartością
                continue
            for d in sorted(top.iterdir()):
                if not d.is_dir():
                    self.ruch(d, self.kfolder(klucz) / ASSETY / "Inne" / d.name, "plik")
                    continue
                if d.name in ("Panel Premiere", "Panel DaVinci"):
                    kl = self.klienci.get(klucz, {})
                    dokladny = not klucz or _zwarty(top.name) in {_zwarty(klucz), _zwarty(kl.get("nazwa", ""))}
                    for x in sorted(d.iterdir()):
                        # folder w rodzaju „Bogmat_Rolki_all”: jego nazwa zostaje w nazwie, żeby było wiadomo, skąd to jest
                        self.ruch(x, self.kfolder(klucz) / ASSETY / d.name / (x.name if dokladny else f"{top.name} - {x.name}"), "panel")
                    continue
                zad.append((klucz, d, d.name))  # nazwa folderu, a nie tytuł: ma już dopiski „v2”, „(2)”
        zad.sort(key=lambda x: _czas(x[1]))
        for z in zad:
            klucz, d, tytul = z[0], z[1], z[2]
            caly = len(z) > 3
            inf = _info_z(d)
            if not klucz and inf.get("klient_folder"):
                # zadanie zapisane kiedyś „bez klienta”, choć w zadaniu był klient: wraca do niego
                sl = uklad.slug_z_folderu(inf["klient_folder"])
                klucz = sl if sl in self.klienci else (self._klucz(sl) or "")
            zid = str(inf.get("zadanie_id") or "")
            rodzaj = inf.get("rodzaj") or uklad.zadanie_ze_studia(zid).get("type") or ""
            if not rodzaj:
                psd = any(x.suffix.lower() in (".psd", ".psb") for x in list(d.rglob("*"))[:3000])
                rodzaj = "grafika" if (psd or ZNAKI_GRAFIKI.search(d.name)) and not any(d.glob("*.mp4")) else "rolka"
            kat = uklad.kategoria(rodzaj)
            cel = self.nowe_zadanie(klucz, kat, re.sub(r"^\d{4}-\d{2}-\d{2}_-?", "", tytul))
            self.ruch(d, cel, "zadanie_caly" if caly else "zadanie", zadanie_id=zid)
            if zid and zid not in self.zadania:
                self.zadania[zid] = cel
            for zj in (d / "Materiały" / "zadanie.json", d / "zadanie.json"):
                try:
                    x = json.loads(zj.read_text(encoding="utf-8-sig"))
                except Exception:
                    continue
                zz = x.get("zadanie", x) if isinstance(x, dict) else {}
                for pole in ("nagrania_folder", "materialy_folder"):
                    v = str(zz.get(pole) or x.get(pole) or "").replace("\\", "/").strip("/")
                    if v.count("/") == 1:
                        self.wejscia_zadan.setdefault(tuple(v.split("/")), cel)
                break
        # 3. wejścia zadań (nagrania, materiały, zlecenia narzędzi, generator napisów)
        tasks = uklad._baza("tasks.json")
        po_folderze = {}
        for tid, t in (tasks.items() if isinstance(tasks, dict) else []):
            if isinstance(t, dict):
                for pole, rodz in (("nagraniaFolder", "nagrania"), ("materialyFolder", "materialy")):
                    if t.get(pole):
                        po_folderze.setdefault((rodz, t[pole]), (str(tid)[-4:].upper(), t))
        uzyte = {}
        for rodz in ("nagrania", "materialy", "zlecenia", "napisy"):
            b = KATALOG / rodz
            for x in sorted(b.iterdir()) if b.exists() and not uklad.cel_polaczenia(b) else []:
                if not x.is_dir() or x.name.startswith("_") or uklad.cel_polaczenia(x):
                    continue
                zt = po_folderze.get((rodz, x.name))
                klucz = self._klucz(x.name.split("_")[0]) or ""
                zw = self.wejscia_zadan.get((rodz, x.name))
                if zw is not None and not (zt and self.zadania.get(zt[0])):
                    pod = uklad.WEJSCIA[rodz]
                    n = uzyte.get((str(zw), pod), 0)
                    uzyte[(str(zw), pod)] = n + 1
                    cel = zw / ASSETY / (pod if n == 0 else f"{pod} {x.name}")
                    self.ruch(x, cel, rodz)
                elif zt:
                    zid, t = zt
                    klucz = next((s for s in self.klienci if s and self.studio.get(s) and _zwarty(self.studio[s]["nazwa"]) == _zwarty(_klient_zadania(t))), klucz)
                    zad_f = self.zadania.get(zid)
                    if zad_f is None:
                        zad_f = self.nowe_zadanie(klucz, uklad.kategoria(t.get("type") or ("grafika" if rodz == "materialy" else "rolka")), t.get("title") or x.name)
                        self.zadania[zid] = zad_f
                        self.ruch("", zad_f, "nowe_zadanie", zadanie_id=zid, tytul=t.get("title") or x.name)
                    pod = uklad.WEJSCIA[rodz]
                    n = uzyte.get((str(zad_f), pod), 0)
                    uzyte[(str(zad_f), pod)] = n + 1
                    cel = zad_f / ASSETY / (pod if n == 0 else f"{pod} {x.name}")
                    self.ruch(x, cel, rodz)
                elif rodz in WEJSCIA_PLIKI:
                    tytul = uklad._tytul_z_nazwy(x.name)
                    kat = GRAFIKA if ZNAKI_GRAFIKI.search(x.name) else FILMY
                    zad_f = self.nowe_zadanie(klucz, kat, tytul)
                    self.ruch(x, zad_f / ASSETY / "Pliki", rodz, gotowe_na_wierzch=str(zad_f))
                    cel = zad_f / ASSETY / "Pliki"
                else:
                    cel = self.kfolder(klucz) / ASSETY / uklad.WEJSCIA[rodz] / x.name
                    self.ruch(x, cel, rodz)
                self.polaczenia.append({"link": str(x), "cel": str(cel)})
        # 4. biblioteka
        for rodz, pod in uklad.BIBLIOTEKA.items():
            b = KATALOG / rodz
            cel = self.dane / "Biblioteka" / pod
            if b.is_dir() and not uklad.cel_polaczenia(b):
                self.ruch(b, cel, "biblioteka")
            self.polaczenia.append({"link": str(b), "cel": str(cel)})
        return self

    def opis(self):
        """Krótki opis planu dla człowieka: klient -> ile zadań w Filmy i Grafika."""
        out = {}
        for r in self.ruchy:
            try:
                rel = Path(r["do"]).relative_to(self.dane / "Klienci")
            except ValueError:
                continue
            k = rel.parts[0]
            o = out.setdefault(k, {"Filmy": [], "Grafika": [], "Assety": 0})
            if len(rel.parts) >= 2 and rel.parts[1] in (FILMY, GRAFIKA) and r["rodzaj"] in ("zadanie", "zadanie_caly", "nowe_zadanie", "zlecenia", "napisy"):
                n = rel.parts[2]
                if n not in o[rel.parts[1]]:
                    o[rel.parts[1]].append(n)
            else:
                o["Assety"] += 1
        return out


def _klient_zadania(t):
    cid = t.get("clientId")
    d = uklad._baza("clients.json")
    return (d.get(cid) or {}).get("name", "") if isinstance(d, dict) else ""


def plan(dane=None):
    p = Plan(dane).zbuduj()
    return {"dane": str(p.dane), "klienci": {k or "(bez klienta)": v["folder"] for k, v in p.klienci.items()}, "uklad": p.opis(),
            "ruchow": len(p.ruchy), "polaczen": len(p.polaczenia), "ruchy": p.ruchy, "uwagi": p.uwagi}


# ---------- wykonanie ----------
RUCHY = []  # każda zmiana miejsca po kolei (dziennik do cofnięcia)
USUNIETE_PUSTE = []  # puste foldery usunięte przy przenoszeniu (przy cofaniu wracają)
UTWORZONE = []  # pliki opisu zadań (_info.json) założone przy przenoszeniu (przy cofaniu znikają)


def _info_nowe(folder, inf):
    if not uklad._info(folder):
        UTWORZONE.append(str(Path(folder) / ASSETY / "_info.json"))
    uklad.zapisz_info(folder, inf)


def _mv(a, b):
    os.rename(a, b)
    RUCHY.append([str(a), str(b)])


def _przenies_folder(z, do):
    """Zwykła zmiana miejsca (ten sam dysk: natychmiast, bez kopiowania). Gdy coś jest otwarte w innym programie, Windows
    nie pozwoli: wtedy folder zostaje i trafia do raportu (żadnego kopiowania w połowie)."""
    z, do = Path(z), Path(do)
    do.parent.mkdir(parents=True, exist_ok=True)
    if do.exists():
        if do.is_dir() and not any(do.iterdir()):
            do.rmdir()
        else:
            # cel już jest (np. Panel Premiere z dwóch folderów): przenosimy zawartość po kolei
            for x in list(z.iterdir()):
                c = do / x.name
                if c.exists():
                    c = uklad_wolna(c)
                _mv(x, c)
            try:
                z.rmdir()
            except OSError:
                pass
            return
    _mv(z, do)


def uklad_wolna(c):
    n = 2
    while True:
        k = c.with_name(f"{c.stem} ({n}){c.suffix}")
        if not k.exists():
            return k
        n += 1


def _nazwy_wielkie(assety, zmiany=None):
    """Podfoldery Assety klienta z wielkiej litery (Brandbook, Logo...), Windows: przez nazwę tymczasową."""
    for st, nw in (("brandbook", "Brandbook"), ("logo", "Logo"), ("fonty", "Fonty"), ("makiety", "Makiety"), ("referencje", "Referencje"),
                   ("referencje/wideo", "Referencje/Wideo"), ("referencje/grafiki", "Referencje/Grafiki")):
        p = assety / st
        if p.is_dir() and p.name != Path(nw).name:
            tmp = p.with_name(p.name + "_tmp_nazwa")
            _mv(p, tmp)
            _mv(tmp, p.with_name(Path(nw).name))
            if zmiany is not None:
                zmiany.append((p, p.with_name(Path(nw).name)))


def _projekty_na_nowe(task, zmiany, stary=None):
    """W przeniesionym zadaniu: Materiały -> Assety, Projekty/* -> Premiere/, Photoshop/, After Effects/."""
    m = task / "Materiały"
    if m.is_dir() and not (task / ASSETY).exists():
        _mv(m, task / ASSETY)
        zmiany.append((m, task / ASSETY))
    pr = task / "Projekty"
    if not pr.is_dir():
        return
    rzeczy = list(pr.iterdir())
    prem = [x for x in rzeczy if x.is_dir() and "premiere" in x.name.lower()]
    for x in rzeczy:
        n = x.name.lower()
        if x.is_dir() and "premiere" in n:
            mm = re.match(r"(Rolka \d+)", x.name)
            cel = task / "Premiere" / (mm.group(1) if mm else x.name) if len(prem) > 1 else task / "Premiere"
        elif x.is_dir() and ("photoshop" in n):
            cel = task / "Photoshop"
        elif x.is_dir() and ("after" in n):
            cel = task / "After Effects"
        elif x.suffix.lower() in (".psd", ".psb"):
            cel = task / "Photoshop" / x.name
        elif x.suffix.lower() in (".aep",):
            cel = task / "After Effects" / x.name
        else:
            cel = task / "Premiere" / x.name
        if cel.exists() and cel.is_dir() and x.is_dir():
            for y in list(x.iterdir()):
                c = cel / y.name
                c = uklad_wolna(c) if c.exists() else c
                _mv(y, c)
                zmiany.append((y, c))
            try:
                x.rmdir()
                if stary:
                    USUNIETE_PUSTE.append(str(Path(stary) / x.relative_to(task)))
            except OSError:
                pass
            continue
        cel.parent.mkdir(parents=True, exist_ok=True)
        if cel.exists():
            cel = uklad_wolna(cel)
        _mv(x, cel)
        zmiany.append((x, cel))
    try:
        pr.rmdir()
        if stary:
            USUNIETE_PUSTE.append(str(Path(stary) / "Projekty"))
    except OSError:
        pass


MEDIA = {".mp4", ".mov", ".png", ".jpg", ".jpeg", ".webp", ".srt", ".pdf", ".gif", ".psd"}


def _wierzch(task, zmiany):
    """Po przeniesieniu starego zadania: na wierzchu tylko gotowe pliki (z ostatnich porządków), reszta do Assety."""
    inf = uklad._info(task)
    zostaw = set(inf.get("na_wierzchu") or [])
    (task / ASSETY).mkdir(exist_ok=True)
    for x in list(task.iterdir()):
        if x.name in ("Premiere", "Photoshop", "After Effects", ASSETY) or x.name.startswith("."):
            continue
        media = not x.name.startswith("_") and (x.is_dir() or x.suffix.lower() in MEDIA)
        if media and (x.name in zostaw or (not zostaw and x.is_file())):
            continue  # gotowe z ostatnich porządków (albo pliki multimedialne, gdy porządków nie było) zostają na wierzchu
        if x.name in ("postep.json", "proces_panelu.json", "claude_log.jsonl", "zadanie_panel.json", "sekwencja.xml", "proksy.json"):
            continue  # pliki sterujące panelu zostają (ukryte)
        cel = task / ASSETY / x.name
        cel = uklad_wolna(cel) if cel.exists() else cel
        _mv(x, cel)
        zmiany.append((x, cel))


def _usun_puste(folder):
    """Puste foldery po przeniesieniu (tylko puste, nic z plikami)."""
    for d in sorted((p for p in Path(folder).rglob("*") if p.is_dir() and not uklad.cel_polaczenia(p)), key=lambda p: -len(p.parts)):
        try:
            d.rmdir()
            USUNIETE_PUSTE.append(str(d))
        except OSError:
            pass
    try:
        Path(folder).rmdir()
        USUNIETE_PUSTE.append(str(folder))
    except OSError:
        pass


def przenies(dane=None):
    import porzadek
    bylo_wlaczone = uklad.wlaczony()
    p = Plan(dane).zbuduj()
    RUCHY.clear()
    dziennik = {"kiedy": time.strftime("%Y-%m-%d %H:%M"), "dane": str(p.dane), "przeniesione": [], "ruchy": RUCHY, "polaczenia": [], "bledy": [],
                "utworzone": UTWORZONE, "usuniete_puste": USUNIETE_PUSTE}
    UTWORZONE.clear()
    USUNIETE_PUSTE.clear()
    # pliki silnika ze starego wyniki/_<nazwa> do _system (gdyby jeszcze były)
    for n in porzadek.SYSTEMOWE:
        try:
            porzadek.system(n)
        except Exception:
            pass
    u = uklad.ustawienia()
    u.update({"dane": str(p.dane), "klienci": {k: v["folder"] for k, v in p.klienci.items() if k}})
    zmiany = []  # (stara ścieżka, nowa) do poprawienia w plikach
    for r in p.ruchy:
        z, do = r["z"], Path(r["do"])
        try:
            if r["rodzaj"] == "nowe_zadanie":
                (do / ASSETY).mkdir(parents=True, exist_ok=True)
                _info_nowe(do, {"utworzono": time.strftime("%Y-%m-%d %H:%M"), "tytul": r.get("tytul", ""), "zadanie_id": r.get("zadanie_id", "")})
                continue
            if not Path(z).exists():
                continue
            _przenies_folder(z, do)
            dziennik["przeniesione"].append({"z": z, "do": str(do)})
            zmiany.append((Path(z), do))
            przed = len(zmiany)
            if r["rodzaj"] == "klient":
                _nazwy_wielkie(do, zmiany)
                uklad.ukryj_notatki(do)
            if r["rodzaj"] in ("zadanie", "zadanie_caly"):
                if r["rodzaj"] == "zadanie":
                    _projekty_na_nowe(do, zmiany, stary=z)
                    _wierzch(do, zmiany)
                if not uklad._info(do):
                    _info_nowe(do, {"utworzono": time.strftime("%Y-%m-%d %H:%M", time.localtime(_czas(do))), "tytul": do.name[3:],
                                           **({"zadanie_id": r["zadanie_id"]} if r.get("zadanie_id") else {})})
                else:
                    uklad.ukryj(do / ASSETY / "_info.json")
            if r.get("gotowe_na_wierzch"):
                g = do / "gotowe"
                if g.is_dir():
                    for x in list(g.iterdir()):
                        c = Path(r["gotowe_na_wierzch"]) / x.name
                        c = uklad_wolna(c) if c.exists() else c
                        _mv(x, c)
                        zmiany.append((Path(z) / "gotowe" / x.name, c))
                    try:
                        g.rmdir()
                        USUNIETE_PUSTE.append(str(Path(z) / "gotowe"))
                    except OSError:
                        pass
            # zmiany wewnątrz przeniesionego folderu zapisujemy też względem starej ścieżki (pliki zawierają stare ścieżki)
            for a, b in list(zmiany[przed:]):
                try:
                    zmiany.append((Path(z) / Path(a).relative_to(do), b))
                except ValueError:
                    pass
            if r.get("gotowe_na_wierzch"):
                if not uklad._info(Path(r["gotowe_na_wierzch"])):
                    _info_nowe(Path(r["gotowe_na_wierzch"]), {"utworzono": time.strftime("%Y-%m-%d %H:%M", time.localtime(_czas(do))),
                                                                     "tytul": Path(r["gotowe_na_wierzch"]).name[3:]})
        except OSError as e:
            dziennik["bledy"].append({"z": z, "do": str(do), "blad": f"{e.__class__.__name__}: {e}"})
    # połączenia pod starymi adresami programu
    for c in p.polaczenia:
        link, cel = Path(c["link"]), Path(c["cel"])
        try:
            if os.path.lexists(link):
                if uklad.cel_polaczenia(link):
                    continue
                if link.is_dir() and not any(link.iterdir()):
                    link.rmdir()
                else:
                    dziennik["bledy"].append({"z": str(link), "blad": "stary folder nie jest pusty (coś było otwarte?): połączenie nie powstało"})
                    continue
            uklad.polacz(link, cel)
            dziennik["polaczenia"].append({"link": str(link), "cel": str(cel)})
        except OSError as e:
            dziennik["bledy"].append({"z": str(link), "blad": f"{e.__class__.__name__}: {e}"})
    # numery zadań ze Studio -> foldery
    for zid, f in p.zadania.items():
        try:
            u.setdefault("zadania", {})[zid] = Path(f).relative_to(p.dane).as_posix()
        except ValueError:
            pass
    u["wlaczony"] = True
    u["przeniesiono"] = dziennik["kiedy"]
    uklad.zapisz_ustawienia(u)
    # ścieżki w osiach Premiere, planach i rejestrach panelu
    poprawione = 0
    if zmiany:
        for f in [p.dane / "Klienci", KATALOG / "_system" / "panel", KATALOG / "_system" / "proksy"]:
            if f.exists():
                poprawione += porzadek.popraw_sciezki(f, zmiany, rozwiaz=False, pomin={"claude_log.jsonl", "log.jsonl"}, filtr=FILTR)
    dziennik["poprawione_pliki"] = poprawione
    dziennik["zmiany"] = [[str(a), str(b)] for a, b in zmiany]
    _ukryte_panelu(zmiany)
    # puste foldery, które zostały w wyniki/ (same puste, pliki nigdy nie są kasowane)
    if WYNIKI.exists() and not uklad.cel_polaczenia(WYNIKI):
        _usun_puste(WYNIKI)
    # kolejne przenosiny (dobieranie luźnych folderów) dopisują się do dziennika, żeby „cofnij” cofnęło wszystko
    try:
        stary = json.loads(DZIENNIK.read_text(encoding="utf-8")) if bylo_wlaczone and DZIENNIK.exists() else {}
    except Exception:
        stary = {}
    for k in ("przeniesione", "ruchy", "polaczenia", "zmiany", "utworzone", "usuniete_puste"):
        if stary.get(k):
            dziennik[k] = list(stary[k]) + list(dziennik.get(k) or [])
    DZIENNIK.write_text(json.dumps(dziennik, ensure_ascii=False, indent=1), encoding="utf-8")
    return {"przeniesiono": len(dziennik["przeniesione"]), "polaczenia": len(dziennik["polaczenia"]), "poprawione_pliki": poprawione,
            "bledy": dziennik["bledy"], "dane": str(p.dane), "uklad": p.opis(), "dziennik": str(DZIENNIK)}


DZIENNIK = uklad.DZIENNIK


def _ukryte_panelu(zmiany):
    """Zadania z panelu usunięte z listy w Console zostają ukryte po przeniesieniu (ich numer zależy od ścieżki)."""
    plik = KATALOG / "_system" / "studio" / "ukryte.json"
    try:
        ukr = json.loads(plik.read_text(encoding="utf-8"))
    except Exception:
        return
    kr = uklad.klienci_root()
    nowe = set(ukr)
    for a, b in zmiany:
        try:
            st = "panel~" + Path(a).relative_to(WYNIKI).as_posix().replace("/", "~~")
            nw = "panel~@" + Path(b).relative_to(kr).as_posix().replace("/", "~~")
        except ValueError:
            continue
        for x in ukr:
            if x == st or x.startswith(st + "~~"):
                nowe.add(nw + x[len(st):])
    if nowe != set(ukr):
        plik.write_text(json.dumps(sorted(nowe), ensure_ascii=False, indent=1), encoding="utf-8")


def cofnij():
    """Przenosi wszystko z powrotem według dziennika (połączenia usuwa, ścieżki w plikach przywraca)."""
    import porzadek
    d = json.loads(DZIENNIK.read_text(encoding="utf-8"))
    bledy = []
    dane = Path(d.get("dane") or uklad.dane())
    nowe = (str(dane / "Klienci") + os.sep, str(dane / "Biblioteka") + os.sep)
    for f in d.get("utworzone", []):  # opisy zadań założone przy przenoszeniu (i ich puste foldery Assety)
        try:
            Path(f).unlink()
            Path(f).parent.rmdir()
        except OSError:
            pass
    for c in reversed(d.get("polaczenia", [])):
        try:
            uklad.usun_polaczenie(c["link"])
        except Exception as e:
            bledy.append(str(e))
    for a, b in reversed(d.get("ruchy", [])):
        try:
            Path(a).parent.mkdir(parents=True, exist_ok=True)
            os.rename(b, a)
            # puste foldery, które zostały po przeniesieniu z powrotem (tylko w nowym układzie)
            q = Path(b).parent
            while str(q).startswith(nowe) and q.exists() and not any(q.iterdir()):
                q.rmdir()
                q = q.parent
        except OSError as e:
            bledy.append(f"{b}: {e}")
    for f in d.get("usuniete_puste", []):
        Path(f).mkdir(parents=True, exist_ok=True)
    # tylko pary „pierwotna ścieżka -> ostateczna” (bez pośrednich zmian nazw wewnątrz nowych folderów)
    zm = [(Path(b), Path(a)) for a, b in d.get("zmiany", []) if not str(a).startswith(nowe)]
    if zm:
        for f in (WYNIKI, KATALOG / "_system" / "panel", KATALOG / "_system" / "proksy"):
            if f.exists():
                porzadek.popraw_sciezki(f, zm, rozwiaz=False, pomin={"claude_log.jsonl", "log.jsonl"}, filtr=FILTR + ["Klienci", "Biblioteka"])
    for f in (uklad.klienci_root(), uklad.biblioteka_root()):
        if f.exists():
            _usun_puste(f)
    u = uklad.ustawienia()
    u["wlaczony"] = False
    u["klienci"], u["zadania"] = {}, {}
    uklad.zapisz_ustawienia(u)
    return {"cofnieto": True, "bledy": bledy}
