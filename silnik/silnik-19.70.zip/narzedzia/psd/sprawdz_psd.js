// Spis warstw pliku Photoshopa (bez obrazów): artboardy, warstwy, które są edytowalnym tekstem.
// Użycie: node narzedzia/psd/sprawdz_psd.js plik.psd   (wypisuje JSON)
'use strict';
const fs = require('fs');
const { readPsd } = require('ag-psd');

function spis(lista) {
  return (lista || []).map((l) => ({
    nazwa: l.name || '',
    tekst: l.text ? String(l.text.text || '').slice(0, 80) : null,
    // tekst bez ramki: Photoshop nie przesunie go (Free Transform: pusta ramka) i wyrzuca „program error” przy edycji
    bez_ramki: l.text ? !(l.text.boundingBox && l.text.bounds) : undefined,
    ukryta: !!l.hidden,
    grupa: Array.isArray(l.children),
    dzieci: Array.isArray(l.children) ? spis(l.children) : undefined,
  }));
}

const psd = readPsd(fs.readFileSync(process.argv[2]), { skipLayerImageData: true, skipCompositeImageData: true, skipThumbnail: true });
process.stdout.write(JSON.stringify({ szerokosc: psd.width, wysokosc: psd.height, warstwy: spis(psd.children) }));
