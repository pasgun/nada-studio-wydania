"""Grafika z warstw: każdy element (zdjęcie, wycięty produkt, kształt, ramka, tekst) to osobna warstwa
w pliku Photoshopa, a teksty zostają edytowalne. Do własnych projektów (kupony, plakaty, karty, łuki...),
których nie da się zrobić gotowym układem z grafika.py. Nigdy nie spłaszczaj takich elementów w jeden PNG.

Użycie:
  python narzedzia/kompozycja.py --plan wyniki/X/kompozycja.json

kompozycja.json:
{
  "wyjscie": "wyniki/X/grafiki",               folder na PNG i photoshop/<nazwa>.psd
  "nazwa_psd": "projekty",                      (opcjonalnie) nazwa pliku Photoshopa
  "folder_klienta": "klienci/marka",            fonty klienta (szuka tam, potem we wspólnych fonty/, potem Google Fonts)
  "formaty": ["story-9x16", "square"],          jak w grafika.py (też "wlasny-1200x900")
  "projekty": [
    {"nazwa": "kupon",
     "warstwy": [ ... ],                        wspólne dla wszystkich formatów (jednostki w % skalują się same)
     "warstwy_formatu": {"square": [ ... ]}     (opcjonalnie) osobna lista dla jednego formatu zamiast wspólnej
    }
  ]
}
Warstwy (kolejność = od spodu do góry), każda ma "nazwa" (tak się nazywa w Photoshopie) i opcjonalnie "krycie" 0–1:
  {"typ": "obraz", "plik": "...png|jpg", "x": 0, "y": 0, "w": "100%", "h": "100%", "dopasuj": "wypelnij",
   "fokus_x": 0.5, "fokus_y": 0.5}            tło na cały kadr (wypelnij = przycięte jak cover, zmiesc = całe w ramce)
  {"typ": "obraz", "plik": "produkt.png", "x": "50%", "y": "62%", "w": "70%", "kotwica": "srodek",
   "obrot": -6, "zaokraglenie": 40, "kolo": false, "cien": {"rozmycie": 30, "przesuniecie": [0, 20], "krycie": 0.35},
   "obrys": {"kolor": "#FFFFFF", "grubosc": 8}}   wycięty produkt / zdjęcie w ramce (cień i obrys to osobne warstwy)
  {"typ": "ksztalt", "ksztalt": "prostokat" | "kolo" | "elipsa", "x": "6%", "y": "70%", "w": "88%", "h": "20%",
   "kolor": "#005B4C" albo "gradient": {"od": "#000000", "do": "#00000000", "kierunek": "pion" | "poziom"},
   "zaokraglenie": 36, "obrys": {"kolor": "#FFFFFF", "grubosc": 4}}
  {"typ": "tekst", "tekst": "Kod *-20%*|dla zapisanych", "font": "Figtree", "waga": 800, "rozmiar": "6.5%",
   "kolor": "#FFFFFF", "kolor_wyroznienia": "#D0FC00", "x": "8%", "y": "12%", "szer": "84%",
   "wyrownanie": "left" | "center" | "right", "interlinia": 1.08, "wielkie": false}
     *gwiazdki* = kolor wyróżnienia, | = nowa linia, dłuższy tekst łamie się sam do szerokości "szer";
     przy center/right x to środek / prawa krawędź bloku. Rozmiar w px albo % wysokości kadru.
  {"typ": "tekst", "nazwa": "Nagłówek", "linie": [{"tekst": "ŻABKĘ", "rozmiar": "11%", "waga": 900},
     {"tekst": "znasz?", "rozmiar": "6%", "waga": 600, "kolor": "#D0FC00"}], "font": "Figtree", "kolor": "#FFFFFF",
   "x": "8%", "y": "12%", "szer": "84%", "wyrownanie": "left", "interlinia": 1.05}
     linie różnej wielkości, grubości albo koloru w JEDNYM bloku = jedna warstwa tekstowa w Photoshopie (każda linia
     może mieć rozmiar, waga, font, kolor, kolor_wyroznienia, interlinia, wielkie; reszta jak wyżej).
  ZASADA WARSTW: jeden blok tekstu = jedna warstwa (cały nagłówek, cały podtytuł, tekst przycisku, tekst prawny).
     Nie rozbijaj nagłówka na warstwy po słowie ani po linii: wyróżnienie to *gwiazdki*, inna wielkość linii to "linie".
     Osobna warstwa tylko dla tekstu w innym miejscu kadru, pod innym kątem (obrót) albo na innym tle (np. na przycisku).
  {"typ": "logo", "plik": "klienci/marka/logo/logo_biale.png", "x": "8%", "y": "5%", "w": "26%"}  (jak obraz)
Jednostki: liczba = piksele, "12%" = procent szerokości (x, w, szer) albo wysokości (y, h, rozmiar).
"kotwica": "lewo-gora" (domyślnie) | "srodek" | "srodek-gora" | "srodek-dol" | "prawo-gora" | "prawo-dol" | "lewo-dol".

Wynik: <wyjscie>/<nr>_<nazwa>_<skrót formatu>.png, podglad_serii.jpg i photoshop/<nazwa_psd>.psd (rząd = projekt,
kolumny = formaty, każda na osobnym artboardzie; każdy element osobną warstwą, teksty edytowalne).
"""
import argparse
import json
import math
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from wspolne import blad, wynik  # noqa: E402
import fonty  # noqa: E402
import grafika  # noqa: E402
from grafika import sciezka  # noqa: E402


def wartosc(v, baza, domyslna=0.0):
    """Liczba = piksele, "12%" = procent bazy (szerokości albo wysokości kadru)."""
    if v is None:
        return domyslna
    if isinstance(v, str) and v.strip().endswith("%"):
        return float(v.strip()[:-1]) / 100 * baza
    return float(v)


def kolor(h, dom=(255, 255, 255, 255)):
    """#RRGGBB albo #RRGGBBAA -> (r, g, b, a)."""
    if not h:
        return dom
    h = str(h).lstrip("#")
    try:
        if len(h) == 8:
            return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4, 6))
        if len(h) == 6:
            return (*(int(h[i:i + 2], 16) for i in (0, 2, 4)), 255)
    except ValueError:
        pass
    return dom


def zakotwicz(x, y, w, h, kotwica):
    k = (kotwica or "lewo-gora").lower()
    if k == "srodek":
        return x - w / 2, y - h / 2
    dx = -w / 2 if k.startswith("srodek") else (-w if k.startswith("prawo") else 0)
    dy = -h if k.endswith("dol") else (-h / 2 if k in ("lewo-srodek", "prawo-srodek") else 0)
    return x + dx, y + dy


def maska_ksztaltu(w, h, ksztalt="prostokat", promien=0):
    from PIL import Image, ImageDraw
    m = Image.new("L", (max(1, int(w)), max(1, int(h))), 0)
    d = ImageDraw.Draw(m)
    if ksztalt in ("kolo", "elipsa"):
        d.ellipse((0, 0, m.width - 1, m.height - 1), fill=255)
    elif promien:
        d.rounded_rectangle((0, 0, m.width - 1, m.height - 1), radius=int(promien), fill=255)
    else:
        d.rectangle((0, 0, m.width - 1, m.height - 1), fill=255)
    return m


def obrys_warstwy(im, kol, grubosc):
    """Obwódka wokół kształtu obrazu (np. wyciętego produktu) jako osobny obraz pod spodem."""
    from PIL import Image, ImageFilter
    g = max(1, int(grubosc))
    duzy = Image.new("RGBA", (im.width + 2 * g, im.height + 2 * g), (0, 0, 0, 0))
    duzy.alpha_composite(im, (g, g))
    a = duzy.getchannel("A").filter(ImageFilter.MaxFilter(g * 2 + 1))
    ob = Image.new("RGBA", duzy.size, kolor(kol))
    ob.putalpha(a.point(lambda v: 255 if v > 8 else 0))
    return ob, g


def cien_warstwy(im, c):
    """Miękki cień kształtu obrazu: (obraz cienia, margines)."""
    from PIL import Image, ImageFilter
    r = int(c.get("rozmycie", 24))
    m = r * 2 + 4
    duzy = Image.new("RGBA", (im.width + 2 * m, im.height + 2 * m), (0, 0, 0, 0))
    k = kolor(c.get("kolor", "#000000"))
    a = im.getchannel("A").point(lambda v: int(v * float(c.get("krycie", 0.35))))
    sz = Image.new("RGBA", im.size, (*k[:3], 255))
    sz.putalpha(a)
    duzy.alpha_composite(sz, (m, m))
    return duzy.filter(ImageFilter.GaussianBlur(r)), m


def warstwa_obrazu(ws, w, W, H, folder_klienta):
    from PIL import Image
    p = sciezka(w.get("plik"))
    if not p or not p.exists():
        blad(f"Warstwa „{w.get('nazwa', 'obraz')}”: nie ma pliku {w.get('plik')}")
    im = Image.open(p).convert("RGBA")
    bw = wartosc(w.get("w"), W, 0) if w.get("w") is not None else None
    bh = wartosc(w.get("h"), H, 0) if w.get("h") is not None else None
    if bw and bh:
        tryb = w.get("dopasuj", "wypelnij")
        if tryb == "wypelnij":
            im = grafika.cover(im, int(bw), int(bh), float(w.get("fokus_x", 0.5)), float(w.get("fokus_y", 0.5))).convert("RGBA")
        elif tryb == "zmiesc":
            s = min(bw / im.width, bh / im.height)
            im = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)
        else:
            im = im.resize((max(1, int(bw)), max(1, int(bh))), Image.LANCZOS)
    elif bw or bh:
        s = (bw / im.width) if bw else (bh / im.height)
        im = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)
    elif w.get("skala"):
        s = float(w["skala"])
        im = im.resize((max(1, int(im.width * s)), max(1, int(im.height * s))), Image.LANCZOS)
    if w.get("kolo") or w.get("zaokraglenie"):
        m = maska_ksztaltu(im.width, im.height, "kolo" if w.get("kolo") else "prostokat", wartosc(w.get("zaokraglenie"), W, 0))
        a = im.getchannel("A")
        from PIL import ImageChops
        im.putalpha(ImageChops.multiply(a, m))
    if w.get("obrot"):
        im = im.rotate(-float(w["obrot"]), resample=Image.BICUBIC, expand=True)
    x, y = zakotwicz(wartosc(w.get("x"), W), wartosc(w.get("y"), H), im.width, im.height, w.get("kotwica"))
    nazwa = w.get("nazwa") or Path(p).stem
    if w.get("cien"):
        c, m = cien_warstwy(im, w["cien"])
        dx, dy = (w["cien"].get("przesuniecie") or [0, 18])[:2]
        grafika.wklej(ws.nowa(f"{nazwa} cień"), c, int(x - m + dx), int(y - m + dy))
    if w.get("obrys"):
        ob, g = obrys_warstwy(im, w["obrys"].get("kolor", "#FFFFFF"), w["obrys"].get("grubosc", 6))
        grafika.wklej(ws.nowa(f"{nazwa} obrys"), ob, int(x - g), int(y - g))
    grafika.wklej(ws.nowa(nazwa, krycie=float(w.get("krycie", 1))), im, int(round(x)), int(round(y)))


def warstwa_ksztaltu(ws, w, W, H):
    from PIL import Image
    bw, bh = wartosc(w.get("w"), W, W), wartosc(w.get("h"), H, H)
    x, y = zakotwicz(wartosc(w.get("x"), W), wartosc(w.get("y"), H), bw, bh, w.get("kotwica"))
    ks = w.get("ksztalt", "prostokat")
    m = maska_ksztaltu(bw, bh, ks, wartosc(w.get("zaokraglenie"), W, 0))
    if w.get("gradient"):
        g = w["gradient"]
        od, do = kolor(g.get("od"), (0, 0, 0, 255)), kolor(g.get("do"), (0, 0, 0, 0))
        pion = g.get("kierunek", "pion") == "pion"
        n = m.height if pion else m.width
        pas = Image.new("RGBA", (1, n) if pion else (n, 1))
        for i in range(n):
            t = i / max(1, n - 1)
            pas.putpixel((0, i) if pion else (i, 0), tuple(int(od[k] + (do[k] - od[k]) * t) for k in range(4)))
        im = pas.resize(m.size)
    else:
        im = Image.new("RGBA", m.size, kolor(w.get("kolor"), (0, 0, 0, 255)))
    from PIL import ImageChops
    im.putalpha(ImageChops.multiply(im.getchannel("A"), m))
    nazwa = w.get("nazwa") or ks.capitalize()
    if w.get("obrys"):
        g = max(1, int(wartosc(w["obrys"].get("grubosc", 4), W)))
        ob = Image.new("RGBA", m.size, kolor(w["obrys"].get("kolor", "#FFFFFF")))
        wew = maska_ksztaltu(max(1, bw - 2 * g), max(1, bh - 2 * g), ks, max(0, wartosc(w.get("zaokraglenie"), W, 0) - g))
        dziura = Image.new("L", m.size, 0)
        dziura.paste(wew, (g, g))
        ob.putalpha(ImageChops.subtract(m, dziura))
        if w.get("kolor") or w.get("gradient"):
            grafika.wklej(ws.nowa(nazwa, krycie=float(w.get("krycie", 1))), im, int(x), int(y))
        grafika.wklej(ws.nowa(f"{nazwa} obrys"), ob, int(x), int(y))
        return
    grafika.wklej(ws.nowa(nazwa, krycie=float(w.get("krycie", 1))), im, int(round(x)), int(round(y)))


def zlam(slowa, font, szer):
    """Słowa (tekst, wyróżnione) w linie mieszczące się w szerokości."""
    linie, biez = [], []
    for s in slowa:
        prob = biez + [s]
        if biez and font.getlength(" ".join(x[0] for x in prob)) > szer:
            linie.append(biez)
            biez = [s]
        else:
            biez = prob
    if biez:
        linie.append(biez)
    return linie


def warstwa_tekstu_linie(ws, w, W, H, folder_klienta):
    """Jeden blok tekstu (np. nagłówek) z liniami różnej wielkości, grubości albo koloru jako JEDNA warstwa tekstowa
    w Photoshopie (fragmenty tego samego tekstu), zamiast osobnej warstwy na każdą linię albo słowo."""
    from PIL import ImageDraw
    szer = wartosc(w.get("szer"), W, W * 0.84)
    wyr = w.get("wyrownanie", "left")
    x, y = wartosc(w.get("x"), W), wartosc(w.get("y"), H)
    inter_bazowa = float(w.get("interlinia", 1.1))
    wiersze = []  # (słowa, font, plik, rozmiar, kolor, kolor wyróżnienia, interlinia)
    for li in w["linie"]:
        li = {"tekst": li} if isinstance(li, str) else dict(li)
        t = str(li.get("tekst") or "")
        if li.get("wielkie", w.get("wielkie")):
            t = t.upper()
        rozm = int(wartosc(li.get("rozmiar", w.get("rozmiar", "5%")), H))
        plik, waga = fonty.znajdz_wage(li.get("font", w.get("font")), int(li.get("waga", w.get("waga", 700))), folder_klienta,
                                       kursywa=bool(li.get("kursywa", w.get("kursywa"))))
        if not plik:
            blad(f"Warstwa „{w.get('nazwa', 'tekst')}”: brak fontu {li.get('font', w.get('font'))}")
        font = fonty.wczytaj(plik, rozm, waga)
        kol = kolor(li.get("kolor", w.get("kolor")))
        kw = kolor(li.get("kolor_wyroznienia", w.get("kolor_wyroznienia")) or li.get("kolor", w.get("kolor")))
        sl = [(s_, k is not None) for s_, k in grafika.slowa_kolorowe(t)]
        for l in (zlam(sl, font, szer) if sl else [[]]):
            wiersze.append((l, font, plik, rozm, kol, kw, float(li.get("interlinia", inter_bazowa))))
    if not wiersze:
        return
    bazy, teksty, runs = [], [], []
    for i, (l, font, plik, rozm, kol, kw, inter) in enumerate(wiersze):
        asc = font.getmetrics()[0]
        if i == 0:
            bazy.append(y + asc)
        else:  # odstęp według tej linii, ale nie mniejszy niż ogonki poprzedniej (ę, ą) + litery tej
            pf = wiersze[i - 1][1]
            bazy.append(bazy[-1] + max(int(rozm * inter), int(pf.getmetrics()[1] * 0.9 + asc * 0.95)))
        lead = rozm if i == 0 else bazy[i] - bazy[i - 1]
        ps = fonty.nazwa_postscript(plik)
        for k, (s_, wyroz) in enumerate(l):
            frag = s_ + (" " if k < len(l) - 1 else ("\n" if i < len(wiersze) - 1 else ""))
            teksty.append(frag)
            run = {"dl": len(frag), "kolor": list((kw if wyroz else kol)[:3]), "rozmiar": rozm, "interlinia": lead, "font": ps}
            p_ = runs[-1] if runs else None
            if p_ and all(p_[q] == run[q] for q in ("kolor", "rozmiar", "interlinia", "font")):
                p_["dl"] += run["dl"]
            else:
                runs.append(run)
    szer_lin = [wiersze[i][1].getlength(" ".join(s_ for s_, _ in wiersze[i][0])) for i in range(len(wiersze))]
    kx = x  # Photoshop: przy center/right punkt zaczepienia to środek / prawa krawędź bloku (tak jak x w planie)
    opis = {"tekst": "".join(teksty), "font": fonty.nazwa_postscript(wiersze[0][2]), "rozmiar": wiersze[0][3],
            "interlinia": wiersze[0][3], "x": kx, "y": bazy[0], "wyrownanie": wyr if wyr in ("center", "right") else "left",
            "runs": runs, "rozmiary": [r[3] for r in wiersze]}
    img = ws.nowa(w.get("nazwa") or " ".join(s_ for r in wiersze for s_, _ in r[0])[:30], opis, float(w.get("krycie", 1)))
    d = ImageDraw.Draw(img)
    for i, (l, font, plik, rozm, kol, kw, inter) in enumerate(wiersze):
        dl = szer_lin[i]
        xx = x - dl / 2 if wyr == "center" else (x - dl if wyr == "right" else x)
        for k, (s_, wyroz) in enumerate(l):
            d.text((xx, bazy[i]), s_, font=font, fill=kw if wyroz else kol, anchor="ls")
            xx += font.getlength(s_ + (" " if k < len(l) - 1 else ""))


def warstwa_tekstu(ws, w, W, H, folder_klienta):
    from PIL import ImageDraw
    if isinstance(w.get("linie"), list) and w["linie"]:
        return warstwa_tekstu_linie(ws, w, W, H, folder_klienta)
    tekst = str(w.get("tekst") or "")
    if w.get("wielkie"):
        tekst = tekst.upper()
    rozm = int(wartosc(w.get("rozmiar", "5%"), H))
    plik, waga = fonty.znajdz_wage(w.get("font"), int(w.get("waga", 700)), folder_klienta, kursywa=bool(w.get("kursywa")))
    if not plik:
        blad(f"Warstwa „{w.get('nazwa', 'tekst')}”: brak fontu {w.get('font')}")
    font = fonty.wczytaj(plik, rozm, waga)
    szer = wartosc(w.get("szer"), W, W * 0.84)
    linie = []
    for kawalek in tekst.split("|"):
        sl = [(s, k is not None) for s, k in grafika.slowa_kolorowe(kawalek)]
        linie += zlam(sl, font, szer) if sl else [[]]
    wyr = w.get("wyrownanie", "left")
    kol, kw = kolor(w.get("kolor")), kolor(w.get("kolor_wyroznienia") or w.get("kolor"))
    inter = int(rozm * float(w.get("interlinia", 1.15)))
    x, y = wartosc(w.get("x"), W), wartosc(w.get("y"), H)
    opis = grafika.opis_tekstu(linie, font, plik, rozm, inter, x, y, kol, kw if w.get("kolor_wyroznienia") else None,
                               "center" if wyr == "center" else "left")
    if wyr == "right":  # Photoshop: punkt zaczepienia lewy; przesuwamy blok tak, żeby prawa krawędź była w x
        opis["x"] = x - max((font.getlength(" ".join(s for s, _ in l)) for l in linie if l), default=0)
    img = ws.nowa(w.get("nazwa") or tekst.replace("|", " ")[:30], opis, float(w.get("krycie", 1)))
    d = ImageDraw.Draw(img)
    yy = y
    for l in linie:
        dl = font.getlength(" ".join(s for s, _ in l))
        xx = x - dl / 2 if wyr == "center" else (x - dl if wyr == "right" else x)
        for k, (s, wyroz) in enumerate(l):
            d.text((xx, yy), s, font=font, fill=kw if wyroz else kol)
            xx += font.getlength(s + (" " if k < len(l) - 1 else ""))
        yy += inter


def rysuj(warstwy, W, H, folder_klienta, ws=None):
    """Rysuje listę warstw na obiekcie grafika.Warstwy (nowym albo podanym, np. z grafika.py)."""
    ws = ws or grafika.Warstwy(W, H)
    for w in warstwy or []:
        typ = w.get("typ", "obraz")
        if typ in ("obraz", "logo"):
            warstwa_obrazu(ws, w, W, H, folder_klienta)
        elif typ == "ksztalt":
            warstwa_ksztaltu(ws, w, W, H)
        elif typ == "tekst":
            warstwa_tekstu(ws, w, W, H, folder_klienta)
        else:
            blad(f"Nieznany typ warstwy: {typ} (obraz, logo, ksztalt, tekst)")
    return ws


def zloz(plan_plik):
    plan = json.loads(Path(sciezka(plan_plik)).read_text(encoding="utf-8"))
    formaty = grafika.dodaj_wlasne(plan.get("formaty") or ["story-9x16"])
    for f in formaty:
        if f not in grafika.FORMATY:
            blad(f"Nieznany format {f}. Dostępne: {', '.join(grafika.FORMATY)} albo wlasny-<szer>x<wys>")
    wyj = sciezka(plan.get("wyjscie") or Path(plan_plik).parent / "grafiki")
    wyj.mkdir(parents=True, exist_ok=True)
    fk = sciezka(plan["folder_klienta"]) / "fonty" if plan.get("folder_klienta") else None
    nazwy, opisy, pliki = [], [], []
    for i, pr in enumerate(plan.get("projekty") or []):
        nazwa = pr.get("nazwa") or f"projekt-{i + 1}"
        nazwy.append(nazwa)
        rz_o, rz_p = [], []
        for f in formaty:
            W, H = grafika.FORMATY[f]
            ws = rysuj((pr.get("warstwy_formatu") or {}).get(f) or pr.get("warstwy"), W, H, fk if fk and fk.exists() else None)
            img = ws.zlacz()
            cel = wyj / f"{i + 1:02d}_{nazwa}_{grafika.SKROTY.get(f, f)}.png"
            img.convert("RGB").save(cel)
            rz_p.append(str(cel))
            rz_o.append(ws.zapisz_do_psd(wyj / "_warstwy" / f"{i + 1:02d}_{f}"))
        opisy.append(rz_o)
        pliki.append(rz_p)
    if not nazwy:
        blad("Plan nie ma żadnego projektu (\"projekty\": [...])")
    psd, uwaga = (None, None)
    if plan.get("psd", True):
        psd, uwaga = grafika.zloz_psd(formaty, nazwy, opisy, pliki, wyj)
        if psd and plan.get("nazwa_psd"):
            nowy = Path(psd).with_name(f"{plan['nazwa_psd']}{Path(psd).suffix}")
            Path(psd).replace(nowy)
            psd = str(nowy)
    import shutil
    shutil.rmtree(wyj / "_warstwy", ignore_errors=True)
    podglad = wyj / "podglad_serii.jpg"
    grafika.arkusz_podgladu(pliki, formaty, podglad)
    wynik(pliki=[p for r in pliki for p in r], psd=psd, uwaga=uwaga, podglad=str(podglad))


if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Grafika z warstw (każdy element osobną warstwą w PSD)")
    ap.add_argument("--plan", required=True)
    zloz(ap.parse_args().plan)
