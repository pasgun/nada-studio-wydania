---
name: brandbook
description: Tworzy brandbook marki (PDF) z linku do strony i materiałów klienta, plus notatkę marki i kartę klienta do Studio. Uruchamiane poleceniem /brandbook z danymi zlecenia w JSON ze Studio Nadamedia.
disable-model-invocation: true
---

Zlecenie ze Studio Nadamedia:

$ARGUMENTS

1. Folder klienta: `zlecenie.folder_klienta` (np. `klienci/emeraldmedia`). Jeśli go nie ma: `python narzedzia/foldery.py --otworz <folder>`.
2. Źródła:
   - linki z `zlecenie.linki`: dla strony www najpierw `python narzedzia/ruch.py strona --url <link> --folder <folder klienta>/brandbook/_zrodla` (dembrandt w prawdziwej przeglądarce: kolory z rolami primary/accent/tło/tekst, fonty nagłówków i tekstu, logo, kontakt; pełne dane w `_zrodla/strona_dembrandt.json`, w tym `motion` = jak strona się porusza, przydatne do „gustu marki”), a potem dla każdego linku `python narzedzia/brandbook.py strona --url <link> --folder <folder klienta>/brandbook/_zrodla` (teksty strony do oceny tonu, kandydaci na logo); dla profili społecznościowych, których nie da się pobrać, użyj WebFetch i opisu z wyszukiwarki
   - materiały: wszystko z `<folder klienta>/brandbook`, `logo`, `referencje/grafiki` (obejrzyj obrazy Read, PDF czytaj po kawałku)
   - opis od użytkownika: `zlecenie.opis`
3. Ustal: kolory (z CSS, logo i materiałów; 3–6 kolorów z nazwami i rolami: główny, akcent, tekst, tło), fonty (z CSS/Google Fonts; jeśli nie wiadomo, dobierz pasujące z Google Fonts i napisz, że to propozycja), logo (najlepsze pliki z `_zrodla` i `logo/`; jeśli brakuje wersji białej na ciemne tło, a logo jest jednokolorowe PNG z przezroczystością, zrób ją: przekoloruj w Pillow na biało i zapisz do `logo/logo_biale.png`), ton i wartości (z tekstów strony), grupę docelową, 2–3 przykładowe zastosowania (nagłówki postów), zakazy.
4. Zapisz `<folder klienta>/brandbook/brandbook.json` (opis pól na górze `narzedzia/brandbook.py`) i uruchom `python narzedzia/brandbook.py pdf --spec <folder klienta>/brandbook/brandbook.json`.
5. Obejrzyj strony z `brandbook/_strony` (Read). Popraw to, co wygląda źle (za długie teksty, logo nieczytelne na tle), i wygeneruj ponownie. Maksymalnie 2 poprawki.
6. Napisz `<folder klienta>/marka.md` według sekcji „Marka i brandbook” w `CLAUDE.md` (role kolorów z brandbooka).
7. `karta_klienta.json` (w folderze klienta) ma pola: `name`, `paleta` (lista #RRGGBB), `fonts` (`heading`, `body`), `tone`, `audience`, `cta`, `notes`, `koloryUwagi` oraz dane kontaktowe ze strony, jeśli są: `www`, `email`, `tel`. Nie zgaduj maili ani telefonów: tylko te, które są na stronie.
8. Raport: ścieżka do PDF, kolory i fonty w jednym zdaniu, co było propozycją (nie z materiałów). Zapisz `karta_klienta.json` w folderze klienta (i zostaw ten w `brandbook/` od `brandbook.py`): Studio po skończeniu zadania samo uzupełni z niego kartę klienta i dołączy PDF (albo utworzy nowego klienta z tą marką), więc nie każ niczego przeklejać. Napisz jednym zdaniem: „Karta klienta w Studio uzupełni się sama; w razie potrzeby w karcie klienta jest przycisk «Wczytaj dane z brandbooka».”
