/* „Ruch na żywo”: przejścia i animacje klipów zrobione wbudowanymi efektami Premiere (Transform, Gaussian Blur, Offset,
   Directional Blur) z klatkami kluczowymi, tak jak Animation Studio. Nic się nie renderuje: Premiere odtwarza to od razu,
   a każda zmiana suwaka w panelu przelicza klatki kluczowe w ułamku sekundy.

   Ten plik tylko LICZY klatki kluczowe (działa w panelu i w Node do testów). Kładzie je na klipach host.jsx: nm_ruch_natywny().

   Opis jednego klipu (spec):
     { we: {rodzaj, dl, sila, ease}, wy: {rodzaj, dl, sila, ease}, caly: {rodzaj, sila}, akcenty: [{rodzaj, t, dl, sila}],
       pelny: true/false (pełny kadr: obrót i wstrząs dostają powiększenie bez czarnych rogów), migawka: 0–360 (rozmycie ruchu) }
   Klip: { start, end (sekundy na osi), fps, W, H }.
   Wynik: { kanaly: {skala:[[t,v]], x:[[t,v]], y, obrot, krycie, rozmycie, ofx, ofy, kier}, kier_kat, migawka, uzyte: [...] }
   Czas t = sekundy na osi sekwencji (host przelicza na czas klipu). x, y, ofx, ofy to przesunięcia w ułamku kadru od środka. */
(function (glob) {
  "use strict";
  const EASE = {
    miekko: { out: (p) => 1 - Math.pow(1 - p, 4), in: (p) => p * p * p },
    ostro: { out: (p) => (p >= 1 ? 1 : 1 - Math.pow(2, -10 * p)) / (1 - Math.pow(2, -10)), in: (p) => (p <= 0 ? 0 : Math.pow(2, 10 * (p - 1)) - Math.pow(2, -10)) / (1 - Math.pow(2, -10)) },
    plynnie: { out: (p) => Math.sin((p * Math.PI) / 2), in: (p) => 1 - Math.cos((p * Math.PI) / 2) },
    sprezyscie: { out: (p) => { const c = 1.4, c3 = c + 1; return 1 + c3 * Math.pow(p - 1, 3) + c * Math.pow(p - 1, 2); }, in: (p) => p * p * p },
    liniowo: { out: (p) => p, in: (p) => p },
  };
  const easeOut = (n, p) => (EASE[n] || EASE.miekko).out(Math.max(0, Math.min(1, p)));
  const easeIn = (n, p) => (EASE[n] || EASE.miekko).in(Math.max(0, Math.min(1, p)));

  /* Przesunięcie (displacement) przy k = 1 (pełne) .. 0 (spoczynek). s = siła (1 = normalnie).
     Zwraca zmiany kanałów: skala (mnożnik), x, y, obrot, krycie (mnożnik), rozmycie, ofx, ofy, kier. */
  const PRZEJSCIA = {
    zoom: { nazwa: "Zoom w przód", opis: "Kadr wjeżdża w następny ujęcie z rozmyciem ruchu", d: (k, s) => ({ skala: 1 + 1.0 * s * k }) },
    "zoom-rozmycie": { nazwa: "Zoom z rozmyciem", opis: "Zoom w przód i miękkie rozmycie na cięciu", d: (k, s) => ({ skala: 1 + 0.6 * s * k, rozmycie: 45 * s * k * k }) },
    "z-bliska": { nazwa: "Wjazd z bliska", opis: "Następne ujęcie odjeżdża z bliska do normalnego kadru", tylkoB: true, d: (k, s) => ({ skala: 1 + 0.8 * s * k }) },
    obrot: { nazwa: "Obrót z zoomem", opis: "Skręt kadru z powiększeniem, bez czarnych rogów", d: (k, s, rola) => ({ skala: 1 + 0.5 * s * k, obrot: (rola === "wy" ? 1 : -1) * 28 * s * k }) },
    "whip-lewo": { nazwa: "Whip w lewo", opis: "Szybki obrót kamery w lewo (obraz się zawija, bez czarnych pasów)", whip: true, d: (k, s, rola) => ({ ofx: (rola === "wy" ? -1 : 1) * 0.5 * k, kier: 140 * s * k }) },
    "whip-prawo": { nazwa: "Whip w prawo", opis: "Szybki obrót kamery w prawo", whip: true, d: (k, s, rola) => ({ ofx: (rola === "wy" ? 1 : -1) * 0.5 * k, kier: 140 * s * k }) },
    "whip-gora": { nazwa: "Whip w górę", opis: "Szybki ruch kamery w górę", whip: true, pion: true, d: (k, s, rola) => ({ ofy: (rola === "wy" ? 1 : -1) * 0.5 * k, kier: 140 * s * k }) },
    "whip-dol": { nazwa: "Whip w dół", opis: "Szybki ruch kamery w dół", whip: true, pion: true, d: (k, s, rola) => ({ ofy: (rola === "wy" ? -1 : 1) * 0.5 * k, kier: 140 * s * k }) },
    rozmycie: { nazwa: "Rozmycie", opis: "Miękkie rozmycie przez cięcie, spokojne", d: (k, s) => ({ rozmycie: 90 * s * k, skala: 1 + 0.05 * k }) },
    wstrzas: { nazwa: "Wstrząs", opis: "Krótkie uderzenie i drganie na początku następnego ujęcia (na bit)", tylkoB: true, wstrzas: true, d: () => ({}) },
  };
  const ELEMENTY = {
    "z-dolu": { nazwa: "Z dołu", d: (k, s) => ({ y: 0.07 * s * k, krycie: 1 - k }) },
    "z-gory": { nazwa: "Z góry", d: (k, s) => ({ y: -0.07 * s * k, krycie: 1 - k }) },
    "z-lewej": { nazwa: "Z lewej", d: (k, s) => ({ x: -0.08 * s * k, krycie: 1 - k }) },
    "z-prawej": { nazwa: "Z prawej", d: (k, s) => ({ x: 0.08 * s * k, krycie: 1 - k }) },
    "zza-kadru": { nazwa: "Zza kadru (bok)", d: (k, s, rola, o) => ({ x: (o.strona === "prawo" ? 1 : -1) * 1.0 * k }) },
    skala: { nazwa: "Powiększenie", d: (k, s) => ({ skala: 1 - 0.12 * s * k, krycie: 1 - k }) },
    pop: { nazwa: "Pop", d: (k, s) => ({ skala: 1 - 0.55 * s * k, krycie: Math.min(1, (1 - k) * 2.5) }) },
    rozmycie: { nazwa: "Z rozmycia", d: (k, s) => ({ rozmycie: 40 * s * k, krycie: 1 - k, skala: 1 + 0.04 * s * k }) },
    zanik: { nazwa: "Zanik", d: (k) => ({ krycie: 1 - k }) },
    obrot: { nazwa: "Obrót", d: (k, s) => ({ obrot: -12 * s * k, skala: 1 - 0.1 * s * k, krycie: 1 - k }) },
  };
  const CALY = {
    "przybliz": { nazwa: "Powolne przybliżenie", d: (p, s) => ({ skala: 1 + 0.1 * s * p }) },
    "oddal": { nazwa: "Powolne oddalenie", d: (p, s) => ({ skala: 1 + 0.1 * s * (1 - p) }) },
    "dryf-prawo": { nazwa: "Dryf w prawo", d: (p, s) => ({ skala: 1 + 0.08 * s, x: 0.03 * s * (p - 0.5) * 2 }) },
    "dryf-lewo": { nazwa: "Dryf w lewo", d: (p, s) => ({ skala: 1 + 0.08 * s, x: -0.03 * s * (p - 0.5) * 2 }) },
  };

  // powtarzalny „los” do wstrząsu (bez Math.random: ta sama zmiana suwaka = ten sam wynik)
  function szum(i, ziarno) { const x = Math.sin((i + 1) * 12.9898 + ziarno * 78.233) * 43758.5453; return (x - Math.floor(x)) * 2 - 1; }

  // najmniejsza skala, przy której obrócony o kąt kadr W×H wciąż zakrywa cały ekran
  function oslona(katDeg, W, H) {
    const t = Math.abs(katDeg) * Math.PI / 180, a = W / 2, b = H / 2, c = Math.cos(t), s = Math.sin(t);
    return Math.max((a * c + b * s) / a, (a * s + b * c) / b);
  }

  function zero() { return { skala: 1, x: 0, y: 0, obrot: 0, krycie: 1, rozmycie: 0, ofx: 0, ofy: 0, kier: 0 }; }
  function dodaj(acc, d) {
    if (!d) return acc;
    if (d.skala != null) acc.skala *= d.skala;
    if (d.krycie != null) acc.krycie *= Math.max(0, Math.min(1, d.krycie));
    ["x", "y", "obrot", "rozmycie", "ofx", "ofy"].forEach((k) => { if (d[k] != null) acc[k] += d[k]; });
    if (d.kier != null) acc.kier = Math.max(acc.kier, d.kier);
    return acc;
  }

  function presetRoli(r) {
    if (!r || !r.rodzaj) return null;
    return (r.przejscie ? (PRZEJSCIA[r.rodzaj] || ELEMENTY[r.rodzaj]) : (ELEMENTY[r.rodzaj] || PRZEJSCIA[r.rodzaj])) || null;
  }

  /* Klatki kluczowe dla jednego klipu. */
  function oblicz(klip, spec) {
    const fps = +klip.fps || 30, W = +klip.W || 1080, H = +klip.H || 1920;
    const N = Math.max(1, Math.round((klip.end - klip.start) * fps));
    const tKl = (i) => klip.start + i / fps;
    const wyn = { kanaly: {}, kier_kat: 90, migawka: spec.migawka == null ? 240 : +spec.migawka, uzyte: [], uwagi: [] };
    const we = spec.we && presetRoli(spec.we), wy = spec.wy && presetRoli(spec.wy);
    let nWe = we ? Math.max(2, Math.round((+spec.we.dl || 0.4) * fps)) : 0, nWy = wy ? Math.max(2, Math.round((+spec.wy.dl || 0.4) * fps)) : 0;
    // krótki klip: wejście i wyjście dzielą klip, żeby się nie nakładały
    if (nWe + nWy > N) { const f = N / (nWe + nWy); nWe = Math.max(we ? 1 : 0, Math.floor(nWe * f)); nWy = Math.max(wy ? 1 : 0, Math.floor(nWy * f)); wyn.uwagi.push("Klip jest krótszy niż wejście i wyjście razem: oba skrócone."); }
    const opt = (r) => ({ strona: r.strona || "lewo" });
    const wstrzasy = [];
    if (we && we.wstrzas) wstrzasy.push({ i0: 0, n: nWe, s: +spec.we.sila || 1 });
    (spec.akcenty || []).forEach((a) => {
      const i0 = Math.round((a.t - klip.start) * fps);
      if (i0 < 0 || i0 >= N) return;
      const n = Math.max(3, Math.round((+a.dl || (a.rodzaj === "punch" ? 0.3 : 0.4)) * fps));
      if (a.rodzaj === "wstrzas") wstrzasy.push({ i0, n, s: +a.sila || 1 });
      else wstrzasy.push({ i0, n, s: +a.sila || 1, punch: true });
    });
    if (we && we.whip || wy && wy.whip) wyn.kier_kat = (we && we.whip ? we : wy).pion ? 0 : 90;
    const ramki = [];
    for (let i = 0; i < N; i++) {
      const acc = zero();
      if (spec.caly && CALY[spec.caly.rodzaj]) {
        const p = N > 1 ? i / (N - 1) : 0, pe = (1 - Math.cos(p * Math.PI)) / 2;
        dodaj(acc, CALY[spec.caly.rodzaj].d(pe, +spec.caly.sila || 1));
      }
      if (we && !we.wstrzas && i <= nWe) dodaj(acc, we.d(1 - easeOut(spec.we.ease || "miekko", i / nWe), +spec.we.sila || 1, "we", opt(spec.we)));
      const j = i - (N - 1 - nWy);
      if (wy && j >= 0) dodaj(acc, wy.d(easeIn(spec.wy.ease || "miekko", j / nWy), +spec.wy.sila || 1, "wy", opt(spec.wy)));
      wstrzasy.forEach((w, nr) => {
        const di = i - w.i0;
        if (di < 0 || di > w.n) return;
        const zan = Math.pow(1 - di / w.n, 2);
        if (w.punch) { const p = di <= 2 ? di / 2 : 1 - easeOut("miekko", (di - 2) / Math.max(1, w.n - 2)); dodaj(acc, { skala: 1 + 0.12 * w.s * p }); return; }
        dodaj(acc, { x: 0.018 * w.s * zan * szum(di, nr + 1), y: 0.014 * w.s * zan * szum(di + 50, nr + 7), obrot: 1.2 * w.s * zan * szum(di + 99, nr + 3), skala: 1 + 0.06 * w.s * zan });
      });
      if (spec.pelny) {
        // pełny kadr: obrót i przesunięcie bez czarnych rogów (powiększenie z zapasem)
        const pot = oslona(acc.obrot, W, H) * (1 + 2 * Math.max(Math.abs(acc.x), Math.abs(acc.y)));
        if (acc.skala < pot) acc.skala = pot;
      }
      ramki.push(acc);
    }
    const kan = { skala: (a) => a.skala * 100, x: (a) => a.x, y: (a) => a.y, obrot: (a) => a.obrot, krycie: (a) => a.krycie * 100, rozmycie: (a) => a.rozmycie, ofx: (a) => a.ofx, ofy: (a) => a.ofy, kier: (a) => a.kier };
    const spocz = { skala: 100, x: 0, y: 0, obrot: 0, krycie: 100, rozmycie: 0, ofx: 0, ofy: 0, kier: 0 };
    const tol = { skala: 0.05, x: 0.0004, y: 0.0004, obrot: 0.02, krycie: 0.2, rozmycie: 0.2, ofx: 0.0004, ofy: 0.0004, kier: 0.3 };
    Object.keys(kan).forEach((k) => {
      const w = ramki.map(kan[k]);
      if (w.every((v) => Math.abs(v - spocz[k]) < tol[k])) return;
      wyn.kanaly[k] = upros(w.map((v, i) => [tKl(i), +v.toFixed(k === "skala" || k === "krycie" ? 3 : 5)]), tol[k]);
      wyn.uzyte.push(k);
    });
    return wyn;
  }

  /* Usuwa klatki, które leżą na prostej między sąsiadami (zostają tylko potrzebne: mniej pracy dla Premiere). */
  function upros(kl, tol) {
    if (kl.length <= 2) return kl;
    const w = [kl[0]];
    for (let i = 1; i < kl.length - 1; i++) {
      const a = w[w.length - 1], b = kl[i], c = kl[i + 1];
      const lin = a[1] + (c[1] - a[1]) * ((b[0] - a[0]) / (c[0] - a[0]));
      if (Math.abs(lin - b[1]) > tol / 2) w.push(b);
    }
    w.push(kl[kl.length - 1]);
    return w;
  }

  /* Przejście na cięciu: spec dla klipu A (przed cięciem) i B (po cięciu). */
  function przejscie(rodzaj, o) {
    o = o || {};
    const p = PRZEJSCIA[rodzaj]; if (!p) throw new Error("Nie ma przejścia " + rodzaj);
    const dl = +o.dl || 0.35, sila = o.sila == null ? 1 : +o.sila, ease = o.ease || (p.whip ? "ostro" : "miekko");
    return { a: p.tylkoB ? null : { rodzaj, dl, sila, ease, przejscie: true }, b: { rodzaj, dl: p.wstrzas ? Math.max(dl, 0.35) : dl, sila, ease, przejscie: true } };
  }

  /* Jakie efekty Premiere są potrzebne dla wyniku oblicz(). */
  function efekty(w) {
    const u = w.uzyte, e = [];
    if (u.some((k) => k === "ofx" || k === "ofy")) e.push("offset");
    if (u.includes("kier")) e.push("kierunkowe");
    if (u.includes("rozmycie")) e.push("gauss");
    if (u.some((k) => ["skala", "x", "y", "obrot", "krycie"].includes(k))) e.push("transform");
    return e;
  }

  const API = { oblicz, przejscie, efekty, oslona, upros, PRZEJSCIA, ELEMENTY, CALY, EASE };
  if (typeof module !== "undefined" && module && module.exports) module.exports = API;
  if (glob) glob.RN = API; // panel CEP: window.RN (także gdy Node dał „module”)
})(typeof window !== "undefined" ? window : this);
